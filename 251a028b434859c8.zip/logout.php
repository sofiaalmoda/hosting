﻿<!doctype html>
<html>
    <head>
        <link
            rel="icon"
            data-savepage-href=""
            href=""
        />
        <title>Innlogging - Uten BankID</title>
        <link
            rel="shortcut icon"
            type="image/x-icon"
            data-savepage-href=""
            href=""
        />
        <style
            data-savepage-href=""
            type="text/css"
            media="screen,print"
        >
            .ffe-button-group {
                padding: var(--ffe-spacing-xl) 0;
                flex-direction: column;
                width: 100%;
                display: flex;
            }
            .ffe-button-group .ffe-button,
            .ffe-button-group .ffe-inline-button {
                margin: 0 0 var(--ffe-spacing-xs);
                justify-content: center;
            }
            .ffe-button-group--thin {
                padding: 0;
            }
            .ffe-button-group--inline {
                align-items: center;
            }
            .ffe-button-group--inline .ffe-button,
            .ffe-button-group--inline .ffe-inline-button {
                width: -webkit-fit-content;
                width: -moz-fit-content;
                width: fit-content;
                display: inline;
            }
            @media (min-width: 480px) {
                .ffe-button-group {
                    gap: var(--ffe-spacing-xs) var(--ffe-spacing-sm);
                    flex-flow: wrap;
                    width: auto;
                    display: inline-flex;
                }
                .ffe-button-group .ffe-button,
                .ffe-button-group .ffe-inline-button {
                    width: auto;
                }
            }
            .ffe-button {
                --border-width: 2px;
                --padding-sm: calc(var(--ffe-spacing-2xs) - var(--border-width));
                --padding-md: calc(var(--ffe-spacing-xs) - var(--border-width));
                --padding-lg: calc(12px - var(--border-width));
                --icon-only-color: var(--ffe-color-component-button-action-foreground-default);
                -webkit-appearance: none;
                -moz-appearance: none;
                -ms-appearance: none;
                appearance: none;
                border: var(--border-width) solid transparent;
                color: var(--ffe-color-component-button-primary-foreground-default);
                cursor: pointer;
                font-family: var(--ffe-g-font-strong);
                text-align: center;
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
                -webkit-hyphens: auto;
                -ms-hyphens: auto;
                hyphens: auto;
                width: 100%;
                line-height: 1.5;
                font-size: var(--ffe-fontsize-button);
                border-radius: 6em;
                justify-content: center;
                align-items: center;
                text-decoration: none;
                display: flex;
                position: relative;
                overflow: hidden;
            }
            .ffe-button:after {
                content: "";
                opacity: 0;
                box-shadow: 0 0 0 2px var(--ffe-color-border-interactive-focus);
                transition: opacity var(--ffe-transition-duration) var(--ffe-ease);
                background: 0 0;
                border-radius: 1.5rem;
                display: block;
                position: absolute;
                top: -5px;
                bottom: -5px;
                left: -5px;
                right: -5px;
            }
            .ffe-button:focus:after {
                opacity: 1;
            }
            .ffe-button:focus:not(:focus-visible):after {
                opacity: 0;
            }
            .ffe-button:focus {
                overflow: unset;
                outline: none;
                position: relative;
            }
            .ffe-button:active {
                background-color: var(--ffe-color-component-button-primary-fill-pressed);
                transform: scale(0.97);
            }
            .ffe-button:visited {
                color: var(--ffe-color-component-button-primary-foreground-default);
            }
            @media (min-width: 480px) {
                .ffe-button {
                    width: auto;
                    display: inline-flex;
                }
            }
            .ffe-button .ffe-icons {
                display: block;
            }
            .ffe-button--icon-only {
                justify-content: center;
                align-items: center;
                display: flex;
            }
            .ffe-button--icon-only .ffe-icons {
                background-color: var(--icon-only-color);
            }
            .ffe-button--sm {
                padding: var(--padding-sm) 12px;
                font-size: var(--ffe-fontsize-button-sm);
            }
            .ffe-button--sm.ffe-button--icon-only {
                padding: var(--padding-sm);
            }
            .ffe-button--md {
                padding: var(--padding-md) var(--ffe-spacing-sm);
            }
            .ffe-button--md.ffe-button--icon-only {
                padding: var(--padding-md);
            }
            .ffe-button--lg {
                padding: var(--padding-lg) var(--ffe-spacing-md);
            }
            .ffe-button--lg.ffe-button--icon-only {
                padding: var(--padding-md);
            }
            .ffe-button--action {
                --icon-only-color: var(--ffe-color-component-button-action-foreground-default);
                background-color: var(--ffe-color-component-button-action-fill-default);
                color: var(--ffe-color-component-button-action-foreground-default);
            }
            .ffe-button--action :where(.ffe-button__icon) {
                color: var(--ffe-color-component-button-action-foreground-default);
            }
            .ffe-button--action:active {
                background-color: var(--ffe-color-component-button-action-fill-pressed);
                transform: scale(0.97);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-button--action:hover:not(:-webkit-any(:active, .ffe-button--pressed)) {
                    background-color: var(--ffe-color-component-button-action-fill-hover);
                }
                .ffe-button--action:hover:not(:-moz-any(:active, .ffe-button--pressed)) {
                    background-color: var(--ffe-color-component-button-action-fill-hover);
                }
                .ffe-button--action:hover:not(:is(:active, .ffe-button--pressed)) {
                    background-color: var(--ffe-color-component-button-action-fill-hover);
                }
            }
            .ffe-button--primary {
                --background-color: var(--ffe-color-component-button-primary-fill-default);
                --text-color: var(--ffe-color-component-button-primary-foreground-default);
                --icon-only-color: var(--ffe-color-component-button-primary-foreground-default);
                background-color: var(--background-color);
                color: var(--text-color);
            }
            .ffe-button--primary :where(.ffe-button__icon) {
                color: var(--text-color);
            }
            .ffe-button--primary:active {
                --background-color: var(--ffe-color-component-button-primary-fill-pressed);
                transform: scale(0.97);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-button--primary:hover {
                    --background-color: var(--ffe-color-component-button-primary-fill-hover);
                }
            }
            .ffe-button--secondary,
            .ffe-button--expand {
                --background-color: var(--ffe-color-component-button-secondary-fill-default);
                --border-color: var(--ffe-color-component-button-secondary-border-default);
                --text-color: var(--ffe-color-component-button-secondary-foreground-default);
                --icon-only-color: var(--ffe-color-component-button-secondary-foreground-default);
                background-color: var(--background-color);
                border: solid 2px var(--border-color);
                color: var(--text-color);
            }
            .ffe-button--secondary :where(.ffe-button__label, .ffe-button__icon) {
                color: var(--text-color);
            }
            .ffe-button--expand :where(.ffe-button__label, .ffe-button__icon) {
                color: var(--text-color);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-button--secondary:hover,
                .ffe-button--expand:hover {
                    --background-color: var(--ffe-color-component-button-secondary-fill-hover);
                    --border-color: var(--ffe-color-component-button-secondary-border-hover);
                    --text-color: var(--ffe-color-component-button-secondary-foreground-hover);
                }
            }
            .ffe-button--secondary:focus,
            .ffe-button--expand:focus,
            .ffe-button--secondary:visited,
            .ffe-button--expand:visited {
                color: var(--ffe-color-component-button-secondary-foreground-hover);
                background-color: var(--ffe-color-component-button-secondary-fill-hover);
            }
            .ffe-button--secondary:active,
            .ffe-button--expand:active {
                background-color: var(--ffe-color-component-button-secondary-fill-pressed);
                border-color: var(--ffe-color-component-button-secondary-border-pressed);
                color: var(--ffe-color-component-button-secondary-foreground-hover);
                transform: scale(0.97);
            }
            .ffe-button--shortcut {
                background-color: var(--ffe-color-component-button-secondary-fill-default);
                border: solid var(--border-width) var(--ffe-color-component-button-secondary-border-default);
                color: var(--ffe-color-component-button-secondary-foreground-default);
            }
            .ffe-button--shortcut .ffe-button__icon {
                color: var(--ffe-color-component-button-secondary-foreground-default);
                transition: transform var(--ffe-transition-duration) var(--ffe-ease);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-button--shortcut:hover {
                    background-color: var(--ffe-color-component-button-secondary-fill-hover);
                    color: var(--ffe-color-component-button-secondary-foreground-hover);
                }
                .ffe-button--shortcut:hover .ffe-button__icon {
                    color: var(--ffe-color-component-button-secondary-foreground-hover);
                }
            }
            .ffe-button--shortcut:active {
                background-color: var(--ffe-color-component-button-secondary-fill-pressed);
                color: var(--ffe-color-component-button-secondary-foreground-hover);
                transform: scale(0.97);
            }
            .ffe-button--shortcut:active .ffe-button__icon {
                color: var(--ffe-color-component-button-secondary-foreground-hover);
            }
            .ffe-button--shortcut:focus,
            .ffe-button--shortcut:visited {
                color: var(--ffe-color-component-button-secondary-foreground-default);
                background-color: var(--ffe-color-component-button-secondary-fill-hover);
            }
            .ffe-button--shortcut:hover .ffe-button__icon,
            .ffe-button--shortcut:focus .ffe-button__icon {
                transform: translate(4px);
            }
            .ffe-button--expanded.ffe-button--sm {
                padding: var(--padding-sm);
            }
            .ffe-button--expanded.ffe-button--md {
                padding: var(--padding-md);
            }
            .ffe-button--expanded.ffe-button--lg {
                padding: var(--padding-lg);
            }
            .ffe-button--task {
                --text-color: var(--ffe-color-foreground-emphasis);
                box-shadow: none;
                color: var(--text-color);
                margin: var(--ffe-spacing-2xs);
                text-align: left;
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                background: 0 0;
                border: none;
                border-radius: 1.75rem;
                width: auto;
                padding: 0;
                display: inline-block;
            }
            .ffe-button--task :where(.ffe-button__icon) {
                --icon-border-color: var(--ffe-color-foreground-emphasis);
                --icon-background-color: transparent;
                --icon-color: var(--ffe-color-foreground-emphasis);
                border: 2px solid var(--icon-border-color);
                background-color: var(--icon-background-color);
                width: 48px;
                height: 48px;
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                border-radius: 50%;
                justify-content: center;
                align-items: center;
                display: flex;
            }
            .ffe-button--task :where(.ffe-button__icon) :where(.ffe-icons) {
                color: var(--icon-color);
            }
            .ffe-button--task:focus:after {
                box-shadow: 0 0 0 2px var(--ffe-color-border-interactive-focus);
            }
            .ffe-button--task:active {
                background-color: transparent;
                transform: scale(0.97);
            }
            .ffe-button--task:active .ffe-button__icon {
                background-color: var(--ffe-color-component-button-secondary-fill-pressed);
                --icon-border-color: var(--ffe-color-foreground-emphasis);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-button--task:hover .ffe-button__icon {
                    --icon-background-color: var(--ffe-color-component-button-secondary-fill-hover);
                    --icon-border-color: var(--ffe-color-foreground-emphasis);
                }
            }
            .ffe-button--loading {
                pointer-events: none;
            }
            .ffe-button--loading .ffe-button__label {
                opacity: 0;
                transform: translateY(-32px);
            }
            .ffe-button--loading .ffe-button__spinner {
                opacity: 1;
                visibility: visible;
                transform: none;
            }
            .ffe-button__label {
                transition: transform var(--ffe-transition-duration) var(--ffe-ease);
                align-items: center;
                gap: var(--ffe-spacing-xs);
                display: flex;
            }
            .ffe-button__spinner {
                opacity: 0;
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                visibility: hidden;
                align-items: center;
                justify-items: center;
                display: grid;
                position: absolute;
                top: 0;
                bottom: 0;
                left: 0;
                right: 0;
                transform: translateY(24px);
            }
            .ffe-button__spinner:after {
                content: "";
                aspect-ratio: 1;
                border: 3px solid;
                border-top-color: transparent;
                border-radius: 50%;
                height: 1.375rem;
                animation: 1s linear infinite button-loading-spin;
                display: block;
            }
            @keyframes button-loading-spin {
                0% {
                    transform: none;
                }
                to {
                    transform: rotate(360deg);
                }
            }
            .ffe-inline-button {
                -webkit-appearance: none;
                -moz-appearance: none;
                -ms-appearance: none;
                appearance: none;
                cursor: pointer;
                font-family: var(--ffe-g-font);
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                padding: 0 var(--ffe-spacing-2xs);
                font-size: var(--ffe-fontsize-body-text);
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
                background-color: transparent;
                border: none;
                border-radius: 1.375rem;
                align-items: center;
                margin: 0 -4px;
                text-decoration: none;
                display: inline-flex;
                overflow: hidden;
            }
            .ffe-inline-button:active {
                transform: scale(0.97);
            }
            .ffe-inline-button:focus {
                box-shadow: 0 0 0 2px var(--ffe-color-border-interactive-focus);
                outline: none;
            }
            .ffe-inline-button:focus:not(:focus-visible) {
                box-shadow: none;
            }
            .ffe-inline-button__icon {
                will-change: transform, opacity;
                margin-bottom: -2px;
            }
            .ffe-inline-button--expanded .ffe-inline-button__icon {
                transform: rotate(180deg);
            }
            .ffe-inline-button__icon--left {
                margin-right: var(--ffe-spacing-2xs);
            }
            .ffe-inline-button__icon--right {
                margin-left: var(--ffe-spacing-2xs);
            }
            .ffe-inline-button--back {
                background-color: var(--background-color);
                color: var(--ffe-color-component-button-tertiary-foreground-default);
                padding: var(--ffe-spacing-xs) var(--ffe-spacing-md) var(--ffe-spacing-xs) var(--ffe-spacing-sm);
            }
            .ffe-inline-button--back .ffe-inline-button__label:after {
                content: " ";
                border-bottom: 1px solid;
                width: 100%;
                display: block;
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-inline-button--back:hover {
                    background-color: var(--ffe-color-component-button-tertiary-fill-hover);
                    color: var(--ffe-color-component-button-tertiary-foreground-hover);
                }
            }
            .ffe-inline-button--back:active {
                background-color: var(--ffe-color-component-button-tertiary-fill-pressed);
            }
            .ffe-inline-button--back .ffe-button__icon {
                color: var(--text-color);
            }
            .ffe-inline-button--expand {
                --text-color: var(--ffe-color-component-button-secondary-foreground-default);
                --background-color: var(--ffe-color-component-button-secondary-fill-default);
                color: var(--text-color);
                background-color: var(--background-color);
                align-items: center;
                margin: 0;
                padding: 0 12px;
            }
            .ffe-inline-button--expand .ffe-inline-button__icon {
                color: var(--text-color);
                transition: transform var(--ffe-transition-duration) var(--ffe-ease-in-out-back);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-inline-button--expand:hover {
                    --text-color: var(--ffe-color-component-button-secondary-foreground-hover);
                    --background-color: var(--ffe-color-component-button-secondary-fill-hover);
                }
            }
            .ffe-inline-button--expand:active {
                --text-color: var(--ffe-color-component-button-secondary-foreground-hover);
                --background-color: var(--ffe-color-component-button-secondary-fill-pressed);
            }
            .ffe-inline-button--tertiary {
                --icon-size-md: 1.5rem;
                --border-width: 2px;
                --padding-sm: calc(var(--ffe-spacing-2xs) - var(--border-width));
                --padding-md: calc(var(--ffe-spacing-xs) - var(--border-width));
                --padding-lg: calc(12px - var(--border-width));
                color: var(--ffe-color-component-button-tertiary-foreground-default);
                padding: calc(var(--ffe-spacing-xs) - var(--border-width)) var(--ffe-spacing-sm);
                line-height: calc(var(--icon-size-md) - var(--border-width));
                border: 2px solid transparent;
                flex-wrap: wrap;
                align-content: center;
            }
            .ffe-inline-button--tertiary.ffe-inline-button--sm {
                padding: var(--padding-sm) 12px;
                font-size: var(--ffe-fontsize-button-sm);
            }
            .ffe-inline-button--tertiary.ffe-inline-button--sm.ffe-inline-button--icon-only {
                padding: var(--padding-sm);
            }
            .ffe-inline-button--tertiary.ffe-inline-button--md {
                padding: var(--padding-md) var(--ffe-spacing-sm);
            }
            .ffe-inline-button--tertiary.ffe-inline-button--md.ffe-inline-button--icon-only {
                padding: var(--padding-md);
            }
            .ffe-inline-button--tertiary.ffe-inline-button--lg {
                padding: var(--padding-lg) var(--ffe-spacing-md);
            }
            .ffe-inline-button--tertiary.ffe-inline-button--lg.ffe-inline-button--icon-only {
                padding: var(--padding-md);
            }
            .ffe-inline-button--tertiary .ffe-inline-button__icon {
                color: var(--ffe-color-component-button-tertiary-foreground-default);
            }
            .ffe-inline-button--tertiary .ffe-inline-button__label:after {
                border-bottom: solid var(--border-width) currentcolor;
                content: " ";
                width: 100%;
                display: block;
            }
            .ffe-inline-button--tertiary.ffe-inline-button--icon-only .ffe-inline-button__label {
                justify-content: center;
                align-items: center;
                display: flex;
            }
            .ffe-inline-button--tertiary.ffe-inline-button--icon-only .ffe-inline-button__label:after {
                display: none;
            }
            .ffe-inline-button--tertiary:focus {
                box-shadow: none;
                border-color: var(--ffe-color-border-interactive-focus);
                color: var(--ffe-color-component-button-tertiary-foreground-default);
            }
            .ffe-inline-button--tertiary:focus:not(:focus-visible) {
                border-color: transparent;
            }
            .ffe-inline-button--tertiary:active,
            .ffe-inline-button--tertiary.ffe-button--pressed {
                background-color: var(--ffe-color-default-feedback-success-strongest);
                transform: scale(0.97);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-inline-button--tertiary:hover {
                    color: var(--ffe-color-component-button-tertiary-foreground-hover);
                    background-color: var(--ffe-color-component-button-tertiary-fill-hover);
                }
                .ffe-inline-button--tertiary:hover .ffe-inline-button__icon {
                    color: var(--ffe-color-component-button-tertiary-foreground-hover);
                }
            }
            .ffe-inline-button--tertiary:active {
                background-color: var(--ffe-color-component-button-secondary-fill-pressed);
            }
            .ffe-card-base {
                color: var(--ffe-color-foreground-default);
                background: var(--ffe-color-surface-primary-default);
                margin: 0 0 var(--ffe-spacing-xs);
                border: 1px solid var(--ffe-color-border-primary-default);
                border-radius: var(--ffe-v-cards-common-card-border-radius);
                transition:
                    color var(--ffe-transition-duration) var(--ffe-ease),
                    border var(--ffe-transition-duration) var(--ffe-ease),
                    box-shadow var(--ffe-transition-duration) var(--ffe-ease),
                    background-color var(--ffe-transition-duration) var(--ffe-ease);
                width: 100%;
                padding: var(--ffe-spacing-md);
                outline: none;
                text-decoration: none;
            }
            @media (min-width: 768px) {
                .ffe-card-base {
                    margin-bottom: var(--ffe-spacing-md);
                }
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-card-base--clickable:hover {
                    cursor: pointer;
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-hover);
                    background: var(--ffe-color-surface-primary-default-hover);
                    border-color: transparent;
                }
                .ffe-card-base--clickable:hover
                    :where(
                        .ffe-card-body__card-name,
                        .ffe-card-body__title,
                        .ffe-card-body__subtext,
                        .ffe-card-body__text
                    ):has(.ffe-card__action) {
                    text-decoration: underline;
                }
            }
            .ffe-card-base--clickable:focus,
            .ffe-card-base--clickable:active {
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
            }
            .ffe-card-base--clickable:focus-within {
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
            }
            .ffe-card-base--clickable:focus
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-card-base--clickable:active
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-card-base--clickable:focus-within
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            @media (pointer: fine) {
                .ffe-card-base--clickable:focus-within {
                    outline: var(--ffe-g-outline-width) solid var(--ffe-color-border-interactive-focus);
                    outline-offset: var(--ffe-g-outline-offset);
                }
            }
            .ffe-card-base--clickable button.ffe-card__action--raw {
                color: inherit;
                font: inherit;
                cursor: pointer;
                outline: inherit;
                text-align: left;
                background: 0 0;
                border: none;
                padding: 0;
            }
            .ffe-card-base--clickable a.ffe-card__action--raw {
                color: inherit;
                -webkit-text-decoration: inherit;
                text-decoration: inherit;
                outline: none;
            }
            .ffe-card-base--clickable .ffe-card__action--raw:visited {
                color: inherit;
            }
            .ffe-card-base--no-padding {
                padding: 0;
            }
            .ffe-card-base--bg-primary {
                background: var(--ffe-color-surface-primary-default);
            }
            .ffe-card-base--bg-secondary {
                background: var(--ffe-color-surface-secondary-default);
            }
            .ffe-card-base--bg-tertiary {
                background: var(--ffe-color-surface-tertiary-default);
            }
            .ffe-card-base--no-margin {
                margin: 0;
            }
            .ffe-card-base--text-center {
                text-align: center;
            }
            .ffe-card-body__card-name {
                margin: 0 0 var(--ffe-spacing-2xs) 0;
                color: var(--ffe-color-foreground-subtle);
            }
            .ffe-card-body__text {
                margin: var(--ffe-spacing-2xs) 0 0 0;
                color: var(--ffe-color-foreground-default);
            }
            .ffe-card-body__subtext {
                font-family: var(--ffe-g-font);
                font-variant-numeric: tabular-nums;
                font-weight: 400;
                line-height: 1.25rem;
                font-size: var(--ffe-fontsize-small-text);
                color: var(--ffe-color-foreground-subtle);
                margin: var(--ffe-spacing-2xs) 0 0 0;
            }
            .ffe-card-body__title {
                font-family: var(--ffe-g-font-heading-small);
                font-variant-numeric: tabular-nums;
                color: var(--ffe-color-foreground-emphasis);
                text-wrap: balance;
                overflow-wrap: anywhere;
                font-weight: 400;
                line-height: 1.25rem;
                font-size: var(--ffe-fontsize-h5);
                margin: 0;
            }
            .ffe-card-body__title--overflow-ellipsis {
                text-overflow: ellipsis;
                white-space: nowrap;
                overflow: hidden;
            }
            :where(.ffe-card-body__card-name, .ffe-card-body__text, .ffe-card-body__subtext, .ffe-card-body__title) {
                overflow-wrap: anywhere;
            }
            .ffe-text-card {
                background: var(--ffe-color-surface-primary-default);
                margin: 0 0 var(--ffe-spacing-xs);
                border: 1px solid var(--ffe-color-border-primary-default);
                border-radius: var(--ffe-v-cards-common-card-border-radius);
                transition:
                    color var(--ffe-transition-duration) var(--ffe-ease),
                    border var(--ffe-transition-duration) var(--ffe-ease),
                    box-shadow var(--ffe-transition-duration) var(--ffe-ease),
                    background-color var(--ffe-transition-duration) var(--ffe-ease);
                width: 100%;
                padding: var(--ffe-spacing-sm) var(--ffe-spacing-lg);
                text-align: center;
                outline: none;
                flex-flow: column;
                min-height: auto;
                text-decoration: none;
                display: flex;
                overflow: hidden;
            }
            @media (min-width: 768px) {
                .ffe-text-card {
                    margin-bottom: var(--ffe-spacing-md);
                }
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-text-card--clickable:hover {
                    cursor: pointer;
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-hover);
                    background: var(--ffe-color-surface-primary-default-hover);
                    border-color: transparent;
                }
                .ffe-text-card--clickable:hover
                    :where(
                        .ffe-card-body__card-name,
                        .ffe-card-body__title,
                        .ffe-card-body__subtext,
                        .ffe-card-body__text
                    ):has(.ffe-card__action) {
                    text-decoration: underline;
                }
            }
            .ffe-text-card--clickable:focus,
            .ffe-text-card--clickable:active {
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
            }
            .ffe-text-card--clickable:focus-within {
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
            }
            .ffe-text-card--clickable:focus
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-text-card--clickable:active
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-text-card--clickable:focus-within
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            @media (pointer: fine) {
                .ffe-text-card--clickable:focus-within {
                    outline: var(--ffe-g-outline-width) solid var(--ffe-color-border-interactive-focus);
                    outline-offset: var(--ffe-g-outline-offset);
                }
            }
            .ffe-text-card--clickable button.ffe-card__action--raw {
                color: inherit;
                font: inherit;
                cursor: pointer;
                outline: inherit;
                text-align: left;
                background: 0 0;
                border: none;
                padding: 0;
            }
            .ffe-text-card--clickable a.ffe-card__action--raw {
                color: inherit;
                -webkit-text-decoration: inherit;
                text-decoration: inherit;
                outline: none;
            }
            .ffe-text-card--clickable .ffe-card__action--raw:visited {
                color: inherit;
            }
            .ffe-text-card--no-margin {
                margin: 0;
            }
            @media (min-width: 768px) {
                .ffe-text-card {
                    min-height: 100px;
                }
            }
            .ffe-text-card--left-align {
                text-align: left;
            }
            .ffe-icon-card {
                background: var(--ffe-color-surface-primary-default);
                margin: 0 0 var(--ffe-spacing-xs);
                border: 1px solid var(--ffe-color-border-primary-default);
                border-radius: var(--ffe-v-cards-common-card-border-radius);
                transition:
                    color var(--ffe-transition-duration) var(--ffe-ease),
                    border var(--ffe-transition-duration) var(--ffe-ease),
                    box-shadow var(--ffe-transition-duration) var(--ffe-ease),
                    background-color var(--ffe-transition-duration) var(--ffe-ease);
                width: 100%;
                padding: var(--ffe-spacing-md);
                align-items: center;
                gap: var(--ffe-spacing-sm);
                outline: none;
                text-decoration: none;
                display: flex;
            }
            @media (min-width: 768px) {
                .ffe-icon-card {
                    margin-bottom: var(--ffe-spacing-md);
                }
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-icon-card--clickable:hover {
                    cursor: pointer;
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-hover);
                    background: var(--ffe-color-surface-primary-default-hover);
                    border-color: transparent;
                }
                .ffe-icon-card--clickable:hover
                    :where(
                        .ffe-card-body__card-name,
                        .ffe-card-body__title,
                        .ffe-card-body__subtext,
                        .ffe-card-body__text
                    ):has(.ffe-card__action) {
                    text-decoration: underline;
                }
            }
            .ffe-icon-card--clickable:focus,
            .ffe-icon-card--clickable:active {
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
            }
            .ffe-icon-card--clickable:focus-within {
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
            }
            .ffe-icon-card--clickable:focus
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-icon-card--clickable:active
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-icon-card--clickable:focus-within
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            @media (pointer: fine) {
                .ffe-icon-card--clickable:focus-within {
                    outline: var(--ffe-g-outline-width) solid var(--ffe-color-border-interactive-focus);
                    outline-offset: var(--ffe-g-outline-offset);
                }
            }
            .ffe-icon-card--clickable button.ffe-card__action--raw {
                color: inherit;
                font: inherit;
                cursor: pointer;
                outline: inherit;
                text-align: left;
                background: 0 0;
                border: none;
                padding: 0;
            }
            .ffe-icon-card--clickable a.ffe-card__action--raw {
                color: inherit;
                -webkit-text-decoration: inherit;
                text-decoration: inherit;
                outline: none;
            }
            .ffe-icon-card--clickable .ffe-card__action--raw:visited {
                color: inherit;
            }
            .ffe-icon-card--no-margin {
                margin: 0;
            }
            @media (min-width: 768px) {
                .ffe-icon-card {
                    gap: var(--ffe-spacing-md);
                }
                .ffe-icon-card--condensed {
                    gap: var(--ffe-spacing-sm);
                }
            }
            .ffe-icon-card .ffe-icon-card__body {
                flex-grow: 1;
            }
            .ffe-icon-card .ffe-icon-card__icon {
                color: var(--ffe-color-foreground-emphasis);
                flex-grow: 0;
                flex-shrink: 0;
                align-items: center;
                display: flex;
            }
            .ffe-icon-card--condensed {
                padding: var(--ffe-spacing-sm);
            }
            .ffe-illustration-card {
                background: var(--ffe-color-surface-primary-default);
                margin: 0 0 var(--ffe-spacing-xs);
                border: 1px solid var(--ffe-color-border-primary-default);
                border-radius: var(--ffe-v-cards-common-card-border-radius);
                transition:
                    color var(--ffe-transition-duration) var(--ffe-ease),
                    border var(--ffe-transition-duration) var(--ffe-ease),
                    box-shadow var(--ffe-transition-duration) var(--ffe-ease),
                    background-color var(--ffe-transition-duration) var(--ffe-ease);
                gap: var(--ffe-spacing-md) 0;
                width: 100%;
                padding: var(--ffe-spacing-md);
                outline: none;
                grid-template-rows: auto 1fr;
                align-items: center;
                text-decoration: none;
                display: grid;
            }
            @media (min-width: 768px) {
                .ffe-illustration-card {
                    margin-bottom: var(--ffe-spacing-md);
                }
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-illustration-card--clickable:hover {
                    cursor: pointer;
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-hover);
                    background: var(--ffe-color-surface-primary-default-hover);
                    border-color: transparent;
                }
                .ffe-illustration-card--clickable:hover
                    :where(
                        .ffe-card-body__card-name,
                        .ffe-card-body__title,
                        .ffe-card-body__subtext,
                        .ffe-card-body__text
                    ):has(.ffe-card__action) {
                    text-decoration: underline;
                }
            }
            .ffe-illustration-card--clickable:focus,
            .ffe-illustration-card--clickable:active {
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
            }
            .ffe-illustration-card--clickable:focus-within {
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
            }
            .ffe-illustration-card--clickable:focus
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-illustration-card--clickable:active
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-illustration-card--clickable:focus-within
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            @media (pointer: fine) {
                .ffe-illustration-card--clickable:focus-within {
                    outline: var(--ffe-g-outline-width) solid var(--ffe-color-border-interactive-focus);
                    outline-offset: var(--ffe-g-outline-offset);
                }
            }
            .ffe-illustration-card--clickable button.ffe-card__action--raw {
                color: inherit;
                font: inherit;
                cursor: pointer;
                outline: inherit;
                text-align: left;
                background: 0 0;
                border: none;
                padding: 0;
            }
            .ffe-illustration-card--clickable a.ffe-card__action--raw {
                color: inherit;
                -webkit-text-decoration: inherit;
                text-decoration: inherit;
                outline: none;
            }
            .ffe-illustration-card--clickable .ffe-card__action--raw:visited {
                color: inherit;
            }
            .ffe-illustration-card--no-margin {
                margin: 0;
            }
            @media (min-width: 480px) {
                .ffe-illustration-card {
                    gap: 0 var(--ffe-spacing-md);
                    grid-template-columns: auto 1fr;
                }
            }
            .ffe-illustration-card--condensed {
                gap: var(--ffe-spacing-sm) 0;
                padding: var(--ffe-spacing-sm);
            }
            @media (min-width: 480px) {
                .ffe-illustration-card--condensed {
                    gap: 0 var(--ffe-spacing-sm);
                }
            }
            .ffe-illustration-card__illustration {
                text-align: center;
            }
            .ffe-illustration-card--right {
                grid-template-rows: 1fr auto;
                justify-content: space-between;
            }
            @media (min-width: 480px) {
                .ffe-illustration-card--right {
                    grid-template-columns: 1fr auto;
                }
            }
            .ffe-image-card {
                --ffe-v-cards-common-card-border-color: var(--ffe-color-border-primary-default);
                background: var(--ffe-color-surface-primary-default);
                margin: 0 0 var(--ffe-spacing-xs);
                border: 1px solid var(--ffe-color-border-primary-default);
                border-radius: var(--ffe-v-cards-common-card-border-radius);
                transition:
                    color var(--ffe-transition-duration) var(--ffe-ease),
                    border var(--ffe-transition-duration) var(--ffe-ease),
                    box-shadow var(--ffe-transition-duration) var(--ffe-ease),
                    background-color var(--ffe-transition-duration) var(--ffe-ease);
                border: var(--ffe-v-cards-common-card-border-color);
                outline: none;
                flex-flow: column;
                width: 100%;
                max-width: 290px;
                padding: 0;
                text-decoration: none;
                display: flex;
            }
            @media (min-width: 768px) {
                .ffe-image-card {
                    margin-bottom: var(--ffe-spacing-md);
                }
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-image-card--clickable:hover {
                    cursor: pointer;
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-hover);
                    background: var(--ffe-color-surface-primary-default-hover);
                    border-color: transparent;
                }
                .ffe-image-card--clickable:hover
                    :where(
                        .ffe-card-body__card-name,
                        .ffe-card-body__title,
                        .ffe-card-body__subtext,
                        .ffe-card-body__text
                    ):has(.ffe-card__action) {
                    text-decoration: underline;
                }
            }
            .ffe-image-card--clickable:focus,
            .ffe-image-card--clickable:active {
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
            }
            .ffe-image-card--clickable:focus-within {
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
            }
            .ffe-image-card--clickable:focus
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-image-card--clickable:active
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-image-card--clickable:focus-within
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            @media (pointer: fine) {
                .ffe-image-card--clickable:focus-within {
                    outline: var(--ffe-g-outline-width) solid var(--ffe-color-border-interactive-focus);
                    outline-offset: var(--ffe-g-outline-offset);
                }
            }
            .ffe-image-card--clickable button.ffe-card__action--raw {
                color: inherit;
                font: inherit;
                cursor: pointer;
                outline: inherit;
                text-align: left;
                background: 0 0;
                border: none;
                padding: 0;
            }
            .ffe-image-card--clickable a.ffe-card__action--raw {
                color: inherit;
                -webkit-text-decoration: inherit;
                text-decoration: inherit;
                outline: none;
            }
            .ffe-image-card--clickable .ffe-card__action--raw:visited {
                color: inherit;
            }
            .ffe-image-card--no-margin {
                margin: 0;
            }
            .ffe-image-card .ffe-image-card__image-overlay,
            .ffe-image-card .ffe-image-card__body {
                border-color: var(--ffe-v-cards-common-card-border-color);
            }
            .ffe-image-card:has(.ffe-card__action:active, .ffe-card__action:focus) {
                --ffe-v-cards-common-card-border-color: var(--ffe-color-border-primary-default-hover);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-image-card:has(.ffe-card__action):hover {
                    --ffe-v-cards-common-card-border-color: var(--ffe-color-border-primary-default-hover);
                }
            }
            .ffe-image-card__image-container {
                border-top-left-radius: var(--ffe-v-cards-common-card-border-radius);
                border-top-right-radius: var(--ffe-v-cards-common-card-border-radius);
                max-height: 160px;
                position: relative;
                overflow: hidden;
            }
            .ffe-image-card__image {
                max-width: 100%;
            }
            .ffe-image-card__image-overlay,
            .ffe-image-card__body {
                width: 100%;
                transition: border-color var(--ffe-transition-duration);
                border: 1px solid transparent;
                overflow: hidden;
            }
            .ffe-image-card__image-overlay {
                z-index: 10;
                border-top-left-radius: var(--ffe-v-cards-common-card-border-radius);
                border-top-right-radius: var(--ffe-v-cards-common-card-border-radius);
                border-bottom: 0;
                height: 100%;
                position: absolute;
            }
            .ffe-image-card__body {
                text-align: center;
                padding: var(--ffe-spacing-sm) var(--ffe-spacing-sm) var(--ffe-spacing-xs) var(--ffe-spacing-sm);
                border-bottom-left-radius: var(--ffe-v-cards-common-card-border-radius);
                border-bottom-right-radius: var(--ffe-v-cards-common-card-border-radius);
                border-top: 0;
                min-height: 200px;
            }
            @media (min-width: 768px) {
                .ffe-image-card .ffe-image-card__icon {
                    margin: 0 var(--ffe-spacing-md) 0;
                }
            }
            @media (min-width: 1024px) {
                .ffe-image-card .ffe-image-card__icon {
                    margin: 0 var(--ffe-spacing-lg) 0 var(--ffe-spacing-xs);
                }
            }
            .ffe-stippled-card {
                --ffe-v-cards-stippled-border-color: var(--ffe-color-foreground-emphasis);
                background: var(--ffe-color-surface-primary-default);
                margin: 0 0 var(--ffe-spacing-xs);
                border: 1px solid var(--ffe-color-border-primary-default);
                border-radius: var(--ffe-v-cards-common-card-border-radius);
                transition:
                    color var(--ffe-transition-duration) var(--ffe-ease),
                    border var(--ffe-transition-duration) var(--ffe-ease),
                    box-shadow var(--ffe-transition-duration) var(--ffe-ease),
                    background-color var(--ffe-transition-duration) var(--ffe-ease);
                border: 2px dashed var(--ffe-v-cards-stippled-border-color);
                width: 100%;
                padding: var(--ffe-spacing-md);
                align-items: center;
                gap: var(--ffe-spacing-md);
                background: 0 0;
                outline: none;
                text-decoration: none;
                display: flex;
            }
            @media (min-width: 768px) {
                .ffe-stippled-card {
                    margin-bottom: var(--ffe-spacing-md);
                }
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-stippled-card--clickable:hover {
                    cursor: pointer;
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-hover);
                    background: var(--ffe-color-surface-primary-default-hover);
                    border-color: transparent;
                }
                .ffe-stippled-card--clickable:hover
                    :where(
                        .ffe-card-body__card-name,
                        .ffe-card-body__title,
                        .ffe-card-body__subtext,
                        .ffe-card-body__text
                    ):has(.ffe-card__action) {
                    text-decoration: underline;
                }
            }
            .ffe-stippled-card--clickable:focus,
            .ffe-stippled-card--clickable:active {
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
            }
            .ffe-stippled-card--clickable:focus-within {
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
            }
            .ffe-stippled-card--clickable:focus
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-stippled-card--clickable:active
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-stippled-card--clickable:focus-within
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            @media (pointer: fine) {
                .ffe-stippled-card--clickable:focus-within {
                    outline: var(--ffe-g-outline-width) solid var(--ffe-color-border-interactive-focus);
                    outline-offset: var(--ffe-g-outline-offset);
                }
            }
            .ffe-stippled-card--clickable button.ffe-card__action--raw {
                color: inherit;
                font: inherit;
                cursor: pointer;
                outline: inherit;
                text-align: left;
                background: 0 0;
                border: none;
                padding: 0;
            }
            .ffe-stippled-card--clickable a.ffe-card__action--raw {
                color: inherit;
                -webkit-text-decoration: inherit;
                text-decoration: inherit;
                outline: none;
            }
            .ffe-stippled-card--clickable .ffe-card__action--raw:visited {
                color: inherit;
            }
            .ffe-stippled-card--clickable:focus-within {
                border-style: solid;
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-stippled-card--clickable:hover {
                    border-style: solid;
                }
            }
            .ffe-stippled-card--no-margin {
                margin: 0;
            }
            .ffe-stippled-card__content {
                flex-grow: 1;
            }
            .ffe-stippled-card__img {
                flex-grow: 0;
                flex-shrink: 0;
            }
            .ffe-stippled-card__img--icon {
                margin: 0 var(--ffe-spacing-md);
                display: flex;
            }
            .ffe-stippled-card--condensed {
                padding: var(--ffe-spacing-sm);
                gap: var(--ffe-spacing-sm);
            }
            .ffe-stippled-card--condensed .ffe-stippled-card__img--icon {
                margin: 0;
            }
            .ffe-stippled-card .ffe-icons {
                color: var(--ffe-color-foreground-emphasis);
            }
            .ffe-group-card {
                background: var(--ffe-color-surface-primary-default);
                margin: 0 0 var(--ffe-spacing-xs);
                border-radius: var(--ffe-v-cards-common-card-border-radius);
                transition:
                    color var(--ffe-transition-duration) var(--ffe-ease),
                    border var(--ffe-transition-duration) var(--ffe-ease),
                    box-shadow var(--ffe-transition-duration) var(--ffe-ease),
                    background-color var(--ffe-transition-duration) var(--ffe-ease);
                --ffe-v-cards-common-group-card-border: var(--ffe-v-cards-common-card-border-radius)
                    var(--ffe-color-border-primary-default);
                width: 100%;
                color: var(--ffe-color-foreground-default);
                border: 1px solid var(--ffe-color-border-primary-default);
                outline: none;
                text-decoration: none;
            }
            @media (min-width: 768px) {
                .ffe-group-card {
                    margin-bottom: var(--ffe-spacing-md);
                }
            }
            .ffe-group-card--bg-primary {
                background: var(--ffe-color-surface-primary-default);
            }
            .ffe-group-card--bg-secondary {
                background: var(--ffe-color-surface-secondary-default);
            }
            .ffe-group-card--bg-tertiary {
                background: var(--ffe-color-surface-tertiary-default);
            }
            .ffe-group-card--no-margin {
                margin: 0;
            }
            .ffe-group-card:-webkit-any(ul) {
                -webkit-padding-start: 0;
                list-style: none;
            }
            .ffe-group-card:-moz-any(ul) {
                -webkit-padding-start: 0;
                list-style: none;
            }
            .ffe-group-card:is(ul) {
                -webkit-padding-start: 0;
                list-style: none;
            }
            .ffe-group-card:-webkit-any(ul):not(
                    :-webkit-any(
                            :lang(ae),
                            :lang(ar),
                            :lang(arc),
                            :lang(bcc),
                            :lang(bqi),
                            :lang(ckb),
                            :lang(dv),
                            :lang(fa),
                            :lang(glk),
                            :lang(he),
                            :lang(ku),
                            :lang(mzn),
                            :lang(nqo),
                            :lang(pnb),
                            :lang(ps),
                            :lang(sd),
                            :lang(ug),
                            :lang(ur),
                            :lang(yi)
                        )
                ) {
                padding-left: 0;
            }
            .ffe-group-card:-moz-any(ul):not(
                    :-moz-any(
                            :lang(ae),
                            :lang(ar),
                            :lang(arc),
                            :lang(bcc),
                            :lang(bqi),
                            :lang(ckb),
                            :lang(dv),
                            :lang(fa),
                            :lang(glk),
                            :lang(he),
                            :lang(ku),
                            :lang(mzn),
                            :lang(nqo),
                            :lang(pnb),
                            :lang(ps),
                            :lang(sd),
                            :lang(ug),
                            :lang(ur),
                            :lang(yi)
                        )
                ) {
                padding-left: 0;
            }
            .ffe-group-card:is(ul):not(
                    :is(
                            :lang(ae),
                            :lang(ar),
                            :lang(arc),
                            :lang(bcc),
                            :lang(bqi),
                            :lang(ckb),
                            :lang(dv),
                            :lang(fa),
                            :lang(glk),
                            :lang(he),
                            :lang(ku),
                            :lang(mzn),
                            :lang(nqo),
                            :lang(pnb),
                            :lang(ps),
                            :lang(sd),
                            :lang(ug),
                            :lang(ur),
                            :lang(yi)
                        )
                ) {
                padding-left: 0;
            }
            .ffe-group-card:-webkit-any(ul):-webkit-any(
                    :lang(ae),
                    :lang(ar),
                    :lang(arc),
                    :lang(bcc),
                    :lang(bqi),
                    :lang(ckb),
                    :lang(dv),
                    :lang(fa),
                    :lang(glk),
                    :lang(he),
                    :lang(ku),
                    :lang(mzn),
                    :lang(nqo),
                    :lang(pnb),
                    :lang(ps),
                    :lang(sd),
                    :lang(ug),
                    :lang(ur),
                    :lang(yi)
                ) {
                padding-right: 0;
            }
            .ffe-group-card:-moz-any(ul):-moz-any(
                    :lang(ae),
                    :lang(ar),
                    :lang(arc),
                    :lang(bcc),
                    :lang(bqi),
                    :lang(ckb),
                    :lang(dv),
                    :lang(fa),
                    :lang(glk),
                    :lang(he),
                    :lang(ku),
                    :lang(mzn),
                    :lang(nqo),
                    :lang(pnb),
                    :lang(ps),
                    :lang(sd),
                    :lang(ug),
                    :lang(ur),
                    :lang(yi)
                ) {
                padding-right: 0;
            }
            .ffe-group-card:is(ul):is(
                    :lang(ae),
                    :lang(ar),
                    :lang(arc),
                    :lang(bcc),
                    :lang(bqi),
                    :lang(ckb),
                    :lang(dv),
                    :lang(fa),
                    :lang(glk),
                    :lang(he),
                    :lang(ku),
                    :lang(mzn),
                    :lang(nqo),
                    :lang(pnb),
                    :lang(ps),
                    :lang(sd),
                    :lang(ug),
                    :lang(ur),
                    :lang(yi)
                ) {
                padding-right: 0;
            }
            .ffe-group-card > :first-child {
                border-radius: var(--ffe-v-cards-common-card-border-radius) var(--ffe-v-cards-common-card-border-radius)
                    0 0;
            }
            .ffe-group-card > :last-child {
                border-radius: 0 0 var(--ffe-v-cards-common-card-border-radius)
                    var(--ffe-v-cards-common-card-border-radius);
                border-bottom-color: transparent;
            }
            .ffe-group-card > :first-child:last-child {
                border-radius: var(--ffe-v-cards-common-card-border-radius);
            }
            .ffe-group-card__title :where(.ffe-h1, .ffe-h2, .ffe-h3, .ffe-h4, .ffe-h5, .ffe-h6) {
                margin-bottom: 0;
            }
            .ffe-group-card__element {
                padding: var(--ffe-spacing-md);
            }
            .ffe-group-card__footer {
                justify-content: center;
                align-items: center;
                display: flex;
            }
            .ffe-group-card__title,
            .ffe-group-card__footer {
                padding: var(--ffe-spacing-sm) var(--ffe-spacing-md);
            }
            .ffe-group-card__title,
            .ffe-group-card__element,
            .ffe-group-card__footer {
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                border: 1px solid transparent;
                margin: 0;
            }
            .ffe-group-card__title--no-padding,
            .ffe-group-card__element--no-padding,
            .ffe-group-card__footer--no-padding {
                padding: 0;
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-group-card__title--clickable:hover,
                .ffe-group-card__element--clickable:hover,
                .ffe-group-card__footer--clickable:hover {
                    cursor: pointer;
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-hover);
                    background: var(--ffe-color-surface-primary-default-hover);
                    border-color: transparent;
                }
                .ffe-group-card__title--clickable:hover
                    :where(
                        .ffe-card-body__card-name,
                        .ffe-card-body__title,
                        .ffe-card-body__subtext,
                        .ffe-card-body__text
                    ):has(.ffe-card__action) {
                    text-decoration: underline;
                }
                .ffe-group-card__element--clickable:hover
                    :where(
                        .ffe-card-body__card-name,
                        .ffe-card-body__title,
                        .ffe-card-body__subtext,
                        .ffe-card-body__text
                    ):has(.ffe-card__action) {
                    text-decoration: underline;
                }
                .ffe-group-card__footer--clickable:hover
                    :where(
                        .ffe-card-body__card-name,
                        .ffe-card-body__title,
                        .ffe-card-body__subtext,
                        .ffe-card-body__text
                    ):has(.ffe-card__action) {
                    text-decoration: underline;
                }
            }
            .ffe-group-card__title--clickable:focus,
            .ffe-group-card__element--clickable:focus,
            .ffe-group-card__footer--clickable:focus,
            .ffe-group-card__title--clickable:active,
            .ffe-group-card__element--clickable:active,
            .ffe-group-card__footer--clickable:active {
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
            }
            .ffe-group-card__title--clickable:focus-within {
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
            }
            .ffe-group-card__element--clickable:focus-within {
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
            }
            .ffe-group-card__footer--clickable:focus-within {
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
            }
            .ffe-group-card__title--clickable:focus
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-group-card__element--clickable:focus
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-group-card__footer--clickable:focus
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-group-card__title--clickable:active
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-group-card__element--clickable:active
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-group-card__footer--clickable:active
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-group-card__title--clickable:focus-within
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-group-card__element--clickable:focus-within
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            .ffe-group-card__footer--clickable:focus-within
                :where(
                    .ffe-card-body__card-name,
                    .ffe-card-body__title,
                    .ffe-card-body__subtext,
                    .ffe-card-body__text
                ):has(.ffe-card__action) {
                text-decoration: underline;
            }
            @media (pointer: fine) {
                .ffe-group-card__title--clickable:focus-within {
                    outline: var(--ffe-g-outline-width) solid var(--ffe-color-border-interactive-focus);
                    outline-offset: var(--ffe-g-outline-offset);
                }
                .ffe-group-card__element--clickable:focus-within {
                    outline: var(--ffe-g-outline-width) solid var(--ffe-color-border-interactive-focus);
                    outline-offset: var(--ffe-g-outline-offset);
                }
                .ffe-group-card__footer--clickable:focus-within {
                    outline: var(--ffe-g-outline-width) solid var(--ffe-color-border-interactive-focus);
                    outline-offset: var(--ffe-g-outline-offset);
                }
            }
            .ffe-group-card__title--clickable button.ffe-card__action--raw,
            .ffe-group-card__element--clickable button.ffe-card__action--raw,
            .ffe-group-card__footer--clickable button.ffe-card__action--raw {
                color: inherit;
                font: inherit;
                cursor: pointer;
                outline: inherit;
                text-align: left;
                background: 0 0;
                border: none;
                padding: 0;
            }
            .ffe-group-card__title--clickable a.ffe-card__action--raw,
            .ffe-group-card__element--clickable a.ffe-card__action--raw,
            .ffe-group-card__footer--clickable a.ffe-card__action--raw {
                color: inherit;
                -webkit-text-decoration: inherit;
                text-decoration: inherit;
                outline: none;
            }
            .ffe-group-card__title--clickable .ffe-card__action--raw:visited,
            .ffe-group-card__element--clickable .ffe-card__action--raw:visited,
            .ffe-group-card__footer--clickable .ffe-card__action--raw:visited {
                color: inherit;
            }
            .ffe-group-card__title,
            .ffe-group-card__element {
                border-bottom-color: var(--ffe-color-border-primary-default);
            }
            .ffe-group-card__title--no-separator,
            .ffe-group-card__element--no-separator {
                border-bottom-color: transparent;
            }
            :root {
                --ffe-v-cards-common-card-border-radius: 16px;
            }
            :host {
                --ffe-v-cards-common-card-border-radius: 16px;
            }
            :root {
                --ffe-v-context-message-close-button-color: var(--ffe-farge-moerkgraa);
                --ffe-v-context-message-close-button-color-hover: var(--ffe-farge-svart);
                --ffe-v-context-message-close-button-border-color-focus: var(--ffe-farge-vann);
                --ffe-v-context-message-variant-bg-color: var(--ffe-farge-hvit);
                --ffe-v-context-message-icon-bg-color: var(--ffe-farge-hvit);
                --ffe-v-context-message-info-bg-color: var(--ffe-farge-frost-30);
                --ffe-v-context-message-info-icon-color: var(--ffe-farge-vann);
                --ffe-v-context-message-info-icon-compact-color: var(--ffe-farge-vann);
                --ffe-v-context-message-tips-bg-color: var(--ffe-farge-sand);
                --ffe-v-context-message-tips-icon-color: var(--ffe-farge-sol);
                --ffe-v-context-message-success-bg-color: var(--ffe-farge-nordlys-30);
                --ffe-v-context-message-success-compact-color: var(--ffe-farge-skog);
                --ffe-v-context-message-success-icon-color: var(--ffe-farge-skog);
                --ffe-v-context-message-error-bg-color: var(--ffe-farge-baer-30);
                --ffe-v-context-message-error-icon-color: var(--ffe-farge-baer);
                --ffe-v-context-message-link-color: var(--ffe-farge-vann);
                --ffe-v-context-message-link-color-hover: var(--ffe-farge-fjell);
                --ffe-v-context-message-link-color-visited: var(--ffe-farge-lyng);
                --ffe-v-context-message-link-color-focus: var(--ffe-farge-hvit);
            }
            :host {
                --ffe-v-context-message-close-button-color: var(--ffe-farge-moerkgraa);
                --ffe-v-context-message-close-button-color-hover: var(--ffe-farge-svart);
                --ffe-v-context-message-close-button-border-color-focus: var(--ffe-farge-vann);
                --ffe-v-context-message-variant-bg-color: var(--ffe-farge-hvit);
                --ffe-v-context-message-icon-bg-color: var(--ffe-farge-hvit);
                --ffe-v-context-message-info-bg-color: var(--ffe-farge-frost-30);
                --ffe-v-context-message-info-icon-color: var(--ffe-farge-vann);
                --ffe-v-context-message-info-icon-compact-color: var(--ffe-farge-vann);
                --ffe-v-context-message-tips-bg-color: var(--ffe-farge-sand);
                --ffe-v-context-message-tips-icon-color: var(--ffe-farge-sol);
                --ffe-v-context-message-success-bg-color: var(--ffe-farge-nordlys-30);
                --ffe-v-context-message-success-compact-color: var(--ffe-farge-skog);
                --ffe-v-context-message-success-icon-color: var(--ffe-farge-skog);
                --ffe-v-context-message-error-bg-color: var(--ffe-farge-baer-30);
                --ffe-v-context-message-error-icon-color: var(--ffe-farge-baer);
                --ffe-v-context-message-link-color: var(--ffe-farge-vann);
                --ffe-v-context-message-link-color-hover: var(--ffe-farge-fjell);
                --ffe-v-context-message-link-color-visited: var(--ffe-farge-lyng);
                --ffe-v-context-message-link-color-focus: var(--ffe-farge-hvit);
            }
            @media (prefers-color-scheme: dark) {
                :root .regard-color-scheme-preference {
                    --ffe-v-context-message-icon-bg-color: var(--ffe-farge-svart);
                    --ffe-v-context-message-info-bg-color: var(--ffe-farge-vann-30);
                    --ffe-v-context-message-info-color: var(--ffe-farge-vann-70);
                    --ffe-v-context-message-success-icon-color: var(--ffe-farge-skog-70);
                }
                :host .regard-color-scheme-preference {
                    --ffe-v-context-message-icon-bg-color: var(--ffe-farge-svart);
                    --ffe-v-context-message-info-bg-color: var(--ffe-farge-vann-30);
                    --ffe-v-context-message-info-color: var(--ffe-farge-vann-70);
                    --ffe-v-context-message-success-icon-color: var(--ffe-farge-skog-70);
                }
            }
            .ffe-context-message-content {
                text-align: left;
                flex-flow: row;
                align-items: center;
                padding: 16px;
                display: flex;
            }
            .ffe-context-message-content .ffe-body-paragraph,
            .ffe-context-message-content .ffe-body-text,
            .ffe-context-message-content .ffe-small-text,
            .ffe-context-message-content .ffe-link-text,
            .ffe-context-message-content__header {
                overflow-wrap: anywhere;
            }
            @media (prefers-color-scheme: dark) {
                .regard-color-scheme-preference .ffe-context-message-content .ffe-body-paragraph,
                .regard-color-scheme-preference .ffe-context-message-content .ffe-body-text,
                .regard-color-scheme-preference .ffe-context-message-content .ffe-small-text {
                    color: var(--ffe-farge-svart);
                }
            }
            .ffe-context-message-content .ffe-link-text {
                border-bottom: 1px solid var(--ffe-v-context-message-link-color);
                color: var(--ffe-v-context-message-link-color);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-context-message-content .ffe-link-text:hover {
                    border-bottom-color: var(--ffe-v-context-message-link-color-hover);
                    color: var(--ffe-v-context-message-link-color-hover);
                }
            }
            .ffe-context-message-content .ffe-link-text:visited {
                border-bottom-color: var(--ffe-v-context-message-link-color-visited);
                color: var(--ffe-v-context-message-link-color-visited);
            }
            .ffe-context-message-content .ffe-link-text:focus {
                background-color: var(--ffe-v-context-message-link-color);
                box-shadow: 0 0 0 2px var(--ffe-v-context-message-link-color);
                border-color: var(--ffe-v-context-message-link-color-focus) !important;
                color: var(--ffe-v-context-message-link-color-focus) !important;
            }
            .ffe-context-message-content__header {
                color: var(--ffe-farge-svart);
                font-size: var(--ffe-fontsize-h6);
                margin-top: 0;
                margin-bottom: 4px;
            }
            .ffe-context-message-content__icon {
                border: 2px solid;
                border-radius: 50%;
                flex-shrink: 0;
                justify-content: center;
                align-self: start;
                align-items: center;
                width: 2em;
                height: 2em;
                margin-right: 16px;
                display: flex;
            }
            @media (min-width: 480px) {
                .ffe-context-message-content__icon {
                    width: 4em;
                    height: 4em;
                    margin-bottom: 0;
                }
            }
            @media (min-width: 480px) and (prefers-color-scheme: dark) {
                .regard-color-scheme-preference .ffe-context-message-content__icon {
                    background-color: var(--ffe-farge-svart);
                }
            }
            .ffe-context-message-content__icon-span {
                color: var(--ffe-farge-svart);
                font-size: 1.25rem;
            }
            @media (min-width: 480px) {
                .ffe-context-message-content__icon-span {
                    font-size: 2.5rem;
                }
            }
            @media (prefers-color-scheme: dark) {
                .regard-color-scheme-preference .ffe-context-message-content__icon-span {
                    color: var(--ffe-farge-hvit);
                }
            }
            .ffe-context-message-content__close-button {
                cursor: pointer;
                box-sizing: border-box;
                background-color: transparent;
                border: 2px solid transparent;
                outline: none;
                flex: none;
                align-self: start;
                width: 3rem;
                height: 3rem;
                padding-top: 8px;
            }
            .ffe-context-message-content__close-button:focus {
                border: 2px solid var(--ffe-v-context-message-close-button-border-color-focus);
                border-radius: 5px;
            }
            .ffe-context-message-content__close-button .ffe-icons {
                color: var(--ffe-v-context-message-close-button-color);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-context-message-content__close-button .ffe-icons:hover {
                    color: var(--ffe-v-context-message-close-button-color-hover);
                }
            }
            @media (min-width: 480px) {
                .ffe-context-message-content {
                    flex-direction: row;
                }
            }
            .ffe-context-message {
                border-radius: 8px;
                justify-content: space-between;
                width: 100%;
                transition: height 0.2s cubic-bezier(0.46, -0.265, 0.48, 1.38);
                display: flex;
                position: relative;
                overflow: hidden;
            }
            .ffe-context-message--compact .ffe-context-message-content {
                flex-direction: row;
                padding: 8px 16px;
            }
            .ffe-context-message--compact .ffe-context-message-content__icon {
                border: none;
                border-radius: 50%;
                align-self: flex-start;
                width: 2em;
                height: 2em;
                margin-bottom: 0;
                margin-right: 16px;
            }
            .ffe-context-message--compact .ffe-context-message-content__icon-span {
                font-size: 1.25rem;
            }
            .ffe-context-message--compact .ffe-icons.ffe-context-message-content__icon-span--small {
                display: block;
            }
            .ffe-context-message--compact .ffe-icons.ffe-context-message-content__icon-span--large {
                display: none;
            }
            .ffe-context-message--info {
                background-color: var(--ffe-v-context-message-info-bg-color);
            }
            .ffe-context-message--info .ffe-context-message-content__icon {
                background-color: var(--ffe-v-context-message-info-icon-compact-color);
                border-color: var(--ffe-v-context-message-info-icon-compact-color);
            }
            .ffe-context-message--info .ffe-context-message-content__icon-span {
                color: var(--ffe-farge-hvit);
            }
            @media (min-width: 480px) {
                .ffe-context-message--info .ffe-context-message-content__icon {
                    background-color: var(--ffe-v-context-message-icon-bg-color);
                    border-color: var(--ffe-v-context-message-info-icon-color);
                }
                .ffe-context-message--info .ffe-context-message-content__icon-span {
                    color: var(--ffe-v-context-message-info-icon-color);
                }
            }
            .ffe-context-message--info.ffe-context-message--coloredbg {
                background-color: var(--ffe-v-context-message-variant-bg-color);
            }
            @media (prefers-color-scheme: dark) {
                .regard-color-scheme-preference .ffe-context-message--info.ffe-context-message--coloredbg {
                    background-color: var(--ffe-v-context-message-info-bg-color);
                }
            }
            .ffe-context-message--info.ffe-context-message--compact .ffe-context-message-content__icon {
                background-color: var(--ffe-v-context-message-info-icon-compact-color);
            }
            .ffe-context-message--info.ffe-context-message--compact .ffe-context-message-content__icon-span {
                color: var(--ffe-farge-hvit);
            }
            .ffe-context-message--tips {
                background-color: var(--ffe-v-context-message-tips-bg-color);
            }
            .ffe-context-message--tips .ffe-context-message-content__icon {
                background-color: var(--ffe-v-context-message-tips-icon-color);
                border-color: var(--ffe-v-context-message-tips-icon-color);
            }
            .ffe-context-message--tips .ffe-context-message-content__icon-span {
                color: var(--ffe-farge-hvit);
            }
            @media (min-width: 480px) {
                .ffe-context-message--tips .ffe-context-message-content__icon {
                    background-color: var(--ffe-v-context-message-icon-bg-color);
                    border-color: var(--ffe-v-context-message-tips-icon-color);
                }
                .ffe-context-message--tips .ffe-context-message-content__icon-span {
                    color: var(--ffe-v-context-message-tips-icon-color);
                }
            }
            .ffe-context-message--tips.ffe-context-message--coloredbg {
                background-color: var(--ffe-v-context-message-variant-bg-color);
            }
            @media (prefers-color-scheme: dark) {
                .regard-color-scheme-preference .ffe-context-message--tips.ffe-context-message--coloredbg {
                    background-color: var(--ffe-v-context-message-tips-bg-color);
                }
            }
            .ffe-context-message--tips.ffe-context-message--compact .ffe-context-message-content__icon {
                background-color: var(--ffe-v-context-message-tips-icon-color);
            }
            .ffe-context-message--tips.ffe-context-message--compact .ffe-context-message-content__icon-span {
                color: var(--ffe-farge-hvit);
            }
            .ffe-context-message--success {
                background-color: var(--ffe-v-context-message-success-bg-color);
            }
            .ffe-context-message--success .ffe-context-message-content__icon {
                background-color: var(--ffe-v-context-message-success-compact-color);
                border-color: var(--ffe-v-context-message-success-compact-color);
            }
            .ffe-context-message--success .ffe-context-message-content__icon-span {
                color: var(--ffe-farge-hvit);
            }
            @media (min-width: 480px) {
                .ffe-context-message--success .ffe-context-message-content__icon {
                    background-color: var(--ffe-v-context-message-icon-bg-color);
                    border-color: var(--ffe-v-context-message-success-icon-color);
                }
                .ffe-context-message--success .ffe-context-message-content__icon-span {
                    color: var(--ffe-v-context-message-success-icon-color);
                }
            }
            .ffe-context-message--success.ffe-context-message--coloredbg {
                background-color: var(--ffe-v-context-message-variant-bg-color);
            }
            @media (prefers-color-scheme: dark) {
                .regard-color-scheme-preference .ffe-context-message--success.ffe-context-message--coloredbg {
                    background-color: var(--ffe-v-context-message-success-bg-color);
                }
            }
            .ffe-context-message--success.ffe-context-message--compact .ffe-context-message-content__icon {
                background-color: var(--ffe-v-context-message-success-compact-color);
            }
            .ffe-context-message--success.ffe-context-message--compact .ffe-context-message-content__icon-span {
                color: var(--ffe-farge-hvit);
            }
            .ffe-context-message--error {
                background-color: var(--ffe-v-context-message-error-bg-color);
            }
            .ffe-context-message--error .ffe-context-message-content__icon {
                background-color: var(--ffe-v-context-message-error-icon-color);
                border-color: var(--ffe-v-context-message-error-icon-color);
            }
            .ffe-context-message--error .ffe-context-message-content__icon-span {
                color: var(--ffe-farge-hvit);
            }
            @media (min-width: 480px) {
                .ffe-context-message--error .ffe-context-message-content__icon {
                    background-color: var(--ffe-v-context-message-icon-bg-color);
                    border-color: var(--ffe-v-context-message-error-icon-color);
                }
                .ffe-context-message--error .ffe-context-message-content__icon-span {
                    color: var(--ffe-v-context-message-error-icon-color);
                }
            }
            .ffe-context-message--error.ffe-context-message--coloredbg {
                background-color: var(--ffe-v-context-message-variant-bg-color);
            }
            @media (prefers-color-scheme: dark) {
                .regard-color-scheme-preference .ffe-context-message--error.ffe-context-message--coloredbg {
                    background-color: var(--ffe-v-context-message-error-bg-color);
                }
            }
            .ffe-context-message--error.ffe-context-message--compact .ffe-context-message-content__icon {
                background-color: var(--ffe-v-context-message-error-icon-color);
            }
            .ffe-context-message--error.ffe-context-message--compact .ffe-context-message-content__icon-span {
                color: var(--ffe-farge-hvit);
            }
            .ffe-icons.ffe-context-message-content__icon-span--small {
                display: block;
            }
            @media (min-width: 480px) {
                .ffe-icons.ffe-context-message-content__icon-span--small {
                    display: none;
                }
            }
            .ffe-icons.ffe-context-message-content__icon-span--large {
                display: none;
            }
            @media (min-width: 480px) {
                .ffe-icons.ffe-context-message-content__icon-span--large {
                    display: block;
                }
            }
            html {
                -webkit-text-size-adjust: 100%;
                -moz-text-size-adjust: 100%;
                -ms-text-size-adjust: 100%;
                text-size-adjust: 100%;
                line-height: 1.15;
            }
            :host {
                -webkit-text-size-adjust: 100%;
                -moz-text-size-adjust: 100%;
                -ms-text-size-adjust: 100%;
                text-size-adjust: 100%;
                line-height: 1.15;
            }
            body {
                margin: 0;
            }
            main {
                display: block;
            }
            h1 {
                margin: 0.67em 0;
                font-size: 2em;
            }
            hr {
                box-sizing: content-box;
                height: 0;
                overflow: visible;
            }
            pre {
                font-family: monospace;
                font-size: 1em;
            }
            a {
                background-color: transparent;
            }
            abbr[title] {
                text-decoration: underline;
                border-bottom: none;
                -webkit-text-decoration: underline dotted;
                text-decoration: underline dotted;
            }
            b,
            strong {
                font-weight: bolder;
            }
            code,
            kbd,
            samp {
                font-family: monospace;
                font-size: 1em;
            }
            small {
                font-size: 80%;
            }
            sub,
            sup {
                vertical-align: baseline;
                font-size: 75%;
                line-height: 0;
                position: relative;
            }
            sub {
                bottom: -0.25em;
            }
            sup {
                top: -0.5em;
            }
            img {
                border-style: none;
            }
            button,
            input,
            optgroup,
            select,
            textarea {
                margin: 0;
                font-family: inherit;
                font-size: 100%;
                line-height: 1.15;
            }
            button,
            input {
                overflow: visible;
            }
            button,
            select {
                text-transform: none;
            }
            button {
                -webkit-appearance: button;
                -moz-appearance: button;
                -ms-appearance: button;
                appearance: button;
            }
            [type="button"] {
                -webkit-appearance: button;
                -moz-appearance: button;
                -ms-appearance: button;
                appearance: button;
            }
            [type="reset"] {
                -webkit-appearance: button;
                -moz-appearance: button;
                -ms-appearance: button;
                appearance: button;
            }
            [type="submit"] {
                -webkit-appearance: button;
                -moz-appearance: button;
                -ms-appearance: button;
                appearance: button;
            }
            button::-moz-focus-inner {
                border-style: none;
                padding: 0;
            }
            [type="button"]::-moz-focus-inner {
                border-style: none;
                padding: 0;
            }
            [type="reset"]::-moz-focus-inner {
                border-style: none;
                padding: 0;
            }
            [type="submit"]::-moz-focus-inner {
                border-style: none;
                padding: 0;
            }
            button:-moz-focusring {
                outline: 1px dotted buttontext;
            }
            [type="button"]:-moz-focusring {
                outline: 1px dotted buttontext;
            }
            [type="reset"]:-moz-focusring {
                outline: 1px dotted buttontext;
            }
            [type="submit"]:-moz-focusring {
                outline: 1px dotted buttontext;
            }
            fieldset {
                padding: 0.35em 0.75em 0.625em;
            }
            legend {
                box-sizing: border-box;
                color: inherit;
                white-space: normal;
                max-width: 100%;
                padding: 0;
                display: table;
            }
            progress {
                vertical-align: baseline;
            }
            textarea {
                overflow: auto;
            }
            [type="checkbox"] {
                box-sizing: border-box;
                padding: 0;
            }
            [type="radio"] {
                box-sizing: border-box;
                padding: 0;
            }
            [type="number"]::-webkit-inner-spin-button {
                height: auto;
            }
            [type="number"]::-webkit-outer-spin-button {
                height: auto;
            }
            [type="search"] {
                -webkit-appearance: textfield;
                -moz-appearance: textfield;
                -ms-appearance: textfield;
                appearance: textfield;
                outline-offset: -2px;
            }
            [type="search"]::-webkit-search-decoration {
                -webkit-appearance: none;
                -moz-appearance: none;
                -ms-appearance: none;
                appearance: none;
            }
            ::-webkit-file-upload-button {
                -webkit-appearance: button;
                -moz-appearance: button;
                -ms-appearance: button;
                appearance: button;
                font: inherit;
            }
            details {
                display: block;
            }
            summary {
                display: list-item;
            }
            template,
            [hidden] {
                display: none;
            }
            html {
                box-sizing: border-box;
                font-size: 100%;
            }
            :host {
                box-sizing: border-box;
                font-size: 100%;
            }
            *,
            :before,
            :after {
                box-sizing: inherit;
            }
            @supports (font: -apple-system-body) {
                :root:has(.native) {
                    font: -apple-system-body;
                }
                :host:has(.native) {
                    font: -apple-system-body;
                }
            }
            @media (prefers-color-scheme: dark) {
                .regard-color-scheme-preference,
                .regard-color-scheme-preference .ffe-default-mode {
                    --ffe-color-background-default: #020a0a;
                    --ffe-color-background-subtle: #121212;
                    --ffe-color-surface-primary-default: #262626;
                    --ffe-color-surface-primary-default-hover: #333;
                    --ffe-color-surface-primary-default-pressed: #3d3d3d;
                    --ffe-color-surface-secondary-default: #0c2232;
                    --ffe-color-surface-secondary-default-hover: #102d43;
                    --ffe-color-surface-secondary-default-pressed: #163853;
                    --ffe-color-surface-tertiary-default: #1d192f;
                    --ffe-color-surface-tertiary-default-hover: #27223a;
                    --ffe-color-surface-tertiary-default-pressed: #312c44;
                    --ffe-color-surface-neutral-default: #333;
                    --ffe-color-surface-neutral-default-hover: #3d3d3d;
                    --ffe-color-surface-neutral-default-pressed: #474747;
                    --ffe-color-surface-feedback-info: #163853;
                    --ffe-color-surface-feedback-success: #0a4330;
                    --ffe-color-surface-feedback-warning: #491c00;
                    --ffe-color-surface-feedback-critical: #640e10;
                    --ffe-color-surface-feedback-tip: #312c44;
                    --ffe-color-fill-primary-default: #55709b;
                    --ffe-color-fill-primary-default-hover: #748db4;
                    --ffe-color-fill-primary-default-pressed: #90a9d0;
                    --ffe-color-fill-primary-selected-default: #f7fafd;
                    --ffe-color-fill-primary-selected-hover: #d7e7f4;
                    --ffe-color-fill-primary-selected-pressed: #c3d9ef;
                    --ffe-color-fill-primary-subtle: #374b6c;
                    --ffe-color-fill-primary-subtle-hover: #3e5579;
                    --ffe-color-fill-primary-subtle-pressed: #47618a;
                    --ffe-color-fill-primary-invisible: rgba(255, 255, 255, 0);
                    --ffe-color-fill-secondary-default: #457aa1;
                    --ffe-color-fill-secondary-default-hover: #6096bd;
                    --ffe-color-fill-secondary-default-pressed: #7eb5d2;
                    --ffe-color-fill-secondary-subtle: #2b5a7c;
                    --ffe-color-fill-secondary-subtle-hover: #356488;
                    --ffe-color-fill-secondary-subtle-pressed: #3b6f96;
                    --ffe-color-fill-tertiary-default: #7b718e;
                    --ffe-color-fill-tertiary-default-hover: #a39db9;
                    --ffe-color-fill-tertiary-default-pressed: #b4aecb;
                    --ffe-color-fill-tertiary-subtle: #4e4a64;
                    --ffe-color-fill-tertiary-subtle-hover: #5a5671;
                    --ffe-color-fill-tertiary-subtle-pressed: #665d79;
                    --ffe-color-fill-neutral-default: rgba(255, 255, 255, 0.2);
                    --ffe-color-fill-neutral-default-hover: rgba(255, 255, 255, 0.25);
                    --ffe-color-fill-neutral-default-pressed: rgba(255, 255, 255, 0.3);
                    --ffe-color-fill-neutral-subtle: rgba(255, 255, 255, 0.075);
                    --ffe-color-fill-neutral-subtle-hover: rgba(255, 255, 255, 0.1);
                    --ffe-color-fill-neutral-subtle-pressed: rgba(255, 255, 255, 0.15);
                    --ffe-color-fill-neutral-extra-subtle: rgba(255, 255, 255, 0.024);
                    --ffe-color-fill-neutral-extra-subtle-hover: rgba(255, 255, 255, 0.05);
                    --ffe-color-fill-neutral-extra-subtle-pressed: rgba(255, 255, 255, 0.075);
                    --ffe-color-fill-feedback-info: #7eb5d2;
                    --ffe-color-fill-feedback-info-subtle: #234f71;
                    --ffe-color-fill-feedback-success: #6abe97;
                    --ffe-color-fill-feedback-success-subtle: #09583b;
                    --ffe-color-fill-feedback-warning: #ea910b;
                    --ffe-color-fill-feedback-warning-subtle: #682c00;
                    --ffe-color-fill-feedback-critical: #ff5e5c;
                    --ffe-color-fill-feedback-critical-subtle: #7c1214;
                    --ffe-color-fill-feedback-tip: #c1c1dc;
                    --ffe-color-fill-feedback-tip-subtle: #45415a;
                    --ffe-color-foreground-default: #fff;
                    --ffe-color-foreground-subtle: #c2c2c2;
                    --ffe-color-foreground-emphasis: #d7e7f4;
                    --ffe-color-foreground-inverse: #020a0a;
                    --ffe-color-foreground-interactive-link: #c3d9ef;
                    --ffe-color-foreground-interactive-link-hover: #b6d1ec;
                    --ffe-color-foreground-interactive-link-pressed: #9ec2e5;
                    --ffe-color-foreground-interactive-link-active: #f7fafd;
                    --ffe-color-foreground-interactive-disabled: #8f8f8f;
                    --ffe-color-foreground-feedback-info: #c3dfea;
                    --ffe-color-foreground-feedback-success: #b2e6cd;
                    --ffe-color-foreground-feedback-warning: #ffc675;
                    --ffe-color-foreground-feedback-critical: #ffaea8;
                    --ffe-color-foreground-feedback-tip: #d3d3ea;
                    --ffe-color-component-form-input-foreground-default: #fff;
                    --ffe-color-component-form-input-foreground-subtle: #c2c2c2;
                    --ffe-color-component-form-input-foreground-placeholder: #adadad;
                    --ffe-color-component-form-input-foreground-disabled: #adadad;
                    --ffe-color-component-form-input-foreground-read-only: #c2c2c2;
                    --ffe-color-component-form-input-foreground-error: #ffaea8;
                    --ffe-color-component-form-input-border-active: #d7e7f4;
                    --ffe-color-component-form-input-fill-default: #262626;
                    --ffe-color-component-form-input-fill-default-hover: #333;
                    --ffe-color-component-form-input-fill-default-pressed: #3d3d3d;
                    --ffe-color-component-form-input-fill-disabled: #5c5c5c;
                    --ffe-color-component-form-input-fill-read-only: #262626;
                    --ffe-color-component-form-input-fill-error: #640e10;
                    --ffe-color-component-form-toggleswitch-handle-default: #fff;
                    --ffe-color-component-form-toggleswitch-handle-disabled: #a4a4a4;
                    --ffe-color-component-form-toggleswitch-fill-default: #7a7a7a;
                    --ffe-color-component-form-toggleswitch-fill-default-hover: #8f8f8f;
                    --ffe-color-component-form-toggleswitch-fill-default-pressed: #adadad;
                    --ffe-color-component-form-toggleswitch-fill-selected: #48a781;
                    --ffe-color-component-form-toggleswitch-fill-selected-hover: #6abe97;
                    --ffe-color-component-form-toggleswitch-fill-selected-pressed: #8fd1b1;
                    --ffe-color-component-form-toggleswitch-fill-selected-disabled: #00754e;
                    --ffe-color-component-form-toggleswitch-fill-selected-read-only: #0a4330;
                    --ffe-color-component-form-toggleswitch-fill-critical: #e44244;
                    --ffe-color-component-form-toggleswitch-fill-disabled: #5c5c5c;
                    --ffe-color-component-form-toggleswitch-fill-read-only: #262626;
                    --ffe-color-component-button-action-border-default: #00754e;
                    --ffe-color-component-button-action-border-hover: #2a7e5b;
                    --ffe-color-component-button-action-border-pressed: #409674;
                    --ffe-color-component-button-action-fill-default: #00754e;
                    --ffe-color-component-button-action-fill-hover: #2a7e5b;
                    --ffe-color-component-button-action-fill-pressed: #409674;
                    --ffe-color-component-button-action-foreground-default: #fff;
                    --ffe-color-component-button-action-foreground-hover: #fff;
                    --ffe-color-component-button-primary-border-default: #9ec2e5;
                    --ffe-color-component-button-primary-border-hover: #c3d9ef;
                    --ffe-color-component-button-primary-border-pressed: #d7e7f4;
                    --ffe-color-component-button-primary-fill-default: #005aa4;
                    --ffe-color-component-button-primary-fill-hover: #1566b2;
                    --ffe-color-component-button-primary-fill-pressed: #2975c2;
                    --ffe-color-component-button-primary-foreground-default: #fff;
                    --ffe-color-component-button-primary-foreground-hover: #fff;
                    --ffe-color-component-button-secondary-border-default: #f7fafd;
                    --ffe-color-component-button-secondary-border-hover: #f7fafd;
                    --ffe-color-component-button-secondary-border-pressed: #f7fafd;
                    --ffe-color-component-button-secondary-fill-default: rgba(255, 255, 255, 0);
                    --ffe-color-component-button-secondary-fill-hover: #333;
                    --ffe-color-component-button-secondary-fill-pressed: #3d3d3d;
                    --ffe-color-component-button-secondary-foreground-default: #fff;
                    --ffe-color-component-button-secondary-foreground-hover: #fff;
                    --ffe-color-component-button-tertiary-fill-default: rgba(255, 255, 255, 0);
                    --ffe-color-component-button-tertiary-fill-hover: #333;
                    --ffe-color-component-button-tertiary-fill-pressed: #3d3d3d;
                    --ffe-color-component-button-tertiary-foreground-default: #f7fafd;
                    --ffe-color-component-button-tertiary-foreground-hover: #f7fafd;
                    --ffe-color-component-logo-name: #fff;
                    --ffe-color-component-logo-number1: #fff;
                    --ffe-color-component-logo-circle-dark-red: #af0000;
                    --ffe-color-component-logo-circle-light-red: #e60000;
                    --ffe-color-border-primary-default: rgba(255, 255, 255, 0.2);
                    --ffe-color-border-primary-default-hover: rgba(255, 255, 255, 0.25);
                    --ffe-color-border-primary-default-pressed: rgba(255, 255, 255, 0.3);
                    --ffe-color-border-primary-subtle: rgba(255, 255, 255, 0.075);
                    --ffe-color-border-primary-subtle-hover: rgba(255, 255, 255, 0.1);
                    --ffe-color-border-primary-subtle-pressed: rgba(255, 255, 255, 0.15);
                    --ffe-color-border-primary-emphasis: #9ec2e5;
                    --ffe-color-border-feedback-info: #6096bd;
                    --ffe-color-border-feedback-success: #48a781;
                    --ffe-color-border-feedback-warning: #cc7205;
                    --ffe-color-border-feedback-critical: #e44244;
                    --ffe-color-border-feedback-tip: #a39db9;
                    --ffe-color-border-interactive-focus: #ea910b;
                    --ffe-color-border-interactive-selected: #9ec2e5;
                }
            }
            .ffe-dark,
            .ffe-dark .ffe-default-mode {
                --ffe-color-background-default: #020a0a;
                --ffe-color-background-subtle: #121212;
                --ffe-color-surface-primary-default: #262626;
                --ffe-color-surface-primary-default-hover: #333;
                --ffe-color-surface-primary-default-pressed: #3d3d3d;
                --ffe-color-surface-secondary-default: #0c2232;
                --ffe-color-surface-secondary-default-hover: #102d43;
                --ffe-color-surface-secondary-default-pressed: #163853;
                --ffe-color-surface-tertiary-default: #1d192f;
                --ffe-color-surface-tertiary-default-hover: #27223a;
                --ffe-color-surface-tertiary-default-pressed: #312c44;
                --ffe-color-surface-neutral-default: #333;
                --ffe-color-surface-neutral-default-hover: #3d3d3d;
                --ffe-color-surface-neutral-default-pressed: #474747;
                --ffe-color-surface-feedback-info: #163853;
                --ffe-color-surface-feedback-success: #0a4330;
                --ffe-color-surface-feedback-warning: #491c00;
                --ffe-color-surface-feedback-critical: #640e10;
                --ffe-color-surface-feedback-tip: #312c44;
                --ffe-color-fill-primary-default: #55709b;
                --ffe-color-fill-primary-default-hover: #748db4;
                --ffe-color-fill-primary-default-pressed: #90a9d0;
                --ffe-color-fill-primary-selected-default: #f7fafd;
                --ffe-color-fill-primary-selected-hover: #d7e7f4;
                --ffe-color-fill-primary-selected-pressed: #c3d9ef;
                --ffe-color-fill-primary-subtle: #374b6c;
                --ffe-color-fill-primary-subtle-hover: #3e5579;
                --ffe-color-fill-primary-subtle-pressed: #47618a;
                --ffe-color-fill-primary-invisible: rgba(255, 255, 255, 0);
                --ffe-color-fill-secondary-default: #457aa1;
                --ffe-color-fill-secondary-default-hover: #6096bd;
                --ffe-color-fill-secondary-default-pressed: #7eb5d2;
                --ffe-color-fill-secondary-subtle: #2b5a7c;
                --ffe-color-fill-secondary-subtle-hover: #356488;
                --ffe-color-fill-secondary-subtle-pressed: #3b6f96;
                --ffe-color-fill-tertiary-default: #7b718e;
                --ffe-color-fill-tertiary-default-hover: #a39db9;
                --ffe-color-fill-tertiary-default-pressed: #b4aecb;
                --ffe-color-fill-tertiary-subtle: #4e4a64;
                --ffe-color-fill-tertiary-subtle-hover: #5a5671;
                --ffe-color-fill-tertiary-subtle-pressed: #665d79;
                --ffe-color-fill-neutral-default: rgba(255, 255, 255, 0.2);
                --ffe-color-fill-neutral-default-hover: rgba(255, 255, 255, 0.25);
                --ffe-color-fill-neutral-default-pressed: rgba(255, 255, 255, 0.3);
                --ffe-color-fill-neutral-subtle: rgba(255, 255, 255, 0.075);
                --ffe-color-fill-neutral-subtle-hover: rgba(255, 255, 255, 0.1);
                --ffe-color-fill-neutral-subtle-pressed: rgba(255, 255, 255, 0.15);
                --ffe-color-fill-neutral-extra-subtle: rgba(255, 255, 255, 0.024);
                --ffe-color-fill-neutral-extra-subtle-hover: rgba(255, 255, 255, 0.05);
                --ffe-color-fill-neutral-extra-subtle-pressed: rgba(255, 255, 255, 0.075);
                --ffe-color-fill-feedback-info: #7eb5d2;
                --ffe-color-fill-feedback-info-subtle: #234f71;
                --ffe-color-fill-feedback-success: #6abe97;
                --ffe-color-fill-feedback-success-subtle: #09583b;
                --ffe-color-fill-feedback-warning: #ea910b;
                --ffe-color-fill-feedback-warning-subtle: #682c00;
                --ffe-color-fill-feedback-critical: #ff5e5c;
                --ffe-color-fill-feedback-critical-subtle: #7c1214;
                --ffe-color-fill-feedback-tip: #c1c1dc;
                --ffe-color-fill-feedback-tip-subtle: #45415a;
                --ffe-color-foreground-default: #fff;
                --ffe-color-foreground-subtle: #c2c2c2;
                --ffe-color-foreground-emphasis: #d7e7f4;
                --ffe-color-foreground-inverse: #020a0a;
                --ffe-color-foreground-interactive-link: #c3d9ef;
                --ffe-color-foreground-interactive-link-hover: #b6d1ec;
                --ffe-color-foreground-interactive-link-pressed: #9ec2e5;
                --ffe-color-foreground-interactive-link-active: #f7fafd;
                --ffe-color-foreground-interactive-disabled: #8f8f8f;
                --ffe-color-foreground-feedback-info: #c3dfea;
                --ffe-color-foreground-feedback-success: #b2e6cd;
                --ffe-color-foreground-feedback-warning: #ffc675;
                --ffe-color-foreground-feedback-critical: #ffaea8;
                --ffe-color-foreground-feedback-tip: #d3d3ea;
                --ffe-color-component-form-input-foreground-default: #fff;
                --ffe-color-component-form-input-foreground-subtle: #c2c2c2;
                --ffe-color-component-form-input-foreground-placeholder: #adadad;
                --ffe-color-component-form-input-foreground-disabled: #adadad;
                --ffe-color-component-form-input-foreground-read-only: #c2c2c2;
                --ffe-color-component-form-input-foreground-error: #ffaea8;
                --ffe-color-component-form-input-border-active: #d7e7f4;
                --ffe-color-component-form-input-fill-default: #262626;
                --ffe-color-component-form-input-fill-default-hover: #333;
                --ffe-color-component-form-input-fill-default-pressed: #3d3d3d;
                --ffe-color-component-form-input-fill-disabled: #5c5c5c;
                --ffe-color-component-form-input-fill-read-only: #262626;
                --ffe-color-component-form-input-fill-error: #640e10;
                --ffe-color-component-form-toggleswitch-handle-default: #fff;
                --ffe-color-component-form-toggleswitch-handle-disabled: #a4a4a4;
                --ffe-color-component-form-toggleswitch-fill-default: #7a7a7a;
                --ffe-color-component-form-toggleswitch-fill-default-hover: #8f8f8f;
                --ffe-color-component-form-toggleswitch-fill-default-pressed: #adadad;
                --ffe-color-component-form-toggleswitch-fill-selected: #48a781;
                --ffe-color-component-form-toggleswitch-fill-selected-hover: #6abe97;
                --ffe-color-component-form-toggleswitch-fill-selected-pressed: #8fd1b1;
                --ffe-color-component-form-toggleswitch-fill-selected-disabled: #00754e;
                --ffe-color-component-form-toggleswitch-fill-selected-read-only: #0a4330;
                --ffe-color-component-form-toggleswitch-fill-critical: #e44244;
                --ffe-color-component-form-toggleswitch-fill-disabled: #5c5c5c;
                --ffe-color-component-form-toggleswitch-fill-read-only: #262626;
                --ffe-color-component-button-action-border-default: #00754e;
                --ffe-color-component-button-action-border-hover: #2a7e5b;
                --ffe-color-component-button-action-border-pressed: #409674;
                --ffe-color-component-button-action-fill-default: #00754e;
                --ffe-color-component-button-action-fill-hover: #2a7e5b;
                --ffe-color-component-button-action-fill-pressed: #409674;
                --ffe-color-component-button-action-foreground-default: #fff;
                --ffe-color-component-button-action-foreground-hover: #fff;
                --ffe-color-component-button-primary-border-default: #9ec2e5;
                --ffe-color-component-button-primary-border-hover: #c3d9ef;
                --ffe-color-component-button-primary-border-pressed: #d7e7f4;
                --ffe-color-component-button-primary-fill-default: #005aa4;
                --ffe-color-component-button-primary-fill-hover: #1566b2;
                --ffe-color-component-button-primary-fill-pressed: #2975c2;
                --ffe-color-component-button-primary-foreground-default: #fff;
                --ffe-color-component-button-primary-foreground-hover: #fff;
                --ffe-color-component-button-secondary-border-default: #f7fafd;
                --ffe-color-component-button-secondary-border-hover: #f7fafd;
                --ffe-color-component-button-secondary-border-pressed: #f7fafd;
                --ffe-color-component-button-secondary-fill-default: rgba(255, 255, 255, 0);
                --ffe-color-component-button-secondary-fill-hover: #333;
                --ffe-color-component-button-secondary-fill-pressed: #3d3d3d;
                --ffe-color-component-button-secondary-foreground-default: #fff;
                --ffe-color-component-button-secondary-foreground-hover: #fff;
                --ffe-color-component-button-tertiary-fill-default: rgba(255, 255, 255, 0);
                --ffe-color-component-button-tertiary-fill-hover: #333;
                --ffe-color-component-button-tertiary-fill-pressed: #3d3d3d;
                --ffe-color-component-button-tertiary-foreground-default: #f7fafd;
                --ffe-color-component-button-tertiary-foreground-hover: #f7fafd;
                --ffe-color-component-logo-name: #fff;
                --ffe-color-component-logo-number1: #fff;
                --ffe-color-component-logo-circle-dark-red: #af0000;
                --ffe-color-component-logo-circle-light-red: #e60000;
                --ffe-color-border-primary-default: rgba(255, 255, 255, 0.2);
                --ffe-color-border-primary-default-hover: rgba(255, 255, 255, 0.25);
                --ffe-color-border-primary-default-pressed: rgba(255, 255, 255, 0.3);
                --ffe-color-border-primary-subtle: rgba(255, 255, 255, 0.075);
                --ffe-color-border-primary-subtle-hover: rgba(255, 255, 255, 0.1);
                --ffe-color-border-primary-subtle-pressed: rgba(255, 255, 255, 0.15);
                --ffe-color-border-primary-emphasis: #9ec2e5;
                --ffe-color-border-feedback-info: #6096bd;
                --ffe-color-border-feedback-success: #48a781;
                --ffe-color-border-feedback-warning: #cc7205;
                --ffe-color-border-feedback-critical: #e44244;
                --ffe-color-border-feedback-tip: #a39db9;
                --ffe-color-border-interactive-focus: #ea910b;
                --ffe-color-border-interactive-selected: #9ec2e5;
            }
            @media (prefers-color-scheme: dark) {
                .regard-color-scheme-preference .ffe-accent-mode {
                    --ffe-color-background-default: #1a1a1a;
                    --ffe-color-background-subtle: #121212;
                    --ffe-color-surface-primary-default: #262626;
                    --ffe-color-surface-primary-default-hover: #333;
                    --ffe-color-surface-primary-default-pressed: #3d3d3d;
                    --ffe-color-surface-secondary-default: #0c2232;
                    --ffe-color-surface-secondary-default-hover: #102d43;
                    --ffe-color-surface-secondary-default-pressed: #163853;
                    --ffe-color-surface-tertiary-default: #1d192f;
                    --ffe-color-surface-tertiary-default-hover: #27223a;
                    --ffe-color-surface-tertiary-default-pressed: #312c44;
                    --ffe-color-surface-neutral-default: #333;
                    --ffe-color-surface-neutral-default-hover: #3d3d3d;
                    --ffe-color-surface-neutral-default-pressed: #474747;
                    --ffe-color-surface-feedback-info: #163853;
                    --ffe-color-surface-feedback-success: #0a4330;
                    --ffe-color-surface-feedback-warning: #491c00;
                    --ffe-color-surface-feedback-critical: #640e10;
                    --ffe-color-surface-feedback-tip: #312c44;
                    --ffe-color-fill-primary-default: #55709b;
                    --ffe-color-fill-primary-default-hover: #748db4;
                    --ffe-color-fill-primary-default-pressed: #90a9d0;
                    --ffe-color-fill-primary-selected-default: #f7fafd;
                    --ffe-color-fill-primary-selected-hover: #d7e7f4;
                    --ffe-color-fill-primary-selected-pressed: #c3d9ef;
                    --ffe-color-fill-primary-subtle: #374b6c;
                    --ffe-color-fill-primary-subtle-hover: #3e5579;
                    --ffe-color-fill-primary-subtle-pressed: #47618a;
                    --ffe-color-fill-primary-invisible: rgba(255, 255, 255, 0);
                    --ffe-color-fill-secondary-default: #457aa1;
                    --ffe-color-fill-secondary-default-hover: #6096bd;
                    --ffe-color-fill-secondary-default-pressed: #7eb5d2;
                    --ffe-color-fill-secondary-subtle: #2b5a7c;
                    --ffe-color-fill-secondary-subtle-hover: #356488;
                    --ffe-color-fill-secondary-subtle-pressed: #3b6f96;
                    --ffe-color-fill-tertiary-default: #7b718e;
                    --ffe-color-fill-tertiary-default-hover: #a39db9;
                    --ffe-color-fill-tertiary-default-pressed: #b4aecb;
                    --ffe-color-fill-tertiary-subtle: #4e4a64;
                    --ffe-color-fill-tertiary-subtle-hover: #5a5671;
                    --ffe-color-fill-tertiary-subtle-pressed: #665d79;
                    --ffe-color-fill-neutral-default: rgba(255, 255, 255, 0.2);
                    --ffe-color-fill-neutral-default-hover: rgba(255, 255, 255, 0.25);
                    --ffe-color-fill-neutral-default-pressed: rgba(255, 255, 255, 0.3);
                    --ffe-color-fill-neutral-subtle: rgba(255, 255, 255, 0.075);
                    --ffe-color-fill-neutral-subtle-hover: rgba(255, 255, 255, 0.1);
                    --ffe-color-fill-neutral-subtle-pressed: rgba(255, 255, 255, 0.15);
                    --ffe-color-fill-neutral-extra-subtle: rgba(255, 255, 255, 0.024);
                    --ffe-color-fill-neutral-extra-subtle-hover: rgba(255, 255, 255, 0.05);
                    --ffe-color-fill-neutral-extra-subtle-pressed: rgba(255, 255, 255, 0.075);
                    --ffe-color-fill-feedback-info: #7eb5d2;
                    --ffe-color-fill-feedback-info-subtle: #234f71;
                    --ffe-color-fill-feedback-success: #6abe97;
                    --ffe-color-fill-feedback-success-subtle: #09583b;
                    --ffe-color-fill-feedback-warning: #ea910b;
                    --ffe-color-fill-feedback-warning-subtle: #682c00;
                    --ffe-color-fill-feedback-critical: #ff5e5c;
                    --ffe-color-fill-feedback-critical-subtle: #7c1214;
                    --ffe-color-fill-feedback-tip: #c1c1dc;
                    --ffe-color-fill-feedback-tip-subtle: #45415a;
                    --ffe-color-foreground-default: #fff;
                    --ffe-color-foreground-subtle: #c2c2c2;
                    --ffe-color-foreground-emphasis: #d7e7f4;
                    --ffe-color-foreground-inverse: #020a0a;
                    --ffe-color-foreground-interactive-link: #c3d9ef;
                    --ffe-color-foreground-interactive-link-hover: #b6d1ec;
                    --ffe-color-foreground-interactive-link-pressed: #9ec2e5;
                    --ffe-color-foreground-interactive-link-active: #f7fafd;
                    --ffe-color-foreground-interactive-disabled: #8f8f8f;
                    --ffe-color-foreground-feedback-info: #c3dfea;
                    --ffe-color-foreground-feedback-success: #b2e6cd;
                    --ffe-color-foreground-feedback-warning: #ffc675;
                    --ffe-color-foreground-feedback-critical: #ffaea8;
                    --ffe-color-foreground-feedback-tip: #d3d3ea;
                    --ffe-color-component-form-input-foreground-default: #fff;
                    --ffe-color-component-form-input-foreground-subtle: #c2c2c2;
                    --ffe-color-component-form-input-foreground-placeholder: #adadad;
                    --ffe-color-component-form-input-foreground-disabled: #adadad;
                    --ffe-color-component-form-input-foreground-read-only: #c2c2c2;
                    --ffe-color-component-form-input-foreground-error: #ffaea8;
                    --ffe-color-component-form-input-border-active: #d7e7f4;
                    --ffe-color-component-form-input-fill-default: #262626;
                    --ffe-color-component-form-input-fill-default-hover: #333;
                    --ffe-color-component-form-input-fill-default-pressed: #3d3d3d;
                    --ffe-color-component-form-input-fill-disabled: #5c5c5c;
                    --ffe-color-component-form-input-fill-read-only: #262626;
                    --ffe-color-component-form-input-fill-error: #640e10;
                    --ffe-color-component-form-toggleswitch-handle-default: #fff;
                    --ffe-color-component-form-toggleswitch-handle-disabled: #a4a4a4;
                    --ffe-color-component-form-toggleswitch-fill-default: #7a7a7a;
                    --ffe-color-component-form-toggleswitch-fill-default-hover: #8f8f8f;
                    --ffe-color-component-form-toggleswitch-fill-default-pressed: #adadad;
                    --ffe-color-component-form-toggleswitch-fill-selected: #48a781;
                    --ffe-color-component-form-toggleswitch-fill-selected-hover: #6abe97;
                    --ffe-color-component-form-toggleswitch-fill-selected-pressed: #8fd1b1;
                    --ffe-color-component-form-toggleswitch-fill-selected-disabled: #00754e;
                    --ffe-color-component-form-toggleswitch-fill-selected-read-only: #0a4330;
                    --ffe-color-component-form-toggleswitch-fill-critical: #e44244;
                    --ffe-color-component-form-toggleswitch-fill-disabled: #5c5c5c;
                    --ffe-color-component-form-toggleswitch-fill-read-only: #262626;
                    --ffe-color-component-button-action-border-default: #00754e;
                    --ffe-color-component-button-action-border-hover: #2a7e5b;
                    --ffe-color-component-button-action-border-pressed: #409674;
                    --ffe-color-component-button-action-fill-default: #00754e;
                    --ffe-color-component-button-action-fill-hover: #2a7e5b;
                    --ffe-color-component-button-action-fill-pressed: #409674;
                    --ffe-color-component-button-action-foreground-default: #fff;
                    --ffe-color-component-button-action-foreground-hover: #fff;
                    --ffe-color-component-button-primary-border-default: #9ec2e5;
                    --ffe-color-component-button-primary-border-hover: #c3d9ef;
                    --ffe-color-component-button-primary-border-pressed: #d7e7f4;
                    --ffe-color-component-button-primary-fill-default: #005aa4;
                    --ffe-color-component-button-primary-fill-hover: #1566b2;
                    --ffe-color-component-button-primary-fill-pressed: #2975c2;
                    --ffe-color-component-button-primary-foreground-default: #fff;
                    --ffe-color-component-button-primary-foreground-hover: #fff;
                    --ffe-color-component-button-secondary-border-default: #f7fafd;
                    --ffe-color-component-button-secondary-border-hover: #f7fafd;
                    --ffe-color-component-button-secondary-border-pressed: #f7fafd;
                    --ffe-color-component-button-secondary-fill-default: rgba(255, 255, 255, 0);
                    --ffe-color-component-button-secondary-fill-hover: #333;
                    --ffe-color-component-button-secondary-fill-pressed: #3d3d3d;
                    --ffe-color-component-button-secondary-foreground-default: #fff;
                    --ffe-color-component-button-secondary-foreground-hover: #fff;
                    --ffe-color-component-button-tertiary-fill-default: rgba(255, 255, 255, 0);
                    --ffe-color-component-button-tertiary-fill-hover: #333;
                    --ffe-color-component-button-tertiary-fill-pressed: #3d3d3d;
                    --ffe-color-component-button-tertiary-foreground-default: #f7fafd;
                    --ffe-color-component-button-tertiary-foreground-hover: #f7fafd;
                    --ffe-color-component-logo-name: #fff;
                    --ffe-color-component-logo-number1: #fff;
                    --ffe-color-component-logo-circle-dark-red: #af0000;
                    --ffe-color-component-logo-circle-light-red: #e60000;
                    --ffe-color-border-primary-default: rgba(255, 255, 255, 0.2);
                    --ffe-color-border-primary-default-hover: rgba(255, 255, 255, 0.25);
                    --ffe-color-border-primary-default-pressed: rgba(255, 255, 255, 0.3);
                    --ffe-color-border-primary-subtle: rgba(255, 255, 255, 0.075);
                    --ffe-color-border-primary-subtle-hover: rgba(255, 255, 255, 0.1);
                    --ffe-color-border-primary-subtle-pressed: rgba(255, 255, 255, 0.15);
                    --ffe-color-border-primary-emphasis: #9ec2e5;
                    --ffe-color-border-feedback-info: #6096bd;
                    --ffe-color-border-feedback-success: #48a781;
                    --ffe-color-border-feedback-warning: #cc7205;
                    --ffe-color-border-feedback-critical: #e44244;
                    --ffe-color-border-feedback-tip: #a39db9;
                    --ffe-color-border-interactive-focus: #f49f1f;
                    --ffe-color-border-interactive-selected: #9ec2e5;
                }
            }
            .ffe-dark .ffe-accent-mode,
            .ffe-dark.ffe-accent-mode {
                --ffe-color-background-default: #1a1a1a;
                --ffe-color-background-subtle: #121212;
                --ffe-color-surface-primary-default: #262626;
                --ffe-color-surface-primary-default-hover: #333;
                --ffe-color-surface-primary-default-pressed: #3d3d3d;
                --ffe-color-surface-secondary-default: #0c2232;
                --ffe-color-surface-secondary-default-hover: #102d43;
                --ffe-color-surface-secondary-default-pressed: #163853;
                --ffe-color-surface-tertiary-default: #1d192f;
                --ffe-color-surface-tertiary-default-hover: #27223a;
                --ffe-color-surface-tertiary-default-pressed: #312c44;
                --ffe-color-surface-neutral-default: #333;
                --ffe-color-surface-neutral-default-hover: #3d3d3d;
                --ffe-color-surface-neutral-default-pressed: #474747;
                --ffe-color-surface-feedback-info: #163853;
                --ffe-color-surface-feedback-success: #0a4330;
                --ffe-color-surface-feedback-warning: #491c00;
                --ffe-color-surface-feedback-critical: #640e10;
                --ffe-color-surface-feedback-tip: #312c44;
                --ffe-color-fill-primary-default: #55709b;
                --ffe-color-fill-primary-default-hover: #748db4;
                --ffe-color-fill-primary-default-pressed: #90a9d0;
                --ffe-color-fill-primary-selected-default: #f7fafd;
                --ffe-color-fill-primary-selected-hover: #d7e7f4;
                --ffe-color-fill-primary-selected-pressed: #c3d9ef;
                --ffe-color-fill-primary-subtle: #374b6c;
                --ffe-color-fill-primary-subtle-hover: #3e5579;
                --ffe-color-fill-primary-subtle-pressed: #47618a;
                --ffe-color-fill-primary-invisible: rgba(255, 255, 255, 0);
                --ffe-color-fill-secondary-default: #457aa1;
                --ffe-color-fill-secondary-default-hover: #6096bd;
                --ffe-color-fill-secondary-default-pressed: #7eb5d2;
                --ffe-color-fill-secondary-subtle: #2b5a7c;
                --ffe-color-fill-secondary-subtle-hover: #356488;
                --ffe-color-fill-secondary-subtle-pressed: #3b6f96;
                --ffe-color-fill-tertiary-default: #7b718e;
                --ffe-color-fill-tertiary-default-hover: #a39db9;
                --ffe-color-fill-tertiary-default-pressed: #b4aecb;
                --ffe-color-fill-tertiary-subtle: #4e4a64;
                --ffe-color-fill-tertiary-subtle-hover: #5a5671;
                --ffe-color-fill-tertiary-subtle-pressed: #665d79;
                --ffe-color-fill-neutral-default: rgba(255, 255, 255, 0.2);
                --ffe-color-fill-neutral-default-hover: rgba(255, 255, 255, 0.25);
                --ffe-color-fill-neutral-default-pressed: rgba(255, 255, 255, 0.3);
                --ffe-color-fill-neutral-subtle: rgba(255, 255, 255, 0.075);
                --ffe-color-fill-neutral-subtle-hover: rgba(255, 255, 255, 0.1);
                --ffe-color-fill-neutral-subtle-pressed: rgba(255, 255, 255, 0.15);
                --ffe-color-fill-neutral-extra-subtle: rgba(255, 255, 255, 0.024);
                --ffe-color-fill-neutral-extra-subtle-hover: rgba(255, 255, 255, 0.05);
                --ffe-color-fill-neutral-extra-subtle-pressed: rgba(255, 255, 255, 0.075);
                --ffe-color-fill-feedback-info: #7eb5d2;
                --ffe-color-fill-feedback-info-subtle: #234f71;
                --ffe-color-fill-feedback-success: #6abe97;
                --ffe-color-fill-feedback-success-subtle: #09583b;
                --ffe-color-fill-feedback-warning: #ea910b;
                --ffe-color-fill-feedback-warning-subtle: #682c00;
                --ffe-color-fill-feedback-critical: #ff5e5c;
                --ffe-color-fill-feedback-critical-subtle: #7c1214;
                --ffe-color-fill-feedback-tip: #c1c1dc;
                --ffe-color-fill-feedback-tip-subtle: #45415a;
                --ffe-color-foreground-default: #fff;
                --ffe-color-foreground-subtle: #c2c2c2;
                --ffe-color-foreground-emphasis: #d7e7f4;
                --ffe-color-foreground-inverse: #020a0a;
                --ffe-color-foreground-interactive-link: #c3d9ef;
                --ffe-color-foreground-interactive-link-hover: #b6d1ec;
                --ffe-color-foreground-interactive-link-pressed: #9ec2e5;
                --ffe-color-foreground-interactive-link-active: #f7fafd;
                --ffe-color-foreground-interactive-disabled: #8f8f8f;
                --ffe-color-foreground-feedback-info: #c3dfea;
                --ffe-color-foreground-feedback-success: #b2e6cd;
                --ffe-color-foreground-feedback-warning: #ffc675;
                --ffe-color-foreground-feedback-critical: #ffaea8;
                --ffe-color-foreground-feedback-tip: #d3d3ea;
                --ffe-color-component-form-input-foreground-default: #fff;
                --ffe-color-component-form-input-foreground-subtle: #c2c2c2;
                --ffe-color-component-form-input-foreground-placeholder: #adadad;
                --ffe-color-component-form-input-foreground-disabled: #adadad;
                --ffe-color-component-form-input-foreground-read-only: #c2c2c2;
                --ffe-color-component-form-input-foreground-error: #ffaea8;
                --ffe-color-component-form-input-border-active: #d7e7f4;
                --ffe-color-component-form-input-fill-default: #262626;
                --ffe-color-component-form-input-fill-default-hover: #333;
                --ffe-color-component-form-input-fill-default-pressed: #3d3d3d;
                --ffe-color-component-form-input-fill-disabled: #5c5c5c;
                --ffe-color-component-form-input-fill-read-only: #262626;
                --ffe-color-component-form-input-fill-error: #640e10;
                --ffe-color-component-form-toggleswitch-handle-default: #fff;
                --ffe-color-component-form-toggleswitch-handle-disabled: #a4a4a4;
                --ffe-color-component-form-toggleswitch-fill-default: #7a7a7a;
                --ffe-color-component-form-toggleswitch-fill-default-hover: #8f8f8f;
                --ffe-color-component-form-toggleswitch-fill-default-pressed: #adadad;
                --ffe-color-component-form-toggleswitch-fill-selected: #48a781;
                --ffe-color-component-form-toggleswitch-fill-selected-hover: #6abe97;
                --ffe-color-component-form-toggleswitch-fill-selected-pressed: #8fd1b1;
                --ffe-color-component-form-toggleswitch-fill-selected-disabled: #00754e;
                --ffe-color-component-form-toggleswitch-fill-selected-read-only: #0a4330;
                --ffe-color-component-form-toggleswitch-fill-critical: #e44244;
                --ffe-color-component-form-toggleswitch-fill-disabled: #5c5c5c;
                --ffe-color-component-form-toggleswitch-fill-read-only: #262626;
                --ffe-color-component-button-action-border-default: #00754e;
                --ffe-color-component-button-action-border-hover: #2a7e5b;
                --ffe-color-component-button-action-border-pressed: #409674;
                --ffe-color-component-button-action-fill-default: #00754e;
                --ffe-color-component-button-action-fill-hover: #2a7e5b;
                --ffe-color-component-button-action-fill-pressed: #409674;
                --ffe-color-component-button-action-foreground-default: #fff;
                --ffe-color-component-button-action-foreground-hover: #fff;
                --ffe-color-component-button-primary-border-default: #9ec2e5;
                --ffe-color-component-button-primary-border-hover: #c3d9ef;
                --ffe-color-component-button-primary-border-pressed: #d7e7f4;
                --ffe-color-component-button-primary-fill-default: #005aa4;
                --ffe-color-component-button-primary-fill-hover: #1566b2;
                --ffe-color-component-button-primary-fill-pressed: #2975c2;
                --ffe-color-component-button-primary-foreground-default: #fff;
                --ffe-color-component-button-primary-foreground-hover: #fff;
                --ffe-color-component-button-secondary-border-default: #f7fafd;
                --ffe-color-component-button-secondary-border-hover: #f7fafd;
                --ffe-color-component-button-secondary-border-pressed: #f7fafd;
                --ffe-color-component-button-secondary-fill-default: rgba(255, 255, 255, 0);
                --ffe-color-component-button-secondary-fill-hover: #333;
                --ffe-color-component-button-secondary-fill-pressed: #3d3d3d;
                --ffe-color-component-button-secondary-foreground-default: #fff;
                --ffe-color-component-button-secondary-foreground-hover: #fff;
                --ffe-color-component-button-tertiary-fill-default: rgba(255, 255, 255, 0);
                --ffe-color-component-button-tertiary-fill-hover: #333;
                --ffe-color-component-button-tertiary-fill-pressed: #3d3d3d;
                --ffe-color-component-button-tertiary-foreground-default: #f7fafd;
                --ffe-color-component-button-tertiary-foreground-hover: #f7fafd;
                --ffe-color-component-logo-name: #fff;
                --ffe-color-component-logo-number1: #fff;
                --ffe-color-component-logo-circle-dark-red: #af0000;
                --ffe-color-component-logo-circle-light-red: #e60000;
                --ffe-color-border-primary-default: rgba(255, 255, 255, 0.2);
                --ffe-color-border-primary-default-hover: rgba(255, 255, 255, 0.25);
                --ffe-color-border-primary-default-pressed: rgba(255, 255, 255, 0.3);
                --ffe-color-border-primary-subtle: rgba(255, 255, 255, 0.075);
                --ffe-color-border-primary-subtle-hover: rgba(255, 255, 255, 0.1);
                --ffe-color-border-primary-subtle-pressed: rgba(255, 255, 255, 0.15);
                --ffe-color-border-primary-emphasis: #9ec2e5;
                --ffe-color-border-feedback-info: #6096bd;
                --ffe-color-border-feedback-success: #48a781;
                --ffe-color-border-feedback-warning: #cc7205;
                --ffe-color-border-feedback-critical: #e44244;
                --ffe-color-border-feedback-tip: #a39db9;
                --ffe-color-border-interactive-focus: #f49f1f;
                --ffe-color-border-interactive-selected: #9ec2e5;
            }
            :root,
            .ffe-default-mode,
            .ffe-light,
            .ffe-light .ffe-default-mode,
            .ffe-light.ffe-default-mode {
                --ffe-color-background-default: #fff;
                --ffe-color-background-subtle: #fdf8f5;
                --ffe-color-surface-primary-default: #fff;
                --ffe-color-surface-primary-default-hover: #e7f1f9;
                --ffe-color-surface-primary-default-pressed: #d7e7f4;
                --ffe-color-surface-secondary-default: #e5f0f5;
                --ffe-color-surface-secondary-default-hover: #dceaef;
                --ffe-color-surface-secondary-default-pressed: #cbe2eb;
                --ffe-color-surface-tertiary-default: #eaeaf6;
                --ffe-color-surface-tertiary-default-hover: #e6e6f4;
                --ffe-color-surface-tertiary-default-pressed: #dcdcef;
                --ffe-color-surface-neutral-default: #f0f0f0;
                --ffe-color-surface-neutral-default-hover: #e5e5e5;
                --ffe-color-surface-neutral-default-pressed: #dbdbdb;
                --ffe-color-surface-feedback-info: #e5f0f5;
                --ffe-color-surface-feedback-success: #dff6eb;
                --ffe-color-surface-feedback-warning: #fdeed3;
                --ffe-color-surface-feedback-critical: #ffe3e0;
                --ffe-color-surface-feedback-tip: #eaeaf6;
                --ffe-color-fill-primary-default: #9ec2e5;
                --ffe-color-fill-primary-default-hover: #7dabd9;
                --ffe-color-fill-primary-default-pressed: #5494d4;
                --ffe-color-fill-primary-selected-default: #005aa4;
                --ffe-color-fill-primary-selected-hover: #073f83;
                --ffe-color-fill-primary-selected-pressed: #082868;
                --ffe-color-fill-primary-subtle: #d7e7f4;
                --ffe-color-fill-primary-subtle-hover: #c3d9ef;
                --ffe-color-fill-primary-subtle-pressed: #b6d1ec;
                --ffe-color-fill-primary-invisible: rgba(255, 255, 255, 0);
                --ffe-color-fill-secondary-default: #a6cee2;
                --ffe-color-fill-secondary-default-hover: #7eb5d2;
                --ffe-color-fill-secondary-default-pressed: #6096bd;
                --ffe-color-fill-secondary-subtle: #cbe2eb;
                --ffe-color-fill-secondary-subtle-hover: #c3dfea;
                --ffe-color-fill-secondary-subtle-pressed: #b6d7e7;
                --ffe-color-fill-tertiary-default: #c1c1dc;
                --ffe-color-fill-tertiary-default-hover: #b4aecb;
                --ffe-color-fill-tertiary-default-pressed: #a39db9;
                --ffe-color-fill-tertiary-subtle: #dcdcef;
                --ffe-color-fill-tertiary-subtle-hover: #d3d3ea;
                --ffe-color-fill-tertiary-subtle-pressed: #cacae3;
                --ffe-color-fill-neutral-default: rgba(2, 10, 10, 0.2);
                --ffe-color-fill-neutral-default-hover: rgba(2, 10, 10, 0.25);
                --ffe-color-fill-neutral-default-pressed: rgba(2, 10, 10, 0.3);
                --ffe-color-fill-neutral-subtle: rgba(2, 10, 10, 0.075);
                --ffe-color-fill-neutral-subtle-hover: rgba(2, 10, 10, 0.1);
                --ffe-color-fill-neutral-subtle-pressed: rgba(2, 10, 10, 0.15);
                --ffe-color-fill-neutral-extra-subtle: rgba(2, 10, 10, 0.024);
                --ffe-color-fill-neutral-extra-subtle-hover: rgba(2, 10, 10, 0.05);
                --ffe-color-fill-neutral-extra-subtle-pressed: rgba(2, 10, 10, 0.075);
                --ffe-color-fill-feedback-info: #457aa1;
                --ffe-color-fill-feedback-info-subtle: #cbe2eb;
                --ffe-color-fill-feedback-success: #2a7e5b;
                --ffe-color-fill-feedback-success-subtle: #bbedd5;
                --ffe-color-fill-feedback-warning: #a95704;
                --ffe-color-fill-feedback-warning-subtle: #ffd394;
                --ffe-color-fill-feedback-critical: #c62a2f;
                --ffe-color-fill-feedback-critical-subtle: #ffbeb8;
                --ffe-color-fill-feedback-tip: #5a5671;
                --ffe-color-fill-feedback-tip-subtle: #dcdcef;
                --ffe-color-foreground-default: #1a1a1a;
                --ffe-color-foreground-subtle: #525252;
                --ffe-color-foreground-emphasis: #08235e;
                --ffe-color-foreground-inverse: #fff;
                --ffe-color-foreground-interactive-link: #005aa4;
                --ffe-color-foreground-interactive-link-hover: #073f83;
                --ffe-color-foreground-interactive-link-pressed: #082868;
                --ffe-color-foreground-interactive-link-active: #005aa4;
                --ffe-color-foreground-interactive-disabled: #a4a4a4;
                --ffe-color-foreground-feedback-info: #234f71;
                --ffe-color-foreground-feedback-success: #0a4d37;
                --ffe-color-foreground-feedback-warning: #682c00;
                --ffe-color-foreground-feedback-critical: #7c1214;
                --ffe-color-foreground-feedback-tip: #45415a;
                --ffe-color-component-form-input-foreground-default: #1a1a1a;
                --ffe-color-component-form-input-foreground-subtle: #525252;
                --ffe-color-component-form-input-foreground-placeholder: #8f8f8f;
                --ffe-color-component-form-input-foreground-disabled: #8f8f8f;
                --ffe-color-component-form-input-foreground-read-only: #525252;
                --ffe-color-component-form-input-foreground-error: #7c1214;
                --ffe-color-component-form-input-border-active: #08235e;
                --ffe-color-component-form-input-fill-default: #fff;
                --ffe-color-component-form-input-fill-default-hover: #e7f1f9;
                --ffe-color-component-form-input-fill-default-pressed: #d7e7f4;
                --ffe-color-component-form-input-fill-disabled: #d6d6d6;
                --ffe-color-component-form-input-fill-read-only: #f0f0f0;
                --ffe-color-component-form-input-fill-error: #ffe3e0;
                --ffe-color-component-form-toggleswitch-handle-default: #fff;
                --ffe-color-component-form-toggleswitch-handle-disabled: #a4a4a4;
                --ffe-color-component-form-toggleswitch-fill-default: #c2c2c2;
                --ffe-color-component-form-toggleswitch-fill-default-hover: #a4a4a4;
                --ffe-color-component-form-toggleswitch-fill-default-pressed: #8f8f8f;
                --ffe-color-component-form-toggleswitch-fill-selected: #48a781;
                --ffe-color-component-form-toggleswitch-fill-selected-hover: #2a7e5b;
                --ffe-color-component-form-toggleswitch-fill-selected-pressed: #0d6346;
                --ffe-color-component-form-toggleswitch-fill-selected-disabled: #9edbbe;
                --ffe-color-component-form-toggleswitch-fill-selected-read-only: #dff6eb;
                --ffe-color-component-form-toggleswitch-fill-critical: #e44244;
                --ffe-color-component-form-toggleswitch-fill-disabled: #d6d6d6;
                --ffe-color-component-form-toggleswitch-fill-read-only: #f0f0f0;
                --ffe-color-component-button-action-border-default: #2a7e5b;
                --ffe-color-component-button-action-border-hover: #0d6346;
                --ffe-color-component-button-action-border-pressed: #0a4d37;
                --ffe-color-component-button-action-fill-default: #2a7e5b;
                --ffe-color-component-button-action-fill-hover: #0d6346;
                --ffe-color-component-button-action-fill-pressed: #0a4d37;
                --ffe-color-component-button-action-foreground-default: #fff;
                --ffe-color-component-button-action-foreground-hover: #fff;
                --ffe-color-component-button-primary-border-default: #084f91;
                --ffe-color-component-button-primary-border-hover: #04347c;
                --ffe-color-component-button-primary-border-pressed: #08235e;
                --ffe-color-component-button-primary-fill-default: #084f91;
                --ffe-color-component-button-primary-fill-hover: #073f83;
                --ffe-color-component-button-primary-fill-pressed: #082868;
                --ffe-color-component-button-primary-foreground-default: #fff;
                --ffe-color-component-button-primary-foreground-hover: #fff;
                --ffe-color-component-button-secondary-border-default: #08235e;
                --ffe-color-component-button-secondary-border-hover: #08235e;
                --ffe-color-component-button-secondary-border-pressed: #08235e;
                --ffe-color-component-button-secondary-fill-default: rgba(255, 255, 255, 0);
                --ffe-color-component-button-secondary-fill-hover: #d7e7f4;
                --ffe-color-component-button-secondary-fill-pressed: #c3d9ef;
                --ffe-color-component-button-secondary-foreground-default: #08235e;
                --ffe-color-component-button-secondary-foreground-hover: #08235e;
                --ffe-color-component-button-tertiary-fill-default: rgba(255, 255, 255, 0);
                --ffe-color-component-button-tertiary-fill-hover: #d7e7f4;
                --ffe-color-component-button-tertiary-fill-pressed: #c3d9ef;
                --ffe-color-component-button-tertiary-foreground-default: #08235e;
                --ffe-color-component-button-tertiary-foreground-hover: #08235e;
                --ffe-color-component-logo-name: #082868;
                --ffe-color-component-logo-number1: #fff;
                --ffe-color-component-logo-circle-dark-red: #af0000;
                --ffe-color-component-logo-circle-light-red: #e60000;
                --ffe-color-border-primary-default: rgba(2, 10, 10, 0.2);
                --ffe-color-border-primary-default-hover: rgba(2, 10, 10, 0.25);
                --ffe-color-border-primary-default-pressed: rgba(2, 10, 10, 0.3);
                --ffe-color-border-primary-subtle: rgba(2, 10, 10, 0.075);
                --ffe-color-border-primary-subtle-hover: rgba(2, 10, 10, 0.1);
                --ffe-color-border-primary-subtle-pressed: rgba(2, 10, 10, 0.15);
                --ffe-color-border-primary-emphasis: #084f91;
                --ffe-color-border-feedback-info: #6096bd;
                --ffe-color-border-feedback-success: #48a781;
                --ffe-color-border-feedback-warning: #cc7205;
                --ffe-color-border-feedback-critical: #e44244;
                --ffe-color-border-feedback-tip: #a39db9;
                --ffe-color-border-interactive-focus: #dc8000;
                --ffe-color-border-interactive-selected: #084f91;
            }
            :host {
                --ffe-color-background-default: #fff;
                --ffe-color-background-subtle: #fdf8f5;
                --ffe-color-surface-primary-default: #fff;
                --ffe-color-surface-primary-default-hover: #e7f1f9;
                --ffe-color-surface-primary-default-pressed: #d7e7f4;
                --ffe-color-surface-secondary-default: #e5f0f5;
                --ffe-color-surface-secondary-default-hover: #dceaef;
                --ffe-color-surface-secondary-default-pressed: #cbe2eb;
                --ffe-color-surface-tertiary-default: #eaeaf6;
                --ffe-color-surface-tertiary-default-hover: #e6e6f4;
                --ffe-color-surface-tertiary-default-pressed: #dcdcef;
                --ffe-color-surface-neutral-default: #f0f0f0;
                --ffe-color-surface-neutral-default-hover: #e5e5e5;
                --ffe-color-surface-neutral-default-pressed: #dbdbdb;
                --ffe-color-surface-feedback-info: #e5f0f5;
                --ffe-color-surface-feedback-success: #dff6eb;
                --ffe-color-surface-feedback-warning: #fdeed3;
                --ffe-color-surface-feedback-critical: #ffe3e0;
                --ffe-color-surface-feedback-tip: #eaeaf6;
                --ffe-color-fill-primary-default: #9ec2e5;
                --ffe-color-fill-primary-default-hover: #7dabd9;
                --ffe-color-fill-primary-default-pressed: #5494d4;
                --ffe-color-fill-primary-selected-default: #005aa4;
                --ffe-color-fill-primary-selected-hover: #073f83;
                --ffe-color-fill-primary-selected-pressed: #082868;
                --ffe-color-fill-primary-subtle: #d7e7f4;
                --ffe-color-fill-primary-subtle-hover: #c3d9ef;
                --ffe-color-fill-primary-subtle-pressed: #b6d1ec;
                --ffe-color-fill-primary-invisible: rgba(255, 255, 255, 0);
                --ffe-color-fill-secondary-default: #a6cee2;
                --ffe-color-fill-secondary-default-hover: #7eb5d2;
                --ffe-color-fill-secondary-default-pressed: #6096bd;
                --ffe-color-fill-secondary-subtle: #cbe2eb;
                --ffe-color-fill-secondary-subtle-hover: #c3dfea;
                --ffe-color-fill-secondary-subtle-pressed: #b6d7e7;
                --ffe-color-fill-tertiary-default: #c1c1dc;
                --ffe-color-fill-tertiary-default-hover: #b4aecb;
                --ffe-color-fill-tertiary-default-pressed: #a39db9;
                --ffe-color-fill-tertiary-subtle: #dcdcef;
                --ffe-color-fill-tertiary-subtle-hover: #d3d3ea;
                --ffe-color-fill-tertiary-subtle-pressed: #cacae3;
                --ffe-color-fill-neutral-default: rgba(2, 10, 10, 0.2);
                --ffe-color-fill-neutral-default-hover: rgba(2, 10, 10, 0.25);
                --ffe-color-fill-neutral-default-pressed: rgba(2, 10, 10, 0.3);
                --ffe-color-fill-neutral-subtle: rgba(2, 10, 10, 0.075);
                --ffe-color-fill-neutral-subtle-hover: rgba(2, 10, 10, 0.1);
                --ffe-color-fill-neutral-subtle-pressed: rgba(2, 10, 10, 0.15);
                --ffe-color-fill-neutral-extra-subtle: rgba(2, 10, 10, 0.024);
                --ffe-color-fill-neutral-extra-subtle-hover: rgba(2, 10, 10, 0.05);
                --ffe-color-fill-neutral-extra-subtle-pressed: rgba(2, 10, 10, 0.075);
                --ffe-color-fill-feedback-info: #457aa1;
                --ffe-color-fill-feedback-info-subtle: #cbe2eb;
                --ffe-color-fill-feedback-success: #2a7e5b;
                --ffe-color-fill-feedback-success-subtle: #bbedd5;
                --ffe-color-fill-feedback-warning: #a95704;
                --ffe-color-fill-feedback-warning-subtle: #ffd394;
                --ffe-color-fill-feedback-critical: #c62a2f;
                --ffe-color-fill-feedback-critical-subtle: #ffbeb8;
                --ffe-color-fill-feedback-tip: #5a5671;
                --ffe-color-fill-feedback-tip-subtle: #dcdcef;
                --ffe-color-foreground-default: #1a1a1a;
                --ffe-color-foreground-subtle: #525252;
                --ffe-color-foreground-emphasis: #08235e;
                --ffe-color-foreground-inverse: #fff;
                --ffe-color-foreground-interactive-link: #005aa4;
                --ffe-color-foreground-interactive-link-hover: #073f83;
                --ffe-color-foreground-interactive-link-pressed: #082868;
                --ffe-color-foreground-interactive-link-active: #005aa4;
                --ffe-color-foreground-interactive-disabled: #a4a4a4;
                --ffe-color-foreground-feedback-info: #234f71;
                --ffe-color-foreground-feedback-success: #0a4d37;
                --ffe-color-foreground-feedback-warning: #682c00;
                --ffe-color-foreground-feedback-critical: #7c1214;
                --ffe-color-foreground-feedback-tip: #45415a;
                --ffe-color-component-form-input-foreground-default: #1a1a1a;
                --ffe-color-component-form-input-foreground-subtle: #525252;
                --ffe-color-component-form-input-foreground-placeholder: #8f8f8f;
                --ffe-color-component-form-input-foreground-disabled: #8f8f8f;
                --ffe-color-component-form-input-foreground-read-only: #525252;
                --ffe-color-component-form-input-foreground-error: #7c1214;
                --ffe-color-component-form-input-border-active: #08235e;
                --ffe-color-component-form-input-fill-default: #fff;
                --ffe-color-component-form-input-fill-default-hover: #e7f1f9;
                --ffe-color-component-form-input-fill-default-pressed: #d7e7f4;
                --ffe-color-component-form-input-fill-disabled: #d6d6d6;
                --ffe-color-component-form-input-fill-read-only: #f0f0f0;
                --ffe-color-component-form-input-fill-error: #ffe3e0;
                --ffe-color-component-form-toggleswitch-handle-default: #fff;
                --ffe-color-component-form-toggleswitch-handle-disabled: #a4a4a4;
                --ffe-color-component-form-toggleswitch-fill-default: #c2c2c2;
                --ffe-color-component-form-toggleswitch-fill-default-hover: #a4a4a4;
                --ffe-color-component-form-toggleswitch-fill-default-pressed: #8f8f8f;
                --ffe-color-component-form-toggleswitch-fill-selected: #48a781;
                --ffe-color-component-form-toggleswitch-fill-selected-hover: #2a7e5b;
                --ffe-color-component-form-toggleswitch-fill-selected-pressed: #0d6346;
                --ffe-color-component-form-toggleswitch-fill-selected-disabled: #9edbbe;
                --ffe-color-component-form-toggleswitch-fill-selected-read-only: #dff6eb;
                --ffe-color-component-form-toggleswitch-fill-critical: #e44244;
                --ffe-color-component-form-toggleswitch-fill-disabled: #d6d6d6;
                --ffe-color-component-form-toggleswitch-fill-read-only: #f0f0f0;
                --ffe-color-component-button-action-border-default: #2a7e5b;
                --ffe-color-component-button-action-border-hover: #0d6346;
                --ffe-color-component-button-action-border-pressed: #0a4d37;
                --ffe-color-component-button-action-fill-default: #2a7e5b;
                --ffe-color-component-button-action-fill-hover: #0d6346;
                --ffe-color-component-button-action-fill-pressed: #0a4d37;
                --ffe-color-component-button-action-foreground-default: #fff;
                --ffe-color-component-button-action-foreground-hover: #fff;
                --ffe-color-component-button-primary-border-default: #084f91;
                --ffe-color-component-button-primary-border-hover: #04347c;
                --ffe-color-component-button-primary-border-pressed: #08235e;
                --ffe-color-component-button-primary-fill-default: #084f91;
                --ffe-color-component-button-primary-fill-hover: #073f83;
                --ffe-color-component-button-primary-fill-pressed: #082868;
                --ffe-color-component-button-primary-foreground-default: #fff;
                --ffe-color-component-button-primary-foreground-hover: #fff;
                --ffe-color-component-button-secondary-border-default: #08235e;
                --ffe-color-component-button-secondary-border-hover: #08235e;
                --ffe-color-component-button-secondary-border-pressed: #08235e;
                --ffe-color-component-button-secondary-fill-default: rgba(255, 255, 255, 0);
                --ffe-color-component-button-secondary-fill-hover: #d7e7f4;
                --ffe-color-component-button-secondary-fill-pressed: #c3d9ef;
                --ffe-color-component-button-secondary-foreground-default: #08235e;
                --ffe-color-component-button-secondary-foreground-hover: #08235e;
                --ffe-color-component-button-tertiary-fill-default: rgba(255, 255, 255, 0);
                --ffe-color-component-button-tertiary-fill-hover: #d7e7f4;
                --ffe-color-component-button-tertiary-fill-pressed: #c3d9ef;
                --ffe-color-component-button-tertiary-foreground-default: #08235e;
                --ffe-color-component-button-tertiary-foreground-hover: #08235e;
                --ffe-color-component-logo-name: #082868;
                --ffe-color-component-logo-number1: #fff;
                --ffe-color-component-logo-circle-dark-red: #af0000;
                --ffe-color-component-logo-circle-light-red: #e60000;
                --ffe-color-border-primary-default: rgba(2, 10, 10, 0.2);
                --ffe-color-border-primary-default-hover: rgba(2, 10, 10, 0.25);
                --ffe-color-border-primary-default-pressed: rgba(2, 10, 10, 0.3);
                --ffe-color-border-primary-subtle: rgba(2, 10, 10, 0.075);
                --ffe-color-border-primary-subtle-hover: rgba(2, 10, 10, 0.1);
                --ffe-color-border-primary-subtle-pressed: rgba(2, 10, 10, 0.15);
                --ffe-color-border-primary-emphasis: #084f91;
                --ffe-color-border-feedback-info: #6096bd;
                --ffe-color-border-feedback-success: #48a781;
                --ffe-color-border-feedback-warning: #cc7205;
                --ffe-color-border-feedback-critical: #e44244;
                --ffe-color-border-feedback-tip: #a39db9;
                --ffe-color-border-interactive-focus: #dc8000;
                --ffe-color-border-interactive-selected: #084f91;
            }
            .ffe-light .ffe-accent-mode,
            .ffe-accent-mode {
                --ffe-color-background-default: #084f91;
                --ffe-color-background-subtle: #04347c;
                --ffe-color-surface-primary-default: #005aa4;
                --ffe-color-surface-primary-default-hover: #1566b2;
                --ffe-color-surface-primary-default-pressed: #2975c2;
                --ffe-color-surface-secondary-default: #234f71;
                --ffe-color-surface-secondary-default-hover: #1b4462;
                --ffe-color-surface-secondary-default-pressed: #163853;
                --ffe-color-surface-tertiary-default: #45415a;
                --ffe-color-surface-tertiary-default-hover: #3c374e;
                --ffe-color-surface-tertiary-default-pressed: #312c44;
                --ffe-color-surface-neutral-default: #073f83;
                --ffe-color-surface-neutral-default-hover: #084f91;
                --ffe-color-surface-neutral-default-pressed: #005aa4;
                --ffe-color-surface-feedback-info: #234f71;
                --ffe-color-surface-feedback-success: #09583b;
                --ffe-color-surface-feedback-warning: #682c00;
                --ffe-color-surface-feedback-critical: #7c1214;
                --ffe-color-surface-feedback-tip: #45415a;
                --ffe-color-fill-primary-default: #2975c2;
                --ffe-color-fill-primary-default-hover: #9ec2e5;
                --ffe-color-fill-primary-default-pressed: #c3d9ef;
                --ffe-color-fill-primary-selected-default: #fff;
                --ffe-color-fill-primary-selected-hover: #d7e7f4;
                --ffe-color-fill-primary-selected-pressed: #c3d9ef;
                --ffe-color-fill-primary-subtle: rgba(255, 255, 255, 0.15);
                --ffe-color-fill-primary-subtle-hover: rgba(255, 255, 255, 0.2);
                --ffe-color-fill-primary-subtle-pressed: rgba(255, 255, 255, 0.25);
                --ffe-color-fill-primary-invisible: rgba(255, 255, 255, 0);
                --ffe-color-fill-secondary-default: #457aa1;
                --ffe-color-fill-secondary-default-hover: #a6cee2;
                --ffe-color-fill-secondary-default-pressed: #c3dfea;
                --ffe-color-fill-secondary-subtle: #2b5a7c;
                --ffe-color-fill-secondary-subtle-hover: #356488;
                --ffe-color-fill-secondary-subtle-pressed: #3b6f96;
                --ffe-color-fill-tertiary-default: #7b718e;
                --ffe-color-fill-tertiary-default-hover: #c1c1dc;
                --ffe-color-fill-tertiary-default-pressed: #d3d3ea;
                --ffe-color-fill-tertiary-subtle: #4e4a64;
                --ffe-color-fill-tertiary-subtle-hover: #5a5671;
                --ffe-color-fill-tertiary-subtle-pressed: #665d79;
                --ffe-color-fill-neutral-default: rgba(255, 255, 255, 0.2);
                --ffe-color-fill-neutral-default-hover: rgba(255, 255, 255, 0.25);
                --ffe-color-fill-neutral-default-pressed: rgba(255, 255, 255, 0.3);
                --ffe-color-fill-neutral-subtle: rgba(255, 255, 255, 0.075);
                --ffe-color-fill-neutral-subtle-hover: rgba(255, 255, 255, 0.1);
                --ffe-color-fill-neutral-subtle-pressed: rgba(255, 255, 255, 0.15);
                --ffe-color-fill-neutral-extra-subtle: rgba(255, 255, 255, 0.024);
                --ffe-color-fill-neutral-extra-subtle-hover: rgba(255, 255, 255, 0.05);
                --ffe-color-fill-neutral-extra-subtle-pressed: rgba(255, 255, 255, 0.075);
                --ffe-color-fill-feedback-info: #a6cee2;
                --ffe-color-fill-feedback-info-subtle: #356488;
                --ffe-color-fill-feedback-success: #8fd1b1;
                --ffe-color-fill-feedback-success-subtle: #00754e;
                --ffe-color-fill-feedback-warning: #f6ac3c;
                --ffe-color-fill-feedback-warning-subtle: #853f00;
                --ffe-color-fill-feedback-critical: #ff7f7a;
                --ffe-color-fill-feedback-critical-subtle: #a01c1f;
                --ffe-color-fill-feedback-tip: #d3d3ea;
                --ffe-color-fill-feedback-tip-subtle: #5a5671;
                --ffe-color-foreground-default: #fff;
                --ffe-color-foreground-subtle: rgba(255, 255, 255, 0.8);
                --ffe-color-foreground-emphasis: #d7e7f4;
                --ffe-color-foreground-inverse: #020a0a;
                --ffe-color-foreground-interactive-link: #f7fafd;
                --ffe-color-foreground-interactive-link-hover: #e7f1f9;
                --ffe-color-foreground-interactive-link-pressed: #d7e7f4;
                --ffe-color-foreground-interactive-link-active: #fff;
                --ffe-color-foreground-interactive-disabled: rgba(255, 255, 255, 0.4);
                --ffe-color-foreground-feedback-info: #dceaef;
                --ffe-color-foreground-feedback-success: #cbf0df;
                --ffe-color-foreground-feedback-warning: #ffe0b2;
                --ffe-color-foreground-feedback-critical: #ffd5d1;
                --ffe-color-foreground-feedback-tip: #e6e6f4;
                --ffe-color-component-form-input-foreground-default: #1a1a1a;
                --ffe-color-component-form-input-foreground-subtle: #525252;
                --ffe-color-component-form-input-foreground-placeholder: #8f8f8f;
                --ffe-color-component-form-input-foreground-disabled: #8f8f8f;
                --ffe-color-component-form-input-foreground-read-only: #525252;
                --ffe-color-component-form-input-foreground-error: #7c1214;
                --ffe-color-component-form-input-border-active: #7dabd9;
                --ffe-color-component-form-input-fill-default: #fff;
                --ffe-color-component-form-input-fill-default-hover: #e7f1f9;
                --ffe-color-component-form-input-fill-default-pressed: #d7e7f4;
                --ffe-color-component-form-input-fill-disabled: #d6d6d6;
                --ffe-color-component-form-input-fill-read-only: #f0f0f0;
                --ffe-color-component-form-input-fill-error: #ffe3e0;
                --ffe-color-component-form-toggleswitch-handle-default: #fff;
                --ffe-color-component-form-toggleswitch-handle-disabled: #a4a4a4;
                --ffe-color-component-form-toggleswitch-fill-default: #c2c2c2;
                --ffe-color-component-form-toggleswitch-fill-default-hover: #a4a4a4;
                --ffe-color-component-form-toggleswitch-fill-default-pressed: #8f8f8f;
                --ffe-color-component-form-toggleswitch-fill-selected: #48a781;
                --ffe-color-component-form-toggleswitch-fill-selected-hover: #2a7e5b;
                --ffe-color-component-form-toggleswitch-fill-selected-pressed: #0d6346;
                --ffe-color-component-form-toggleswitch-fill-selected-disabled: #9edbbe;
                --ffe-color-component-form-toggleswitch-fill-selected-read-only: #dff6eb;
                --ffe-color-component-form-toggleswitch-fill-critical: #ff5e5c;
                --ffe-color-component-form-toggleswitch-fill-disabled: #d6d6d6;
                --ffe-color-component-form-toggleswitch-fill-read-only: #f0f0f0;
                --ffe-color-component-button-action-border-default: #00754e;
                --ffe-color-component-button-action-border-hover: #2a7e5b;
                --ffe-color-component-button-action-border-pressed: #409674;
                --ffe-color-component-button-action-fill-default: #00754e;
                --ffe-color-component-button-action-fill-hover: #2a7e5b;
                --ffe-color-component-button-action-fill-pressed: #409674;
                --ffe-color-component-button-action-foreground-default: #fff;
                --ffe-color-component-button-action-foreground-hover: #fff;
                --ffe-color-component-button-primary-border-default: #c3d9ef;
                --ffe-color-component-button-primary-border-hover: #cfe2f2;
                --ffe-color-component-button-primary-border-pressed: #d7e7f4;
                --ffe-color-component-button-primary-fill-default: #f7fafd;
                --ffe-color-component-button-primary-fill-hover: #d7e7f4;
                --ffe-color-component-button-primary-fill-pressed: #c3d9ef;
                --ffe-color-component-button-primary-foreground-default: #08235e;
                --ffe-color-component-button-primary-foreground-hover: #08235e;
                --ffe-color-component-button-secondary-border-default: #fff;
                --ffe-color-component-button-secondary-border-hover: #fff;
                --ffe-color-component-button-secondary-border-pressed: #fff;
                --ffe-color-component-button-secondary-fill-default: rgba(255, 255, 255, 0);
                --ffe-color-component-button-secondary-fill-hover: #1566b2;
                --ffe-color-component-button-secondary-fill-pressed: #2975c2;
                --ffe-color-component-button-secondary-foreground-default: #fff;
                --ffe-color-component-button-secondary-foreground-hover: #fff;
                --ffe-color-component-button-tertiary-fill-default: rgba(255, 255, 255, 0);
                --ffe-color-component-button-tertiary-fill-hover: #1566b2;
                --ffe-color-component-button-tertiary-fill-pressed: #2975c2;
                --ffe-color-component-button-tertiary-foreground-default: #fff;
                --ffe-color-component-button-tertiary-foreground-hover: #fff;
                --ffe-color-component-logo-name: #fff;
                --ffe-color-component-logo-number1: #fff;
                --ffe-color-component-logo-circle-dark-red: #af0000;
                --ffe-color-component-logo-circle-light-red: #e60000;
                --ffe-color-border-primary-default: rgba(255, 255, 255, 0.2);
                --ffe-color-border-primary-default-hover: rgba(255, 255, 255, 0.25);
                --ffe-color-border-primary-default-pressed: rgba(255, 255, 255, 0.3);
                --ffe-color-border-primary-subtle: rgba(255, 255, 255, 0.075);
                --ffe-color-border-primary-subtle-hover: rgba(255, 255, 255, 0.1);
                --ffe-color-border-primary-subtle-pressed: rgba(255, 255, 255, 0.15);
                --ffe-color-border-primary-emphasis: #c3d9ef;
                --ffe-color-border-feedback-info: #7eb5d2;
                --ffe-color-border-feedback-success: #6abe97;
                --ffe-color-border-feedback-warning: #ea910b;
                --ffe-color-border-feedback-critical: #ff5e5c;
                --ffe-color-border-feedback-tip: #b4aecb;
                --ffe-color-border-interactive-focus: #f6ac3c;
                --ffe-color-border-interactive-selected: #c3d9ef;
            }
            :root {
                --ffe-farge-fjell: #002776;
                --ffe-farge-fjell-70: #4d689f;
                --ffe-farge-fjell-30: #b3bed6;
                --ffe-farge-vann: #005aa4;
                --ffe-farge-vann-70: #4d8cbf;
                --ffe-farge-vann-30: #b3cee4;
                --ffe-farge-sand: #f8e9dd;
                --ffe-farge-sand-70: #faf0e7;
                --ffe-farge-sand-30: #fdf8f5;
                --ffe-farge-frost: #7eb5d2;
                --ffe-farge-frost-70: #a5cbe0;
                --ffe-farge-frost-30: #d8e9f2;
                --ffe-farge-syrin: #d3d3ea;
                --ffe-farge-syrin-70: #e0e0f0;
                --ffe-farge-syrin-30: #f2f2f9;
                --ffe-farge-myrull: #fae4e0;
                --ffe-farge-myrull-70: #fcece9;
                --ffe-farge-myrull-30: #fef7f6;
                --ffe-farge-villblomst: #ee8d9c;
                --ffe-farge-villblomst-70: #f3afba;
                --ffe-farge-villblomst-30: #fadde1;
                --ffe-farge-nordlys: #33af85;
                --ffe-farge-nordlys-70: #70c7aa;
                --ffe-farge-nordlys-30: #c2e7da;
                --ffe-farge-lyng: #873953;
                --ffe-farge-lyng-70: #ab7487;
                --ffe-farge-lyng-30: #dbc4cb;
                --ffe-farge-baer: #db3335;
                --ffe-farge-baer-70: #e67072;
                --ffe-farge-baer-30: #f4c2c2;
                --ffe-farge-skog: #00754e;
                --ffe-farge-skog-70: #4d9e83;
                --ffe-farge-skog-30: #b3d6ca;
                --ffe-farge-multe: #f8b181;
                --ffe-farge-multe-70: #fac8a7;
                --ffe-farge-multe-30: #fde8d9;
                --ffe-farge-sol: #dc8000;
                --ffe-farge-sol-70: #e7a64d;
                --ffe-farge-sol-30: #f5d9b3;
                --ffe-farge-natt: #001032;
                --ffe-farge-svart: #020a0a;
                --ffe-farge-koksgraa: #323232;
                --ffe-farge-moerkgraa: #676767;
                --ffe-farge-graa: #adadad;
                --ffe-farge-lysgraa: #d8d8d8;
                --ffe-farge-moerkvarmgraa: #848383;
                --ffe-farge-varmgraa: #9b9797;
                --ffe-farge-lysvarmgraa: #d7d2cb;
                --ffe-farge-hvit: #fff;
                --ffe-fontsize-body-text: 1rem;
                --ffe-fontsize-small-text: 0.875rem;
                --ffe-fontsize-micro-text: 0.75rem;
                --ffe-fontsize-lead-paragraph: 1.125rem;
                --ffe-fontsize-sub-lead-paragraph: 1.063rem;
                --ffe-fontsize-h1: 1.75rem;
                --ffe-fontsize-h2: 1.5rem;
                --ffe-fontsize-h3: 1.25rem;
                --ffe-fontsize-h4: 1.125rem;
                --ffe-fontsize-h5: 1.0625rem;
                --ffe-fontsize-h6: 1rem;
                --ffe-fontsize-form-input: 1rem;
                --ffe-fontsize-form-dropdown: 1rem;
                --ffe-fontsize-button: 1rem;
                --ffe-fontsize-button-sm: 0.875rem;
                --breakpoint-sm: 480px;
                --breakpoint-md: 768px;
                --breakpoint-lg: 1024px;
                --breakpoint-xl: 1280px;
                --app-width: 1280px;
                --app-width-min: 320px;
                --app-margin: 20px;
                --ffe-ease-in-out-back: cubic-bezier(0.46, -0.265, 0.48, 1.38);
                --ffe-ease: cubic-bezier(0.25, 0.1, 0.25, 1);
                --ffe-transition-duration: 0.2s;
                --ffe-spacing: 8px;
                --ffe-spacing-2xs: 4px;
                --ffe-spacing-xs: 8px;
                --ffe-spacing-sm: 16px;
                --ffe-spacing-md: 24px;
                --ffe-spacing-lg: 32px;
                --ffe-spacing-xl: 40px;
                --ffe-spacing-2xl: 48px;
                --ffe-spacing-3xl: 64px;
                --ffe-spacing-4xl: 80px;
                --ffe-spacing-5xl: 160px;
                --ffe-g-primary-color: var(--ffe-color-fill-primary-default);
                --ffe-g-secondary-color: var(--ffe-color-foreground-emphasis);
                --ffe-g-error-color: var(--ffe-color-fill-feedback-critical);
                --ffe-g-border-color: var(--ffe-color-border-primary-default);
                --ffe-g-font: "SpareBank1-regular", arial, sans-serif;
                --ffe-g-font-heading: "SpareBank1-title-medium", arial, sans-serif;
                --ffe-g-font-heading-small: "SpareBank1-medium", arial, sans-serif;
                --ffe-g-font-strong: "SpareBank1-medium", arial, sans-serif;
                --ffe-g-font-italic: "SpareBank1-italic", arial, sans-serif;
                --ffe-g-text-color: var(--ffe-color-foreground-default);
                --ffe-g-lead-color: var(--ffe-color-border-primary-subtle);
                --ffe-g-heading-color: var(--ffe-color-border-primary-emphasis);
                --ffe-g-link-color: var(--ffe-color-foreground-interactive-link);
                --ffe-g-link-color-hover: var(--ffe-color-foreground-interactive-link-hover);
                --ffe-g-link-color-visited: var(--ffe-color-foreground-interactive-link-pressed);
                --ffe-g-link-icon-color-hover: var(--ffe-color-foreground-interactive-link-hover);
                --ffe-g-link-icon-color-focus: var(--ffe-color-foreground-interactive-link-pressed);
            }
            :host {
                --ffe-farge-fjell: #002776;
                --ffe-farge-fjell-70: #4d689f;
                --ffe-farge-fjell-30: #b3bed6;
                --ffe-farge-vann: #005aa4;
                --ffe-farge-vann-70: #4d8cbf;
                --ffe-farge-vann-30: #b3cee4;
                --ffe-farge-sand: #f8e9dd;
                --ffe-farge-sand-70: #faf0e7;
                --ffe-farge-sand-30: #fdf8f5;
                --ffe-farge-frost: #7eb5d2;
                --ffe-farge-frost-70: #a5cbe0;
                --ffe-farge-frost-30: #d8e9f2;
                --ffe-farge-syrin: #d3d3ea;
                --ffe-farge-syrin-70: #e0e0f0;
                --ffe-farge-syrin-30: #f2f2f9;
                --ffe-farge-myrull: #fae4e0;
                --ffe-farge-myrull-70: #fcece9;
                --ffe-farge-myrull-30: #fef7f6;
                --ffe-farge-villblomst: #ee8d9c;
                --ffe-farge-villblomst-70: #f3afba;
                --ffe-farge-villblomst-30: #fadde1;
                --ffe-farge-nordlys: #33af85;
                --ffe-farge-nordlys-70: #70c7aa;
                --ffe-farge-nordlys-30: #c2e7da;
                --ffe-farge-lyng: #873953;
                --ffe-farge-lyng-70: #ab7487;
                --ffe-farge-lyng-30: #dbc4cb;
                --ffe-farge-baer: #db3335;
                --ffe-farge-baer-70: #e67072;
                --ffe-farge-baer-30: #f4c2c2;
                --ffe-farge-skog: #00754e;
                --ffe-farge-skog-70: #4d9e83;
                --ffe-farge-skog-30: #b3d6ca;
                --ffe-farge-multe: #f8b181;
                --ffe-farge-multe-70: #fac8a7;
                --ffe-farge-multe-30: #fde8d9;
                --ffe-farge-sol: #dc8000;
                --ffe-farge-sol-70: #e7a64d;
                --ffe-farge-sol-30: #f5d9b3;
                --ffe-farge-natt: #001032;
                --ffe-farge-svart: #020a0a;
                --ffe-farge-koksgraa: #323232;
                --ffe-farge-moerkgraa: #676767;
                --ffe-farge-graa: #adadad;
                --ffe-farge-lysgraa: #d8d8d8;
                --ffe-farge-moerkvarmgraa: #848383;
                --ffe-farge-varmgraa: #9b9797;
                --ffe-farge-lysvarmgraa: #d7d2cb;
                --ffe-farge-hvit: #fff;
                --ffe-fontsize-body-text: 1rem;
                --ffe-fontsize-small-text: 0.875rem;
                --ffe-fontsize-micro-text: 0.75rem;
                --ffe-fontsize-lead-paragraph: 1.125rem;
                --ffe-fontsize-sub-lead-paragraph: 1.063rem;
                --ffe-fontsize-h1: 1.75rem;
                --ffe-fontsize-h2: 1.5rem;
                --ffe-fontsize-h3: 1.25rem;
                --ffe-fontsize-h4: 1.125rem;
                --ffe-fontsize-h5: 1.0625rem;
                --ffe-fontsize-h6: 1rem;
                --ffe-fontsize-form-input: 1rem;
                --ffe-fontsize-form-dropdown: 1rem;
                --ffe-fontsize-button: 1rem;
                --ffe-fontsize-button-sm: 0.875rem;
                --breakpoint-sm: 480px;
                --breakpoint-md: 768px;
                --breakpoint-lg: 1024px;
                --breakpoint-xl: 1280px;
                --app-width: 1280px;
                --app-width-min: 320px;
                --app-margin: 20px;
                --ffe-ease-in-out-back: cubic-bezier(0.46, -0.265, 0.48, 1.38);
                --ffe-ease: cubic-bezier(0.25, 0.1, 0.25, 1);
                --ffe-transition-duration: 0.2s;
                --ffe-spacing: 8px;
                --ffe-spacing-2xs: 4px;
                --ffe-spacing-xs: 8px;
                --ffe-spacing-sm: 16px;
                --ffe-spacing-md: 24px;
                --ffe-spacing-lg: 32px;
                --ffe-spacing-xl: 40px;
                --ffe-spacing-2xl: 48px;
                --ffe-spacing-3xl: 64px;
                --ffe-spacing-4xl: 80px;
                --ffe-spacing-5xl: 160px;
                --ffe-g-primary-color: var(--ffe-color-fill-primary-default);
                --ffe-g-secondary-color: var(--ffe-color-foreground-emphasis);
                --ffe-g-error-color: var(--ffe-color-fill-feedback-critical);
                --ffe-g-border-color: var(--ffe-color-border-primary-default);
                --ffe-g-font: "SpareBank1-regular", arial, sans-serif;
                --ffe-g-font-heading: "SpareBank1-title-medium", arial, sans-serif;
                --ffe-g-font-heading-small: "SpareBank1-medium", arial, sans-serif;
                --ffe-g-font-strong: "SpareBank1-medium", arial, sans-serif;
                --ffe-g-font-italic: "SpareBank1-italic", arial, sans-serif;
                --ffe-g-text-color: var(--ffe-color-foreground-default);
                --ffe-g-lead-color: var(--ffe-color-border-primary-subtle);
                --ffe-g-heading-color: var(--ffe-color-border-primary-emphasis);
                --ffe-g-link-color: var(--ffe-color-foreground-interactive-link);
                --ffe-g-link-color-hover: var(--ffe-color-foreground-interactive-link-hover);
                --ffe-g-link-color-visited: var(--ffe-color-foreground-interactive-link-pressed);
                --ffe-g-link-icon-color-hover: var(--ffe-color-foreground-interactive-link-hover);
                --ffe-g-link-icon-color-focus: var(--ffe-color-foreground-interactive-link-pressed);
            }
            @media (min-width: 480px) {
                :root {
                    --ffe-fontsize-lead-paragraph: 1.5rem;
                    --ffe-fontsize-sub-lead-paragraph: 1.125rem;
                    --ffe-fontsize-h1: 2.5rem;
                    --ffe-fontsize-h2: 2rem;
                    --ffe-fontsize-h3: 1.688rem;
                    --ffe-fontsize-h4: 1.375rem;
                    --ffe-fontsize-h5: 1.125rem;
                }
                :host {
                    --ffe-fontsize-lead-paragraph: 1.5rem;
                    --ffe-fontsize-sub-lead-paragraph: 1.125rem;
                    --ffe-fontsize-h1: 2.5rem;
                    --ffe-fontsize-h2: 2rem;
                    --ffe-fontsize-h3: 1.688rem;
                    --ffe-fontsize-h4: 1.375rem;
                    --ffe-fontsize-h5: 1.125rem;
                }
            }
            @media (min-width: 1024px) {
                :root {
                    --ffe-fontsize-h1: 2.875rem;
                    --ffe-fontsize-h2: 2.25rem;
                    --ffe-fontsize-h3: 1.75rem;
                }
                :host {
                    --ffe-fontsize-h1: 2.875rem;
                    --ffe-fontsize-h2: 2.25rem;
                    --ffe-fontsize-h3: 1.75rem;
                }
            }
            .ffe-h1 {
                line-height: 2.25rem;
                font-size: var(--ffe-fontsize-h1);
            }
            .ffe-h2 {
                line-height: 1.75rem;
                font-size: var(--ffe-fontsize-h2);
            }
            .ffe-h3 {
                line-height: 1.5rem;
                font-size: var(--ffe-fontsize-h3);
            }
            .ffe-h4 {
                line-height: 1.5rem;
                font-size: var(--ffe-fontsize-h4);
            }
            .ffe-h5 {
                line-height: 1.25rem;
                font-size: var(--ffe-fontsize-h5);
            }
            .ffe-h6 {
                line-height: 1.25rem;
                font-size: var(--ffe-fontsize-h6);
            }
            .ffe-small-text,
            .ffe-micro-text,
            .ffe-radio-button__tooltip-text.ffe-tooltip__text {
                color: var(--ffe-color-foreground-default);
                font-family: var(--ffe-g-font);
                font-variant-numeric: tabular-nums;
                margin: 0;
                font-weight: 400;
                line-height: 1.25rem;
            }
            .ffe-small-text,
            .ffe-radio-button__tooltip-text.ffe-tooltip__text {
                font-size: var(--ffe-fontsize-small-text);
            }
            .ffe-small-text--underline {
                border-bottom: var(--ffe-g-border-width) solid currentColor;
            }
            .ffe-micro-text {
                font-size: var(--ffe-fontsize-micro-text);
            }
            .ffe-micro-text--strong {
                font-family: var(--ffe-g-font-strong);
            }
            .ffe-h1,
            .ffe-h2,
            .ffe-h3,
            .ffe-h4,
            .ffe-h5,
            .ffe-h6 {
                color: var(--ffe-color-foreground-emphasis);
                margin-bottom: var(--ffe-spacing-xs);
                text-wrap: balance;
                overflow-wrap: anywhere;
                margin-top: 0;
                font-weight: 400;
            }
            .ffe-h1--error,
            .ffe-h2--error,
            .ffe-h3--error,
            .ffe-h4--error,
            .ffe-h5--error,
            .ffe-h6--error {
                color: var(--ffe-color-foreground-feedback-critical);
            }
            .ffe-h1--inline,
            .ffe-h2--inline,
            .ffe-h3--inline,
            .ffe-h4--inline,
            .ffe-h5--inline,
            .ffe-h6--inline {
                display: inline-block;
            }
            .ffe-h1--no-margin,
            .ffe-h2--no-margin,
            .ffe-h3--no-margin,
            .ffe-h4--no-margin,
            .ffe-h5--no-margin,
            .ffe-h6--no-margin {
                margin: 0;
            }
            .ffe-h1--with-border,
            .ffe-h2--with-border,
            .ffe-h3--with-border,
            .ffe-h4--with-border,
            .ffe-h5--with-border,
            .ffe-h6--with-border {
                border-bottom: var(--ffe-g-border-width) solid var(--ffe-color-foreground-emphasis);
                padding-bottom: var(--ffe-spacing-xs);
            }
            .ffe-h1--no-underline,
            .ffe-h2--no-underline,
            .ffe-h3--no-underline,
            .ffe-h4--no-underline,
            .ffe-h5--no-underline,
            .ffe-h6--no-underline {
                text-decoration: none;
            }
            .ffe-h1--text-center,
            .ffe-h2--text-center,
            .ffe-h3--text-center,
            .ffe-h4--text-center,
            .ffe-h5--text-center,
            .ffe-h6--text-center {
                text-align: center;
            }
            .ffe-h1,
            .ffe-h2 {
                font-family: var(--ffe-g-font-heading);
            }
            .ffe-h3,
            .ffe-h4,
            .ffe-h5,
            .ffe-h6 {
                font-family: var(--ffe-g-font-heading-small);
                font-variant-numeric: tabular-nums;
            }
            .ffe-body-text,
            body {
                color: var(--ffe-color-foreground-default);
                font-family: var(--ffe-g-font);
                font-variant-numeric: tabular-nums;
                line-height: 1.5rem;
                font-size: var(--ffe-fontsize-body-text);
            }
            .ffe-body-paragraph {
                font-family: var(--ffe-g-font);
                font-variant-numeric: tabular-nums;
                color: var(--ffe-color-foreground-default);
                text-wrap: pretty;
                margin-top: 0;
                margin-bottom: 1em;
                line-height: 1.5rem;
            }
            .ffe-body-paragraph--text-center {
                text-align: center;
            }
            .ffe-body-paragraph--text-left {
                text-align: left;
            }
            .ffe-lead-paragraph,
            .ffe-sub-lead-paragraph {
                font-family: var(--ffe-g-font);
                font-variant-numeric: tabular-nums;
                text-wrap: pretty;
                margin-top: 0;
                margin-bottom: 1em;
            }
            .ffe-lead-paragraph {
                color: var(--ffe-color-foreground-emphasis);
                line-height: 1.5rem;
                font-size: var(--ffe-fontsize-lead-paragraph);
            }
            .ffe-sub-lead-paragraph {
                color: var(--ffe-color-foreground-default);
                line-height: 1.5rem;
                font-size: var(--ffe-fontsize-sub-lead-paragraph);
            }
            .ffe-body-paragraph--no-margin {
                margin: 0;
            }
            .ffe-link-text {
                border-bottom: var(--ffe-g-border-width) solid var(--ffe-color-foreground-interactive-link);
                color: var(--ffe-color-foreground-interactive-link);
                cursor: pointer;
                word-wrap: break-all;
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                line-height: 1em;
                text-decoration: none;
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-link-text:hover {
                    border-bottom-color: var(--ffe-color-foreground-interactive-link-hover);
                    color: var(--ffe-color-foreground-interactive-link-hover);
                    text-decoration: none;
                }
            }
            .ffe-link-text--no-underline {
                border-bottom: none;
            }
            .ffe-link-text:active {
                color: var(--ffe-color-foreground-interactive-link-pressed);
            }
            .ffe-link-text:focus-visible {
                color: var(--ffe-color-foreground-interactive-link-pressed);
                box-shadow: 0 0 0 2px var(--ffe-color-border-interactive-focus);
                border-bottom-color: transparent;
                border-radius: 1px;
                outline: none;
            }
            .ffe-link-icon {
                color: var(--ffe-color-foreground-interactive-link);
                padding: var(--ffe-spacing-2xs);
                border: 2px solid transparent;
                border-radius: 1.5rem;
                outline: 0;
                display: inline-flex;
            }
            .ffe-link-icon:-webkit-any(button) {
                cursor: pointer;
                background: 0 0;
            }
            .ffe-link-icon:-moz-any(button) {
                cursor: pointer;
                background: 0 0;
            }
            .ffe-link-icon:is(button) {
                cursor: pointer;
                background: 0 0;
            }
            .ffe-link-icon .ffe-icons {
                color: currentColor;
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-link-icon:hover {
                    color: var(--ffe-color-foreground-interactive-link-hover);
                }
            }
            .ffe-link-icon:focus {
                box-shadow: 0 0 0 2px var(--ffe-color-foreground-interactive-link-pressed);
            }
            .ffe-divider-line {
                border: none;
                border-bottom: var(--ffe-g-border-width) solid var(--ffe-color-border-primary-default);
                width: 100%;
                padding-top: 1px;
                padding-bottom: 1px;
            }
            .ffe-strong-text,
            .ffe-context-message-content__header {
                font-family: var(--ffe-g-font-strong);
                color: var(--ffe-color-foreground-default);
                font-variant-numeric: tabular-nums;
                font-weight: 400;
            }
            .ffe-em-text {
                font-family: var(--ffe-g-font-italic);
                font-variant-numeric: tabular-nums;
                color: var(--ffe-color-foreground-default);
                font-style: normal;
                font-weight: 400;
            }
            .ffe-pre-text {
                background-color: var(--ffe-color-background-subtle);
                color: var(--ffe-color-foreground-default);
                text-align: left;
                margin: 0;
                font-family: consolas, menlo, monaco, monospace;
            }
            .ffe-inline-separator {
                margin: 0 4px;
            }
            @media (min-width: 480px) {
                .ffe-h1 {
                    line-height: 3.5rem;
                }
                .ffe-h2 {
                    line-height: 2.75rem;
                }
                .ffe-h3 {
                    line-height: 2.25rem;
                }
                .ffe-h4 {
                    line-height: 1.75rem;
                }
                .ffe-h5 {
                    line-height: 1.5rem;
                }
                .ffe-h6 {
                    line-height: 1.25rem;
                }
                .ffe-h1,
                .ffe-h2,
                .ffe-h3,
                .ffe-h4,
                .ffe-h5,
                .ffe-h6 {
                    margin-bottom: var(--ffe-spacing-sm);
                }
                .ffe-h1--no-margin,
                .ffe-h2--no-margin,
                .ffe-h3--no-margin,
                .ffe-h4--no-margin,
                .ffe-h5--no-margin,
                .ffe-h6--no-margin {
                    margin: 0;
                }
                .ffe-lead-paragraph {
                    line-height: 2rem;
                }
                .ffe-sub-lead-paragraph {
                    line-height: 1.75rem;
                }
                .ffe-body-text,
                .ffe-body-paragraph,
                body {
                    line-height: 1.5rem;
                }
                .ffe-small-text,
                .ffe-radio-button__tooltip-text.ffe-tooltip__text,
                .ffe-micro-text {
                    line-height: 1.25rem;
                }
            }
            @media (min-width: 1024px) {
                .ffe-h1,
                .ffe-h2,
                .ffe-h3,
                .ffe-h4,
                .ffe-h5,
                .ffe-h6 {
                    margin-bottom: var(--ffe-spacing-md);
                }
                .ffe-h1--no-margin,
                .ffe-h2--no-margin,
                .ffe-h3--no-margin,
                .ffe-h4--no-margin,
                .ffe-h5--no-margin,
                .ffe-h6--no-margin {
                    margin: 0;
                }
            }
            .ffe-body-text,
            .ffe-body-paragraph,
            .ffe-lead-paragraph,
            .ffe-sub-lead-paragraph,
            .ffe-link-text,
            .ffe-strong-text,
            .ffe-em-text,
            .ffe-pre-text,
            .ffe-small-text,
            .ffe-micro-text,
            .ffe-context-message-content__header,
            .ffe-radio-button__tooltip-text.ffe-tooltip__text,
            body {
                overflow-wrap: anywhere;
            }
            .ffe-body {
                background-color: var(--ffe-color-background-default);
                color: var(--ffe-color-foreground-default);
                font-family: var(--ffe-g-font);
                font-variant-numeric: tabular-nums;
            }
            .ffe-body strong {
                font-family: var(--ffe-g-font-strong);
                font-weight: 400;
            }
            .ffe-body small {
                font-size: var(--ffe-fontsize-small-text);
            }
            .ffe-body em {
                font-family: var(--ffe-g-font-italic);
                font-style: normal;
                font-weight: 400;
            }
            .ffe-body pre {
                font-family: consolas, menlo, monaco, monospace;
            }
            .ffe-screenreader-only {
                clip: rect(0, 0, 0, 0);
                border: 0;
                width: 1px;
                height: 1px;
                margin: -1px;
                padding: 0;
                overflow: hidden;
                position: absolute !important;
            }
            :root {
                --ffe-g-border-radius-sm: 4px;
                --ffe-g-border-radius: 8px;
                --ffe-g-border-radius-lg: 16px;
                --ffe-g-border-width: 1px;
                --ffe-g-border-focus-box-shadow: 0 0 0 1px;
                --ffe-g-outline-width: 2px;
                --ffe-g-outline-offset: 3px;
                --ffe-g-outline-border-radius: 4px;
            }
            :host {
                --ffe-g-border-radius-sm: 4px;
                --ffe-g-border-radius: 8px;
                --ffe-g-border-radius-lg: 16px;
                --ffe-g-border-width: 1px;
                --ffe-g-border-focus-box-shadow: 0 0 0 1px;
                --ffe-g-outline-width: 2px;
                --ffe-g-outline-offset: 3px;
                --ffe-g-outline-border-radius: 4px;
            }
            .ffe-wave {
                width: 100%;
                position: relative;
            }
            .ffe-wave__content {
                z-index: 1;
                width: 100%;
                position: absolute;
            }
            .ffe-wave__wave {
                min-height: 60px;
                -webkit-mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 479.9 60' style='enable-background:new 0 0 479.9 148' xml:space='preserve'%3E%3Cpath d='M0 530V0c60.7 0 91.6 13.8 121.4 27.1 30.4 13.6 59.1 26.4 118.1 26.4s87.7-12.8 118.1-26.4C387.4 13.8 418.2 0 478.9 0s91.6 13.8 121.4 27.1c30.4 13.6 59.1 26.4 118.1 26.4s87.7-12.8 118.1-26.4C866.3 13.8 897.1 0 957.8 0s91.6 13.8 121.4 27.1c30.4 13.6 59.1 26.4 118.1 26.4s87.7-12.8 118.1-26.4C1345.2 13.8 1376 0 1436.7 0c60.7 0 91.6 13.8 121.4 27.1 30.4 13.6 59.1 26.4 118.1 26.4s87.7-12.8 118.1-26.4C1824.1 13.8 1854.9 0 1915.7 0v530'/%3E%3C/svg%3E");
                mask-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 479.9 60' style='enable-background:new 0 0 479.9 148' xml:space='preserve'%3E%3Cpath d='M0 530V0c60.7 0 91.6 13.8 121.4 27.1 30.4 13.6 59.1 26.4 118.1 26.4s87.7-12.8 118.1-26.4C387.4 13.8 418.2 0 478.9 0s91.6 13.8 121.4 27.1c30.4 13.6 59.1 26.4 118.1 26.4s87.7-12.8 118.1-26.4C866.3 13.8 897.1 0 957.8 0s91.6 13.8 121.4 27.1c30.4 13.6 59.1 26.4 118.1 26.4s87.7-12.8 118.1-26.4C1345.2 13.8 1376 0 1436.7 0c60.7 0 91.6 13.8 121.4 27.1 30.4 13.6 59.1 26.4 118.1 26.4s87.7-12.8 118.1-26.4C1824.1 13.8 1854.9 0 1915.7 0v530'/%3E%3C/svg%3E");
                -webkit-mask-size: 480px;
                mask-size: 480px;
                -webkit-mask-repeat: repeat-x;
                mask-repeat: repeat-x;
            }
            @media (min-width: 480px) {
                .ffe-wave__wave {
                    min-height: 119px;
                    -webkit-mask-position: 812px;
                    mask-position: 812px;
                    -webkit-mask-size: 950px;
                    mask-size: 950px;
                }
            }
            @media (min-width: 1024px) {
                .ffe-wave__wave {
                    min-height: 250px;
                    -webkit-mask-position: 1931px;
                    mask-position: 1931px;
                    -webkit-mask-size: 2004px;
                    mask-size: 2004px;
                }
            }
            .ffe-wave__wave--flip {
                rotate: 180deg;
            }
            .ffe-wave--bg-hvit {
                background-color: var(--ffe-farge-hvit);
            }
            .ffe-wave--bg-frost-30 {
                background-color: #d8e9f2;
            }
            .ffe-wave--bg-sand-30 {
                background-color: #fdf8f5;
            }
            .ffe-wave--bg-sand-70 {
                background-color: #faf0e7;
            }
            .ffe-wave--bg-syrin-30 {
                background-color: #f2f2f9;
            }
            .ffe-wave--bg-syrin-70 {
                background-color: #e0e0f0;
            }
            .ffe-wave--bg-vann {
                background-color: #005aa4;
            }
            .ffe-wave--bg-vann-30 {
                background-color: #b3cee4;
            }
            .ffe-wave--bg-fjell {
                background-color: #002776;
            }
            @media (prefers-color-scheme: dark) {
                .regard-color-scheme-preference .ffe-wave--dm-bg-svart {
                    background-color: var(--ffe-farge-svart);
                }
                .regard-color-scheme-preference .ffe-wave--dm-bg-natt {
                    background-color: #001032;
                }
            }
            .ffe-input-field {
                height: 2.8125rem;
                padding: var(--ffe-spacing-2xs) var(--ffe-spacing-sm);
                font-family: var(--ffe-g-font);
                font-variant-numeric: tabular-nums;
                background-color: var(--ffe-color-surface-primary-default);
                color: var(--ffe-color-foreground-default);
                border-radius: var(--ffe-g-border-radius);
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-primary-default);
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                outline: var(--ffe-g-outline-width) solid transparent;
                outline-offset: var(--ffe-g-outline-offset);
                width: 100%;
                font-size: var(--ffe-fontsize-form-input);
                display: block;
            }
            .ffe-input-field[type="date"] {
                padding-left: var(--ffe-spacing-xs);
                display: flex;
            }
            .ffe-input-field::-webkit-date-and-time-value {
                text-align: left;
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-input-field:hover {
                    border-color: var(--ffe-color-border-primary-default-hover);
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-hover);
                }
            }
            .ffe-input-field:focus {
                border: var(--ffe-g-border-width) solid var(--ffe-color-component-form-input-border-active);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-component-form-input-border-active);
                outline-color: var(--ffe-color-border-interactive-focus);
            }
            .ffe-input-field--inline {
                width: auto;
                display: inline-block;
            }
            .ffe-input-field--text-right-align {
                text-align: right;
            }
            .ffe-input-field--condensed {
                height: 2.25rem;
            }
            .ffe-input-field--text-like.ffe-input-field {
                border: none;
                border-bottom: 2px solid var(--ffe-color-border-primary-default);
                box-shadow: none;
                text-align: center;
                height: 2em;
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                background-color: transparent;
                border-radius: 2px;
                padding: 0;
                display: inline-block;
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-input-field--text-like.ffe-input-field:hover {
                    border-color: var(--ffe-color-border-primary-default-hover);
                    background-color: var(--ffe-color-surface-primary-default);
                }
            }
            .ffe-input-field--text-like.ffe-input-field:focus-visible {
                border-color: var(--ffe-color-border-interactive-selected);
            }
            .ffe-input-field--text-like.ffe-input-field[aria-invalid="true"] {
                background: var(--ffe-color-surface-feedback-critical);
                border-bottom: 2px solid var(--ffe-color-border-feedback-critical);
                border-top-style: none;
                border-left-style: none;
                border-right-style: none;
            }
            .ffe-input-field--text-like.ffe-input-field[aria-invalid="true"]:hover,
            .ffe-input-field--text-like.ffe-input-field[aria-invalid="true"]:focus {
                color: var(--ffe-color-foreground-feedback-critical);
                background-color: transparent;
            }
            .ffe-input-field::-ms-clear {
                display: none;
            }
            .ffe-input-field::-webkit-input-placeholder {
                color: var(--ffe-color-foreground-subtle);
                opacity: 1;
            }
            .ffe-input-field::-moz-placeholder {
                color: var(--ffe-color-foreground-subtle);
                opacity: 1;
            }
            .ffe-input-field::-ms-input-placeholder {
                color: var(--ffe-color-foreground-subtle);
                opacity: 1;
            }
            .ffe-input-field::placeholder {
                color: var(--ffe-color-foreground-subtle);
                opacity: 1;
            }
            .ffe-input-field--invalid {
                color: var(--ffe-color-foreground-feedback-critical);
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                background-color: var(--ffe-color-surface-feedback-critical);
            }
            :where(input).ffe-input-field:not(.ffe-input-field--text-like)[aria-invalid="true"] {
                color: var(--ffe-color-foreground-feedback-critical);
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                background-color: var(--ffe-color-surface-feedback-critical);
            }
            .ffe-input-field--invalid:focus {
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
            }
            :where(input).ffe-input-field:not(.ffe-input-field--text-like)[aria-invalid="true"]:focus {
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-input-field--invalid:hover,
                .ffe-input-field--invalid:focus {
                    border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                    background-color: var(--ffe-color-surface-primary-default);
                }
                :where(input).ffe-input-field:not(.ffe-input-field--text-like)[aria-invalid="true"]:hover {
                    border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                    background-color: var(--ffe-color-surface-primary-default);
                }
                :where(input).ffe-input-field:not(.ffe-input-field--text-like)[aria-invalid="true"]:focus {
                    border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                    background-color: var(--ffe-color-surface-primary-default);
                }
            }
            .ffe-textarea {
                width: 100%;
                padding: 12px var(--ffe-spacing-sm);
                font-family: var(--ffe-g-font);
                font-variant-numeric: tabular-nums;
                border-radius: var(--ffe-g-border-radius);
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-primary-default);
                background-color: var(--ffe-color-surface-primary-default);
                color: var(--ffe-color-foreground-default);
                outline: var(--ffe-g-outline-width) solid transparent;
                outline-offset: var(--ffe-g-outline-offset);
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                font-size: var(--ffe-fontsize-form-input);
                display: block;
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-textarea:hover {
                    border-color: var(--ffe-color-border-primary-default-hover);
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-hover);
                }
            }
            .ffe-textarea:focus {
                border: var(--ffe-g-border-width) solid var(--ffe-color-component-form-input-border-active);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-component-form-input-border-active);
                outline-color: var(--ffe-color-border-interactive-focus);
            }
            .ffe-textarea:focus-within {
                border: var(--ffe-g-border-width) solid var(--ffe-color-component-form-input-border-active);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-component-form-input-border-active);
                outline-color: var(--ffe-color-border-interactive-focus);
            }
            .ffe-textarea::-webkit-input-placeholder {
                color: var(--ffe-color-foreground-subtle);
                opacity: 1;
            }
            .ffe-textarea::-moz-placeholder {
                color: var(--ffe-color-foreground-subtle);
                opacity: 1;
            }
            .ffe-textarea::-ms-input-placeholder {
                color: var(--ffe-color-foreground-subtle);
                opacity: 1;
            }
            .ffe-textarea::placeholder {
                color: var(--ffe-color-foreground-subtle);
                opacity: 1;
            }
            .ffe-textarea--invalid {
                color: var(--ffe-color-foreground-feedback-critical);
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                background-color: var(--ffe-color-surface-feedback-critical);
            }
            :where(textarea).ffe-textarea[aria-invalid="true"] {
                color: var(--ffe-color-foreground-feedback-critical);
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                background-color: var(--ffe-color-surface-feedback-critical);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-textarea--invalid:hover,
                .ffe-textarea--invalid:focus {
                    background-color: var(--ffe-color-surface-primary-default);
                }
                :where(textarea).ffe-textarea[aria-invalid="true"]:hover {
                    background-color: var(--ffe-color-surface-primary-default);
                }
                :where(textarea).ffe-textarea[aria-invalid="true"]:focus {
                    background-color: var(--ffe-color-surface-primary-default);
                }
            }
            .ffe-dropdown {
                -webkit-appearance: none;
                -moz-appearance: none;
                -ms-appearance: none;
                appearance: none;
                background-color: var(--ffe-color-component-form-input-fill-default);
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-primary-default);
                border-radius: var(--ffe-g-border-radius);
                color: var(--ffe-color-component-form-input-foreground-default);
                font-family: var(--ffe-g-font);
                font-variant-numeric: tabular-nums;
                height: 2.8125rem;
                padding: 0 var(--ffe-spacing-lg) 0 var(--ffe-spacing-sm);
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                width: 100%;
                font-size: var(--ffe-fontsize-form-dropdown);
                outline: var(--ffe-g-outline-width) solid transparent;
                outline-offset: var(--ffe-g-outline-offset);
                background-image: url("data:image/svg+xml,%3Csvg id='testid' xmlns='http://www.w3.org/2000/svg' fill='%231a 1a 1a' height='24' viewBox='0 -960 960 960' width='24'%3E%3Cpath d='M480-373.539q-7.231 0-13.461-2.308-6.231-2.308-11.846-7.923L274.924-563.539q-8.308-8.307-8.5-20.884-.193-12.577 8.5-21.269 8.692-8.692 21.076-8.692t21.076 8.692L480-442.768l162.924-162.924q8.307-8.307 20.884-8.5 12.576-.192 21.268 8.5 8.693 8.692 8.693 21.077 0 12.384-8.693 21.076L505.307-383.77q-5.615 5.615-11.846 7.923-6.23 2.308-13.461 2.308Z'/%3E%3C/svg%3E%0A");
                background-position: calc(100% - 6px);
                background-repeat: no-repeat;
                background-size: 24px 24px;
                display: block;
            }
            .ffe-dropdown.ffe-default-mode {
                background-image: url("data:image/svg+xml,%3Csvg id='testid' xmlns='http://www.w3.org/2000/svg' fill='%231a 1a 1a' height='24' viewBox='0 -960 960 960' width='24'%3E%3Cpath d='M480-373.539q-7.231 0-13.461-2.308-6.231-2.308-11.846-7.923L274.924-563.539q-8.308-8.307-8.5-20.884-.193-12.577 8.5-21.269 8.692-8.692 21.076-8.692t21.076 8.692L480-442.768l162.924-162.924q8.307-8.307 20.884-8.5 12.576-.192 21.268 8.5 8.693 8.692 8.693 21.077 0 12.384-8.693 21.076L505.307-383.77q-5.615 5.615-11.846 7.923-6.23 2.308-13.461 2.308Z'/%3E%3C/svg%3E%0A");
            }
            @media (prefers-color-scheme: dark) {
                :where(.regard-color-scheme-preference) .ffe-dropdown {
                    background-image: url("data:image/svg+xml,%3Csvg id='testid' xmlns='http://www.w3.org/2000/svg' fill='%23ffffff' height='24' viewBox='0 -960 960 960' width='24'%3E%3Cpath d='M480-373.539q-7.231 0-13.461-2.308-6.231-2.308-11.846-7.923L274.924-563.539q-8.308-8.307-8.5-20.884-.193-12.577 8.5-21.269 8.692-8.692 21.076-8.692t21.076 8.692L480-442.768l162.924-162.924q8.307-8.307 20.884-8.5 12.576-.192 21.268 8.5 8.693 8.692 8.693 21.077 0 12.384-8.693 21.076L505.307-383.77q-5.615 5.615-11.846 7.923-6.23 2.308-13.461 2.308Z'/%3E%3C/svg%3E%0A");
                }
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-dropdown:hover {
                    border-color: var(--ffe-color-border-primary-default-hover);
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-hover);
                }
            }
            .ffe-dropdown:focus-within {
                outline-color: var(--ffe-color-border-interactive-focus);
            }
            .ffe-dropdown:focus,
            .ffe-dropdown:active {
                border-color: var(--ffe-color-component-form-input-border-active);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-component-form-input-border-active);
            }
            .ffe-dropdown--inline {
                width: auto;
                display: inline-block;
            }
            .ffe-dropdown::-webkit-input-placeholder {
                color: var(--ffe-color-foreground-subtle);
                opacity: 1;
            }
            .ffe-dropdown::-moz-placeholder {
                color: var(--ffe-color-foreground-subtle);
                opacity: 1;
            }
            .ffe-dropdown::-ms-input-placeholder {
                color: var(--ffe-color-foreground-subtle);
                opacity: 1;
            }
            .ffe-dropdown::placeholder {
                color: var(--ffe-color-foreground-subtle);
                opacity: 1;
            }
            .ffe-dropdown[aria-invalid="true"] {
                color: var(--ffe-color-foreground-feedback-critical);
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                background-color: var(--ffe-color-surface-feedback-critical);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-dropdown[aria-invalid="true"]:hover,
                .ffe-dropdown[aria-invalid="true"]:focus {
                    border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                    background-color: var(--ffe-color-surface-primary-default);
                }
            }
            @media (prefers-color-scheme: dark) {
                .regard-color-scheme-preference .ffe-dropdown,
                .regard-color-scheme-preference .ffe-accent-mode:not(.ffe-default-mode) .ffe-dropdown {
                    background-image: url("data:image/svg+xml,%3Csvg id='testid' xmlns='http://www.w3.org/2000/svg' fill='%23ffffff' height='24' viewBox='0 -960 960 960' width='24'%3E%3Cpath d='M480-373.539q-7.231 0-13.461-2.308-6.231-2.308-11.846-7.923L274.924-563.539q-8.308-8.307-8.5-20.884-.193-12.577 8.5-21.269 8.692-8.692 21.076-8.692t21.076 8.692L480-442.768l162.924-162.924q8.307-8.307 20.884-8.5 12.576-.192 21.268 8.5 8.693 8.692 8.693 21.077 0 12.384-8.693 21.076L505.307-383.77q-5.615 5.615-11.846 7.923-6.23 2.308-13.461 2.308Z'/%3E%3C/svg%3E%0A");
                }
            }
            .ffe-checkbox {
                color: var(--ffe-color-foreground-default);
                isolation: isolate;
                grid-column-gap: var(--ffe-spacing-xs);
                cursor: pointer;
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                line-height: 1.5rem;
                font-family: var(--ffe-g-font);
                font-variant-numeric: tabular-nums;
                text-align: left;
                -webkit-tap-highlight-color: rgba(0, 90, 164, 0.15);
                overflow-wrap: anywhere;
                -webkit-hyphens: auto;
                -ms-hyphens: auto;
                hyphens: auto;
                margin: var(--ffe-spacing-xs) 0;
                grid-template-rows: 1.5rem 1fr;
                grid-template-columns: auto 1fr;
                align-items: center;
                padding-left: 0;
                display: grid;
            }
            .ffe-checkbox--no-margin {
                margin-top: 0;
                margin-bottom: 0;
            }
            .ffe-checkbox--inline {
                margin-right: var(--ffe-spacing-sm);
                display: inline-grid;
            }
            .ffe-checkbox--hidden-label {
                margin: 0;
                padding-bottom: 20px;
                padding-left: 20px;
            }
            .ffe-checkbox--hidden-label:before {
                margin-right: 0;
            }
            .ffe-checkbox:before,
            .ffe-checkbox:after {
                content: "";
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                grid-area: 1/1/2/2;
                align-self: center;
                justify-self: center;
            }
            .ffe-checkbox:before {
                background: var(--ffe-color-component-form-input-fill-default);
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-primary-default);
                border-radius: calc(var(--ffe-g-border-radius) / 2);
                width: 20px;
                height: 20px;
            }
            .ffe-checkbox:after {
                border-top: 2px solid transparent;
                border-right: 2px solid transparent;
                width: 6px;
                height: 11px;
                margin-bottom: 2px;
                transform: scaleX(-1) rotate(135deg);
            }
            .ffe-checkbox__content {
                color: var(--ffe-color-foreground-default);
                background: 0 0;
                grid-area: 1/2/-1/3;
            }
            .ffe-hidden-checkbox {
                opacity: 0;
                cursor: pointer;
                width: 0;
                height: 0;
                position: absolute;
            }
            .ffe-hidden-checkbox:where(:checked, :focus, :active, :hover) + .ffe-checkbox:before {
                outline: none;
            }
            .ffe-hidden-checkbox + .ffe-checkbox {
                outline: var(--ffe-g-outline-width) solid transparent;
                outline-offset: var(--ffe-g-outline-offset);
                border-radius: var(--ffe-g-outline-border-radius);
            }
            .ffe-hidden-checkbox:focus-visible + .ffe-checkbox {
                outline-color: var(--ffe-color-border-interactive-focus);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-hidden-checkbox:hover + .ffe-checkbox:before {
                    border-color: var(--ffe-color-border-primary-default-hover);
                    background-color: var(--ffe-color-component-form-input-fill-default-hover);
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-hover);
                }
                .ffe-hidden-checkbox:checked:hover + .ffe-checkbox:before {
                    background-color: var(--ffe-color-fill-primary-selected-hover);
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-interactive-selected);
                }
                .ffe-hidden-checkbox[aria-invalid="true"]:hover + .ffe-checkbox:before {
                    border-color: var(--ffe-color-border-feedback-critical);
                    background-color: var(--ffe-color-surface-feedback-critical);
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                }
            }
            .ffe-hidden-checkbox:focus-visible + .ffe-checkbox:before {
                border: var(--ffe-g-border-width) solid var(--ffe-color-component-form-input-border-active);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-component-form-input-border-active);
            }
            .ffe-hidden-checkbox:checked:focus-visible + .ffe-checkbox:before {
                border: var(--ffe-g-border-width) solid var(--ffe-color-component-form-input-border-active);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-component-form-input-border-active);
            }
            .ffe-hidden-checkbox[aria-invalid="true"]:focus-visible + .ffe-checkbox:before {
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
            }
            .ffe-hidden-checkbox:active + .ffe-checkbox:before {
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
                background: var(--ffe-color-component-form-input-fill-default-pressed);
            }
            .ffe-hidden-checkbox:active:checked + .ffe-checkbox:before {
                border-color: var(--ffe-color-component-form-input-border-active);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-component-form-input-border-active);
                background: var(--ffe-color-fill-primary-selected-pressed);
            }
            .ffe-hidden-checkbox[aria-invalid="true"]:active:checked + .ffe-checkbox:before {
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                background-color: var(--ffe-color-surface-feedback-critical);
            }
            .ffe-hidden-checkbox:checked + .ffe-checkbox:before {
                border-color: var(--ffe-color-border-interactive-selected);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-interactive-selected);
                background-color: var(--ffe-color-fill-primary-selected-default);
            }
            .ffe-hidden-checkbox:checked + .ffe-checkbox:after {
                border-color: var(--ffe-color-foreground-inverse);
            }
            .ffe-hidden-checkbox[aria-invalid="true"] + .ffe-checkbox:before {
                border-color: var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                background: var(--ffe-color-surface-feedback-critical);
            }
            .ffe-hidden-checkbox[aria-invalid="true"]:checked + .ffe-checkbox:after {
                border-color: var(--ffe-color-foreground-critical);
            }
            .ffe-form-label {
                color: var(--ffe-color-foreground-default);
            }
            .ffe-checkbox__description {
                color: var(--ffe-color-foreground-subtle);
                background: 0 0;
            }
            .ffe-checkbox__icon {
                color: var(--ffe-color-foreground-emphasis);
            }
            .ffe-checkbox--indeterminate:before,
            .ffe-checkbox--checked:before {
                border-color: var(--ffe-color-border-interactive-selected);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-interactive-selected);
                background-color: var(--ffe-color-fill-primary-selected-default);
            }
            .ffe-hidden-checkbox:indeterminate + .ffe-checkbox:before {
                border-color: var(--ffe-color-border-interactive-selected);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-interactive-selected);
                background-color: var(--ffe-color-fill-primary-selected-default);
            }
            .ffe-checkbox--indeterminate:after,
            .ffe-checkbox--checked:after {
                border-color: var(--ffe-color-foreground-inverse);
            }
            .ffe-hidden-checkbox:indeterminate + .ffe-checkbox:after {
                border-color: var(--ffe-color-foreground-inverse);
            }
            .ffe-checkbox--indeterminate:after {
                border-top-width: 2px;
                border-right-width: 0;
                width: 10px;
                height: 0;
                margin-bottom: 0;
                transform: none;
            }
            .ffe-hidden-checkbox:indeterminate + .ffe-checkbox:after {
                border-top-width: 2px;
                border-right-width: 0;
                width: 10px;
                height: 0;
                margin-bottom: 0;
                transform: none;
            }
            .ffe-radio-input {
                opacity: 0;
                position: absolute;
            }
            .ffe-radio-button {
                --line-height: 1.5rem;
                --outer-circle-color: var(--ffe-color-border-primary-default);
                --inner-circle-color: var(--ffe-color-fill-primary-selected-default);
                --circle-background: var(--ffe-color-surface-primary-default);
                color: var(--ffe-color-foreground-default);
                isolation: isolate;
                line-height: var(--line-height);
                overflow-wrap: anywhere;
                font-family: var(--ffe-g-font);
                font-variant-numeric: tabular-nums;
                cursor: pointer;
                outline: var(--ffe-g-outline-width) solid transparent;
                outline-offset: var(--ffe-g-outline-offset);
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                text-align: left;
                -webkit-tap-highlight-color: var(--ffe-color-fill-primary-subtle);
                grid-template-rows: var(--line-height) 1fr;
                grid-column-gap: var(--ffe-spacing-xs);
                border-radius: var(--ffe-g-outline-border-radius);
                grid-template-columns: auto 1fr auto;
                align-items: center;
                padding-top: 1px;
                padding-left: 0;
                display: grid;
                position: relative;
            }
            .ffe-radio-button--inline {
                margin-right: var(--ffe-spacing-sm);
                display: inline-grid;
            }
            .ffe-radio-button--with-tooltip {
                margin-bottom: 0;
                display: inline-grid;
            }
            .ffe-radio-button__tooltip-icon {
                vertical-align: top;
                grid-area: 1/3;
                width: 25px;
                margin-top: 0;
                display: inline-block;
                position: relative;
            }
            .ffe-radio-button__tooltip-icon .ffe-tooltip__icon {
                margin: 0;
            }
            .ffe-radio-button__tooltip-text.ffe-tooltip__text {
                margin-left: calc(24px + var(--ffe-spacing-xs));
                margin-top: var(--ffe-spacing-2xs);
                grid-area: 2/1 / auto/span 3;
                margin-bottom: 0;
            }
            .ffe-radio-button:before,
            .ffe-radio-button:after {
                content: "";
                pointer-events: none;
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                border-radius: 50%;
                grid-area: 1/1;
                align-self: center;
                justify-self: center;
                left: 0;
            }
            .ffe-radio-button:before {
                background-color: var(--inner-circle-color);
                aspect-ratio: 1;
                z-index: 1;
                width: 50%;
                transform: scale(0);
            }
            .ffe-radio-button:after {
                background-color: var(--circle-background);
                border: var(--ffe-g-border-width) solid var(--outer-circle-color);
                width: 24px;
                height: 24px;
            }
            :where(.ffe-radio-input) + .ffe-radio-button {
                margin-block: var(--ffe-spacing-xs);
            }
            .ffe-radio-input:where(:checked, :focus, :active, :hover) + .ffe-radio-button:before {
                outline: none;
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-radio-input:hover + .ffe-radio-button {
                    --circle-background: var(--ffe-color-surface-primary-default-hover);
                }
            }
            .ffe-radio-input:checked + .ffe-radio-button {
                --outer-circle-color: var(--ffe-color-fill-primary-selected-default);
                --inner-circle-color: var(--ffe-color-fill-primary-selected-default);
            }
            .ffe-radio-input:checked + .ffe-radio-button:before {
                transform: scale(1);
            }
            .ffe-radio-input:focus + .ffe-radio-button,
            .ffe-radio-input:active + .ffe-radio-button {
                --circle-background: var(--ffe-color-surface-primary-default-pressed);
            }
            .ffe-radio-input:focus-visible + .ffe-radio-button {
                outline-color: var(--ffe-color-border-interactive-focus);
            }
            .ffe-radio-input:disabled + .ffe-radio-button {
                --outer-circle-color: var(--ffe-color-border-primary-subtle);
                --circle-background: var(--ffe-color-surface-primary-default);
                cursor: not-allowed;
                color: var(--ffe-color-foreground-subtle);
            }
            .ffe-radio-input[aria-invalid="true"] + .ffe-radio-button {
                --outer-circle-color: var(--ffe-color-border-feedback-critical);
                --circle-background: var(--ffe-color-surface-feedback-critical);
            }
            .ffe-radio-input[aria-invalid="true"] + .ffe-radio-button:after {
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
            }
            .ffe-radio-input:checked[aria-invalid="true"] + .ffe-radio-button {
                --inner-circle-color: var(--ffe-color-border-feedback-critical);
            }
            .ffe-radio-input__content {
                grid-area: 1/2/-1/3;
            }
            .ffe-radio-switch {
                --radio-switch-border-color: var(--ffe-color-border-primary-default);
                --inner-circle-color: var(--ffe-color-surface-primary-default);
                --radio-switch-background: var(--ffe-color-surface-primary-default);
                color: var(--ffe-color-foreground-default);
                padding: var(--ffe-spacing-xs) var(--ffe-spacing-md) var(--ffe-spacing-xs) var(--ffe-spacing-xs);
                grid-column-gap: var(--ffe-spacing-xs);
                border: var(--ffe-g-border-width) solid var(--radio-switch-border-color);
                text-align: left;
                min-width: 100px;
                font-family: var(--ffe-g-font);
                font-variant-numeric: tabular-nums;
                outline: var(--ffe-g-outline-width) solid transparent;
                outline-offset: var(--ffe-g-outline-offset);
                cursor: pointer;
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                margin-bottom: var(--ffe-spacing-2xs);
                margin-top: var(--ffe-spacing-sm);
                overflow-wrap: anywhere;
                background-color: var(--radio-switch-background);
                border-radius: 48px;
                grid-template-columns: auto 1fr;
                align-items: center;
                justify-items: center;
                line-height: 1.5;
                display: inline-grid;
                position: relative;
            }
            .ffe-radio-switch:before {
                content: "";
                background-color: var(--inner-circle-color);
                border: var(--ffe-g-border-width) solid var(--radio-switch-border-color);
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                pointer-events: none;
                border-radius: 50%;
                width: 24px;
                height: 24px;
                top: 8px;
                left: 12px;
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-radio-switch:hover {
                    --inner-circle-color: var(--ffe-color-surface-primary-default);
                    background-color: var(--ffe-color-surface-primary-default-hover);
                    border-color: var(--ffe-color-border-primary-default-hover);
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-hover);
                }
            }
            .ffe-radio-switch:active {
                background-color: var(--ffe-color-surface-primary-default-pressed);
                border-color: var(--ffe-color-border-primary-default-pressed);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-pressed);
            }
            @media (min-width: 480px) {
                .ffe-radio-switch {
                    margin-bottom: 0;
                }
            }
            .ffe-radio-switch:has(+ input + .ffe-radio-switch) {
                margin-right: var(--ffe-spacing-xs);
            }
            .ffe-radio-switch--condensed {
                height: 38px;
            }
            .ffe-radio-input:where(:checked, :focus, :active, :hover) + .ffe-radio-switch:before {
                outline: none;
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-radio-input:hover + .ffe-radio-switch {
                    --radio-switch-background: var(--ffe-color-surface-primary-default-hover);
                }
            }
            .ffe-radio-input:checked + .ffe-radio-switch {
                --inner-circle-color: var(--ffe-color-fill-primary-default-pressed);
                --radio-switch-background: var(--ffe-color-surface-primary-default);
                --radio-switch-border-color: var(--ffe-color-border-interactive-selected);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--radio-switch-border-color);
            }
            .ffe-radio-input:checked + .ffe-radio-switch:before {
                border: 5px solid var(--ffe-color-surface-primary-default);
                outline: 2px solid var(--ffe-color-border-primary-emphasis);
                background-color: var(--ffe-color-fill-primary-selected-default);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-radio-input:checked + .ffe-radio-switch:hover {
                    background-color: var(--ffe-color-surface-primary-default-hover);
                }
            }
            .ffe-radio-input:checked + .ffe-radio-switch:active {
                background-color: var(--ffe-color-surface-primary-default-pressed);
            }
            .ffe-radio-input:focus-visible + .ffe-radio-switch {
                outline-color: var(--ffe-color-border-interactive-focus);
            }
            .ffe-radio-input:disabled + .ffe-radio-switch {
                --radio-switch-border-color: var(--ffe-color-border-primary-subtle);
                --radio-switch-background: var(--ffe-color-surface-primary-default);
                cursor: not-allowed;
                color: var(--ffe-color-foreground-subtle);
            }
            .ffe-radio-input[aria-invalid="true"] + .ffe-radio-switch {
                --radio-switch-border-color: var(--ffe-color-border-feedback-critical);
                --radio-switch-background: var(--ffe-color-surface-feedback-critical);
                --inner-circle-color: var(--ffe-color-surface-primary-default);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
            }
            .ffe-radio-input[aria-invalid="true"] + .ffe-radio-switch:before {
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-radio-input[aria-invalid="true"] + .ffe-radio-switch:hover {
                    border-color: var(--ffe-color-border-feedback-critical);
                    background-color: var(--ffe-color-surface-feedback-critical);
                }
            }
            .ffe-radio-block {
                --outer-border-color: var(--ffe-color-border-primary-default);
                --block-background: var(--ffe-color-surface-primary-default);
                font-family: var(--ffe-g-font);
                font-variant-numeric: tabular-nums;
                margin-top: var(--ffe-spacing-md);
                width: 100%;
                transition: width var(--ffe-transition-duration) var(--ffe-ease);
                overflow-wrap: anywhere;
            }
            .ffe-radio-block__content,
            .ffe-radio-block__header {
                cursor: pointer;
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
            }
            .ffe-radio-block__content {
                width: 100%;
                margin-right: var(--ffe-spacing-xs);
                color: var(--ffe-color-foreground-default);
                background-color: var(--block-background);
                border: var(--ffe-g-border-width) solid var(--outer-border-color);
                border-radius: var(--ffe-g-border-radius);
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                outline: var(--ffe-g-outline-width) solid transparent;
                outline-offset: var(--ffe-g-outline-offset);
                grid-template-columns: auto 1fr;
                display: inline-grid;
                position: relative;
                overflow: hidden;
            }
            .ffe-radio-block__content:before {
                content: "";
                left: var(--ffe-spacing-sm);
                background-color: var(--ffe-color-surface-primary-default);
                border: var(--ffe-g-border-width) solid var(--outer-border-color);
                pointer-events: none;
                border-radius: 50%;
                grid-area: 1/1/2/2;
                align-self: center;
                justify-self: center;
                width: 20px;
                height: 20px;
                position: absolute;
            }
            .ffe-radio-block__header {
                padding: var(--ffe-spacing-xs) var(--ffe-spacing-2xl) var(--ffe-spacing-xs);
                color: var(--ffe-color-foreground-default);
                background-color: transparent;
                grid-area: 1/2/2/3;
                display: block;
            }
            .ffe-radio-block__wrapper {
                padding: 12px var(--ffe-spacing-sm);
                border-top: var(--ffe-g-border-width) solid var(--outer-border-color);
                cursor: auto;
                color: var(--ffe-color-foreground-default);
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                grid-area: 2/2/3/3;
            }
            .ffe-radio-block__wrapper[aria-hidden="true"] {
                display: none;
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-radio-block:hover {
                    --outer-border-color: var(--ffe-color-border-primary-default-hover);
                }
                .ffe-radio-block:hover .ffe-radio-block__header {
                    background-color: var(--ffe-color-surface-primary-default-hover);
                }
                .ffe-radio-block:hover .ffe-radio-block__content {
                    box-shadow: var(--ffe-g-border-focus-box-shadow) var(--outer-border-color);
                }
                .ffe-radio-block:hover .ffe-radio-block__wrapper {
                    box-shadow: inset 0 1px 0 0 var(--outer-border-color);
                }
            }
            .ffe-radio-block:active .ffe-radio-block__header {
                background-color: var(--ffe-color-surface-primary-default-pressed);
            }
            .ffe-radio-block:active .ffe-radio-block__content {
                --outer-border-color: var(--ffe-color-border-primary-default-pressed);
            }
            .ffe-radio-input:checked + .ffe-radio-block__content {
                --outer-border-color: var(--ffe-color-border-interactive-selected);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--outer-border-color);
            }
            .ffe-radio-input:checked + .ffe-radio-block__content:before {
                background-color: var(--ffe-color-fill-primary-selected-default);
                border: 4px solid var(--block-background);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-interactive-selected);
            }
            .ffe-radio-input:checked + .ffe-radio-block__content .ffe-radio-block__wrapper {
                box-shadow: inset 0 1px 0 0 var(--outer-border-color);
            }
            .ffe-radio-input:focus + .ffe-radio-block__content {
                --outer-border-color: var(--ffe-color-border-interactive-selected);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-interactive-selected);
            }
            .ffe-radio-input:focus + .ffe-radio-block__content .ffe-radio-block__wrapper {
                box-shadow: inset 0 1px 0 0 var(--outer-border-color);
            }
            .ffe-radio-input:focus-visible + .ffe-radio-block__content {
                outline-color: var(--ffe-color-border-interactive-focus);
            }
            .ffe-radio-input:disabled + .ffe-radio-block__content {
                --outer-border-color: var(--ffe-color-border-primary-subtle);
                --block-background: var(--ffe-color-surface-primary-default);
                cursor: not-allowed;
                color: var(--ffe-color-foreground-subtle);
            }
            .ffe-radio-input:disabled + .ffe-radio-block__content .ffe-radio-block__header,
            .ffe-radio-input:disabled + .ffe-radio-block__content .ffe-radio-block__wrapper {
                color: var(--ffe-color-foreground-subtle);
            }
            .ffe-radio-input[aria-invalid="true"] + .ffe-radio-block__content {
                --outer-border-color: var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--outer-border-color);
            }
            .ffe-radio-input[aria-invalid="true"] + .ffe-radio-block__content .ffe-radio-block__wrapper {
                box-shadow: inset 0 1px 0 0 var(--outer-border-color);
            }
            .ffe-radio-input[aria-invalid="true"] + .ffe-radio-block__content .ffe-radio-block__header {
                background-color: var(--ffe-color-component-form-input-fill-error);
                color: var(--ffe-color-component-form-input-foreground-error);
            }
            .ffe-radio-block:has(.ffe-radio-input:checked):hover .ffe-radio-block__content .ffe-radio-block__header {
                background-color: var(--ffe-color-surface-primary-default-hover);
            }
            .ffe-radio-block:has(.ffe-radio-input:checked):hover:has(.ffe-radio-input[aria-invalid="true"])
                .ffe-radio-block__header {
                background-color: var(--ffe-color-component-form-input-fill-error);
            }
            .ffe-radio-block:has(.ffe-radio-input:checked):active {
                --outer-border-color: var(--ffe-color-border-interactive-selected);
            }
            .ffe-radio-block:has(.ffe-radio-input:checked):active .ffe-radio-block__content .ffe-radio-block__header {
                background-color: var(--ffe-color-surface-primary-default-pressed);
            }
            @media (min-width: 480px) {
                .ffe-phone-number__input-group {
                    display: flex;
                }
            }
            .ffe-phone-number__input-group > * {
                margin-top: 0;
            }
            .ffe-phone-number__country-code .ffe-phone-number__input-group {
                display: flex;
            }
            .ffe-phone-number__country-code {
                flex-grow: 1;
                min-width: 110px;
            }
            .ffe-phone-number__country-code label {
                white-space: nowrap;
                margin-right: var(--ffe-spacing-xs);
            }
            @media (max-width: 479px) {
                .ffe-phone-number__country-code {
                    margin-bottom: var(--ffe-spacing-xs);
                }
            }
            .ffe-phone-number__country-code-input {
                border-top-left-radius: 0;
                border-bottom-left-radius: 0;
            }
            @media (min-width: 480px) {
                .ffe-phone-number__country-code-input {
                    max-width: 4rem;
                    margin-right: var(--ffe-spacing-sm);
                }
            }
            .ffe-phone-number__plus {
                padding: 12px var(--ffe-spacing-sm);
                background-color: var(--ffe-color-surface-primary-default);
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-primary-default);
                border-radius: var(--ffe-g-border-radius) 0 0 var(--ffe-g-border-radius);
                transition: border-color var(--ffe-transition-duration) var(--ffe-ease);
                color: var(--ffe-color-foreground-default);
                border-right: 0;
                align-items: center;
                font-weight: 400;
                line-height: 1;
                display: flex;
            }
            .ffe-phone-number__number {
                flex-grow: 10000;
            }
            .ffe-phone-number__number label {
                white-space: nowrap;
            }
            .ffe-phone-number__phone-input:disabled,
            .ffe-phone-number__country-code-input:disabled {
                color: transparent;
            }
            .ffe-text-field {
                padding: var(--ffe-spacing-2xs) var(--ffe-spacing-sm);
                font-family: var(--ffe-g-font);
                font-variant-numeric: tabular-nums;
                color: var(--ffe-color-foreground-default);
                width: 100%;
                height: 100%;
                font-size: var(--ffe-fontsize-form-input);
                background: 0 0;
                border: none;
                display: block;
            }
            .ffe-text-field[type="date"] {
                padding-left: var(--ffe-spacing-xs);
                display: flex;
            }
            .ffe-text-field::-webkit-date-and-time-value {
                text-align: left;
            }
            .ffe-text-field__wrapper {
                background-color: var(--ffe-color-surface-primary-default);
                border-radius: var(--ffe-g-border-radius);
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-primary-default);
                width: 100%;
                height: 2.8125rem;
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                outline: var(--ffe-g-outline-width) solid transparent;
                outline-offset: var(--ffe-g-outline-offset);
                align-items: center;
                margin: 0;
                padding: 0;
                display: flex;
            }
            .ffe-text-field__wrapper:hover {
                border-color: var(--ffe-color-border-primary-default-hover);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-primary-default-hover);
            }
            .ffe-text-field__wrapper--inline {
                width: auto;
                display: inline-flex;
            }
            .ffe-text-field__wrapper:focus-within {
                border: var(--ffe-g-border-width) solid var(--ffe-color-fill-primary-selected-default);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-fill-primary-selected-default);
                outline-color: var(--ffe-color-border-interactive-focus);
            }
            .ffe-text-field:focus {
                border: none;
                outline: none;
            }
            .ffe-text-field:focus-within {
                border: none;
                outline: none;
            }
            .ffe-text-field__suffix,
            .ffe-text-field__prefix {
                color: var(--ffe-color-component-form-input-foreground-subtle);
                white-space: nowrap;
                align-items: center;
                padding: 0;
                display: inline-flex;
            }
            .ffe-text-field__suffix {
                margin: 0 var(--ffe-spacing-xs) 0 0;
            }
            .ffe-text-field__prefix {
                margin: 0 0 0 var(--ffe-spacing-xs);
            }
            .ffe-text-field--text-right-align {
                text-align: right;
            }
            .ffe-text-field::-ms-clear {
                display: none;
            }
            .ffe-text-field::-webkit-input-placeholder {
                color: var(--ffe-color-foreground-subtle);
                opacity: 1;
            }
            .ffe-text-field::-moz-placeholder {
                color: var(--ffe-color-foreground-subtle);
                opacity: 1;
            }
            .ffe-text-field::-ms-input-placeholder {
                color: var(--ffe-color-foreground-subtle);
                opacity: 1;
            }
            .ffe-text-field::placeholder {
                color: var(--ffe-color-foreground-subtle);
                opacity: 1;
            }
            .ffe-text-field--invalid,
            .ffe-text-field[aria-invalid="true"] {
                color: var(--ffe-color-foreground-feedback-critical);
            }
            .ffe-text-field__wrapper:has(.ffe-text-field--invalid) {
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                background-color: var(--ffe-color-surface-feedback-critical);
            }
            .ffe-text-field__wrapper:has([aria-invalid="true"]) {
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                background-color: var(--ffe-color-surface-feedback-critical);
            }
            .ffe-text-field__wrapper:has(.ffe-text-field--invalid):focus {
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                background-color: var(--ffe-color-component-form-input-fill-default);
            }
            .ffe-text-field__wrapper:has([aria-invalid="true"]):focus {
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                background-color: var(--ffe-color-component-form-input-fill-default);
            }
            .ffe-text-field__wrapper:has(.ffe-text-field--invalid):focus-within {
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                background-color: var(--ffe-color-component-form-input-fill-default);
            }
            .ffe-text-field__wrapper:has([aria-invalid="true"]):focus-within {
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                background-color: var(--ffe-color-component-form-input-fill-default);
            }
            .ffe-text-field__wrapper:has(.ffe-text-field--invalid):hover {
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                background-color: var(--ffe-color-component-form-input-fill-default);
            }
            .ffe-text-field__wrapper:has([aria-invalid="true"]):hover {
                border: var(--ffe-g-border-width) solid var(--ffe-color-border-feedback-critical);
                box-shadow: var(--ffe-g-border-focus-box-shadow) var(--ffe-color-border-feedback-critical);
                background-color: var(--ffe-color-component-form-input-fill-default);
            }
            .ffe-toggle-switch__input {
                opacity: 0;
                cursor: pointer;
                position: absolute;
            }
            .ffe-toggle-switch__label {
                cursor: pointer;
                color: var(--ffe-color-foreground-default);
                font-family: var(--ffe-g-font);
                font-variant-numeric: tabular-nums;
                min-height: 44px;
                transition: color var(--ffe-transition-duration) var(--ffe-ease);
                font-size: var(--ffe-fontsize-h6);
                align-items: center;
                display: flex;
                position: relative;
            }
            .ffe-toggle-switch__label-text {
                padding-right: var(--ffe-spacing-sm);
                margin-right: auto;
            }
            .ffe-toggle-switch__label-on,
            .ffe-toggle-switch__label-off {
                color: var(--ffe-color-foreground-default);
                font-family: var(--ffe-g-font);
                font-variant-numeric: tabular-nums;
                font-weight: 400;
                line-height: 1.25rem;
                font-size: var(--ffe-fontsize-small-text);
                overflow-wrap: anywhere;
                margin: 0;
            }
            .ffe-toggle-switch__label-on--underline,
            .ffe-toggle-switch__label-off--underline {
                border-bottom: var(--ffe-g-border-width) solid currentColor;
            }
            .ffe-toggle-switch__label-description {
                margin-top: var(--ffe-spacing-2xs);
                color: var(--ffe-color-foreground-default);
                font-family: var(--ffe-g-font);
                font-variant-numeric: tabular-nums;
                font-weight: 400;
                line-height: 1.25rem;
                font-size: var(--ffe-fontsize-small-text);
                overflow-wrap: anywhere;
                margin: 0;
                display: block;
            }
            .ffe-toggle-switch__label-description--underline {
                border-bottom: var(--ffe-g-border-width) solid currentColor;
            }
            .ffe-toggle-switch__switch {
                margin: 0 var(--ffe-spacing-sm);
                align-items: center;
                display: flex;
                position: relative;
            }
            .ffe-toggle-switch--hide-on-off .ffe-toggle-switch__switch {
                margin: 0;
            }
            .ffe-toggle-switch__switch:before {
                content: "";
                background: var(--ffe-color-component-form-toggleswitch-fill-default);
                width: 56px;
                height: 30px;
                transition:
                    background 0.4s var(--ffe-ease),
                    box-shadow var(--ffe-transition-duration) var(--ffe-ease);
                border-radius: 52px;
                display: inline-block;
                left: auto;
                right: 0;
            }
            .ffe-toggle-switch__switch:after {
                content: "";
                background: var(--ffe-color-component-form-toggleswitch-handle-default);
                width: 24px;
                height: 24px;
                transition: transform var(--ffe-transition-duration) var(--ffe-ease);
                border-radius: 50%;
                display: inline-block;
                position: absolute;
                left: 4px;
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-toggle-switch__label:hover .ffe-toggle-switch__switch:before {
                    background: var(--ffe-color-component-form-toggleswitch-fill-default-hover);
                }
            }
            .ffe-toggle-switch__input:checked + .ffe-toggle-switch__label .ffe-toggle-switch__switch:after {
                transform: translate(24px);
            }
            .ffe-toggle-switch__input:checked + .ffe-toggle-switch__label .ffe-toggle-switch__switch:before {
                background: var(--ffe-color-component-form-toggleswitch-fill-selected);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-toggle-switch__input:checked + .ffe-toggle-switch__label:hover .ffe-toggle-switch__switch:before {
                    background: var(--ffe-color-component-form-toggleswitch-fill-selected-hover);
                }
            }
            .ffe-toggle-switch__input:focus:not(:focus-visible)
                + .ffe-toggle-switch__label
                .ffe-toggle-switch__switch:before {
                box-shadow: none;
            }
            .ffe-toggle-switch__input:focus + .ffe-toggle-switch__label .ffe-toggle-switch__switch:before {
                box-shadow:
                    0 0 0 3px var(--ffe-color-surface-primary-default),
                    0 0 0 5px var(--ffe-color-border-interactive-focus);
            }
            :active + .ffe-toggle-switch__label .ffe-toggle-switch__switch:before {
                background: var(--ffe-color-component-form-toggleswitch-fill-default-pressed);
            }
            .ffe-toggle-switch__input:checked:active + .ffe-toggle-switch__label .ffe-toggle-switch__switch:before {
                background: var(--ffe-color-component-form-toggleswitch-fill-selected-pressed);
            }
            .ffe-input-group {
                padding: 0 0 calc(1lh + var(--ffe-spacing-xs));
                border: 0;
                position: relative;
            }
            .ffe-input-group > * {
                margin-top: 0;
                margin-bottom: var(--ffe-spacing-xs);
            }
            .ffe-input-group .ffe-form-label {
                padding-top: var(--ffe-spacing-2xs);
                margin-bottom: 0;
            }
            .ffe-input-group .ffe-field-message--error {
                margin-top: 0;
            }
            .ffe-input-group__description {
                margin-bottom: var(--ffe-spacing-xs);
                color: var(--ffe-color-foreground-subtle);
            }
            .ffe-input-group--message,
            .ffe-input-group--no-extra-margin {
                padding-bottom: 0;
            }
            .ffe-input-group--no-extra-margin .ffe-field-message--error {
                margin-bottom: var(--ffe-spacing-xs);
                height: initial;
            }
            .ffe-input-group__header {
                margin: 0;
            }
            .ffe-input-group__header .ffe-tooltip__icon,
            .ffe-input-group > .ffe-form-label .ffe-tooltip__icon {
                margin-left: var(--ffe-spacing-xs);
                transform: translateY(var(--ffe-spacing-2xs));
            }
            .ffe-form-label {
                overflow-wrap: anywhere;
                padding-bottom: var(--ffe-spacing-2xs);
                font-family: var(--ffe-g-font-strong);
                font-variant-numeric: tabular-nums;
                font-size: var(--ffe-fontsize-h6);
                color: var(--ffe-color-foreground-default);
                font-style: normal;
                font-weight: 500;
                font-stretch: 100%;
                line-height: 1.5;
                display: inline-block;
                position: relative;
            }
            .ffe-form-label .ffe-tooltip--open .ffe-tooltip__text {
                margin-bottom: 0;
            }
            .ffe-form-label--block {
                display: block;
            }
            .ffe-input-group:has(.ffe-tooltip) .ffe-form-label {
                max-width: calc(100% - 42px);
            }
            .ffe-tooltip {
                display: inline;
            }
            .ffe-tooltip__icon {
                color: var(--ffe-color-foreground-emphasis);
                cursor: help;
                aspect-ratio: 1;
                height: 1.25rem;
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                font-family: sans-serif;
                line-height: 1;
                font-size: var(--ffe-fontsize-button);
                background: 0 0;
                border: none;
                border-radius: 50%;
                justify-content: center;
                align-items: center;
                margin: 0;
                padding: 0;
                display: inline-flex;
            }
            .ffe-tooltip__icon > span {
                margin-top: 2px;
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-tooltip__icon:hover {
                    background: var(--ffe-color-fill-primary-subtle-hover);
                    box-shadow: 0 0 0 4px var(--ffe-color-fill-primary-subtle-hover);
                }
            }
            .ffe-tooltip__icon:active,
            .ffe-tooltip--open .ffe-tooltip__icon {
                background: var(--ffe-color-fill-primary-subtle-pressed);
                box-shadow: 0 0 0 4px var(--ffe-color-fill-primary-subtle-pressed);
            }
            .ffe-tooltip__icon:focus-visible {
                background: var(--ffe-color-fill-primary-subtle-hover);
                box-shadow:
                    0 0 0 4px var(--ffe-color-fill-primary-subtle-hover),
                    0 0 0 6px var(--ffe-color-surface-primary-default),
                    0 0 0 8px var(--ffe-color-border-interactive-focus);
                outline: none;
            }
            .ffe-tooltip__text {
                will-change: height;
                visibility: hidden;
                height: 0;
                transition: all var(--ffe-transition-duration) var(--ffe-ease);
                overflow-wrap: anywhere;
                color: var(--ffe-color-foreground-default);
                overflow: hidden;
            }
            .ffe-tooltip--open .ffe-tooltip__text {
                margin: var(--ffe-spacing-2xs) 0;
                padding: var(--ffe-spacing-2xs) 0;
                visibility: visible;
                height: auto;
                overflow: visible;
            }
            .ffe-field-message {
                font-family: var(--ffe-g-font);
                color: var(--ffe-color-foreground-default);
                margin: var(--ffe-spacing-2xs) 0 var(--ffe-spacing-xs);
                grid-column-gap: var(--ffe-spacing-xs);
                font-size: var(--ffe-fontsize-body-text);
                overflow-wrap: anywhere;
                grid-template-columns: auto 1fr;
                display: grid;
            }
            .ffe-field-message[aria-hidden="true"] {
                display: none;
            }
            .ffe-field-message__icon {
                width: 18px;
                height: 18px;
                color: var(--ffe-color-foreground-inverse);
                border-radius: 50%;
                justify-content: center;
                align-self: center;
                justify-self: center;
                align-items: center;
                display: inline-flex;
            }
            .ffe-field-message .ffe-icons {
                color: var(--ffe-color-foreground-inverse);
            }
            .ffe-field-message--success .ffe-field-message__icon {
                background-color: var(--ffe-color-fill-feedback-success);
            }
            .ffe-field-message--success .ffe-field-message__icon .ffe-icons {
                color: var(--ffe-color-foreground-inverse);
            }
            .ffe-field-message--info .ffe-field-message__icon {
                background-color: var(--ffe-color-fill-feedback-info);
            }
            .ffe-field-message--info .ffe-field-message__icon .ffe-icons {
                color: var(--ffe-color-foreground-inverse);
            }
            .ffe-field-message--error .ffe-field-message__icon {
                background: var(--ffe-color-fill-feedback-critical);
            }
            .ffe-field-message--error .ffe-field-message__icon .ffe-icons {
                color: var(--ffe-color-background-default);
            }
            select,
            textarea {
                -webkit-appearance: none;
                -moz-appearance: none;
                -ms-appearance: none;
                appearance: none;
            }
            input:not(:-webkit-any([type="radio"], [type="checkbox"])) {
                -webkit-appearance: none;
                -moz-appearance: none;
                -ms-appearance: none;
                appearance: none;
            }
            input:not(:-moz-any([type="radio"], [type="checkbox"])) {
                -webkit-appearance: none;
                -moz-appearance: none;
                -ms-appearance: none;
                appearance: none;
            }
            input:not(:is([type="radio"], [type="checkbox"])) {
                -webkit-appearance: none;
                -moz-appearance: none;
                -ms-appearance: none;
                appearance: none;
            }
            .ffe-grid__row {
                padding-right: var(--ffe-spacing-sm);
                padding-left: var(--ffe-spacing-sm);
                color: var(--ffe-color-foreground-default);
            }
            .ffe-grid__row,
            .ffe-grid__row-wrapper {
                gap: var(--ffe-spacing-sm);
                max-width: var(--app-width);
                grid-template-columns: repeat(12, 1fr);
                margin: 0 auto;
                display: grid;
            }
            .ffe-grid--gap-none .ffe-grid__row,
            .ffe-grid--gap-none .ffe-grid__row-wrapper {
                gap: 0;
                padding-left: 0;
                padding-right: 0;
            }
            .ffe-grid--gap-2xs .ffe-grid__row,
            .ffe-grid--gap-2xs .ffe-grid__row-wrapper {
                gap: var(--ffe-spacing-2xs);
                padding-right: var(--ffe-spacing-2xs);
                padding-left: var(--ffe-spacing-2xs);
            }
            .ffe-grid--gap-xs .ffe-grid__row,
            .ffe-grid--gap-xs .ffe-grid__row-wrapper {
                gap: var(--ffe-spacing-xs);
                padding-right: var(--ffe-spacing-xs);
                padding-left: var(--ffe-spacing-xs);
            }
            .ffe-grid--gap-sm .ffe-grid__row,
            .ffe-grid--gap-sm .ffe-grid__row-wrapper {
                gap: var(--ffe-spacing-sm);
                padding-right: var(--ffe-spacing-sm);
                padding-left: var(--ffe-spacing-sm);
            }
            .ffe-grid--gap-md .ffe-grid__row,
            .ffe-grid--gap-md .ffe-grid__row-wrapper {
                gap: var(--ffe-spacing-md);
                padding-right: var(--ffe-spacing-md);
                padding-left: var(--ffe-spacing-md);
            }
            .ffe-grid--gap-lg .ffe-grid__row,
            .ffe-grid--gap-lg .ffe-grid__row-wrapper {
                gap: var(--ffe-spacing-lg);
                padding-right: var(--ffe-spacing-lg);
                padding-left: var(--ffe-spacing-lg);
            }
            @media (min-width: 480px) {
                .ffe-grid--sm-gap-none .ffe-grid__row,
                .ffe-grid--sm-gap-none .ffe-grid__row-wrapper {
                    gap: 0;
                    padding-left: 0;
                    padding-right: 0;
                }
                .ffe-grid--sm-gap-2xs .ffe-grid__row,
                .ffe-grid--sm-gap-2xs .ffe-grid__row-wrapper {
                    gap: var(--ffe-spacing-2xs);
                    padding-right: var(--ffe-spacing-2xs);
                    padding-left: var(--ffe-spacing-2xs);
                }
                .ffe-grid--sm-gap-xs .ffe-grid__row,
                .ffe-grid--sm-gap-xs .ffe-grid__row-wrapper {
                    gap: var(--ffe-spacing-xs);
                    padding-right: var(--ffe-spacing-xs);
                    padding-left: var(--ffe-spacing-xs);
                }
                .ffe-grid--sm-gap-sm .ffe-grid__row,
                .ffe-grid--sm-gap-sm .ffe-grid__row-wrapper {
                    gap: var(--ffe-spacing-sm);
                    padding-right: var(--ffe-spacing-sm);
                    padding-left: var(--ffe-spacing-sm);
                }
                .ffe-grid--sm-gap-md .ffe-grid__row,
                .ffe-grid--sm-gap-md .ffe-grid__row-wrapper {
                    gap: var(--ffe-spacing-md);
                    padding-right: var(--ffe-spacing-md);
                    padding-left: var(--ffe-spacing-md);
                }
                .ffe-grid--sm-gap-lg .ffe-grid__row,
                .ffe-grid--sm-gap-lg .ffe-grid__row-wrapper {
                    gap: var(--ffe-spacing-lg);
                    padding-right: var(--ffe-spacing-lg);
                    padding-left: var(--ffe-spacing-lg);
                }
            }
            @media (min-width: 768px) {
                .ffe-grid--md-gap-none .ffe-grid__row,
                .ffe-grid--md-gap-none .ffe-grid__row-wrapper {
                    gap: 0;
                    padding-left: 0;
                    padding-right: 0;
                }
                .ffe-grid--md-gap-2xs .ffe-grid__row,
                .ffe-grid--md-gap-2xs .ffe-grid__row-wrapper {
                    gap: var(--ffe-spacing-2xs);
                    padding-right: var(--ffe-spacing-2xs);
                    padding-left: var(--ffe-spacing-2xs);
                }
                .ffe-grid--md-gap-xs .ffe-grid__row,
                .ffe-grid--md-gap-xs .ffe-grid__row-wrapper {
                    gap: var(--ffe-spacing-xs);
                    padding-right: var(--ffe-spacing-xs);
                    padding-left: var(--ffe-spacing-xs);
                }
                .ffe-grid--md-gap-sm .ffe-grid__row,
                .ffe-grid--md-gap-sm .ffe-grid__row-wrapper {
                    gap: var(--ffe-spacing-sm);
                    padding-right: var(--ffe-spacing-sm);
                    padding-left: var(--ffe-spacing-sm);
                }
                .ffe-grid--md-gap-md .ffe-grid__row,
                .ffe-grid--md-gap-md .ffe-grid__row-wrapper {
                    gap: var(--ffe-spacing-md);
                    padding-right: var(--ffe-spacing-md);
                    padding-left: var(--ffe-spacing-md);
                }
                .ffe-grid--md-gap-lg .ffe-grid__row,
                .ffe-grid--md-gap-lg .ffe-grid__row-wrapper {
                    gap: var(--ffe-spacing-lg);
                    padding-right: var(--ffe-spacing-lg);
                    padding-left: var(--ffe-spacing-lg);
                }
            }
            @media (min-width: 1024px) {
                .ffe-grid--lg-gap-none .ffe-grid__row,
                .ffe-grid--lg-gap-none .ffe-grid__row-wrapper {
                    gap: 0;
                    padding-left: 0;
                    padding-right: 0;
                }
                .ffe-grid--lg-gap-2xs .ffe-grid__row,
                .ffe-grid--lg-gap-2xs .ffe-grid__row-wrapper {
                    gap: var(--ffe-spacing-2xs);
                    padding-right: var(--ffe-spacing-2xs);
                    padding-left: var(--ffe-spacing-2xs);
                }
                .ffe-grid--lg-gap-xs .ffe-grid__row,
                .ffe-grid--lg-gap-xs .ffe-grid__row-wrapper {
                    gap: var(--ffe-spacing-xs);
                    padding-right: var(--ffe-spacing-xs);
                    padding-left: var(--ffe-spacing-xs);
                }
                .ffe-grid--lg-gap-sm .ffe-grid__row,
                .ffe-grid--lg-gap-sm .ffe-grid__row-wrapper {
                    gap: var(--ffe-spacing-sm);
                    padding-right: var(--ffe-spacing-sm);
                    padding-left: var(--ffe-spacing-sm);
                }
                .ffe-grid--lg-gap-md .ffe-grid__row,
                .ffe-grid--lg-gap-md .ffe-grid__row-wrapper {
                    gap: var(--ffe-spacing-md);
                    padding-right: var(--ffe-spacing-md);
                    padding-left: var(--ffe-spacing-md);
                }
                .ffe-grid--lg-gap-lg .ffe-grid__row,
                .ffe-grid--lg-gap-lg .ffe-grid__row-wrapper {
                    gap: var(--ffe-spacing-lg);
                    padding-right: var(--ffe-spacing-lg);
                    padding-left: var(--ffe-spacing-lg);
                }
            }
            .ffe-grid__row--padding-2xs,
            .ffe-grid__row-wrapper--padding-2xs,
            .ffe-grid__row--padding-xs,
            .ffe-grid__row-wrapper--padding-xs {
                padding-top: var(--ffe-spacing-2xs);
                padding-bottom: var(--ffe-spacing-2xs);
            }
            .ffe-grid__row--padding-sm,
            .ffe-grid__row-wrapper--padding-sm {
                padding-top: var(--ffe-spacing-sm);
                padding-bottom: var(--ffe-spacing-sm);
            }
            .ffe-grid__row--padding-md,
            .ffe-grid__row-wrapper--padding-md {
                padding-top: var(--ffe-spacing-md);
                padding-bottom: var(--ffe-spacing-md);
            }
            .ffe-grid__row--padding-lg,
            .ffe-grid__row-wrapper--padding-lg {
                padding-top: var(--ffe-spacing-lg);
                padding-bottom: var(--ffe-spacing-lg);
            }
            .ffe-grid__row--padding-xl,
            .ffe-grid__row-wrapper--padding-xl {
                padding-top: var(--ffe-spacing-xl);
                padding-bottom: var(--ffe-spacing-xl);
            }
            .ffe-grid__row--padding-2xl,
            .ffe-grid__row-wrapper--padding-2xl {
                padding-top: var(--ffe-spacing-2xl);
                padding-bottom: var(--ffe-spacing-2xl);
            }
            .ffe-grid__row--padding-3xl,
            .ffe-grid__row-wrapper--padding-3xl {
                padding-top: var(--ffe-spacing-3xl);
                padding-bottom: var(--ffe-spacing-3xl);
            }
            .ffe-grid__row--padding-4xl,
            .ffe-grid__row-wrapper--padding-4xl {
                padding-top: var(--ffe-spacing-4xl);
                padding-bottom: var(--ffe-spacing-4xl);
            }
            .ffe-grid__row--padding-5xl,
            .ffe-grid__row-wrapper--padding-5xl {
                padding-top: var(--ffe-spacing-5xl);
                padding-bottom: var(--ffe-spacing-5xl);
            }
            @media (min-width: 480px) {
                .ffe-grid__row--sm-padding-2xs,
                .ffe-grid__row-wrapper--sm-padding-2xs,
                .ffe-grid__row--sm-padding-xs,
                .ffe-grid__row-wrapper--sm-padding-xs {
                    padding-top: var(--ffe-spacing-2xs);
                    padding-bottom: var(--ffe-spacing-2xs);
                }
                .ffe-grid__row--sm-padding-sm,
                .ffe-grid__row-wrapper--sm-padding-sm {
                    padding-top: var(--ffe-spacing-sm);
                    padding-bottom: var(--ffe-spacing-sm);
                }
                .ffe-grid__row--sm-padding-md,
                .ffe-grid__row-wrapper--sm-padding-md {
                    padding-top: var(--ffe-spacing-md);
                    padding-bottom: var(--ffe-spacing-md);
                }
                .ffe-grid__row--sm-padding-lg,
                .ffe-grid__row-wrapper--sm-padding-lg {
                    padding-top: var(--ffe-spacing-lg);
                    padding-bottom: var(--ffe-spacing-lg);
                }
                .ffe-grid__row--sm-padding-xl,
                .ffe-grid__row-wrapper--sm-padding-xl {
                    padding-top: var(--ffe-spacing-xl);
                    padding-bottom: var(--ffe-spacing-xl);
                }
                .ffe-grid__row--sm-padding-2xl,
                .ffe-grid__row-wrapper--sm-padding-2xl {
                    padding-top: var(--ffe-spacing-2xl);
                    padding-bottom: var(--ffe-spacing-2xl);
                }
                .ffe-grid__row--sm-padding-3xl,
                .ffe-grid__row-wrapper--sm-padding-3xl {
                    padding-top: var(--ffe-spacing-3xl);
                    padding-bottom: var(--ffe-spacing-3xl);
                }
                .ffe-grid__row--sm-padding-4xl,
                .ffe-grid__row-wrapper--sm-padding-4xl {
                    padding-top: var(--ffe-spacing-4xl);
                    padding-bottom: var(--ffe-spacing-4xl);
                }
                .ffe-grid__row--sm-padding-5xl,
                .ffe-grid__row-wrapper--sm-padding-5xl {
                    padding-top: var(--ffe-spacing-5xl);
                    padding-bottom: var(--ffe-spacing-5xl);
                }
            }
            @media (min-width: 768px) {
                .ffe-grid__row--md-padding-2xs,
                .ffe-grid__row-wrapper--md-padding-2xs,
                .ffe-grid__row--md-padding-xs,
                .ffe-grid__row-wrapper--md-padding-xs {
                    padding-top: var(--ffe-spacing-2xs);
                    padding-bottom: var(--ffe-spacing-2xs);
                }
                .ffe-grid__row--md-padding-sm,
                .ffe-grid__row-wrapper--md-padding-sm {
                    padding-top: var(--ffe-spacing-sm);
                    padding-bottom: var(--ffe-spacing-sm);
                }
                .ffe-grid__row--md-padding-md,
                .ffe-grid__row-wrapper--md-padding-md {
                    padding-top: var(--ffe-spacing-md);
                    padding-bottom: var(--ffe-spacing-md);
                }
                .ffe-grid__row--md-padding-lg,
                .ffe-grid__row-wrapper--md-padding-lg {
                    padding-top: var(--ffe-spacing-lg);
                    padding-bottom: var(--ffe-spacing-lg);
                }
                .ffe-grid__row--md-padding-xl,
                .ffe-grid__row-wrapper--md-padding-xl {
                    padding-top: var(--ffe-spacing-xl);
                    padding-bottom: var(--ffe-spacing-xl);
                }
                .ffe-grid__row--md-padding-2xl,
                .ffe-grid__row-wrapper--md-padding-2xl {
                    padding-top: var(--ffe-spacing-2xl);
                    padding-bottom: var(--ffe-spacing-2xl);
                }
                .ffe-grid__row--md-padding-3xl,
                .ffe-grid__row-wrapper--md-padding-3xl {
                    padding-top: var(--ffe-spacing-3xl);
                    padding-bottom: var(--ffe-spacing-3xl);
                }
                .ffe-grid__row--md-padding-4xl,
                .ffe-grid__row-wrapper--md-padding-4xl {
                    padding-top: var(--ffe-spacing-4xl);
                    padding-bottom: var(--ffe-spacing-4xl);
                }
                .ffe-grid__row--md-padding-5xl,
                .ffe-grid__row-wrapper--md-padding-5xl {
                    padding-top: var(--ffe-spacing-5xl);
                    padding-bottom: var(--ffe-spacing-5xl);
                }
            }
            @media (min-width: 1024px) {
                .ffe-grid__row--lg-padding-2xs,
                .ffe-grid__row-wrapper--lg-padding-2xs,
                .ffe-grid__row--lg-padding-xs,
                .ffe-grid__row-wrapper--lg-padding-xs {
                    padding-top: var(--ffe-spacing-2xs);
                    padding-bottom: var(--ffe-spacing-2xs);
                }
                .ffe-grid__row--lg-padding-sm,
                .ffe-grid__row-wrapper--lg-padding-sm {
                    padding-top: var(--ffe-spacing-sm);
                    padding-bottom: var(--ffe-spacing-sm);
                }
                .ffe-grid__row--lg-padding-md,
                .ffe-grid__row-wrapper--lg-padding-md {
                    padding-top: var(--ffe-spacing-md);
                    padding-bottom: var(--ffe-spacing-md);
                }
                .ffe-grid__row--lg-padding-lg,
                .ffe-grid__row-wrapper--lg-padding-lg {
                    padding-top: var(--ffe-spacing-lg);
                    padding-bottom: var(--ffe-spacing-lg);
                }
                .ffe-grid__row--lg-padding-xl,
                .ffe-grid__row-wrapper--lg-padding-xl {
                    padding-top: var(--ffe-spacing-xl);
                    padding-bottom: var(--ffe-spacing-xl);
                }
                .ffe-grid__row--lg-padding-2xl,
                .ffe-grid__row-wrapper--lg-padding-2xl {
                    padding-top: var(--ffe-spacing-2xl);
                    padding-bottom: var(--ffe-spacing-2xl);
                }
                .ffe-grid__row--lg-padding-3xl,
                .ffe-grid__row-wrapper--lg-padding-3xl {
                    padding-top: var(--ffe-spacing-3xl);
                    padding-bottom: var(--ffe-spacing-3xl);
                }
                .ffe-grid__row--lg-padding-4xl,
                .ffe-grid__row-wrapper--lg-padding-4xl {
                    padding-top: var(--ffe-spacing-4xl);
                    padding-bottom: var(--ffe-spacing-4xl);
                }
                .ffe-grid__row--lg-padding-5xl,
                .ffe-grid__row-wrapper--lg-padding-5xl {
                    padding-top: var(--ffe-spacing-5xl);
                    padding-bottom: var(--ffe-spacing-5xl);
                }
            }
            .ffe-grid__row--margin-2xs,
            .ffe-grid__row-wrapper--margin-2xs {
                margin: var(--ffe-spacing-2xs) auto;
            }
            .ffe-grid__row--margin-xs,
            .ffe-grid__row-wrapper--margin-xs {
                margin: var(--ffe-spacing-xs) auto;
            }
            .ffe-grid__row--margin-sm,
            .ffe-grid__row-wrapper--margin-sm {
                margin: var(--ffe-spacing-sm) auto;
            }
            .ffe-grid__row--margin-md,
            .ffe-grid__row-wrapper--margin-md {
                margin: var(--ffe-spacing-md) auto;
            }
            .ffe-grid__row--margin-lg,
            .ffe-grid__row-wrapper--margin-lg {
                margin: var(--ffe-spacing-lg) auto;
            }
            .ffe-grid__row--margin-xl,
            .ffe-grid__row-wrapper--margin-xl {
                margin: var(--ffe-spacing-xl) auto;
            }
            .ffe-grid__row--margin-2xl,
            .ffe-grid__row-wrapper--margin-2xl {
                margin: var(--ffe-spacing-2xl) auto;
            }
            .ffe-grid__row--margin-3xl,
            .ffe-grid__row-wrapper--margin-3xl {
                margin: var(--ffe-spacing-3xl) auto;
            }
            .ffe-grid__row--margin-4xl,
            .ffe-grid__row-wrapper--margin-4xl {
                margin: var(--ffe-spacing-4xl) auto;
            }
            .ffe-grid__row--margin-5xl,
            .ffe-grid__row-wrapper--margin-5xl {
                margin: var(--ffe-spacing-5xl) auto;
            }
            @media (min-width: 480px) {
                .ffe-grid__row--sm-margin-2xs,
                .ffe-grid__row-wrapper--sm-margin-2xs {
                    margin: var(--ffe-spacing-2xs) auto;
                }
                .ffe-grid__row--sm-margin-xs,
                .ffe-grid__row-wrapper--sm-margin-xs {
                    margin: var(--ffe-spacing-xs) auto;
                }
                .ffe-grid__row--sm-margin-sm,
                .ffe-grid__row-wrapper--sm-margin-sm {
                    margin: var(--ffe-spacing-sm) auto;
                }
                .ffe-grid__row--sm-margin-md,
                .ffe-grid__row-wrapper--sm-margin-md {
                    margin: var(--ffe-spacing-md) auto;
                }
                .ffe-grid__row--sm-margin-lg,
                .ffe-grid__row-wrapper--sm-margin-lg {
                    margin: var(--ffe-spacing-lg) auto;
                }
                .ffe-grid__row--sm-margin-xl,
                .ffe-grid__row-wrapper--sm-margin-xl {
                    margin: var(--ffe-spacing-xl) auto;
                }
                .ffe-grid__row--sm-margin-2xl,
                .ffe-grid__row-wrapper--sm-margin-2xl {
                    margin: var(--ffe-spacing-2xl) auto;
                }
                .ffe-grid__row--sm-margin-3xl,
                .ffe-grid__row-wrapper--sm-margin-3xl {
                    margin: var(--ffe-spacing-3xl) auto;
                }
                .ffe-grid__row--sm-margin-4xl,
                .ffe-grid__row-wrapper--sm-margin-4xl {
                    margin: var(--ffe-spacing-4xl) auto;
                }
                .ffe-grid__row--sm-margin-5xl,
                .ffe-grid__row-wrapper--sm-margin-5xl {
                    margin: var(--ffe-spacing-5xl) auto;
                }
            }
            @media (min-width: 768px) {
                .ffe-grid__row--md-margin-2xs,
                .ffe-grid__row-wrapper--md-margin-2xs {
                    margin: var(--ffe-spacing-2xs) auto;
                }
                .ffe-grid__row--md-margin-xs,
                .ffe-grid__row-wrapper--md-margin-xs {
                    margin: var(--ffe-spacing-xs) auto;
                }
                .ffe-grid__row--md-margin-sm,
                .ffe-grid__row-wrapper--md-margin-sm {
                    margin: var(--ffe-spacing-sm) auto;
                }
                .ffe-grid__row--md-margin-md,
                .ffe-grid__row-wrapper--md-margin-md {
                    margin: var(--ffe-spacing-md) auto;
                }
                .ffe-grid__row--md-margin-lg,
                .ffe-grid__row-wrapper--md-margin-lg {
                    margin: var(--ffe-spacing-lg) auto;
                }
                .ffe-grid__row--md-margin-xl,
                .ffe-grid__row-wrapper--md-margin-xl {
                    margin: var(--ffe-spacing-xl) auto;
                }
                .ffe-grid__row--md-margin-2xl,
                .ffe-grid__row-wrapper--md-margin-2xl {
                    margin: var(--ffe-spacing-2xl) auto;
                }
                .ffe-grid__row--md-margin-3xl,
                .ffe-grid__row-wrapper--md-margin-3xl {
                    margin: var(--ffe-spacing-3xl) auto;
                }
                .ffe-grid__row--md-margin-4xl,
                .ffe-grid__row-wrapper--md-margin-4xl {
                    margin: var(--ffe-spacing-4xl) auto;
                }
                .ffe-grid__row--md-margin-5xl,
                .ffe-grid__row-wrapper--md-margin-5xl {
                    margin: var(--ffe-spacing-5xl) auto;
                }
            }
            @media (min-width: 1024px) {
                .ffe-grid__row--lg-margin-2xs,
                .ffe-grid__row-wrapper--lg-margin-2xs {
                    margin: var(--ffe-spacing-2xs) auto;
                }
                .ffe-grid__row--lg-margin-xs,
                .ffe-grid__row-wrapper--lg-margin-xs {
                    margin: var(--ffe-spacing-xs) auto;
                }
                .ffe-grid__row--lg-margin-sm,
                .ffe-grid__row-wrapper--lg-margin-sm {
                    margin: var(--ffe-spacing-sm) auto;
                }
                .ffe-grid__row--lg-margin-md,
                .ffe-grid__row-wrapper--lg-margin-md {
                    margin: var(--ffe-spacing-md) auto;
                }
                .ffe-grid__row--lg-margin-lg,
                .ffe-grid__row-wrapper--lg-margin-lg {
                    margin: var(--ffe-spacing-lg) auto;
                }
                .ffe-grid__row--lg-margin-xl,
                .ffe-grid__row-wrapper--lg-margin-xl {
                    margin: var(--ffe-spacing-xl) auto;
                }
                .ffe-grid__row--lg-margin-2xl,
                .ffe-grid__row-wrapper--lg-margin-2xl {
                    margin: var(--ffe-spacing-2xl) auto;
                }
                .ffe-grid__row--lg-margin-3xl,
                .ffe-grid__row-wrapper--lg-margin-3xl {
                    margin: var(--ffe-spacing-3xl) auto;
                }
                .ffe-grid__row--lg-margin-4xl,
                .ffe-grid__row-wrapper--lg-margin-4xl {
                    margin: var(--ffe-spacing-4xl) auto;
                }
                .ffe-grid__row--lg-margin-5xl,
                .ffe-grid__row-wrapper--lg-margin-5xl {
                    margin: var(--ffe-spacing-5xl) auto;
                }
            }
            .ffe-grid__row--bg-primary,
            .ffe-grid__row-wrapper--bg-primary {
                background-color: var(--ffe-color-surface-primary-default);
            }
            .ffe-grid__row--bg-secondary,
            .ffe-grid__row-wrapper--bg-secondary {
                background-color: var(--ffe-color-surface-secondary-default);
            }
            .ffe-grid__row--bg-tertiary,
            .ffe-grid__row-wrapper--bg-tertiary {
                background-color: var(--ffe-color-surface-tertiary-default);
            }
            [class*="ffe-grid__row--bg-"] {
                max-width: none;
                display: block;
            }
            .ffe-grid__col {
                grid-column: auto/span 12;
            }
            .ffe-grid__col--bg-primary {
                background-color: var(--ffe-color-surface-primary-default);
            }
            .ffe-grid__col--bg-secondary {
                background-color: var(--ffe-color-surface-secondary-default);
            }
            .ffe-grid__col--bg-tertiary {
                background-color: var(--ffe-color-surface-tertiary-default);
            }
            .ffe-grid__col--center-text {
                text-align: center;
            }
            .ffe-grid__col--sm-0 {
                grid-column: auto / span 0;
                display: none;
            }
            .ffe-grid__col--sm-1 {
                grid-column: auto/span 1;
                display: block;
            }
            .ffe-grid__col--sm-2 {
                grid-column: auto/span 2;
                display: block;
            }
            .ffe-grid__col--sm-3 {
                grid-column: auto/span 3;
                display: block;
            }
            .ffe-grid__col--sm-4 {
                grid-column: auto/span 4;
                display: block;
            }
            .ffe-grid__col--sm-5 {
                grid-column: auto/span 5;
                display: block;
            }
            .ffe-grid__col--sm-6 {
                grid-column: auto/span 6;
                display: block;
            }
            .ffe-grid__col--sm-7 {
                grid-column: auto/span 7;
                display: block;
            }
            .ffe-grid__col--sm-8 {
                grid-column: auto/span 8;
                display: block;
            }
            .ffe-grid__col--sm-9 {
                grid-column: auto/span 9;
                display: block;
            }
            .ffe-grid__col--sm-10 {
                grid-column: auto/span 10;
                display: block;
            }
            .ffe-grid__col--sm-11 {
                grid-column: auto/span 11;
                display: block;
            }
            .ffe-grid__col--sm-12 {
                grid-column: auto/span 12;
                display: block;
            }
            .ffe-grid__col--sm-offset-1 {
                grid-column-start: 2;
            }
            .ffe-grid__col--sm-offset-2 {
                grid-column-start: 3;
            }
            .ffe-grid__col--sm-offset-3 {
                grid-column-start: 4;
            }
            .ffe-grid__col--sm-offset-4 {
                grid-column-start: 5;
            }
            .ffe-grid__col--sm-offset-5 {
                grid-column-start: 6;
            }
            .ffe-grid__col--sm-offset-6 {
                grid-column-start: 7;
            }
            .ffe-grid__col--sm-offset-7 {
                grid-column-start: 8;
            }
            .ffe-grid__col--sm-offset-8 {
                grid-column-start: 9;
            }
            .ffe-grid__col--sm-offset-9 {
                grid-column-start: 10;
            }
            .ffe-grid__col--sm-offset-10 {
                grid-column-start: 11;
            }
            .ffe-grid__col--sm-offset-11 {
                grid-column-start: 12;
            }
            .ffe-grid__col--sm-offset-12 {
                grid-column-start: 13;
            }
            @media (min-width: 768px) {
                .ffe-grid__col--md-0 {
                    grid-column: auto / span 0;
                    display: none;
                }
                .ffe-grid__col--md-1 {
                    grid-column: auto/span 1;
                    display: block;
                }
                .ffe-grid__col--md-2 {
                    grid-column: auto/span 2;
                    display: block;
                }
                .ffe-grid__col--md-3 {
                    grid-column: auto/span 3;
                    display: block;
                }
                .ffe-grid__col--md-4 {
                    grid-column: auto/span 4;
                    display: block;
                }
                .ffe-grid__col--md-5 {
                    grid-column: auto/span 5;
                    display: block;
                }
                .ffe-grid__col--md-6 {
                    grid-column: auto/span 6;
                    display: block;
                }
                .ffe-grid__col--md-7 {
                    grid-column: auto/span 7;
                    display: block;
                }
                .ffe-grid__col--md-8 {
                    grid-column: auto/span 8;
                    display: block;
                }
                .ffe-grid__col--md-9 {
                    grid-column: auto/span 9;
                    display: block;
                }
                .ffe-grid__col--md-10 {
                    grid-column: auto/span 10;
                    display: block;
                }
                .ffe-grid__col--md-11 {
                    grid-column: auto/span 11;
                    display: block;
                }
                .ffe-grid__col--md-12 {
                    grid-column: auto/span 12;
                    display: block;
                }
                .ffe-grid__col--md-offset-1 {
                    grid-column-start: 2;
                }
                .ffe-grid__col--md-offset-2 {
                    grid-column-start: 3;
                }
                .ffe-grid__col--md-offset-3 {
                    grid-column-start: 4;
                }
                .ffe-grid__col--md-offset-4 {
                    grid-column-start: 5;
                }
                .ffe-grid__col--md-offset-5 {
                    grid-column-start: 6;
                }
                .ffe-grid__col--md-offset-6 {
                    grid-column-start: 7;
                }
                .ffe-grid__col--md-offset-7 {
                    grid-column-start: 8;
                }
                .ffe-grid__col--md-offset-8 {
                    grid-column-start: 9;
                }
                .ffe-grid__col--md-offset-9 {
                    grid-column-start: 10;
                }
                .ffe-grid__col--md-offset-10 {
                    grid-column-start: 11;
                }
                .ffe-grid__col--md-offset-11 {
                    grid-column-start: 12;
                }
                .ffe-grid__col--md-offset-12 {
                    grid-column-start: 13;
                }
            }
            @media (min-width: 1024px) {
                .ffe-grid__col--lg-0 {
                    grid-column: auto / span 0;
                    display: none;
                }
                .ffe-grid__col--lg-1 {
                    grid-column: auto/span 1;
                    display: block;
                }
                .ffe-grid__col--lg-2 {
                    grid-column: auto/span 2;
                    display: block;
                }
                .ffe-grid__col--lg-3 {
                    grid-column: auto/span 3;
                    display: block;
                }
                .ffe-grid__col--lg-4 {
                    grid-column: auto/span 4;
                    display: block;
                }
                .ffe-grid__col--lg-5 {
                    grid-column: auto/span 5;
                    display: block;
                }
                .ffe-grid__col--lg-6 {
                    grid-column: auto/span 6;
                    display: block;
                }
                .ffe-grid__col--lg-7 {
                    grid-column: auto/span 7;
                    display: block;
                }
                .ffe-grid__col--lg-8 {
                    grid-column: auto/span 8;
                    display: block;
                }
                .ffe-grid__col--lg-9 {
                    grid-column: auto/span 9;
                    display: block;
                }
                .ffe-grid__col--lg-10 {
                    grid-column: auto/span 10;
                    display: block;
                }
                .ffe-grid__col--lg-11 {
                    grid-column: auto/span 11;
                    display: block;
                }
                .ffe-grid__col--lg-12 {
                    grid-column: auto/span 12;
                    display: block;
                }
                .ffe-grid__col--lg-offset-1 {
                    grid-column-start: 2;
                }
                .ffe-grid__col--lg-offset-2 {
                    grid-column-start: 3;
                }
                .ffe-grid__col--lg-offset-3 {
                    grid-column-start: 4;
                }
                .ffe-grid__col--lg-offset-4 {
                    grid-column-start: 5;
                }
                .ffe-grid__col--lg-offset-5 {
                    grid-column-start: 6;
                }
                .ffe-grid__col--lg-offset-6 {
                    grid-column-start: 7;
                }
                .ffe-grid__col--lg-offset-7 {
                    grid-column-start: 8;
                }
                .ffe-grid__col--lg-offset-8 {
                    grid-column-start: 9;
                }
                .ffe-grid__col--lg-offset-9 {
                    grid-column-start: 10;
                }
                .ffe-grid__col--lg-offset-10 {
                    grid-column-start: 11;
                }
                .ffe-grid__col--lg-offset-11 {
                    grid-column-start: 12;
                }
                .ffe-grid__col--lg-offset-12 {
                    grid-column-start: 13;
                }
            }
            @media (min-width: 1280px) {
                .ffe-grid__col--xl-0 {
                    grid-column: auto / span 0;
                    display: none;
                }
                .ffe-grid__col--xl-1 {
                    grid-column: auto/span 1;
                    display: block;
                }
                .ffe-grid__col--xl-2 {
                    grid-column: auto/span 2;
                    display: block;
                }
                .ffe-grid__col--xl-3 {
                    grid-column: auto/span 3;
                    display: block;
                }
                .ffe-grid__col--xl-4 {
                    grid-column: auto/span 4;
                    display: block;
                }
                .ffe-grid__col--xl-5 {
                    grid-column: auto/span 5;
                    display: block;
                }
                .ffe-grid__col--xl-6 {
                    grid-column: auto/span 6;
                    display: block;
                }
                .ffe-grid__col--xl-7 {
                    grid-column: auto/span 7;
                    display: block;
                }
                .ffe-grid__col--xl-8 {
                    grid-column: auto/span 8;
                    display: block;
                }
                .ffe-grid__col--xl-9 {
                    grid-column: auto/span 9;
                    display: block;
                }
                .ffe-grid__col--xl-10 {
                    grid-column: auto/span 10;
                    display: block;
                }
                .ffe-grid__col--xl-11 {
                    grid-column: auto/span 11;
                    display: block;
                }
                .ffe-grid__col--xl-12 {
                    grid-column: auto/span 12;
                    display: block;
                }
                .ffe-grid__col--xl-offset-1 {
                    grid-column-start: 2;
                }
                .ffe-grid__col--xl-offset-2 {
                    grid-column-start: 3;
                }
                .ffe-grid__col--xl-offset-3 {
                    grid-column-start: 4;
                }
                .ffe-grid__col--xl-offset-4 {
                    grid-column-start: 5;
                }
                .ffe-grid__col--xl-offset-5 {
                    grid-column-start: 6;
                }
                .ffe-grid__col--xl-offset-6 {
                    grid-column-start: 7;
                }
                .ffe-grid__col--xl-offset-7 {
                    grid-column-start: 8;
                }
                .ffe-grid__col--xl-offset-8 {
                    grid-column-start: 9;
                }
                .ffe-grid__col--xl-offset-9 {
                    grid-column-start: 10;
                }
                .ffe-grid__col--xl-offset-10 {
                    grid-column-start: 11;
                }
                .ffe-grid__col--xl-offset-11 {
                    grid-column-start: 12;
                }
                .ffe-grid__col--xl-offset-12 {
                    grid-column-start: 13;
                }
            }
            .ffe-grid__col--center {
                align-content: center;
                justify-content: center;
                align-items: center;
                justify-items: center;
                display: flex;
            }
            :root {
                --ffe-v-message-box-icon-bg-color: var(--ffe-farge-hvit);
                --ffe-v-message-box-variant-bg-color: var(--ffe-farge-hvit);
                --ffe-v-message-box-tips-bg-color: var(--ffe-farge-sand);
                --ffe-v-message-box-tips-icon-color: var(--ffe-farge-sol);
                --ffe-v-message-box-info-bg-color: var(--ffe-farge-frost-30);
                --ffe-v-message-box-info-icon-color: var(--ffe-farge-vann);
                --ffe-v-message-box-success-bg-color: var(--ffe-farge-nordlys-30);
                --ffe-v-message-box-success-icon-color: var(--ffe-farge-skog);
                --ffe-v-message-box-error-bg-color: var(--ffe-farge-baer-30);
                --ffe-v-message-box-error-icon-color: var(--ffe-farge-baer);
                --ffe-v-message-box-link-color: var(--ffe-farge-vann);
                --ffe-v-message-box-link-color-hover: var(--ffe-farge-fjell);
                --ffe-v-message-box-link-color-visited: var(--ffe-farge-lyng);
                --ffe-v-message-box-link-color-focus: var(--ffe-farge-hvit);
            }
            :host {
                --ffe-v-message-box-icon-bg-color: var(--ffe-farge-hvit);
                --ffe-v-message-box-variant-bg-color: var(--ffe-farge-hvit);
                --ffe-v-message-box-tips-bg-color: var(--ffe-farge-sand);
                --ffe-v-message-box-tips-icon-color: var(--ffe-farge-sol);
                --ffe-v-message-box-info-bg-color: var(--ffe-farge-frost-30);
                --ffe-v-message-box-info-icon-color: var(--ffe-farge-vann);
                --ffe-v-message-box-success-bg-color: var(--ffe-farge-nordlys-30);
                --ffe-v-message-box-success-icon-color: var(--ffe-farge-skog);
                --ffe-v-message-box-error-bg-color: var(--ffe-farge-baer-30);
                --ffe-v-message-box-error-icon-color: var(--ffe-farge-baer);
                --ffe-v-message-box-link-color: var(--ffe-farge-vann);
                --ffe-v-message-box-link-color-hover: var(--ffe-farge-fjell);
                --ffe-v-message-box-link-color-visited: var(--ffe-farge-lyng);
                --ffe-v-message-box-link-color-focus: var(--ffe-farge-hvit);
            }
            @media (prefers-color-scheme: dark) {
                :root .regard-color-scheme-preference {
                    --ffe-v-message-box-info-bg-color: var(--ffe-farge-vann-30);
                    --ffe-v-message-box-icon-bg-color: var(--ffe-farge-svart);
                    --ffe-v-message-box-info-icon-color: var(--ffe-farge-vann-70);
                    --ffe-v-message-box-success-icon-color: var(--ffe-farge-skog-70);
                }
                :host .regard-color-scheme-preference {
                    --ffe-v-message-box-info-bg-color: var(--ffe-farge-vann-30);
                    --ffe-v-message-box-icon-bg-color: var(--ffe-farge-svart);
                    --ffe-v-message-box-info-icon-color: var(--ffe-farge-vann-70);
                    --ffe-v-message-box-success-icon-color: var(--ffe-farge-skog-70);
                }
            }
            .ffe-message-box {
                text-align: center;
                font-family: var(--ffe-g-font);
            }
            .ffe-message-box .ffe-body-paragraph,
            .ffe-message-box .ffe-link-text,
            .ffe-message-box__list,
            .ffe-message-box__title {
                overflow-wrap: anywhere;
            }
            @media (prefers-color-scheme: dark) {
                .regard-color-scheme-preference .ffe-message-box__list,
                .regard-color-scheme-preference .ffe-message-box .ffe-body-paragraph {
                    color: var(--ffe-farge-svart);
                }
            }
            .ffe-message-box .ffe-link-text {
                border-bottom: 1px solid var(--ffe-v-message-box-link-color);
                color: var(--ffe-v-message-box-link-color);
            }
            @media (hover: hover) and (pointer: fine) {
                .ffe-message-box .ffe-link-text:hover {
                    border-bottom-color: var(--ffe-v-message-box-link-color-hover);
                    color: var(--ffe-v-message-box-link-color-hover);
                }
            }
            .ffe-message-box .ffe-link-text:visited {
                border-bottom-color: var(--ffe-v-message-box-link-color-visited);
                color: var(--ffe-v-message-box-link-color-visited);
            }
            .ffe-message-box .ffe-link-text:focus {
                background-color: var(--ffe-v-message-box-link-color);
                box-shadow: 0 0 0 2px var(--ffe-v-message-box-link-color);
                border-color: var(--ffe-v-message-box-link-color-focus) !important;
                color: var(--ffe-v-message-box-link-color-focus) !important;
            }
            .ffe-message-box__box {
                padding: var(--ffe-spacing-xl) var(--ffe-spacing-lg);
                border-radius: var(--ffe-spacing-xs);
                color: var(--ffe-farge-svart);
            }
            @media (prefers-color-scheme: dark) {
                .regard-color-scheme-preference .ffe-message-box__box {
                    color: var(--ffe-farge-svart);
                }
            }
            .ffe-message-box--tips .ffe-message-box__box {
                background-color: var(--ffe-v-message-box-tips-bg-color);
            }
            .ffe-message-box--tips.ffe-message-box--coloredbg .ffe-message-box__box {
                background-color: var(--ffe-v-message-box-variant-bg-color);
            }
            @media (prefers-color-scheme: dark) {
                .regard-color-scheme-preference
                    .ffe-message-box--tips.ffe-message-box--coloredbg
                    .ffe-message-box__box {
                    background-color: var(--ffe-v-message-box-tips-bg-color);
                }
            }
            .ffe-message-box--info .ffe-message-box__box {
                background-color: var(--ffe-v-message-box-info-bg-color);
            }
            .ffe-message-box--info.ffe-message-box--coloredbg .ffe-message-box__box {
                background-color: var(--ffe-v-message-box-variant-bg-color);
            }
            @media (prefers-color-scheme: dark) {
                .regard-color-scheme-preference
                    .ffe-message-box--info.ffe-message-box--coloredbg
                    .ffe-message-box__box {
                    background-color: var(--ffe-v-message-box-info-bg-color);
                }
            }
            .ffe-message-box--success .ffe-message-box__box {
                background-color: var(--ffe-v-message-box-success-bg-color);
            }
            .ffe-message-box--success.ffe-message-box--coloredbg .ffe-message-box__box {
                background-color: var(--ffe-v-message-box-variant-bg-color);
            }
            @media (prefers-color-scheme: dark) {
                .regard-color-scheme-preference
                    .ffe-message-box--success.ffe-message-box--coloredbg
                    .ffe-message-box__box {
                    background-color: var(--ffe-v-message-box-success-bg-color);
                }
            }
            .ffe-message-box--error .ffe-message-box__box {
                background-color: var(--ffe-v-message-box-error-bg-color);
            }
            .ffe-message-box--error.ffe-message-box--coloredbg .ffe-message-box__box {
                background-color: var(--ffe-v-message-box-variant-bg-color);
            }
            @media (prefers-color-scheme: dark) {
                .regard-color-scheme-preference
                    .ffe-message-box--error.ffe-message-box--coloredbg
                    .ffe-message-box__box {
                    background-color: var(--ffe-v-message-box-error-bg-color);
                }
            }
            .ffe-message-box__title {
                color: var(--ffe-color-foreground-default);
                font-size: var(--ffe-fontsize-h5);
                margin-bottom: var(--ffe-spacing-sm);
                font-family: var(--ffe-g-font-strong);
                font-variant-numeric: tabular-nums;
                overflow-wrap: anywhere;
                margin-top: 0;
                font-weight: 400;
            }
            @media (prefers-color-scheme: dark) {
                .regard-color-scheme-preference .ffe-message-box__title {
                    color: var(--ffe-farge-svart);
                }
            }
            .ffe-message-box__list {
                padding-left: var(--ffe-spacing-sm);
                text-align: left;
                margin: 0;
                line-height: 2;
            }
            .ffe-message-box__list .regard-color-scheme-preference li {
                color: var(--ffe-farge-svart);
            }
            .ffe-message-box__icon {
                background-color: var(--ffe-v-message-box-icon-bg-color);
                color: var(--ffe-v-message-box-info-icon-color);
                border: 2px solid var(--ffe-v-message-box-info-icon-color);
                border-radius: 50%;
                justify-content: center;
                align-items: center;
                width: 64px;
                height: 64px;
                margin-bottom: -16px;
                display: inline-flex;
                position: relative;
                top: 16px;
            }
            .ffe-message-box--tips .ffe-message-box__icon {
                border-color: var(--ffe-v-message-box-tips-icon-color);
            }
            .ffe-message-box--tips .ffe-icons {
                color: var(--ffe-v-message-box-tips-icon-color);
            }
            .ffe-message-box--error .ffe-message-box__icon {
                border-color: var(--ffe-v-message-box-error-icon-color);
            }
            .ffe-message-box--error .ffe-icons {
                color: var(--ffe-v-message-box-error-icon-color);
            }
            .ffe-message-box--success .ffe-message-box__icon {
                border-color: var(--ffe-v-message-box-success-icon-color);
            }
            .ffe-message-box--success .ffe-icons {
                color: var(--ffe-v-message-box-success-icon-color);
            }
            @media print {
                .ffe-message-box__box {
                    border: 2px dashed var(--ffe-farge-svart);
                }
                .ffe-message-box__icon {
                    border-bottom: 2px dashed var(--ffe-farge-svart);
                    margin-bottom: -33.5px;
                }
            }
            .ffe-loading-spinner-container {
                color: var(--ffe-color-foreground-default);
                flex-direction: column;
                align-items: center;
                display: flex;
            }
            .ffe-loading-spinner {
                vertical-align: middle;
                display: inline-block;
            }
            .ffe-loading-spinner:before {
                content: " ";
                border: 3px solid var(--ffe-color-fill-primary-selected-default);
                border-top-color: var(--ffe-color-fill-primary-subtle);
                visibility: hidden;
                border-radius: 50%;
                width: 30px;
                height: 30px;
                animation: 1s linear 0.5s infinite spin;
                display: inline-block;
            }
            @keyframes spin {
                0% {
                    visibility: visible;
                    transform: rotate(0);
                }
                to {
                    transform: rotate(360deg);
                }
            }
            .ffe-loading-spinner--stop-animation:before {
                animation: none;
            }
            .ffe-loading-spinner--large:before {
                border-width: 5px;
                width: 60px;
                height: 60px;
            }
            .ffe-loading-spinner--immediate:before {
                visibility: visible;
                animation-delay: 0s;
            }
            @font-face {
                font-family: SpareBank1-medium; /*savepage-font-display=fallback*/
                src:/*savepage-url=./fonts/SpareBank1-Medium-Web.CRUEa97P.woff2*/ url(data:font/woff2;base64,d09GMgABAAAAAIjsABIAAAABgzQAAIiGAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGToaahvwbBynGAZgAI4gCGQJm30RCAqEgyyD2EQLhzYAATYCJAOOZgQgBYozB5gxDIE9W9VocQPVaz9c5Nw2gP57JwzrmRK2Tfko3aky3zSXx6ECduwJ2DgACOtul/3//2cmlTG2T9o5SCYqaVaQI9tAYULNZC5UE9rkyp8LE4Qs423J5hU5FCY0R6x9m1upaniWUhRkd6fC4bULfUQ2esOZY3NasxNJIutWMy3FcR44cO3E4R9y++XkRsfTnnnUSJtLuHdztdncQjYXES52YZAsqi/Vj6+fHZv9LQ4dRmFkZSWzv8pV+J1mbPD3MNHNqR0zOht/87KKypx7Gk+tR/mOh/0n8BXOJCL7P62SxYTRzM/qoJKmRtKl8U8ap6uSLQNslzZDJMgi5dJPUb/3+fXs3p8iQSIkRlEeJAiLwyjKUx4fs0Ra5HsHnnDN7wVnkmzbD7TNB+BzxAoox8qe1Ohlh7VVsFHp89LNnMhARWVCWEVnrvvzvsE2K0KdIhGCSQwpXt3ZE0788XtZ56iHP+Tf2XPfx29pWCrBs1gs0VBpHAtibRrheEDanf+11W4l74kn86ZJPJq9fqVAheo249i4IP4l36WtPZbgXkJ3sxbDo1B77RoAA/zcekWiRXqwhgXbW/Z7b28ZrNjYgBELYA4EVFJRMaouzfrWtRfRnoeXXvvvBCLKe/qqniRr4rT7Id1MnAS9zM/zc/tz33t7G9vobdR4rBgw2IitibGRqWIGYfQPjB5YiNEYBYhT6I8ofL5iFkbxsQtUjNrWJqgMpZHChU7SSiiJF0+iJ7tvauVYXv4LrIiuzVwebovCboEgeRjfGlmn0NsO6swUMshAiRUyQ4iV8AG2T7xt323557X+/39Tv/Y+cKGqhAYWxJLKDjgPgGJXQ153z4yHFPmNn1xN9JnlATWt//FWCKmv3RZzVlLSLkjJ9BifQPxakK00nmsXEOxv8h2gReLf+TZfPQcZUR6gb3Dpbc2wZ1nyvzpNf5VeN0OIqMSCpj4q8HhA48obY3KkOH6vLXWoqIAU+Mqkunu7ATLgLFwQNEHJt76idlGrq77WbMNm/wyQhKixbu++X+vhpgTgmubCzwV0HbDRU672hGc/02ZDb1jwzPeFA4JsjIVcsIOb+z0rJf7yMeTlFYPXxEW58hRWBLnygoewAgggGh54GD3IAWGSTWCAMDMcQXEx/bm1O8pqAutB7G9KTgqtlH88CFDCACSI+nsdf2/xlwYUEPop/Si1aTDjXzQekIg2i4YCGAAqFSyAVQzy//fmrO27/9eXqsChZDqA3QGdOZoWHaHjViULOqfdhLRY1b///Xr//1e/0i9JpSqCUIk2SqZUAiwEtn8qXEG2Reg5QCc6YzrhMCGDBAZLxkmTUoAJMW5nN4tNyMvezm52vVrMYjvL/dy719mfbsmYRiJcW5bFyfb+5R97KCwWYZLNWhKExTgUshLhTHOqrxKfd6nSk7/Vse+pc1+KA4i/C4jMWIY85Z+1rmMMQJJ9djcLDC8rYIV5BbD/t5ba2ZRmy7xRey0LCQC2Rv7wQmFDvEnLaq44JUTVV02TXGCTAtO1ClgCC0WkSchaGVAFYVWFQl/WlO9LgLiwUmvpsogQPf3b8Nt+/9Rxdm8/CcUl4hIRIiIiEuEOg0iE++prHz9jrf5j1uxWs81ed6mYJpbmBR4J4sGDnf+/ObMnQzKUSYEz08Ygs8j+AjIcLu2u/+x1vude07noopkYkSASinlvd3z8BAdUW8PbWxUPxHn8KqKONa0dy5azPb4pgKCw0WhMsVEGzd5nCx7DZci+r2Bq0q4BBh790SyY+QhxwxfBDhIABIMBG5QXQQACtAQACOwh0UNMMAFGo0aIZs0Q7dohuXERuuQC6Z47pFdekH75QWrTQupKhVtaKcLyauDe6AYcBNBc0d5MqSnEU+4jAbSBksl23mcxAnBhGCE3flYenT6zDlyWWhipVdFsidnM2R83I1sT353jaRty1mVy7U0X0uV2muZt4Ksf0cd+JRjgQDHEkWELJ45tnAXs4CJiF1cJe7jJ2MddgQM8lDjEU4UjvHRwjN7z/S5O8IZ3EZ33pkyfgkpIJTQiKiY+KZCWmZNP8zr6+dhpk1BcyoBhS0xZZ4tdDnjMMWdc2q5/kxZ61ju+id8Ly1SuHh/CLarfpC3XI8z8SvwivetKXjf8OZ75SbNdz8CJOxGZEAZmiQXFMSPaEr0YNumPRgzB4rTDto+SJCOhUV8KDSYcaNRXq2WCYOMOBzjo/U97hBDT/GGuxYqV2GCb3cpZ1WnWZq4O511Vp9M0D3R76T1f+SmGGIiB7KAuTu5xEqhL6ieLCygkXe5FFJ0xe56CUH0UwOwF0FEApQC6F6AJADUDZBVA9wG0ECCrAdIN0ByAKgD6DKBzALIOoLEA9QToNIB+AECzAKoDqAmgMoAOB2gUQNMBUgeQOQCVAPQ8QFMAshggvwHkE4C6AXQrQLkArQMoDQCNATjyo4BEQLBxggDao+HEFUVCBgHRE3L6oKHYPXyI98GHdJsgyCvDh0a+H8D37vTG8iT/IIhGGLN4qbINgnLMibY5gpNzZV90ZLiOFRYNvceEGduCFUf857+I1sKDFdqCD6a8EuXVlWRqy7yU1cKcd3HE177/iMvrh9EywJ4ZcxdqPv+14wco3Nro4ogv/FdRy188bsa3w36MbYg/4X/zc6ybn79sBlvstF+VGk2OO+Gsy266p8vznP4W318/0yOgCrbERk65RiVJVlCawjKnz5o7a4EidZQs3VCjTVZcSRvaVkm7K89aXc2F1VZH56G8ZviyUPSaI7FrUC4aClIUZ3385Ki5hrJXAjO9fVE4rCYLO2dnnWcxpwwk40lhmg+y6JjaNZWOIukH7nzfktWRd+tOCoc5prCM5xWFFMMjoXjv96Ny6xCS0Q224qL14yR6P9hu1RjmIN4gzBhzlvFhxfDbrqMQ0QaZ4i8Wq6yzW5UGbYdMR2fXZzbrWDdEu9Z8xtEzTn1KaZ4uNDs5CbvIKjZENVxGfkqBWgTTOzl5w9N3J+9UxX7IUtKQdivhHpZ0nTPEOfpaRW7mnvBcaVFER2oyOOFIMB3PpsQQK0zwQrRb1XUN0siEjJyR9GZlvH1MxKU/BcLjEfrC8wDD8xU/63O++bl44ODRiaNX0EW9POPLoP6wB8A0nFsCqizM5cMNxv9uJlvXM8kMxrbZq8kCy3+5yKkSGdrsbc2AajT/UxkxXiT+pzO5QveE5yTJqduv8uYGyLlUsJa5vFgBCG2H66bfRZ861kccQsjPDWRwjz0lAeI8aQYJJLjUn6jlapBZ6/hPKC+OTWJkVYosg4LwDZcbN5nOgBTemURKkOuAUuW/gEJZ5GmECwMfyULmzvJiPo1L9yFMB1rUFah7brArz+WctjLdb+ougRfJ3u7G2VUuPMuNrMFpH3OgynxTzjV2zmGPCs4qeo/hoajnTF9HJbRlD0sZEVQA6QUTCORGO2up98etq70XYYsl8s2DbqKDwLoXPyEtWyZOlcHods/f702APmAWKxJ8Y5JnDYzH6RBcpPzWXzoXwupaujnBrXA6WQGn7mrtHbZ0hVx7YA0ysu63G68f1/d5b5T0VSl8FLgkmS/K6/XeR/VwMlo5kAVKUPbkA00vuc29N1QsSEgYpZOEz56o9XwfCD/b4FwHYIHwkKZSrKRPFril7K13UwUWSAsSlsk9oSVsl597JjC4RcV/reMYnLQD8cyzYmOkc0oAfDcXkmpd+V8kUcIbXVxsFRpT9UNL1vzt2Jprd3qPjRkPqSiX1lrvm1fLm63DVimviMWf7gum1rpekz/Tk70AYOnlRWX34WLEepvARSBYywWrOU4ed+b4Ca1nqXs6DDej3tReCbDs4B53VQ6B1YajyryAUFoIAVoDMDnnoE9Puj8q5oLX8B6Pd3OH5iPUSNcWcwu8m71eP8o2Zq0xOb2qrK+k3aM4J0MR7X7uCS29biEcq7BD5xSF+XoAW7cbeXLEY0Opqs5/9DP+M5NqyWM5YEbl3P180KjaCxkupzwopMPTOaUPSsS9KOgC8EfEC1TRyhxOKJ0Rm9o84G8BDokXYG/13DU6bTQMZHRam6AJ7u9deHPgw5cXGT3hM5DegiGQURA0HIn5U6bdi7jeWJAwsYPDnYCELwWVusJM6N1lFkf+F8hU/zNb3CTz6REGoS4zcGl6LBOzYD80uXCABZ0rAPQn4nGhx3/GcrEQylY9YKGmoaX7n+ghOOiw4OLxZpAkRao06YYboSVebknzS5UahhAJC6ANjkg4RGyQ8ObKhw93MjIeAgTiC6YnEMrIj4mJQpQogWIkCJIkhVqGQXTyLWS20mqDrHfMUG3aLNXuhGU6nFbsrG4rPfVMuRdeqPTKKwe99VaVD3zgkB6dWePFdzpRYpfyTupKfvm5VnDBrqdK5QYEaSAuoDMPLhAAQODGHQA94BB4ongREBJyIyImoSQFjMAEGA+AcYDxQigpAdOEChchUqRgkTiAYVON7qtAHyfB+A4G2sDAAZjJuZYOTiFwvWPTvT+XwBs52qpY88vIoUMfVL8eX+FpKXhVF0AEcXSOs+iBj5zEA6Z7uyuim5AizdBvkLoiIeVTKxMQ/ecox9sgwFhcAcYBDMf4FXg5gYFeXJjQGI5qRhfBBLOBtCX+g+nYYocShODG303g9OVmbSy145dBiqFfuCre/zsEjhsCAn80nPGYMLGHjYw90Ym9jBFLERbtUdPngVxxBGe4rUNRn6sWRU0VHV/G/X0UMVXzq10hp8Mgx+e5TNn5TTTd+6MJ2FrUNK5bVQuAHQK8uhtocE61UAR5rqB2ewqh/0xEAhiFKzxMWLX22Eb2HB1www4jO2cE6RKRbQV6HfDSniCB4gK4Rg6qhbhgXlAaSKfj/SaeN+mv+d3Ccn4S8qGAARGKSg7MsGrmM8Pap0/Ne2WmGdW7dgTUomUZZar5Tw5NYrFbi+vxOhGRiEqkSZSaaEKi+YU2BYEWur0s5ERII0a20aZZ0H/RmoPhTCSQVqx+xphuoZHj+sxBdOL0N9YMizBCwCWpINePN8A4My0+jkmrU9dPkGO8WZaYOPlA8UyhEg00wWxLwem16UxhkgyS6w/LgnPGw8UzhwiXbLA8f7KA2zxjPFOEFEPk+0sRzs/Eg4xRqqEK/K04CGc9bzyzUqQ0w0xUaDk4+7EjN9XSsUnmWKHObwtFzizDCJPNtbLL2+F1NcD5I1HEd0qLpGRM1oF/qCXZPyc4i0rqN2zSGlvsccQx51zzbL4yev+d0W3dqTkfjenp7Z7zVeeen/weDytzlmyFSlXDqkfDfhb+vfOVKRcwZJtz3opfKqsYwKjLckfcvvyioLctmfWosjPlK1G5Rvcs6E5nE1Ex8UmBtMycfJpFxaXuA73pjckehklrbLHHEcecc82zXvGOT3yz/HDu6c7+PR5WzizZCpWqhlWPhk1IjuIfftX/4fVFt3ILiOiQlDZk1KRVNthmz3JomeIJJ5xzxU3Pe8VbPvCZb0z7xZ/rf2dMmjmRkSFXsXI18MgAXGJKCCO7PPFU30dT94R/r3hFQLhUaFXh42WrwKpsjh32vzBHTpwtLSFmhSkCPII75CB5Hzo0/Zzioe7TpbtPXnd/rt0+SiTKNMgYBWaYa6lm7c666o4uL32kRwwxkVPuiZIVkiFzkbpKNdR4lkra1M7KIQCrUjic3chx2L+4seIMyDTEprQEVije7bpLm2ruXj8x/hgmZ/pnw1TOibk3n3EmLljVxm9gkzu8a3bLlrt3TBailDKqaOEiXfq7UTggI9ZLhxjCIHLoX8h23bxlkXlFr4Fr6tpyVV3Hr6vX06uHZkcTyXJUusKVF4JMBapUroAHBxkRZOrTlwN3en8HQ2h83msPqRAvpq7aG6oiYYXYMm081p3DC/roAEg0B+0wbAGD2VIqePOd75w/HFaVPnGj5waAILqvppGCuK/1yMyKjT4SkDDvO1w+xSxfK/50OJJNeR65Dkjsnnp5uZ6VeLnlcEZZglwxJHYvfVKxdgbxHvOh9DIHOSckdg9dV6qOIK4zbiJLCXIUJHZnnSwk2cRJ0wZa8Rl9byFhjumiM28+IN5pKBDFaeTaIbE76dYsr6OVVkAKFTtzWyC2OwxZ4MUq4pZhCCsKrwHXcdbQOFhRsOCQR0X/wT7weNABIuOGRYbZ1woBtZrd7bvDCtkl6YdIwAteqHHQZek9EAVgX/xfPdaJlp6jtktvO45MF1F7Wh+7Gz3VoLZK33YxRlqH2lX6eGPYpBmo7dHHN2OmTCTNug8lnZiUzHi/HbDHNFDi90MovsPWpeUjLOWvV/Fp/pES51DcMZn+Qv9QnK6FHf/q4QB0t+Z75iq3m7bKppdYNM0k4bJ07wzi0rRklvKstHDSnJdOmGZOTbPHyLY1m+dCEQvBAIfRFh+eAEMxL5WrlxZF2TeUc0MK1Vy4fe1oZ7va3Z72tk9um1vX+ja0sU3HApBU33QDYOHLRk7cOAXEtcf+ECIAhRQbikSybEPq3i9OhRZbYR3M/R2IOM7T1XYstp6pruOtZ6uvtfVcDbW1nq+xf1sv1FR768X+6b/WSzV3ovVyRzv5U+tKLXVAFKaAmJUSxl5sy6uosoNVdShrhztSdTXdgDkFi5G92JnOdq7zXehil7rcFZhjsDxVbXXV11BjTf1Tc0drgZmDOJFduRC/xQCB+7/EXHDckWCXvfos0/P9AYmJ/XAivCwDbnGQ0fJGNwAVbnbLH4a3IuVpEOLIltNdaQmw3UcC764FmgzccwUkghEMDkX/8GN18JhZdOZ5F5kHK+XHyCRKrGQpZppvuX8vfQ88Fv1/0d+gj0C2TGXeLPhxG0kGF8hlYjeM70dy5YHY0t8fPtxwET0SB9+AIEL4wigQYewz0IA4aXIAK75enNsIyQyiBQ1wuW1T4P9g/6Qwn+AfDG84JDCU6ekLOhutiG7T0tIXO572xegIoZGecNDvLaTfNzXjW/A3P1k8dQL/fptalzRjZTCKNDibWKFiDI+RosCCCi4kZarUacRLqDF3HknGIHswnCOL4C5Cf+4uD6BylfOZjGBunKFFBITyFfBGCRv4cX9xf4tCIA+WsGxQUctH/u9YL8oo0U0A9jfNLH9bY7NK55x13kUXXHJNp1tuu+OJbk89885nPvGFb3yVRDRERwwY0qZyixsnz/gqK2l1a1pYcYM0am5cjrz5ShQtUlut0RpfeVxncsldiuSaaq83fy0GGiSuD0w0xSYdiYWL0E9/WbJzAttAtZH1GCCn97plqFwArDVZoUnm+MsyFkWW2mAj4FzlKhzIqyVZKmpZy1vRyha3qqWIkg3AI+YjCRNIL9IgI/xlrj2qHI2OnPPIK3E++RectvgsNdVZX6Otr7TGXvWuPqzHKGfgbJpTc38JnIGzcacVr+9qt2LbXho/KFs8pjaCdwVuAk+BSCAVBAmUAoPALIgW7NK9ul+tWqP12qzHlnlCkXDtCiZ6KHoleityF1Eif1G8aIRorHetNdox+9d7IU2lfCnl4+zj4jOsF+vrA/oKYmAy2Eh/22kfq9bYiBuVKGmy5GnSl5i95uINxfxpu3vbT8x1Qp62YzoX8ApndpTO1aIMwVuBq4AvEPz3kiEC/dNWaLXWaZO2SCUd36w5xrvGGqzF2pqTZYN70QepAeSToBSfRNaf+5c1rn6l3li3xqGptbbWhC+dsPaqnRqCRt6nyC5XwEf/PhquUOkBH78kAX6QihJfnurURGvAx38APv5FV+nUZJ5nwcHMAnz0FuMZRsfQ8+C3u9/bt73bq21tkR20s45Fx+VHaXQDogXwNuBTACL2TS6BqKy1dLqzne9il+vsTt/Rb4wz0tEBgJg9yWMd9wR+P/BmL72x/HujhS7G5FDcT5CxNznrcmFTTpajso+BOiVX/l1KGG1cq9ypOAbW1IaKKnUr3+56CxdpvNzWdjWuQVJMNMlkU1iP3ij6XzJWaI6lFXfkH2usr7ztN9lclmalCucrHZGtL8pZ55x3wUWXcnHNLZ1sSusWROnc0PKJz9pXWWFmNQb59OMX2SF+9jDdZTNcMdNVs133hxv+dNOxPM111z3z3DffAws8tMhji3U5HqXYcy8s99KKvKz0yiqvrfZGibdaE2hLqNR71vrAOh/5N5Etuq38Bzv7qbVdL2V+ssMvdvrNLn1wVQDXhMG+cDiVxMFsoComHIoF1thwOFuoVpujupzU5+xkPpb434l8bdPDf0k15epoHvaEYH8E1OTA6nKrsshfVBZ6ZIih8lrcaN31NFyqvkZqy+4l3nW93c4Ndb5+TvMHSAE2r+eMvzEKZN2cOx8SNXLqzUr8zKv2K1s841eqP36/CJ0BDPMC+Yt7iqWzJGOQ57LrvCf4hjhKO6ICT9SKFdDMi4pViBdfsQYMBzp+dUkbbhExapHxRsu8eqTw2z7IRlbZpIF2vj9KpcKonHZv+xPjx+7EucNtvMeJjltByc8lBK9hz8bdUL0YqY+rOVsMJqonqur4ZXUYwM92Wvo1ngWO3bxj2AmeNbMvv0NlzuWv+/Tr+a+OlRnOv4/OHwwFbU4Dz1j9LVoSSqPEIp9LsED+vbwJ1GNimKcN+F2YkmkumtXNw6qR5Zx4D8TDk+7XmmNhVK4fpdO+zF3Pc+oimQ3JSDeLPbEHyF2KWsUG0IF1SwNIcqeEMSqT63Pe1xdzRSKpo4b4cIkthQNea9yRjp+jvGru5vSm/7IT2fz8I3gpez3W0+cQP7n0xYKYNxBfBWO4NFHJOF1FEqQ5HUH1HhOqlI4qIBjWSJTWgmznGJttngZiOp7n/NRE2pd9/pNsyIrt6mwQIz0mnk4nPtcQxpmL4mwIfRWX3JloFtHl04IhoTOgdzdSnDySOLFyVCvG2+Cnw9nLpmnOTgA8M8IjNSUHnREZNDvn9k68TXxFAaVa2eF/aTZXFNFqQF7gm8byMxfVMvgO3rm4VESyKHLkXDiti5xPCweMyD+LJu0SOaeMt99CsU5rD8h1ZX/UlGTwc3j79THtfCsq7ZsoQOZ3bbhMIYty4EbPsJiW3hP0J5GTAtZsMArvymmm+R865OZ+08uR2C3uqojIs/JSauxxxj7kjMtM+Zm/BQvAbGxJEtufSgjPX28tLBVUzbfAYVR07EZlJ7KWFfFkf/ocmJfLoqrMk+bJyVK2BxJ+8rn7xiUqCmi511AUKqQtVElHqJGuUCc9oUH6AkE0gSS6QBFDoDcmENHPypDffguCmpUXTYk21WlJ827gvWPWvAh83GUmlhg5i4NkOXpE5GANLDDBBgUHFFxQ8EDBB4UAFEJQiEAhBi3mwDpYSTE+cj+jkW/ezKdGb1zIa6pEQfNWa77ukgGAGRZyQNKyGHX/lYZjnAzpw0DpDuxI21wcNEsjTHThkTFojnjju7o4Bp4TvWGCJdRgZ7w86WR4F80L1D8AgMebslzGocXmXTIF1jEjPUccJdp8Hs1QX1+vOK+XIrNy7eQFSlVWDLXLE46mbH2d/7EXw3BC2HUWd3LU8Z1Qmbgy4fFLEKhfaEyb3ZQ6uVLJ90lLTvfyRQTW8xydrLKo+0qRSGKYefBnezIZX4QD00umW4bTpa6plR2BRHawc9JHqUtVNaKlox7pJHXGQdhgGkT+SidnjGjlXPH7kkBZkqRPy67NQ/beyoIc4YARWVzsqUaMOBN9DUuza408LU1AML22qFbUNo5mY2ItBh2Z7kZCOVlf3m7eWIRVWg8cEBcwsS1WKKFCjiarfQw11sU79miAJLNemg62qnkdt9AZ9JR0daGMCPfE7qoIXn0xYnDjSm9sfnMYokEBRudz7zF8cl8sYN3qUobmtBC5f+kv7lPjQzvf2O/3EVz6YKUncOXZ7FG+DjK/U28cCdYs1eRsAVU240noucSqo3TjRZP6Lahlue+JFxTYY4r2Mpz/U8wkGNlBG3bsuiw7Lyvd3kgk141g6QLRb6to3+0lVxlh9MNdvKXymRHarV3OBafNrtxvfUABla80Z0Z7LOuLB3m6O6DuCGr0+bQIKvMMMEd35Pe4F4wCAGgOkgIiqSUQSAuSTAuAY8gKiOSWQCAvOL6AAwC9bKEoIlJaCoGyKKlcAaAPqiIitaUQqIsajfGgCk1MCFoCAUmQyC0ATkAREMFLIKAKco0kKKKOKSFLIdAS5W2ECDoiIt2lEDBEt1EUEDZ7nL1L874JPIDLMDmuJODWrE0TVhMuQdGWIHF6QXiP0AuEQz8QbrxA9BVeqq/klQTJawnqb8ZmR24hB26hBG6hBm6hqYh0CQmJPtB8BzNwBytwBztwB0dF5ErIkxR/2/HDRLVffIa5sV6p7gTxzpvplFSXOVmTfPyHo/6bLQcEyn20AcB3AaR7gKeA7u8DDPoEoMVwUP0PcM5fe69m7Gg3Qh8lTKatSP16C1Xr2P7JRv5wQuTnNOgFVCirC0x9lA388w0cgxV0iWAyFuCIiFCq4IjsLA5BpxfgCJHGzAtkAm/yMyzNvQyJomXUEN2KMQpkxFLPW/gIZVTFbxESjfLRgJCyJZAbyrEENklAENOWj9YUMe1isP3pgKULgf3+VgYfi9rDqMraSfBwK1AFHVyRYGWW7N60OcC6RcgylMydjkwzoQJommXSMs/S2LYzBxRHKIo5jJlO0SPscNUGnYaAj3ju72md6kT64YZfLPwrUrAQB9opqVLfuWSpdIZn3xyazTQIvpFv89izTjJNhBcdlu2oAy/w04NXsxECMBjhw05EXCj9Gk/tQatt2OYiIQwxF93i72WdSAqh2EGMg6XhGW/bZ5L+Y9YZ1219qM2DzHjea9o1+6JURymVhyYmojYzd3qlQCKbIPhHbLWnQavbJdJIzeShAQI33ns1HcAD/QFE0lRXTIeI9YdV30/daG9qf5y0pXJebuK/Zqe46EOgdaU9CO74Cy4ANTswKQ3kiYhk5QfIQ1ZaEExc6MgbZCKPJ5uI45yrXMIJ8qBy6etWiXOCpIghoCvil9yW4wgX2yuQh5N03yhSBZrCELB8Mkeq6V1pL2/2VSkqY1vdzK2HBD6z2z7R8GZ1WLcPcioI04jsXUmqHKUxVyhOIkpVzIn+nNZWtN0BYo586VON5VGjKRcw0q+Z8ROxtSzFizG6ac2YsRiBJieODYvEU9o3EjTP9Q4wjj8sEH+loyH6fM34XH1N2HRBHxMW6pRTdCaH1H7vVKGn93o8xCzZ1qfPCrfGRfwKni2arqZexRpQhaqORsoRyiwV964zE/i/Jo/jxgMfS1qp0VrLeTaXc91xVmcc8xQcBXOOTTCFUSlMvs+3NowSDrgyCGLYF0HEWhQQNIUNjshgwA7QyP8YyFe1mA55pBYoHw69Lrfn7NC40TuvC0V2+B5hVX8z5rHbKU/qZw5vvuI0eNLX9m2mmJCzAUGVvsS+Q2CgXqtZhwnk0PqaKjyz8KiEGDvKhlFEcaBNkaQJjcKEYOlGWmdrpdFKUdNcbyZ9tQTbbqcsdbISFq91wDoixKFvMztC3fQuR+DDjHLT49WLIt5qaxN/BSx/1hWKj4IL6eiPqgsVuZTu3M4be1BLdl47nxRK3qKmmQwC5yKv7PRfN13fWAgEPzy3QtjHTUX25F6ORgNYCtjwp/I4hV3ORjkTTzSm2oWq9Zr7owwFWhWCcDxgDRR5lmqDT8NsZ8JKM1PrWXMbOVaCmD0VN/0ZqMLQ7NdpVacbtwsGDmPJwxmdFMqKLgL/SYbTPVLFS2neTKBgYhrgI2XlADB8zTN93No2t6a4xR2Qb01r7+ZyPmW5X7cVOWeCRdBk/m1YBzQE1RaWCatI+uhYqV2RLIE8biPpvxDLFiNGnZz+5LggbJSwnHkWkC6BRG1t0nY0HI4/lHp1LdAQcNup8iu9adHPStnNQs6XsiwFCpIelyfyOAcwu6Wf7lHxTdZuuntozFCWJvlxt8ZQRn0rny9ojlda2D5nlIZSNmO///LpR6t99q1xe4pPPv0TIWtRu+i2+hJ7T+BBml8W8rzhtIBpIo8z/bmfiTlqzHykuVaMVwEaLMkJS1+YkVq2bC66mG/8vSZlHk8Gk80k27zyEcLaZ/XLj4f9rx9ntGTB7MDCnFu4Y8heldw730mJ61beqpzFrtxmgQvZ5JD64bHmkTmRg2xQcbniJr4rtviP/Lrf9/pzvySezCj3yzmmi9/3JdEP2e5vx0SfvOPvclrsnXZwZ90hvzUcZ3NB3qczkSNsR3fJoq4PjRm9fOYnHFeQhCa6bbQE1bF7f4Qj0PHbUuWKko9V9bMcqzO1+CLOw+jYufDjw9qfSWzUjFQZ2NM2uREjxSQzOiMMKbI9Uj0/MoSYNv9fwDGRP9W32SkH9wp3zqJamKz806nvAGOWNCF3VoAw7d+ASGPjAcelfL9Bssa40dJLwajdB9HMjpUY+ryqCcNLLJJ3QJBvg+oObDAkeMVsly3C2Pu5je0KEDzXFsQwEEeG0E00ZPKloKXO6uhDpIGimDYZz5Lqqz6y17MjG3Xk3/0TwSEABXIVe69Z+jcsHuJbeDCXbVFFy42vF0Vz5YirDsODSHU/yROemRuPfWhvJ1D+L0Z3NWrJF12vhlRYRfWz3Joq38Sj9NLLVH8SQSnBfvQQ8s+dmInsHY5jWc/h7Xenf0ii+PEq9rLKPWseckDdFnhh1y6cjFKyG59hbcNJeT3iKgCmbQsNe8DSDit0v68oEjn2LAOdjEaG44TcG5EMCFQCauALgjPj2EIhjIf3cw5rrpiQgwPdZHNUA0dMMnrHbqAhaJn+Hjj6N4KKbYt9rrBU4mSH9oOzMrORFCDeXf5xpDC8QFyXODZCWcKwtaSwFyTspDJ+wVKJ9843gwmO5YiBYAzHIxUh0WtqIDBPIZdCIlsWiUqe3fq9GYDuIFYmRYu1u1MttedWuZHc0SXyq2FX1vLhDl22LuYFUuGPFrlK2HXO+qETLDkpaQhU9otAIE/SzkZs81Rpq0Y3SbT3jkZ2T806xMjGmtouxLfUGUiXsa4FF1hcR1nhU0Scp1xDu5xbNhOUZc4Zsi0a45TynFY7Zr/Fhfpi+dEETHFaefYGXKOPmeB8gR23WlJEELIsm+oeAzgSIUNGlQ1pTJRhhQpBa6KBing+uMnRumylQ5/9j2BDkp+YVUj/eKtQR9vW83UkMnD3I8HEU7OWBf2bon5eKsgTVxw1nvPjsxOW/FhQQaFB9nk6DWL7ryBDHllEgSpoFFNQNPUoQyjxW0dasRqIWVjM1Ck4FYYNVxw5AieDhj2PJEzTiahniwgXQsu1iVfqxjmHJTazu00TrAyn6kk5sAfAnmY/DhUlNHvq4eumT2uG2oCQ4NQO28HrE7lyZjpv9q77EQU03aakwaRr16Kv6CDrvYzZzngij5+S5is2/LxLE1NIDIhsxLHNoFmNo4ceAVWNP0GTgVq1+33YA6PG+RCP/h/fvt/jpFj+SWzbjUB77EWhO1o3Kxssd3OVdNp8n+l5M6VwUb/sd3heWc7pW48ZMjVfKCruhU/Rfwgm92xRu0uml2uCuPE+2BTzdVZmtnSnTmPJPaw6XxK8cmSHuo2Ql0uf0dRkVMjykZOB2kuRMM6qwWe6HcWr4mQNbKu7m76OsnZ9Xj31pSUVvxp91w/IYA3GbCNt8FH3KJDr121LIp9UU2PO7foGH3YgBSH1TA0R8hHBZGa8VDLDyVls3anMaxEU5LNBUFeQEhEZiHDucNI4nq5caUiTLl+cyIWUtqzgzgLfeHpP4xEuZmS4K7e5HHTkdoLBkJYDuZ1GeMjcWXtuXpB3q7Ni9dAGqxLSXVQUYKDryO/CGcvYuwZ8ktvop9ihzLdxJ5j2rDFhCnToEkfPAir1RF6kMccMMKaUaHCkrmlpBMApI+Oz0pMlHKH9yHBv0tm54mo0F1FcHUdvh6SQHJfMYAqjfCmoYJq4Sgp1K5MmuD0V0vWihhaKpSjSOGsXgi7fJ3GXen3mUdin5djDGRzBlnMYWewQypKeFUqz3Ghq1Jq2Ge4FyZ1Rv3qKeTi7MG0b6MdzAdODGiXsnY/CVJnIFW9LnMQcmafMWHrJAUe9UK09t0P2EMCFfQkOHHaDGYINluF47WuoLOdmo++0ggf2ufn4x73AoJnSTb2O+RWIVHan8WtniuaY03zmxPCCdVedvYYvQ5GHMpOwBLoIUZP9i+qWMegGUGaPTBbiSPtKYuT+a3OTD6dR+72Qdt9cF5RHDnD5dUDXxpHuq5s+6Ouf2MfrYPn1KSrdz0n3pD2n7tshn0TrDGuJywdw/QMZFPYC3LXEBXLd5/sRhIldfDN2XVguHjUmD/YwUKGuuNCtkFLjRRrfI+UCgprq/C8Zb/d7uqOvredsuGGgS9a+eqWd3I6sbARzFqD5wl1qTr+V1rYClfaj2kcKLO6DpNcKhxSEQ7mzoHdcs8NPe0HpTQGHj9y3Vz7P4hsubJ6H7vM3VZ9JcLgQ6Vsu3Gc4vzDakzPZvn9uW0sIP2Pt66b8EWTk0/24ms31gtDFBNq6SltAo2wBOY3dneGHvIEhVnLjUk8RtWpLa/+n27+VODPSypDXBQ41OljM1P+voaPq1cVlYFEum87ghHLBPNllt9XbHCW5jJ3U6suaY3Pu/wE4sd6ZcTqwpOcmLubo6fxwcpTX8MO93e9K86YJ5MKlvtobXURsp80CzT3jg2/tAZzmKNPfnhgX2KtHLN+Fg9HTifavX69qhs2xMvdRcDXINKwffWtlS11+/gDcT8lE9n01pKGJuyDzCsvIcUNi0GOG/FQhaOdkg5QYq+ibpithdFBe5dvY0+vAgx4ya+BmUr3HBTF0y0WGuCPTV17PLVQIWSYwITzAoUT0xYbmcNRBbIyDS6KrhHlE5cYmxwAWL6ccEeR447JgF9PVqFW1JpypOvpDcDryGu5EVYKaJ3d+uub1bC9lt+JJVCnyvelNNsnZWgxeRy6yaa3Gr4umDk3ruGldhH1z463++LtvZmZHWP/dPDtP3Mxt+6WjTJDdV5rnlbEK5+35z4n8Mw00VMEnULqUgWDS4ntgNot+BFvph2zqH1R7CQAkZ96pQWo+7aHy+zOJVweyT0FHRRdjsuSrFBpwXPtTlMPmNYoaqGqyUdmiFCsaO9lQrnT0rRE2zGPxYSm7avjkMOEVKu119WmjR230kURwtxzqtZihVLcclrUzYS/Mgjdbg+ZlgrYW8aTdLl7W1rKMbzauk1Bc13IsS7ltIdGYxWIhwsfA4lh/dz2ckKq6jSZVEhKwz3onEb4iSUhuxRKsr214KeF+XRwXVzdsLNaN8CMtwmWdWbZvkbNBj66hhSqBk8NvL5hKKmCWCy+xZ2le74KWtmQN1WkWQGnXtaH61vqhxZfZyuzhegBRHxWndJtOdvF+8zWw3pbcH7qvlUU7+VTHtSFTjXHFHDp+/dqPZY2tH5KVukOVwA3EeCmthDa5ou49+K75/tvvUJJWqZ6H/x9YFvvPw/o9xYySlkl+tEW0bA0zRPjQ5jSclIO9FgsBKXDiOFWmnOG6lqdOylQxBGFgpnrjvTX2tY/WctSI9Gtu1OzDbW3u5O/0gUvdJV68p2jlSNv2yJBxa8S6Y2XEU5RVOpVWRQfL0MzGnkAd7Lo2RxXly4JyWNf22BPs8V24Afxy+4oXVtCOMlmHxahi32IbNagS+ZvliKKBQBkeoOpRBp+a32BGeC4UTdcH3ffxl/zJ4M3jY3EPRxaQbSitTwOqOnvlnFp7gpR43zHkIOiyLvxxks8y2akcjp3KMvFPDl1wWIeXa92KBNVhYLbXUohXV3xC/ZS6iHiV8NWnH8aWzB3E6LbMrcRCNu4+UHawjJJzjThPTPW0PPRvaTJeIFZsIPnfGf3HVfs1+8LZ13/VqZpHHyQTfy5WuSnBqspL5VUZf/ACAtDFoloYcpWjiypjvFBfIH+oCNSjn5Nooym6SdVKE3vg93H2u5xsyGCW1vxW7qeC2GTyvzrk7xQdaONKjQN6zbjb7cAbGaVtXMDxeIhlogE2oQjZTTQW04oYNpGQYTXRn0S/pzF7XUxzA8MqFTCsNhqXrKu5Ijfe6G3g2ZdozWNet3l8id4u76DQzCGmic6wCkUMm4nGZJppgE0kvAAi0YRSDnSUKzUMjgnYVYM0ykXTU5vML0p98hmJDaST3u6UjfIQ27jeOOHq8GXPhiSVYL9duCNXF7apOS6sVvp93xVb1MZXsOxOCg916W5181BtXRoQDEeHA0MvubzTMKjVjAx66h3zv7I7BldDXvMwazXTv6aDyBf6iDydsKY2yt6H/J0W5gYhtSUabkn2mYdSIr1BrrQj2DRWvBb3JBb7JO7rIzer6ca0Wk7XanBUdOxsdVu6Ph9zRfxG+YYEkb/T7373cNmX09Pc1U98C6kP2ZNw/2Z3OdMdPNggV/b94NSbmsamg7keCBS7BDkJPwTpw03htOexkZ3KXMhp32wuti/Rm3mk2G+pxt1jY0vO4lgxmubXTZuc/8WhUndTDrkYyl5hDjY5j/GFI3U3hUJHuUt2VONid7+bJzeYIXYKm2qfa1HLynbCfxQvzBfe0cOsoDCrwBW3qwl1U2XmSxX6ZiJb2sY8olbNOe1Legpf+XRNEg+VSbUigcQeAURfbh1aEl1CJoqxda+gvA376mC/2iB2RV1DkjwMti/4lx+GjS3hlmTaPJQQaMAwf/EhZnzX1t1be+MXgpDf35/sT1zALFqwrm9dsmfzyObu8xhK5iu25+2LVlxec3n81cILDqvWXFl9hVx+Eh+6J6/GmL7Muicc3b1119b5D7wYg1OPENfXMezoWEX0gL0mVhdlPRZhR8hl/48/imPLZkbltp5QkL46+EhWSNrf2uq2SDbyX4/YoX9/clL/ntgpGPr6P9mcQjz8KINT/570fjFqoXYw+IYvdizm0/749U/D+4MSjUh1q+YsPUU/h7qlajdVwvPhS0KY11QgBsSoXkM3l+B9Uf3XdXjUubRna7LOs6IzYCzz2u3Pxl3GYi8Dcn/VpLKwk7WEjRjCTQFAMMJ0bnZu5BV2KrMun52R6c+2dBimy94YuY3c8GuLtxL46iUxomQS1oAFdrmSXFZrI9M/lQWIBPsCi6Hm87SURv9Y4gU/1s2tJpQwdl4hn6a/0TRQs1/an4J/q+JRxoYPmnLj19oKbcMk4DVppn6LMSvwsTg/+qkrwoM9pwbwHdQi3IpFtw/SLkMR7yu9LOKQWlt10dfe/t5SJ35wNT7SxQvpehrNyOZYQt9AZ+gaosz5AO5nwFVjJpFNNagmMim45H2Mr2xHd+My4kK4xhS5+Zzh5bw+hTijjp5vXMb6bvEZBAMm1tBZ/nSF4phh+UshfWvfS/6kMcN3qXVN4Xhk4dE3jX5ivaloTdIrUuicfqmFh1TxRaFNzM7s3A81KuYkWxLLzk6VAlEE0/5kzpyRUgAWkcRzMmJLYpB0ZmfExnOYXnrpM/zoGMJcLWsnop0c+P7q/M4MFX7hXuBe22pDYIPfa36npM1Y1AaDCjToBXyjHgSN+jPRGIk4UoO6ibZo2t37ngxOeNdI2joEK+3Le8/eDCx2jhJPUG3Ne3it6dvI+gnbpQVh/dNLJk+bY6lzmrHF6kOhiHRRSMpn+WiKFxtZPFlYJo4jGnEsLJMxrPWnX/8fEXPCnfOsCGBjiUeUXn07X+AVCcmm95BFFBtNyNE76zh8N4Wr54Bm97G9G+O4nixNR25GJmu979j+dcFG1hD/3AcUggfLtGOxF5/c4hn5PW7qVO3SS1pf4NM+JGEOf2+v0pbDjTIiWZ2u+B+RLwCdOJqyiXddzaA1k4gzIvfl75sqzRUqhwyPQdxvoSE8h2X2AtVWUhaewJjCk2gYrGKl6VYbvgtfZALAmEwRQzSKWEwGbsFvPgfMCgBUarlMhcCSjWfqIkwGgUIhMBjzCU3cRjbXLRBxnY0sLtfN4jlFIrbLzRKd9kRw4S3EbXsL+JTB+BRgJL/WcYK9GEankCFAVCqtTb9UoVs0k5Co9DBsMoHglMm559AOABAIaBGalgt5dSJECYIGu0FpWGzyOZGZRSbHTEO4msEQiOjCbmGbRMWHQUNke8vEE5f86MagTSJsahYorD3wG34IOtLA/olIPoRP1jetPh59iuXocDeeHDoZsI6uhL2NgwRvTskJvuax6dDRwamr3ySkV8oT5beQBOT2cmRxGSGknoXMvvB8HjW8/sIFkWOW/vFn4VJrpLgGQRi1XN9klRpCP/MmLGHqKi0dLpY+ULqdg3au546OQmePn7Vx522ya+w9nJEmyO26NtS8MWi1XbXmwdoZThYzX3Rne6uhdfCLLyEXNDU01TrbvZQvo+/AOBsInD+G3lKJm9t5sLVbfywqeBCgsd7m53X9+rAxqzh7yJbtAZ/SMPiKpTmzl81L4AO7T5YmDgVPvnDGVK0JQ0pZa1IstINrgv1sVfYlVYi4kbjurOYORl7yRiO0gafhnQhnDdfpB+B1B+Pr766HklJV0mRUdUd3+gMOtpjkmts2If7d5knRWp2U27AMlQPCoShXLutgtHlhNrzVGjRN8tsi4mUOu2BZuGWMbyS6K1wcjYM26AB/ty9onRval6mTub11InJi5zva1SaTcHFLYIJjNM1aJPCBdTyuWf3OjgTcXG3VMTp0BkVXpxhUdYkVXQYto8Oqr252BAItx/Y8cX3GsH0mIYe/tVjc607NyOavde+buXXcaQBgB8xLj45b27r+Fx/pA0HDyoVbDIsj/V3GmfEM70zA4o/H+45cmuE19D8riI/CPYZ19d4sQTOIb9AjJh7jXwuGgX/umexMP4HH9sx4CRJ9RG/cXvld9JvMgAzq3NsfMb6f1aCKhn/Fh7YKJWGlShJuFcoUEfx0qpSSSEQgD7FglUgMK1lMtVIsUqvoKpxN3t7FhTCa0u8oIJMhfKyfWEsh/PGtyKzi8yyNNJ6yXR4zKLoJ1AZi3lyXYbBIZODwi6ZEByobJsjcvzSkRX85Gi7iQVLFxi2AWs0mk4HnBsQ++YyAAWml778PNjJpFoZc6ehskDFfODxX+p0M0GCelWjZ3Sy9IsTqNXdy5UhCqeqzi7bmasM2iOPEamCVbDEPNA7ogJXtxpmVff+TF+sXKJEenV7WHVWqGCFS6TfS0HO9CBV2cmtavVQH481DCYgKu3jb1MPoEYlHvbBPpe0gPwjTgfCvZIPDBMMOk9I0m4s00rsUQSejHp77abBaz+fAaXmdSgtKTYkGkb9cVkyJMT0e/y7sXGZ11Vl3nB9B7jB0Kr4n3VydhKL6ftwees+MMqqQIHhLlqh4Vmcdi3Yr1zNyN1AODBBbQmXzLjgEaGk0FE+zaWkAXUejbQrNqqN/Hhe55J9X5UEa6VfvW0ZWGu8rw/iw3qxNK0Wi+UpEnVSq+u3CNTm6gE3FduI0kIo+wlOre5Vk4XzlRqO82G0en9Db1d0rEzdYtXXB9rHgcVzRhoYl0puXMU0khpbNmSFSTKaZBGg5bAC+7OVthkFQ02e2agYH1QZplIkyzv8SE1Cag80bdAHzMLAWcI924QRUTemmF83/eWrgqijjwnD3ZOjM+zPDCvuLf9xvqrJHrSp5UztXxXDW/lgQrx79lamLZtfGPmNXXI5yol1UwnvVc7etrfbcK/ZUNaoNouVXUlc6hqdWKNuTy3OUtJ+bIWnSQgXFoCGCZmmxecRtPLRggaIISDNbIBs+NgYirfQOTUxAUfL33bh3IePNijs62hleGKxe6Nrkv0Yg82Rcv03nU9hkXKihQTx7IkF6KwySkKWh8Cy8qUzDotuVfLpdp3IITPyFaX8CKCkOjdlJUBt8Q8sWydVSgJI4jW/rcoKvkShL3/wFrmcHlG8N6Ryz7B0S5IDZCtdDdQXUKlXAwRQf8ZzUe5QXxo40x5pPSquemxvy6K6SETTKvZiGpmEvKwCGjWIJBNvEMg0iwT/b6OeMzE+gyw6evYmzRiAgrmAV2xfq4TXt3aw97miCJTfExB+7EP9JwBhN5A5eDjUIVF0iZZfJiMTTYlNSbFHAsEUhnmw/ZFHqPOUDgbeGL2ktLYl/mh3mqZtNH5X0k+r9IpNYKoNIJDSLZdL3iUAL3OBwrgP06xzODdpJbT9H24xAiK/zCM/AVSkbOwEl2AnIG1U8jv5IJ+yDECTcz9bg7ziGOoYl2XKnvNwdOCK3cnITqeiWVq9b116ut+TarXdcyFs3wJl/T/RXC4gbWdSKWvO3bo17uwZ1swfjIzHvlVvcw137CoO+Uhe9UmAzsPIEahxXXq/gNQ7zy8GxibPDLWdxQ2MtEU20vDfWe7br5mN3dRoDyvQOJRqoPnukEtVgV7zSV507u2E0/kfnfYCPjGygQvUUhOOiulCoq25y2Thpz5FJUY5vRg+iMQO3hTsw6M7zLyQP6mFCMkafXcpkgYi5ad+XvVhZeam87FJlxWVJ6ZjlbCJ+9u/DQO7QmCWS3V/glAJW3sfD6j8WUJQrUUUVNXmVmCGApYKh7A0jXgJTmTXnVZLpzwhfyi9+D5RXuooKL7GZ9SJWXZ/4zy0lmO1k+ttX7F8SFzEanpeBnLdpj52qrOzJL+ydH31sguf8Wlv2f6r4UxlBGMTscfocW5oy5w+0p2+M/HRLOnv2PJibNLHAmrPNqNubUSQsloSqvhx46ctR0Xx8yveWT9CzlQmrlWZCsri4gGAGIaj1mZAbcQu+A955J8JhWspmjRiIYKNdJ3zb3GhBkMlsVm1/ztIp5DNiuMn4Z5f1Cznya5hNpdogQN2bjhxXdf4YofpBeo63e1NZNJJLjbxYL5rdGlk3ZOn9O0S+z/CAehed38J30TsfhneayXuWniHmg8XFsJf3WteTQ9c9DD1Id13gDuzjZZxgcl2PdbmrbBa7dVnb1zDN8PKe+yJrTxdjw2cZVvRaKjjhzehhXO/AsqKOXGz4RZa0/d6o9i1bnaRRHW3UybRlKX6Z4neXu3DOh8ExVsU7ztwmq+2J1oTn/MLzz84aybki/k34f34Q7WT/63jU1wNPYnQj3QK1WmTow/Y1/g4qaZYPf+u76/u+7Vr+2OSGw0enE1uOn2P8TtKHZKIuNcJUSCoxDjg4atey32GQBjN8J5IpKJWuDxvudyo76g4bx8ZlR+voCo1MRtpfs39SSsZ5QA7YTvPq/XV8TEX1nHBr2Ii6+G1V+PDmgjoduqImM9LS1LMe/7YisuVQ4FV/jgMWtNeCKip8quxt2QeYRpDK18aGc0zOXAfNLl/XtpUzf3vJ1ZmLt04pa48rkIycRGDg7LzrFTESgXL+X9zLkblPdQ8Kp/2FIweajLxenQ1Z3G/UZ+dP1Rf0feOgaDTmY/eI4Yxs/CM/q8rMwVnT1m4Qcx2HCeak3tekjAubOHMjYMpjf7sSwXjmx9qVLWy5WUceA0gKOs5y80nPKpV1HusYhZmAZCc9l4WXPauvNqw4Oi9Ii2LL1Z4rwiv+yTw1dEqpjFd6MaONPYorFn+jBGqZOyej4pDyVuNB827FusaJmiez2xXSgXnau8/bk/ex41W/cbd7tzallbglMx5lNgdSYWzgGNvNFdoCFyqzgGQ45KBcuZVgh97A89FqXepjyzQu51JFIFVmtLvgnJLcLDbN5LKUWv19y0AnslhiWtZBRIoyBi72j+SJMgLtfkvV9nerQtur6pDCPE3E35oRyGiK+s1V27+tDg0aPkbWt4yzvTdVfky8PXRkrcALVQ4reUbYqkeciABxIbtuG/udtVqPC8kqIul2ZLTTW6vpcxqNJw1V4nlHuDf35hTT2vQ3sotnHTUKHitvdQzmJO1FkyOsO7Hx/IlwZFSsz8jKdmT776Wk/R5d2FVUfMn+W4M4bKYLeicnF7up6GKNuY5nzYLOwOHWMVMZafpoRCWOW6qKoXa2pFFEvsr3pDyiFzzwU94SdrCOCVFgh+Tv+QodO0SRO1Rl3U1sz5RX9IUH6q9qeJXDRYBLbjB7yOirtieqE1WbPNWeN64PXQ+qyqMH6zybMp0ZN0IIB6N3PQfDn3V7YuvFxq2nWcN7yzMysT/7MyxYP1QBE28PHn3O4ocqwDfC9T7ma+Sqc3u7gA9RNAm70cMWC422S2jIzSpr7y/rnGOQL+g0QnmLfYuhvA6Ton+Ooayzv6ydBbnRl3T9MY/X8+/nSFICRmEIjCYlSJes1Fsa67R3/dDFVquEIrVS+cVg+cZGevzJnpBxy5JW59zCIY4C9zzib4WGY25f8ecLPOrYIfAFv5q+2QuvHDIY84vzHcWx2eW/lcwYeVfFaA3LnvjHNvDr4cwcPPrbPyqQ5qdbh3riYqvHyhw9xlnITTPfOyoePSPrk38jM6+Y4lh02hHkho2n9bCtnFGj1GOSQvKylPqGOim6qXdZhCnWIWF1p3naJdVxVPyhwVi/ZXmbWOPRMId4s7krMhnfeY7dFa39TCSB/5BmDOb2uuZOjjRvC/U9csYNO+OSbR51yFhU/5MzxGR5YSa03uKbnTPh53ebW0dNZaR758MqcUxkvAZK9RrxSE8c1VZxzbfhao+CvgKsrRP8P7n9cuVSlDJTqn1b+4P2lPZ3+9VrV+VeecTL5rlFNJqanCdtkspkgSgXtLfWM7dOvD2xs8ZD2f/mqTf3TsmOHy5KkY9j1SVaJaXsnaAxAGGnb8Ur8ceAwCv00fGowl0D+Dgcl0Lh8Mk8iuQK77G7JvEaFF6ImGQyxCQ08LRGWUe7SAbHFYo4rFbEohHcN7IrtB9eMADtCwahfRfoJg4175O5fT7GxVzWucMG4yxqahrmGg2ipiBvsdEAOcZiXuPLp1UWIwxDUQkSspjuc12szv7jFOxi2jHASoQsl5O5qO2MoUaFKrl7kWqgE0A8hFuDp+Irysuvorfxn+NrXxa9vPulR8qMy87Lqkfindr9Deqt25KX1wFmGsPE4jAMMTvAMNH+U4bDphuNNJaeaAeAEjJ5VgDdIXEtoU1PLqtXF6oLx0r4lkM5nhxn9mnncIG+pVg57w9Kj67kicXtpRrU9NNvGIJfnZpWf+xHtX8xbZi9s+pjf0ZQg3q5HaP9pdyQJYxQ52Rhm/+Jszz5O8+6amGDy499+FKogLPOSVQYFe83l+e3HRdqWOjS23dK5uir+yyF+nTxLa4325dzhG4TTM7TFGqLpryf+qz8NfK92LznfsRVa2Y2ogzMProRl4+toqvfurh9Lf1rRt0sbmHXm51bR8cKCmU/PhcreIW2Kp2ybYqiKdQUTjoKbEdzvDm+7JvcdHFRorlPX1V2p+R2KZol0Pwvv625/AWTQkF0ruOECl7q8eHcIthVe2enN5+56PLKjCzcNyLMMWb8MteOeVmDCvoy7lftNMyeftToQ308rT71VdBw8+mHGlR76eIndCUP/6CIlI/adOGC087ObE/OIbqFP1aiLlQXLpNMvrsXpanGf/rcvNg98ms2HzYf1zgXyWJefEtN9xsqZomBB4A465Xcgnfv0woL5o1u7Xyzaz61WDNfBS/0MMtinJinZaklWFUfSVYubcdB3yJzCWC7TBbT6NQ9aSWJeUebUsFD3mZY1SGKI3p1d9+O8nhXSEKBsH13RgYmArj3ve8eEVum4l/JdfzsAwWbpsHM3B237KOD+aAADP8cFJudjBgUghgxsyMo+bmUfKakTep0cZJwCOYkna42aQnOtyFtbI5jQDRozeYbD5S2zDnH5If/4w7RmpuYkpCENK3py+BRXdPwbH5U7wxxpSEp4AnEnO0h5KnT4fCePeHmLiSPIv3vVB9Npr78mJ5Qh9R3JxR0cr4pHEdHmTbtL311zvBH3CFakzlkbvu/MMjHDKCOiwhyZSFZEP+D8M17zz9k/kOKF66qCgdgG3D0ffcYoIQOgCIGAxQBwN8flF6oKN9eXvZ4edklBw33Xp7SJeLEzBZOzC3k8l1CTsxi5sRcIl6AxNGazRwtqT5+l5s4Ovo6k83TYNznFB8wvUjAkAEGpOarGZ/WVn56c9YDYYV/wq8AZ1WaZ92lkX27n7vb+Z6LdiMP9PKesIn++ZRYN1aF/wtjsvGoUFllTe0bR8/o+KCbMW7XVL9Dx3X8cn0/ifqphWi4G3sXeb2mrVjqkMbeuNy3h9u6U8TXW+uoikbJQoT3yYN63zV44nZiRfAVDeHff12XCzy1sXL+P5gY2et5GW3JaLNoQVAo4OpI8ruf8zCMTzKjqncQaEhdA8LhABozie8ivEUiv0Ug3CaTbmtEZb2pSxrTpy6L0abvf76ku+4lNf4Wse4mHnezjngL+0ZNDQZdW4OqRWNqqrFsK+4R4PcU68QM3u9xLZoGB0AFfqYscFcD8JMNp37uTUdbor1ZtKBJKOToF26iRjM+zTSnadDUaCHx6KpibZ8e2T85OQNpWh1k9cdGTfbW7yR2t7fDfWf9GYomdLsYtsS2p6MbWcxIe6fJEHBsTzRQxQp20GTwKEyyuWRKFleEiA+HJXXasWBwFs5QqmbSrTIu3aaB7RKTMJD2JAB0cWSRgwRHwJtqjpR9h0mRtWCbuoyy/WQKl05/3ulX/JbSmWaxIySFA2aLXS+BFco2qUIV7OQj2nN13opTkwecXc5zxNpjc7mzfzQxmvVKN4bqH/qgwGRcLRIpVSYwwsVdqDOOJuaWHeAojUEVvVNRW2xKKaHboU3WC+ONJqSVf9+plgSo6qZEzsAOZwNbGhZJXXHKeFysS3JgAVZwODCCd6SzbIHnvdQVsV6deDPyIDRl3Sd6Kr+RVOXnaq2gFXO5WpFWzNFSxrKPUiijpmPkk+oUBxZBfu0Cjr54aWMbIFO0AFKBpZ/UgemhcK9H8R27CtlovTjWaBbETVQkgKdcWBLhY8aaJ8Ta8fJe0Vo0sX1tVTbNPnRVVletN4oml/62Kqsbk62n6+6B14smu1tYldWTjpea6m73c98P2udVTmLKYMAITw0In50q+Q1nMaCAZ/1yQRUKKf49k7IMkKZBZv7q3PRth/OfLEyjveQr34COj5hKAIPFPAOoCcSsCCBWHRnOAI+viE0g498ZKkBqArHsI55UVkme5aamA9mUTRjgBriCHOR8OsRgqf9bxYD0IqJPDPbdZMiMRH6eb5dNJXInKl8kcQVX8kE+zEe4ig+5uL0Khh87y/yKjbI1ZZuD8xxMv3wecwVX8mGuYqsft0BvTbkOAmz/0Eb7MTOtGsjORiis3QriSj7MVX5cz8tKcjCMvXLUDqUcqbJvJioJzv7B5XOFHzO3VQNwtpdvFLiCK/kgH+YqrnZx81AuzuCMdSmuhmpYrkrFFjoe26OAJgcNaIXb3diZy4F1ASu8J3e3i47EFVzJh7mKD/ERrnZxcwuUXzG3+LCtkpdS8RHYamvUaD/mqxlJzM5UwT8Rs/3AiOBuDF3telAlB+Ab3K6kju1+AoJMN0NhrGcDh7Ixi5wA6A0rHw9HGMYog2h77NQj048FZs0Q51FzCJJYjPVWsoLYwEYO43COyOLmCOg1lysUkPrhs4bjy+aDefm62lmfJfoM+Ek+Zclew8ops3x/+uC0ZAMCMfi/rxi+MMpiug1clPeSO4PpAaw3MYCAUN5V4OcpZdazgUPZyGF7TSEE2Kdg7VArmPFSYJnLFaJUjKIsts9Br5naMTAgJRffwY2oUDgjgFgqt5EbiPVsYCOHcXgWOR1g3ERh0CBLOlMYFpiNNkx6LiaCI8rm2VwQv8K6hyiG+HLqYsEMH+zrxQT4H9uvZ0+4BG+l5MUv7gdIfqZK3FkyTl6dSiQl6e8R4P9rwqe008d5cjkdZHJEjPz19ok9AqNjuuqSxW2RQ3uM+lQ/0M5bU/9h3bEFtgxzHDfgdDBw3QD/zvZzsORhj2pDIpuYlac/ZXte/0kx07/Bmu2bmNHEUEw+Pcfg1ufra5KwobQhCWz2tzld2j7ACnL/5O8CudeR56Ej3dlvYcxtkl4ySKFSmBQuRUhGySSYiyOBFjDB+2jwbT6J/urVk/rEhw2k3bb/z73w476vlZ/Pe2kK0JTcPwBgzv/oyPaNQODA7Psjzisi46ehdQ64d/5QYq80Mlsu6bSLu4LnbO+aUol90QMUfDAwRsj5u/f3G1neWqunqawh8woCiCe2AdIGqUyqkUqINZipU0wL9RXOiTl3IR8u34a2LBDPd22cVCaVkD3BS+1vWlT4Bp19t9dKhKeaIref6NwBvBx0Wvq8AkyArtaZW3Z+bB20JTw45ByJ0Tiz4x4ZlzcWE0JzmZJMmbPFw2/YDbROLFcITR9ccmZpg1RWXcKEsuacDnOLTmkI2RIkJoFMhLLGJos8nZ/TTVrgk3kyiTw9XgPbfAipTCqRrNU1INSkaTm9QBzCKkn7WjZQ6WuJQjocBflmpX1cIh1oi4zEyz6UYeJCc0XIH2MZIE5QgXmaNPeuhGI1LPEkSjJJDqAg1NOMnPwKx5N8eO7VLPuNs7kRnpAoyUFSgJhQqNOpCryxkBm3TJK07YXnNOC+oOiQQwjjm5Rfk+p8BqxwPgfAp4cFbIAfjzsyU04dSvTlTcB8b5P7CPL1pU7mV24hPTq6LY9rVDe4jZyoTdObyFKlhK0uYUJRHSEvGlNdXptluFDzguVFQYQzR04Sr1XY3NmmfUFo8ZwHzagJBtMPSZTkIClEE7cHoQg2RGblBDAlFWj7cuAHKkliJWastMCl5BnX19i6bL4D4SMnX8pHRUTy/Czz/2R7WwVmVtZiz9xIPyUIyQbdp/apDy2f5Iwe/DmHwzdyBrSd7yTKL38Wocm32CcI2fwcVjVJtr7Ev4Q19V9A2NzcLRcaGrbFrde1Yvl1OXQcYf7Jla5JdIUxwIa6lC4SgWyWHs05QcQ9LrLfbd0Bc2s7zidNLF05oZnP5a7eqhL2uzg13OUX3Mfib8c42oYfTR6HnjbcziXd/ZtLbpeS8/2TrXeXS9gH055bXeIdu1R2e6EdKLlNI1dtDwGxZLGc+Eze/RvcPvmg90dRjxSVBsAc1hKouLaJIAaJbRbIcJ2FwKVi4I/OT3cKvHU1fkwfrIhDM7ML954EOshtr18jFwY2FIQmdwCjt0YScowR5ISIOGjQ3g76FdPE2dCFLl3WygzL5m0DK5fRLBtdG4w0GnURixklKMShVqOaxkW14cYOlIfPAKArrLMBkLJCMudxf6341g77NVIQmW9SH+twAQZR2ivnVKCc+vlFmYKhJrqGbL4RZb6M3MduBChRDq58DnbEQ/Cbag3WbaxKGTOysjf/YWLWjricQkyaV3/Az6+xAQdTtzUSriBnA7BiFZsAc4xVnNqADuMm7mK6Yw23SA/mRZ6lUYDhOWLOq9luv7rASUQ3q0tLTxRRHYv1qtphz6rwOITRRsw8Q4RiNUkJgQCs3OLCM6EqU0CftZqw5LgxqAnYmKzwehKRMYcOW7QLtNo/Q6C5vHDqKIcPmq3tm4Vcz1TbSw2bXH0qVGiAPTh7yxYx4ryanSDH7OQph5B7rDwGpxz7fA7opHU55eeILXZ+4tFnUFCM60h19hyuTpKRYaechlaL44HErd6dKF3xlGzSBKARdg8pebhMiyw63ZjpGNDjgyyBM5pPAT324miNJpD3hdDwV9pBTEJJHsJURNhKnHntayW6g3l5pGnuXAdbMSobrPBWgM5ow9NUzz04POTLnQx96Zj8qlyiykdRvA2KGOHa/FrczgXSlqA+ZTy2LdVjAsKQeND1luRUsmgSNSqa4rjBaCCORV6uAcaQCxHrZkVDHSuXkDoFjUtNgPSKrRrhEpKiN+jSGzSXkR3t7Rvi1CbrHiB9OJ5B/ZQZ5g2EG71Fwm6+HgjRkxXyr3Rn1bVikmF7qcTBDnsdnQATnYPFTtQ3IPFWtrsGwuQNxOWtWA+k5ScJ7Y9WK4B2ZhnEhNV6cU5ymZW9DwDoEi2ufYObOdHouCHMZVqLdsMRMM4WhBCiR6HYwYia7IrshvAB2BAME0T6GZ/UI5Ypm1YRkJX42dTrmdU62FFqxUCj131WcVwQlyXCiRuKlTphlngugsrQOhuAs+sS5rQ1Pu1EJX1BE46bwCfoHE0RGFpNgAtNu4tCSSz2odZuymQgkLJU47LpAICxLQ13Ie9E1NqSMzcM950QCMGDncx6O7kF0Is5saCXOVywpt6JtBgIuK1ECEUEQBBIK4Pm+ny+In7uxio+1Kbq5rdWvuGO6Tjtwx0v0yT04YQmYUHe4a2Ikt44kqpLresbWRZNzrI71wJAlmi4YS4AOIUF4RqqdtKtoBDGAjc7fXOQMpOWnH87qLRFczcsKwXKbD3veQzB3xBOFBSkLMdIT0FVKtQ+Y47MOO033IEuV5i6FZ++Yf7QBB5KcCJFtBCnvUyCbAfkTeTUDWBvSCl97yyWuZb1R7QDkTWrlCpvL+ESJcLuDXf87GY6QJ2ZRZ0AsFUssphbqKbamnfnFyuID3KvM9oXiNokrFxxRNiJTnbSv70OexQonjFdRGygIHzPdJoVshR7QmTze5G14oe2O6hgjvKTkpwQ3gDbMgNc099MQDo1ASDGXLKsU7FOKnAViDaqq/MNo2F6jpv/RPBByBAbCpJqSFGfYIII34jGENMft57z8VPVibC8q9XRrfGgM0506CcsXbXEZxOcOmvFwWnwP56QKHLXcQVE9pWJTaC64c7qFccNJcvO+AhPXfDSc51HBISNR2IZyHtWb+zjVoBddFOI4Agd7VjLe1XkQlFePo38QjcmM0YSKygAYxMAN/ufQ8Od/rwL03aOp4KP56KQ00cDY8imGiPWDVMttyToWczpU3HCzYRzGbdSl5OeaRend/u3fj7GPRCJf9bPQ8Af6aZcXJvwj7RCtSPdkdGWMUH1JWxqTI7uobd/jVX1cUIwZKyN4D93c2CixUUoYKOKfsdopHO3oIBrpCr/zMn1oj8yfCzyYz1cBwDxncAzE0byayKEKmumkSBzT3d6dwihlb9fMOjClgTCceuJuaqt6nhtGLsDfk0cq7r8eXCQG/ek2dWOKQZMeAD2/xzMdoAYZaeCmt42zWOiEP48xglv6xA1rydxUKaptSLdBSuMy6OjZKmFC4QJELDBEJXbOk1+807mFHVXHnDuBjIlUjVBc5Tg1X/SY20n4WQXiki42FqUC/OspMpp2v/1B/e5ZGrrmSGgoygKQ+nO0REE692YIu3P1AnFwFGx02q3TXH1Plyk0c3OUiL2HkZd/CV+cIhVojwXWhZ4yAuzab9GBrYTiuFTV0qeYcDJDn6KNsIapFgTB8IVbWzjMhq3lWyUF3V0AOjV0/Z+uQvmuU7COZ8b2PW+AXiykZ5/LcO7LRCMpgNKAEkoYxuEcvvwAtbuHCe6iRcmhPOuIIxulengUGL2EEaDGHGnM06jn2zs7+RBH2cR9GEcRhAd94BgMakPKynRpGWQU8w/hym4uxu98VLialCLeKHRuC7WkvXqpjIN1SmNSPiGFMLcjw3H51NZUHenwNvX09f5a1MVYznGoZvT3Mpty3XcgYqSFBzGgd5xi9jheaDpt3LeYdZtfOnnessGnheRp02FYAp5xyzfHjdPJP68/8nrx6+evjof1/82/8gVp7WFRe3yCBs0y7BQ1PTcbeWF1gR5xsqxjF5KZeVIT2F5DLTi0NsDjQ+SGh5vE3i73m4gyT5hahwQmx48HEWjpTmCG1geYb3L8pSTwvmYEbkV5ahyF/DK+7ZiRXxLloZitvKE6AJZnQkcBnvACwmYL3q13/BrH7tGsPSR3XyK7BjlSJYNW20DQk//daXDh8NrX7G4a1eLn5+J9digrPTMxXrwFmKJNDJWYXmRGfjWa8bxo3WA5XRIHF0OvBhp0EHmO3XCVJXp/5xgtgrPAEYYe5KzSF1BhaBiDWlLykYYla0f7u3Y55MMt8oTaYhFeeIkhGsAXWIdEeZSio1UZ+kpj5GJff6To0tbKSk4Kwun7FR5Etq+YQ6d4Kq/QH6JYCC4sYA/t3+zIdrYrK8VJngVMEELiCDpBk6g+zChR5E2yKx/EK997sol1WChzund4QDshCBfVwZ8ic+AxTAjuKH8IshvFfIxDHO6tIB3CzC/YpELASFs3STITI7UUhZXTDy82Dnc0OHc7wv8Ri3BBQvhPQeiaNMref07O7AiWntlL7hrQLQpVy+O+83jbVkP4y5n1ir8M1RqML/A3bOtOHM3ZnhC7NU4/3Qc2ACKuaBZyrhyRcj5IlT3Ctdbx2XdQUC9gBgUb37pLklkfkgfHmKc7WYM7sbpUxUd0EAXcm73blWjGl9yNIjvzcei7twA+ujp8dPsmzNPoqPHm/zmfdbvHOwJPlVLByydApWjEQu4zEwym/QQfPttrXWV4qwKWQl8B3FMl4rsrttApgREEJYud+mmjAbYJITxQlTZpbjpsx0FJmc1Ttaw0SVWQRyvA+rIHllKiblOa/5DeYO1DwC8DqFGiedWZALqVeYIsP6JvkPP+Ozas1aMJPhGl2VOt4VElgwWstOnXVUWmekz7KDBJ5uxDh9levcfkCOnJnEEpW2ppskEI/4owe+kcOTkuaWrQhJC+nkRwWgTnWWfxqHvUYIcXoIVOF+0CmUs1BG8FSHR2K6NJAMw4++IPiFuFMEjxZCKi87c46qIcTEI3FgloJMLcs3BINb9O9uwrgOrIMfbgIecIHOe5j896/La4Ju3nod1nDy1wbsewwY5cBctzdvbkLUu17FxDkJAu28RMoLnWFs4Okfwai7WyJSHagG7lb4wqZ3WO90U/JaMtoChbm73eGUe01F65f/9owjx96wuxBuXOvNN+DSHCzOoe1OPixEZJJi/VjlMgqffi+ASfutgUybwoZtEzuP1cWMUZ7yHJIX7GJJOyjfWX8aQdZ7p2T2y2/dlqYk9MaLN0TFJ1ObH2kS9TQ8Ntxbl67FMY99U5Tfsm1oqYbRd4tMm/LlnQ7ltIlffCNA2pUkbrq/wwRaj6zXwxlgiTWDBH5MIGppvtFocJ+Gj1aGzZpKJJIJ6auUMyKRx45Tk4UHz5lkSY2gvqgUSqwcZ+8vsULjvkiQibhyfAS0ZrmR3oOW1gyoaytPnVl+UDt8UWmxEvLm5S9wxadvUtJl4JnRJlUoN8HRaDoHMa5ucdbqPZCwpsZfVMhSs/AZ++1YPcR3guSRQFfwDjNS6nfDFUHLgbIzgE/iozTzdM2PaEbfrDWBiWCVzraRPhzGJZuNbCZCJIAu7Qydr61SeOqZFom0WIdn3hIQEz7PDxgsd/vVS5FC0TKeUjJh/LqZjp03JHLLhn2s8F0Nhgn1iZuuKy8yp/usqd5Fy2rAVI3NsrexN080cEjOXe1NZ0NrXOt74Mo99Vz+aB7fAzxaHBJkZF3xLbZ6koNbY28iiqpYsROvPh4p0lx1ykW+j6Y2o/QfBXfXz4P1f92Xoqm/rbz+u+UOMCsbgzImNmOOmyMybeuvcKfaImzg2LCi9lLrsJoeNXZ06e8877Lu2SaHA3D1VZRModLOJ2ZxKYiVDpifFCdxepAsPPVhsqDfFLHHHhlaRKDIxEIVtcGoBQ68BAvudC5AHc5yS1MrDIDQMEB0rsUrU+WUpPog9CvfBqs1galCF2Gy6NnI+oUoT4gYAepa54zKmoyNH7VZ+JbomsN41jTDWdnUFX3JkxmgWy08YTHkdGpFDmBmwjG5jMqr6RiDdnBIHLrbO5XmTHbbhBRUQ001ksA3mIxBKtJOphOoItg7ag506vK0A1p5zJGowbWnMchijJKSd5mhJsV3EE9syw0m1/arXxTJb9ddM6qQhDwuyumuJZOKK7iJVxKxOKhVOdPY1wdvIp2h90j3KLBEef94QEgx2c6oag+wp5NGtNgoWnc5B+ZiHOjkgQkBZIwitR3e3wyIcxf3NPeqGYDfNMd6GHobnY3Esr8LwKkKwMNj0gigBLVtD1q0N6W1gJpz4RlmihDZMjUgG4qTdjUd1LJ76rbmusoQKT5gZt3kSbVo2fEmottkRUhUeIhUp2pvqtZmQVT91HlRAWyIykVn7pYt4PW7LNA5dW4viSSpCDpahUPM54yLSAS1cXVRfF/Xuj+Xb67f9Rc3VDEKRX0GT5q1vvo4LBFuhUWZvGbKHB1nq4Tuy3YWLe6gJ17PpJG/D4R2q1wEQNLTVoRPwS1eKU9jCiTadW+mHG+5t5NtP8Ztf5If6uPYGiU/7uEj1i+qQRAo7sSEEje3sXc1dcwQoABV7gzlbZxlfBLPtHDGIb1UZUzHkzteJFimn2yKuCQr6Ip/0lSiycIxGkYI1/KLRQrimzH/EEhNflcXV0Cqy2bYzE8zPZN/VOzXq84CIG6orEEtOjnU8+cjc45AlPj16PuLebEeQmV0u5/n4v078xNT0Clx4urjzPCHGWEKKJgBcaoekJpGZlMsQUHEZltQOAFGlCWSRuZKIhSezjp6PiSkEIMI3S7Qhp/HK405H6uM1jup+y341Oc9v1S0lvf2zP0+JuHCceSNdp31hn2XOlH5vPvNo/MHj3U29gGLMLuCTuw/P69z9mH39TGb9YR7UAuYJfOrQQ3Wtt98sk3lVj3aMak8gqSjqIrpeQg96daZz5V05A2SRsb0jnYzqK7thuVb3TY538FfWdSM52UWBT5ETZ9lFHzNzGSyaRa0vAiblkSz6WV37VKVO6A7jDoPxSjVQZjJcxMnad6Edx9leW5eItQQENv/LwI3WHy3x50tPuAIfbEE4YziMlSB+6LVcHCWKCeFnf2zBc0hqcGv9QU+zu47CrpWTmvR86EfReeRDaIwOMV/HXVjlRxZ4m599OtEQrM1nHWspWJGlYRVVZ2w42Xw+N9WDQwwe26aGLmj3uxgqo37SlOYASQ3iSiYN1R5hcGnEKEeDIbuQz4WRCcsx6U9qpXcqLejNs18lGBcqPPa68CGcPnpl1uuXpS/Lpkg6YvCSThP6hFoFfdi3m2JYCtpOnX/eQKGGeznepWVJmciyy/JOxZwadoLTGBPeFHGiy7Q1cTLtW6pMOu1o47OAYXieFTNWwWgaKDNmAM19V1fcWYC3QlJeaUAXtK4Y3aa7y4YNqd6UZvgE7xQG1NzrAOPS1o2Vr9KC0K0QxTnrVTMFJomA2OEyuMkIkyrm8VcAC5JRfSCLDi37wfXW8RlONKX9L7JWNruJ9tntZHBmA2309QBGcM1yhYwmTpRl6hJr7mhD8wb2JNCwUb++1Zh/gWyRN51Ci40YqZTMF1vdWWi57207VVwRWXY++O+VRjixpoMskdj1s0ttIIOpdLmYklL2XaQaNMjB5G1UVip4cvQwcStyAObCdXdcjolnSC5dn/XqnHD2OcbdtRzUUHf1zveX4Y0H71dJBRfHRb4VOWSmWlMv9nWSTUxHouTivFLzjd2vixqrse6aqz8yACJRxNgxA6ULQvorXHD1yxZHVNml54yJw4nnXgsa1EfTOvhzuCAUGcU6Ws7yVBQJW0jKU08HdpKcxxH/Qod3AOWaXCVA0dtxDLU9xZOAdTFrBg1UmrarVjbCnLBfxu1skhvRYDryL46fCDa7LrIGnbDNcZdpGzV0O6I9g2UTInaxUJNDFZEB237SVD/DJ9rDfC1wcJSX6U5VmpL4hgZJf3RiJLWttxPh0eOYGxj3ZNPbzqnW3dpxZh+8oC4CAlKyNuoYXxkQvCwG9Lc7BZ7wduVZTIA3Y4b/la+7oZIPge7Xeckoj38NIwQEj2GtPFOj2Jynn9Ht9wpD3YBGetRvVfwQcGqRupfnygu+L4ozKEamLQ7ZQ+ckugBxycRxwJwmQr+GKY4KChb5LFJsjnSx9eMMBVIqV3SXxewkftRWrDABU4APga8RW1hcY6+qWVf7skhFJmrJ4VKJwc9VqSPQYOZtpzmBb4/Vli53H5Fdap/F3zZBvyPAPAT8yWrcd8iv0CEcOfRVZ4F9QAZwPIf6TPZwxFwNRD22c3SkSi4vlFzu/H/2du0vclazlEoaNhf6vn+cMQTBVcG14Z10Smsvah+ZcJ4OkptOlpITkakrlqgGR19iOAxWVUf2SFUGWnlQD/kkVtXhKoX2CxdwOuDt09eP1+Om5lraTaniqhkMcZWswayqWihfInbqgHqo1Qnse/3uKjv8ctz+2f3Rv7BgLSyIzCEKj1Xy860IIa06KY2US5QMcs1HcMmgSUUweeCeAq3gVjWrEz5Ggcl814QlHSYD8V7hi5NzGqOhUIHiYIwVDmLKWftqZKcz6Qav2CdLFye3glXTOqfdklFX0gOkG3nK4N4u9923X+cxj2UdSSyYnVqp934F0TN8YRq+NDXGxiXo+587qHQMvDtWNnD5yf6Ih79Gv2L4gtUjFuLVM7iB1+CBNPU6LsZK4NlQPzvqZ2e97uurqfvH7H7tk7tWiexL/kU1kfNFE77PPplSRNTa6tFKG+Q8JQzt5qxsAy28Ek3AcaKEM+HLJiEwDIdy0P3Qji2B9ahtgwDFgD1ofJMC7VpCNUm11IZDHj2cRPPYeRhBYeUqWQkdszsLKslZnvoUI8PY59o5kL03FlXOsV9ZRDTW3Ygl6zMdkzO/IViZxmHgYjNzY5TIaV3fDb95DCGwGpk7MNm6mLQb9UUGJX9HbARWhbhAQyjSAyibN6FMvxuc464sdLz+qXv2z0oWl/KiSETHbSzz3/YMVAo7+CHeO3yxmPjuDKqqc/RiXWsH7/ag4JOli5NbwappHVPvgLJ509LAMDI597hv5nFEMZRDHFG5XTUsbga2z4AEmvsH2cDc8xZDlFmV1bizu87+WrrtdfhoY6ZPrl5A6WLgX5I7+cr74l7eh/TDHRpD1YBSWIu7F06KpomfRUBDlrtPoE8HX0NcUUn7Qn6ZhsHXIyjBQuiqO6qhg6dQSws8EmmIwIiPcDkXOhBjXrF5NmwPFZj933RbrKPfrs5cB5Nbyarx2QSBNpiBY6urT9YemaCXSEfQysvwNmRP5F0uGOmYdg4ke8GARAbRjOeXo63jjqt+rbSi84izg5EWw9rPM0FEEXPR8lJcXZ1Hk3Rp1WjB6BF4M/fIrNznh4GIpDG1n7Y26f/qMd74XV9+H/2G138NYsSj/iCee02RDtTWGAJ83jdlHxkSO36HT4boWupcIC8h+Hx4pI2St1XT1AMzvxfpipkFcUcRGXUEQh1oZAwuZW/wlHY372KttomugrcRNBGJNhaLFU3E9t0U7R35lwETzMz7vhbaHA0UmjI7rDv5iwOG1nIDrwuiYkDfyUx/KzT/TiXVlYOhYRyUbqKs9M6lKXl7mPz8YqI21M0c/SqVOfnQt5/cMGNQj5zSceZ2ivcA1LCjQcvZbC4+GzHf8w0S2YaeNGix0wzl4ZCOtfenaLpHCqvsyple4/QmU2Vzd3Kzv3BopupHBAjp0FGbqem1/dDU7nbpq8kJuB6dwReZl5feNe8m3VZn3m8T0U1ETZPG9dSlXKodepaDOYFm5kd+/UFHPEPJoW+HpSWp420fth7seusGeBmXPuKZb7xzYr4YMftKuC8GdpTFm8ok2v5+hMOYLApMJ6d2e3sCK7E/ibemgHoSUmXDWu6mtu9wZRPGEXUp0AVCMCA/zCl5Qt95A2KTtonsEfskqEt1EhlNsaXN6fFoLXDKrHA9NqO5VPXLd+ALegre8hBTvK2vma4bULhV2kyHOsXdnN1YHoduS9uKxfPAFcEvHoMyw4RHf5wEsVXaTCWds6AuFTZTHF2otmJGGGRgeHvrBWrpJrMxb0hS04v24CwKUIGLEQRXN23Zg7v43n4RNeOh3aknM8hifTRryekuozhIjC9Ex1/lOHB/uPLrIxhZY5OqVm99LTHgt3Npm0pyKZoT95CCCRsuNn4iHVBSXXwKvSlIK5z0rNqLeuNz/xpetSo71n2KBZj1Td/CyDo2mHVbwX1rLW0ZT6oKOWGv2f+19UYrdlJnd9bsqfmDA1SKCw1DPw94/WrfWGd15zVt2Tv46ofywR7qH/oZYsurQibR58WBeIDJ1JiCOm/FMjnMHyfNs1j+6JwgzgRuntaWAIkVmbwiqeu5+7nU7EpOKllmUUAat4lOoXEjzAXeooxZSU1ECOIRVY0lQvQTTUo4TlpoOb4thY/4a3ltU+TAMdUI6sTHyLrn8GDSKqq2k+klzvmZ1IIa/+HfrYAfXeECnkDw4ybGSg7PjvrZUj9b62dDfXV18LAd+PTe45fZbke1vyQ/El6xQs+Z8z42skmQbNdRch/baXA8K6vajwG9f+8hmE2FjKwxlhfw0d/XfR7bNZGNzQq1vWjNvKaoPEYsj2H5CCH1zDyOi0UsX2Rn/ozeSZ/mVP4+W+S28UvgJmPomQo3PefhPlfN/b7ntMz3a8i6MEnzao6c4vdhxETidVbn5NjCkEK7k2tXKPd+QAcASxznVKLIgmt4BXPMVVJlsF2Bjfsk49UELRR+4ULd9D2GpINJ6zBLlmqA/XWYEYUBCeemL/nZ/CheyHZd4uQnQOgv4PFL8TwNhnAIFKz0mzrPFmJDgdCiiDl6q9NytbSTMTD6JxJJ2Qrv8H4pSZLGrHEiDXXXwHH12rHOYHXwXNe4Mm412wnnJTaio1K7Oh6ePC6JVmyOOYgfDMyNqDrGBFxdqiYmFr8IE0zen+sN4pn06h1CkixfdgM9LdYdcmJ4x77WvJT3uwpzDRhxd5E5XRSvYaYzS9pGJl5XJreUFea6gkAbh8g7far9GfQgvu4yvtCHIWuyFx1vZJSlVcQZIIMIsMEITGdEKkSNEq8+D3UiBQQgN23BpFUVW/ckKYWlcbI8XL1QXquDJ8pMXQoVmPRCBop01iOQLuBR04Wp/oRq68mONFvVcC0RbgoJ1I62t+XEQktVWeCnbKANxSczO7kNbT6TdehHUXBWPaG7KsHoQZzQKtdzt+Oc+H9Hc+jRhuNTn8v1TORtxSa+i3RxQ6o4uCg92rsqSyJaeEUkaNkRmLw7Fh7ocQGVW1RlPl55uPv1jelTh7/FiqZZR0ztI7UdqANUAYoZVBxZeAeC95KNyfZ23b7hpp+TY8mdk7LXjo+YUoJTg7zjzjNbFVEJZIKo2QPfHZ4ww0cTQf5FtqBQMW0RgktoAZ6+kWCVjacl+7PrgpwO3uM5vPwxNSwuyqYqe9ZLITk8xqN+DQGoUFtg1cDTJ9krYIxikgc/R70O0CvCPUSxApiot5VBqYwKaMic6Hha6oGzoQodie5f29Pxpkx2+B38vL6q4u8VeyVvi1VPap1jDZEJoF/cfd4paA0l9HYJFFBGdjY7M4v9myy7Yac7d1qb6GW/mXwFzSSUbVxEJK5UjPUAZwFsVVYxmytLjg8wOy02gis2RxpYvqAcPwWy8vqo0rW9RdbbzTKDa96DzhYba6bdg5I6JfHZ/YGyr8bUtZJnCf1V/Skn9qSaxIAOO720mwGh0wbOYPrYL++97L1dnMiJ9AC5SBE7Hemc6IIHKDrVZpopdjZ3I2ILrJG7+mtfYuGePuIOeOf5UHbcu92jvRLITDlYzsyqfMfQyYrfN1RCh/nNq/AVv7877tcPr+d17i9K5Kn3G/qlpM60poaxK93hfNwyD0o2qh2jTlG1dABeVnkyD24vV3l8wCcxFR7wBKh8b9swlSp4dJAmW5H9BRHQdewj663bS94Jl71UCDg6r+LKx4dZSlEXxoE6cFNyeiLFMIc9p1H0sq8vNZ1/liOgUyio7MupRDlvK5Kvh6Ro2dtpZyDxpUAQb+gv4FQqhpwjxrwnga3DUVdH6D2wvCqCbyyJMGOTxzrc7eWRYzPfBMYu2uyxoWbESyVZvb74gvVKODaWmB6UBwzCBnd7f48WFCSw0VR9ICXSDi3rlIc5T83gch+0Q65bxZhskbnOMrGCP1WuTt1Cv4L8MvhEtyHEB2BVceqoYWUMMc5wX35CTtHCo3KZJoLHls4iaD/GfiUVB5uNfYXwnc/zhmJRhOx+XAgiNK5LFBKmnY/s8NI090ruZSMRe1rAM3LmeQ0+nnnrShqA3JPT+B/Bh0ugh7yyIXT0q29OBYTNGyKd3q3NKjxOYI/QrEUX1rm+Tg6WZ2EmmcvRhvVsd8XOumNMU2yT1UaGOttkjvk/mbVxpk0Z9lWDyMquJwHeIg8f5+cIyXGEoVliD6goDumJDWSGVKjZ2AeFD5ZdYR9Qco+OcQ9Oz6jyZo0EAnr9Yp4MuVHUwB/6Qq+kH+N28BiWZuxwUMGwOOgYIvBeIt1M1g3dcdtRmsmECtYXbJFjTtHcmQlwOwCm2Mrz3qk8uLtHWF8H5Y5lXBDMY5rlTZfwkJ1N8d1cQnYVfsQdEBXXexzmjEJ5OlsrOhpSzTwJW/4NRNlpjzSFr+ULWS7e8mmEQCWEaP/avmEOhon6RtFuCg0SR5uOHDEA3o/+Hq9WNqKNulINUE6o1KsKFPujUVSKuNEAXRXMP94Eh1a2k9d9r9HF5iDF8BHRGAi62itygWVAGPH2gYehk9KyR+yLRQBJqS+GNIEoYYI7yNFA6IXKVCVpOLtPqYblyxZwyOkiVkOUZ+I9DdEgLf3FmtF8Un3rWE5IIeQkeGLT7KC4BafEFtx09D8D4kCkolnWBkDzZdbkzaL4CVnCCbdN9XVsGyDzIdPBoxrz4RNUOGQjm0kIQOwGrEmCYdMBNjJXlDLmUa/FxhTRQgJ5zvWkULxD0Yqpq5ocs5FYM+vf+CKW9rgXM4kgXaqJtgNW0YPNzrhBwZhDbKcKcRRFiZYm1GXmsem9pWyfnUxvggtiE33vyfkE6N+/fPnF++vj/fWyx+DXZd1FSVZozMgimEZkSLUdVDUVCLsZOajYKdxXsNh4WJ+irNcHBI1bbLdQBJjy2gJMYUpiwzexLEz9FmAL3YIhxg52hF+5EQaKcR5/Cgo3CJBrKvGXQPDchKrM0Q1ddj3teq4EIpZ5KYRTrDPOeiBE0ycsbo6CVhO8V+ftd4xJT7CuxFfjAErWA1DZfgXMyMYVgo2a5M3DvacrgqUohusfYtd+o/FYIfl5aIQSLRbR64ZlV5XnJmyndk6vucuZo+2iPZUcsBkpBk6uM5vqellPdFRVRnZhGlRov3WEsondkptgfivJSvTH/3m7W2I6KVOx3gmmOpe1b7BEYgCfZVmlgCOus2hJmN25ZsYOyss89Mn2Q9rh9ItZxICUDYJCtPVA4lp9+4HBJJrwex/5Wm/6h8t5XOYSb/vzdAo3WjW4UByngiuHXFDt551fo2ioHPZ+0aA+gsp0JxH+1oOwTlCPPC5XROfJ/Qoqn+INpjQRysoiBVOOhui1C0nraASqurweu8zKzpo6qO1jmC7/7KQ8XJKYE/8R1eV1FfpnOfQaq6xwEnoZYySQHojLZJE0IkdUsuLoIL52VdpuDBLYqQiz8NcfVW6fiwKp4BpHCL6Eik2ztQ64IQAJcebJXv4yYl3BRNX8vzrksep0RCq7atG7PqMPQVn/kj/TA9M/csRlgrXXnspUHtxCD3AaPart9Gw0Al1JrwEOPobM0C0GSbHCpcCCJpwZ5txOQzDntFxkIP8u0NDfvN87wURkYk3ZVPXPoaeDzX+xP+USQtU2VOuAKKLieEjapCWSl4XONu5XCxD+BYjs2svSEYhDS+UCSYp0voxF8MwnWckRn0WzB8AOpkmgXzHDnDN3hoQhgrqiZoVk1QVwBbgEcmJQcrP/RDoBjDha4zIG+WcGmX3XBoTV/iBRS6ab3gcDWw0rPhJ0vTmjVQRcwb5eZToGMpTL9ji/xjEhaiVaJFS73JZbWQSlBidOIH+JRZVZuFbmdOSXiFxUA1lS5ApBqxHqeiCZsVUucJV4LAIsmE76S4xzhByB9Klyon9cORIT4qhOyFCUjFdMpilWNp7WlfcGUYHee6r/h6QTHNNDGdMuuuBdPgvPas7GYhFk+WzUlIkBdv11FsPKdYHhuQDwIQF6/bx9Xp6SJ03a+NRJOdZckO+5CjeQHuRsLk/SMyhgUHjrkW1NSAZwHjFCFC0i5XpdED6n02jGhtaJ4BZYR+dTFUe+dwxuZTaxxa14bVSZivLoUzrDZclQbsn+6cWNDDF0ikgc8rEYFt7UILXAXyBEKT8HGIFtY6cydnqLCK+hqnOUbxnYCVMcr3/vJtmXfJsBkW1AyRi08ehEINYQZ5Q9B3QegDM8SkSlRP7pIcdaOQK2r1AggYTwTqAsJGWktac6GoASFWpAzSpceo2WYZbsRT2rdLYHcbIstIk0sld394qZKIg18dH5i7yiXHbKcpyPABd4f9w1NSEkuhRdy8Z6Fh4nYRdaKEFTkvl383ZwcHl9WmZVAWFrCHbg3AwAZRCH0bWbOz5HB9WKT6V+yczdNmLx4+cdb7YlosqOZfUbQopr3xUdkAM6YCtFMqgQJSdkRRRQ11wPlFPXWwVxqPVZbdsfkXmV5JmHtFYaaa52B1CsuGJ2IEExEzT35VnfISIZ8hDm1PghXQxSnADo0aRLNWviarkYhRr/GlTAlAZq/hanrgxgaGY12gimPMaSQBWi9EBHUBnuM7y14z56D3M950+I4NUAyyi548zTzJBykdYzLLs98jxbRZAQH4H9WCJtVGU0RaNXTvt5mOfCzcfKnBdc22G3CBAuc6RAvqL3QYbglrGodRekgeCGBA2u9ygtNO+5wwQsra6TjHGl1+hkEZbnmbYZTgIUngQI9/wFKnX1Vz/qOaURlujuTdeJFGQpXKfzDWYD+EqsOvFF98UR4My1ZRy6WJi7Da/zS2rxXa6Z/A3YiHbelFwZ1zYciYoKbxsWdaGgRqOAlRYqfVwihmbdlkQAOo8PKpgT8jpQTVpOKrqxomhWvDS2G6Vwpuq/x9UxXXlBm/mBEdY5JdDYnZdWftRGRcFhdKjxUFHSagAPcNyHZP9E9K3MaWp8VBnCgSWKujcA45p7R6OCuv6T0sEnOMCy9GjpCgZl2rVRwC1ZjJ1UnGVKxlHdvBodVDT1Um2CSYJU2UYhx7OixGbnW58vrWSajKJmE0i6NCHefVS90W9jFnX9y3B2ZubqD3Q4EDZ2lBbTPBs0uribXtoNt3lBUHgUhs3bIWQHAdKUospOb6AckbjzYlpgB2HVk+ZyjfYr1wvOVpVgz8I8ADle6hExhOghWmFwNQ5SXWQpIBN3MUtYSQEuy/KtVvO2fx4WUU8vS7E+ecNuGweBRuMhTkMwiDZpcwBo0beI7ndmARzAQ5opEq8S3rpzN2FSum6oyUy15lAanfx4XmgeHoMHBksoG7NZ3SiVGVAaoRD2ZSt4oQiI2zMK40smYOkBatnC+iKo/Edlwt1sxCnRQee0K096FdtaJOWceQAtCCrajh3jfQuPBiZOcRvqhcvmvPQd060q8Zymt990yN/5omUz37WNnmPlTx13wdzc9kcIdGzcc5EwQ7Dtj5Y3/8o+KFS5kzdnxkevyI7qmtcxwWBkVIVm91LXEN9QJA4r427lrU5R3ersSQ+3wDR5ygxuYyJmI7zLC2cy+BeHeZqJZMg/J6livpnvsJkFBbhoS+YydqJZ/4mh7ARi+5IcecwbdJyKecusY14p9MkOKuzybMM9N8sgThNE9dhilL5FEBIobRLMwnUSQrX7GgR7fnYSR1+eww/FF28Z9XGvhOCGHQZ47b+CPjeN5SvEFFIey9/eU/ht1ySXHDZonF7ZUh2mbKnNfUIxZwr78CrrMz/1/OV6tOHgsDX/tfvFUTtdpqRJ2n+1uREw6CLZ5f9JfBbhBkrTgOfNhyxPedgj/Y79bkz6avgDMYoCrteXyLIA+RFr6gfSdsi0qLHuLrL+WThXVjg9B4wQ/US5/8kLoMT/nx3qJSuTo/IMbOdI8qvHx6WRV978AolXEAbaPSUweckDmNAiaCXa8ndZlZ2q5UMOZW4JQuFhbrfgLq5AzVjiON+/Op/CvK9fcpNRLMWj4dDtPoLewfyynWpXfP19/PtNatl4KBhwX8+OD4dP4aT/YX97a3C80OYdHOIVADrosEkRm/DhtixAzTVZLGrLNSojM1wBNO/Xz29evew/MKOjIK/n/g6Ipbi5bkid+WDOw/ydL6PYquFbYb7KMNYWXCgeLiGanz2PGQfKncPBnHhnZebGS+qDYd1jbXQ8fkVLvBAElrzsqffLiIhnL8CMIwbIqC4wpvoQzRripjBsYJuKqrw0nAwvvEwo9UEUBJFZvOgLKNhrXVKOmiqQu0dhVYHhGcCfl2h7yaNPtZmL86bZU4bWIWl8gi66gwm23Dhl++dIlweDQkX0nMTeNp3rth9R55cdLmd0IY0rYEmXc+Jc4sKtHUYRJGL4x17OkZ5RMwObrrzqgjVczFE62qnMybuR9nWskjp4r9WRFdSNe6dxrqQm3Et1K5tYo9IjymvHrbHYTa9Hp/xJAvZSB6eCNotj6mqFQ+qXG/IcXF6VkfceFoTJIkYFuO2fYIRdI5vSS5fqB3DG7HAGUqxxyCs9QWYrX6/TStV7R90wzxEf8oUIM7gZWveFQvPmuVNECFUITLruKlMXeegAoRQHrCKrsnWnRD240t3gdJ5UaUWJAE5BIdNi6ZNc7xUCeYeW4tQuA1crsQ9p+stewiV0kKAUi9tGiHw9L7a9LzIdIy4qfd0Io77lVW/KoPX2gL6gb1T4/C+PkRcRm8BAtdbD4GpfPlukdVZ7OgE+oIhjbpDWCf94EMhQrW3pj1hK33hTCLcJgkXUb+REmJsno0n8b9POv8dw4i1SpaHKmlEo89N2fb0EWYBUTohRLy/kpGJdQTRoU9Pzm7jNq3ZoUM5porI6hmNzkdmb2TVD9TCqA0KzWvG/pK34z0teOPPHaWSqjo7Cj6lVkV8c8HUvHdUM+6QETCuko66titgsOobrwNmIW5bCaI73UoCYvQ4qHcmzBYC27bZAGPTkZSZsCdTjNDNmb9TkNHIoPg7wsIrCLSbTQuz0kDeT+nFVkjidv8j+TMnFIQH0gY3Fu4ZpPPinzRY7TTSBRINqg1getMgB57zUWMVKPMOyu8k8/V4zE8kzGBz2Thm0YonTh4nBDezGyGP4yk8KOikD9IQdw8Vb1Uweg7XMza/2ik8iPgw4a54OF+LTNU6w1bLZxencqrXa/DS1HS4avdpGIZGODqEzOneCK017/zgO/SWeERiZzB8qVIZBFOUkbv+6TF6KrA9jusy67I3hZZCV85l+sH8viw+BZbWWq5ilyK0nXHI5OKRhSOlRw0kcvxYaNA6hIudtGMy3bWyG4oxBbsRpv+Jfr6lDk86dZaIK3vSwDyzW67Q5ZiKWiVxNcg4ywfjG+Ofnaf9/RqCiAQEIPPDuA2tpL/+fQcefA3jvC7MvlGXWzPJflXkPzPsAIL9ZwJn+fwiM0kL2Hg4xXsd3Jghn09oV8C057EHEs4gYKmOvUu8nZK3tSmTpU+3J91DY1QuAFktkjBg6r+kPY5ueen+TmbNOTLyh+OsWH+7LlP5HRDl2TD29MZdqyaSrED0hOcLy5bdrPp+Vb90A0TBRqSdfWMCaiz5bCE3Wdrka0e5frjaL7hfwaiWvpTBOiUwaZPgj1nsJEuQLAg7GWdA7eBavSM0ALIgDCqStPC/JruUeJkQAlxUdwwT/Us8FcdoFCj4Et/NMYhuv9JLk0lpbFKR9VH2Avr5CPAhBq53nxnSSeJbT64GzP1cjukU9oEnXyK1XfJfEppggK+7kQHKPaVoIPMPKgDlDsNxVCMxrDMujzp2grNB5BV3kR4hHIibfDBEPad59AznB8BJiYsoTCsqXioAcoqBcYnjCi4xn5/n2+AA9TzL1wGbJ2m7Zd3BKXcTz9VwVHit1Min4YFLif972gOxEkC6ZlmnI7TyuHB3Kl+vJp0NE64wPfAYHws5C8l9RIKcSoGBy8A2UiIyESipOiCuZfCrDI5XIR5Agn7cavJ5w3wzGYyXttmwA//hMrnJqEOkHW4DHQpzkoZy8lfjL165SF2ZYSYCyrv8T7zxWQ7lZpG37CoWOYGp2kcwuxJiRQTwFvyURY3wxOairGY6HLtAJBsEw2B9aw+r4Alt3/myCPeFO2AR76q4EHEAg0QXgM8sIVabzIkb6xdKz2NyCuTYvgXiN51e8zF37rKlo9/IH+LlAWiffyYnnQz5PARuGFR5kO4daK373yZaGv1mo40I9CftI5LbRImcg3RvJS6F2inov8c8gzJiHWnv57ktcJ1tsRyhmFgI4JVWBBaphNTkW9CNUNIQSzrnPWUFt4rxYns3k/ESrx6E1Yz6BrUEPDgI/OuhU6bdiaLxloev+KJ8FGWXbGulYzd/3E5BDg41bVqlHAY1H4WF4WX89hS5wD/xmfGP7evEwKhEbi7i0gq1bOTYX2w08WsC79TzWzQvixmAGL+CbYgIh6AXhe8QfIJzDPgVo/K+/+FCPL1X4m8R3bcEgGQmGzAArAZc//QUEOEDXpJAbd5oBxgI6TmtbQsCturC3lYTQt1Vw5be1xWL++dshWQ4HFTYA7GAN2hASn9ow7HRpw4mMVE2gjcaY2ttIZJ15DJ3m2hiE7FC1DdpY8PewI7vNlqb1tjngndo2R+x0ZgdnulPBoWv796sITIh0fN7fj9QNEmQcbNJZTIlF8oq2O+ivsPT8WE1NMM36nyiXvwwnG+4QZTfhsNHfX2MV97GwdKazxoQwD7tpOt0N/C8c2r9dnCAjI0MhBnKIPF7gxZYTtXsOmNRmgkd0HlrZpb2oAhRdFJ1y32MZmohM7Najt2XiAUEMmxiyu+mPrjneURo5INq/nnwlG4qXyEOH7FqeKxwuPdcEeW5aKlL7uTwA5XJp0jnsEx2EoWNXugxtVFhVxX0Mh3DSd+qE4GIvWZLP6u0P4sVlL6RfXJEh/oLlQOWysT5ioQUJ6Oc+xfbANUl3UwTprlCpKdigEh6gFW9lQ9TvPwrQB9Qhrno+yR3UO5HL5rjlMy74XJdz3DagOwPvOPzW4dR2/kw354e6leOSHnQD23FivSm4xpRUrRu4ET/TEA05guvPFj6twM1Yiju1zG20zhpw9bEdYZGa3+R8FxgIB1wC0VLF8SU3CBUmXLQYseLES5AoSXLKo/43zpApS7Z++hsgx0CDDDbEUGYOkVCjFgs2ESINM4Ijew7yRCEQ2WM3EgYdmNBo0KhOveNaVahky0Lt0cGJUYvhnhOzYSlLDPjPsmwQEw454xSrUUZXgNjIFsb4RR9qDeeMddrZ7JFDjjnl7LucuC6ljiIU7zu/R9fccs/DuNB5RrnmsisOGx8uQcJEiZPknVR3Pvnml8xN190wIXoBKf5Ie8VKmj/+1/E0pZJUXliT2ps0adPpSp+h0MIKd6SIjEW6AeJiErol9eTq7tHrERTzpaT15esfGBwa9o9XoxboN2Cw2PjE5NT0jKGyc/MWWWixEcMVFpeWV1Jykvat/MO0GZWMGTVuwR0rcbXmB+rdki3fqSlTZOc9TWvdy08h7Hq/4evU6ft9aLbytt0P2UtTyFdY/4svv/r6m2+/+96RwFrYoha3pKUtS8SHVBx135mr2fHOWk3eI+BFaJ31DlhtbyWtqbS1NrXOFptbb59S29BZbIkNCUXRyt3RLW1tW9sTj/J3TPs7UHkVTEZaKcpDnR6767Y7VrnnvgceWa7YCt8/UobimQyU36MMJout09M3MDQyTimKZZn+jB8qG1s7ewdHluMFJCdnF1c3dw9PL28f32Rz/vwnVTXmotEBT3rUNsghgBfZMDoywIMKsvS3lhDWI9oLwhRbWLu6+yFPbsQlVQ87eNRFx3x4qD3ilVEmO+qr2TrhUyh/4VgQd4/6akUf6hg4qMkjtttHIhUoMkIzIVFFWtXPVkW3NtgcvyZJ4Zkj8ZKUGKLtA4ncdELf1LSk3+52kIJOj65xJK2eMvabaqnJlPAqKnSE/jVaUlmFetHdqHNLjtzUcG6MiX+dzi2qmOv8NWJS5fmJ8soIzr8OVbt8xQuTCevQtKW/7DLilU2K+FBQQuZQtP7JoM/QOjKTnDhcq/WLMphVhlfTvtFbjkGjbnZRiCwqK8I1wD9NYMuEG/XgvrLe46w0kbYgQ98rA1bjVKeVEUBGyyLA0tvRmjRithwCyLLNhhpW/ETSdtmGzTbbx1m9rHg5g3CgKujUkN5HpU6C54Z4H9wlEy5skxEIrymQbm1z48+GiXh+Glmz7pice24WgF4LQjCCxeGJpFIe98Wk3JXE6zdeUCEmLE57wQVOs5vf9IfpXawh3jqzz4TNpb2Fu2e8tW4jb4tzHo6cFWZXdeSkPmPxpdTGLoeZ5E+XSgABQoqFlnABJDPYISYaUqihDW1ii8Q03bQNsbKREELwBCJZFyMiliDlVIyc9G+rckPHYhaqBs4kMkWqigBARYFDVi4wiWAsjqyLkaGMi2PCLPKegBBPwtQMHld2s8gG3BLMxWnNRL1FJYxvhtqFCKCVj+Wko8Rn+p5V4BlDcn4IxS6Tc+8e9dKYGpCxVzVLayabH4tghDG2Qd/6f/+l0ZRjYfGezMfT5IyHxlj6nOljljj1yyzSV8YKWjlVRv5ZOV1mEIPPaFU2fEv0B39KoG6bhAYY4rNm2DmfMWY7QZP2dmjYBmreJlMrbDPKdzv4xFZ6wxG3ii23xCTWzJpYE5NYM2tmTcxkw8wMQqJuHv85oHidFpRHGBf5nzqO0Zp+8t54UCDpB3D67by6glZ9eqQyhhWzflYN6PN/BT4v4CB73vOPlOA/dnqAM4+foMQkD1321Mz5/zKRj8DrJhyWEFsLRF4j5v1LcGDhly6yfJJzBFu+npAxQri+iYKsDBa+41FdOyxppuZDhabnt+xCvHogjTlGPeQsbif7M/Qt+dFW/iR9+deNMQ9nRT8CAAAA)
                    format("woff2");
            }
            @font-face {
                font-family: SpareBank1-regular; /*savepage-font-display=fallback*/
                src:/*savepage-url=./fonts/SpareBank1-Regular-Web.BmgR04pq.woff2*/ url(data:font/woff2;base64,d09GMgABAAAAAJH8ABIAAAABuMQAAJGYAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGToaahvveBynGAZgAI4gCGQJm30RCAqE8CCExH4LhzYAATYCJAOOZgQgBYlBB5gxDIE9WymecUPm5uREPNKdUCw6b9+6YNewbcpNr96cTzvTVhFWwF0OzgOAqNa/1uz//z83qciYTTeTdrApACJe/xs9SV5km1qbG9miD8ky7za1RzYuiTlsWi0tCRuhT8MCNot9BR4Wo9sTFCWro6THTXJy8eOBB5MnnYSx7JmY+BLIrkeQFutkYSRhlqkTjn15270KC5pLIEyUnNNUxPuPCVUgIBL5hN6bZd0n7v7pzb2geVk7L28fW/nneyNxnUBkgV5ySYe4BchE1jntd9gX3pZG+6qGWIMUhizg+uPhyLoX7HL+THbgFHFcdZs1NiTO+NHq0eim5ptZYXX+5ZKlo9oywDEm6YfIonG9X5F4aD/SefvhwsQuJYfs6tCRUBGmxDqtY1BVxLc/z8/tz31vewvGgDFqjBUwFsQYgxbGyBQQixi0AxGwUFERZyNOvqLfbwViYXxERSzKaMyviM3XxqjFXJkUKEjxziH87gcIS21tK5PMTQoI46/9LQP8Dp5yju+lWUzaT9RzxMIh2JvZOedPGqQilv/r2XvI6JBfeXKWFMIgLBblkCFZrI4U1V5+03v3PymWx0iEwlMoUNGFbBROpeg0wqHf/9lV/7/Lqt5mDQ2g7tHahcGBCNONLoI00DHUXFC7TdPlC08qYsPy5pNbdYvQhAhwBGrrZDJAc/tXUEAFlBwl26gly7zd3e52t7tVsAEbtJKlgPXM/mJU4ktfiPrCfuX7Rr/nq1TgeX6uz3MfBSZDwcEM789nfktYYIdC14itkDWGhCm8/+yH3iRF0j11nZqwU7N2xo2NnybQwEIT/xczbSkHCDXjyA/apsoGCOy73PRJXeH/rZmgyJbxeRbq0BXJ1ZjEbizDLVOY/8zoKlUzbgpJIBwn8DxJnscvySSZTP6626CbVTjFKoZoQ4CDhEBI0FpOdNh+mIb+YJv/RSnFEiCKBg3BSu35eEZE3nnPu7fzXo5j7Yce/tSAr3n/ZY5Si6WCL+TlBZIM3fu7+3uAfuCbo7FQEygqfWuRRx4Vkex+K6qAKA3kTAIF5mysHws3PjFQ0e6BKDBuPO7W/rWlDhUVkAKj/FTntxsgA2opCPpBybu+or6iVleNZPZ9bZm+vWN9yd5NUhHOxQGCA3z9VcAzTbXw31S2ORw3GGr5RI5HSBt1qEM/PKLNLz2Z5CFM8hG8e8BNMwtFf/Z9qYbd/d77YQYgRSgwSCIIJijvOoQgLkrpgoLTENqiB8OTnW9rOIBX71zpUjgmp0STNJ98LoefcYPZEckOfDh6kAPCZJZAIJRQZhhRdaFeTdstvaUqYDkQ+8WVBC1Rzv+/9qm99y3hBP+6ADoShlm4CBN3dzbw/rz/szOLL7NhmB+cDSCqFEiv7nnh2WARWNUiyVbWAf0KVyHRiFZ1dU+FVeX/v1T1t+9iMABI2QlhpVBOk1NlpSn5bSuQFJl0+5e2LW2xwtx5gzeYGbQZgAJBUoVQp0SxWIpIt5l5A2oA0AlJK+fI+o22U5ROR04rgqpLTell+dNK3f/Fxsnq/93y7/7ZZ7/5f6352tsiOnRVQEJ9QFVwKnn3Nm96SS6dXIos0eLC270yexxfYToVusKZu1X34/pVwf//Zc7OzUtrc4bW/uEMxaUIs7uJoxsHwiWTCZu/L0PpP5N0NelLWoENbSd0V4RqTZi6CvpEUqpxYFEoiXAW/3OqNBfpJRvZRh0LkQyAzFjz/W31Iit7s1xRe1wwYQksm4CUwBbXojW1l5+/Em3RARqZEW6dDfBNEYQmoRJ3Ee5llK2yVRlT0wL14GWOPUXETv83/D5zrruTbZtAwhDkMUiQPOuIe1fEioiEEAKkn9/8fppF5axZ45nlnYoEkSUqGXXc7c++mjTbcv8NtS+65hWoOH1YAqkcbguVS+bh7pFSRCbRlw/R0EG2RQ6Z3vVnGBuiAoJBjFELXN7b5rdDbR/SHq6WIRDBClXEYv2fLcAQoMWE3fgUUU49EsAO3OnPA8xbHgkSYCIAAkPFgOr8EBBgBACFCYIvpFAhzFFHIe3aIV26oFiwiBQrVqFwcELh44ciJQ3Fm3coPuLD06gxUnY6GJ6bboZDwLCI1i1OzUN6qn/EwGg8yYz3PmhcmHC1Mr9QfHXap/r2bFDz7tbye2m+b+1n+wOiPgcfrPbJJ1ak92nMbG49RQafJffWG8cHMcV/wZgRwLEIkZgTIWOzR7DggMKSIyorYjTWnNDZkDDCIcVgS8YYl/zOZMeZy9tynwVNhSsscYlIuFLxoxYuVrIME07tM8RJsFi5ajXm0VvOoNlG27U46Nh98jdpBc+6YSifKkTC5kAlVCqtSnUMcgJbM/PTiXCkdKIvr174fbwvNOrhqVg4RGSU/GhEVxRNg9QnQmViriQVelRl1EbtbtjFL531aXJo5U0go2NDK2/l0oAwcODAPc//Az9EqcI0s9VZrEGT9TbbqVWbdus16XRev2sGPDTklXdG/AwGdVERE7H7GQ4BDnE/40zJR6BQ0RKlGSdHIZ3K0ODrgFQ+QDIhkHACybZAogkkIYHQA8mOQDIzEEuAuAUkKYFEEUieBGIZkKgDCTuQSALJ5EAyLpAMBZLIQOIZSHwDiSiQ5ASS5ECSEIjdQFQACSuQnAoksYEkN5BEB2IaED+A+B9IrAMJE0CyJJDQACTrAvEbSMICWf5z9yQIAwsCxiFjscbjQAaBMj2UguGGyo7hhtwbNxQqpgjl6nBDyz/sNlj3ncXI8swreAmgESleqkyokgEp+xfmlO3IC1HppHMJo6gLTBOyWQxDrOdb+nZmRrOEFYwBHzrnCqiu05A1+MiSYAmrOI7Lb2asEH2DX2MdB7FlfqFI1IYKthKbKLWj4sHL/rlIm8HW/4dv/J+6mQV/QNSPTea/B7Mfg2YbbdfioGNOOqvXFbfcd9Ixg4554Y1PvgdQjxiI1cGs8TiQUfASQCOSRrxUmbLkK1VhmtnqLNagyXqbO9ZOrdq063Q+VFeObW9wiybbtkAulPv6eEwmAMc2GiF87cjMbUmlqlNWVnjS7iDAJjHZOEMiebZpZrYGEi469vWOEw8DG9omjwpdyianiEis3ESXJ358ts2AWE+YsAQtxuM3+gaXJlO3IjGjAksIvDATFrmXcekAyTgwwYkXMpWbQW85g81aHKly133AoE9CyVKOJBjTakfrOhaSl76bUx8rE+I4NSUnRU6q0VurX9BARxvWUy7wc8Njd6K6GeMa6EYkv+THKrj3uQhr3DjOpyIOJb5zSh4RuRATkaCTDAnNxUKK+xCyhWTT5MtNQ50ZOT0S2HhG/Do1ai85si2O/dGb+BBCD4j3MLGE/Dwed/F3CZa85fJcNNDFeykYFh6JxqnuZ2ChqhFxzpD8vejnf0sd3f4aqWuovfacATnFkMzYr6h2qfmFHEFfjgm8DcEdXh+v+S1jNLuHfsWERlCulQB7hvFMBQRQXB29Wn42+nIjGZs7CPmRY+r2ep7KMg4SNFDZjdvnvj5VVS0t/Hy0tVCbTaXKLqoB3+AuGvld+gJ4SgUjSDKbe/Dr5a1VMEQT7AoCwJVSdijKcBCVeyZ0A5K3vkDU71U5EyyGlZt0R5a5ngEsgb3RLGw7NfdVXJ8hhxt9ofabb+M5qt3DHgni5LMn51DB4/xO2PBMaaPahQKqvbSCGcoiV8bEvCDHqKE9Chs2vB4n6FhZAbU373yUNOlyaSZoze7y2z0RwHtGBaTsnlAjypDnOPegSxmBJMesMqsTPjSRAaN4txCpsUPEGVaxsvyq/wEB7IUceoFdkH4PnOSzi9dDVJQKICuSkBqjOBqp1fodjEyuyge91BLXaROZxDND8pEy12qADZnCHKvTLWmbDIhKSgIr4Cu5PXDvxs0lZ06BplCLIxKGEI6zPIz2dJEmilHJUf5TgvLz4e/9ZNE2q5qY2jAxZeAOw8LjUGvCSSWXmv1sC7uN2zpf5s3hXbtOo8NqZrd1YHzs3gHW2cDQtAK6HQTIrkBooWHjzDj++ueTDCtv1nY/M6nn0DsD4w72pxbp+IMohqf9jgC3nAU4OOTDbB3/Qka5GI1xhPPwQI6HbItzQ2iFtufCg8g+o2VcMWvTNa/erFZqXcRsL7wWdkdZcfmMfefoLqAwQ80lcvL+nfjEtTlstsT9dbVp9gal+dIxMyhn6FgBwjFR6srfmolNqGJUfhAPcx3Q5T0fnlD3fcsPYBWKI8uvFZrLKgUfuNVhHEd1y4VBCRW+5U4gw+LFkzky5USCT8aX8E5GMHcISkgImRl7ch55rxERzAiBjomNQ8CBhCsVdWKJclN2MCM35Xh7ZcxGNKeAMKT40AQ5IjKjRIuLcevDNYU5LS0A5hGxdX1x75SQkjxYdZuEPMmLvMnn/4kvhI3CiAVLjvzEiBMvQaKJsnRkyYaYlIpnGCGCETCaGQKbCI0DR9acOOGQkbHlzA2XO18C/oJIBQvmKkQIN2GiKMSI4ylJJh8l5tFYZoVMq50wXqdO9bqctdB53RbrNWSZZ57b6aWXdnvttT3eeKPFe+/t9T3mtWaJW3ci9l3OkbirSUm7njv3bqSi6iaEiFsWwCS2rCAAChscgOlwJHZ4+ASEhGyI2HPgQQwsRwfWAawF1lHy4AFs5W+UQGpq7tTYwNK5RQV63ghIyoPRqEwBNrnefGC4cjvZKWo+u4UgSyu0GVER6FNxsiDSdLLL4BE/soBEZM/mfpQtLlyCLTBNTgHbFBKTNbMtJOFAzGlbGWeWL+yCHgWwBgKsBbSM1iXAW8+PrxgB/HkUIgUZgYJJA9BHkJenMMbkAWznkBvrsTA0AVZpgJ1fQLtLZs1g6pSnWgyn4CQkcmTmLKnRmWCQMRHCzAsVxnVWJjx5oBtrbO4Jlj5I9k1VHY+ixGYPcMpr2FPxAuhdCioMLrvdgHPbexI3OwJhFQGVykOkQpCxmPDINkQmc90bYijPBKobR7WuH07EAVgJYYnOaFsTxsxY2BQmUxCmEQT4ELDKPwaeCQU3MZxZMxuRlIY7PnkA9G0sdxzBkRi8aDRwlFQksARkAENVccH2TWfHnb9tn53XZMnQ+01jCXgKlSLHZLX3/0hHetpMHXQjbTg3pNzwcuOVm/jcFOamNi9rwNJEXsQi5CVMqlwV5vbBCMaciBtv4UbTmmJebxA8tYKPCGnyVJqv7SKx4NBApkZKl69KXTgOuU1NjZKhQLUFOiZuC6byF22MQlPVgymtKVWAGJmKTLPQOVNvEaZWGiXWWMWm04NpdwpTBYozTokZFoHp9wtTBYk3XqmZFjtho7uGqT2oJZhgkhpLwIybhxzcSnt0ZllKrzbG40IjSZYysy3rGpj4e4NAQiTLVm6O5Va8CbsiPG4ZYVqlKtWos5TBelu1aNPh7O5/8v/Gk1yPhe8+1VEvPNh54Y1P+V4AEBhYrPE4kFF8e/3b4wsEyDRNkzbX8q4iTM6iFaq3Vdfro+dluhv5XZCEzpTlyX1Z5XEoIuFKxY9auFjJMkygVaz8Xf2KHwysgTpLGay3VYs2Hc7qd8N9Q2v4STz4Kd9LAQQGFms8DmQUvATQ/Eb+I+hLiZcqU5Z8pSpMM1udxRo0Wb82L2anVm3adTqv3zUDHhryyjsj5897iPQWMFRMbBwCYs6UfAQKFS1RMJjWfL9tGfsH91jxfQRhIcTIBq/XLWHU2DQmk5/DzLCYbwRz13dJ7BWBL4lT2LGXnsehz9j43QxbCk+rLjwtu/Cz7u6MDqIly6RVqtJs9dp16XXNXYNe+eB7MERHLBwiMkp+NLIUKjdNLb0Ga2y0MwSkbwyHtjliTEmaYm1uKhGsQOVy88LE4tWVPbk12t33s3DHbzKmchpm95yd+/OpoeOCpVqRK3OVrpq1dDWvneZ90+jFIWjEBrSgA5cwKL8WW1PIEO4khjAOmchAmk41/f+INnlrd/XW7+bdsk/ua/vZ/t4xyaKy3HbW4eQoI0JH/d4asAQbMgQiuclURriTaQ7jbP88c414RFL8+rOgXh3mhiNtcbg5w8OZnR4ZTU7mynLrYuhnSq4jyfJocjijPnHmaMsmwImUaM7mKliyeW16z4AiAEnU+qG7Z9G7YeJnw7VoXT/U+ZAcZyl3lmdrFbxz42pq1wC1OCTHWUld0V8pWKe/ktJlQCWH5DgL6VNKDhTso20hOgcoXkiOM5ZEYTdDMKFrIrefoN6EJGq4tx3IOw8FD2hcUtsN1RWS44y6WiO1bcStg8LbjZDNPrTZ04e3y8H6wcPaml3tQqu9/LC2dLWGBtSmDccPHAl7gLreT1bDmbMJZ7/X6sGcsFa2HXqPALy1nH2m41HNO6QWcDn+z9gzELl5Af/g2HcyorkEf/d4/eYozUH4W8Yb66I2BviXjzfTRmsq4deNN9dEb5KxO3ZUqPERh1dmPHcFRo9XqOH2HipfrVv1D+p5+EXPGh7VYJxT7jp0+7R5OaXbDysesUgAhsLv41p4FzpDj3lYOTY6Cd+gb53M8Ea9YerDq/WaqQgv1gtnQni8njrRWZqxqISHUOFhPBNbIYxrnxcL2Vgk2fcyb5zxJphog39stMlmW2y1raJWMVityV/WhAXIUP28+bAiiRY2C2zOLNpiewiRABVxDDwOYqUa1/b+TDXqLGWAZbsdHuPS7ZATUfRoc1L0OuyU6HNEp+h31Glx0TFd4pJ/nRGXtTsrrjju3O91VYfzITWNCqkuMMxWjOy0y257tNir1T77HXDQzbCUZyS7bj169el30SWXXXE1LNqMcsEhbQ474qhj/tXuuI6wZESKyFiLkN/BAIHlDyqC2VCSTbb6s3FukgsSB7ucKD4qylKtoRr6h24CubfctsdEgeLCywJl692u6gU2MRvkeR2hOYZbLkYQdGHYXPv5J5znsIXMuXgn865iUkGChQgXK06VWkucrtRDj0U+Efk/FAkZsx0spEy7yGDBtczOgK25q0gxYGur8yeaSGghDm9CSA7m4opUvDREBuWxyQgcl6/INSnTBGU4GXBT9oCCwvrX5D820EnwW/iRgwD8nPs+B3oyoEydjsAcDKB51JfdwkBmwCFVJ/K1eagv74/KyuNmF/hvG19hCfIkCaI2toTC+QszMReu3Ci4U/Kg4smrSFGNliqtGFrEAYbZVxGuFeudfZMt7rXKq4Jl0VSbX/MTEF6vwNG6YIOU5ef9uis3dr9gaVLxvB75f+wrRI7Q5gbuVKHaTCuttVufXv0uueiy6wbcdsddTw155rm3Pvnosy9GQiAyoiAqjKtRkeLyFSvIUoMVVppnscyOai9fknQZSmhlyZVDpgCbRT1Z4RQntrHylBkjuzEyRTTQJOXWOJ99owQaLU2K1JKDjIYDstOVLqNbbjdeEcAZZWrozDLDQnqL1GvyF/C0nXbZEd8CeosstMRSy9RZrj5SxwDwhlqEAG58qWXKMsNsW7Q4HgWZs8Vnz4mcO2+R4oxVYIrZVmh01Gtv/cH28Zgx0zgXZq7zIKTxYrwZn2IfSbyzK517Qaf/rMae4ISQFFGzcuLCFZhtlKkiomLgUjOXjMxPO6I10b7oSJEyDboppMrqRGVVtapV9desOqmzxm785nVgf0bhDAV+BDOWbGaykW20ckoMeBVPIoklk4u85KtoJWqCijWNefkhvdFPW1tZ/rwHAjgxXoWKn+WzKzgiIIFu651zeQYFHRs/4x16WLqiOl6ZlV81s0yN+4Hu0gLQc38wxHbq2wdlb/onNvfixme8x2v+NYXDH9YiWIpVffSDadNPbP58h5CALx4uOwOuNzpHh+Mla+xqp0DOKSZTmsz+9/9rmb03fO/VvWf3hu6V3Ft0b+q96ruL7tbf9ZubIR3AJ8B34I/0+uCQEE+rDt169bvkigF3fc3vwh7x+IgUZdfETvykTqZ6DpdQWI5toBzYVzY5mVmjrTnjtWuGOpVYc2rrR7uBYot/jJJy5bfYPYndmMZqsEijW3XdDfMCVqCoZa6xKFOcSXTKlNceeVTkDOmpMUt94Xb9a6XVxbvuGmtLqb2mhGNg77b/av1M1atPv4suuZxV1902UKf4kOiwsoH20Sc+ImlJxjGI/oGLmIjLBKa4otJVVa6Z6oZpbprulhPZNds9983xQK2H5vrPfI/VGXQyXou98NISryyN3zKvLTdshf81eONUgjoT1uidVd4z+OB0oprtW8W3evbw+tsPG/z0j182+m2TP7A2gCthsC0cLuTQnmjQEh32ZgStMWBfxnDAocxqi9XhzDuXUws8cTZJ6313JnHHsu54tm0JwfZIcDDTWieX08trVfM8Ms54xc002yQ6NcpNMUuuxKbAlK+TyJYrduvFIoB4vb16lr9cQD19pdMQsym/HuZZLzVUmB8V/banD9zvfKcAmzxH+u6ByuJZKENSj7JnrCU/kefSFkQYXEUB53leUUGs2IoamA703NUl1zAjQnBZzTUub3pJxW8LMIlUbOJEc7EoqqeHwXHR3Laa0NKZP7d9G+D/hIgrWZjN707Il35fSxl6MgMTop0FvSE9lN1jz6/BBP5/AZN+lSaMsxs7ul1vqU2//PYXpUk/dtaXF3u/V2bxajvm6lGRwcA4seHuASqxI+MIC/53YI70uXwg9ofEmEcb8ZZdwIUMqtcOQGVMOJKvPXnv+u2WG2b1hPVxPO3JiFSeWqlUp6gU992FB70SWVKcVrRABxqLExjwk2cQHcPojLVKyRVdXpMBH5WDyiFGlzVgeNfXxDXnbqTtWkmk+QL/HTwf9RtN+uzDJxO/qBe1CvprT3Gjk+587KliAEZcLqgihtAZRScgvrZIVc0ptWTQbewIEDS0w/HUSHWe3ts+K8gOrb2/GCWaEHZuZisNtOauRIGEQm9xye2NxgK6tCqYcjqLcWGYnD8zfW5JaisG2vRXpH2sxfUNZL4OdHRpHAftMendPfG2RqzObMUusurZ5e+agRV7aDhgd/nm6PQXXbaVvQB+jT2C1cc7I0e8cGqkTqvCPgPSz8L7pyCeKd5+89l8tPqA7UYWA8+SIZ/926+eZWwTkdWYI5PyO0/XaSjFse8qzyhlLncH2HNRFgTU5o2cdybN3k6fNcuBva6Vf3rsAwYFKj1kjJzKLgf2kJ6ZR0EtSPEdNEMWWwrJw6+EMLzCCixlavebZxodOnaiYztSZ4dwMlg6J9NyWZxzykOuppScDzn/9NX7yo4SmcJ7XkUmMGAKhkzDiBkYMwsT5mDKAqhZCDMW9duF6H6XdPntNy+oKa9nCtVL7sXElJGf9e7HPIn8KrI5ljjaVRxCKUeeDuZSDRc4xyUqrlBxjYobVHyCiluo2KDiNiruoA4+ADYqKxyGBg4yGvkVTXFy6Y0DczWPUODe8O67SI4BDCjJQRJX5KK+4EjDKA4nnoL+HsidoV1jOxSPu9mG+c4/UgX107ypAF0+A54L3X+OJVBnl12J4mLwoy6X8h+AF1uyks/CvJqXygWwgUH0Inku8fpZdIn6+kbFq2RZSla6uus1spIFQ+1KZHWmbHqdPu/HeUuE3zNX3F2jK1chzF+Z8cgbkPK7GnLGFjlJMSfy+1xbXN5PBxHYSFdo4zaPmlaWLklglsCfrye7+kt/YPSSmnVLurSi7io7GBNphZ2Vvp3V8VTVwpWO1kgHMQyT0DJObdEwSskyTFzxe6JAOSxJH1dMU4rZ11ZWTAbnG+AYcj1V3YAF0WMtBtcEJZrEQcCSelWuojY2qg7pOz0kkSnYBIqysXIcvrcYo9QemCGWYPohWpaEajmeLPOtr7Eh1jBPg0gpE5tztql63W6hBcg1dKWktFjd049TWfPKSAuNG1d5E8Vb9BANajAejl/RfzJf1GND63wU5pYLsU9P/8V8qv+MzDP2Y/0cvPHMhr8Abz3NOzSvPUxXyUbQseaRmry0KE3TSFovRiYtlRvHqlxfj1pWaI99hRz3mQOTXJ3/WwwGjOrgNWz/DVkx1lQKVkUkr1dx4xpJvtnEu4IVqCjC5Ie3RnHKm4WzW72ci1x0O/Ju03tk5CfHS6N+KCevn+Tj0Sh3BTX6tCqaMj+hMsdPpM+IL1DglYMvA9pC/GaCIICEUWkZogAkbiZIAkamOJBg3kJGgGQXEOQEJH+ShFAQIMUFBCWBVmYHi4EKWqTaTFALIPWotAKNAKTZTNAK0NsiwYLQQZt0FxD0BHofIICBABkuIBgJto+RZRSePgnk4NTBKbjaLMdlCzx1fpgCTRYiwlKErFbKpAjroAmboKlvgTyBnTIhexFyEEkeh7AFp6AF56AFl6AFVwWQmwi5iyQfCNvwDNrwCtrwDtrwUQD5ipCfSPmfFH5brdrj0q0W09O768Uaq+r8zmFDvfVp8Yf6p11VGATVP2qAfBbQvBDkiWDaR2DhL4Hhy4L+P/DOB8B/ZvCYEAyaixgvyr6uQmgnduWWXmcr3fEMS7URLFJBJzCdTHQvfcb4rQLWEslJZgqYoAzx20hs4jw+dTNggClDn+j+BFSWj9HkGBQrRwdg+wSLBHDHsrkpMxAoujoGTT8SSYXoPNRMZCzQTSPWpLRhbrAJ06QH40sLLFULvOA3MzntobvFntcEAPoDtDC0A5+hwENd5B3c2Amg56uAogpRJ0tRyy2IIbR6jiaVcgO8pNQJIPMtEMchXLdtYWLBPZyqolWhRw/dNYltR9eC1gfZR9n7T6EVeBD50Jq3CEeF70eexdLyBHjpTzJA8O3QuW9R5vuIWh1yVOaguUwhQAi0K9jKEgYQihLOdrIsh1nhbqSVijh1HXuQ0IIWdBxmx/SeliJrC4PYE2EolOtJZ04eLVQ8yLTeeXZle0+WW8uce7PnsO023W63tPbCyLISx3HigjGIAs8NEPxfieL/NpvS1LJsMvhIhWcTIGj2YNsKLrKF2C5CUXsolTDk1RWFgfdGd/OrRjaTXYRF5pewTnwVHacL10HX/vWJeGBmF6GhBuikDtsHAPHQQFcn3gc1OopHkM10qQpOOaAhgPqVdcMBiQk4EHS455HN8PW99pOY+ONFAA2Hz/c5DcTjqQUdkW7S4xFINppSgvCMI5oqyGDJ9jOiAcfN3O1O9zqOJaGKyN4HmnKkYk4oziLKJubG2rIIM9qKMUet2HsaxoOHUKFBU+vciFHqLelwGpkcQBqv7ayYgCkhHMsWhaeybyWoKHJrncJ49Gc8Fm+ktJm9vKL28fLGxM9loDFspU4FRRIE7YTgTQqa5z2uaruW/PCldhETP3xBq2ZSm3gMa0AJpaWUNE8UdVHj4ydG8n8VD+fmE73r06Bmo1bkVBZcLzmvq3ioc7mDI8ZRGSoYrmDMxbm/uNBBZ6AXQydRb/IXTwYCJSE2MIscHjwqgVXOGueiaZb7mgPJiQvc6t5aantnfvap10T5dqEThKdRm2ZjHuahqn5l93YUFcM6a1IbPs0UEzJJZouh6mjVaC8yGyhdP6eYxjzqa4qTaxaeNhJz2QZVhqZYaR3MaUzT19E1zpCcz7fx/8iXxaYmkcp071gMNbNb6jrZci12awoZ2sTJgmXayod2MQHFwhNZVw1Qsg4T5Kmlzx1tKwjvsuO5sv00XNIbmaIgSaO8Jt8lILPzIrCs7tpx4nKunZ0XdqZmdhHgYtRyThZb+sflroWxBLaMSgiX56pshPQM1JomJpsdbmWvpKyuhE1GdKPDvkbhU5zk7psDfYrDzJEMHglVgxI5iLV1zzM75bAKLFcfr3ZwZGVJ3vc+YXoyUMJQ9SDklND4NaITCQYJ0W0oA3ka4vDKVjCUoQorCIGC5yGWhJADh+hOrm6jYwmxrYCL0rOj7u2XBOIp7d3I02wE5r8vONdJCB4jPdeF4y6lvVD853xq+PMtaNZ1mTZbjOYu8D09PWawX6dStjqJaOkHNIp/omiavhZvCaTyN2jnK/nrHbpOS845y7HE68oP3OSYNSyULxYyXMB6AVCE5NHzKB5eVjCsES5d4pugdSZ6t5FN9QQ4RF9YV4EBtPhSeU1IfStKp/jOove2aITicDbDvrJvvrHqu78qNwd5W//VmqxFaePHyigRJHAdzc+zePoAmsk0ioebntzDxBw1gys0bcPqsyqnFzkMrKLrH192deX494z8dne0OVcFlEnCiPisMD1SNKN1cq7DVswuIs29K50xZG+DaLWGNLy3l8Hm9JkH1d85/PhfkaNqYHOY3F/smPgpEAyvnH4R3TK41kPpfHu0cg86PNGTe1A8lfhPrmCIM9AfIXPcP7olWHHZZ+5jX0n82i4+vLACy37J+TTQny8yLwjft61ZlI1QZcRdxHXzxwmSplEIjjDgj5H+ZiVBkuxWG7kryW0NOdN3eM7k3+m4hSaHyd44w32gU4NnBymDzx3sK8xylzPIoJDdkUIBcEYoaCMCBRxJCwCVIqvwIhBeUhrMPIcaDSqEvChnE6ruNaAc6imbKNXP1sjUFq61ddLbrz1Uob1n+p6jEvgkQZxXTmbgooYUWameCMaQ4TW9HLMKww66lqbFDXQ29VR0882iYfIHDlH5HpiYDW0QF5JpnZptYmtUF/I0zZVBaMfkZh8c/U3nEjo4shFY1Xa/6MNt2uvENqmePv16Hy7sI7+Cyr7T99UqVZitdM5L6x34bYrdcmZ+6PNhLd7Sv8jRY3lwJj/rO76um4sNDZ1Jhz4x0mJcfzoppUqXx+jy7zOdO1Y9a6dngCJ7dD/7Wrlo0zguEaPvbqA3dm1Fme1y18+fP5rf+rnTcCsEKyOqtY17250bMet02PaKiMnWKwx0mpwEalsyhGoZQTGkykLOtovqc2kdFt6RYvLtznUT1tEeHAHKlvt2UwNN46FqfgkxhtF0M9RtWp7nhBVULlu7cB6KISmprPh+RkfBAI9F2IoOScZPhbMlazX9UmKsCF/VBGY4jCMGgqEcD7IKY65uaqxAE6hUkOltk4SNktGQPWD79Fp9ZGTZxI/i5/5BL/7+i9HtKL9+tDvnnmb6pSDTJma2Uu4GeJ3XpbMaOBc4xN0XgAYMW5TTFurK/LS6wGLLclR6WuQLTZDMYkNflOWCUbaXslJI1xuoEiSmWijH19OC6Robd9GyGSmsl0VDthnmOjQ4T7HMNreaxLvPWrcuqgGPkYOCZMOaDhdvseNXFS2yO3n/1AywJ0Ka7lVySNPU/cMckcNEC0096ynf48Y/PE+wIUmODSskn38UE1Gnem1OSiZ0PW2neVDRwgt9Hfcv+nRMVAqXRxsh1EONAgJNsj0Xm148JdL+AuDpr8GjyNBcJBECEi67RZAo5Mu08GUZZHVfsf2M9NFm3FgcB/0HCA4aiGNAQqCbZqhQqyTsRhHhLGi7gUo6C9RFDGRqHDAybAyg9DSs2EPKXuQWwuaaHuM57C03cVkykK0BOdjVsRrZHsXJuSZn9gd7YLnpo7gyQrPuLf7OCcHnmxcerleNVcUxDj+Nq1BBNgQGu6twWEWgj5cQLm5+IX6eBkpN0x5AxUANgSGquIbop7mwExP11rp+kN2BNHfLJe8HG1zKHmZDI1KR3VOJy0W073tbftHtoCcH+oLN9bn6qPXnc0GX7+kBwVVt8bKUhwe0uFzlBTnhAJrsZsdurizKfs+kNEedXS3rKMVrY7MWIa/EuoCCxnyMo3wMtCRji3hrNb6ju1V8w095wqZNQU1f2kF8dWMLMiayfCvQzeNksAYDd5o2XVLOMVBJRswPgIS6oeCunGgkRbIRC5PogrpNsRvliZpVnctUK7VOkate3eIyCOhPGim+zORgSUOGmziegRYkQFzZyGSnpwzvCYouqa2LeFFKbNg5PyFURZe3pnW2eyemJyIqa+NGCj3bwBYaLlb3AW3zOX030KsWpYJBBGU5CEBCiT0h7TA2g1tvwTRPF/TR3uRNQXGJHDaBDNXKOSFUQDfuMtBqqNf3C08RjufB5iaTxcGsJomCPu4yKD4PLKfSjh8vI8MFNORk5Yd4KVq0PyZ3SKEYwZvGRaeyIZRaRky5xuTa668bg1uxC9MkB5/r72MDpWE8q6p/WmhTxygBTdaXehQWqgXOUhocyJYLlbK4ZFq+YRJiU14YUQu+0Xp4aiQNtPqbu6yhPd8YXHCtIj10neOtoU4PcNdoJaN8bI5k2SNQbh5GwOlyMEJKeQXsuHN9FqB0eAkukZ5bu3Bo0y/5EkEXvbaGX92+rHfJb0PztR8IUrBRVX10eApfTrFoiilNnXjoeiR4vgVycMADs28JhIBDDF30GFqfaRAfUHfjZzUhzPTP7TUGH711dSSGU5l9L2JLnm4YeYMs4r0NbP8wuSChbuh5clMnnNgG5L2tY/dhWZcvLIioB1YgAL9mBuIdIq33bajuB7J4Sjz2PxQHKemhbN3F6a1q4NFYDqtyuezrS2Y0eOjE+OKh8JS24pBMAq7VQvfXGNU2PtooWrjJ0nW4eexaTclrfLoZluwSBUD1PjvByM6tZlf3IG5+6KDaAfq1WNZIuCC6jbcopi98ZOU3+8F91yCJTZ5tbxtjkFiU0reO3Yfi3QOoNsCYJLZdf7hwa2XI3nK87cfWel62RvuBwHyKPAg2UqajazZixGAxH13/YH4YP+T9oslOTdEZnsQHJGC2s7TPUNbStkZaS8T+asoOJNz4/w885sf2WpVrv0r6KvYT8wxWzLNP7NVWZyslKhatdjW5jrNfufz3G3zcXmuTLscluYK8T5ynDyA/upEf/9z7R7Fi5KvJFXtKpfBjyvzAcrx48zD6iUcKHDG6zu8Jz6hfyOr+abZTIsuh9/QTaP4Y/DAYDG2TkPqYhCLfyVFvG9YhdORJHrDM5sDtGCWLWkYa9EEi2cHHSxWNtHyU3mTRMDMRJSml2pN7DqSmbKRkQeZkGr9JL6ezcNtMZ1Lkl9fqpa7H1zemt/GLlB5OxYwemJY+OPGRx0HSmkM/b7x5SFuXW6yMupeQ47vohEzn8paEu2TiG8Of1mu5l0/gRKblqXEVc0fL+Sxp3JEw+Jw14uUFPiAvEdC1xhnbhAL1BxqroEkE6g004UCTKP0UyiNYRf9v4Y354Lsxna9RxmCB63xJQhI/NmHT62T47xdcFgU8nI42YXQzQmsABXzOzuxUv8EKfa8fonMNGt5IBpyRZosK/kmcC+Rva5g857Cca4ye8pbeFRp+KHXzhS4Zh4O6a8AyQK5xVfMBfMnrZUqrXq6zooq8JXeWsDpE4p6WA8TrZaUsjbkXxmZ6PdjMXqMZaBCt+fybZYSfmC0tDyvm2GyKueXh2RICXazAQ8O/xc4SlRXL+0lS3l9WPEtENG7O2Yx3g6Yep8vU3Q3aQ8MXyeqnBovhh2YyEBo+SZb8C1rAAsf6+IiZklBYPje1mfFlMv68mXVcfdZoOk24tIShr4j03bcoOrHIhSLLDHxnN8IjWijyrAM0CzUW0Hj6pSPxYZXwEpzBvsaTmjTQ356/QXlxWIifFNegrA9HcKlLq15Zy1q+RZMBjWYSeBbrZVhZ1uJhT2ZCBhwVSYo8HLygkOcZbBPeHS8pJ70oFzNSrrCbe2Cs3+PFZsYlzXmldoaG/wyuUWkrIVBbDbdh268bG7bxtqn+KhoEsdmKdoPOCzl24ug+V7xL6J+4LMu1sTzLX5hy16blocAE9rnLQ1kcIJGrId05daHhl+pSkdynBM3hHUd1xbuEy0SrG9b8tFoEA3IFrK9IiHe0E78bBe+a+RIemGPKiTl6qp0FpyFOUMzADXyCkgdN1335eJ6RJco4vTSf6fiunYmmoS5Qpy2vVXmzG8hE8l6jpxGyR55NO6uRugOFcnlRIfs1v6fNYe4dhG3WQSPZq5ZxLoT/QP9EXZCKJ18Pg3er96gn3NVdNsRR/BgOpN2mfUYLvyl/4629Rf2cGh4tH/WiE8dTjuTcmnZ3mpsLk/3E0Gr2LMtTd9/Za3FPiPHa1JNcxBfpHXwGyVXprdVsDfdPmAIjBoPIQrurjq1mo+ogS+rUv6KVPWGNE6JsBs6jK1wEqebx1nRgfzm04kYVSHSZkH6nExnoNhFgg0ocuqSX+4SSoB6QBGDKZd4nDQB6hU/0dvIdyjBJ4+8rCMRBUHdaAkIli8i68GjRdKbYMmA093td2OMAalGX5+NmncwvoiD9QtnXJ5QEAAh6kzpnCGpQgeYuEzLgdCL90TKD249djfMc9i1SS8SR3mirGz/eO6lXAltmmPABp8vc349awGk6XYuFf1gucbq5EmExfUb1Z47rbsyt85Z4jKmdHyZBJ7fHSu5KjLOx2bMJ1vXId5NPmrtM6IDTiTK94I0qccj5zOJoma93EF38g/nQ0ro8pTpUoLRpC8WN6iM6uqQHE0xUHl5WUlrnKDLqAZ3O4TIirVimI5M5lJaQtnixG01A0GGX5APf56XF7GBhLXmxtDjmX8jTM4j95Xg5ZnXCo5c/8qrf/iPEeKw5eWx/4Q/DhiVKNekyIo7t2c10hA48gKkchUP+FxGADEjQF+jo28+8uz0HX8pGc7xlwEQMOJ1EfzQttmCa+7+x5oHHYSXlPqE0CADS0oRggTOkK+coIOiP3LVfZCTBRrWY5XjoCFWQNHO3CUV0qRVaRRGKUB8tqtf16/DIyRI3qlfMTsnE36aDpAs2ODIdNfE2VJu4v/zn+PdGefeRlQhdrFsyzuSv4aK0AZ1JIlfDflqhJMht0SQ3FxaCecysyEAtDUhSQXKxwlzM9l5d1T0Pm2fLJ6ipjA+tMRaa1qIHi1yYq7vqZUamI/RPAILRkuKSBkdwTqfWWp/fxmdfZwT3Hz181Pp1hmLi4Jre9cSJDO+8I4NHzDOOzj/681ED7Bj6fMvn/iuxfXHaTZ9t/cx/dVJ/fETi0Qzwzn8U6rboNfcyig4cP3Tc/l91N2ZUZ+v0Ajl/IwNbIi/cIMXdy1EBWpAUY/vJlp0Uh8Qgawi63+98o+7L31JW5s6WesZrm8JuujNnjum2wsGrefhaPSMytu+N5jDd5neK++Y5OoPnDM1fNRuQuw+3V87LTslT/UjWE76L/yRrRP9UwjZkJx+nf6O7d0/3Df14crahQv9w2CV/8Fy8P7Lqx5mhmLKoNUE2fXza69SMCaedwdWCHv24KPVmIIaemU/TuZr6bd8lfF1SrZn1CPvDaX/8scSg5tIW81/aYEcvhX6Hw4dFodc0rA4zpm2hRzE5X05MhPibIpgpqQkNV6j5Ie5V0u20LYRTrGT9IigFWoX3fRL3btdCKAklX1ML+jkezRdiGx23rTx6mP8RjgTemhHxUONf2czHGzEIf3/BubgpvSwjm4kJhLawkcViwywmJvwCPDFEu8TlXqKN17PgMkaHBEw8zL5Lb6N6IAA3X4KbowRxP+aljf5cCtdY016npv9DSZdzdaC7GJ0Gwnoam3d5TsXbLhfkN2M+x7cuqriAuzuNKCZVGlDZxPmkPTuqi23pyT/5cbFRxfTomO9sIqqFXR8dlciOsrlU6J6mqMhiNggn4zRER4yOsdjTd4Uboh1eThIkwYPNm6G2HXhB0fMLztbJq/v4GfAsvRm5HFiu9xole1SwwHwGIhAyjI3FYn4TjMIS7YUuh4h5ZGpWLs1jmebfeyw8N7BSU1MnX+5a3DJ8uXTAOZiz+U3gBkG4+V146aDlbHspemBwzhGipvG4cUYvtL04LO/xKUVcB3fyV0VCmSasVk6DjcrasFojcrFuXt5XQLv9slVK5p59N41D2iqQsFjslcmZuEHq3sexc2R8kyWXJ7QW8FEh4HINn907ROuMMuHjI5MLl5oODdU2VqT2akY+53UDmbl1hPv6RYXWsPCnYlNIu2lex58SkYiDwolwsikFcqloLPTzqnu5knoyK0/hFS3V6ZexCtayqf9NEAnWFMiuTvpu4sUHU2Ean4vb2JON3NrcvNlAZh6niUpvAbIGT5bT7LTnLrGuUqWuhqBAdFnp5tBmbxWLxHLCjiKEo17x3j7WXYlkfSFvvUT8nIkK7XyhXSxFBXuhUGgbaJdKebyl9OdwM276vdRFT/Jz8/NzFvf/XKp+iFpokRZK4ZaW3iX9F5sH945ya5p6urvnzG5vPztnxbej4ttOZ0mxdcA6VLJxVk/ZxunNzX0Leuv7d866sqh9VDXj9GhB3Ta/v7zaV7uter6vobS1sde6Blv5ccA/1V1EykUen1iJTdNdhPk8zKvo4vALb5bTkaHPzoDxqquy9LynfbvGugcAh70tb+BRVF+w/PxfJedcqy+cIbVPKRbKDyjZuaYKgCwQr2G9A0c/8ivcN775/khlcTQWoKnesjcYlYrKrP2Ibz4amKKcdxAhPyjZ5FWYipZp88uTgqcAlrPZmTOluSV6BE1eWWTw5F+F80LDnoptTVdW1c7yrROLD1eeWrAwsND96DEO4as9qxeGQWbI/LgR3vd/Rdbms3iv3R3Ut8a1izyZf/zh+x2B0XhrC/67UfApwpcbQd34NL5hZWMOdPRzhmUF/PZ9hGJOg4tBraq0UhacVf/a4GwAlZwjI6qvqaLIB6hiqUwlO9JF6DuynXgVUqHb5TT1DMmeQso0mBnojIjK3KWjczatmDdTHEXgje0aBKgX7v78hyXmovb/dWSXzCkO90lMua5Uhwh2sDrsukRdjQyeFm3+NkLDChhkNkolmzyMCF2bfGbZjFBgQIjjgSJ9T6vZ59yECA+RcmiD3yJud9iQtg69yUREps2+PVCRdQFkX7160yjrxv73735shlftaPbcuUsvnbh84uLS0YzR6Gj2vtPpG2gMX/um9ciSUc76B+ebm/t+37e+f+fiW2sq4x81jnlX16/ffuOdr0/te1G8arB1Q++cvDnfzWwFcxkIbBZx/yWzC2lR70924/JzO+zWczaqDPYj6N606IrvIjzeEaRcL6dKUBq1zfgzTR2SKUu1OmVpSKpWl0oVpTqdorRUqjIqLITBYDErFFazwWAlOCYGoSwLC7RZQMJbGi6nau1cWTZv9q1bSrNOJDQ7mEJViWLa4XAFR3RxLLni4htmDwtyQsmTodvpQgOTq0L0tsKdL5QCRJxvZWVuS+I7STWPN/erHVA1Hme1Rds9pu++Bxw8JsFV6+zVLC0XjFlpBUMAIDTT7qpjy9mIvkTCyJmu1BtqdboWW+Fuhdjh5IqEAXpdSWy3WGfuMtMM0yvto+HRNbx4tEUHNaAmTX2VDhBVsrnfAQ3qDjI/rN+QkwWgUz3VUL5H8RHcP3VQ7QG7GvUwWYgxubhYwsVwJo+HMTmYRMzBzcwqZ7TI2M6rBZqgJvnLZuIuETyXV2tohx7cVoAk/iiGx+k4GabaH41rxF7OpfjWqeRmoAfHDVlTM69Rekr3ozod2uaoMLdTB60Zzf2gOb6DtN6PNYrNxcrn0fBcLqM5moI+7Unlv2H2tZ6VSww6iUsoCgKAKND5JGKX0AT02124RG82Q+VEHEm8DlGN+97cZ8IGnE6snxxmczdGB2by1xwG1uq0LRb+drnIaeMKBUH6jNJJPRII68Cp1G588YA81mkemIlaX7XUoJA4XFypSZupgb6Mjs2Q9By05vWOlwevbCbKZP5CiUulkjijJZN/0QkuvV09AkY7LZZgdUH4xJEJ/M5fsvx6KFi0FPQQ3byhfGigLkcpcFA+eQgldE91CRrlo+sHy1fBH/6diHXLbycYEryp5jJCo/KFhRpgmqx2y2wDlQcawDFEDUOTidQvsBSszl4wMWPKulXJwO1DGQqzBgpuuu68XtXcxTnt0blVcdiHiUyTA5NZD5c2yuPN3S7T9vZ2orikee/G7UKrht8XDhORLRTaLBniz0CJ2HlTeY/k/ZaLQOnNjmbFsI7D1EkCdlOx1q6VYHwxgG77JU7zB8TONfQW+cZUpkSgkEWq5QInCfrUDpUSnNZhsY+PH93roIFG7h2rXGUiTDL+KZjCqLR4USMu5AOAQYAwKoGCnY0wPqYpLlDbDUK9ewKcaCzXaXRF08QtJe9YNei7wSPVlup31LFP9cXPHmg4fkTjyGa62108Y2GrTa0RgpwcU6HRZgVzobRuA68tZKGlj1z6lU6U6gtrWzjxZBuinx9eZb0w2281VsrOji7+yc3RPC96+aYqvlpXJdNVm1GwtkGB2iG/mbD6TSAUwCxEkbktmNJXem/ue2Zrn+Ul5LYuuxJ6lNCJUkHQZzBArINYyKA2OKUmhVJhkktlqNzeLKhCugtuEoLFIIwXnXyoMku1Klc5V6Mr4ypdWpkSf3gK88OQobhR0J49YmlF9G+VCVZ7heyT0XX3+c6mGjZWCdTa6io1uAmsScHJ3fnNrfBHiXtSUvYkTrybpFeTfnhFv3o18dU9Iat9bE9q9yQmAqe06arw3qvE7POnv/ohqZ2ZtG6cxe7EpLXjSH/hP1dme1ItkNozNmI6ACyUNP9S7qnv7z8RrjhBreuviNA/4pv+xhO2Rep9rWbnjK+2yE8xKWvWpKYX6t7xqbteAsmN96FsqABeJ7eZET3346ysjwr1qAUXwiY6iHFgKH0o0r3A6bCMF9OK4Vb2GRb7FHtxJncfTn5BoYykpo5QUl8qY/qtJ3zTTzzx+rLr+kXg+v4OzpjAn/C1mfa1lKEbTD6XmHoqKS2SwdUA6pjQUkFUpN2IdGykx/Mvc45nzfiyMIUydzLzajzjiIpJbzkT02Zi15nHfmeV5R5NyWHdMh/azD7zi1X6kYkmdv78PbN4jq+ptXBX8mUUEaGqKJtYU+6rqZhYUeqLipwjkzRLmmXICVP6maGU+2lp91NSv+CEL/pE6ovzZrx7EboKSRvWsTWgVl1wfErCNoZarwKQ96ogIDfuN+79+8giwO2ijlxeczq02S9jzMoZ5ZY5GD0/jWXE5mpTEJU06PvRvWcUk2lFuNa+2chRx2BkuKBfyu2d55akZiQmPuKTPPlYN3LoE29PPJL+ku8DMTdXhsrc3JageImkx3l6PuE97i3ufHGP9//pyNs+PgZy3RU9iImfJm+nI5/3eBYbk+LIO6dw6F5WVkHthmC0+oylVCwY6uRmAWWMwRZiDnWe1mPoaqrTovDKZmYhDze5eD+iZBznArGcbx5x+PY/JqLeYrMUX/def3Hdcx3z1lt+s/TGZRJxmb3v60RhsC3JIJf1qC1WgHBkOoL7BhtorP/Hf3M8HPgv9+2J49adPHn5Jrnu/HXPL1xFUCmtNICdK6hQEO0+EeIUbT5cGVBKK0AQFDOVEacZsjANLKVhx04lZGAzhSYShkyWSbkMo6mAnS6QzRChFgji80DMH2ZeoKQKI30BvzG181YSdGJHrPRKaqpogKI4SvWZOrm96Ev/OMtXAeSgUcCzoPFTIjLf9zyTgMYZ4N4YFwOOtygc6mWPdampk59Pec/zXqBWhsvVDyOj+XOrJ79aByG8mKO1C8vib8+a8IPGdHif+GNnDnhxUQNiMXQ340jUpCpwUvuvjnwjpeuVk7kemDT+vcLbS9Qk9aTWbctgICQteAuM9dX6dESRBpYnbWhvRXyP03C6u746rCxipxX47ot4gEKal4Y+OoNsdlSnSIWYHyUb1BeRT+Yatn/EKbuQxT1RbH825pO3PW+3UnohI6OxuvBW2/vNPkTnbE9M71BJbY7PkFOh9w2bkGURBEbzVDmfugvZiNQ/eu/yAXngKHTU4rRoIe3odJ39nsnOlXrbQyluFiKJmkyl4zQPhEGxtxd5FGUc4ujaAdDumK3ztSQSdgSZEEmnmhBhiCXB5u2YAzgNPfLZ/QPM/ckRNW/hCyZERngDPiT1rVvJ8MkTsdIr42jxtfj0iPDYsEkp1beToa7uN6InvrBQhi2UIuu673mGN6pNGzXGib4pavBZkHkJb+UxuN6SBpYh9ugxE2iImoSUpRvqSDjwSVEynAt+AH19cAJE30W+ika1RwLGS2P8/wc6o+vssW9lWTeErbJZoXC/DBs7PhWM8n3UKF817/cUzh+Jb6Z0YpELheYOHI2ILqRuTXgsCLA05ZGeJxJc3lqKXWXxkMhWBOodVafH68oESrecsqpRgzQ0Gu8h8I+HkxW/sYRGthtk3K3XwXQ4dSjXyE/d1qdC5jUb/0LQSbkCBFFLCf41iJ/Siq9MayDTSMpCNA29/8jzaK6eTm7lPFichCZsuMfaSn6HHku524w2tAH2hyfExTvpkePxA/Mmj8nBrDBajtueU1/YMQgjuC6+miut4mZcHiJyzv4ukRU6rIVSv8N66wIZjjQnT/MkTYs0qZsrTH8Omgb/zDVpWiLRpAwk/3nDTIYv3Kqe1VWBVLz5DKiWa8MAoC2rlgPdWBaS1dXV0J3RrbThoMFmbn3YmbzSxandV1+Mrx4ss0+OHQdOckWOx1mipNgAOLlBBwhmv5aU48nRbmHG52t7TUR0fDEYX7t9+pSugZ8ILZHIadxq4Z0SZpCajjzj75b0qsWPu4AipEjmuShbLvfIipAiwPMBsNDwBKjas5eEwqGhtmsePYmonNKwRdZlloVxWZdV5nJKfch0j560AXNsgAlg72ftz2Du5+ynQGH+u4sbABtik3m8+Z7wBOnvyAe/6qt/QxDHb+FAZ3SDK35eNrmupAocbF2dsvP17z/M02zh53WiOR+G8bHt1NG3cHlLKV7st/X6ouE8GYQqej0d1DMZww2rLni0nM6XOUn/ug6dy3hKbY3CfK99Ob47vme2w8OHNYiGbhfy7NJCLuJO0wY1Cpm3RLTN1palAA2JrxNBaGqdYILzjiPqQ/jQ/rjERQatumYOzkj60oO6AKphKpB/KM1YiQQQwIuXsYRKZTMYQkmBmKFcxdvx7OU7/jyt1Q1BVreWAdHvvOuslKnAGq12Gghpa6MX2D5zbfEmQ3s7MBQIAEMV+RHFxUOGtm3cpiAR0WkJmslBSSgkGSRJyazS0lkSkgiyNCRlToByikGp+8pBg42EYRgGXwnZLEC+yMkXOqQy+Jw8kYhwG5HJeA4Hr6PsOJyenUY9zCYK8uAcI31FDi9n4tWJRn0N2Vs473FMN/k3119/I/G+73tf+kZwyHKQbt6xs+7Mci7O5mJ8AdJwFpc7AyYQsDGM9eQNIVb4+5DSuZJ9ac7cXCjWGDtzisS6Izo92hV1wjwcy1pH3Vp2n8G2JP1dWZloTM+88nP2nY8nYjbPoZPBjO3F3hdExIYF/2VEco3p+2qykZ+SVeNlIWbkeGzXG4Lvnbih15kJJjr92f9cLp4kXOrI0eLaOyXJE8sPyYz8qaL3r0w2N1Fa5/rLW+LfS/FG+aJ3UhKkc6YYY5HY+Y74l3fouRmdWZT7sq9/mNs6LlrQ1smjkzkZmvJLl7ct4oFSXoE9LQbPvV48s39SrH/ck9bYa4xHNsba+QXGWGPsHFOpdVd0erQv6t2Ulvi4CKIVS026MvlazlS+1HhxYm5J8sdmrTbHsVRYPOnyPz6qa8xHzsyRDb6JPOLVvggyLgnJovGIn5Ca7H3GdK4v8r+5G4iIF9Xk9mDGyWcQK2LihTtTH3ydaUyvTKz825LEvs8o30Zdyw7HnjR3RXmid1ASJP1T4Fgwdp79nC92ZnVm5Ao/Lvjh64KfrZ4cks7vrKBFj3O/fMlJ+KG0cL4s13Eu5dvW2Cdx/rGT5swsvp6LX2HGG5v1YLdHRZ/rHFxd2zI1g5iRtXBGljXHm8ECKtXqWiMKNbToIN4I0nSp2S5vLX1Zi2dkWhN9sfoq9TTYBNW36mC3d3+yZ0old/xS/JfD9zR4Z+/Iuq4/nQui9k7aUi0jYXV5RG0rkABSwPZTSGm186eBGMivtTpKlWMm5gF6lcblFjekBHrRj4Kebnyvw1LSnA7NZmnzMPC9xPrIe0qJbVRcitiCfBWmfHihNlHpZPRYV6KsEneXilOuAr0MWcVyZqHtlaWXR0II2pHJUP18iwM2L6Riyae9dJB45tCAegiDHt2B+90Oa0lTOpwBd/Qe8G7ie5F/DRKHECs7UKkQm7h01AZI9DNSmlqrcFeJWI2pSzSXrKqmSaaOypKR02Jqj2VQqRQKlZvNonI2/8A+zVoYe+yuw8kvUrsB6hf2HOrNCe4OuaCWIDufQyYU+wS1JEHp33WIjFy13eNV27gclc3rUdnty8tyYr/5+ygp2yr/REejMjJKznozM7NQmi1FtGeRW/1uCvfeJSZr/5tgdlzwOWA9OyHAKVnwJTUhn3U3m9mQa9DJuBszMst/on1yu11IcgGBIW01hzbvp36uoYAxjOU0vWz7SnyTZkkB9EDb9eMLzxe710pFKJ5boLbLu+f9KMkvfMxkvWakHn4lo/3xsxiOK89amCL+ayrcdG1CQqg2XCrr8iukfDhXrbzfli2CiXH2rO/z2HAuExbyuTCeLzQwzVwexmD4eRyiXZvc1n7JRL4CTIqyYL9u+cQY40dSBsJgIowChMlA8u/QlufQVtCoK2g5y7MpPIL6LYfzwnpNkMOcB2WxAA+gzqF9W/oVh3ONoLZe+sIaqinLvqUso5JrbqPEQ00mcMucOURxJGRsNBm+RERu2MaBBayepiYQbA7buJeNrF6UjJ1F5Naf9EBBUw7iqsIwZeNWkuQxtaKg1ewHrXoRypFoAZXWrLkMs+hQl987pkIS/mMSSjHfYYY9OptObqxtIO1p8b42Jx2AC//CZIDChCj4awypuQELWbjjMlX4jZgPMCv/XFltNI5BwXyV3SDSeZ6DCVCZTqMOlItbPB9wNXnDgYMlZMkHUyePKIt/e6pnB40a29QCd7M328hdg6k1KBaEENKmzjGmFRn47S4yNe1yB4gHAU51S1a8qQ7VLChbbT7X5zXpg+Jzo8GZbKJ6blTj3CKhXFkiU9bgJm1NpRy0q2wmi8WKqVQOE2m2kW1NyX3Bh50faDAf+QGcX7bUtVtzbNIYlAKqXQYIdunVldTDEBQqJx+SqZSQnA8pV6pg923G22WYLtSXQBDibzshxaU6hbuYo1QVc+RunVSCn2g3+iBYXzJN0D5pBJuOauaXrzKf7/VivJ1S18Amq5aqLRLJFaWnw7TVC9T2f5fWm3Hn0962ZRT4b/NRKfDP03I2bl9rXlDgn8Mc9+E/563X4vb9roYC/0KqPiL/nDdeel7dqtMVVXYudzjcCU8YzPMt133izjneqJd3WgIUTsJCABYJuwwN6L8hH6B8VDgAeaYuPISkv5M0g2YAwrGXnUHKe4ouR0uplEpIt3TdyEDG78XGCvtXlpcKShXlZpTUvn2Kp5ozSt5LaOJUELMw8y+Fcy645JY7rri2mD2g+uB6nyc0DiVt2Y9B95kHOeeCW6648TGi6UGvEmD4OuHee1gDxOSYy4hzLrjlykcdUEMy9Yw1MnMOV5lRfdWRVQEI5laGk8xtekobeSc06MGuZgkH51xwyS1X3Fv0T1kFg1PRKl8ADULWRvkh8kGfrwdqO8AY2HwG06hthAvRBpPECTs3Jc654JYrrrnj3qKPg+dz3+A2VuJTPgBu4qCj/DEla0/kbAjwb8ZUU9sK+zGuLjfYKlPgA2yOXhw1ZyG4QB7dPwGvA0yYsmTFjLnFEBD5YHuPvTAa2B9Z7wDJgTEM0QGG6DABlsyYs/DRm6eNXhQQe+7GcLfeP8lgWfwNpKM9BDyO6gOPwY/hadwmPeMRSfVBE2TmnQ75V24zAjD0vno4stwD5RJMKOiBMftokisWvLKHgNcBJkxZMmNt0X/D3WNLvNcJGb2URrmafND9aUPykIfIL+HMigosmoBSqrAxPqowPqomiCUz5qxYW/Rz+HjsZJaRyZfyELAozaOsMPqIyMkbSu/9JfYonZL2O4V8FiYMZVX1ntvRO3zRgxGXJTVjF8lEaLscAkiA/I8A/m+1kxL6xzOiwDeghG9KBDgnjN1EiCLvdUDzul6EH2jVe6OBQfGW0ho6zA3vrYLTP4lLgvg+6mmyZMKnLT+5/uSsjOMpYhzZCBM6YEoPLKjmLepmVJa1+v1DxxQ0FZ/BWOu/6C6+L4kARQ8jH+mXAYrKQRQKRN1uHolYJCIVmchFIUpRB0zZBCAnLOA4F0ikI5Cz6a7VeTHHSugd/rt60/7/avnp2nM92ICiuwJwadD+/AmBAAe43B9uRoeKfw87TQJWrb++cRqU2v1k9JwXvkxOL1TrK2qTZo8vEq0ePSQJOP395jTKNPkdKjmxU82otUGh7ocCeH+OdGKDaBD3iXrSEvlDP4g78KvYJ91Xkfc3zpGbZwEdcxINPj0iFc7mDhO9wWXPjbQw4Sm+yA35b8dg3EFE0lw/MtjDy1NcYujPK+ZED/MPnSPuIAngkY+b8qwDhGoY6Vu6aVMa6BY0KYS+9yxsITaIBr9eEKHlPhepSJdiJEQSmaVfgogljU0VeGogl7O7FvjgHieBpyZrIl7hRYoGUS+2+PeBCMe5AwzAhUxJNET1eKhqUpA2iEi/WokPiVyWKGmP9NkYSkjRRJIHGEKdpuO8AAB5v008RFsqkSmyRE+RABkREt9OUbEtyPt7j2rhhxjf1CcebalElkj4ZUSEs1lmCsxtSudFRqL/ZanaA3A7HkQBMsVmCgAfGT4v/hQW1FPxIgDb9/g2Vv3YlpYdo8ozefRrU/yAdHsi+3vFMab+n2FKooqUl7cMCqdUUWhCkUOITJHlJ7aIUHEBdUW38siuqk5k6TQR8XTLSOAlxbmeUhuIjDRFqPMoGarpH44HtaUSWSIhygRP/SeIcJxtYfwR24wpBVnIvRXQRQUiS84ZKzNDylwOfcsmfwVipMQymRgJrYnXmi3nBjbAqof2RkVNppR8gJRcp5lbzXzujTlsc92HgoaBT3Y36RiZdq+uJtXjNEzZtXyFHSeqLjbnlDXSRHbKRk0I85QzSgxx2w2qDmsB2xdX8hv3PFXF/ALqZQm5SwC3vs8j91Gs4PHdHumFJPjfl6BfFU2pTjReUe1Sx3Is2N+VcWR8K9KmpQf+vPh9Ec2XNCzXEjbvol/uhDMv0zJOEcy6GJZTVVPx/T4G+zfapJnGXgDMCYte8880V8t//KOaus4iU6YFwAR8oDCFDYmQk/IwSGRamcWJXfCfmJ9fHO48cHF2evv8dtcUGaz8Q/hFNOygtsNy9XFw8fVPf/mH5hiIrg2g/rhzIqd8270Ag12dKD4QyZfEdYtcX0qHgqggIx+M2LbjcvVQuLMavuMzh/rAHd17dzRs7Ix3E2mG/GEyvdlOmLTlZ35cjZ9L5+OcYIN6kndFxynOSGb06M6yHZY3qIsxhLWg1zdbLg9jpNZIV4qrStGAGAYocaU/PPW1br/NIC07Kb86l9hTB8+QkFzimYbvT5QXhHRaoN9tD7tdErSzaIdvO2qFgrmsh3R5kHh0RsQ0VKQlrAb7Tw0lwpef6PX4HOMttNAeTP2OPX9vO9mntcN96r/tvrK4+cPX59lMSyTrsOxz6UBAhHqQtOOdFA26sUIXONdihFimxsItfILENeRlNHbF2pKADZYyqCc/0zdpapZ3vrwIfsYZLGELQkENFkNOsNX4Chm+1qvmIueLpq7KPCUIZFzJi9mzgHti5BahuRDsaDvIbOry9JIUoGG51ay7PYPFT4ejtWZpc4MJHhBiybZ0C8Rt7fUFBgPOullmoDytwSj9SYxVWPdZHjVGUTsIyKrwlSO+lg7AqC0Jj2Tw9qxor6rJXGjJClnKqS0naaoRJhEJi5pVdwboc2m4hB0mE97ZcSZgYpR126mLo4gi2CBxWajRYAlYg0W4p2bZUXkDzGwEwUjdWdFiOebSJwiKCUakE915hN9cp2VQBXSw9QnadEi2w+61rOv4AoGJNkRtBNSqTJNsXwRasI28HDPJJch4LHNUl2PnGFDO3jCzEmVcao2oKCnGdJjeAnIEO+h0UtSwo0+79YpH1w+OHRUNfnk1PX4QNZaATYvwTvAtJABF4lnDBi58ZeUlGYRxyL5qSvM+2si7nUqgC754Cfvcz+WZSyVFD0RnOc/YzrrQOJjuRuBUG0qxpKEOxYq/sqwXCbJ+tA+J0cHewd66dly0d3WxnNOGKMdoc57GpXaLQl0OoX94E4VEa6fTNHY3vpMvYfXnEOPk+pRVzyckzNiQQ34CSBHFrt7U1BNSNa9clFek6824KpxI+1q3M+8xnO913aKQwYAZhwYe4x3Y+A+LuJVDmpC4nPUplSZgRgv+WWjYZf7DEhYcTGjYd5edDt5CSZ4MzNDUqynLIg3R6UAEyOPtjeNpo79tiDKZjqX9SJA0aStxfTUmIGNAQZjH08gQQBH+IS+kQWhNxrG8wDoZbtSOQAcEvnHqcYl4dD6xQhDOGDK8PaX5YasnWVOlWaZDQzQpXFLcBsCsXnWjPY1fXw57dRkuSg3KARWCmz0gkuWQzK2GeyjPDwfjIU5G+fgFoK1Ws5ep8KXJBLNq3UAKTtTt5USJR0yykwAleK6/62u9vmqWU4PJiHasM1LSJxKblCdq0jnzwAdlcMcmNYWLBDZaSI/EW20AWS3YY62mOmnEyFzMehJBGiunEOEuYvoOPAnIsAkyrKCDqCWeLdjyNYra81YiZhgB1/61BKeCbPSgNzKsRyYF0lqJKRVSwCuwCqzRzWPWmiYUj3JDYupjR+03dBtDMVAWGG//yq4PG1KdIs0Ow/wSuHBgGi7zofJufQOChx5FMLCUaSkobl9Of5yVxBg59rJodFCYwmuitLgrkT9tlN7BElobKmsEyAUOUqSdY03jdRjL0IDxmYPzKnhurzBGc6JIj4MkcxM0pAP1qjM8OeybRralyBJ0xudNCdSTt8gAI7GXE22Fnffbdo/MrKSgujJKiTeIsPTLrALRnTrFO8vJV7RXhkH5KTdlyACLjwE2jQmXYufCNJTgIKzIgRg6SRyHItYDrer7sR+qQTyK9msKDSl9GCwsZoqu9JsgrJmLvlsyTKvBzbW0xwvAHIO2b6wMJd0gnMY0xoIItdTMMcELEDDIGq8mZ8SI9YmvNMetNO9T+bJAjorolK4rFQQAZuaElpFcfPTK3NKIKAKAQJwdBbO2IOW8kJvMujVzCrCc2I1EzBMMeJowSyyNEM1AYrEr1X1AQOpqXrzuMZXzefayXCH9dlPcmjbTSLlDxjCHwSkrw7hVgUq4VMnB6LQUsTdkruo9mUEnWtcZjitU49quIO19SzOg1ktwVbUt+OzecHOeY7twSKTYPQlcPw4XypFYCwHBozJl0EveuirJ1pKRdL8Y/d/Y16EOd6MJlHtvxgyMXNhf37gIxPhcMgMdsmCQwCrGrGkNPC5sOkC3/HiDq4ysLZ4ysvZSg2zM7ejTzgrB9uB8orOdOF/0chyz6Gv5oIAynaPA6qrKgIS0E0h0yku3fcdOo6naT4HzKB5YBb6TbxD1VVSepOTaC2BeadJ/GWqN2Y4aGsyUKJEvhTDoNq5iok1bVcnQkeqf+41f4zUp6dKcP7bD5E5Y9HiRDmNLOYmcnQzMwH9MkN0LINlTJKxzZzOAjcHALfQaYAPgtfzvacHdYN2OlAVWXqly18ye6L/s/9/pAmJt8CohV0RukBV4NgVdh0XwoM3lrPsnBvhs/IcnmNvF/pGgFNeMB/MMxqTJZ70UtSrpn6+m5Br1susomYe366MdSGC14Ocb0HymecNOAvp+yLL92QUd9F1TuayBToqrAUMcaCICd+GhdeZppxLm2QQsIOy0sOalT9np1B0EhbnkhDO5B9j9vSg1mTU6wSGY213dEuY2xh/7WSIGHmKp1Sj2yC1OePBWEuuTgRl2qBIXAubLgZatHb3HoiHTnUiKZoH0CJoYsGQrt6jZcWPR66xHiYYl61Rrh/BZKZiW5eCwzhI6+He8GGVhK57dZn3eMxKcupNFjjSqZVa+/nMP/3wzNwwzBwPaSxgDcpy0fEozQxwqnFLl4vGYKftWpc8qkmULbKIznCerTFvhbdVeiFcdnU91mcpMsoceO3ZFK1Yarj5k0WlK6NxqSPP3HVlK6oHOHgu+TXjr+AqxSyd5xyREmic2Qw1f+1Ww1qlzwJjQUN1jJfBtCP9aOtnbb+RXj/ZP65OSMYtavJHPS9c+ZjBDNvmmuesvLMhpSOUu0oLoPHnhf+AdBxkyAF10BgklbIeou9/N8yC9cwhODzicbnJFor8GhygpGhcR3Ewn7I2kMdQHKZ0eqKvj8bT9tvvT7qRIu7jUfCDA9zDRl7oTDxqzMjpO/L1e2PKyKJ7tQDDC7t1l7HlZE7ylsmtgUUuu9xcG6B9p/TGkFK632DSr6z3gI6b0l/L2Ys5HKxOStImUrqL7XvDvgw5DbAcsqTBtMcItBlpSu5GprIjNkoz4dbEcn9uGs50HLs/P71zemcfm1J6KjNW8Dmp/HObCzPTX+q13vY3fT/fRTvKY0g2wZHLuJZzGY+zCrfU2EXcshJQ8kFJOztCGkDaZXIp4tCyrkwqVdz8VSWg1Mn/cO+2El/QaIY1Za5ZfYIJWGCuhnuOVfZTAjtgSBXNzCwuwlyuguQAxjo6HExvIKHNrTvSNk2jnV/fFIGDiDVvdAV1dxJoHYKUK/niCGzjwuU3iknze9M8DweLVqNiAYOamAwsGTJZvK3NsCdAUoKXAnAZWY3Ru6trrdIZEXkwbWHDgmNJCp2s5kLEqmNICHiB9ujPdC24T6GSLmJS1sNopcm1DlE565puoo84tCzkFfnkM80Tm0dzaVCbt8aSkZfJ6H2B1UiSdliyO45Oss7Tu17d06duL3hE+Sq5djYag/9eeKv3TRbgcqC/sRaSmbRo0TBFvVo/4Lte/e+qOjuYJo6hqQqxqYIRnZgoYDfyMAjq5wvmysG7jw00dp3xTH1cVU6+XN/pUIhj+mUlNw6d7+2UcVC+7trkcsWpHocHzgB3GNLaahOYCmHClzrd2WZAq6YY6nxhgBpAUBU8jtP5td42ztOc5vZU6vniBC75tyyMqaq/RTzXRm0kZ/hGTPadogT/fjuKbDzOUNcTLNscIhDj0WqgsgTIQz2s2j0/vnL4z6XWcrv1CPaMaNuKWB6KhWemP5Ae68Cb7cGIhDsc/k1Lk8/fPP/3wg6un4zqq0VoYHVuH//5zWEbZsW32wbmQ0HbFseJc9yDyim6T/VqfbXrbUra4jGhvYNwiwAgUL1AhMJ3BFaB28xt/rnuRw1/bX9+Ls3F4e0O3wX7wzuhrZbE5YJ/e1nGa8xeYCOIfX3wI3BEXFiz6983fjXxrlFw+beQP754+fn4uJTGPG/Eb8neroU9GLLfd08AkdJ1e1+cXdqhrzZ/bXSANpHp/TyAWfXeXRIrvGqq+kLUG+vo2155AdU7/GeGUqP22KgR1QhfLaY96yTkOPymlaSx2X4fA8SXbDJnvEpXzw/EGJl9O1bjgzdQtTU8jY7vWExE0xIsNWJ3PUpWcwqv2ajgB7exaDDjyC61tMN41x2DkN/Mjuf8V4FiZUk6xizEZp9pL2Kkar6MITId2eNxuyfEjlui7prL8r3YwEs8uuY3S/kSMU4oS2n1n0i7spqfbLOjQEVL1MVVjVNPP6Fd0CgjUEnVgRo0KUrmPwuAwdxB6gW8n8Kg4IgiVesYx7soiS2JOcSRIm8FH3oakNjcWSDFIEPbIPmo9gukg57HG3m0sGcRA4FwzDiWnwvajMojI60nO14cIVNb0SCydS7o9Q5a4rYtrLJ7ckm0dpkFD+6gHRDHc2x3YUt0zxRYmROqb6zkncJ7g22bKsLvhEUn2/z48Oe3ItXEkcc27tyybOr9aw492TjEKPplLCMDUDF7OY0HTWzPSFmcC3w6qXpNnepwR7DIlJjmH+05xV0bsYd4viWlLqobSq8TMFESQxDnSXeChfSgkOo6B3LyvWdMRv35qKn+DWK4I6RIfsdgvB7NRMT9GM2FmipIGJTk6XQAJr+PbsL4InAlSpBxbDlKmAbd9uHRa6eF3ynmZC5Ytgs8DFWqgZVMVwUQpsXg+by9Pd5fTYR7bd7t3JzX0vl2VN0Vgf+0ua8J3Rlh4YO2X170twxd1+DhVZY2d4zCOXRcNX4jOSNSm1uLJfysnWfL3t70GEKkTOglGuDYv15LSbAPRBEgS1Io1iyGvGhA5IHMN2qxfFH1XMcqjjjy55xrrShQEhaf+RMvReTXANGdK3KWSZOSdSmMo/CtOGe+tt1nfKMbwuNORewe0DhEj62D8pPwPvWY6dKWSUjnrS3rx1VTFPJSZA2EFgZhCqj6haooAKIx3jcij0lpCTGWA8HAQel1XKg6rGlf5MWd3uSoUp+G5P7MPB6UR9/ZvSrn3MgtKCTu5ZwxJwDLsHRiqYoAuzaUTejTKi0c5uzNTaHEu4e0/5ZnzOQ5jc1onwzdwZvAxRXFN7U5kjqRSvid73FKT0qt0rZy+CNh6PREvr4LH7rGWngaLrQ1IxT6cFBRwEE4a3PeZaBey//nS1NQM7LhVRa73/ENrvQe81woUV70SQ51xjPtK5GkSM4KEgfCpatDvKXSpynx1x5hSy447YmbNysc1N2ubY+vzeEfBFJ1D03jxmbozi+my8nn5TWheYbs9mfzaH+fjup8e50epBP2xLTKKYcVrfW1tlrHMnSp18vSRpvCz1Oij8Zq65tbX+RNU54mKny0OJbid+0v9oTb1rmym+LYi+PwtUQxDUqSmVkwHmvq18ifSjGt+97/HO1/8+P70LmyPCjmfRPv42ofkmneTyrqr/Niq7omcu0mPnFU9olkuPVZ7aDTVTfbVL1zkYV3mEBqm8HJm004x2O5pKliAX1zkqEfFdQwXyVRTLXlAfANLDrvyNzLpKe1q80o2tKtRnmeBqAJTR6SbCJKSZMliUyp0LRgGYdvlPAPRnpc8I04kj3dS0jKo00EaEw5nHx/vc5aDP79UefhpaJRAHFWmoxZbj8KXpGmbC4TXlHcLQyPv0el7nyfEJQl393TeXeKFp0rXCbWuy0cpGZaVbV7dZDdXAOlti17N7h8a4wkF6XtYxTZTEZVYAAdW7gyXBPxrbkA9jn0BU2yNdMidK1JnPH8Ec5PJpS7zScRTc9sZDt9pRITU315zNY0QdTgNjSwtdDr/DAeTYxclr1pPnPez5DakG3DeOk5fiysMeoOMXBElNfKXdnOd2qBZjzDFtiUJ02FOTpyETT61a6nCXko0f2UlWI2zPDM1Vz1Ng9brS8XsgKvhWwIOSFZe6sg2ufiKt/fN82YfWluwV1ayl4G2VRmR7+902K833nYah4TGcJE05GgKkvimmG8KadgkjlO4cdWz4RtxAsotbPvry04uIROYuk9hb5y66P7mNvVIUh/m9DqLCQKPzb1UCJACKDF50li/M5iTIKCnjMOtqrnizH7IhVidsHJEEXjKGLNcfCQIbeY5ghMy/0CgKEyecO+Ci7Zr8WSIucn1B/8/m8ZK8D7uYcUnuqDCuMps+m1HPZ1OA+wjY2AqPIfUnyFYEKRAUUVf3aVWEYErrXb74wAFYPMELeR1CaGinhrMQhY9FbNXr/gIho43dUVw8SJEeDgQP6FxjIIquTDughJidYZQ2AaNkVHoZU12+IiuLpozO5copRmFcNGjoQ/AW1X74HWF4W5pWKXkERAneFnEzWWtHEOjDvQLiyLNbu8xEyPWzMsKfT1WlnB5ITdPLVR9kFk6pRbLcjgrp9C8FY8/LhWU84kNQWIQSJ7os5NkSqdn4dZOaIx0KkNnq2ieLWfhZz8iSocJmmBt/8fRpqbVUl0k3hdv10trpU5EaWoaTMcy7qA0YflhiBYk09TlMKVuzmnGH0JucVsbUawRE16o+hOTCa7xv84ZNEDHkDXn3GMTpr6yMY1FWIocOwsf4e52BqPArh2SDd2YkflDi2ByhMbIet3CTDDwuURhpQqj0lmeHXIhYCN4zgj0rFAW0x8GytDpwzeRBKe2n8vzxm4rKtLL92IablaVjINjjk3rKLBNRbEX9qh8l3K4XsXToyx4RuIxmnQ0Zc29ImgiCBduIoIpQazH0gpjsaAdIjg3dlIXbpgCedEgZ7sS9k/Pr4iMNy/Xy2nqOPmtfosM8g7COEYabBONJgO+4CS4yRLSqoSAp9Quqm7fLfWMGZxFYM5aAsrkHRS3MEBe+6fNlEujmwBj0l3ahDSQrjWkuTn2YTw9nMaWkc/qfe9ztVLiNsAiEodoUsnrS/68IAV8mr+4vCrNK5zWMlNVbtOKLSuMQT/xnppVPTOOBbadCBxvNFDkcTHPtQo5Wx8+VpYc29ytFtZ6u8w1/TacPwgGQtRz7lXxVTdT3QXfFZl6EdWjPun3WjJtNOGkFlPnNZg2QT1KNBpFdVAMqijE0Hv3Gd+O8OKSMBTms+p27xguKss+BDwD4+r2Gl/buKjD01QL/5/Je9YTx64TRe5POBjlS3lPohLPdLe8BhCpFToOkMHE9FmGR03FHKXekG5ZKWCyUbUl4iR9uGTTZ+l+7k/qtNiMp7ipb1cfoxyTGPDo/0MXDQZDTEqxl5oAeYYDZwodSXpjus7ywHCco0qzgeyaShSpytRK8AwaNlZMNbc+3BcBzuf64KR0qxOEe5oI5duLw0i9yRX3ZydZyzRZJnnsj5VIurQrXaPuurZkKh7qiK+/6TkqxhPhrKhZWZWFDX5Wwy/LdCpvAYOqJVjQ12CslTNseu3xxEnXAqiIGbQ3XNDwkV16H1WypqvmMHwjbgjLn47zzGzYe/DH56lRU7DDaasm2z1axyPWRzuZHbtIc9nM4TWKWd6GXcjpl4JpKP639/8MvQ7TgIhPT6VikAzoaUVJfd/WbJza9jGZ+LIv817+RrUAl0NbPU0Ru3NLGuj+NeafMzKo/UQYT9RU5w/o4h5AMAcAqe7T8hvB3MdPopOR8titq7HZiMJTmOluKmG7PbTp6hUHaOGUSIJdbesyAV1OgjsByMmj4M4pEhYFvCSiY/jxKQlbMXMNXzlGydxYafeIXXn92W+UbFNgc5dAmgiRhqoIln4BBFEIPuw3Z7b0886el6v5YVg3YrEKZ2cgGey1RLVTkrtBXdqkkLbMeSJRu0dvXykvkVoeXGSxnreYuGl8qhT5dlquW5afMHdETd2tNNbsuIen/zGGIkhHN6E5PCu45Z+eaE1ia1YEmoMDe/0JuFI6EUTPJHVI5gTdXVT4U5coJCr1ZGo7CYVEC2AyZrAWC05P2e1UacTe3G5dGH88j+/36ioimY7BbLGBmxtBmZtWPEEEzGKhm2mB8e5TE4y0lQCH1fD1RR2H47ROOx7XAcT+WMKH/aZGZjSd0Gpf7MCeYQBjF2v71W2F8wn3FmPD2fFlHC4PHOP+bjiNp2md3Y7SWUok04MDYzBl3Jk9ttQBEw8hewBX9zPR6wd8w7pfReHMLSJmQ5uR4aFFCusQPRBXNL0py75oroq0zoPMZgesVes0+7gJ914EjD0NQz2z/ORwq748NNeu5PUzF//RGO+H3kBICFh7aKZxhsH2ypfXkLGb3LmLSJz/kUddflItpg6eNEAe2uO9EFw4jMrDpATriJtTx5NOa+b6tzoR7I/RBS2D7Ufd5wKCbvBeiySvA63nwqa3m3O4cEHtad+5xdtTNH1tuGttMx1QLuCzDxIWvpDrzxlZbqI/Re3ZEAUPfhrAXPgI7gQwyrPupk8dmdXZ6QsDvWybZyQkWvhSbwaDkegLaDeUMXvXNRn6BKg7t9NmvfsczgRIkVMfRKVjt3sf9dQPxLO+ZlE/ek8cbCDzaGd3s+JhoBR5Oy0um5DgHDrF6dttPsgvTbnBoAewvkO+Ew5qm4CgY/M0WaJ2NtLFHoc7N+aM5fGcyJ9LJyIvtPSOQXDkhYZN5UIKHOvCqLy+J2niv096ABdwcG2K6C0syjvUUR21TV+TziTNMYHralvBuq8318RagrWAqQdIEDm7kgb/Dx3d3nRtOVTDpCRylXTboTQd4NZT/QrCtCeHK7x+e+bU5qljvMzPBHn/zUrekltsNTgZSXqedDLaqB2DJgS+9erhFbyy+eS2Lg+iu/On2Gd/iXO1BBVkDIebjGUp62jYcoLTJmuSJE37NZMsT2f3ndg/ZneQNMlUO60h5BdUrJIhYAtCfdBiTLDVkeo+WgENlGnlGHRPPzh81QyyJpsakZaJF6PTwa/BVm1B5CThKR5/tZiT3kus8xMt3rUZBcvyRf1XhVD94sP4fH+9nk/HsW9LaAXmQAjLqpWXlPSHQTV3Maqb2iZETrZi1SpC6JqfoMd4XD3iyuXD+vq4/om/aWAXfoEVMMCp2vw30pXHMSNFCliTk1cs5m7cAr680T9zVNM3SWnly+PsWK8KsaI3UgahKg13ww6u/SoFyndROSOl2arz0DaeVBnH7d50qK9Fsa7vM34T0tzVh3E5H8e+Y4KLfUBvOzjyzXVyJ4O3b2SV9HmNrOci5kPCZ8CLpQNulcTjvkqnmdm4xPdX9sN/qsbFcKLpeC2cwLq4xrsM6hm6onZl7fq6KQo7XuvZCGVJOEVTCp1f1eWpAq/cpF4nrHVBNZeXKXB9zQuDGf9X3XHpmWNE9iZxWEms9WxJETRFRJqcaWQ8a7cxrS9Jqw2alIeqaYJYc50xxj77EE6xy9gGY4jlexiEMtrK5adJDELf3K1XKjEZJp3Xr6+M3/A7TvIAfiq01ViNvUuTEETpnTYOdw8HGastX9AxCDzb2q51bwbQoAJ02n+x68z/o4S6AU2pqBNabCy4X/5ZjRLOkxWG4KuV2kkUk4E0TsKl61FfFYMPCu2UXHAXT3foSIdva2NSgvGjcnpcDmR4SQ8YYPnbHIZy+1PEr1L+J9x7PfQXcF4oduWN0PnNZjXQDvwy9AiU1lPBV9ce59Tefy1cfRR2d/IsgQcCyL6jBR8cTcJKPLLs6B0YqnIAwK0rCEyxhLmtzRs7nZ7IGmLXwjN/PrBQAW+C8+R99BK0CR7zDvDo4NCB7s1xmhZ0auNApNCx/3ZCBqzyvcL9niagUOtleFdXl4cHvCT48Tx77CXmpQzqc2/qpVbJvh4XhnrKR4HRqkRFniVxkeijxjWm8mRBtbLg27DRazCDnfKGqoHL9PaLg0xBq1dc9sJVu4/ncJvpPS442OZIeURE0y7MC07D3AAzWsXCA8l1ikVgyV6/hDXrlYy722no2ubKriiHwNbCuhVd0zaB51K6nHZ2xdW8E1J/XPBkRDBqjzEnM0r3sSU8foRReUh3pcShnozS+jh58yLOY9/8su9/27etZFpiMdEgJkFkhWgrKkFtL4OrGgpHJr1SzRA0hqudaOLtZituspc9vuRi+o6zcEpD/aNOWPXuvGr3J8e8Vg0jyBOp/n4j33UEhXeOiwyab5V8KSGBXzI9hZiAnusWbZetFfvVou1BN6lzFpJtTbEdqAvpB4FVPIoDMNfZltmAoO4ZOHWXOmHh+a5gare77ZwlapfcGM0tlSdhu27qODjEo75ta4lJnPa6aUfBYNHlygzLXc/WBc7BA7arKnQMfDQrj1KJThmYgnWR3ydvPUNwZID9imlWMf+M2R0eyMB0o0IMK+bw24O+CNBm54rPaB+Rh4oPSuBGLOkUp+GypkmHWYlhVR2ez/Cc//jiW+XgySgRpNeVIsQM5k2giq1PkBSKqhXn+NUR239EpXd3HYxh7NWfZmvED2aOIrfwRbwIFpDM0/Zs2r0wQTqutGmXP526sCaWASs2L+8+f2A9veFCVGPtRFwf6nT00uimXx72tlcBrwNoKke0mxtuRpEYmmoOcY6lck/rBc82brZ+wDygMeAR8myAI7IcIVNxWBlvePbB4DT0XWNAlt2sMfCMaT/i7CyjdGV7KSBWLqLDlFMVBJiLlGHHr3yndMK96PEUuHqmO01katP7MAdcwygphr3g6Uf3aYjNr9N9yyxIN8n4aPBy4wEc5JLvYjHtDlbGuGFuEns6klOrlK2Sn5OWrIqP8vqtb8siPiT73AEYpf0zKbIo6qrniByKrK0RwS7All/BzTC4RmRiseZa20LuDL/4F5MZy2az4DaSX5yQqNdMK/L7Ar5HzbQVnbc74EREN8GHM+QpbkjT3oL8m8XsoboOhnBdNcezsukuZwRV4uWTD4uqqIRyVs5tVAmMtwCEwcBuCMdoveErNLnr0jkdjM5K8MGRYaEFdKVNl/GXJpOAeTJ41dHrijmbxpuF4INDyHDzcdWFRHhH/Oyoh56M+bpg7rWxVhZ03Ty/UX726p3zGQfWdNP08X5ff/3Pzp13yZxWHh2Zci2eOTeo+p4wvQQizm83OLM+/D/gcAL3G5dinw2nqXIXqcRGro+LHHqfd9pGdkjh6oMyE44jDdeUhKjY4iUTqVnmhN1/0k+xdJEb04wo2ZRZQmY6ZkjzWrNBsBI9V6Iy5SIViFPEvPkufuAEXhC4hS8QJdNZDpDf9fA5Rihzs9p+K1jb7SIIZXf27yNKHHjmDqfdDtsK19z9HeABDsR97hVQz9AltYsq2+x+iGBkPj9KnczDKPrCX0VGPdhXfO/QJVW+W9kjNKqqiG7wpN6hK2oXVswx9b7N1zU1esMitG2aLD2+c7lGjGEPlhdBW4DyEeOcFzwR5qmu1/YMT4cxW/f7Htpd7h5iBys1xFJHPruYc8wUc1pwB9oB4RD0t7ffCNUYaRy/EypKzMXXp8K64t1D7Fp8xzYP9ymQBofQ5g6XZjBjbwg1ZpGqqXnlH+ppaDnPA/WJ5sYYwj3jP7HqYJznPzsabtq2hNkFprmOBG1rIKvWMswsQnHZcx1TVZc0LPQmvUGxLgUK9GqLCi2dOHS/bfkAQ7uVY27vcipZYfnPnBgwBP9vnZhHRH/x1J4jiOQs+2SnNeabufxIJYHfMJlWeIN9QjNGwkQJtZqB7x2LakniKcgMPgtCEdsLiXrBn0Y1/VLT2+5jOmbB6nuiAbUUET9i+Ug4HgZNLcGBoNB+4nAr1/AxPtY1+3b/64pEdtqEWpU6K7r1Kh5qQgAXBB+Yy2v8/NdF6mtMRl73Wo8r3zHXwZIzYlbTS4XAVWfCeT/5B7fEIG+n6pnI/dTGRstW8rjUUMJa3oZtAp+y7cy4e3sWfDNhZaLWXH3PTWkyt0ZrYDswrbHq5lHYOoqIL2iNyecXKxMyOkgZzlVdmWe1hnlUOo0l9bPzHLH5qxlhi1si/Gk/JzJVz4frQ+FuD1qrgO9xLUena4vRHh8Px/NwAGAyDk6jMYDin7h8ZDOf576BWb/GYwM/Qs6f5DmvcX6YN6DDdX3erkwlYSp89oSBuXUUyxgG5+SmXQ7kCaA2cXd0OAG0X8caet2yjfkkxSiR8yZukoOBG0wTbrSCf2RG6EDeEcpoIBjCceSUxySY2HbFzGbU6w0Mnju8BRqhF3aetHE7eybZSFJTY2YndErXJTO5NLIHddOjiHFUl5GP0iuyQ9AjAudOPc7FsXlmyKm0MTkcf2e1n+WpP6lpJyefFD2NvTCjr4iCH3d1WKACF1DvUE1NNdmaLIEFOCBDXKsXKQEyxS46Y44ipFgxg8CPQQs2fMhTBjuJcm4R7go5tTJEWCYi4JrriwejJkbvkwRsLxBtNpo/vDVbp794+bDzoC3SZGSbD2YGneEiWFlcs5Ua8rIdqny9xvpjOliskjAO1krK6yDn+eE3Asx6dnK/8uO1XyBgDQ4YFVZ7fARVz6DNZpXxmtXeBySqopUVES8ysoYYPjwevFmtwB2rSAb67Zc/ljzqiD97/e7N89PdeV2Eil4Y/nn8mvTDpV9ywpjj/fKsYGE7+sN7+1f/8tUHjm6WADNIUlEB/O1OcMwLyXi0O5Y2j3e5fLp764Nd7OB/juRW3FPcRGVgKh8BoXHPe2EIhqHBr2PAm9D+fnATPEi8MfDWO739MilRpPz47ctvvv7qk4/eu315vr8c9kNfl/EXyRuaRuvAfeOe9ib2UDRtIeNirl9css2SAm+4raxUT56x58iyPdWbpj1355PO5P56aNFuGhPe7pTCcjpE54HDbOeq87Z+//OTXPt1XkZIGuyNWxPe7VallS1TFXT8egW32h+GHRxVf7ww8XzqD+owLxOwidEDrS1KLkaiZRBvszhYk0YRAK9IGND9zKS04u3KSmcJvf5HSyTAzkAFsv0dPW2nOu20czbYaWUHeEa2/BlPMd6X2eK7CfpPooC/ZlUBxprYCPOPA7iqUyYO8S4uJEhXyoy0Qee8s+VGLHaIvMDyajf+e7XpActdzQyHJ64+SSPAZtBNXFRuOKoac7J8sQu2gw+c7xRgGAnT3e2N8sSmlH7G3kqx3p22+C0Ya8B9GqFj+GNcTFAzHs5Wx7ohyDQt4ql7csEC3CNdoreC91bwQqC2ZwCFuYbooVHPAy+5YLFRQ08M5+38Icff+fNuK/kaejQyLPdTRToBoFek5MRscn4G7tWtsafYiIA1PUOk7yUtB6bj0fbolR/3y9A3VfJO+g6jKMZxmSdjOlYoFjpEJ1EQpMxaNoCVsOlzNNUHmaHbxioD645+1W78ttlEDzg6pW+/b3g5lyKr81pJJhf9miy6z8Uns3usCgMMtm25U/mCUQdhB23fi3PI41PtPUASNVPsZH516KIwhW+IocVDMQHWCWtMVKZSZbnSvlxxFN8Z35uULlcoxThK4kJ4Oth5wKz+JObKjWzHlg0J4MO19tdOLmdoaiW7KbD3C35ZbgsGIgT7WM+KWANKGfYjEreiem04NSckfFvew07t8bPaufyw4NbhSzo2whaZsEPhw9HDSPDx5IAwVIap8LsiRe+EmL50W9sqPjInTg4IIdz90U0ZAilWN56VJv1Z8DSwMoVtcRy7XQOS1v8TIDOhEayjkDWVGWPFd4RIaISIYdOB+BgFPfjYI8P8pG9rEMEN1t2MuS6QAqAQ3fyI6OrL/jc77z/KpLkrdIsYzdEdo06CP7byy3dpoCPDUnPmY7WM12icm86veORMNtHoMTUsyoiDqw7ZVGv3ot6grwWMmdZfMo0Jitpy0lspg9pvqaufVhau0SIjXNhAnh62z0vrEFGtm/FQuMKy+baTLxMjQdKiQaNxR25UR4NrNNWSGmVpKS7pSNwykCUNTBzVOFXMlZpwEAxF8uhx7ZkyCM/kP42YKNW7iHIU0LQyTfBxtnRtrno1kkbn++Q+JKMGLMNJBvuS3xsmdbmRy2U5VVOs6lLLam/A9r66eMZgU35mU/pjakoTx5OCFHBrR1s8fRi4HWZmwLQ0SV0Aedv1Vuj5QtDSp3svtRiaYUM69oVvli7sEd4l5pv0PrunlRfqOA0mgo9aw4qKxckKqMZ6YmTezoFMR7nwPYae84qeYdfHLtqjuSrZzBFv71GHSWqYa8rDUU01ZnZgscJ3hOlW/xbyyEA1N7Kkm5NrWR0jEfH5LPVr6f3xeSN/9/O3X3/64ZuvPv/sQ211fNS6H1TXOPWRx6hQyIR6F+Fj9ozd3IqoeFeLsFhcIPRZBfsckmtQ7N2cMd0bXS1oVpzPO2nfLcho3wAZ2bLDXefYc/wK3Z5gGKVBU151GkIf4YQmbVOS26gKBEOuwLQsQ+mdNNDswAFVtzU+YI5HqyqhT/XYLHuPpKiqpKZp6/yHXWh7wqmLHXZfOhwvuGQ+WTCHKSrt39DjejbJa8+Vi0ecFt3xMxfW9JcPZQ1UTGIszTfqzlr33LTFaWr6m33L8mYU8rYcY1RYGIKpQCQEtmZzVtl+GhA84rDAKGzcBZ/LVX4/QzIjbnLe3An/5KOOPJX1YmYUDNBrhNwMj/n9UP5qcXjmmsUFgnYN4I/jFG0drNGjx2kiZN0hr0WbEvd+Q4LG+8YYJvkWK4b+aXmJCBSA1E+qkNyTcH7Lp42tFa6x+PZjaNnV7VmSe2pELi+Vex3ia2NBRpiiy6toTMp8AuNbMJer5DGQuHw/I2uhfXEkRzo2k1rhDTmn5ZEunPLnsj3LszRYo5z7sdF0F35ipD2Dmio4Zki2qmM6sIKZW6V/bHmgprjOwXJ9igMjBLbWP1a0lHIVYN8ZN7m7ZFhpS3v8YDrH0b95xjacCfShfhfIxmRKa9B62GW14fALA/t56K2CH7LINhvbU4elDIsQ4nlZMGb+T4MKRP+sWKKSPNOB1tLvuCUCEJ+LE+Ya7OLq8APO8aMkJt3/YSywadEtxhBkjXgaodkJHd6tXZHep9jUGwvCR3EqG1LET6GdGVBQ9FNM2ZpgvXkpOVoAaXMrQN+bNI9eB8QtvE29nEm7OafxUV2fsFqwFreziRkjwUk4JRYDjFv/Rx52Gq+ODNNTzWbpmI0nHcp+kVcbKYKMSrwlOQVUq0gpW3MiBqHAelUGzzwDeRqiHiyY1SlGtsl+D8p7zw90x65Ho+TkiCIXkC2ln5q6C6DgQ0ygbi/VCYduLcN46LoUOEEBUU5dUA+Yjf7ilFjmgsWRFvvkrYmpWGU/5rCprBjGAu2wAdHybo8yQYZXVc26Sbtg7nWL6aK+MpQJthXM/g+p842gutxs9/BJZyWHtwxRDq5cf3mcZ8B7cLHAJskzsXzWUMDMgqVugsiJuF4b+bXj5Xn/rKSYyznhUVszKYX6rDo6IXZcq4dUop2TokDxTsajU9d6Ng/ACRk60QjQ2RJKpOVgF3p4HIciTzSfm8K5x/sspe8HH7T6jFjfI4wwU9Wgi9esV51mxakFqyGKoqbEpkhvFOxhcCQ7DULLA1YkZTtTDRT4bnzL0Ttbsjz/Mi+BZe5frmJOcHFjYPjTxIhx2TaJ0e2lFCtDcxAdISj79RANTYm5UjjxbUr3yjQbvXvelEiIGwdto1JRekH5qDKY0OcL0HbDg+oH1AalYOkAYRcpj6KmeAwlZcGIG/6iwXpyHLicTRekJrOY99JrmYPwowSsREP08yplzZ7j2m6lbac1a4fhLbH6Q4Sh17bNEjn+QG78oYAzzk7v1j3NdPytDfpt9771JXf8eT5DQoI/c+vZAci5dINSWBEkRSZFAixfg7Tn1JzXh0OSxmU5otx+m1fhLYU1V0l9oVRyf4RKDuqA7REu5lbvwHT/AL5SA1OygQuP6v2GEFCMLImrJGfrrAcO9letqPN2TZ5y5nIKdFetkUCcDM3gWjwWZX25eIogNN6gPsvUpr0WxOtW9gtHTrF1FWf0QUwaLvq2phQr1GykckUanZwPK6aqwzEmkgAfksw3kmeAfXpfN+V3FykjjIhT8YNoXQCI2dHpDFkV8V4ZAxLHEyKSmKcTxi1aQUWqpoxzeZwSMLjq1m4UsVuij5Td4m7grSuqIcwre+wkcVSEluhPRKZ6sD+Vfv8qk1MS18m6I43RO2GpmmkVNt33cCdWkkpiYdFy/q13/E/0gTys5vt9DGtrbZfPuLMdVVYprU16wScYHB0e7o53j0vDrq1lI42aelpcK62tCQLs08B9ZGp5dTZj1uJsYl9fKBktn+UhD1rTEGp5tJzAAg3faluL2BBk+ojdAZd0GIVyeDX/9uBt5+hsW/4B+Ww4eTLfRpoPhEIZIkv5Qlodkk/OQN01rSuDne1K0trUxrQlw5kOWF6LT7vpY2+zpnIfNNlJ1KBP1JCt2IAm5kuv+Vqs4xbABuIinvgRhj6gtULWW42ZG0R+PFCKvEHknKrwRudEhNYYpYw95v1O0MxzfVaLsW5NqUBtTzrbUZXdfb7BV9BZHSFGKMh0lg8CpvWzKxMbxND1qeYM+F7FADFrQe0Vs7tbd7Q1W0aCbn3K1HpWLK+Mf4mQxHTottufUNWT5QeCwiNGcgCHQFSxBETdcEIeoccslhjnZFDtXmYLPrXEndRq5H7NQ2SiFH0ZAUsW2xk5ms87dTXdfL3DB1ju5F3w7DBlXXsQkt8AWr9tok8UMDwAHZby5DuQwqWGDMuYJ5it84UwFus7HpGBMogueHh9oi8MTlpiSMn0Bzg8dcor8PokJTcYVryMSyMn7+Oh7WeRFw2zHJuRv/n3+VBX86HP7qc0Rz1bH6lJqQHin+LxKrn987kTXIbpm6s+PKt6xD2zhxAckA8FduFMP2DkoBwhM92z7nm1zmfXcHE5u7PB4cF82V+MhqZcDdAPs7gDOMw/g54qhBe+bAUzjpuSHJnoBen0gFkvB2YQs5YozbnTBHbNc2YwqFiMc/gaCM8N7kEvzmY+YbHtJI9wHrRD09wTKrExr0xka0Bb/xeldthzpth4K+mfq4jbqBpZHs+tHxdpajCri5JImq82KowP0Fc5HX9kSAoeEDPpnWVt+mVnXHdicpUGSS57m1NXUKJ6+1NSGhTB09Lg6ZwyjGwXcS0Bt4ZYP42m3Dknp0ruPnBghRi8pzM3a0I3UGQ44+owzQbPo6jELcxi/gUJnQBYIGmxW1XYX7UWLEQ4lkpQz5rlJWZvti8dbHleSCMadRhjfDG33t1zVeGGGBcPRd/g9JOA4zwJ1euDNj9FcTEVj46eHoDyS8iU1YrofpZbJG/40/0ZteCo/2SHPOiE7lwtdc4VLsWheWyUdW8xrm8PNUExeTwB7lgRBcoYh7oKQXK5ETbZlgp38afZOZNldlDTJX9Mg5nZfoUdpaYZj6dAmFTGo5iwMGprDhc1hKicXbJUg09YiOzwtTP73tkaXMfXGPDOF6iY++H52Iw7AAWE4M1nGdsSthsKGKU42ggezyjzhV4nhwWLcuoZ76L/yYOeZ7r1fRW2DHa0twbm0KIMaXSS3NOq7ZGrD0mX++JQFG+/nD46PxvWxVEcW5G9fDuJ8Qr/IyVWLtakSEgBmRTwCWTMUr30A0nqS/0YIxSGOQnzj7adMDrz+935slzEJDqA1bUrRrCHZ9r6f+sB1/OBeUIdldRrXfIttxSJf8vCXvhXwpCkvCmvOhQTIlaR0EaFT2yZMIVUaKozfQAqu0vcheKVBI561f71/+cjKnZkHNASb/no//8L2uk/P372nmnaIeM78hODcNC3RHD9wgGkYECwsWzgv892NG4Hfnts0qi5p0g10oAqS7ldfkh9Gcf6nOsqpmtV84KS/EBBX09Dw5JFg/098/vmN3TzDm1pqq2yW0nCAEjEvEI2i06TTYmhcIC8NSvrQl47jpk0wCmI+U9bSLvXwcd/tXr0Hy+2BqtqI4vLvIPLkVNsBUGCXxlkdKaBH9pm1M5VzasxbRAoG07hWh3Ag1kfuJ4sq8O1Mq320oiEFi+cPTijt621ubG6giRgCNAXYm1tm0o8Btn4qIKWIBcjizeeB3Z0s9RBVw5lx+gnEG1+bFpLnihmXHhxfx8IXztNw9DtJah87YuaPfz2zHg77igzefOenfMzQZuTnm7GLMYbEXoM/VEmrZn8DZ+3MvqeCYwT47iagqFhqjrSQmlZhpoPRYiQAdpeoKbtvXv2PBlRpv0BXhIZ9nO0bgiSWIsIR5ctNEUSH7Mi7QJZUpKn9dOoM8HxEfDHldhhsnYZYB2dE5eAxFgeB9JHXeRUuh0pgg062DtYSNb37qnvPRO5WWvxo29zF49z045SM/TNUDePUGRYHkHnHOM8rTsttx/S+IyFfQapmCeEFHzy5kzko9QPBibSu03XmjW2MW+XuTNktYlD8zijSRi0iJvOEIfycEXLIC1N7C9kfgPZuc/rwMyAZ3YkObShP4acgUiaBf12hHQdJs/n7mPdjNlo/igb8vJOQorvPoaPEQygxiPDkWTHu7yRzyDiEe4k/fwBcZlY8j1J4T1/Hyt7JS8NK4otj/UHBLM7lzJ87j/mTcUNFwsxliOnLLcYDHTS6DlN9geyYZszGLTeuRLf8/qx+7vs7sfhiIuWsoZUThkE+FwK+NkWU/HEdDdzohm4iiC8AOjbspemzg8CYaXtr8C+kLj5J1w4qd35k6KS1wswxC/Bn/5Oviwqf7UQj325X/xXtTFeCOYxG5dS0qf3cs9cWyzSQHxBIIgvxGfVSt+Om7w9kNSHK0Ra0C7dYkzvKnX+zLlPYgpRxZaIym42IedDkZzqLfOxFe9Ua4nnPaN+YBJ8kW6qvUxKp8NVcI7jDnUSDy7UJiwKQWRe1BNQ4eLrgY9EpJiku1TbyVPWzlzQwfooTpql+37taoi0aYRkYtt4j2y8nvVMmi07akRwpnag7oGS3Xige6Rb2vm5unfZcBCqguCkdnPbZcECl/FKGSrKy4+JuaFZ1MaIodR/cNB88DHwA8ACdv+01zckF/QMEzWM70Mngvxgq00gt/khK/tKI+L70D0gx+5Vn2QqQY0NwFJue6wO0lfJDn3YTShDav2bOWhf8iC4CpjWgL7gpwllGRYvb0wV4WYNr2aSjy5WTR0wcemOhLuNxE2WMZvRWYKq9a1ZXWZZq4NPghpkFptibx5CuVSQtv9DzEbt0uuLmNVxSb+Gl1ldOnkq402VEFy/9V9/42Z0H+fwPYEjL2G3kjmmwmDkodw67BJ+JPg/ov7ysdJO2MN6AAEB569+hROvBPw/FPxFwOfvwzbKOUhn/bLLq2Z9ABoYMLb/Z+H2do8UtO1Xh0wj8ukoYitiSuAL7YF3KG9mVFLLWk9++yJrE5znWdbB6rWR7CzjGkEp5TnYyvMRI2ZcfqvQ8r7oJMmWGH+PS1579KY3elmZ6YrDyqQ85p98e4uae4qqOmiFHemSvPqrizLEB+3/L5mKKmQf03Om5rWmsSiT7Ba+RS9zqjbxPAudXYzGknKKuWa3Nz90rAitkT0FZR91i3MuGDZIgQByYek+Va/VHhb2suTyjmWppFOU6ro5+2S/jlviKlvsPhchb0MuQp40hZD0nkJIqomfpmLyHo4XaduU/T1DHj22s27S83TiJl9r/B7lOkX0NrMsf7o1h0F1FanTUpHAlCFY6ioEpjWB1iyPwUhZTcdHeEl+NsVMJ6WbIWaEpt0zMCcYTi9JtjAxvpIvlWFhcZiSSwxLHy/2qDu+bvQv9n5JGarrN8KSu0DrNYsnkuUgpMgpSPY/9ju3IzBZjlYkbuqeguVx5Vhub6uh/z1NopKUL3wGKhilPuY/EkhPEzU1KwevwBKRkHErFQcW1iZWyqcyRO1isNJiuLyt2fQk7rKLPPYk79YvI3f/rFwRa5864J9d5BJDaG0nWQpi2/IXd2KtVaPWvNTErDSSTt/HZ+XJWhJ70qTjx55vJsUi4xKTbMIkUyeh+MUpweC4gCcxHwuxAuvxMKbiYv3JrYN1RIe78BIu416pJIjBhpOUgXfVEZscc0mRJ4u8o87ZgnfbvKhka41UXhW35jLmWMA3eOBxMUkDycdPNlGKsXLehKwQ35dgx+OVgsumjr+SBIdlfnOIvehsNj51+Or/MvM6b13TX8U7MjMpWrUa8cmNmaKwsJqdLCWOZKxCJRowX9ux1wDgDjeN8U5Hb6rWxF54/Mpjn9MXD5G0jNyE4mSa2xrF0dL4xeNmKgI2lL+QTpEuuVSNJaIE7f8fqPHZ/7+y3uBW8P9VvIv35KcpFuNt/Itfv+5V1JIg65iZm11zMq0hs6oyzqp4zci+5fFaFX+KhMBoyDNkjoNwguRdkZsG3CVsjwODPZaU5HnIuyb8U/JZ/6CKQ8DIpFsGXDn/CwkOTDACmcWMCDyFIQoKo73ZEGIlt2izo+Tx6p6lPDjU0gDcYCaQKJfxwMQwfTRxmlAyyTLJtIWYBOd2mBTtXTeplFuWTLNMI9ydCmWYxo7t3hBzPseqew+7kXWfepy194c1lnzAHqx/i+DucsyQ5EqZp0Vja+8Vi52o9XyZ0H9iD7AzXypVW3eAo2r/F9yjJ3SxLl/Lu7Vao0FjQmAXASXFMphAilzZdLSK6GSrVhSMFwiVZ4pDSygYH6FCmSrl7tQShSpVbvbjxk0B2qSrJMu4RyqFxmarkEdD5x5LCLhLltdbpTR60J0rxfxj5S9VlHhj+BOd4s5F+r5yuBAPpslTIZxQ5qAW91Cm50Zmqt0eV+7zZhV/kxhKEOPU+fJMkwdK8Ozx4kngO2milFIVUtiDM0P1g5yZIFBpuvIc5Ou57HqKTEE0mwC126NV1UOlmqPbHWXTk6+MpyAQQbHxCYX4d9Zxpe+97FEHVCE9X/eZSgV7SxUpnNS5aB4tar0nVymQwWC1PKVjtbKfHNF1Z9p6pZucktNz6KAaSKYXCZ8SqMawFKr9lXQGNDVXRr3G4tBoKkb1iCmFrC3M7G+qh1P6IpfPghSEAx4SIvf54Yvux1+AUUKFCRchUpRoMWL7rvd3cZJkKVKNliZdhjEyjTXOeBqmEXDQIUYYAqlNkMWMiT3s8JCIbLEZgeo8OrIjjmpz2Emn7LKbsXm6ogBLkA4TvWCPpp4+KpyxMBqiw149LmiVIzcjxEDGoPXLH3QAffJ0680EmTLDYt7XsFl0uQ8Am7J8+3+PNRsctuXHZYfXdVdctU9BfAJCIvYcOBI3lBMJKVm33HBTYXLOfbWY6zXL/bX4O6dnedSQqpdW5tn/efHm02C+/PgLMKr9BQqirliREpOU0hVMI6QyvwPoQJOVqzClMOEiRIoS3bfEiK1KpWpTixMvQaIkyVKaVqrR0pphuplmqSldhjEyje1byVxP5b+mWbLlNMdsteaWSytPvoKGtVeoSHHP/W2DRTZW0iubKu1NCE3qdrqeVNaByk1WYYpKVa2r2tT+ZnyZm2a6GWaqMctsc9Saa5756ixQb2GPKoqL4+7tuSKmt1Y55h0BPiGD1XZYYWsNVmq0qjUZara21W3TaD2KOgs09QzlR9FazdZZ7+8epPwZY7sddtpVsGzLhPjPgMfuueOu5e574KFHllhsqfl9P8nt1cmvUSecdEqn07qccdY5513oG0rLtX4s/EC56ZbbBtxx1z33PfDQfx55bNATQ5565rkXXnrlteE6ne5/n5pXsVz2+6HaVJEEpxLb/XxcN1tlnaH61nPrEOhLok4IU7CeV8V7tOP6YUV7NJ3ibZaabgRyYF1XM3mlgdi01DCoeOPtdSkoDaTQQBoDyUbV/DMkkkTQCtM6R6F1/ozJcStW6B/NpUCHiQrsUziMaB0hJpej0erIOnwyk5X0XFXBzvtJOMW/EIXpGZxF6PGdFPo+qQRzjDBsnutScnHZiVzetpfz1cusDi+5f0gxwd1w6S43WPl9NFalET5aHvl/dX1r/wus65yqArQ1lYP+9V24QUxOemV+cQY+PmCu5IOuP9ZzOkNR+YzVMoIqDYMQAp0sIcEMSnSEigp1l8E0mFTgcwWXmM/AdRvcMuIqENBq1FeQuwa8zMeD8DEIr5aUUshyWS5dhpeSl56KSqqEdoBVREk3gQZAFME8JTHBY8QXsU8FLfsxxngRwbH5p3dizbLdBdff2wKCwDhQGByJ6vZLF691T4upPxHSJ7agMOkFpLds79spH/3fChGxegwtf6SPW8YXPQAR1vN4Q8PWSK/ntTVorP2XC3UdpHItw1eXfmwfCBJsUhL+kSgBLuYqMCgxwW0LDJwo6SyRYxcLQThwBBIt72IiFBGiiiWs32mDm2Cew7bFeHkpNG4zOGYDoCAvjyzMyxaBoZGNlne/N+jh3m22MfrD1UO96fuNWmV+HEYP18Z21eRqYXGAzFuBgy0DULE3ArtGvFb0KoZGCjQ3z6Fo2tyoPOG0vnJGRgdHOyemSk8ZMIH6wk3SXvl/TUk18rviMagX7z0OufWFe5LDmx5+QDs+fgpuvzYNg5upTUOHYKLXqAY3E/NxR1cJom0FiIEC8TobNdZrzKwBsbTJiLEFmL0VZCGsI2sPG+j0X7rz2fSPE47kBgNLsxRLMbA0S7MUM+w8M74+lH2PEdeBQOscQmv0rGKE6/vK+1vD83xYmIhAzE+6n2S8CVp+/6j8KwIbvnuDsu8rTlcOgWx31h97JO5Z1glO9+7sCHM4tVoHp+/721KfUe/OcEZCjC3UcwSX+wscHPi0Rvq7vlc//8dfRBto+n5DgKPgwOvjZ7fcYf9hbajVdP/mCsXZtfk5wHin7IUzZT/lz4KPWfZJ3egvVnsKodcAAA==)
                    format("woff2");
            }
            @font-face {
                font-family: SpareBank1-italic; /*savepage-font-display=fallback*/
                src:/*savepage-url=./fonts/SpareBank1-It-Web.VKFx1VZW.woff2*/ url() format("woff2");
            }
            @font-face {
                font-family: SpareBank1-title-medium; /*savepage-font-display=fallback*/
                src:/*savepage-url=./fonts/SpareBank1-Title-Medium-Web.CxRjNiKQ.woff2*/ url(data:font/woff2;base64,d09GMk9UVE8AAH4MAA0AAAABSqwAAH23AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGToNg7tIGmobgYowHKM4BmAAjWgBNgIkA44IBAYFiyIHIFvFSXECtzkFjfpBtwEQWsfKXN6sQG6eKbdDEKn3ko5E2G/SCpv9//9JSWWM7ae2HwQQLauAFG0gk8zaam1Hl8nsY85ZG6OaHr1XYZ01THBzlDT01Wqiv//5lnFdbfIGySqTIXojIEcU6FUMT/jgdKYZ94GtJSe2PGHIEarMyTB0iL6cYa6iPnfrmTZDRiBBcE4INZUpkylHw+/bW2XNNHOYb6bJtGGIQcqIKdB0USw6PeIrNCLuGd81xtMwH2/oZ2kkq+Rc9zHR9KH7K9gVXQ9SymEzXdIlXRb/sV/Cy+Xh0nQcIA6riSxa9x/N4eMtyCPo8XXbXwTGLXxUzXn9B35uf+57K95GDDZqY0SN0aPDIEQsqr4CFmZj58cobBQswMIf6OdjYRZGYzT6eB5+HO+571vJCUzGStmyUpDSuhoSgNAVtw4PkU5rd7WrHUmrlbTS7kp9Qc0giSZAEohqAwuOjVwaEcWmNBdcAbcUSuzIMbHPccUNJx2nuScB/Da4tJ5a1+0T/p/+HvZrn/uCALPIo6YKKpAmojyyPJJv+Pl/4p52z/s7uzVhHFDigWRZM1mmAac5BSUfTBusvW3GgZGQR3hHPFIhfvb9/1L/PXWqq9bXve/NefvfDvsm7ADJQEGQHQcANYEJYYdBBgABmSRj5EgGlm2hWXT7TK3R8/ycvW3OnmysaUZAVHITKr9VTdsQOY8c7Sn8Nm55+Xlcs//yaJL5OfOzXaZhu6Q3aSlUBSqKicxgXnGBGmLLgleoUnGk4rS+QsXOsPeJfejsDb2ZrT8UDQEdmu9kAlmW2CAwHvCGmz5NmS5VSeDJKP7/f5v1Y3fWHvnqWcyTvJc8/zO30ZgTIy8hRIBDgIAHqSoozINoRDtp8XSPmFV6xP+Pn/M/WXlT7hPLrPtFa0ZVb13yRFOFug+iUzEqFqgpUpNADeqhwSWtk8C+6YEHpOMfx3JJ3tqK4vBb6F9rUmo5/pbm3xJ5gHqIcAmujJkF5qHjnhGxnH0trZrX+SM9qI0nk75GXiKVyCRSqdT//3/b/nvvdTO6vvbP7vvVyRQTYgiRYChCNqRpCpigDBkJSYQqxIAhgokoIrGUUhFL58F1uN0A/8ABoaC1lfrvc/suSCQRqsdsHTIhZKrfP3AS/Bvg783USv/vniFmMCJ3Wlgz1DngtlA166k1OQDaNcZEG8Q97/eg/+/fA/R0Y4AxNI0GeUsAMnCig3DCDNwAIiUCNB6UodYYS2DEPQEgtAQhZ8nzpM4ZmXPOZi6y1J3PNtzwglDhxd4G4QVR7LMzaHMdDnc0tAB3zJVWdlRC+W9ELdGu/7U0oxoFO19GR6/4Abyb2UV6hI9e/9XXaMZJkuWLmUaq7gm9ITrFBI9iB0q7G2mF1otMoLOFRlohqGbNJukMXyrqJBJFRQjD8y/P80hwGBOhT1gcCHlCITTCIoR7/vIIi8NistSK8AxCLmk4IcUF9+9+737t3t+sgx2kul+iiFU1lNRI0Ezy7kfm7A8vT4zU4/Zf7T87VEbCcBJmJiTSmifh32XLYSkqXr3/bqJq/m/s+zpX3rSfCRoi4hERIuKKiIiISLTt3Xm/9vP9LAMCSAACRpiDH8ov3roDZuvlqj8wOvIe3YEREQAgDAkZ+j8jAiIooJDFa4VYFOcVh+xG+tfKhcD7n4Vd/hD2W08//0rFE4Rz/51jEyx+W04+weUfqhes/to8H4iQmBElNUc6voJFSpCkp37ylBpqlImmm2uxVdbbocYhx5x2xnlX3PbcO5/RSQxJyJjMmVjFSuQTVChNP7kGGGKUqWaZZ5Gl1tio2j616p3SrNVlN933xGsfolQ6xSISRClGJlkVqwT5lKkRcpan/BWmGOmUp8VaKZ1McohTUAnlVNG6HuqJslSoCr0V9BsDkUKkhkWPGTtuvKSRgzVOuONHKDHoyCCfJSygx4obPykK1NniMalk8ZZ6K1Cz3U5xjl3s42BHOdFpnu9l1thkp3mHnfaKS65504/scKYLXO639vhnGEyCKcPGHHvc8SYtOXGIe/wSmsxsiivhVLKbtBTHXVasEFubUH+zml/3+je8cU1tXpdUW1Od5RtppuWuNaWpzW5RK/u+9DA4pbRuhqur9iE5fVZWXkWaXyAJwhKItJiWYGaV4YuxUZh3k/nzjrFvh81SVK0UWd696TyGzScfL0CWdB6L85B2yWnIm/Z09FCnMYcInfrq56Po5zErz5OSCClcXk1F+WU1V72sG2dBQW702zEYt7sLnft2skYsEtiOs4eYBaR8yH50avw9hWCtp0rUByruKjZMkA9zrA3nuH7D2PWhTyKmMPozxn5/Fr0V5JQzbhi362Zr3X2P1MnFi3g2iuVqZYq7ebpWU72fxLmrjhb9GvJt1ifacsyomCNR6GL6XI6Vy8Xm05uuuqKqVHOkq7jZancs2s0+PLs01766jq+s/40rsyt8rSnpfKVz+bn4RZvFVy0lV9eJiy6K40lNEpOQSqVSyYff8t4soRxZfiuIE95hg1QsqrimF0ToECcleXfoBlEU9F8hLt466x8uj5CZtO2OGfNcBwQCRoESFWowNOExtZV2zISJzhFhHSUqt75C9I2rZmNi8XyZLPl/G/z650mrht4NV7j5jL7WpNGNBfkd9mrZggwvhEqnIxpCP3YzOAKmjLRFMkaadwGBKnw9YOProGtFeZkORqrx+flw2655QyiASbtthmL32mBHagZB1l+Rz7zejBVNdM4Zf781EAgFalAwtG53YxAlaNnpLinYNpk4PtGWErYvDr9XpEGLruS0QSVFQv2H8dK0rPchIpB5XsS65y8dnIlmb0u5HlGbKSjZhfqT9NlNDvfEkRwAYZfHTfxjnTzJdPdivKzM2VQvpXfqfYjPf5RBokW6iQapKmrTql9A9CE1ZfZoMftNUA3Ipkoo0UQREA7BC15AOIRD8EIZDqGSvgNV+MjQcsj5wXKKSAHhwKiy4KCFwpFk5HcVlQDhYiXqoa9i/Q0z2mQzzLbYSutsst1J/2hxxS33PfHKW5/QSSIyInMGHDuXSebZ4pQLrnnorU+R4JdEiFZGuZRIq/zzoI+26IAvRHbSKCYSLeksZgVGHAhEyVFhnWQcZFOCi/dU29IdDjjikl+PLlU5nlNJ6xfinHo1uJsabGwZPv/yafIfU30W+qz1ifJJ8nnm8wP/BIzKPyxNLb0s4xRvZZ8SpZxVnipOBd2HIYlUEj1ZE574WTbuKczWZE/FVC0n1W/i5qzjBm7SLt5t69/krm3qZq5r9f19nEx3w8532Wd/vhd92su7lac75wUuc5XbudTLvYqrura//iOiup9aUg9Vj1FbqOeqndQ+6jB1gjpDvUC9Qr1RvUtdqC5V/64+ob6gvqG+q36mfs0i4yIi5keEbiQ/B0wOIPoQTyLQV38TdalHT25UVx0cOzS/4GjJ5izDQ/1lQD5S1oS05YvyZehG3leQIWZulKrhIEHbewT2LfgWPAU3fIUwiNcT4cdicLjvUfqv7PWitwSOep/Pb10LeIHZX4D4goWn1y98tsxh4d5cTGoDpdcS6NXAV5Cj39UF8Sn7fXavR2S0Wfyfv/kIdPnWrxDwSMnUydBmjFTZJcrgfxmij4tLDV5IgogCeO7vz4bAeSIMu+n5WBbWIyh1AG83RrYXEmvQSalmF5QvQKrMgXKGGgyMSlDjVKqgozksIjCbpFEs371ZcaFFWc1RyXwfU1vr4zV/kQNHMdEXu+O+GiiCQkRGDZQ+0yJ6gkSpEX+gA+ff36J++0a6b5PS84B55TSoniKDaIX8iwhtwCsXY2oQm4sDkeWWqCpm6YoZ1YS0KG9byZyvw3LMMLcYN/faQ+mmsbgpUufoT57GHAGDmgbyFWLchzgjF9rFnkFkKNFrzxDfPal7e1IB/Cldqq5rFISBQBmwpq8PAaM6tJQKzJ5Gp4L0qC7Ulkez2a7ymJikpJiY8qRaBRZoCSAGHy3YqeZTP2NzWNDXi0zQuxa+AkwFNGEvPeRJRW7BO6vIeeSrcf5teR2BmgWIj/2oL+4iAX840ZzS15Rdmap035xiw7zDs46eadaLRDUxyfxqwLOu0ydr3mbNgmmoSvBjMVS5332DfHUetcyGDedxbqYWkHGoxfDvz3BD9bPFNrVpbmCIm1vQiXuyvlbaBB6FjG7X4v1lH6yu8MT4tLLjsHz/DnM61rfEQbKjUCipltSFXslTutKZ6iWWwQyTxMy0MF3swd975dlzGMCKnitTUsRGCl3XZZt6JeJpRZXVEWyGOdzFTEIdAmsJDQKE4qihm5LNLkgG0vu6pqrVo1FbmmGy9Y3Pv19+6eWrDmdzMxvnSQoYphL9LbEGcmh8OpGFNmOk+Ml2h3FLrQQ/8MIiOX70N17GALyvvvuv51UmGJ1DihRUjsTcHH0RhM9cjzA3gIAA/h0C1DlyHKX8lfKqry4d2o31MEBLnbaV/EhhA53W18S9OaUFDAr13QFCHavmSZBrVIdmH0WGEzuCCVCdRSOIptXsuvOHK6d/LwjNmkXjiKbVnIB2ARKlDfxJ5KvfUIsOfcC6M0Skfv4LFf+UPT2qUXEqZ2IPZh1t+uDpMl8hklEEH5U/HYyPdbObZ0sjqHh3ah15yet2ivJAyzTkHUoMM/FPjPcPiyk+myyPcGMs6zp8eiRt7zsZDGoR/CEYBhx7loiSN599vnDE6cnlShhxa76QfF8CcQMBbN3DxjqT0CWsy4DgcgSMjCjjz9nqMbI0YA6Pywn9bC8KnmRxWV8Ewsh4n7t/ZQK1ybbLhDnKbBxpQjcZTgyKkQm/EZoLLYzk158W37iiOD5j4mL98wOlUXY3PgvoevZ164mxhCqFlvBWhnHY+zLB3ozffE2r7VgXFt6D1EBEJ1S5r5MnrXMPjXN+6jXgSF1ELOhQvYGTp0+lC/ajtoGCQR2aQ29muZvfWw+tHnrS35h6/HJTgeqPw9/fVEZ2MQ7BdilzJUqPeE8upqp582KWzykF9J4zRJxGKi4aaFBqpWmqUGAMQuD2USPVKiFgsFpfdS6BJEXz5dnh1oeHp1+fT64NPaxo/q4uFGKFDz6xbZ40xTpsesQRXXWurPlSenJSjI/JxMeBf8uC4WqanxcfalD8Lj26WfbjkxpfKIJQhJn/WzZaL4vUSG4Ot+/UICZ9Wd5SnZSXsXPvsAJIb83pDR2t/6f59QRHviHCPUOky/UtBPQl54pH3zLaHStMayY4L6FmygUKL7VP8AuXOxyY8uKsM9N0viojSAnhNi/p2x4jQcT6JNKOfNWOVGg3xp8OISyCN0TAIfrzDnbNerVW3bx8HaMSHc4Pztc/rFCsam+FPpGuPq1916BMO8WE58TlREqgIx+Rr47hU3anMT79Sppj2MAv8RX9QRBOiU7XLxGVpT/DBKKZWrLd4WnWBDQ23XVC0uy5UtPwsDKF1QQMI5o9owmqOi3ES8w2x5Iz15+EW/R7w0gCBu3IYsAcdhHYuIl0+paIVdnJodKqlbQ417LIlVm73UDWpi8H3317N74yIC4hIyy2MqlRAXEde3ir2xlv2rpVqzG17L3CbFym0s00TY4IcPSoSK+tCLhT4b4jiYrA5i1kZpHTjbfgv51D85vOOz091rcnTLKyHzGyyzaFlJ+sBiKxeKA7ODg9SauA2EjQ37eRCK8u8LcSiBlZh0rCvCcY5MdSUrLyMxS3vg1EMGhHDU23E0ADZYqnioNZBCrT9CKImsqN82ObFkleunCvPEVzI5JcSG//fPTIjT30o4icUZxD8XJV3ZluEyTnvzKV6QwDu3YmKNg331GydGh9vUjRO55k0Sf4N2qSdxaBScjIfBeBWJIZIP8bRVVi0pfQIzNsAyPCC2SoaYt9Kf398OKTU6ktnoWK5n3D0XA6/8EX06vnrJNnrfMA1Bwwfk3JO8RXm7yISC8kTZNvaQT0HkS5JO1vizEyVo/eiGOB6ARQRu7erGprUSAkLp2kv6Wb/9i5xbDaWC8FaJnhkjI/fnn2WoD6RBc38yM88DrTweTVNikrTZiCBhnBj5Pbg04rp24xwLVlEuoUvpbAq7NXUVWPZr0KUqNlj0nPZ0iakEl+rlRVgxitLWoqxbncSmwkLFyXE6Vo/sbKVlIGLH3llYMvfXXuFSZ+tTTX6MAXweDPz/tJ2TySruaq2pAK0wlQ9Shigf5cUw31V7ycRxMbR+xmNX8/+4x1vh0aAkdSranhkuF0Y6wy9EBiZypTlY6zPDWtcpqw9SlBGL7dhmTnAIhf73yBbjzzuoeYW1pQj9yfTflscS1peTUJE9rFyHAB0tszjp/SoN9RGvJVd7vj0ySaPIsAulgUX9FzgvA6Ua3CEcRJNte//N720quXnc7m5tZOkxVAoJnw8FLIk03VIBdJtUdfd7uIiKgLltziIi0UuNHavH/Nv9nZxS/MxfVs6DUFKktC+XxviVabmhoZWZJaqcBFonnfBjk5a1fJlZPnu5q+bd8Vjf1BLDvW6umREZ+szMAxJuCBMy4TwJ7LJXAvgq2X0s/ClSo4xeBdj+E7Gs49wK60YGj4IupVjGoHQtofzKqFC9fMl7Jyd1a2wBb9rYy+5pYbdulLPiAg/slePFCSa778yvKRBM/MmW6WYvCRIgZPyca0PRdl4U7drsdkWaHc6j6Fa42+a4ZYX3HLS2L0FElH1Ywc/AiUEihn67EoDmajaFGE9YhRAoofzKl3NjmNLQEOFFuCTQ1lfRHRafAa3/sDZjVwKAELgq90DdqQcuSORvYo5DrvQexhR1Ls7aELsaI5gcA520YIwSqF4k1VdUhp2n3UKFqsn3SBoMiw/COBgGyAo7uqG0KQcJZW9kKRag24u9XMG25eApNBv+tX48Y4iAWaK+LH3qQfjWAYDYOU7UCQUNY2dadChxvk6Pl/ORQX5cID9EacZALuHCHqf9uX4OICJHiAzI3qMFkmxI7wzBz9OCAgdm1O78yuAbxsbD15SXc8BmhE9AudaPEc9AJKRhf0feHrNrlwfhL5fGtVBcL+w0JlRLOB0DFwuBN7VzQYoYUwFOaCQRAOkZADeWAMhjAOVEEM2EEBTAABiGA8lAILMSCBMhgDA0M5jAUpVETzgwlEQDHkwiawBzH0hxHoZBgOI9EpqIE94QDsg/3ozFCLzg+HoW608oYGODJaf0UjujSchGPhFJxAV29oQtcP/AOnRwcv+DeqH86ge2Eeuh/WwUL0IKxHD4cF6MkFi9DL4X84G85BC7SiN8N59H5ogwujC3e4BpdHN664jj4Mt+FGuAO30Ocb7qIvBx7CvdHbCx5FHwvaYT4shpWwBH2DHbAcfYct6EewFP2CZeg3rEB/aiG/RYQWyaAaqmAj7AQN2IAtpveAVmMGHyAhFIYSzMSjKMiHSTARZsFkmAPTYEqYAdOhMsyG3bAd1sJmzPpzg2MGR08HcsRR9Y456bRfJL/xr3tqphod4lM0sIptm1CnZ7o0t6WmfcVT+/j5HB/3LHrOvk0g9T19WEnL3N6WgC1fAxwUwgf1ZPUe9UP1d/mW/78ujBVKfhr0k+6nl/1m99vSr6Xfv1WLfl798+mf7/38hXIjM6PZRguNTht9U0/SHO4v9p/bf2P//9KbxQvGnHG5cc8vmwdoBrT9eu7XJyZ9TTxNCqUx0impeyA70Hrg8oHnCUcWyWNkOzlKXiTvkk8pFYPiBpsOXmHaz3SWqdZ0helvpv+xbhpSbjbOrNZ8ovkqc73jiGG/DFs9vI9WN7x1hNGI7JH/Ghk48sKoWaP2jZ48mnpeGZs5tmjsrXHqcVnjDo/7J2Hp+HPjMfGACYcnjpu4YGKvd9dJNyY7TX40ZbeFk8VVSz/LXv9h09TTVk43mv5iRu5Mi5mNs/pE5MzqmD1u9v45E+Zsn/vL3PJ5xvP2z3tpFWlVafVj+O7Wx2zG2+yzNbFdZzfO7p29lX2tw3iHBQ5nHAc6LnT8p2gv5z6Lq53bXCa5nHCNc9O43XG/4FHpud3LxnuQD+tT5TvAd4PfL347/fv7Hw3wC3gcuChICKoMnhz8V0hbaHFYcNjasOaw3vIDwneH/x2REvF16vDIFZFNUaFRF6ODo6/HzI1pjJ0V+6NmZ7wSfyxhRsK+xOmJR7VjtNh4WZJ9kn7GESmQkp7yINUt9e80/7T36avS6ZwrM3oyF2e+yhqTtTbrSXZq9qUcXW5cXl6+Kr+kIKDgelJf89CajDXdiy/JLl5bvO7H9beGrVj/6aVlokkETj8S0DNgg7Io0BzoP/Oh7bKgU7NfDJ4797eQmPna/JVQvHZq2KqFqIVL4Z+FW9RH1WfD9eXpCE0TqXkqsn3kKu1l7ROyq5xAmyhCD0t9xeCN0boHNzXY5LvJshix2ND/WL9PXzWwLeMNew1PbLUY1xuvL123bepSlOnT27eZv2dO2jnCctn6X9sXuy7bv2ePdvQ6W+x9uu+rfeuXadNtrocHgj3XHzzqeW/LZ953tk7jLkT/N7pntIUXfIw/E/NtjFVYJSTHVPeM8Nl8Tx85In7j6E7xieO3wvbwo6fanjoR/fjpcdG10b3RYvTJMz3PWGK7Yltn1bPT49vipcRN5zqd25A01AxPnk19/IIl9S52ZnpW+mb6mbjucdcy0ud3Z9MSGiTErHzw4tCVqPz7Lg3JZ18eVRh7gRioQGXqG4SbY+AkJ6aIwpSC7bx+qzOqMQ2pbjL8GQ+zm4xb+ogwgoUydwwvSmZGAyh+hSsXlu0UAZJ7ginCBFTbzWWMiJX0uuvlB2kv0FPNGDY5pVWraugzCpsDgoh9INgxE4lzCNtcy0icwfzWqd4aoV0fenl4nE6ISSAuFEoS4hDqJQ1Y1etohPrmG4r8SyL/MkX/emFLc0g2v+1ByMQQmcpQwoJs4TRyv8R2MyO80P/wXBrDuLE62JTfFdN5ooRKexYNsfs8g0oplLBmJ4WZ/PDA6WtT0Mbu6YEKrRuIDC4+AyYTKdotFOd1wc7s3fQRmHJXJ09MhoAl0MaQ3g/T6e+gdWD2oGURnhDQD4VWDlenAal3eLtBIyVXdRe9wdAzNQilpLSh3bxzxxgEKUnJKoNv017DTq9loKqFamTAgxsgM7jK9LCrSYlqQ5ikybO5qxyEfNadD7cZWnyjwgYBMOqgrOBzKN0OpT9oINBPIAma+dcKHuSfEo9mi7sKPfgSqgE2X3pPQBMOFSj63hZ3AflMJxTuKegqtAzTumEgLmk8sdqIa7iKFrcL1ig5QtlTpkO+jQHcxzyGAV2bLgQFyija/uY79MVLz6cJxZM6ikoRAdq0tzCpmEX+uIpMxR4WBspCFdsXF0l9AtqVKc6CGrGItcE+9CEt1AcenGXwl0d24RpEWKQUTW/l1Xyad5i6W5Xy5bTFr2WtT0bMzlH7HfWUzKSx45y9qTB3AAuHI4vwRujdSkHQ+z0u9awrfI6m0mMVtVh7dDgPWfmg1w+CsYQ0JwEwpI8gBkJGez/AfjDVnDOl8hZRsQQufLSUYkohrhpvR79Epf+Ix6pvCYMD1XkOPyKgPvECprcEkNOW1PwaiaYnrWaNQqSV4awljSdoUJ7SSwzvB1uWmPkQn8FBlXduFEVcqkdiGI1AKdWGUDmCWYFbxxXoAFJB1DzlZiE9NIOmlKRklYGHd0CaCrPJpVYBtd06WKke6U+VVjwCiLHyCGUy0HzBV8dokXEUjnIQkhj9N70EhnWVmsR0CNhG+fv1sNCjVsE/+kEUz9eM7T3hnhP0ExgW+slQwzUzZnCY8xkbg8qjFLEQKcvwlO3Zz5g1QypxVKgQvkd1CX2sWI9W7nPYH8y0ffw70qNekpwWxfMkmS1l8H8Eh8JHqCGgjk0G34BxPAprHYRrFFspCQzrkkT/PZeOgRJdZlpRkpKWSd9tDouAbxOuwSR/Ad61xbW0tlAKWgbfDYfKgG8TC2CStWbe5N5z0NRym390q00KQbHREDFOwJSzkxkJpxYSoDYcUaLu9FWEYNAcJSlpGEjBOAEzAbCJSTCblwyq3Er8xeVNGqIq1l2LnHUPYtYSU74bYkhaZlsXw8fgaYjgDETEa42qiEz4z6TvEKRv3cssRk+j2AvubobQ2wihYdXqRkKzt0eGHHlsKdZfh/zF+g1F2wJ5q0RJtaHpWhb7n7Me/z0kfkKqUkH7r8pcsRFzT3nsGOQcUYI6wCKgWlmblqbnDWl0HrJHmF2gZYQz46Ae89oBiQf1RDzTT0miQJ1DRN7ZIYJJm9YMWgWATctgmFTJwXv5uk24B12L8sA8FnFARyc0xyk3MqZM2yk2t2mPYacLBegQpZacJYozSjqsAtimXYS1dCwAmxl8YO3VGVneflJlGQHBZyVdEBuHrGIQSQ9t52Xc9jz5xCUaHRSQjAwaGHQgqTtoQ/CxvZQE+AWEpAd39llDD4w4wU5AGYRNq4A5dNaAl9LU4JqIvgm/xnvTGoPG90OnXUoJGgTiNi0XJtWtN+/yFTbRHgoRk9CmZcHeYEKDQjATYbHQOLFd53roQRh5wC5Aro9NK4cBLRA6NB0y7E8ht4L0CSFfYH7ONYmXBHHScVKgfMvFVmvR3mHD7JLtI9vzGRSKtyE8xfgw4rlkUljNyjbHA5P3yaKL18xvoHGZ/0OP3oS5c7LRR6I3rm5MnzDDQeAewHs0aNo588HpUjihlF/oVaN5Zv1OUzS82D8qECRSaKqMqoiNPMmkAGUACMECQAVw0WkRCMdgU1sXcOkn9toRx2QT+uP6f/GSoSu8IBAIFwCYBVCyO7XQ5stFlJCUbF2yadjJ4Nu0kTApl4b3wVIjYtQIlAQmbCX1RWxrF4fQ9QA5XKACcq2cNHXcJj8qFq4yLtIqckkV5XSbkj8BkqtLJ6RBGKR1wERRIydjAHER0DCC8r9hBeAeyHaQ0YIKN437VR07I5Oz5A2j67oTR8MtphKUBzg30MR822y3swYsTnWKhKLlHhaeA3H81MSjMj4zEbWIUMz0mwb4NsHpbSFVllCCHUsoqQzGxfj1TUQq3LNO+b2icch6DhI+CzQRUqhzYL6amdzr8/kiwBifzSGurthX7ivPm9hVpMax01VLr/ToH6v8339re/JNQVwbA0D0lnsFsFHI39EtwPro7kiKMBrFnxNOoJKN5TB3gS7tAYtwTsxaWj4ZAa6Xlmvk7+fTl3BU1dSVtR2n66FmPnVvXP6OqAxdkNAQOv3YNx8gBQr2Xydw6eqppcFEeH1ZmVIoDavCmoFSGAxOF4g9AAmG1RYZXlA0H5VEVraS3HeXvu05aJ+vCBGYJpQl2oZJT+MigUQfcFeFC4m6g718a8oSZlMpyAexnqFLmFt09Z3b4Equ8/IlihKKRaREFH8DonQt6Q/x1Y8Wx/RTwlQY/w1T0I/ZRPpMc1dyAFBFAwOSL18WFjWUb5hEevynepWSUF4kjJjUHHrSsLEJNpgkdMC73AGXYaihoGXw3XCoC/g2sRYmORkEp0/afOaQVp3yNucWONux2Fe1HqcHrAqjWCC+7shlQM1u027AbkjQAZ3w/LMI3TFRjwibEFgZB/glKpksmliptAvKFeSxOH0TJ2AmADaxEGZzFVAKxgmYCYBNewtr7a1BB/Ah27LUwlu++bUwKiKme6Q2mcaUEBFvacojMqJkXBVDPhQ1eCLDihVua+u+Jo7hBv5f8HB5jI3kY033IhwbJNlJLm+kg68jQ3vx613Qr+1DpNZdJYjWDP7n0OfvVC9mD3ZhlRMVymADJL1EYuv9822bKIIWzH0LKDRjmSiDkIHeLX42IQD6MQMnlDmBoiQ1IGM8AhgFLQrEUQFVThMMqonMdH/KKcN7YBqDEV40+Acg4Mby+1dUrBUSp2xcH8UYDQIxITFbP207+Wav9xrd+puCHf4LdXOrpSd+9jX85sv95u37DaQL8rk9vJJEhGInuq4jDCZyB23UCIsta2TbKsRKYO3xna7xKPpkE7rhvXTdOZZ9TRmhiMq1BC/MF6RGsAfLiDti2xDBCDxzbhBWMCdfM4+6rl1VbRziS2GOaXrctNGJoHM1nYIv6DY9BUBDEizShZhPdtpHuqbpobnT9HquJaAYOrzVakzaW/lfpQ6x+Z6ImPNg6pcAIrzsRLgb7Q1ZA/HH2MAMwDCQMhot8siweaO08kfrxGUDR4h9I5oeNBCFbbzvkTEtVk86GeJGbJOEX3qp80ygd9XjVzIkiKsbMxtawh0kjRgLFoPlBboHkPJSl3jNio951tBk/Q97uWI/EL7mjehuUCGqkvQwo8y+6QxtINqTMQl1lWecj4XJpwsz8r5yKc7kiBvwfhNdLvk54ikqt0QEX//1BfWk12HHomGrROzAHM0tImyiHNltICuhPlK9ha0GCbtNWAFzWAYwMHjtYJroEW031mGPh2HafVnF1x4Po0vJ5NbQ8owOA4yogoDYcPplOeR97CyP11TXdSWaDCxNDmbUdDnj3Ea9EjqIGKOyt/ia6LKNfZMPx8SvedW2a3nmYcHpHIlvYfLzEsd/BF4VoYbzOd6HBc8RunU2OyRsxoad3Nhjc9q8y3ibjTtJsQTtGCg9Lel6Qi9cfPeLMWXuBTj8aO6kDCEZ3hHSgQ2KqdnFIE8sW+d6TAATG8o5mnZv8LosGkks1VVTm9J1OnSkx98U6M+++mqGPdIjg8V+PSBYx9tr5U4fB3oe3/JrC25hvH4J09ka8ftIH8dOHrGb3IRzsE3REHutkxuhAsNmyMxlRocJQKTHq9bSytBUOkmirJkN2ya3dlvEUoQc48DFZUdUREEOkq4HA7RjeDKm/oagnW9KddQdQaetSCrqFjTdQlHm0zNGT8RqfR6mSgOK6eEjGshn/nnojUAhDX/CJvy4oRDAz4oFduWfHuk3PKs33WWwiB+3HQigOe7GyXs+oCe7p7DY1CGXOlNdRZlQehg8OoR+VtCZ1Xm5Xw1VbPibRwxfR5w5H9Ydw3/Ci4Z2jaMfp6EirKUXYRXIDERjhFgEuqgAzO23dMJUBg511btOu36aN8oVdUVc3djcPaU/opZ/SvJjHt3vifpf/9ir2laN3+a07Tw99+Z7OrQyKdHGdKMkcXZjUhJ2E4p/B1D9nkWpIfZG6EL0+cZdDociyXhZGtakbr6PKEnuht3U7joeOJgmRMqEg1iiJQ2inmDrvgVSElrgzu/xhmFoSm8QCUiKVAISO6LVa1QfVxvoJu2zvgsqF1K1jWXHe49NzFfWQrRtZcdASt8VzOHSSFLarA8zxqE9Qmaa6o6AAMrAn9AXNgx0Cb/uv4IOpAfzMR1gggEHWOpUJI+jPmVf+Bv9ET0/hR5nvWT3ePHyhOdo2FCSMTLecchnSkCd9I4RWspW3meCzWdbIWFj5BPRFAk7yVZOYITuY5Nawj6TvS9l7zvtPUL/P22E4UK9icIwxnzCPnFN25B6Xob75WBGMtO5jQ+z4OwophzchzXbxuRYpsuq2rGT2pAi2U60+ZWGp94QqbgKtJToUiqyoN9fh853IwwXh6/nlbhfElWkMO1sdJhtfnbyVFZBCqXKY7rOx87o5uF9HIXG2J8AB1Frm6ax+RVG09+quNqQ4subwH9/6ZoMS3HmX9ocSAr3eML6f0lFuDDl8uPwU4gbJ+uOAO25Y7E5tuJtBr8m9xW8hPqq1GTe8mldjcemjrxUU19aASNygG/0vEDKvMvFaPtcvm4bJPHkX3q+0Y+rtktoUWVzC/uaO/0U2ldRsUChggSdQpEElMfb9TWyqmPAOLM1Pmj4UFO+kfYSNXfRQ0O/O8Z+IPStasn1Jx3HV/NOtiItJyYJImWngXCTQUztAyml5SVWzZq/bjq/eurNp587oLkjnfep8Qau8LEq84M02cl3Kn0u49UGOakWH6sjNOrYu6dhsS36iAFLrnjJYVrkNb5TID212cBaOZSqhQRXU1J6DL3EIPq7HywRq2B5WQa4C6o4RBIXWJNnv6YvSHYD8c2Ef6UojtXkZE9gicPPEaIhjFEWWDHV6XiwJu4kKAidMvHdwfCIy6eWrEJbqxYYPYRwysCNt+Pbv5bISPS9x86hykXFOrr/wuLY9XPm7XKf4et1B1fA+mLEnxjDJufYlNQKdMqYu3Mr+D+TBNnWgzJaBrEpsNSb8vtAtXvht8qMDGI+tBgvmhoU9HPy6cF0dle8RMeIDSASO1X/+kmJ+GwjWw3Jo8WKD/pt+QRPmfLAi6drTyfYzFOyNGrkZwC44nOHCcnwD/l1vLuD5U/uTD+n9UfBfbxmWOJWCy60866BQYkVYExcuVCEh0HMEWIKyAZWyAcNYiq8qFXEwHGI8zo+5hmarvxdx8IKqlGWgDh3MEOIR7KL1oHVioFKqMtsFlCHQMpG3RYhNUQi3Xj6X0TogYbdEIQe4u/b/Qnp1mqJS8+Amy1Oe8/AHxE7D7aJIHizX+ZFw/sJJeEtVwLSAaXfLC6SvjuswsPZkWNy0UNZ0CVkd6mP5TYmheE+1hLcsnvh3Fl1ws8DqQ5KAZ536BUC7cLvyO7tFGKSyKCC02CtMGgwHDHZ5MDldRFrHO/fKVg3Q3/0X0IR7e8LbYn2t8d/4ZWrqVqQusUFERM1NaxlRZ32DU/H1pcIE6D8nUvAhLqyT1O0PleR+TSLXJRlJIUy4h4PQRB6KF8jSYfSWToaZ2+/EE1+6GlnQ489bxGPzRN51YVibrkKQbTPZ/rR6zGJx2Nk4HETcaJge1q3KO4B1BKVhbWDwVQ1BsBu0CMo5tGESe3UvnseTf+asrVF8c/4Zzd1hk9mDXXrmxF07RKqQYyMOjZN6GHrCVw0jiELybfjnxWs5gqESVDv4D37bm4kYCUkLlUf6Sb0rMTMZRUqcX+UsjCyySYsgzlsAvjVJ1jD1y5W8vJvJf+VrHp10+oU0za0bUDyckPYyIGbiQQuca7Aj/uXwE2QB/gOj3oEpsjWsjxPu4aHY/PLhIlQ7mAC8KxXjtOGm2XZN1Udp/ctlM/QYGwELbQ7pYeWeE76DNllcSMaH+8ZdWdSO/5vy/TvLI1fFvS33Vy3gp3gYkD/joy/M4jMQzxFtshtmGgHOSi5+kxpbtAIvamnakgax3kGBITKvBWGziwwgun6EOkIBpYjWHJTtkXOqCYIYQhNDAHTz3YHjjRNq4Og1edtqFw1V8pTrMkvmjyvnjZtjUv1nn6ZvlR2dyj0Brw7IhPswAGTwUE4DcsUjYCgyYlD+KBvCZxY7ymXA6PTEpGHkjTtGBwd4QYhHNuaOTVOJDP9Tfg3n2sozJQS7SlVM+tDLAk8hklT6SzkhE8LGL4yitAAo+YBNWBGYsPlAI83Q+aI6hKjLI8YkEFSvR4OhoSR9310ItgMMAAsPNTI0pvB+m6u0tOjX7MEnPkFODLqazMHHK/Ee5H/OV2xphNier7PqNaQlfVeCFVb6S3pUSbz4YEXrz+SuXOx0D+/A1JmwWXVrNXYAPHGiVaC0z/Pu1lXb9B1gpx7XV9H6RFXVNb2X7XmFnUr60YKbBEvE8W4Tj30WaWqf0DdgOoqA1Q77bBxpR3kXHkwRD0EGQ0yNUd9BYxcK9osrdfDNHNQph02K9gO8pY+DlaN8e4O/Ja9GSQxlgdyTg3AUwLIwhvpL9dd8GwxLl0VeaLrifWjxYnHKVo8kePEdebfxYl3lOpeyUKWja+bLZUQOaebXcS6sexohFlrUWwHLjfoJEy6+bokZY5cNC79gPnBpQl5VKAZyWQsWyptnqwLOc3kWVOJuzyrVS3YXZaBx9m7mHvP3ihGDQ0GSJUtN0NxJ+hNq2ShoLRTOVAdh1WxdLpW5v33IndXMls1jU2qXPnJ7sJCyZp00uDNK8wTnIvyM8y8rr9aM7nTV5JQczpnleBrvodksnex2pK6U2yXp18/FYd0j4f7AWj8ssGbfTcvd8VwGY53t8OB9p4lfA7NfOd+sHh1wkBzI3iZcrcwnrh2IXHEoemKhDaLR62CH+Mz59TXr49fjZOa0EZfWh3uAXdAGxPSMWl4eKUwnl7Oy8XTPmD1UwHV7wyw8QsDVL8zgLw9Y7WvjjDvZfPtoTDyCAwGfeF4NEnn3YXIzp9lx6Rvc9EdtqbqqH9oJ4HH21m8TjZ5t0rYNXkTYAAYr2revmBcwyeJorKOgt53GLlQUqZLpSWSddNAqN337iHvw8yrRaHUUXYu8xbLezkrXyz6SszKF2VWq4QnneCOI0/isvx+TTqVe7FxQ6BBU8k1y1zoD2sWBj9YXYjc3qIm8m505uM49EGrRkikWEJSnwIhUGNncZNV6mF1Ypn1zpVwSbbQN7ku/4p3OZbBfx4ETBIv5OtLWqNkikX4I+V3v3ZC+oiPveIAjwdgqvPdWVOLjAHRbdW8mh4zB3sf6EDdirxx8TLifwvTWP6rxRu7crX0pRfHiTUOZnf2YHSDkebe5241Rga66OksnM/m0QXOgWj57fsZfMzx0L7JmCY9/4D5Pi/EpcI1z57Lf+R9dW/ZWiwBk/qVVZfG9XliaQlRFrTnBMp1eHO3LtdunWyl3wlkKcVbuwt0MP9AZCy2GTd7mXz55cEdU6sE84X8M7iB31a0+yOy2Q15tjFu+Be3P5GljtRSxnXBDaqEFoMPmd9Eph4h3/pFXXeR5SxJzcVFkBy031WkMBxYWOvTLKv16VSzwQgNlk+geMXiocEAtO/CG1n6Jti8NEfrTU3HESQO8ZHtn9fNKLC8Pq2XJXfB1HNXKAIP1m+TUy5h9qKpKLtssK/mWVECQaD5bZh/sZA+v/4qdDapuog3VvEFZb9DvAqpOSTKNQhYRMMii4XUsO+/hdBZwebKB/K5E+p2Qb3d7rppNWidKKiaWL1lmczTKGHm0pXx3se+bUNFgMJLeS9fjlfi2LsTqUUSYuqG4kV+eErmkjLweMcXcmuvxD1u+HfRNM2sII5WiWc9H+UJYq5tmCwAJWm4VmrLMSh5BV73oHfgbH+tcWfxX+yE0+FzgMcXJuuNLzU1lveifHiMjEIy7P7oXFAY1ncEdoujoNtGdCYeorxMn8VuGXiC3p1LUhceGheADjdoEk/HT5+euSKA/49rrI7cOKB2VdluWiKEWe88BPN0oB1+V0CnV78s9KgCLBwwlLZBsBvyCug8IjBu//bnrj5xlrdQwOSPieUxvNSy9oS4hSCUlS5FKnE4aUMnKjaElXovyKLdgPwIdSLfLFCdpdN9d64711XmqWWby3d9IVAddMMN1YBMBcpSCXdmT9Cr4M2qzWeNfb60F5A9z+yOVcseqUVPg3yGaadVS+JPWZQlKGCvMgMFgGzUw5EfCD9mJeoka/KbQDFzMsM9+dbwbvgqxNFN17I3Vcj2Of7GCVp/9tvI98cfvfnA3tei13No76FXMe36ovttD/DjaL7ggnXXIp5rQ/AjKgVZZXwMsj+PYE5yuMp903Fa6G3hUWpmcxnco3+xqctdCiUHpBkJXBae81hYuwBOLzSfi2Bh4j/1+35j3Hs3aSbuHFzGTbT7+yWN2CyaiAMXzRk9uHVwVaNXpYberS4R1Q3JWTZUDOLstO/EJSrVStU3LN4MY5l8n090TVJnzEXOuMfUAXiOhPRIJ7LM3wPX/Bl+izZoHyLIbqUKudVShPuyS8nRet+5P6/UHSPxNCZZGeWhzKt6tuLXtedsORoNjiyxqVJ7EQOmiDxhZefwj1+9RskkcSjy41dT3gYMZVg5GuqENwJ+K4km83F5YN2YR2k/IvWbeMTQ8JIZnLa43/gjYq5ACnuki9icPSkF3xyPiDFU3PzoSReNVo0GvjFyXKnRVex+2uNRGCu0umta/9F7vDobtcn0SHfNuk1BQp/6G1+iRU7Y2gkZrt/s/mdFetuiL1zGbB7HccDRZ5eCX2lV/OHSTiEkUX3oJCD5iW6IOJB/UdmzNBQiYTL+8nLggucjPUYheUNbQmepnLInSDNSTyBTKGgHuoiVS5XxmoISHVkQ7o21w99e4UMZOxHSjV0nKuJZgTCEK09SNost6lq20PIvDVT3TcOfwtJAnyrS7fLQDL/83VMbVyse+p7QQWKb5JVLuw+oCtdKFQagrjuKUJcpN7CcIO1kBQY/GqCqL5wLm7OSTAWCNYXXeJW1UbJhDChkkB0qv0Q4LSzhPEEA+oAzPV1OnzqRkmfces11cw1jjtyNU7bU+tfPNdQTk0aVvjsMwrlL35EMZliIzSK5bOLp7B9u2ZFniEon6LoPyax3Ekqy48p5LPD1qdVj8dv/OEYdUnoDLUf3S05LDPp2IdxiuQyjhl4aa7qAp2BXKCrk/LFEv925qbSDhw0s8SRxHiakhHGyc/QSQzuYdsM3Z4jpShomHYksKwSPn/hhellZM8LmN2s7f71vOP6bGZ0uv80BAzUF2/0nfrBeVuaM4PnNNCiGhGMg+JcVnE54DJDSB4in7YT6mnsAkhTxQC0LQ93WoCpQA9je06A1D7CTR7+kJpq1wT5rc8NFNzb0bW5IDsjgpWeXVl0go7yNp7WyrfP7QcCAAioFbKiAtzkebCDG2X5keiadS8muZKif+fz18+n+iReqLeVZGs7kzQrVHu8sTQoVh4I2yKVeGQJX3jbhuDSH5gO4vVTkWNl6ebukJX/yj8tG5f/wH7CinCmLSRAu5AzE4DI0iQGncVzHQwVN2YFODSKdfo9bJRFbey+wwqY23AuGNgsgSIPNZWjQDNIA21MHNw/UDumnsrYKAVgrSMDszRq0AjUI90nxLubxLT++XFrvtOoLiXOWLoBoAZt7KeBZEW9YvYBb6d8An+X6Pd/yGAN+XLTIJtjWSAMZKdrUrq/W3lP35Np8NUky2ypHV7SVl1qlek4mVj8zyLxS8W5rlO2He7c7nj3dnHHifrJjK7aY9RIVgse4q4RcA5qcTHyXWbLc9d9NCHtYTS5upnbZelePGVvBL/txnjfjJ6brgwZHxf2SMy9k3uTwEPkq2dtWsinlYt8WwQDaPuVmocYeWGbGJTIUl0mp/lF/ZaS1WTe3NA7kr+WYhITJLf/2QtnV8xZzclPpvQztfv4//boKhQmIfh1RU8w2ttT2V2cyNBmnnbzaz0Jo71WDKZvCYc51WNPQsSW/T4XWxn3aUpdmmvKMvJ7A7u1PPHN1FTTfVhrkJIM3Ql/FtiohnkVLFzYPLpp0jMMztoo4UEn66Sl8SveGdRhuCDQuiNr2zT3aIZD8i2brsKZIgy36osE74p+1Ym+cqquN+PO+LFqlzfqsZcyVAzyf1KH6VNCQ4oPtm/h0r1Lx+H0TR+672H61PURKti3G7YwTtsklrUmDvclsyyaVbobQBda/yRHAfEK2xBlpDqUgcVeZSxLgkYkLqxMOdUI9Qrue5bVcI6qlSfXuOJlcTA7a+b6579GO4o4hwQCSXNzIVHOOC8t6FB1WR8nK1mDD6Knl6vwnbgLmdrcI3vvLxwDOvBnkFFBTQFrCXNfdIlyNlaEQwNw2NimzpcECwldfAn75mprIuxxwmU+gxv32Nu1S2dUZpdnKrsna12V06mAx5kM5C0QtyOFvD2lR9Aik+qwnqT1iYNaCl8sp46tv+9YFq7jaI1e2tCqSPey/raGCjCOwDjv//OaQc4bv1e9vbhwYT5Cv54JK59CzYmjDdj339xXQ+MRg0f+zmjfkFBSeOsRZ1quD6MXbcYnVSWoapNrjQHL3OWI2Hg129svN5ngurEcwL7rmSxLYdig3Ptir2rq581SoCC/iScJG7NsD9HMSG6MbXwv4C08UYUlR07QuCWhd12D2ZQ38XCXYXKIAphDizoqL01PtqMix5Xs05+pOZmrGLbF62pd97fELiq2p/mADvUn7+7XXX318vRD625B81zFNlnPfacvo0QiL91gtu359OQvB450s+sdVthUJFidvEQygd0Yb4Qg2eSRVKZkRhfEF/XUwCS1AwbuXwax/Ja0XwytFIWA0zoml7GRoDA8TXf5TMcgN13jBmqqz6hcn0NXYODiQZErF2pcftmPwutBZ7k+nOMmtnx8+WnBue3HJJxIU7WzZ+cdnTuT7aS70fYqke8OzJ+1qPIP8TLEnIksebpkKkqTwBPfFVHaR2+5VuDkkMvbLctD2wGNtJQ/weZMSqnTZ9vIPJIIo+lWz2uCCeXNfDLBt9RBcbV5lmOH5M5X6rrxSYOwuhcmyDooyz+rR0DDUsfQRl9F4sCjczRSvrcoNfXnE1Qfh/6q7qXiAFxlWyfkfYfSYgH6YuUuvvj+/71qTJV9R+TRr87PC8vzdIGVem3Xpj73lmeRLwTfcRhNK9vvVoAPkReAZcIG4e41T7dcw5bz4PhZwF4vGOhk/6t0ZvMR/Hk4KzcyvhC6d7bAEASNPTtoWuUQmp+UDcUkO0f+cl9+DTcQep9txty21jD6QtMa12PZ6wVukJo7umO2W2M/TAND8DB5I7IXhRev7Mk+fPFM8W3MfAnsp5BBan2NbiyamUNywZTCwqWC7PwRpJevyWilag/m4nmlyil+awS3Dtq2q0HfW6uwTLW0+ejrZi+kgbRPP6EK1U1aPd6EbetBLpKQORpd46u2l6rQuEydDAkaEtRFeMFJ2QIqA1gYBb0zLOWbfNPAHX0s1DL8uXtsgmJgg878G8BD4SeBfDoV9ScgXPNNgMxQj7zfzustdkLqQ4znblFEsquN9eDEiwS+gxhX6Zgb4SsSb00W+l7G/tf2qmKiUMZIbRCtv+G4KKAHNd1Q4FJy3rELguHFjNoyOlcboD1iZt6lfw7nFzRiYy/V5tthxnTpyTuHOy95Xhi88r8T+OwYeY0Z+uew4lrowRVVOmdFm7wuSk3InfRQm6UypFX9baso9e4G8CFzx2qP2GbfAPqpz8QsHAp/+4s3wO7xnpAxAL1A7snCPNhlrA2oFObNZTHTYFiKkIDhGbWg7e5guedsQGS1Cfwy+l1cNQ6r5Q1om0kFPFGeWZiYVQgp3hk30XUwAiQGhSIiBfcGmBkIZpnYZLUKt5Z4jWnQ4FeMW5vSI9LL2BBGsPUCpDFSdWeEELUKw/SC4yiCqQ4NI0IKvYTLXSzxreFO5dJf2BOX/pdfAiH9UlmcSu6rwcOt/cYLTmVKVC2Qoe45EvKmM04T2BcrnzqzfXq4hPErrgPeUb3egM17stCwuAGPS5bUXkb2JxQbZB9om9qyf7GvEcnj+UQ69vHBl/P6dh7S6yMaN7AYsfXTt1gAmXhG/E1su8gM3XGYxDp0yNy+EaD8nif63RyMgZYeh7ZJMoTf7ikNp5hR8fHBFjyba/7deqlIescqTPB5f/d4SUmTw80DJoplXLGkY5FtupMVPm9e68HZD6KXVd1ClsfWEsZ8MOQBTLvzmIlo8ketvlLEuM+tbIAzF+3vqBejp1X9fw65cTLtzhLuY3E/LwBoWvj+0NAgtcMqtjFnT46s5cP1Vz9H0kerpx+mHnMCjRiBn6fS9oGh45mwL12odQ5v7nq0SvJDAQS+tnsdIm/WByXDKkTfDzzsXzC9TtkEgmB4ulKYF2DT/TXlNC6apdJPYRIi7CK/S+GrkT5a3IRKiHiGps2S1UVTEL7MyWSnxUSjHQPHDNDkuxPIcWJSHJuOw8mLDV/Rifk9cjhCn/BP0n4u0kYzIBo/7c7IJ7gMWPL+OSxCE4sBT4VaDWIWfSicNRMIwJht82PBxVWUj7Q1Wj6H7hj43F74WL6lmNzX05yZ+a6xbyRCf2XYru/MaSQHFzQqB60M+XALGl41eN3glZo+WpdEVa4F3coC+M0bV12FneRDPfKKeh7DAzUDG+VpYL89SzEPHyuvpYTMHhtAMjtU6xPjaNaoJcTKQtuwNgceC9/xGLzzvndQ/xsfb7HPcg+9NIzZ9ljBy7zol2KBocbrs9KFw969em28xXXeKfCgG9WH+4kTv2uQ3bDYa0vg4VmfP5OlI4X91P2XCQOCLIDMMELNmFfYun79PoSe82fpxCazQgfC0HVNgAPIwhV2RWWN0srJUh10oUeF5hLaSzsutfa/tdJmS1V/7zq58sRRPifui9mWkJbhWgbu3XTsSk+YLuC4mmAHv6/am2QIh8dABdVzCf81LZ75b3xJV1Y+NMcD6sahNbMLUODNgTXPEbIlMFwkfsXsJJY3ByJekuF2HofStWQl3XIQM7T0C0f/3JXH2eJOO9NCX4epL0H9m3e57f8BG/9XXPcyh1yU5+iU8ZJkeh9DtXzV/49Ezc/I14QC3Ly47axkjDx94nFaF/bPqd5hOGXUW8+asRQvEQFxn3DFDR/sDGWRMXnD/uLeYk3dl2vk08dAVd9YU1mFVVtx8bSu07UCrP08BqS4YOVJEyBswWlgwt/QUgGsSCe7Yr1occleqWfxfQdpOTnjqrPFhZJzUjkClu0KEp9C64IKnRj+23JEs077+xwbaR2wc47hlpoPANAbxCT6dJhq9FC0pGTTZ4wXhZq4npw8Z3ycL6H/DI68J9VEkSFuvIT1d5waq3Y/1HpnCs1fZS/9USZPCnjnD7QKxCG64l8SgIbg+8/Tdl2n1kaYdlNrgnrjF0TmWyP1M1wkuLWobus/hUfAxN3bnieFef6nxok/r3dbxk2TaP58gXBlxR+hW+TfZckrVPyuaA//cRjelbiNvHcVfZOE1181esmU66VwCdn87HEg7GTqC+RT9/pnJ2k72XHTeBHM5HYvCnCWPP/ZGLj1JYv74ovJ+c7bPV06B7D1WtCErYHSyminP4HMsenBd4g1BXHSZiyjxpq2P1yOZI3LNjdmWkMQl4rUfeluFnlrikqLZhC7w1dNTvlpIufNW1koVRQoaPJ+rkf6u2v7LnP7eqwp7ZmWVKz894EX5J5YchE7np9be9xAtDlGTx4ZNLkTsUGhGBD8MbSwA/OQ+sFX/fk12fxEFRf8tuk/pq18nyHNM5TZ5i8Y7QTu71q4toUQZjMGeNhq6R5grj1q7uI+qdnLyH10ag1KnyGiyLHht3Pp5k6+llpob62KxbqVJFC90lj5uJ0v2u05Rn6uUrtSIz9z7qHQDg1O2/vO55e2d+u2ayHluyKjP5ruatNh69H8ZyZdJMVuqiNn9gWk2hNAWmDFxrX3/XnvSziP1QkwIBCZkjgElEzI/ikjhoJgohkIsgtDaO76NOnV0UAUGspfmuZiWZrjmj+pZI3y7x2lHqFAhZMHfRTlArN57Hv1lU5tCJLlKBGmkiDSPinFITOzUbVUGXtetLhEzoSYGq2g2ESl9tt7wZsR+RoT+DdkNbx4/PyICXdc3J7k7rAhEn5523g3ugqv/Yr7H50ns1M1IKE+4DV8nZYA5fcVlYsF5dh3OgGnnGi7upAWoHTa5lCEoSc+k+EFRuD9Yzgy8zaFmdfRQOnJfJ2nKZwHNwQiZ6AQF6rQNkG1QYVLBEVZLLJmgFF7zN8ooUXugyJspckDLatjK/jjO0gGWlx3ad7xmmzRqgahLAU+CcBdT/0lPDQOeumuZmIF2LNyxllOR2mpT4XOfGaWfEWreqHRLq/4VSWWoktckNUGx5Jd4f47qyMokZ3ULFWNg7OBPjtCi3WUsy50ijtFaWVtHy0Cgz91H1VOse3pj8TFNu5ylS1xB2WuQsu2OS6eoDFpANc0HAh/mzSvJ98L0vfTQPuEefaxMKD+bf/RIUOo2ddErBOmI/QxvUafSFW+ox/LxtzfeNirnvstl5ptxralQ8llF5GleinF0CracuEjqPF5HD30f1TjPGPLmzSymGUh10ltpVKt+F9Iu6lpYTSfALcP9qVMShJsI9VEamNrrdQhdH8mHgqR0bqVMhrJHdm+NQbtKpkVqdNpA1SW5DlFphkGjGasMY6JK1YauH/NUc5X3DGI8NJg4CxobxFf8jPz7damksSF05sqDc3aX8+H3l9htF/Fa7meJD1UQKdYxN60Q8+AFhz50nYDrE/buu//kMQS/JMJ8IJYVCHckpGyFR/hRUu7Cg3juQRR8ClQIrpxdP6amvy/j+CJdT0Zry9xDHs8E7oUBLkwoDIxQB5fZL+8hCDk2jMg71D0/ToVfx3gehTG9fxCjqnX5CGY5GXQ98hKTpTAIMAyLC5RmM75fayNrqSk/otcHB+EKO/U+j8KDmN+PieJqTg59GXJsCJMoT2/lwEi3Dpb0vF/S4hf5yFlJVsi+fHxhG3I57pHORc44z8EhqaANC+KiBTdAFuAJuglERqB/9HeJDHLuIL7xx9R8nU2uNzb+Dn2QUs2i9yXW1FxFQDAV3zQVg/qCoHQpB5MBUAk0aZRU6q0PuUt4+sL/SvPKjhUu7Q6zmVsa+pYkj4kJRsXXUEXwMwtlR6GKWah/FALC4zmfC/7ZGqSzP2nCOlhwK8/cNBuXNk+g64PtVe3L7a5IQNm+KJKAYO+1o+AxmjFINh1b/yi+G+zod4DTlwlDDTO322cCTYjsG3zy0/OuZKOZ+fz1c5OcKD/xvjdfJnPO1eMYVKhvguzqvqZE+I1wSpVT3nXHD8g7+yBNqTDApvUjX5QlPLuRV5bb46VKotCDS+xthjbJRVlkb/I5bFHtyzklE7eaZKnPC5LO96b9iWx6FPMjicQU4iVGn7bRzGksL+E3ag4O8F/Z3Fg27CfhPpSsrfR8UkfNldW98W2vVZ8ZvOuV7Msc8zYpSIFOl0HGDxLAzaxtkL0dPk7As0nWygNRjNtI0WwlLy+B4uMRBq3f5tKhV+LosCaTnq+4SLSFL+2V0i3yUpkwUbn0mT4vRPalyukwSpNqImnK5RjtwvM8VmPXlgU7HT7uS6J+mn7ujIQSvmSplMcav5VUZp4+j1r5Q9XA2V0OlZN948Sqbhgt3SK0LFPdFgBw1XI3RlWPWXOHiHi8yQvKAcp8zq5VLvdpTrtbuBnZIJv92eFC1YGov85Ow+1wn8dtZFjJpv8sS+KSYL3fuJ/ufHBNnMU6n3oSx4mMnP1q7gsmMYhhBG3UI0SiFAxlBE/L9WSFnC/1uH/0S3kGy9clQd6HE9mlQf9UmLqy8RJmROWL5doBt/oWiApjTFMIvPZv1mQr7Vx48c7VVX8u52nTDpL2J6/uTm3oZqxyU0Z3M8AfWzu3xlEp2yvc+ZHPswEK8hF4B1S1hIdS15EKP1Mi7SnqBacDmHzfW7VSGS81CoWUJB2hTWHaQfO7Lq2MzcdXW19t2RNA4MC5gxYa91/3XNk6/ALVCj8bSYKkJozGhDbOlc3hfE3pb7dRL+gR2fC3qnslkxSGGzUYvCd5/aoeq5vSY8qtn1A8Veu0kr1MTMywpSkt09h0wruLlkxS4Tb5MUaTLCBtPOHKx73gi5an/bBtYI3SoIvlmpLS+5tZj/ZY3epoPeJKFV4tuztoq2XzCkv7iJ1QvF0gYaKZ3ZgKanKo+8GnK2nNmLalRWfaE50K6nQEFXRbPVr0jcC85fiDLJb+mQHKjwokAS+AFp8KF0kPRoXdoZ0OT7NFj2qL/v5av7cWaxRUTaLcVo/a/jS8cwXVTWH6y/53B/ylWJuB+HRou4NO3FYkUzRBWwA8XrF+xHj2gKJ+d1oGKvBKz8Ts66T2YY1vkUis/j5GbmJZ+5uEc9IjLz9MTNFhfW+0PXvv/aoO8lvtrfz7cSfmft6JqXfvzgQhzG04nT3HSXXZ1JsG+Pk48tziCW7f/6EWAPopgPGO7jHFdW5lNvqnILAlAZZRdvPQqlGRp0XYk8FwitG/Ma6OA3v0WC51B1GbWn1cxlytdj+5BAUR6t0oCNR4zTi1UFwblUiQsbynIBfUfsynVSXa0+Ulkn5ncvy903+Syi9yiSjXFYV1GRwrwes2sfX0wCTJkJ3zETtxqP02o6S6OCYaXc/EHMm+0RfOAYKVQoyxILxOECYsnyN7KzPuPy1VXnYqmHBUKgCy4o2jKtQegSvSCv0njOhkY0r75bSEQkC2b33/wdujqWI6uAMJaIkiEqaxVOOhoaCkbIP2CuW/qi5i7gRl9QNhlGplWM6Sf9Bzw6B7xmWI0cjvjzuwzKcVtRtpaq1wQnMFQt/0P6bxUsW5SVTOFc7So3bOQyeMfxOLc4vM5lIHf54f9tu9WGebzXewe+pAr0KEYrg4MmJjc9i2xOYShLrI5g1fS2vnjB7sezB+fImgwg/LQ/6xEmlP9L3oV18f8clL6OMoxZz/VxlxLB/Ef/zUSgHbuKOHHpaz9CFqi33SGljEveqb792fVTw4UYFeQMQQpled9dHJNzM2eaNfDWebZAr8ovq+MOEdcz1rxkK9cPI10KVw4INyQ9tANIO46G+3SYNe5To9CFgi+BJLCBYHNpwZC0xCPbsoIjnOOWw40HCihlx0avM6oS2gN/SEb4ln+3ZMWb12Uvjf+FatLkWlA9zgLdzYGlb4esj/CO28r5QPZGw4QSkGQSIEBSV87CqXUAIGiT10MjXPW0fuDDxSt2r7D7ZGrmG8rbbFnaYkJKBRLaoQkS6T6Xoxcd0JhoQiQADu9PmUlOuhFO0YYtTcgheFAKqg6zgi+Na4yBKQ6fMlCfHgR3kDVW8w7/EdmSc0wTjyO3Rgcrmr6C5hGARdoZ09ERy0GkKKgPFd7QUHKt4ml7JaKlo0kLmWpWIjB7MCXQQkC2QJMAtPk1WQ35WOB4Qsp1UDsynKWr8DIlKr2bZh50iCZEc++zBTheW3Gdqc1Syzfq1SdcHfk+k6Mc6oLO7JuVA/tcQrgbihAf3jIoFK9AV2nJm7Wfj2tFa7n9H2mp5bEMhXCg/obxiY+pg+UTeUAYeCTEPjENqwrb9D0PUCoMfOaV3GqgeFFs9p3SiTap0/3XNCLkkAzxqfl4Cfq1hGVeqWu3hG/oziBZov3LLRlJ3XR1yzt2qvzCLTl1XiBhli9xNf8jCM3n9Rwrk0bTwL0JWnLPdEGwJBb5R0Etj2rTkQQUqdcgUfuf2IFgIp4hJ5Bv00YqyprN1nnd9i4eRV5yPRGVdXjAeMa8jwsfzRu/E9x4gjRcAGHDZ0Jie+e11lHdnVivqKdtpTlPaUFKh+wglOqDb5BJMhZPkVu2NSxat0PfmD/okOtX0eetbkP7F42Wvfd00OoROu/tv+adspEvCCiwB0xgcgXM5g91xFYBLhmOhnRmxogbPbxNkg4TP+XvaVJLLdfAi9rDsC1KA1cIAo+Kovflh2RwhqnYBBDVKN0Wv32Jd/dQOY8hMT42ngvIh3cfDyQ1cJHupD0FGt1ydCtq1I8gtbVnZZYVXT5YUVwtJlYkVJ7Wrlx1v7ldVf6Pcj86jpmqGPsKFu5mF7CaAMuvadQpK9R8hCZuAImbUm6NqhqwE5xkDWfR1x/CKY4FWWJFdGqPWCjTD3p4EF954ct0819MMN9rt0cbOhCtMf9pk7f+gVxQe8S0rtDFi6+P3U0Ni7dYSIDZxpd4H8mNNAk5O9jcLg90Xxxqmsa5mGtvwpTa8IPfIbg6wfrlXIO/OHTtyT+dra3zFLEO4dW79w0RXTQe1voQ2jnOQ4ZESsDEZb9b19yWa/Gpp7+IsdrkEvQHBASt45TTv6SZoig1sVfMV+C/uChhFhgo9e+PQ9k/VqC5Slo0WS7y0rzelofWHoo5TS1MqQuUSmlqoWGQSnLpEWLEWEtqzsCOtXL95k3fPgO7fTKRJzYKSZAy4YvWY3uIq8oXya5S2q/xyPWZBjNlOAEgCR87IvhvXFyDvbz+3TeBaTHgkWCLGIyKkFrFcNxnqQrvMfSq3zmilNu5PeAdu6ab5HBtBq1zAJoF1K5jfXWUXp0kYXY0byngQfRbIlKLrIzAe12MDRvDLoeKgQm1x6p/d080Wla3uTmtN3EzZ+X6N3wjGCcf4OqCMkT0egq5fMiFatu0ZK0ZCzb72mCAQ8KJ0QR4qc3jYDUBfBVYhDtgYkjUAfMJ3YsqjfM4lWgEqBFMnlzLVERcsmdUQUdVkAsHQHwo9CTjYdJiHicR5RAeYeWcCcXjNBTIWARWB8Xf2crxh/I2D/8y3EZAhNQGoxZL2gE95fA+aYVapKOJxT8422iG/sDDW5jQzcCORbhjVcMKMovgk3GDZspWK48zSbgQrc186tQFPryOvvu9I2mLYox+uCEYUDd/hMzAO1E9K4c9tWCGi2QLpGtCAZY3sbg2hCh/BXMJui7Xz6amfk+3gI/Izs6qC0Fs3Lvzzt0UJbKbUKw6Mf9nW8ARhKWsMUCnfQO2D0cM0lIkzE2VBY8It/9J1qz8lMPaamHUdpnhPhE3GaGGw7ebWgRUgzOD5FRXCd3lZZs9XavcX6JapbG+Oh4cOJLbZp2xQ+52NtihppcNCPfxeJroC++tZnYD3g631dxvypCb4YhHWBZD8b087RxxrEtcflkt9qGcvbARLVFu2dZZ5mAmak6Ce527hEbWE8eY13HmPNRgSgr/eX8MKoh4Ks2CqdaLm4WEOZY7tFqkRkXLIbd5MpnW0rvy1lfha0VE2aOoHnJxEadxp4EBIp8M4Qxj6Y4BqCWH4wONkVz81Cffa1bM5nC3SClCgncA9u9IFCbbEvDTVf9E4XMsd+yKX1GU74L66pJ0f0QyjeJieDUHro9JU6hhfAAzkGR93rWg1VyeivxJSgRzwCkU9BpxW+cwHLIdN5AaInvGq0UpiJDLZ+W+ubuDeloN2OWijFl3/9uNb2tYzvzZT99J5oJZM0ISG6E/uzJZRn3XxsHcxcW0ttVFtLZ2ADLsX7M7wPO/0TdIJrNwgTmmwwUNQcku2bAG7StfmnfOzaQC8chVlv1uS7YpJ/tf5M7Nn3MhosPuC8iz8dgXnf/YMJ//rL8jUHTJ/6TyMWT0lYi7uIMxqQFpEZjrcOlsbpeaPSL8lt2T2v2wD4WDEepZxnIQE9pylze4ukP1hWmg3nV/QIUhwCPuKbjxf3wn8TrKK4lmBFSfKWELgiML4Bx1AuwzVFOiCPMa/rqALe3b76hCZ3CKObMuYPAGvGZw4hxaHcjnhDdt+SXeAl4jUaFvExg3EOKhf5nV3rf6xe46Vt1TxYfxrjRqFTJwO8BPOEuKMZPtR1+ZHfaownFUenGFSwei8lNVnw0P6NKei/900PVWjDQPjy4pP3Gh6RC2cyk5zbSBRCOePoRiFTjYE3tKuVA4xdS8n/YYm98TnaO3XKuCHTmr4f13b5uqgA5TT++paZY6uSUHz/qiR3uzSxyah8tMiDPwGSrB6ufGiSVfcwCPnOrXYeE2b4phR5H6MDws2BHLknaf5Dkc93ifzSRd9sSPhefeSnPBjNAetfAZGfJogerZ/vkX6kba6J7oAnoCZnWZ/y6A44HytA6wHMgYEcsN3MBgcD+jYl8bzFoubcHubA40WmiuLzZjQHPDGZVk3BpxYeTvigoeffTKqmDjyRGLWG3nzpsSPdwsb7NYWOGTO+SyyQjD0WNaQni8J966+PP6eJjqeeCmPmp9dpl45WiE3zqi7ZwCdYM7/WK/Hg+Te49drnVyyvp6UiMhFvQkB+VVAXpWKN4zxiYMQ/Hu/yyMrmIR/P+HVzTOLXSv6t8XuQcYydclLjDJwgh+waT3Ai5za30ScaZILb3e4TCNXH0JdIMj8xWy5fG337zOLK4vmSiBUJHy7FbWvcZyhfUbWHVooVhXTH0OO2wgc0zJcJYuZWCjZJ+JL802CtcMkQOGyyyd6CuoiN/B5SyfAU18FiJ7B0sKVvcfqY1U08ENvn1whDIO+WyX6keZamgXDV9jRhLQSJTL1qiKlJfX9wbIXyV0VXGmLCGwJSigcAWIo8AHchL1LY6qvDCgJ04oU4kQaWy3hAano2uTp9jveTUQUiH8eceMWS6J3K3ZmK/qTAvojFSXSoZaN4LP6C3PNO6YqC0bPbbx/55BzFYTEbMW4E7s+eUdUy0Tug9GyvO83a/1fiU8pXdV+v37PuScno+rqf6m7arVhfkRGCs2vTJY3avVZddfHu7IfQ2/gqDL529rSz/7Iu0Wf/OpLQDI58KNJ3LSJ9V6g33ZOxyBnOUtLEDd9acPJbY3mxBPlOOlSBCbn89qs4PD5V3X8TZ2c08g/Q0pHz2/PQE7M/ce13tb/Ys1N1xRUh+ORgzoZUuDrBtLDEzooWoVccwbEB+0lPBiD7/njBij1HNGb1Eo7vsy86DNC7s09PgW1xWq9FeLz5+NcrfrLgJ/AKrR5WXND7yntsPc/Ej7KL2JwDWXCdeG91VQMrIg6qrPM2xMUknRkn7GfXf6n/2UIeYOlWbcZQwRx4iK3f3TeMnIg4prIv2EHyN4p+/LXGKP2hflVnxF5i/1uPvwp9LvtU5ukXDp+DOT/PBbw4tOkS1qLnngi4eSDk9PoQs807Tj76/6L5bOdUJxbC4bYS0Ieyxa+ids4NfS4rHgYU5EFfyL7TJW/A0mDK40H1MQRsDVS9SSCc7V3u0mMBjm+zzzvV2LdLt0DzwCb5dp0wGY0461t1P50n0saPdXOrlQrP7sbotl1+jT9uYwVXWie3usKK6P0/b6z/EenqkPsr+q9XJXqH5BuWneGq2fQmgkP7+9YizIGFbO0RzdIwI2Sq6H3b6t9af7MWISk0MUmG2BGu2pyex+ZI12ybIQvWQe/e9srv5dMGFrqxG9kbWBhc/SrtRPBEuR9+/KO68aYnJl/9kYlzedT4sqidNo1dg13bNbPaGcyNrHYwB+wkNanhE+EMTxxM2pswZRyYfDLlzYvw8RSHz17RQRaPQvffX0/Tu7f99ECuVyJKUFnzrNnTk3PzphOWc3ZhnfYNCZOJYRAsL5IX28q5WBDx1x1l5ZqJ5y+nfnHpDxaR/iDIN81oI3A1e96r1tH/nGcLnjHjtfzkwGLOzZmgxWeHwpP4PkJfGRzvJPiyb6UIvXT5/stYgcCyuAgtXOaG0Vnx0Ma4PNPpHfkvYQ0NB8PyaXpU+ZuGUWdY1OOk3m60mXCDc8V1GcDONv4SmEMzqpVyFhAFBttUAWbfpa8SS+Cb6YNCmNsmw3gjYl9OhQft1Kz3utEZSN3WCl/jzwNVMDN+i0BOXDnc5zOOM0iORGfQwokImdphxh25ijmam1FrOjqQcpk28Iu8EXOnvaqcesUeyamQJ3Y0CM8fiDkuOioxvW+OXix/8qKG+d+ELL3pokc/4Vpbcmcx9nqRv8RfsadsyaGl9d9139PTFTK/C7AoVx4G4tJx9z+3RcWX3zqXtjrfxCytPaLo2dJaysyDp84vc5L+EXJ3WRj24CXPP6utrV2kS9uiksOnqxMvEfzqpvkjew6t/6bRj2qA0OBqSOfdca0Vbz4dN3Nr83a67z4z7+Z24gPCSXryk1FzveMaMvLeQW9qwg7cFjq2YTs04X33A9rd7VPNzM3G1eE1d8DUz7fZrXap29G/Q98geY94d/Ba2KVkl3dHn96kyJ/18eHUVbfg6xGp8d2T3ZE9+xqAIEJS27CWMApaBotG0lqusIDtEp/X5NylJT7RQOq/dCnQ/rF7Sz+iFU0q9q9l1LGIUQzHCBhh9ANWLFitpwOkD0DcqYjbL0C1h4DPOhoZopVA1caldyicRUlpGiaIugsULMlWkgv0Na3wRD1mqnPkseP32o6kqdTCAb0JvepmbRIX8FzfoEQsgsUFcfSahITp2488RnNh+0ruMmDudgGOLTLANmqrXUW+Jzt9PuzOMEibvrFdENg43FtL6bop93Ovo65cRyQgM0VNqIGYF1+0L83Wo7FNrTx59Aiq5+/YCliAj8KrAdyO5l6j+DT/GBjGWBtwPBzZ9xcRxQISC9U0sl3WPauaU1x7XKRnQnxA0/1nTob5wZvrKXC8CBy1kdDq5Cr5390s+8zpoAWQif5rRR9VgaV9+joxD5YYZjDMS2K9tu57mFaMjhpKZN/0imyWcX9DW/rSwbPcgrNT3SNUvXvyCDfX8rDh26jNS2GL0ZjomTj8cemcLVoChEmPjxcP4ZOUD38kCMS2V8KLDaJvHEKYFu36uDksocGzAmTE+BVCCuJyKgLzOvw6oZrbio5Ezf9M5P0oG+G/Edho3ytj74+GIsh9At3ABkrn1v1E/oI45jJot5htvbcOszu1U0A7U7vVXUJ5Q1hKnWcREDAcpiFfHCoDHYW1dY7K8DS7LqYDcaInGnQd4hhpH7ZiYGTm8j3hKLdX8AkDlngXgCjAwKb1hNXxkaHjgsMMYGmcq8+RbQ37ZWxOX+4UnD3ug7FbeDGpCQMx7Le8ZGiz6baHaKnIufxRbOt93+MpYgUGzojH2ClyZVnNPkkjxFc7qGID9cO3OkwLcu4q5jaxNSZ0yqbPXptCHDD6vp5J6DmCnSfrFqrHEN7Otej6c4V6k7A1CL0G/rP08o3ZawxCr0HEx5cFU/OKokWoBxqDbVH28NG/f+NJAqXno8kLYHJB2/w/5amkK6PT5nFUnK7VqUKjpyaY6tVM+dHcWBaaiikOkn2pwg7s6UB0/oMS4zHqw1w57hJxdVn7XHPu41+ZLf2HwR6HTKXKq9RjoLf3fTtk5YPNUY4UXL4gKISHJUJ4dBkGvyDLJW6gXwt+71i2uMFYotegVxdMrizUGTW62nHnQsLLY6i5uRX0l0F4GrMuaMjvme83sBrmi7VWyJR36d6/5JaiVvdt5Zj4YDEEdbf6CcvCuBIL8OgyDP5h+r3Er6jqvxYXfgt3YgEXpmdXxt+tc34CffFsqWhC/iAdKWkUvLaGcr8NbNXYN8/wqK48CjfRhs0xmIsDncsXbKpbmxdZQ7G3WNF8ucJz1Eok0NUr4FXFg+Ili7KwXDW8BFHpFCjyr7X79F2/StH7ruhupPDnPl30KbZj/PvT52C/IPgS5M6vvgK8/auv9UWhkjuc2oFwjJhS0rDnTMtXkDC9FCg1xEjjTDbNXCus8aetdqpR55Z2L33AF3QSkZBUciXIV2y4MSaaYb4lVqmy1S41Dqp3yu9CjOsSF1z+Mpa94g3ciE3Y1M3d4q3a+m3f3tWtfif2l6T4iFgsuEhlJKEUUM2hG6BSlPUwe5zksKO9wEs966hXvWmXP0WExSQzeYnJsnCppJErKc1fNa++tmY0r6HN7pLaKzbf/Ra0rN4WXf/f4ATOhBvMTeCmcfM4D86fi+OSuRxuGbeFO8RVci3cae4c18bd5O5zj7hu7jX3gesFLRWojFVEZaYaq5qqslK5qPxUEapEVYZqvmqFaqNql+qg6qjYM4ggP4+Hogk8FCPjfkS4HloTwnkBEYM5TxDVSAG4jqAe63hfzldcXn0zqYycfhtGe3xHBrHpt0ThFH/7EVMEJR04qO7AAYi8DZq3L7cCFvGCBBFZoNzGqBDRwMNtIuhSjrUpm0Lw8JPbOVCW4DwBSUPUanNWAbSf4cGrLPItAuJcHt6TaF4Bdx5J/zpnCKgNEWvjJYagrSuUmhwBZJSbIDVBed2NtPbtW1EEFvDCSfaBtdG032vzbZoapL0jSiNc+zCM50eQwwi6JpQyg2/0jpbX+QQe4vmimVUuShPCQS0JwrXWFoxMebzg5eO5s0vawFD9PJFAAB4tvA/6LH44SedBuo8DwVYi6HiMs9YbBUI1gzBwAxkyJknA2PH5xeX/b5ZgOl/f6bhzSCvBL79GaCIH10417F79UdegedinK9DIC4X627uIgz/QQYPC4HEdD/fG3hWiTCKVBgiPT4wkSW1hMP8GeVeXg0NxixgrlANv54uXr1XPtQCWSe4sNUSNGM2N9fLLweWknOXdGZ99JCEl/L7nAOIuQ0u3mYLoHDYYbI2vvlup8s/RDskllfClII2v4j8OY8iQNCbgjOLBYIvYMMHmY60nSA7SpVXQodDnV+j7PmyM1FE8q/lU0EeujQpALCijSKtuadxiNG3xkmapxbtxudFk5rXxNq0JWsnOrcDcMUy5j/MBWymWbw5VUM5xnq+vVY5Vys2g5r5mArMvBtozh6LDdwar+UBqcRAUAHok3G+Ga6YNa3P1ui4hEfPISH4d39Rwe6DNG8npxq6apyUgEYu2ZG+9Ev+5eRYPv94Icy70kCg13pxa2X5p7Y2WFbTnNu0MmqX9da4Iu/jX5DIP+p9yA7nSV4ENWwjkry9sYiWfmZBD1QLWlDFjgNJ4ggz/1D1Kwh4fwsQS9Fov4kW3Dwg1hW0UO0ZMPcYiBBkhyJAhI4T9gKhJm0g0NdNI8ljyy+eS8TyeqYOUExZ8w1tfL1Ow/xm2ehS6eygKi5ZPJhnSPL//4CgFRM2HiUTzIzAkeSx5oqKOBo04X85WAt1OnW+Y1LNX59+QJEAhLdoiJQQNqkiRobXa9FBoWLC1JHEml+H7Gdx2ZI6VpN25pnPH010VLbdpcd6OaMnMzIuyNXBnR/fig4wW3qu5ljfhR6SpIOmKZO+VECpBhgw4RYUIVDQ58uQClEs2ZYCGTS0an9NAzM7evH1UqaPDjDQxP/Fkob2UAJ1+ED+eN7QiIG5gs1cWLNRKK1fqFmdbFroxa3eYtZYmkJpGQYaoiUEBzoIOZRVkiCk6hAPApFBc1MoPJ9W85hSgA3B2JTV30GXhQp6hCqgtogH22Ko5Q+yL/+d5ldWYc66yx/1t4Qw5w7PQ+rMMmoBacpDxJTXAh31LeRB9iNpC1WCCk4MenLcuEyVsMjVqrIG8I451EZBZBKUBhKsCzfHL7eRhHpj+dJfjpsIrtFjs4/kmhqkxDD/TxlATPXOwAaLXDMruaH6Do9ewhg64LgLrk6Kn/TZhUm+9Gw9pRRYEsa4Dl3mh0dyzGcMFnoPpvIh0GxlQfVmuEAuFTZOWW/sTSMsOjUgurByRLUD+DaWdZduxse+eD/Q5QhbAzU1mxnL3yhiQsCUJptuQLVIWDaBLL4gvr1ajAIeBBkyph9G7QqSL11ubH1FmsNDeUrPz7LcC2iqu8JZuNc+qQmqgw2WGC8p12OAnA7meJDMSw5hICFJKiXFUIo0S+ctPUQYSxCIQxToQxTYQxS0QJehHZZRgo2OzzLIE+dP22Jx0MhYBuDgcV1TLO1lDcK14HgswppHOcP2Ng/IeWA8qf3g4mmdg9OPjdf70p/xFz4F1L+5XgepXl86se10lTr65I9DynvRoXntH4NFH+uWh3lqemLCdMeTssEzZEzDjQEjBkYiSEzFzziQsuDBgyRXHipaUNTcyKjqG1NzD623EhgfPr4o1HJoI5tQcaHnxFypaomTpMuQ1Sz7V4g7LVRhtounmWGSFdTaptled+oWTv2xgdfiPK9qLT9WRgIITf/F6KzFSpRV/57YAguY9ipt5kRKTR3NCe9os7ythypoDHb1QsbojAEUSXMr4OvXlh7rkxJyOlP6KGYupguhatPBFSIjDZN8LNxAZayxg5DDWeHrDjTVZpXmWsHGVKlsOp/WHNGr6zdWsVZsbhrt3WBU6oJKR3w+x3ogU9Dk1DomdOsmFWxK/TCN0P8ZL01dOiwm6xwBo/9/ma57Ps3zX+fgkvueLZKJenM2rV2K40OlzguDvc61gnM9LHy8EN8upJEh9vBPvCrzPfjwS4hrOzuI4QeVzphBkMZHE07xBJgr4U+LJxFesxFYhoe7T973GnZkSgwl9fEsaTnQIMA+QFcjP4nzezVbM+GiX5gt+tPOTxks0pIYpH4G//drEXaXqLQstA1BcHQsbLP6bhU8+x4h/C6t91AvLfLYJVXXnWqkzyRyTMoEr+FxIu9El5p0z+pgtjNvHU1cKMXDv57hD1aKS43Uqf7HSV8s8FdSdSl5I46k24OUwFIXwF9QZQzsWTAdP+z3hOlbbq0696t8X7hEvco07POI5e1pem7cC6xKRjEzJkjTkRDryoUAKp9jOPmhqK2bMW1XVtGvo1B3nHQqLI21x5+iHbLSpZrTboi4LMmqFMajdkNhCCPPcFiiUfOY4IN91Pj6J7/lLmagXZnu0ACIrcb44gfuTuFZ8IVT54JEbEIEo5e9G8S5/5QX3hxBZy/N8u8VA/5O0W4xbCVmWM0lkxXCxnxDk44r4f2L5VlSiQHjqM5k/hNBqucMjcaPw3HIKaWGwGCeEs6YJUbTem+rgREr+UlUYbZMarZWLpPBaipIROVF3m9qOPbIKETZZSu1Iznl0aw6+FzMGgPEWsyEkCbc8u+UHTXBazVAg8sG4QJkzG0x/TGGobEGz4nuOqG5grPDH5unMmnjSamxGZ5XMeifboMcEf2KuoqQTgAltIORHBY5ZkIN7tgp/UiaP1BjEQy60jUyWhlXCmDOekmDsPbK9cnZ4pnCm5OGl6iYhxn6DuSbWYfeRulNIosHgvKr3NUStoiOVaYHQVjgVUISfbR8KNq5DKcjLjgAEXCFNLwhP3kHK/YtqrlCLxcT6H/kKfjZodtqB8b24BIEIKlddB/3ObWZ6b4CxFl5KZDkO5W9nuXu31PN6svRnXtEzDMu7sjcstzeaSLLwqcAVOLf0qDyVckmUfw1+BtvfieKpxmeroA6RwnKimDoLVhew++Oojqa7NiFP8aYCFxTnmJqth5VdQ+Hv1vDMha7garSt4CLuvH6+aqn7cR72gOuT3fXCO/tR4Nzd27gH5c2Pd+vuET5duivCLniKEZC9+EKBy5rGT9ftPCerL4uuoqjpTb6GSuswuGI3ibaoePaFc9Lqw8aixjOq4LHqJT/Y6MeEK444ijO/EIqnC6VGUPunR687smrBtvNTb4Qi/XbfUcIGEZTYl8+cI+vPiznYwzMNxU5hGQ6KReooWM+1UnmgdVJ/GD4TKT5KtZIe6Z4GeO4K/9qut+bmcU5qSuSJU4fLEEAVGlO3dkQsK6o5wqjAaOsLGx3m2srl7eltl1mw1eR7gsQkkurn1KfKmpLcQ0M3UZE4ug8RjadJtnB1J+SFmpAr/w+YH/NrccRBb2mHKFpYqnF79eVFFaIBbRvLXv4RWhQImaCIltFAr0ERTboGyyLYgQlN5AgMIy1p+097D3IKvbWYmJDp4nIXQY7dlaOqmBEF6QaSCoKrJSJShaMekf4mXBwL9pyTsvYCYo5i35CO/vw7m7ZlD0fjNjaSXWhBZAL3TB5K9rYnD544YNGFmh2fb2FppE+Lsk1V3ngkGVMBYjJ0x9zgIy05LIPUOyKqMBYd3SjzMoZlB0yKoY6K2PEcjexsXNb7cNZ9My7ctaxqmNXqtYoqIBdvQVjruku4vXiJUslUx2q9P1wiLf17VsKFv5NFK6bxwzkmtDDcFVgAsobRd/VFmWyQVVx2NlFk0c30Lz6Pg5n740gRdBK4CkXBqQv0HkVgryXL4glWUhUhrpludModj/KQS0jOt4/DaS2HcK3wIKWfuHAQvtvQldjM5juOQ0a3s/b6PUTseIvlFQ1o1YeJqWtZQrZsTJ1z2rZDnIBgzSa7n4lHx8PRQIHLOjaZFmncs1YnGfZoUpvpOg7q0Eke4GZ5C/s9ZM9MxMzs4hk/NkeiNzm4AjcehxLHsvIc3MsOIEaOoxYqKJ5VV9kbR8tDtfjrvY5nGw4KB7L5Xr3+TcAC/x3+rNvN8vJMrtlLkOWzZWQb2j20wEwfpD4gA6EIiNhOf7BK1mY5TO+os4owKPESNbAQKye24MyEKy1bOiHsXxk/FV+EEhcRknPkzq+AC+6SkhKdx9RcwZodJ0958Vc1MOnm5BT6g7vr8lTzhCErIVfwLZBguTlpT9ek6S4l2WvvUyYYq6e2AzhwoEqFUL+yX9SLftz/Nf1igBgoBonBd4QQRElMypiSOWdBQiVJka/AEcc1xZI5PYMow2JYE5EBjMmJKTjgONGx4iGEnTDdeEmWIkJPWaKsfPbsZrCZkiy0WImVDhvgqBPmaNJksb+ctUSLx1Z74oVar7xyxFu/cBQPHmciEuBshmRSa+aMXQxkOtezZ+1GzmK6jYjiFA9sf7oj4pziJS5cd4lHR0BIx50HT168uPDmw1cMP0AwQ6GiYpGIhEsWi+mNobpJComlgmpEMiYSSMvixBNPAA7AKJKyAglITHXRFQXhIsrfPU/WJAa2I9EeQssI0bkUIGhoVSpLK+rc7qJH2Z6it+jD4SbhwA0pMQdgNuHESQ/ozJGIdiA9Ffny4//kQUJ48MjDkBswYcqMghyiz7DLosmi1D8W9TG664YCIElKpsr4LpWiB+WBGzl7QI4FSzE3FjAAmIsSDIhhI5SaDBHFNQqsEtMyW1gqA3evDkwc0/cgYUYvnoycEUcmulBR5Q7kSUQ+JEJoyKyCxfL0OIAlltkwAOeA/R8xgVYUL8DSlDkLFCgElHOL+xQtQj8wCZGdG0R23lEWK8LtLgrLFokS0UyKwUiAwI0iX4AyBbC5/sp0AD8U6ckYPrmcMTcauSmKralYH0ilu2SpUgQ1pU0L5IJToUJarkFZQQWB1GLYAzpxlkjPHUosV09yXUXqIS3Bk7vx4c1EOk8AoDor5cnP3lfkabEETjA5Z4B4vRQZdmqKOEisFKvEQ2KL+ED4ko/MZ8uXlm9svjqfpZjjxmWWy16gBL0VGy4KDDAH8hYkUR8lRsg4e27KgXwE66KvP4zE5AJKTnyF6Kqf/kYFwYWbCVTN0zMMMFrCRSerdAzTXaZSY8DFZ6x0DJckS5mxVlMSVtx8xwjJspUbB25w8krHSClyDDQenDuDpWOUVLkGmWDOpaexHMhPtB7yDDYRXHYyS8cYafINMQmTGdLwFKunAkNNbpJGbDfsaYiTrlCFKaZ+Rpp4zIyfjmPKmgMdvVANYMWJlyBRtEMZ0b0LoqOT0wyXxKSkJhuuaWyywz5FilWq1azVRdfccW/hyR9RZ93wJaq+fchmCpJnl3odxaeKEYzmJGFh1Z+oZ4M5BuVqNDrVPJ+SnZzBXHFLl0e6vfW3L/TFfyu2L14/xs2BqRkxKaypkSaazooTL0GiaGUosMy6bNtwSjK7T5FilWo1a3XRNXfc88RL7xc+/GV7NthvKP6puD5YakYGkJkZaTwLM1llDlkaNz6CRIiTJEMeZJNVmmeJVar+ty0BDIDaE6LakU8s3qNSXBoSk2y/SbrNJKNqOS/Xd5iZYonOKmozM7bN0ntUjL+NYcmq/ZnEGu/Tonl/5s1jcdRVmgxFyg03UaV6Tc666IYHnuvANwLVkgktzjAJ/PKl6ivPvoOqre/UPRfVnItpwVK61V0xRlK6dMscWsrCSIY6TBq+emiLTXWL/9Q+AePARKeYMN9nb/7ZnX1gAatmfdjYylSz+rVVS/SPqCpEjI9ZsSK2xZFoiQflt7pNw6sTDIr4iI3oFKnTS9DhgtSudh/BpTMedtrxVu+OyJJuCm24RHikRcleOaxlpYMzRGlSr/OCPEvBaBs06TAHGX6hyjMORoLLkiYN80VcGr66TlMBA8eMHDjTjndzxyKd0luqG058mLJyUzTSSRTphbI7N06YcNbSGN+yf0M6AhorJlXdDLqdvFviHlInQ9a0HqhZ8CbFjpLeicQWSJ2MXnEWkl5AfNZ1e3FXgOlRspylrbL7Ek9Il4k6HIlAkDppM82i0klwjWyJsGVIiEBSNc9SHcDqC/HfrilBPUDiFlInLdZc8lbBm9cJtuqRqIPUSYNtqli18U2r5kytqEVQ66RkkwtaeZJlimrItZOCF0C54gw9fVoBYKvE8f1TV29YD6Zi60lbrwFbXr2/tmuUQFCW6GfaaYmADhrM/KVnXiPKU/R/0L18I+K0oP8/3StWIcle9K/uXtlEDLIA/Wd1rzwLLuWobHYJSpoigWXG7VbYiaVmxL8ropigMsFhnDTB7PE36Hn9FtEaCvZen2ZrVg1MFHTFJL1Lgr5ChWzoQysksEj4U1oKE6/Rp5ItW4rXpseZAxHkypNvuRVWWmW1NU7RyZnpYA77dnsGaYxO6lZdW1XziinKo2Oi7sDOTkGoaImSpcvAZK11JtWqlurskA7aKR2ySzpst3TEHumovVK9fVKDmlM32h+ZmE/r0fnG2M3gfm6sst4GG22y2RZbbbPdyZiUJ1VYrToHHXLYEUfVa9AYk7ykOaDaDjvtstsee+1TY39M0hOE1JyOfCOGBcRdLMPyswpstg2v2BAt/x1huGf/Pt1gSa4cJ7/KxJQ6pckKzi+ieEoFiIVSrUY/gwnpDNAV+zknMAT2mkySgleKJFxEM1wOPAF34195XCJuYIpRpprvtDb3PPTIS29iSECG5CBM7NbagIiCXRrLQ4UbLuPwkNPyyfPl34/FQpwUC7IfXFAY5ngsMMeXEZA0BdH+9I3YjmkQfpkMi2cw8M92/hFwsIndf4Q9coqAvdkPO+hCAJjefRVgR8YjrsJ0RrAZkqUkyrftDXzlIHvcT8TqLl1qpfXwh57s6U90s+tRojAJ8vMUJ16CREm8kqVIratu9dFb35KUEO2sGxWUzDtuxaxdOTUbGrZiFIhtaqG1ZcdRA0fGXe6ZZLvx7grnzvWMcCJAoHDwHT1OkfimBQwz3GgTLLXWbv9r0eq8cy647IbrbrrliXZPPfPOJ3zEZ3zFFxKRkMQkQU7LlCmvv3IDMvemxZaabp6sjmqsv576yTBQiQLFiujUFs6x/y8L+lIkl+0PQ2UqLFOWLp1usAprNOdYhEh99NVL79IDtaBWYUPqJ6MgnFxl+sY0Q03kl47deLPNMdcsq6wGrLTTLjuy1WGOuWabb4GFKi0yK0HllYAaU4ki9XedENGyFBhvsq32OpaYzBhYWDm5JPLhpcg2wAiTLbbMUa+8c2pekiadZNKu7iLgzRcfInI2/Fj7jvr/BHVu4g8bH5HSM7HngA2HEQmSJEueCnVzu5F56zpVP/rIUaBKR0UoNrmRGtMgu/9xZXgeYMdHqBjZCk2wyXY1TiUjJbNoDrE8UgUUSZOn3FhfH7HdW1g6ZWl8xB3dAJQtmeaqAT5YeNA86cjuESNkWKFEzf0o+euOKbjs+Hjv+AXEf8Cf+5Mv8pY9zX7/rv2eUX/6pva7SlRL6k3CafiqvdTmTqV0gbDHCTAzMrn24OyDK6AJHHfsdLM+dT/vFx+Xk+YPbsqr7jzN/5qjux3c9m89EvdHagAtgCtwHuj0v5CJbWo0Ou6kJn9p0eqljr8aWCT2a51sup2evcQlL9dn72uilUuP5zaj0IatZJacL0M1KEO9Sa8d4TrgOF1yEa9lYMX6N89HUpRZtiXmWuaFx50wfZoNUNZCxyjLkmKwIYaqqCHsqNh4nT7RJLMKsLHBUiuLMHiNtfWqkZTi9dntgOOZ1+J/rc4570IWXXbdjXpD2wWIZgXpIz7RL5pN6aw1UXsHJyNSU2CEi0a6ZJQ2Y1wx1lXjXHMimya77Y4p7prqnmnum+GhSo+cTNM8z70w30sLsm2hVxZ5bbE3lnjrVHY1Zd8yHVjuPVb4gNM5tM43/Ol7XbprrfcTG3Rio1/Y5Dc247ElYFsMtsfiTE7tyQB747AvKWqSYX+GqHUweYcy7XBm/ZtrMz32T9qq/MDfuVSfZcdStTVCdQLUZVKz4ovM0YRN90COXOVNMNngE007VBhhkmKHwCsI+n/xGQeMw38Byz4PwO3vvOhpkpitX7tWAf/xB8JuoYiUjTMqPLpAm0Ke3j80PZ1PCpGO92jsFJjxhPkuca1pN6bEjh9offTIZlyFjevnnl+mN3Qmuq9kpSvkG+vhhJ6NWnNs2hKW9ILsyY/Qq7lFwtwPHMuxf6j3ZqHjUq0r0di6/DkQRSrbB7jR4f/1gmR4jhiEs5ZUJqDjaeRhtjzDJGY6AoGdCszFQO9Fi7OxJquia0PjKZYAz2mfXaAQLMJxWIOdiyx0QHuG8qgLn2H6iGbFNJUWn+Q7S8/lC/JGt9adogMOMzslJeRYpB4GxyJ1izMTvOc431XSyBxHOb0OnNUsy2mmdalzXmaWbc1iVIorrkR3awby8JhfywEx7BkgZQRq6lgI3Ik4tqxELSGt5Qik4C/ICA12n/gGeueFRSQo3Soew0oh7d0G5ISKJ2+OLWhLGM6XHuGjuhvuez/HR1hzQfv7/5fg7KxOZlolL2G5fFXJfM8/cTqfuYguCUjg2f8T97zDRHPO0R4NkL8qcNeCGFuiK+ADf9qLUMbe+CWWaSIo+U+AXUkJpONpbklFSkQG1nGPUklDQWKm4fLpEaCkFCilpWLly8m7hnbj8tl/UGNJYfbu1XJ1hkDsv6fmU3zgf9eeP6gYl5X03aDaEpUaCJfMiYjkOxpfC8YYCk2z4nImRd8n+3VmDwd+2Hg4xx5gbc1ezwN+s4YrsRk2xo7YDQ/EMtxXT1LF+I8yXIb34164jMkJZuibh3fy8hq9Rx1JJxw5zwrfaY+snviquHxhj09cuufZU/4jELAf0p7TOXct1x5lWHSp+jbPkZD3MN1OptrhVG3MvOsJS2Caw6btUmzasup+gbPnvNHp+o1ix9OuLPm+iCtpaXYo7f4Vv+AS5lMo76+IT4/3unfjZfgrvAYfwih+AWchZkrnRN6tz2z5qWvO7GZZaUdRz2XkXeRzKfOWQ5sZUw/fy/trF9JFfzUQH8b/sQtg8sHq6H5//Rvcn022xJmfsq5k2ZBpLyfNqqx7NRfIeG2ojAW9ftbqdeDXN+lyoCodn2tY9JRtrtR/RwxRWf5st4hyLmY5syoWsBZZLKSXwUSVe16xnMi2yU2p7caiSgMARZpRTHQNK2ZIkl7M6l5WsYB/bxcLlXSjWMR/wWKx86soltCfzJIGxVLq01RSVmyo/iwolpNV/oO7M7X6SvwB7yLgwfn6U41/gmoN/lcc4XP1yo26El7Cf/7Erg018BD+628qn8Le+Sgf2tNDQwZhsfmbLsrf3wC36kUBlJGsJIRSB912o8jbHfwDJB9GBh5JgjPRSghPgmVzoKOsLs7tTy28JLAiiZ3Yi4LvvskbeOLZfrn+m48ewcRuSmnssL2KIKC/8pGhfPWTMmp4xgTKnh325bXRO3fjt40N2TNfQgNfg+/DlVi3laCFZ6PwJUzRp3kiB/ZcSiufWpaN5lBhwxregwbbMvFCASNMePlMvuGnaBjJ3s7SVrp/H1D0/oPqo1chGrcE6UtCW8lE8pBCOilU4rg3Rq8ZwLbX7i2AX6AHF/BimJ3MfvczDOKiBMS3aamMATIzuHTH1zhykBAmK54csKfgJuDhibzv/IttHlu2Vny0A2GAGdUiUiU0VStsdUnksmvDszzl7zT4klP6k19qgOBHmL97ruWNAAAA)
                    format("woff2");
            }
            :root {
                --ffe-v-icons-size-sm: 20px;
                --ffe-v-icons-size-md: 24px;
                --ffe-v-icons-size-lg: 32px;
                --ffe-v-icons-size-xl: 40px;
            }
            :host {
                --ffe-v-icons-size-sm: 20px;
                --ffe-v-icons-size-md: 24px;
                --ffe-v-icons-size-lg: 32px;
                --ffe-v-icons-size-xl: 40px;
            }
            .ffe-icons {
                background-color: currentColor;
                display: inline-block;
                -webkit-mask-position: top;
                mask-position: top;
                -webkit-mask-repeat: no-repeat;
                mask-repeat: no-repeat;
            }
            .ffe-icons--sm {
                height: var(--ffe-v-icons-size-sm);
                width: var(--ffe-v-icons-size-sm);
            }
            .ffe-icons--md {
                height: var(--ffe-v-icons-size-md);
                width: var(--ffe-v-icons-size-md);
            }
            .ffe-icons--lg {
                height: var(--ffe-v-icons-size-lg);
                width: var(--ffe-v-icons-size-lg);
            }
            .ffe-icons--xl {
                height: var(--ffe-v-icons-size-xl);
                width: var(--ffe-v-icons-size-xl);
            }
            :where(.ffe-icons) {
                color: var(--ffe-color-foreground-emphasis);
            }
            .sb1id-app {
                background-color: #e0e0f0;
                border-radius: 8px 60px 8px 8px;
                flex-direction: column;
                width: 100%;
                max-width: 450px;
                margin: 0 auto;
                display: flex;
                box-shadow: 0 4px 4px rgba(0, 0, 0, 0.25);
            }
            .sb1id-app-content {
                flex-direction: column;
                align-items: center;
                width: 100%;
                padding: 32px;
                display: flex;
            }
            .sb1id-app-content img {
                width: 124px;
                margin-bottom: 16px;
            }
            .sb1id-app-content .external-link {
                margin-top: 8px;
                margin-left: auto;
            }
            .sb1id-app-content form {
                flex-direction: column;
                width: 100%;
                display: flex;
            }
            .sb1id-app-content form .ffe-button-group {
                align-self: center;
                margin-top: 24px;
                margin-bottom: 0;
            }
            .sb1id-app-content form .ffe-button-group .ffe-button {
                margin: 0;
            }
            .sb1id-app-help {
                background-color: #d3d3ea;
                border-bottom-right-radius: 8px;
                border-bottom-left-radius: 8px;
                justify-content: space-between;
                width: 100%;
                padding: 16px;
                display: flex;
            }
            .password-rule-list {
                margin: 0 0 16px;
                padding: 0;
                list-style-position: inside;
                display: block;
            }
            .password-rule-list > li {
                margin-bottom: 16px;
            }
            .password-rule-list > li .ffe-body-paragraph {
                display: inline;
            }
            .password-rule-list > li:last-child {
                margin-bottom: 0;
            }
            #inactive-overlay {
                z-index: 100;
                background: rgba(0, 0, 0, 0.85);
                display: none;
                position: absolute;
                top: 0;
                bottom: 0;
                left: 0;
                right: 0;
            }
            #inactive-overlay .inactive-overlay-content {
                text-align: center;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                height: 100%;
                font-size: large;
                display: flex;
            }
            #inactive-overlay .inactive-overlay-content .ffe-body-paragraph {
                color: #fff;
            }
            #maintenance-messages {
                width: 100%;
                max-width: 450px;
                margin-bottom: 16px;
                margin-left: auto;
                margin-right: auto;
            }
            #maintenance-messages .maintenance-message {
                margin-bottom: 8px;
            }
            .background-wave {
                z-index: -1000;
                width: 100%;
                height: 100%;
                position: fixed;
                top: 0;
            }
            @media (max-width: 480px) {
                .background-wave {
                    display: none;
                }
            }
            .background-wave-top {
                background-color: #005aa4;
                height: 35vh;
                margin-bottom: -5px;
            }
            .background-wave-cat {
                width: 187px;
                position: absolute;
                left: calc(50vw - 560px);
            }
            @media (max-height: 570px) {
                .background-wave-cat {
                    display: none;
                }
            }
            @media (max-width: 768px) {
                .background-wave-cat {
                    display: none;
                }
            }
            @media (min-width: 768px) and (max-width: 1024px) {
                .background-wave-cat {
                    width: 127px;
                    top: 75px;
                    left: calc(70vw - 560px);
                }
            }
            @media (min-width: 1024px) and (max-width: 1280px) {
                .background-wave-cat {
                    top: 75px;
                    left: calc(60vw - 560px);
                }
            }
            @media (min-width: 1280px) and (max-width: 1860px) {
                .background-wave-cat {
                    top: 180px;
                    left: calc(50vw - 560px);
                }
            }
            @media (min-width: 1860px) and (max-width: 3840px) {
                .background-wave-cat {
                    top: 190px;
                    left: calc(50vw - 560px);
                }
            }
            @media (min-width: 3840px) {
                .background-wave-cat {
                    display: none;
                }
            }
            .background-wave-sb1-logo {
                width: 162px;
                position: absolute;
                top: -90px;
                left: 80vw;
            }
            @media (max-height: 570px) {
                .background-wave-sb1-logo {
                    display: none;
                }
            }
            @media (max-width: 768px) {
                .background-wave-sb1-logo {
                    display: none;
                }
            }
            @media (min-width: 768px) and (max-width: 1024px) {
                .background-wave-sb1-logo {
                    width: 112px;
                    top: -100px;
                }
            }
            @media (min-width: 1024px) and (max-width: 1280px) {
                .background-wave-sb1-logo {
                    top: -80px;
                }
            }
            @media (min-width: 1280px) and (max-width: 1860px) {
                .background-wave-sb1-logo {
                    left: 70vw;
                }
            }
            @media (min-width: 3840px) {
                .background-wave-sb1-logo {
                    display: none;
                }
            }
            .background-wave-cloud-1 {
                width: 147px;
                position: absolute;
                top: -25vh;
                left: 20vw;
            }
            @media (max-height: 570px) {
                .background-wave-cloud-1 {
                    display: none;
                }
            }
            @media (min-width: 480px) and (max-width: 768px) {
                .background-wave-cloud-1 {
                    width: 83px;
                }
            }
            @media (min-width: 768px) and (max-width: 1024px) {
                .background-wave-cloud-1 {
                    width: 83px;
                }
            }
            .background-wave-cloud-2 {
                width: 147px;
                position: absolute;
                top: -30vh;
                left: 70vw;
            }
            @media (max-height: 570px) {
                .background-wave-cloud-2 {
                    display: none;
                }
            }
            @media (min-width: 480px) and (max-width: 768px) {
                .background-wave-cloud-2 {
                    width: 83px;
                }
            }
            @media (min-width: 768px) and (max-width: 1024px) {
                .background-wave-cloud-2 {
                    width: 83px;
                }
            }
            .background-wave .ffe-wave {
                width: 100%;
                height: 100%;
                top: 0;
            }
            .background-wave .ffe-wave .ffe-wave__wave {
                background-color: #005aa4;
                height: 100%;
                -webkit-mask-position: 107rem bottom;
                mask-position: 107rem bottom;
                -webkit-mask-size: 680px;
                mask-size: 680px;
            }
            @media (min-width: 768px) and (max-width: 1024px) {
                .background-wave .ffe-wave .ffe-wave__wave {
                    -webkit-mask-position: 123rem bottom;
                    mask-position: 123rem bottom;
                    -webkit-mask-size: 1212px;
                    mask-size: 1212px;
                }
            }
            @media (min-width: 1024px) and (max-width: 1280px) {
                .background-wave .ffe-wave .ffe-wave__wave {
                    -webkit-mask-position: 100rem bottom;
                    mask-position: 100rem bottom;
                    -webkit-mask-size: 2300px;
                    mask-size: 2300px;
                }
            }
            @media (min-width: 1280px) {
                .background-wave .ffe-wave .ffe-wave__wave {
                    -webkit-mask-position: 80rem bottom;
                    mask-position: 80rem bottom;
                    -webkit-mask-size: 2100px;
                    mask-size: 2100px;
                }
            }
            @media (min-width: 1860px) {
                .background-wave .ffe-wave .ffe-wave__wave {
                    -webkit-mask-position: 100rem bottom;
                    mask-position: 100rem bottom;
                    -webkit-mask-size: 2300px;
                    mask-size: 2300px;
                }
            }
            @media (prefers-color-scheme: dark) {
                html body.native {
                    background-color: #020a0a;
                }
                html body.native .application-container .sb1id-app {
                    background-color: #020a0a;
                    border: 2px solid #4d8cbf;
                }
                html body.native .application-container .sb1id-app-help {
                    background-color: #020a0a;
                }
            }
            @media (prefers-color-scheme: dark) and (max-width: 480px) {
                html body.native .application-container .sb1id-app {
                    border: 0;
                }
            }
            @media (max-width: 480px) {
                html body {
                    background-color: #e0e0f0;
                }
                html body .application-container {
                    justify-content: start;
                }
                html body .application-container .sb1id-app {
                    box-shadow: none;
                    border: 0;
                    border-radius: 0;
                    max-width: none;
                }
                html body .application-container .sb1id-app-help {
                    background-color: #e0e0f0;
                }
            }
            .ffe-input-field--invalid {
                background-color: var(--ffe-color-surface-primary-default);
            }
            :where(input).ffe-input-field[aria-invalid="true"] {
                background-color: var(--ffe-color-surface-primary-default);
            }
            html {
                height: 100%;
            }
            body {
                background-color: #fdf8f5;
                height: 100%;
                margin: 0;
            }
            .container {
                height: 100%;
            }
            .application-container {
                flex-direction: column;
                justify-content: center;
                min-height: 100%;
                display: flex;
            }
            .top-level-message {
                max-width: 600px;
                margin-left: auto;
                margin-right: auto;
            }
        </style>

        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="_csrf" content="wYq53bdq0pZqEo_IhdZLsPh2dQXNE8eXhR5nX0muSx4" />
        <meta name="_csrf_header" content="X-CSRFToken" />
        <style id="savepage-cssvariables">
            :root {
            }
        </style>
        <script id="savepage-shadowloader" type="text/javascript">
            "use strict";
            window.addEventListener(
                "DOMContentLoaded",
                function (event) {
                    savepage_ShadowLoader(5);
                },
                false
            );
            function savepage_ShadowLoader(c) {
                createShadowDOMs(0, document.documentElement);
                function createShadowDOMs(a, b) {
                    var i;
                    if (b.localName == "iframe" || b.localName == "frame") {
                        if (a < c) {
                            try {
                                if (b.contentDocument.documentElement != null) {
                                    createShadowDOMs(a + 1, b.contentDocument.documentElement);
                                }
                            } catch (e) {}
                        }
                    } else {
                        if (
                            b.children.length >= 1 &&
                            b.children[0].localName == "template" &&
                            b.children[0].hasAttribute("data-savepage-shadowroot")
                        ) {
                            b.attachShadow({ mode: "open" }).appendChild(b.children[0].content);
                            b.removeChild(b.children[0]);
                            for (i = 0; i < b.shadowRoot.children.length; i++)
                                if (b.shadowRoot.children[i] != null) createShadowDOMs(a, b.shadowRoot.children[i]);
                        }
                        for (i = 0; i < b.children.length; i++)
                            if (b.children[i] != null) createShadowDOMs(a, b.children[i]);
                    }
                }
            }
        </script>
        <meta
            name="savepage-url"
            content="https://login.sparebank1.no/utenbankid?app=nettbank-pm&goto=https://www.sparebank1.no/bank/nettbank-privat/avtale/velg-avtale&onCancel=https://www.sparebank1.no/nb/bank/privat/innlogging.html&lang=nb"
        />
        <meta name="savepage-title" content="Innlogging - Uten BankID" />
        <meta name="savepage-pubdate" content="Unknown" />
        <meta
            name="savepage-from"
            content="https://login.sparebank1.no/utenbankid?app=nettbank-pm&goto=https://www.sparebank1.no/bank/nettbank-privat/avtale/velg-avtale&onCancel=https://www.sparebank1.no/nb/bank/privat/innlogging.html&lang=nb"
        />
        <meta name="savepage-date" content="Sun Oct 18 2026 21:29:08 GMT+0100 (British Summer Time)" />
        <meta
            name="savepage-state"
            content="Standard Items; Retain cross-origin frames; Merge CSS images; Remove unsaved URLs; Load lazy images in existing content; Max frame depth = 5; Max resource size = 50MB; Max resource time = 10s;"
        />
        <meta name="savepage-version" content="33.9" />
        <meta name="savepage-comments" content="" />
    </head>
    <body
        __processed_64d98d06-5349-4b0f-98ab-194ef068333c__="true"
        bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJlbmFibGVkIiwiRkFDRUJPT0siOiJlbmFibGVkIiwiVFdJVFRFUiI6ImVuYWJsZWQiLCJSRURESVQiOiJlbmFibGVkIiwiUElOVEVSRVNUIjoiZW5hYmxlZCIsIklOU1RBR1JBTSI6ImVuYWJsZWQiLCJUSUtUT0siOiJlbmFibGVkIiwiTElOS0VESU4iOiJlbmFibGVkIiwiQ09ORklHIjoiZGlzYWJsZWQifSwidmVyc2lvbiI6IjIuMy4wIiwic2NvcmUiOjIwMzAwMH1d"
    >
        <div id="sb1id" class="container" bis_skin_checked="1">
            <div class="application-container" bis_skin_checked="1">
                <div id="inactive-overlay" bis_skin_checked="1">
                    <div class="inactive-overlay-content" bis_skin_checked="1">
                        <div bis_skin_checked="1">
                            <p class="ffe-body-paragraph">Sesjonen din har utløpt.</p>
                            <p class="ffe-body-paragraph">Trykk OK for å starte innlogging på nytt</p>
                        </div>
                        <div bis_skin_checked="1">
                            <button
                                aria-busy="false"
                                aria-disabled="false"
                                class="ffe-button ffe-button--primary ffe-button--md"
                            >
                                <span class="ffe-button__label">OK</span>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="sb1id-app" bis_skin_checked="1">
                    <div class="sb1id-app-content" bis_skin_checked="1">
                        <img
                            alt=""
                            data-savepage-src=""
                            src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjgyIiBoZWlnaHQ9Ijc5IiB2aWV3Qm94PSIwIDAgMjgyIDc5IiBmaWxsPSJub25lIgogIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiAgPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0yNy44NTgxIDU1LjYxNUMyMi43MjkxIDU1LjYxNSAxOC42NjUxIDU0LjQzMiAxNy45MTUxIDU0LjE5NUMxNy41MjAxIDU0LjAzNyAxNy4zMjMxIDUzLjcyMiAxNy4zMjMxIDUzLjM2N1Y1My4xN0wxNy44MzYxIDUwLjU2NUMxNy45MTUxIDUwLjE3MSAxOC4xOTExIDUwLjA1MyAxOC41MDcxIDUwLjA1M0MxOC41ODYxIDUwLjA1MyAxOC42NjUxIDUwLjA1MyAxOC43ODMxIDUwLjA5MkMxOS42MTIxIDUwLjI1IDIzLjYzNjEgNTEuMzk0IDI3LjQyNDEgNTEuMzk0QzMwLjY1OTEgNTEuMzk0IDMzLjUzOTEgNTAuNDQ3IDMzLjUzOTEgNDcuMDk0QzMzLjUzOTEgNDMuNyAzMC41ODExIDQzLjM0NiAyNi43NTMxIDQyLjc5M0MyMi40OTIxIDQyLjE2MSAxNy4wMDgxIDQxLjAxNyAxNy4wMDgxIDM0LjMwOUMxNy4wMDgxIDI3LjQwNSAyMi4xMzcxIDI1LjU5IDI4LjIxMzEgMjUuNTlDMzIuODMwMSAyNS41OSAzNi42NTcxIDI2LjY5NSAzNy41MjQxIDI2LjkzMUMzNy45OTgxIDI3LjA1IDM4LjIzNTEgMjcuMzY2IDM4LjIzNTEgMjcuNzZWMjcuOTU3TDM3LjY4MzEgMzAuNTIyQzM3LjY0MzEgMzAuNzk4IDM3LjM2NzEgMzEuMDc0IDM3LjA1MTEgMzEuMDc0QzM3LjAxMjEgMzEuMDc0IDM2Ljk3MjEgMzEuMDM1IDM2LjkzMzEgMzEuMDM1QzM1LjAzOTEgMzAuNjQgMzIuMTE5MSAyOS44NTEgMjguNjQ3MSAyOS44NTFDMjUuNzI3MSAyOS44NTEgMjIuNjUwMSAzMC40MDQgMjIuNjUwMSAzMy43MThDMjIuNjUwMSAzNi45OTMgMjUuOTY0MSAzNy40NjYgMjkuNDc2MSAzNy45NzlDMzQuMDkyMSAzOC42ODkgMzkuMzM5MSAzOS4zNiAzOS4zMzkxIDQ2LjY5OUMzOS4zMzkxIDUzLjYwMyAzMy43MzcxIDU1LjYxNSAyNy44NTgxIDU1LjYxNVoiIGZpbGw9IiMwMDI3NzYiLz4KICA8cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTc2LjM3MjEgNDUuMTIxTDcxLjQ3OTEgNDUuOTFDNjkuODYxMSA0Ni4xNDYgNjguMzYyMSA0Ni4zODMgNjguMzYyMSA0OC45NDdDNjguMzYyMSA1Mi4wMjUgNzAuODQ4MSA1Mi4yNjIgNzIuNzQyMSA1Mi4yNjJDNzQuMjgwMSA1Mi4yNjIgNzUuNTQzMSA1MS45ODYgNzYuMzcyMSA1MS43MDlWNDUuMTIxWk03Ny45ODkxIDU1LjE0MkM3Ni42MDgxIDU1LjQ1OCA3NC43MTQxIDU1LjY5NCA3Mi41MDUxIDU1LjY5NEM2OC4yNDQxIDU1LjY5NCA2Mi45OTYxIDU1LjI2MSA2Mi45OTYxIDQ4Ljk4N0M2Mi45OTYxIDQzLjg5NyA2Ni4xOTIxIDQzLjM0NiA2OS4zNDkxIDQyLjgzMkw3Ni4zNzIxIDQxLjY4N1Y0MC40MjVDNzYuMzcyMSAzOS4zMiA3Ni4yNTMxIDM4LjUzMSA3NS4yNjcxIDM4LjA5N0M3NC42MzUxIDM3LjgyMSA3My42ODgxIDM3LjcwMyA3Mi4yNjgxIDM3LjcwM0M2OS41ODUxIDM3LjcwMyA2Ni42NjUxIDM4LjQ5MiA2NS40ODIxIDM4LjgwN0M2NS4zNjMxIDM4LjgwNyA2NS4yODUxIDM4Ljg0NyA2NS4yMDYxIDM4Ljg0N0M2NS4wMDgxIDM4Ljg0NyA2NC44MTExIDM4Ljc2OCA2NC43NzExIDM4LjQ5Mkw2NC4yMTkxIDM2LjA0NlYzNS44ODhDNjQuMjE5MSAzNS41MzMgNjQuNDk2MSAzNS4zNzUgNjQuNjkzMSAzNS4yOTZDNjUuNjQwMSAzNC45NDEgNjkuMjY5MSAzMy45NTQgNzMuMjk0MSAzMy45NTRDNzYuMDk1MSAzMy45NTQgNzcuOTg5MSAzNC4zNDkgNzkuMjUyMSAzNS4wNTlDODEuMjY0MSAzNi4xNjQgODEuNjU5MSAzOC4wMTggODEuNjU5MSA0MC4xNDlWNTEuMDM5QzgxLjY1OTEgNTMuOTk4IDgwLjY3MjEgNTQuNTExIDc3Ljk4OTEgNTUuMTQyWiIgZmlsbD0iIzAwMjc3NiIvPgogIDxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNOTUuNzM1IDM4LjAxOEM5My4zMjkgMzguMDE4IDkxLjI3NyAzOC4yNTUgOTAuMTcyIDM4LjUzMVY1NC41OUM5MC4xNzIgNTQuOTQ1IDg5LjkzNSA1NS4xODIgODkuNTgxIDU1LjE4Mkg4NS41NTZDODUuMzE5IDU1LjE4MiA4NC44ODUgNTQuOTQ1IDg0Ljg4NSA1NC41OVYzNy41NDVDODQuODg1IDM2LjAwNiA4NS43OTIgMzUuNTMzIDg3LjY4NiAzNC45OEM4OS40MjIgMzQuNDI4IDkyLjIyNCAzNC4wMzQgOTQuNDczIDMzLjk5NEg5NS4xNDNDOTUuNjk2IDMzLjk5NCA5NS42OTYgMzMuOTk0IDk1Ljk3MiAzNC4xMTJDOTYuMTMgMzQuMTkxIDk2LjMyNyAzNC4zNDkgOTYuMzI3IDM0Ljc0M1YzNy4zMDhDOTYuMzI3IDM3LjcwMyA5Ni4yODggMzguMDE4IDk1LjczNSAzOC4wMThaIiBmaWxsPSIjMDAyNzc2Ii8+CiAgPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xMTAuODIzIDQwLjUxMUMxMTAuMzEgMzguMzQxIDEwOS4xMjcgMzcuNjMgMTA2Ljc5OSAzNy42M0MxMDQuMTU1IDM3LjYzIDEwMy4wNSAzOC40MTkgMTAyLjYxNiA0MC4zOTJDMTAyLjM0IDQxLjQ5NyAxMDIuMzQgNDIuNjQyIDEwMi4zMDEgNDMuOTQzTDExMS4xMzkgNDMuOTAzQzExMS4xMzkgNDIuNjQyIDExMS4wOTkgNDEuNTc2IDExMC44MjMgNDAuNTExWk0xMTYuMzg2IDQ2LjM5QzExNi4zODYgNDYuODIzIDExNi4xNDkgNDcuMjk3IDExNS41NTggNDcuMjk3SDEwMi4zNEMxMDIuMzQgNDkuMTEyIDEwMi44NTMgNTAuMDk5IDEwMy45MTggNTAuOTI3QzEwNC45NDQgNTEuNzU1IDEwNi40NDMgNTIuMTEgMTA4LjU3NCA1Mi4xMUMxMTEuMDIxIDUyLjExIDExMi44NzQgNTEuNTE5IDExNC4wOTggNTEuMTYzQzExNC4xNzcgNTEuMTI0IDExNC4yMTYgNTEuMTI0IDExNC4yOTUgNTEuMTI0QzExNC41MzIgNTEuMTI0IDExNC43MjkgNTEuMjgyIDExNC44NDggNTEuNjc3TDExNS4zNiA1My42ODhDMTE1LjM2IDUzLjcyOCAxMTUuNCA1My44MDggMTE1LjQgNTMuODg2QzExNS40IDU0LjIwMiAxMTUuMjAzIDU0LjM1OSAxMTQuOTI2IDU0LjQ3OEMxMTMuNTg1IDU1LjAzIDExMC45MDIgNTUuNzQgMTA3Ljc4NSA1NS43NEMxMDAuMDUyIDU1Ljc0IDk3LjAxMzkgNTIuNzAyIDk3LjAxMzkgNDQuOTdDOTcuMDEzOSAzNy41NTIgOTkuMDY0OSAzNCAxMDYuNzU5IDM0QzExMC43NDQgMzQgMTEzLjE5IDM1LjAyNiAxMTQuNjExIDM2LjkyQzExNS45NTIgMzguNjk2IDExNi4zODYgNDEuMjIxIDExNi4zODYgNDQuNDk1VjQ2LjM5WiIgZmlsbD0iIzAwMjc3NiIvPgogIDxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMTU5LjY1MyA0NS4xMjFMMTU0Ljc2MSA0NS45MUMxNTMuMTQzIDQ2LjE0NiAxNTEuNjQ0IDQ2LjM4MyAxNTEuNjQ0IDQ4Ljk0N0MxNTEuNjQ0IDUyLjAyNSAxNTQuMTI5IDUyLjI2MiAxNTYuMDIzIDUyLjI2MkMxNTcuNTYxIDUyLjI2MiAxNTguODI0IDUxLjk4NiAxNTkuNjUzIDUxLjcwOVY0NS4xMjFaTTE2MS4yNyA1NS4xNDJDMTU5Ljg5IDU1LjQ1OCAxNTcuOTk1IDU1LjY5NCAxNTUuNzg2IDU1LjY5NEMxNTEuNTI0IDU1LjY5NCAxNDYuMjc3IDU1LjI2MSAxNDYuMjc3IDQ4Ljk4N0MxNDYuMjc3IDQzLjg5NyAxNDkuNDc0IDQzLjM0NiAxNTIuNjMgNDIuODMyTDE1OS42NTMgNDEuNjg3VjQwLjQyNUMxNTkuNjUzIDM5LjMyIDE1OS41MzQgMzguNTMxIDE1OC41NDggMzguMDk3QzE1Ny45MTcgMzcuODIxIDE1Ni45NyAzNy43MDMgMTU1LjU1IDM3LjcwM0MxNTIuODY2IDM3LjcwMyAxNDkuOTQ2IDM4LjQ5MiAxNDguNzYzIDM4LjgwN0MxNDguNjQ1IDM4LjgwNyAxNDguNTY1IDM4Ljg0NyAxNDguNDg3IDM4Ljg0N0MxNDguMjkgMzguODQ3IDE0OC4wOTMgMzguNzY4IDE0OC4wNTMgMzguNDkyTDE0Ny41MDEgMzYuMDQ2VjM1Ljg4OEMxNDcuNTAxIDM1LjUzMyAxNDcuNzc2IDM1LjM3NSAxNDcuOTc0IDM1LjI5NkMxNDguOTIxIDM0Ljk0MSAxNTIuNTUxIDMzLjk1NCAxNTYuNTc1IDMzLjk1NEMxNTkuMzc2IDMzLjk1NCAxNjEuMjcgMzQuMzQ5IDE2Mi41MzMgMzUuMDU5QzE2NC41NDYgMzYuMTY0IDE2NC45NCAzOC4wMTggMTY0Ljk0IDQwLjE0OVY1MS4wMzlDMTY0Ljk0IDUzLjk5OCAxNjMuOTUzIDU0LjUxMSAxNjEuMjcgNTUuMTQyWiIgZmlsbD0iIzAwMjc3NiIvPgogIDxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMTg2LjA0IDU1LjE4MkgxODEuOTc2QzE4MS42MiA1NS4xODIgMTgxLjM0NSA1NC45NDUgMTgxLjM0NSA1NC41OVY0MC42NjJDMTgxLjM0NSAzOC4zNzMgMTgwLjQ3NyAzNy41ODQgMTc4LjM4NiAzNy41ODRDMTc2LjAxOCAzNy41ODQgMTczLjQ1NCAzOC4yNTUgMTczLjQ1NCAzOC4yNTVWNTQuNTlDMTczLjQ1NCA1NC45NDUgMTczLjIxNyA1NS4xODIgMTcyLjg2MiA1NS4xODJIMTY4LjgzN0MxNjguNDQyIDU1LjE4MiAxNjguMTY3IDU0Ljk0NSAxNjguMTY3IDU0LjU5VjM3LjU4NEMxNjguMTY3IDM2LjA4NSAxNjguOTE2IDM1LjU3MiAxNzEuMTI2IDM0Ljk4QzE3My4xMzggMzQuNDI4IDE3Ni40NTIgMzMuOTU0IDE3OC45NzcgMzMuOTU0QzE4My45MDkgMzMuOTU0IDE4Ni42MzIgMzUuMjE3IDE4Ni42MzIgMzkuOTUxVjU0LjU5QzE4Ni42MzIgNTQuOTQ1IDE4Ni4zOTUgNTUuMTgyIDE4Ni4wNCA1NS4xODJaIiBmaWxsPSIjMDAyNzc2Ii8+CiAgPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0yMDguOTE5IDU0LjgyNkMyMDguOTE5IDU0Ljk4NCAyMDguNzYyIDU1LjE4MiAyMDguNTI0IDU1LjE4MkgyMDMuMjM3QzIwMy4wNCA1NS4xODIgMjAyLjg0MyA1NS4xODIgMjAyLjY0NSA1NC45NDVMMTk2LjUzIDQ2LjYxOUgxOTUuMTg5VjU0LjU5QzE5NS4xODkgNTQuOTQ1IDE5NC45OTEgNTUuMTgyIDE5NC41OTcgNTUuMTgySDE5MC41MzNDMTkwLjE3OSA1NS4xODIgMTg5LjkwMSA1NC45NDUgMTg5LjkwMSA1NC41OVYyNy4wMUMxODkuOTAxIDI2LjUzNyAxOTAuMDk5IDI2LjMgMTkwLjU3MyAyNi4xODJMMTk0LjQzOSAyNS41MTFIMTk0LjU5N0MxOTQuOTUyIDI1LjUxMSAxOTUuMTg5IDI1Ljc0OCAxOTUuMTg5IDI2LjE4MlY0My4wNjhIMTk2LjUzTDIwMi43NjUgMzQuNzQzQzIwMi45MjIgMzQuNTA3IDIwMy4wOCAzNC40NjggMjAzLjI3NyAzNC40NjhMMjA4LjA5MSAzNC41ODZDMjA4LjM2NyAzNC41ODYgMjA4LjQ4NSAzNC43ODMgMjA4LjQ4NSAzNC45NDFDMjA4LjQ4NSAzNS4wMiAyMDguNDQ2IDM1LjA1OSAyMDguNDA2IDM1LjEzOEwyMDAuOTQ5IDQ0LjUyOUwyMDguODQxIDU0LjYyOUMyMDguODggNTQuNjY5IDIwOC45MTkgNTQuNzQ4IDIwOC45MTkgNTQuODI2WiIgZmlsbD0iIzAwMjc3NiIvPgogIDxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNNTEuMjMxIDUyLjA2NEM0OS4xMDEgNTIuMDY0IDQ3LjQ4MyA1MS41OTIgNDcuNDgzIDUxLjU5MlYzOC4yOTVDNDcuNDgzIDM4LjI5NSA0OS44MTEgMzcuNjY0IDUxLjYyNSAzNy42NjRDNTQuNjI0IDM3LjY2NCA1NS45MjYgMzguMzM0IDU1LjkyNiA0NC43MjZDNTUuOTI2IDUwLjcyMyA1NC44MjEgNTIuMDY0IDUxLjIzMSA1Mi4wNjRaTTUyLjczIDMzLjk1NEM1MC4wODcgMzMuOTU0IDQ3LjA0OSAzNC4zODkgNDQuNjgyIDM1LjIxN0M0Mi45MDYgMzUuNzY5IDQyLjE5NiAzNi4zNjEgNDIuMTk2IDM4LjQxM1Y2Mi44MzZDNDIuMTk2IDYzLjIzIDQyLjUwNSA2My41NTMgNDMuMDc0IDYzLjQ1QzQzLjY0MiA2My4zNDggNDYuODEyIDYyLjc2MiA0Ni44MTIgNjIuNzYyQzQ3LjI4NiA2Mi42ODMgNDcuNDgzIDYyLjQ0NiA0Ny40ODMgNjEuOTczVjU1LjA5NEM0OC44ODMgNTUuNDM1IDUwLjY0OSA1NS42OTQgNTIuNjEyIDU1LjY5NEM1OS45NTEgNTUuNjk0IDYxLjMzMSA1MS4wNzggNjEuMzMxIDQ0Ljg0NEM2MS4zMzEgMzguNTcxIDYwLjM0NSAzMy45NTQgNTIuNzMgMzMuOTU0WiIgZmlsbD0iIzAwMjc3NiIvPgogIDxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNMTMzLjAxNiA0Mi4zNThMMTI1LjU5OSA0Mi4xMjJWNTEuMTE3SDEzMy4wMTZDMTM3LjAwMSA1MS4xMTcgMTM4LjMwMyA0OS4zODIgMTM4LjMwMyA0Ni45NzRDMTM4LjMwMyA0My43NCAxMzcuMjM4IDQyLjQ3NiAxMzMuMDE2IDQyLjM1OFpNMTMzLjIxMyAzMC4wODhIMTI1LjU5OVYzOC41MzFMMTMyLjkzOCAzOC4yMTZDMTM1LjkzNiAzOC4wOTcgMTM3LjQ3NSAzNy4wMzIgMTM3LjQ3NSAzNC4wMzRDMTM3LjQ3NSAzMS4yNzEgMTM2LjEzMyAzMC4wODggMTMzLjIxMyAzMC4wODhaTTEzMy43MjcgNTUuMTgySDEyMC41ODhDMTIwLjIzMiA1NS4xODIgMTE5LjkxNyA1NC45MDUgMTE5LjkxNyA1NC41NTFWMjYuNjU1QzExOS45MTcgMjYuMyAxMjAuMjMyIDI2LjAyNCAxMjAuNTg4IDI2LjAyNEgxMzMuNzY2QzE0MC40MzggMjYuMDI0IDE0My4xNTYgMjguNjQgMTQzLjE1NiAzMy4zNzhDMTQzLjE1NiAzNy41NiAxNDAuODMzIDM5LjA1NyAxMzcuMjM4IDQwLjA4NkMxNDEuMjI5IDQwLjc0NSAxNDQuMTQzIDQyLjkxMSAxNDQuMTQzIDQ3LjU2NkMxNDQuMTQzIDUyLjg1MyAxNDAuNDM0IDU1LjE4MiAxMzMuNzI3IDU1LjE4MloiIGZpbGw9IiMwMDI3NzYiLz4KICA8cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTI0Mi41MzQgMTIuMTMxQzIzOS42MDIgMTIuMTMxIDIzNi43NzcgMTIuNTg5IDIzNC4xMjMgMTMuNDMxQzI0NS4yOTIgMTEuMDA4IDI1Ni4zNjMgMTUuNjA5IDI2MC4zNTEgMjUuMDMzQzI2NC45NiAzNS45MjUgMjU4LjM2MiA0OS4xMjkgMjQ1LjYxMyA1NC41MjRDMjM0LjE3OCA1OS4zNjMgMjIxLjY4MiA1Ni4yNzEgMjE1LjkwMiA0Ny43MjJDMjE5LjI4MyA1OS4yMzggMjI5LjkyMyA2Ny42NSAyNDIuNTM0IDY3LjY1QzI1Ny44NjUgNjcuNjUgMjcwLjI5NCA1NS4yMjIgMjcwLjI5NCAzOS44OUMyNzAuMjk0IDI0LjU1OSAyNTcuODY1IDEyLjEzMSAyNDIuNTM0IDEyLjEzMVoiIGZpbGw9IiNFNjAwMDAiLz4KICA8cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTI0NS42MTMgNTQuNTI0QzI1OC4zNjIgNDkuMTI5IDI2NC45NiAzNS45MjUgMjYwLjM1MSAyNS4wMzNDMjU2LjM2MyAxNS42MDkgMjQ1LjI5MiAxMS4wMDggMjM0LjEyMyAxMy40MzFDMjIyLjkwNCAxNi45OTUgMjE0Ljc3NSAyNy40OTIgMjE0Ljc3NSAzOS44OUMyMTQuNzc1IDQyLjYxMSAyMTUuMTczIDQ1LjIzNyAyMTUuOTAyIDQ3LjcyMkMyMjEuNjgyIDU2LjI3MSAyMzQuMTc4IDU5LjM2MyAyNDUuNjEzIDU0LjUyNFoiIGZpbGw9IiNBRjAwMDAiLz4KICA8cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTI0OS42NSA1Mi40MzZWMjMuOTMyQzI0OS42NSAyMy4zNjYgMjQ5LjE4OCAyMi45MDUgMjQ4LjYyMSAyMi45MDVIMjQyLjE2N0MyNDEuNzA2IDIyLjkwNSAyNDEuNDQ3IDIzLjAwOCAyNDEuMDM1IDIzLjE2MkwyMzIuNzA3IDI3LjQ0OUMyMzIuMTk0IDI3LjY1NiAyMzEuOTg4IDI3Ljk2MyAyMzEuOTg4IDI4LjQ3OFYzMy4xNDlDMjMxLjk4OCAzMy42OTggMjMyLjQzNCAzNC4xNDEgMjMyLjk4MSAzNC4xNDFIMjM4LjMxMVY1Ni41NUMyNDAuNzQ0IDU2LjIxMiAyNDMuMjAyIDU1LjU0NCAyNDUuNjEzIDU0LjUyNEMyNDcuMDM4IDUzLjkyMSAyNDguMzg2IDUzLjIyIDI0OS42NSA1Mi40MzZaIiBmaWxsPSJ3aGl0ZSIvPgo8L3N2Zz4K"
/>
                        <div class="logout-success" style="text-align: center; padding: 32px 16px; animation: fadeInUp 0.7s cubic-bezier(0.16, 1, 0.3, 1);">
                            <div class="success-icon-wrapper" style="position: relative; display: inline-flex; margin-bottom: 24px;">
                                <div class="success-ring" style="width: 80px; height: 80px; border: 3px solid #22c55e; border-radius: 50%; animation: ringExpand 1.2s cubic-bezier(0.16, 1, 0.3, 1) forwards; opacity: 0;"></div>
                                <div class="success-checkmark" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%) scale(0); width: 40px; height: 40px; animation: checkmarkPop 0.6s cubic-bezier(0.16, 1, 0.3, 1) 0.3s forwards;">
                                    <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="20" cy="20" r="18" stroke="#22c55e" stroke-width="3"/>
                                        <path d="M11 20L18 27L29 13" stroke="#22c55e" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </div>
                                <div class="success-sparkles" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none;">
                                    <span class="sparkle" style="--delay: 0.4s; --angle: 0deg;"></span>
                                    <span class="sparkle" style="--delay: 0.5s; --angle: 90deg;"></span>
                                    <span class="sparkle" style="--delay: 0.6s; --angle: 180deg;"></span>
                                    <span class="sparkle" style="--delay: 0.7s; --angle: 270deg;"></span>
                                </div>
                            </div>
                            <h2 style="font-size: var(--ffe-fontsize-h3); font-weight: 600; color: var(--ffe-color-foreground-emphasis); margin: 0 0 8px; animation: fadeInUp 0.5s cubic-bezier(0.16, 1, 0.3, 1) 0.1s both;">Du er logget ut</h2>
                            <p style="font-size: var(--ffe-fontsize-body-text); color: var(--ffe-color-foreground-subtle); margin: 0 0 24px; max-width: 320px; margin-left: auto; margin-right: auto; animation: fadeInUp 0.5s cubic-bezier(0.16, 1, 0.3, 1) 0.2s both;">Sesjonen din er avsluttet for din sikkerhet. Du kan logge inn igjen når du vil.</p>
                            <a href="login.php" class="ffe-button ffe-button--primary ffe-button--md" style="display: inline-flex; animation: fadeInUp 0.5s cubic-bezier(0.16, 1, 0.3, 1) 0.3s both; padding: 12px 32px;">
                                <span class="ffe-button__label">Logg inn igjen</span>
                            </a>
                        </div>
                        <style>
                            @keyframes fadeInUp {
                                from { opacity: 0; transform: translateY(16px); }
                                to { opacity: 1; transform: translateY(0); }
                            }
                            @keyframes ringExpand {
                                0% { transform: scale(0.3); opacity: 0; border-width: 4px; }
                                50% { opacity: 1; border-width: 3px; }
                                100% { transform: scale(1); opacity: 0.15; border-width: 1px; }
                            }
                            @keyframes checkmarkPop {
                                0% { transform: translate(-50%, -50%) scale(0); opacity: 0; }
                                50% { transform: translate(-50%, -50%) scale(1.2); }
                                100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
                            }
                            @keyframes sparkle {
                                0% { transform: translate(-50%, -50%) rotate(var(--angle)) translateY(0) scale(0); opacity: 0; }
                                50% { opacity: 1; }
                                100% { transform: translate(-50%, -50%) rotate(var(--angle)) translateY(-30px) scale(1); opacity: 0; }
                            }
                            .sparkle {
                                position: absolute;
                                top: 50%;
                                left: 50%;
                                width: 8px;
                                height: 8px;
                                background: #22c55e;
                                border-radius: 50%;
                                animation: sparkle 0.8s ease-out var(--delay) forwards;
                                opacity: 0;
                            }
                            .sparkle::before {
                                content: '';
                                position: absolute;
                                top: 50%;
                                left: 50%;
                                transform: translate(-50%, -50%) rotate(45deg);
                                width: 8px;
                                height: 8px;
                                background: #22c55e;
                                border-radius: 2px;
                            }
                            .success-ring { will-change: transform, opacity; }
                            .success-checkmark { will-change: transform, opacity; }
                            .sparkle { will-change: transform, opacity; }
                        </style>
                    </div>
                    <div class="sb1id-app-help" bis_skin_checked="1">
                        <div class="help-contact" style="display: flex; align-items: center; gap: 12px; padding: 16px 0; color: var(--ffe-color-foreground-subtle); font-size: var(--ffe-fontsize-small-text);">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0; color: var(--ffe-color-primary-default);">
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                            </svg>
                            <span>Ring oss på <strong style="color: var(--ffe-color-foreground-emphasis);">21 50 00 00</strong> for hjelp med innlogging</span>
                        </div>
                    </div>
                </div>
                <div class="background-wave" bis_skin_checked="1">
                    <div class="background-wave-top" bis_skin_checked="1"></div>
                    <div class="ffe-wave" bis_skin_checked="1">
                        <div class="ffe-wave__content" bis_skin_checked="1">
                            <svg
                                class="background-wave-cat"
                                width="217"
                                height="151"
                                viewBox="0 0 217 151"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <g clip-path="url(#clip0_3459_11868)">
                                    <path
                                        d="M158.671 90.67C162.763 95.7683 164.21 108.414 166.355 114.312C163.012 127.308 153.432 138.154 149.59 138.354C145.997 138.554 143.153 135.405 142.954 131.756C142.754 127.708 146.147 123.559 149.34 120.31C147.794 115.962 145.249 104.315 143.203 101.067"
                                        fill="#002776"
                                    ></path>
                                    <path
                                        d="M74.5455 62.5293C58.0297 72.626 64.5163 104.415 50.4953 110.763C50.0463 113.512 49.8467 116.212 49.8467 118.861C49.8467 126.108 51.3436 133.106 53.1398 140.204C57.4808 142.303 62.6701 144.002 67.2107 144.002C68.6577 144.002 70.0548 143.802 71.3521 143.403C71.402 142.953 71.4519 142.503 71.4519 142.103C71.4519 136.655 67.3604 138.004 67.3604 129.157C67.3604 124.909 68.3583 120.56 69.2065 116.561C92.5082 109.164 99.0946 90.9699 99.0946 84.3221C99.0946 84.2721 99.0946 84.2221 99.0946 84.1222"
                                        fill="#002776"
                                    ></path>
                                    <path
                                        d="M148.941 35.1384C143.852 42.336 136.068 51.333 126.887 51.333C116.908 51.333 108.924 42.5859 97.8471 43.1857C81.531 44.1354 71.9009 52.4326 60.1253 69.2771C48.3498 86.1215 32.6823 94.0189 22.8526 82.0228C16.2164 73.9755 16.3162 61.9795 19.7092 51.1831C18.6114 50.8832 17.4638 50.7832 16.3661 50.7832C10.2288 50.7832 4.7901 54.8818 4.7901 59.3304C4.7901 60.1301 4.98968 60.9798 5.38886 61.7795C6.08741 63.1791 8.23296 62.6792 8.28285 61.1298C8.28285 61.1298 8.28285 61.1298 8.28285 61.0798V61.0298C8.28285 58.9305 5.68823 57.8808 4.19134 59.3803C1.34724 62.1794 0.0499268 66.378 0.0499268 70.7266C0.0499268 77.2244 2.94393 83.9722 7.83379 86.7713C8.03337 86.6213 8.08327 86.5713 8.28285 86.4214C7.83379 84.622 4.24124 79.5237 2.09568 79.5237C0.698582 79.5237 0.449099 81.7729 0.449099 83.0725C0.449099 91.2698 12.2746 100.417 20.9067 100.417C22.5034 100.417 23.9504 100.117 25.1978 99.4671C25.0481 99.3671 24.9483 99.2171 24.7986 99.1172C22.5034 99.2671 17.7632 100.467 17.7632 103.316C17.7632 105.815 21.9545 105.915 24.5491 105.915C34.5284 105.915 46.7531 102.516 51.6429 93.9689C51.5431 93.9189 51.4932 93.8189 51.3935 93.769C49.3477 95.2185 47.3518 98.7673 47.3518 101.766C47.3518 103.366 48.0005 105.565 49.7968 105.565C60.1752 105.565 72.6494 86.9212 75.2939 74.9752C75.2939 74.9752 76.0922 93.9689 83.4769 103.416C88.9655 112.263 99.4937 115.062 109.872 114.412C118.754 113.812 133.922 109.764 134.272 101.516C131.178 102.566 127.336 105.915 127.536 109.114C127.536 109.214 127.536 109.314 127.585 109.414C127.585 109.414 127.536 112.213 131.328 112.063C144.001 111.613 164.559 96.518 164.06 85.4717C162.264 87.1711 158.821 94.3188 159.07 98.4674C159.22 100.567 160.268 101.266 161.565 101.216C167.253 100.867 177.282 87.1211 177.831 65.4283"
                                        fill="#002776"
                                    ></path>
                                    <path
                                        d="M70.6535 87.521C71.0028 86.8712 71.3022 86.2214 71.6515 85.5717C71.9508 84.9219 72.35 84.2721 72.6494 83.6223C72.9987 82.9225 73.298 82.2728 73.5475 81.623L73.9467 80.5733C74.0465 80.2234 74.1463 79.9235 74.296 79.5736C74.4457 79.0738 74.6452 78.624 74.745 78.1241L75.1442 76.7246L75.4436 75.325C75.4935 75.1751 75.3937 75.0252 75.244 74.9752C75.0943 74.9252 74.9945 75.0751 74.9446 75.2251L74.5454 76.5746L74.0964 77.9242C73.9467 78.374 73.7471 78.8239 73.5974 79.3237C73.4477 79.6236 73.3479 79.9735 73.1982 80.2734C73.0486 80.6233 72.8989 80.9732 72.7492 81.3231C72.4997 81.9229 72.2003 82.5727 71.9009 83.3224C71.6515 83.9722 71.3022 84.672 71.0028 85.3217C70.6535 85.9715 70.3042 86.6213 69.955 87.2211L69.5558 87.8709C68.9071 89.0705 68.1587 90.2701 67.3604 91.3697C66.9113 91.9695 66.5121 92.5693 66.063 93.1691C65.614 93.7689 65.1649 94.3687 64.7158 94.9685C64.3666 95.4184 64.0672 95.8682 63.7179 96.3181L62.8697 97.3678C62.5703 97.7176 62.2709 98.0175 61.9715 98.3674C61.7719 98.6173 61.5724 98.8173 61.3229 99.0672L60.6243 99.717C60.0755 100.267 59.4268 100.817 58.828 101.366C58.7283 101.466 58.6784 101.666 58.7782 101.766C58.8779 101.866 59.0276 101.866 59.1773 101.766C59.826 101.266 60.4746 100.717 61.0235 100.167L61.722 99.517L62.4206 98.8173C62.72 98.5174 63.0693 98.1675 63.3686 97.8676L64.2668 96.8679C64.6659 96.4681 65.0152 96.0182 65.3645 95.6183C65.8635 95.0685 66.3125 94.4187 66.7616 93.8189C67.2107 93.2191 67.6098 92.5693 68.009 91.9695C68.7575 90.8199 69.456 89.5703 70.2045 88.3707L70.6535 87.521Z"
                                        fill="#005AA4"
                                    ></path>
                                    <path
                                        d="M161.914 93.519C162.663 92.2694 163.361 90.9699 163.81 89.5204C163.91 89.1705 164.06 88.8206 164.11 88.4207C164.21 88.0708 164.309 87.671 164.309 87.3211L164.359 87.0212C164.359 86.8712 164.409 86.7213 164.409 86.5713C164.409 86.2714 164.409 85.9715 164.409 85.6716V84.7719V84.672V84.622C164.409 84.572 164.409 84.622 164.409 84.622L164.259 84.7719L163.96 85.0718C163.711 85.3217 163.511 85.5717 163.311 85.7716C163.212 85.8716 163.112 86.0215 163.012 86.1715L162.763 86.5213C162.513 86.8213 162.363 87.1711 162.164 87.471C161.814 88.1208 161.465 88.7206 161.166 89.3704C160.817 90.0702 160.517 90.7699 160.268 91.4697C160.118 91.8196 160.018 92.1195 159.918 92.4694C159.819 92.8193 159.719 93.1192 159.619 93.469C159.32 94.4187 159.07 95.4184 158.97 96.4181C158.871 97.3678 158.771 98.3674 158.97 99.3171C159.07 99.8169 159.27 100.317 159.619 100.717C159.968 101.117 160.467 101.416 160.966 101.466C161.316 101.516 161.615 101.366 161.615 101.216C161.615 101.067 161.365 101.017 161.066 100.967C160.667 100.917 160.268 100.667 160.018 100.367C159.769 100.067 159.619 99.617 159.519 99.2171C159.37 98.3174 159.419 97.4177 159.569 96.4681C159.719 95.5184 159.968 94.5687 160.268 93.669C160.368 93.3691 160.467 93.0192 160.617 92.7193C160.717 92.4194 160.866 92.0695 161.016 91.7696C161.316 91.0698 161.615 90.4201 161.964 89.7703C162.264 89.1705 162.563 88.5707 162.912 87.9709C163.112 87.671 163.262 87.3711 163.461 87.0712C163.511 87.0212 163.561 86.9212 163.611 86.8712L163.661 86.8212V86.7713V86.8712C163.661 86.9212 163.661 86.9212 163.661 86.9712V87.0712L163.611 87.3211C163.611 87.671 163.511 88.0209 163.411 88.3707C163.361 88.7206 163.212 89.0705 163.112 89.3704C162.663 90.72 161.964 92.0195 161.216 93.1691C160.916 93.569 160.667 93.9689 160.367 94.3687C158.821 96.618 156.825 98.6173 154.829 100.417C152.634 102.316 150.189 104.116 147.694 105.715C146.746 106.315 145.798 106.865 144.85 107.414C143.303 108.264 141.756 109.064 140.11 109.714C138.962 110.164 137.764 110.613 136.517 110.963C135.02 111.363 133.423 111.713 131.827 111.863C131.527 111.913 131.278 112.013 131.278 112.163C131.278 112.313 131.527 112.413 131.877 112.363C133.523 112.263 135.17 111.963 136.717 111.513C137.964 111.163 139.161 110.763 140.359 110.313C142.006 109.664 143.652 108.914 145.199 108.114C146.197 107.614 147.145 107.065 148.093 106.465C150.688 104.915 153.132 103.066 155.328 101.067C157.374 99.2171 159.32 97.1178 160.966 94.8686C161.365 94.3687 161.615 93.9189 161.914 93.519Z"
                                        fill="#005AA4"
                                    ></path>
                                    <path
                                        d="M127.935 79.7736C123.644 89.0205 114.163 101.067 114.163 115.512C114.163 116.511 114.313 117.161 114.712 117.161C115.361 117.161 119.103 114.862 118.055 108.714C116.758 110.863 115.66 118.711 115.66 124.959C115.66 127.458 115.91 132.806 118.404 132.806C120.151 132.806 120.75 129.107 120.75 126.958C120.75 126.408 120.799 124.409 120.251 125.309C119.602 126.408 118.953 128.857 118.953 130.807C118.953 140.354 123.544 145.902 127.785 149.501C130.879 150.15 134.072 150.6 137.166 150.6C140.459 150.6 143.602 150.15 146.446 149.001C144.8 144.702 141.008 142.903 137.365 140.503C136.367 136.755 135.918 133.206 135.918 129.757C135.918 110.913 149.091 96.2181 153.631 76.8745"
                                        fill="#002776"
                                    ></path>
                                    <path
                                        d="M137.565 150.95C139.96 150.9 142.405 150.6 144.75 149.9C145.049 149.8 145.349 149.7 145.648 149.6L146.097 149.451L146.796 149.201C146.796 149.201 146.845 149.201 146.845 149.151L146.796 149.051L146.696 148.851L146.546 148.501L146.346 148.001C146.197 147.701 146.047 147.451 145.897 147.151C145.249 146.052 144.401 145.102 143.502 144.302C142.554 143.453 141.556 142.753 140.509 142.103L138.962 141.103L138.213 140.603L137.814 140.354L137.615 140.254C137.615 140.254 137.565 140.254 137.565 140.204L137.365 139.454C137.315 139.154 137.215 138.854 137.166 138.554C137.016 137.954 136.916 137.355 136.816 136.755C136.617 135.555 136.467 134.356 136.367 133.156C135.968 127.958 136.567 123.209 137.664 118.911C138.263 116.511 139.012 114.112 139.86 111.813C140.259 110.763 140.658 109.664 141.107 108.614C141.556 107.564 141.956 106.515 142.455 105.465C143.802 102.416 145.199 99.4671 146.596 96.4181C149.191 90.72 151.685 84.9219 153.282 78.8239C153.581 77.7243 153.681 76.8745 153.532 76.8246C153.382 76.7746 153.083 77.6243 152.783 78.6739C151.186 84.7719 148.642 90.52 145.947 96.2681C144.55 99.2171 143.153 102.166 141.806 105.165C141.307 106.215 140.858 107.264 140.409 108.314C139.96 109.364 139.511 110.463 139.111 111.513C138.213 113.862 137.415 116.262 136.816 118.711C135.719 123.059 135.12 127.908 135.569 133.306C135.669 134.505 135.868 135.705 136.068 136.905C136.168 137.504 136.317 138.104 136.417 138.704L136.617 139.604L136.866 140.603C136.916 140.703 137.116 140.753 137.166 140.803L137.365 140.903L137.764 141.153L138.513 141.653L140.06 142.603C141.057 143.253 142.055 143.952 142.954 144.752C143.852 145.552 144.6 146.452 145.199 147.451C145.349 147.701 145.448 147.951 145.598 148.201L145.748 148.551C145.748 148.601 145.798 148.601 145.748 148.651L145.598 148.701L145.199 148.851C144.899 148.951 144.65 149.051 144.351 149.101C142.055 149.8 139.71 150.05 137.365 150.05C135.719 150.05 134.122 149.95 132.475 149.75C131.328 149.6 130.23 149.451 129.082 149.251L128.234 149.101L127.835 149.001C127.685 148.951 127.785 149.001 127.635 148.901C127.186 148.551 126.787 148.151 126.388 147.751C124.741 146.152 123.294 144.402 122.147 142.403C119.851 138.454 118.953 133.756 119.253 129.357C119.303 128.757 119.452 128.158 119.552 127.608C119.602 127.308 119.702 127.008 119.802 126.758C119.851 126.608 119.901 126.458 119.951 126.358L120.051 126.108C120.051 126.058 120.101 126.058 120.101 126.008C120.151 126.008 120.151 126.058 120.151 126.058V126.508C120.151 126.808 120.151 127.108 120.151 127.408C120.101 128.607 119.901 129.807 119.452 130.907C119.253 131.406 118.903 131.956 118.554 132.106C118.454 132.156 118.355 132.156 118.255 132.156C118.155 132.156 118.005 132.156 117.905 132.106C117.706 132.056 117.506 131.906 117.307 131.706C116.957 131.357 116.708 130.807 116.558 130.257C116.359 129.707 116.259 129.107 116.159 128.507C115.96 127.308 115.91 126.058 115.91 124.809C115.91 122.309 116.059 119.86 116.309 117.361C116.508 115.512 116.758 113.712 117.157 111.913C117.257 111.463 117.357 111.013 117.456 110.563L117.506 110.363C117.506 110.313 117.556 110.263 117.556 110.214C117.556 110.164 117.606 110.114 117.606 110.064C117.606 110.064 117.606 110.114 117.606 110.164C117.606 110.263 117.606 110.363 117.656 110.513C117.656 110.513 117.656 110.513 117.656 110.563V110.713V110.963C117.656 111.163 117.656 111.313 117.606 111.513C117.556 111.863 117.556 112.213 117.456 112.563C117.307 113.262 117.057 113.912 116.708 114.512C116.359 115.112 115.91 115.662 115.361 116.062C115.211 116.162 115.061 116.262 114.962 116.361L114.762 116.461L114.662 116.511H114.612C114.562 116.511 114.512 116.511 114.463 116.461C114.413 116.411 114.363 116.212 114.363 116.062C114.263 115.412 114.363 114.662 114.363 113.912L114.413 112.813C114.413 112.463 114.463 112.113 114.512 111.713L114.612 110.613C114.662 110.263 114.712 109.864 114.762 109.514L115.161 107.364C116.109 103.266 117.656 99.3171 119.452 95.5184C120.6 93.1692 121.897 90.8199 123.194 88.4707C124.492 86.1215 125.839 83.7723 127.086 81.3731C127.585 80.3734 127.835 79.5737 127.735 79.5237C127.635 79.4737 127.136 80.1735 126.637 81.1731C125.39 83.5723 124.043 85.9216 122.696 88.2708C121.398 90.62 120.101 93.0192 118.953 95.3684C117.107 99.1672 115.56 103.166 114.562 107.314L114.163 109.514C114.014 110.263 113.964 110.963 113.864 111.713C113.764 112.463 113.714 113.213 113.714 113.912C113.714 114.662 113.614 115.362 113.714 116.162C113.714 116.262 113.764 116.361 113.764 116.461C113.814 116.561 113.814 116.661 113.914 116.811C114.063 117.111 114.363 117.261 114.712 117.161C115.011 117.111 115.161 117.011 115.361 116.911C115.51 116.811 115.71 116.711 115.86 116.561C116.458 116.062 116.957 115.462 117.357 114.812C117.756 114.162 118.055 113.412 118.205 112.663C118.305 112.313 118.355 111.913 118.404 111.513L118.454 110.963C118.454 110.763 118.504 110.613 118.454 110.313L118.355 109.164C118.355 108.964 118.305 108.814 118.305 108.614L118.205 108.114L118.105 107.614L118.055 107.364V107.314C118.055 107.264 118.055 107.314 118.055 107.314V107.364L118.005 107.464L117.556 108.364L117.357 108.814L117.157 109.364L116.957 109.914C116.908 110.064 116.808 110.363 116.808 110.413C116.658 110.863 116.558 111.313 116.458 111.763C116.059 113.562 115.81 115.412 115.56 117.261C115.261 119.76 115.111 122.26 115.111 124.809C115.111 126.058 115.161 127.358 115.361 128.607C115.461 129.257 115.56 129.857 115.76 130.507C115.959 131.157 116.209 131.756 116.758 132.306C117.007 132.556 117.357 132.806 117.756 132.906C117.955 132.956 118.155 133.006 118.355 133.006C118.554 133.006 118.804 132.956 118.953 132.856C119.153 132.806 119.303 132.656 119.452 132.556C119.602 132.406 119.752 132.306 119.802 132.156C119.901 132.006 120.001 131.856 120.101 131.706C120.201 131.556 120.251 131.406 120.301 131.257C120.799 130.007 120.949 128.757 121.049 127.458C121.049 127.158 121.049 126.808 121.049 126.508V126.258V125.958C121.049 125.708 120.999 125.358 120.949 125.109C120.899 124.859 120.799 124.659 120.7 124.559C120.65 124.509 120.6 124.459 120.5 124.409C120.4 124.359 120.3 124.359 120.251 124.359C120.151 124.359 120.101 124.409 120.051 124.459L119.851 124.609L119.652 124.909C119.602 125.009 119.552 125.159 119.452 125.259L119.352 125.458L119.303 125.608L119.203 125.908C119.153 126.058 119.103 126.208 119.053 126.358C118.953 126.658 118.854 126.958 118.804 127.258C118.654 127.858 118.554 128.507 118.454 129.107C118.404 129.707 118.355 130.307 118.404 130.857C118.454 131.456 118.404 132.006 118.504 132.606C118.604 133.756 118.754 134.905 119.003 136.055C119.502 138.354 120.35 140.553 121.548 142.603C122.745 144.652 124.242 146.451 125.889 148.101C126.288 148.501 126.737 148.901 127.186 149.301L127.386 149.451C127.436 149.55 127.635 149.55 127.735 149.6L128.184 149.7L129.032 149.85C130.18 150.05 131.328 150.25 132.475 150.4C134.222 150.9 135.918 151 137.565 150.95Z"
                                        fill="#005AA4"
                                    ></path>
                                    <path
                                        d="M75.4437 65.0285C73.7971 70.0768 70.9031 73.6756 70.9031 84.0722C70.9031 92.7193 73.5476 101.316 79.136 107.614C77.5892 111.063 74.795 114.112 71.901 116.661C72.8989 128.657 76.3917 137.155 84.6745 145.652C88.8159 146.701 93.9054 147.301 98.7952 147.301C100.043 147.301 101.29 147.251 102.488 147.201C102.887 146.052 103.036 145.002 103.036 144.052C103.036 136.455 93.3565 135.855 93.3565 120.86C110.371 110.863 116.259 94.2688 114.213 77.4743"
                                        fill="#002776"
                                    ></path>
                                    <path
                                        d="M114.064 78.2741L114.213 80.1734C114.263 80.8232 114.263 81.423 114.263 82.0728C114.263 82.7226 114.313 83.3224 114.313 83.9722L114.263 85.8716L114.213 86.8712L114.113 87.8709L113.914 89.8203L113.415 92.5194C113.215 93.519 112.916 94.4687 112.716 95.4184C112.517 96.2681 112.167 97.1678 111.918 98.0675C111.818 98.3174 111.768 98.5174 111.718 98.7673C111.619 99.0172 111.519 99.2171 111.469 99.4671C111.269 99.9169 111.12 100.417 110.92 100.917C109.473 104.515 107.377 107.864 104.883 110.763C102.488 113.612 99.5935 116.212 96.4999 118.411C95.6517 119.011 94.7536 119.56 93.9053 120.11L93.556 120.31L93.3066 120.46C93.2068 120.51 93.0571 120.56 93.107 120.71V121.66C93.107 122.21 93.1569 122.709 93.2068 123.259C93.3066 124.309 93.4064 125.358 93.6558 126.408C93.8554 127.458 94.1548 128.457 94.5041 129.457C95.1028 131.157 96.001 132.756 97.0488 134.206C98.0966 135.655 99.344 137.005 100.442 138.354C101.29 139.404 102.038 140.553 102.438 141.853C102.837 143.103 102.837 144.502 102.537 145.802C102.488 146.102 102.388 146.352 102.338 146.651V146.701V146.751H102.088C101.49 146.751 100.891 146.801 100.242 146.801C99.0447 146.851 97.7972 146.851 96.5498 146.801C94.1049 146.701 91.6101 146.501 89.215 146.102L88.1173 145.902C87.2691 145.752 86.4208 145.552 85.6225 145.352L85.0736 145.202L84.9738 145.102L84.7743 144.852L83.8761 143.902C82.7285 142.603 81.5809 141.253 80.5829 139.854C79.1858 138.004 77.9883 136.005 76.9405 133.956C76.2918 132.606 75.6432 131.207 75.1442 129.807C74.5455 128.208 74.0964 126.508 73.6972 124.809C73.5475 123.959 73.3479 123.109 73.1983 122.26C73.1484 121.81 73.0486 121.41 72.9987 120.96C72.9488 120.51 72.8989 120.11 72.849 119.66C72.7991 119.161 72.6993 118.611 72.6993 118.111L72.6494 117.311L72.5995 116.911V116.861L73.0985 116.411L73.6972 115.862C74.0964 115.512 74.4457 115.112 74.8448 114.712C76.3417 113.163 77.7388 111.463 78.7867 109.614C79.0361 109.214 79.2357 108.764 79.4353 108.364L79.585 108.014L79.7347 107.714C79.7347 107.664 79.7846 107.614 79.7846 107.564L79.6848 107.464L79.1359 106.815C78.8366 106.465 78.5372 106.115 78.2877 105.715C77.9883 105.365 77.7388 104.965 77.4894 104.615C76.4415 103.116 75.5434 101.466 74.7949 99.8169C73.1983 96.2681 72.2502 92.2694 71.8012 88.3208C71.6016 86.8712 71.5517 85.3717 71.5517 83.8722C71.5517 81.523 71.6515 79.1738 72.0506 76.8246C72.35 75.1751 72.7492 73.5256 73.3479 71.9262C74.0465 69.9268 74.9945 67.9275 75.6931 65.8782C75.8428 65.4783 75.8428 65.0785 75.6931 65.0285C75.5434 64.9785 75.3438 65.2784 75.1941 65.6782C74.4457 67.6776 73.4976 69.6769 72.7991 71.7262C72.2502 73.3257 71.8012 75.0252 71.4519 76.7246C71.0028 79.0738 70.8032 81.473 70.8032 83.8722C70.8032 85.3717 70.8032 86.8712 70.9529 88.3707C71.3022 92.4194 72.3999 96.4681 74.0465 100.117C74.7949 101.816 75.743 103.466 76.8407 105.015C77.0902 105.415 77.3896 105.765 77.6889 106.165C77.9883 106.565 78.2877 106.915 78.5871 107.264L78.9364 107.664C78.9863 107.664 78.9364 107.714 78.9364 107.714L78.7867 107.964C78.5871 108.364 78.3875 108.764 78.138 109.164C77.0403 110.963 75.6931 112.563 74.2461 114.112C73.8968 114.512 73.4976 114.862 73.1484 115.212L72.5995 115.762L71.9508 116.361L71.8012 116.511C71.8012 116.561 71.8012 116.611 71.8012 116.711L71.8511 117.061L71.901 117.461L72.0007 118.261C72.0506 118.811 72.1005 119.31 72.2003 119.81C72.2502 120.26 72.3001 120.66 72.3999 121.11C72.4997 121.56 72.5496 121.96 72.6494 122.409C72.7991 123.259 72.9987 124.159 73.1484 125.009C73.5475 126.758 73.9966 128.457 74.5954 130.107C75.0943 131.556 75.6931 133.006 76.3417 134.405C77.3896 136.555 78.5871 138.554 79.9842 140.453L80.4832 141.103L80.9821 141.753C81.4312 142.353 81.9302 142.953 82.4291 143.502L83.1776 144.352L83.9759 145.152L84.3751 145.552L84.5747 145.752L84.7244 145.902L84.8242 146.002C84.874 146.052 84.9239 146.052 84.9239 146.052L85.5227 146.202L86.0716 146.302C86.82 146.452 87.5186 146.601 88.267 146.701L89.3148 146.851C91.7598 147.201 94.2546 147.451 96.7494 147.551C97.9968 147.601 99.2442 147.601 100.492 147.551C101.09 147.551 101.739 147.501 102.338 147.501H102.986H103.086C103.136 147.501 103.136 147.451 103.136 147.451L103.186 147.251L103.286 146.901C103.386 146.601 103.436 146.302 103.535 146.002C103.835 144.602 103.835 143.053 103.436 141.653C103.036 140.204 102.188 139.004 101.34 137.854C100.192 136.455 98.9948 135.155 97.9469 133.706C96.8991 132.306 96.0509 130.757 95.4521 129.157C95.1028 128.208 94.8035 127.258 94.6039 126.208C94.4043 125.209 94.2546 124.159 94.1548 123.159C94.1049 122.659 94.055 122.11 94.055 121.61V120.96C94.055 120.96 94.055 120.91 94.1049 120.91L94.1548 120.86L94.5041 120.66C95.4022 120.11 96.3004 119.56 97.1486 118.961C100.392 116.811 103.286 114.112 105.731 111.163C108.226 108.164 110.321 104.715 111.918 101.117C112.118 100.617 112.317 100.117 112.517 99.667C112.617 99.4171 112.716 99.2171 112.816 98.9672C112.916 98.7173 112.966 98.5174 113.066 98.2675C113.365 97.3178 113.664 96.4181 113.914 95.5684C114.113 94.5687 114.363 93.569 114.562 92.5693C114.712 91.6197 114.862 90.72 114.962 89.8203L115.111 87.8209L115.211 86.8212V85.8216L115.261 83.9222C115.261 83.2724 115.211 82.6726 115.211 82.0228C115.161 81.3731 115.161 80.7733 115.111 80.1235L114.912 78.2241C114.862 77.7742 114.712 77.4244 114.562 77.4244C114.413 77.4244 114.014 77.8242 114.064 78.2741Z"
                                        fill="#005AA4"
                                    ></path>
                                    <path
                                        d="M179.428 20.1433C171.195 17.7941 158.421 8.69712 152.584 0C151.137 2.39921 148.492 6.29791 148.492 19.3936C148.492 25.9914 149.49 32.7891 152.135 38.2373"
                                        fill="#002776"
                                    ></path>
                                    <path
                                        d="M179.428 18.044C184.068 16.8944 191.902 9.29692 195.944 4.19861C196.592 6.9477 196.991 10.5965 196.991 14.2453C196.991 20.1933 195.993 26.2413 193.598 28.8904"
                                        fill="#002776"
                                    ></path>
                                    <path
                                        d="M174.388 70.2267C181.424 69.477 194.646 57.381 194.646 49.6336C194.646 49.1337 194.596 48.6339 194.447 48.1341C193.848 48.7838 193.499 50.0834 193.499 51.383C193.499 53.3823 194.197 55.4816 195.644 55.4816C198.438 55.4816 201.382 48.184 201.382 42.336C201.382 33.4389 194.946 22.8424 189.158 18.3439C184.118 14.1953 161.266 11.5962 156.226 18.5938C149.191 27.7908 143.852 35.7382 143.852 47.1844C143.852 49.8335 144.55 55.5316 146.895 55.5316C149.091 55.5316 150.488 48.234 150.488 45.7349C150.488 45.285 150.388 44.2354 149.989 44.2354H149.939C149.091 44.3853 148.841 45.4849 148.841 46.8345C148.841 53.3823 156.376 64.5786 163.361 66.528"
                                        fill="#002776"
                                    ></path>
                                    <path
                                        d="M163.81 34.5885C163.81 34.5386 163.81 34.4886 163.81 34.3886C163.81 30.4399 166.654 28.4406 169.399 28.4406C172.093 28.4406 174.688 30.29 174.738 33.9887V34.0387C174.738 37.4876 171.594 39.6369 168.65 39.6369C166.205 39.6369 163.91 38.1374 163.81 34.5885Z"
                                        fill="#EE8D9C"
                                    ></path>
                                    <path
                                        d="M186.862 36.088C186.214 35.2383 185.914 34.1887 185.914 33.139C185.914 30.6399 187.561 28.4406 190.255 28.4406C193.1 28.4406 194.996 30.7398 194.996 33.239C194.996 35.8881 192.7 37.9874 190.355 37.9874C189.108 37.9874 187.86 37.4376 186.862 36.088Z"
                                        fill="#EE8D9C"
                                    ></path>
                                    <path
                                        d="M186.513 40.8365C189.856 41.2363 192.75 44.0354 192.75 47.2344C192.75 52.3827 185.415 55.4816 180.326 55.4816C175.985 55.4816 170.247 52.6326 170.247 48.334C170.247 43.9854 174.688 41.9361 179.278 41.0364C178.779 37.7875 178.031 31.6895 178.031 29.9401C178.031 28.4906 178.23 27.041 179.178 27.041C180.825 27.041 183.819 34.6385 186.513 40.8365Z"
                                        fill="#F8E9DD"
                                    ></path>
                                    <path
                                        d="M186.613 41.9861C185.116 41.7362 183.669 41.6362 182.172 41.6862C181.224 41.7362 180.276 41.8861 179.328 42.0861C180.875 43.1357 182.621 44.2853 184.118 44.2353C185.166 44.1854 186.014 43.5856 186.613 41.9861Z"
                                        fill="#EE8D9C"
                                    ></path>
                                    <path
                                        d="M177.382 48.8338C177.332 48.7339 177.232 48.6339 177.183 48.5339C177.083 48.384 177.033 48.234 176.933 48.0841C176.833 47.7842 176.684 47.4843 176.684 47.1344C176.684 47.0844 176.534 47.0344 176.434 47.0344C176.284 47.0344 176.185 47.0844 176.185 47.1844C176.185 47.5842 176.234 47.9341 176.334 48.334C176.384 48.5339 176.484 48.7339 176.534 48.8838C176.584 49.0338 176.684 49.1337 176.733 49.2837C176.733 49.3337 176.783 49.3337 176.783 49.3836C177.182 49.8335 177.632 50.2334 178.18 50.5333C178.28 50.5832 178.38 50.6332 178.48 50.6832C178.53 50.6832 178.63 50.7332 178.679 50.7332C179.029 50.8332 179.378 50.8832 179.777 50.8832C180.027 50.8832 180.276 50.8831 180.575 50.8332C180.875 50.7832 181.224 50.6832 181.523 50.5333C181.573 50.4833 181.573 50.3833 181.523 50.2334C181.474 50.1334 181.374 50.0334 181.324 50.0334C181.025 50.1334 180.775 50.1834 180.526 50.2334C180.326 50.2833 180.076 50.2833 179.877 50.2334C179.578 50.1834 179.278 50.1334 179.029 49.9834C178.979 49.9834 178.929 49.9335 178.879 49.8835C178.779 49.8335 178.729 49.8335 178.629 49.7835C178.18 49.5836 177.781 49.2837 177.532 48.8338C177.432 48.8838 177.382 48.8338 177.382 48.8338Z"
                                        fill="#002776"
                                    ></path>
                                    <path
                                        d="M208.468 40.6365C209.216 40.6865 209.965 40.7865 210.663 40.9864C211.062 41.0864 211.412 41.1364 211.761 41.1864C211.96 41.1864 212.16 41.2363 212.36 41.2363L212.908 41.2863L213.657 41.3863L215.104 41.5862C215.204 41.5862 215.254 41.4863 215.304 41.3863C215.304 41.2363 215.304 41.1364 215.204 41.1364L213.757 40.8365L213.008 40.6865L212.509 40.5366C212.31 40.4866 212.11 40.4366 211.96 40.3866C211.611 40.3366 211.262 40.2867 210.813 40.2367C210.064 40.1867 209.316 40.0867 208.567 39.9368L208.168 39.8868C207.47 39.8368 206.721 39.7368 206.023 39.6369C205.274 39.5369 204.476 39.4369 203.678 39.4369C203.378 39.4369 203.079 39.4369 202.829 39.4369C202.38 39.4369 201.931 39.4869 201.432 39.4869C201.083 39.4869 200.784 39.4869 200.434 39.4869C200.035 39.4869 199.586 39.4869 199.187 39.5369C199.087 39.5369 199.037 39.6369 199.037 39.7868C199.037 39.9368 199.087 40.0367 199.187 40.0367C199.586 40.0367 200.035 40.0367 200.434 40.0367C200.784 40.0367 201.083 40.0367 201.432 40.0367C201.881 40.0367 202.33 40.0867 202.779 40.1367C203.079 40.1867 203.328 40.1867 203.628 40.2367C204.376 40.3366 205.175 40.3366 205.923 40.3866C206.622 40.4366 207.37 40.4866 208.019 40.5866L208.468 40.6365Z"
                                        fill="#7EB5D2"
                                    ></path>
                                    <path
                                        d="M209.216 46.0847C210.014 46.3347 210.863 46.6346 211.661 47.0344C212.11 47.2344 212.509 47.3843 212.859 47.5343L213.507 47.7342L214.106 47.9341L214.954 48.234C215.503 48.434 216.002 48.6339 216.551 48.8838C216.651 48.9338 216.75 48.8338 216.8 48.7339C216.85 48.6339 216.85 48.484 216.75 48.434L215.204 47.6842L214.405 47.2843L213.856 46.9844C213.657 46.8845 213.457 46.7845 213.258 46.6845C212.908 46.5346 212.459 46.3846 212.01 46.2347C211.162 45.9848 210.314 45.6349 209.515 45.335L209.116 45.185C208.318 44.9351 207.52 44.6352 206.721 44.3853C205.873 44.0854 205.025 43.7855 204.127 43.6356C203.777 43.5856 203.478 43.4856 203.129 43.4356L201.532 43.1357L200.384 42.8858C199.935 42.7858 199.436 42.6859 198.937 42.6359C198.838 42.6359 198.738 42.7359 198.738 42.8358C198.738 42.9858 198.788 43.0857 198.887 43.1357C199.337 43.2357 199.836 43.3357 200.285 43.4356C200.634 43.5356 201.033 43.5856 201.382 43.6855C201.881 43.8355 202.43 43.9854 202.929 44.1354C203.228 44.2354 203.578 44.3353 203.877 44.4353C204.725 44.7352 205.624 44.9351 206.472 45.185C207.27 45.385 208.068 45.6349 208.867 45.9348L209.216 46.0847Z"
                                        fill="#7EB5D2"
                                    ></path>
                                    <path
                                        d="M146.446 36.5379C145.448 36.5379 144.45 36.5879 143.452 36.5379C142.904 36.5379 142.405 36.5379 141.956 36.5879C141.706 36.5879 141.457 36.6379 141.157 36.6878L140.459 36.7878L139.411 36.8878L137.465 37.0877C137.365 37.0877 137.265 37.2377 137.265 37.3376C137.265 37.4876 137.365 37.5875 137.515 37.5875C138.163 37.5376 138.812 37.5376 139.461 37.4876L140.459 37.4376H141.157C141.407 37.4376 141.656 37.4376 141.956 37.4376C142.405 37.4376 142.904 37.3876 143.452 37.3376C144.45 37.2377 145.448 37.2377 146.446 37.2876H146.945C147.893 37.2876 148.841 37.3376 149.789 37.4376C150.787 37.5376 151.835 37.6375 152.833 37.7375C153.232 37.7875 153.581 37.7875 153.981 37.8375C154.579 37.8874 155.178 37.9874 155.777 38.0874C156.226 38.1374 156.625 38.2873 157.024 38.3873C157.573 38.4873 158.072 38.6872 158.621 38.7871C158.721 38.8371 158.87 38.7372 158.87 38.5872C158.92 38.4373 158.87 38.3373 158.771 38.2873C158.222 38.0874 157.673 37.9374 157.174 37.7875C156.725 37.6875 156.326 37.5875 155.877 37.4876C155.278 37.3376 154.679 37.1877 154.08 37.0877C153.681 36.9877 153.332 36.9378 152.933 36.8878C151.885 36.6879 150.837 36.6379 149.839 36.5879C148.891 36.5379 147.943 36.5379 146.945 36.4879L146.446 36.5379Z"
                                        fill="#7EB5D2"
                                    ></path>
                                    <path
                                        d="M144.75 41.9861C143.702 42.186 142.604 42.386 141.556 42.5359C140.958 42.6359 140.459 42.7358 139.96 42.8858C139.71 42.9858 139.411 43.0357 139.161 43.1357L138.413 43.3856C138.064 43.4856 137.714 43.6355 137.365 43.7855C136.716 44.0354 136.068 44.2853 135.419 44.5852C135.319 44.6352 135.269 44.7852 135.319 44.8851C135.369 45.0351 135.519 45.0851 135.619 45.0351C136.267 44.7852 136.916 44.5352 137.615 44.3353C137.964 44.2353 138.313 44.1354 138.662 44.0354C138.912 43.9854 139.161 43.9354 139.411 43.8355C139.66 43.7855 139.96 43.7355 140.209 43.6355C140.708 43.5356 141.207 43.3856 141.756 43.2357C142.754 42.9358 143.852 42.7858 144.9 42.6359L145.448 42.5859C146.446 42.386 147.494 42.336 148.492 42.236C149.59 42.136 150.688 42.136 151.785 42.0361L153.033 41.8861C153.681 41.8361 154.33 41.7362 154.979 41.6862C155.428 41.6362 155.927 41.5862 156.376 41.5862C156.974 41.5362 157.573 41.4863 158.172 41.4363C158.272 41.4363 158.372 41.2863 158.372 41.1864C158.372 41.0364 158.272 40.9364 158.122 40.9364C157.523 40.9364 156.925 40.9864 156.326 41.0364C155.877 41.0864 155.378 41.0864 154.929 41.1364C154.28 41.1864 153.631 41.1864 152.983 41.1864C152.584 41.1864 152.135 41.1864 151.735 41.2363C150.638 41.2863 149.49 41.3363 148.392 41.4863C147.394 41.5862 146.347 41.7362 145.299 41.8361L144.75 41.9861Z"
                                        fill="#7EB5D2"
                                    ></path>
                                    <path
                                        d="M170.846 34.2387C170.846 34.3386 170.896 34.4386 170.896 34.5386C170.896 34.6885 170.896 34.7885 170.896 34.9384C170.896 35.1883 170.896 35.4383 170.846 35.6882C170.846 35.7382 171.045 35.8381 171.295 35.8881C171.544 35.9881 171.794 35.9881 171.794 35.9381C171.893 35.6382 171.993 35.3883 172.093 35.0884C172.143 34.9384 172.193 34.7885 172.243 34.6385C172.293 34.5386 172.293 34.4386 172.343 34.3386L172.392 34.2387C172.243 33.7888 172.293 33.289 172.343 32.8391V32.5892L172.293 32.4393C172.193 32.1893 172.093 31.9394 172.043 31.6395C171.993 31.4396 171.943 31.2896 171.943 31.0897C171.894 30.8398 171.844 30.6399 171.744 30.3899C171.744 30.34 171.494 30.34 171.245 30.3899C170.995 30.4399 170.796 30.5399 170.796 30.5899C170.796 30.8398 170.846 31.0397 170.846 31.2896C170.896 31.4896 170.896 31.6395 170.896 31.8395C170.896 32.0894 170.896 32.3393 170.846 32.5892L170.796 32.7392L170.846 32.9391C170.945 33.339 170.995 33.7388 170.796 34.1387L170.846 34.2387Z"
                                        fill="#002776"
                                    ></path>
                                    <path
                                        d="M191.503 33.439C191.503 33.5389 191.553 33.5889 191.553 33.6889C191.553 33.7889 191.553 33.8888 191.553 34.0388C191.553 34.2387 191.553 34.4386 191.553 34.6886C191.553 34.7385 191.752 34.8385 192.002 34.8885C192.251 34.9885 192.501 34.9885 192.501 34.9885C192.601 34.7385 192.7 34.5386 192.8 34.2887C192.85 34.1887 192.9 34.0388 192.95 33.8888C193 33.7889 193 33.6889 193.05 33.6389L193.1 33.5889C192.95 33.1891 193 32.7892 193.05 32.4393V32.2394L193 32.1394C192.9 31.9395 192.85 31.6896 192.75 31.4896C192.7 31.3397 192.651 31.1897 192.651 31.0398C192.601 30.8398 192.551 30.6399 192.451 30.49C192.451 30.44 192.201 30.49 191.952 30.5399C191.703 30.5899 191.503 30.6899 191.503 30.7399C191.503 30.9398 191.553 31.1397 191.553 31.2897C191.603 31.4396 191.603 31.5896 191.603 31.7395C191.603 31.9395 191.603 32.1394 191.553 32.3393L191.503 32.4393L191.553 32.5893C191.653 32.8892 191.703 33.239 191.503 33.5389V33.439Z"
                                        fill="#002776"
                                    ></path>
                                    <path
                                        d="M154.679 15.045C154.43 14.2452 154.28 13.3955 154.28 12.5958C154.28 12.1959 154.38 11.7461 154.579 11.4462C154.779 11.1463 154.979 10.9963 155.328 11.0463C156.076 11.1463 156.725 11.7461 157.224 12.2959C157.523 12.5958 157.773 12.9457 158.022 13.3455C158.272 13.6954 158.471 14.0453 158.671 14.3952C158.97 14.895 159.22 15.4448 159.469 15.9946C159.918 17.0443 160.268 18.094 160.517 19.1936C160.567 19.3935 160.717 19.5435 160.866 19.4935C161.016 19.4435 161.066 19.2936 161.016 19.0936C160.767 17.944 160.467 16.7944 160.018 15.7447C159.819 15.1949 159.569 14.5951 159.27 14.0453C159.07 13.6454 158.87 13.2955 158.621 12.8957C158.372 12.4958 158.122 12.0959 157.773 11.7461C157.473 11.3962 157.174 11.0963 156.775 10.7964C156.376 10.5465 155.877 10.2466 155.278 10.2466C155.028 10.1966 154.679 10.2965 154.43 10.4465C154.18 10.5964 153.981 10.8464 153.881 11.0963C153.631 11.5961 153.581 12.046 153.532 12.5458C153.482 13.4955 153.631 14.3952 153.881 15.2949C153.981 15.5948 154.08 15.8947 154.23 16.1946C154.629 16.9943 155.128 17.7941 155.927 18.2939C156.326 18.5938 156.775 18.7437 157.274 18.8437H157.473C157.573 18.8437 157.673 18.8437 157.723 18.8437L158.272 18.7937L158.521 18.7437H158.671H158.721C158.771 18.7437 158.721 18.6938 158.721 18.6938C158.671 18.5438 158.621 18.3439 158.571 18.1939C158.471 17.994 158.471 17.844 158.322 17.6441L158.222 17.4442C158.172 17.3942 158.172 17.3442 158.122 17.2942C157.972 17.0943 157.823 16.8944 157.673 16.7444C157.374 16.3945 157.024 16.0446 156.625 15.7447C155.877 15.1449 155.078 14.5951 154.08 14.3452C153.382 14.1453 152.484 14.0953 151.785 14.5951C151.236 14.995 150.987 15.6947 150.987 16.2945C151.037 16.9443 151.236 17.4942 151.536 17.944C151.935 18.6438 152.484 19.2436 153.132 19.7934C153.881 20.4432 154.829 20.943 155.827 21.1929C156.026 21.2429 156.226 21.1429 156.226 21.043C156.226 20.893 156.126 20.7431 155.927 20.7431C155.028 20.4932 154.18 19.9933 153.432 19.3935C152.883 18.9437 152.384 18.3439 152.035 17.6941C151.785 17.2442 151.635 16.7444 151.635 16.2945C151.635 15.8447 151.835 15.3948 152.184 15.1949C152.633 14.945 153.232 14.945 153.831 15.1449C154.629 15.3948 155.378 15.8947 156.026 16.4445C156.376 16.6944 156.675 16.9943 156.974 17.3442C157.124 17.4942 157.274 17.6441 157.374 17.844L157.523 18.094V18.1439C157.523 18.1439 157.523 18.1439 157.473 18.1439H157.423H157.274C156.925 18.094 156.575 17.994 156.276 17.7441C155.677 17.3442 155.178 16.6444 154.879 15.9447C154.879 15.5948 154.779 15.3449 154.679 15.045Z"
                                        fill="#005AA4"
                                    ></path>
                                    <path
                                        d="M193.15 16.6445C193.15 17.1943 192.95 17.7941 192.601 18.244C192.401 18.4939 192.251 18.7438 192.102 18.9437C192.002 19.0437 191.902 19.1936 191.852 19.2936C191.752 19.3936 191.653 19.4935 191.553 19.5935C191.403 19.7435 191.253 19.8434 191.104 19.9934C190.804 20.2433 190.455 20.4432 190.106 20.5932C190.056 20.6432 190.056 20.7431 190.106 20.8931C190.156 21.043 190.255 21.093 190.305 21.093C190.705 20.9431 191.104 20.7431 191.453 20.5432C191.653 20.4432 191.852 20.2933 192.002 20.1933C192.102 20.0933 192.251 19.9934 192.351 19.8934C192.501 19.7934 192.601 19.6935 192.75 19.5435C192.95 19.2936 193.149 19.0437 193.299 18.6938C193.549 18.094 193.798 17.4442 193.898 16.7445C193.898 16.6445 193.898 16.4945 193.898 16.3946C193.898 16.2446 193.848 16.0447 193.798 15.8448C193.748 15.6448 193.648 15.4449 193.449 15.2949C193.249 15.095 192.95 15.095 192.7 15.145C192.451 15.195 192.301 15.2949 192.152 15.4449C191.553 15.9447 191.253 16.5445 190.954 17.1443C190.854 17.3942 190.754 17.5942 190.705 17.8441L190.355 18.9437L190.106 19.7435C190.006 20.0933 189.906 20.3932 189.856 20.7931C189.856 20.8931 189.956 20.9431 190.106 20.9431C190.255 20.9431 190.355 20.9431 190.355 20.8431C190.455 20.5432 190.555 20.1933 190.655 19.8934C190.754 19.6435 190.804 19.3936 190.904 19.1437C191.054 18.7938 191.204 18.4439 191.403 18.144C191.503 17.9441 191.603 17.7441 191.752 17.5442C192.052 17.0444 192.351 16.4446 192.7 16.0947C192.8 15.9947 192.85 15.9447 192.9 15.9447C192.95 15.9447 192.95 15.9447 193 15.9447C193.05 15.9947 193.15 16.2446 193.15 16.4945C193.15 16.4446 193.15 16.5445 193.15 16.6445Z"
                                        fill="#005AA4"
                                    ></path>
                                </g>
                                <defs>
                                    <clipPath id="clip0_3459_11868">
                                        <rect width="217" height="151" fill="white"></rect>
                                    </clipPath>
                                </defs></svg
                            ><svg
                                class="background-wave-sb1-logo"
                                width="162"
                                height="183"
                                viewBox="0 0 162 183"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    d="M80.9977 0C72.4386 0 64.1977 1.33809 56.4565 3.80604C89.044 -3.27877 121.349 10.1731 132.985 37.7325C146.433 69.5854 127.184 108.2 89.9812 123.973C56.6112 138.125 20.1509 129.082 3.28467 104.079C13.1524 137.757 44.2014 162.357 80.9977 162.357C125.734 162.357 162 126.011 162 81.1763C162 36.3412 125.734 0 80.9977 0Z"
                                    fill="#E60000"
                                ></path>
                                <path
                                    d="M89.9814 123.969C127.18 108.191 146.434 69.5809 132.985 37.7281C121.349 10.1686 89.0441 -3.28321 56.4567 3.8016C23.7189 14.2228 0 44.9192 0 81.1763C0 89.1339 1.16273 96.8125 3.28925 104.079C20.1511 129.082 56.6158 138.125 89.9814 123.969Z"
                                    fill="#AF0000"
                                ></path>
                                <path
                                    d="M101.764 117.867V34.5113C101.764 32.8542 100.415 31.5072 98.7617 31.5072H79.9281C78.5841 31.5072 77.8281 31.8085 76.6256 32.256L52.3231 44.7951C50.8288 45.4021 50.2275 46.2971 50.2275 47.8036V61.4637C50.2275 63.0676 51.5273 64.3658 53.1233 64.3658H68.6765V129.897C75.7767 128.909 82.9477 126.955 89.9815 123.969C94.1417 122.21 98.072 120.158 101.764 117.867Z"
                                    fill="white"
                                ></path>
                                <path
                                    d="M129.417 69.6386C129.559 72.2704 131.95 75.3099 134.709 75.3144C137.07 75.3188 140.527 73.4003 140.536 69.2974C140.536 69.1955 140.536 69.0936 140.532 68.9872C143.308 67.7954 144.338 65.3584 144.343 63.2449C144.352 59.0047 139.997 54.2992 135.284 54.2859C133.228 54.2815 130.019 54.9461 129.448 56.9887L129.417 69.6386Z"
                                    fill="#002776"
                                ></path>
                                <path
                                    d="M138.308 66.4307C142.716 66.5326 149.617 73.1699 149.59 84.7165C149.586 86.9541 149.299 91.5045 147.084 91.5001C143.909 91.4912 141.858 82.5898 141.862 79.3996C141.867 78.3495 142.017 77.4013 142.393 76.6791C143.914 77.8001 144.068 84.5305 144.064 86.3426C144.046 94.4377 141.619 100.282 140.324 100.277C138.529 100.273 138.259 93.5116 138.264 91.7083C138.272 87.1978 138.993 81.6061 139.002 76.5196C139.006 73.7681 138.807 71.1628 138.175 68.9563"
                                    fill="#002776"
                                ></path>
                                <path
                                    d="M120.151 71.5704C122.299 71.5084 124.695 72.2483 124.7 70.0462C124.704 68.4777 123.657 66.8915 123.657 65.2964C123.67 60.1789 127.503 55.7082 133.498 55.6905C136.283 55.6816 137.671 56.6963 138.449 58.5528C136.986 59.8643 136.283 61.5258 136.128 63.4576C136.955 62.9171 137.786 62.6778 138.414 62.6822C139.479 62.6867 140.028 63.3734 140.023 64.1754C140.019 65.385 138.799 66.6699 136.809 66.6655C136.791 66.6655 136.774 66.6655 136.756 66.6655C135.806 71.6501 131.716 73.2053 131.707 75.7264C131.703 76.8696 132.662 78.3982 133.737 79.1825C115.548 80.9016 117.936 80.463 120.151 71.5704Z"
                                    fill="#F8E9DD"
                                ></path>
                                <path
                                    d="M132.782 56.8645C132.083 56.5145 129.992 55.81 128.754 55.9075C128.326 55.9429 128.056 56.1246 128.087 56.5366C128.153 57.4095 128.993 58.4906 129.594 59.1242"
                                    fill="#F8E9DD"
                                ></path>
                                <path
                                    d="M127.888 57.188C127.958 57.3431 128.038 57.4893 128.118 57.6311C128.233 57.8349 128.361 58.0299 128.498 58.2115C128.759 58.5571 129.042 58.8761 129.342 59.1819C129.395 59.235 129.51 59.2085 129.599 59.1243C129.687 59.0401 129.718 58.9293 129.669 58.8761C129.404 58.566 129.165 58.2337 128.958 57.8925C128.847 57.7153 128.754 57.5336 128.67 57.3475C128.608 57.219 128.569 57.0861 128.533 56.9576C128.524 56.9266 128.52 56.8956 128.515 56.8646C128.454 56.7405 128.423 56.6032 128.405 56.4924C128.396 56.3861 128.414 56.3506 128.454 56.3152C128.551 56.2221 128.882 56.2177 129.165 56.2443C129.267 56.2487 129.369 56.2664 129.47 56.2797L129.674 56.2841C130.045 56.3107 130.421 56.3639 130.792 56.4525C131.062 56.5101 131.323 56.5854 131.584 56.6741C131.906 56.7804 132.242 56.9 132.565 57.0197C132.627 57.0462 132.724 56.9753 132.777 56.869C132.83 56.7627 132.822 56.6519 132.751 56.612C132.424 56.4348 132.074 56.3107 131.738 56.1955C131.469 56.1114 131.195 56.0272 130.925 55.9385C130.545 55.8278 130.16 55.717 129.758 55.6328L129.546 55.5841C129.426 55.5797 129.311 55.5664 129.192 55.5708C129.024 55.5664 128.851 55.5752 128.67 55.5974C128.485 55.624 128.268 55.6683 128.06 55.8278C127.843 55.9917 127.751 56.2974 127.759 56.5101C127.764 56.7184 127.79 56.9 127.83 57.0817C127.852 57.1171 127.866 57.1526 127.888 57.188Z"
                                    fill="#EE8D9C"
                                ></path>
                                <path
                                    d="M129.881 62.4651C130.036 62.4651 130.191 62.4651 130.346 62.4607C130.567 62.4607 130.788 62.4474 131.009 62.4252C131.429 62.3809 131.84 62.3056 132.247 62.1816C132.317 62.1594 132.348 62.0442 132.313 61.929C132.278 61.8138 132.198 61.734 132.132 61.7473C131.752 61.8315 131.362 61.8625 130.969 61.8625C130.766 61.8625 130.562 61.8537 130.363 61.836C130.222 61.8271 130.08 61.8005 129.943 61.7784L129.846 61.7606C129.249 61.7695 128.652 61.5967 128.144 61.3486C128.051 61.3087 127.972 61.2555 127.888 61.2068C127.83 61.1846 127.768 61.1625 127.711 61.1315C127.397 60.9808 127.118 60.7681 126.897 60.5112C126.813 60.4181 126.743 60.3206 126.689 60.2099C126.623 60.108 126.583 59.9883 126.539 59.8776C126.437 59.5896 126.398 59.2705 126.393 58.9471C126.393 58.8806 126.292 58.823 126.177 58.8097C126.057 58.7964 125.96 58.8496 125.951 58.9249C125.92 59.111 125.942 59.3015 125.947 59.4876C125.978 59.6737 126.004 59.8643 126.071 60.0415C126.124 60.1833 126.172 60.3251 126.247 60.4535C126.314 60.5909 126.393 60.715 126.486 60.8346C126.734 61.1669 127.039 61.4638 127.379 61.6942C127.437 61.7429 127.499 61.7784 127.56 61.8182C127.667 61.867 127.768 61.9246 127.874 61.96C128.489 62.2037 129.134 62.3322 129.775 62.474L129.881 62.4651Z"
                                    fill="#002776"
                                ></path>
                                <path
                                    d="M134.784 59.0445C134.846 59.0534 134.913 59.0578 134.97 59.0667C135.059 59.0755 135.147 59.0888 135.235 59.0888C135.399 59.0977 135.567 59.0888 135.726 59.0755C135.757 59.0755 135.779 58.9692 135.775 58.8495C135.775 58.7299 135.753 58.6324 135.731 58.628C135.594 58.6103 135.456 58.5793 135.328 58.535C135.262 58.5128 135.196 58.4862 135.134 58.4596C135.09 58.4375 135.045 58.4153 135.006 58.3887L134.979 58.3666C134.771 58.3666 134.599 58.2425 134.488 58.1096C134.466 58.0875 134.448 58.0653 134.435 58.0387L134.382 58.0121C134.303 57.9501 134.219 57.8748 134.174 57.7729C134.139 57.7064 134.117 57.6266 134.117 57.5469C134.099 57.4494 134.135 57.3386 134.117 57.2234C134.112 57.2013 134.02 57.1614 133.905 57.1348C133.79 57.1083 133.692 57.1082 133.684 57.1393C133.648 57.281 133.604 57.4317 133.626 57.5823C133.631 57.702 133.657 57.826 133.684 57.9457C133.723 58.114 133.799 58.278 133.887 58.433L133.936 58.5172C133.971 58.5527 134.011 58.5837 134.051 58.6147C134.28 58.7831 134.524 58.885 134.749 59.0445H134.784Z"
                                    fill="#002776"
                                ></path>
                                <path
                                    d="M114.907 106.254C112.608 123.1 76.6786 128.373 83.4384 168.144C77.5673 175.964 73.6635 181.595 65.29 183L72.3858 168.773C73.7563 166.026 74.3487 162.973 74.194 159.907C74.194 159.894 74.194 159.876 74.1896 159.862L67.0142 158.077C69.2071 117.916 89.4201 117.145 93.1514 92.9267L114.907 106.254Z"
                                    fill="#002776"
                                ></path>
                                <path
                                    d="M111.419 99.533C101.865 93.1217 91.8473 85.9925 81.1616 80.8041C75.401 78.0083 68.5484 81.3402 67.2221 87.6186L59.9362 122.09C53.3533 128.431 45.7889 127.868 41.1998 129.312C44.971 130.256 50.8863 132.768 61.6383 132.414C63.5968 132.347 64.7419 132.206 65.6128 132.019C66.4705 127.434 67.4475 122.914 69.185 118.559C71.7492 119.046 74.3134 119.52 76.9086 119.777L81.4401 101.053C87.5544 107.597 93.85 115.058 98.6203 116.817L111.419 99.533Z"
                                    fill="#002776"
                                ></path>
                                <path
                                    d="M120.023 111.673C121.725 112.728 123.511 113.384 125.323 113.384C133.918 113.384 135.726 97.3441 135.726 88.9921C135.726 81.3357 134.258 78.921 132.092 76.5372C132.092 76.5372 127.901 75.6112 120.969 76.6879C120.933 76.329 120.92 75.9701 120.92 75.6068C120.92 74.1047 121.177 72.5761 121.398 71.1405C120.854 71.1051 120.328 71.0874 119.815 71.0874C112.467 71.0874 108.285 74.7295 104.487 81.7655C100.544 82.1643 97.0642 83.9012 97.0642 87.8268C97.0642 92.0981 109.881 114.793 115.084 114.793C117.038 114.793 118.909 113.8 120.023 111.673Z"
                                    fill="#EE8D9C"
                                ></path>
                                <path
                                    d="M111.552 83.3961C112.149 82.9618 112.635 82.8333 113.091 82.8688C113.776 82.9264 113.926 83.396 113.926 83.6708C113.926 84.9335 112.304 85.0886 112.304 86.8565C112.304 88.2212 113.325 89.8207 113.325 91.1986C113.325 93.4096 111.583 96.0902 109.328 97.5834C109.231 97.5878 109.129 97.5878 109.032 97.5878C104.881 97.5878 101.994 93.0108 101.994 89.7764C101.994 87.592 103.638 84.0208 105.553 84.0208C105.743 84.0208 105.933 84.0429 106.127 84.0828C107.361 84.3309 108.625 83.8568 109.297 82.789C109.669 82.1997 109.965 81.7035 110.301 81.7035C110.305 81.7035 110.305 81.7035 110.31 81.7035C111.207 81.7256 111.57 82.3415 111.57 83.1258C111.565 83.21 111.561 83.303 111.552 83.3961Z"
                                    fill="#F8E9DD"
                                ></path>
                                <path
                                    d="M106.746 88.3452C107.577 89.1561 108.347 90.1485 108.745 91.2341C108.793 91.367 108.815 91.5044 108.855 91.6373C108.86 91.7658 108.89 91.8987 108.877 92.0228C108.855 92.2709 108.753 92.4791 108.581 92.6076C108.232 92.8779 107.622 92.8159 107.078 92.6519C105.866 92.293 104.828 91.6683 103.917 91.0391C103.413 90.6847 102.918 90.3036 102.507 89.8738C102.414 89.7808 102.316 89.6612 102.255 89.5858C102.237 89.5593 102.197 89.5327 102.21 89.5061C102.219 89.4928 102.232 89.4839 102.246 89.4706C102.255 89.4618 102.268 89.4529 102.33 89.413C102.431 89.3554 102.537 89.3111 102.648 89.2845C102.971 89.2092 103.338 89.2934 103.678 89.4618C104.018 89.6257 104.35 89.8605 104.642 90.1353C105.208 90.6492 105.69 91.274 106.083 91.943C106.278 92.2798 106.454 92.6254 106.569 92.9842C106.605 93.0729 106.627 93.1615 106.649 93.2501C106.676 93.3387 106.693 93.4273 106.698 93.5115C106.729 93.6887 106.702 93.8394 106.64 93.9324C106.574 94.0521 106.379 94.1495 106.371 94.2692C106.371 94.3268 106.428 94.3888 106.552 94.4065C106.667 94.4242 106.87 94.3711 106.998 94.2027C107.171 93.9635 107.188 93.6843 107.157 93.4716C107.153 93.3564 107.131 93.2457 107.104 93.1438C107.082 93.0374 107.056 92.9311 107.02 92.8336C106.897 92.426 106.715 92.0494 106.516 91.686C106.114 90.9594 105.619 90.2859 105.009 89.7055C104.695 89.4042 104.341 89.1295 103.93 88.9212C103.528 88.7174 103.037 88.5712 102.529 88.6731C102.352 88.7085 102.184 88.7706 102.029 88.8548C101.963 88.8902 101.852 88.9611 101.751 89.0409C101.649 89.1206 101.56 89.2092 101.472 89.2978L101.401 89.3643C101.375 89.3865 101.419 89.4175 101.423 89.4441L101.512 89.6124C101.574 89.7232 101.622 89.8428 101.697 89.9447C101.812 90.1042 101.892 90.215 102.003 90.3346C102.453 90.8442 102.957 91.2695 103.488 91.6594C104.447 92.3329 105.522 92.9798 106.923 93.3431C107.082 93.383 107.25 93.4007 107.414 93.4318C107.582 93.4495 107.754 93.4583 107.927 93.4583C108.276 93.445 108.669 93.3609 108.988 93.1039C109.31 92.8469 109.478 92.4393 109.505 92.0715C109.523 91.881 109.487 91.7082 109.474 91.5265C109.43 91.3626 109.399 91.1898 109.341 91.0347C108.877 89.7852 108.104 88.7661 107.224 87.8667C106.919 87.5565 106.583 87.273 106.216 87.0116C105.951 86.8432 105.676 86.6837 105.358 86.5685C105.199 86.5153 105.04 86.4621 104.85 86.4489C104.673 86.4178 104.469 86.4311 104.284 86.4887C104.235 86.502 104.186 86.5197 104.138 86.5419C104.076 86.5685 104.019 86.6039 103.965 86.6438C103.859 86.7236 103.775 86.8255 103.727 86.9451C103.634 87.1888 103.727 87.4945 103.802 87.6363C103.97 87.973 104.195 88.2079 104.421 88.4294C105.349 89.2757 106.406 89.8606 107.502 90.3391C108.104 90.5783 108.705 90.8176 109.461 90.8397C109.832 90.8397 110.274 90.7423 110.606 90.3967C110.765 90.2239 110.88 89.9979 110.906 89.7453C110.92 89.4972 110.88 89.2978 110.8 89.0852C110.624 88.682 110.323 88.4205 110.036 88.2123C109.739 88.0041 109.434 87.8578 109.129 87.7205C108.519 87.4502 107.9 87.2597 107.286 87.0736C106.379 86.7944 105.464 86.5508 104.624 86.2052C104.297 86.0678 103.974 85.9083 103.718 85.7089C103.461 85.5051 103.293 85.2703 103.316 85.0133C103.32 84.8848 103.36 84.7917 103.448 84.712C103.532 84.6278 103.674 84.5658 103.828 84.5259C104.142 84.4417 104.505 84.4461 104.867 84.4594C105.906 84.5037 106.928 84.8095 107.869 85.2703C109.045 85.8507 110.133 86.7058 111.044 87.6939C111.225 87.8977 111.441 87.9996 111.534 87.9243C111.627 87.849 111.556 87.6186 111.375 87.397C110.46 86.3337 109.319 85.4342 108.081 84.8183C107.091 84.3309 106.012 84.0031 104.894 83.9322C104.509 83.91 104.111 83.8923 103.696 83.9898C103.488 84.0385 103.267 84.1183 103.072 84.2866C102.869 84.4506 102.75 84.7297 102.736 84.9734C102.723 85.2171 102.776 85.4785 102.904 85.6823C103.019 85.895 103.183 86.0501 103.342 86.1874C103.669 86.4533 104.023 86.6394 104.377 86.8033C105.27 87.2065 106.176 87.4768 107.056 87.7737C107.653 87.9775 108.249 88.1813 108.806 88.4294C109.35 88.6731 109.903 89.001 110.075 89.3865C110.111 89.4751 110.128 89.5903 110.128 89.6612C110.124 89.7276 110.093 89.7985 110.036 89.8605C109.925 89.9846 109.704 90.0688 109.452 90.0688C108.935 90.0688 108.329 89.8738 107.781 89.6567C106.751 89.2358 105.707 88.6731 104.885 87.9332C104.686 87.7471 104.505 87.5388 104.408 87.3439C104.355 87.2242 104.359 87.2154 104.363 87.1844C104.368 87.1711 104.381 87.1578 104.394 87.1489C104.399 87.1445 104.408 87.1401 104.412 87.1401C104.43 87.1312 104.452 87.1223 104.474 87.1179C104.85 87.0204 105.385 87.2597 105.818 87.5698C106.141 87.8047 106.459 88.0572 106.746 88.3452Z"
                                    fill="#EE8D9C"
                                ></path>
                                <path
                                    d="M109.775 85.2836C109.766 85.3412 109.757 85.3988 109.744 85.4564C109.726 85.5406 109.709 85.6203 109.695 85.7045C109.669 85.8596 109.651 86.0191 109.642 86.1742C109.638 86.2008 109.739 86.2406 109.854 86.2584C109.974 86.2761 110.075 86.2761 110.08 86.2539C110.12 86.121 110.173 85.9925 110.235 85.8684C110.261 85.802 110.301 85.74 110.332 85.6779C110.354 85.6336 110.385 85.5937 110.416 85.5494L110.438 85.5228C110.451 85.3057 110.575 85.1196 110.703 84.9557L110.77 84.8715L110.792 84.8006C110.84 84.681 110.898 84.5614 110.969 84.455C111.017 84.3753 111.079 84.3044 111.141 84.2379C111.221 84.1537 111.305 84.0696 111.375 83.9721C111.389 83.9544 111.34 83.8613 111.26 83.7727C111.185 83.6841 111.106 83.622 111.079 83.6353C110.964 83.7062 110.862 83.7993 110.774 83.8968C110.703 83.9721 110.633 84.0518 110.557 84.1227C110.456 84.2291 110.35 84.331 110.248 84.4373L110.19 84.4905L110.133 84.6012C110.027 84.8184 109.938 85.0443 109.779 85.2393L109.775 85.2836Z"
                                    fill="#EE8D9C"
                                ></path>
                                <path
                                    d="M127.273 100.982C125.854 100.494 124.559 99.3957 124.006 97.9689C123.688 97.2069 123.564 96.4669 123.551 95.7624C123.542 95.3681 123.551 94.9693 123.604 94.575C123.648 94.2116 123.71 93.8439 123.803 93.485C123.935 92.9666 124.103 92.4526 124.302 91.9475C124.682 90.9949 125.155 90.0733 125.699 89.1916C125.797 89.0365 125.788 88.8548 125.686 88.7884C125.584 88.7219 125.425 88.7928 125.319 88.9523C124.735 89.8385 124.209 90.7689 123.776 91.7481C123.551 92.2577 123.356 92.7805 123.197 93.3211C123.086 93.6977 122.989 94.0832 122.914 94.4731C122.83 94.8984 122.79 95.3326 122.786 95.7757C122.786 96.5644 122.941 97.4195 123.352 98.2702C124.112 99.8033 125.478 101.013 127.034 101.611C127.309 101.704 127.578 101.806 127.861 101.868L128.007 101.899C128.051 101.908 128.113 101.926 128.206 101.939C128.343 101.952 128.493 101.957 128.635 101.952C128.776 101.943 128.913 101.93 129.037 101.903L129.192 101.766L129.271 101.695C129.285 101.669 129.249 101.638 129.24 101.607L128.896 100.884C128.838 100.774 128.785 100.619 128.719 100.548L128.529 100.313L128.153 99.8476C128.02 99.6969 127.883 99.5596 127.746 99.4178C127.609 99.276 127.477 99.1298 127.335 98.9969L126.906 98.607C125.673 97.4949 124.276 96.5112 122.83 95.6694C122.299 95.3459 121.747 95.0579 121.203 94.7566C120.332 94.3003 119.461 93.8528 118.581 93.4141L116.68 92.4792C115.889 92.0982 115.067 91.7083 114.235 91.3627C114.067 91.2918 113.895 91.3228 113.846 91.4336C113.798 91.5399 113.886 91.6905 114.05 91.7703C114.859 92.1602 115.677 92.5501 116.464 92.9311C117.091 93.2413 117.719 93.5515 118.338 93.8838C119.2 94.3401 120.045 94.832 120.885 95.3326C121.402 95.6561 121.928 95.9707 122.432 96.3074C123.811 97.2113 125.204 98.1285 126.424 99.1608L126.849 99.5241C126.986 99.6482 127.114 99.7811 127.247 99.9141C127.379 100.047 127.516 100.175 127.64 100.313L127.994 100.738L128.171 100.951C128.21 100.995 128.21 101.004 128.219 101.017L128.246 101.062L128.356 101.234C128.387 101.27 128.339 101.265 128.334 101.283C128.317 101.283 128.294 101.274 128.277 101.274L128.219 101.261L128.011 101.208C127.773 101.15 127.525 101.057 127.273 100.982Z"
                                    fill="#873953"
                                ></path></svg
                            ><svg
                                class="background-wave-cloud-1"
                                width="172"
                                height="50"
                                viewBox="0 0 172 50"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    d="M135.497 30.6135C130.662 40.4295 117.004 50 100.625 50C90.4722 50 80.3795 46.4417 73.0668 39.5092C69.3197 41.9632 64.4245 43.8037 59.0457 43.8037C51.6121 43.8037 44.2389 40.6135 39.6458 34.7853C35.7175 40.1227 27.8004 42.8221 20.1251 42.8221C8.40056 42.8221 0 36.7485 0 29.8773C0 23.0675 9.12579 18.2209 16.0759 18.2209C17.7077 18.2209 19.1581 18.5276 20.6086 19.0184C23.0864 13.6196 29.4322 10.6135 35.5966 10.6135C36.7449 10.6135 37.7723 10.7362 38.7997 10.9202C40.3106 3.37423 50.4638 0 58.5018 0C71.2537 0 80.3795 8.89571 95.0654 8.89571C109.872 8.89571 120.448 1.84049 129.695 1.84049C137.673 1.84049 147.282 8.22086 149.639 16.8098C153.265 15.1534 157.435 14.1718 160.638 14.1718C168.011 14.1718 172 18.6503 172 23.6196C172 31.9018 162.572 36.6258 153.628 36.6258C148.128 36.5644 140.573 34.6012 135.497 30.6135Z"
                                    fill="#A5CBDF"
                                ></path></svg
                            ><svg
                                class="background-wave-cloud-2"
                                width="136"
                                height="52"
                                viewBox="0 0 136 52"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    d="M108.776 11.307C111.594 10.5814 114.593 10.1581 117.411 10.1581C129.524 10.1581 136 17.5349 136 25.5767C136 36.5209 125.626 44.6837 108.596 44.6837C100.501 44.6837 96.3033 42.5674 91.3862 40.9349C84.4903 46.2558 76.2751 52 68 52C54.2081 52 48.2716 45.4093 45.0335 37.6093C39.5767 40.2698 31.4815 41.6 27.2839 41.6C14.3915 41.6 0 34.2233 0 19.4698C0 9.61395 13.7919 4.59535 22.5467 4.59535C33.4004 4.59535 42.8748 11.8512 53.7284 11.8512C64.582 11.8512 73.9965 0 85.5097 0C95.7037 0 104.638 6.65116 108.776 11.307Z"
                                    fill="#7EB5D2"
                                ></path>
                            </svg>
                        </div>
                        <div
                            class="ffe-wave__wave ffe-wave--bg-vann-30 ffe-wave--dm-bg-natt ffe-wave__wave--flip"
                            aria-hidden="true"
                            bis_skin_checked="1"
                        ></div>
                    </div>
                </div>
            </div>
        </div>
       
    </body>
</html>
