﻿<!doctype html>
<html lang="nb">
    <head>
        <link
            rel="icon"
            data-savepage-href=""
            href=""
        />
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1" />
        <meta name="theme-color" media="(prefers-color-scheme: dark)" content="#0f150f" />
        <meta name="theme-color" content="#faf7f4" />
        <meta name="robots" content="noindex, nofollow" />
        <link
            rel="icon"
            type="image/png"
            data-savepage-href=""
            href=""
        />
        <link
            rel="preload"
            data-savepage-href=""
            href=""
            as="font"
            type="font/woff2"
            crossorigin=""
        />
        <title>BankID</title>
        <style data-savepage-href="">
            /*! normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css */
            html {
                line-height: 1.15;
                -webkit-text-size-adjust: 100%;
            }
            body {
                margin: 0;
            }
            main {
                display: block;
            }
            h1 {
                font-size: 2em;
                margin: 0.67em 0;
            }
            hr {
                box-sizing: content-box;
                height: 0;
                overflow: visible;
            }
            pre {
                font-family: monospace, monospace;
                font-size: 1em;
            }
            a {
                background-color: transparent;
            }
            abbr[title] {
                border-bottom: none;
                text-decoration: underline;
                text-decoration: underline dotted;
            }
            b,
            strong {
                font-weight: bolder;
            }
            code,
            kbd,
            samp {
                font-family: monospace, monospace;
                font-size: 1em;
            }
            small {
                font-size: 80%;
            }
            sub,
            sup {
                font-size: 75%;
                line-height: 0;
                position: relative;
                vertical-align: baseline;
            }
            sub {
                bottom: -0.25em;
            }
            sup {
                top: -0.5em;
            }
            img {
                border-style: none;
            }
            button,
            input,
            optgroup,
            select,
            textarea {
                font-family: inherit;
                font-size: 100%;
                line-height: 1.15;
                margin: 0;
            }
            button,
            input {
                overflow: visible;
            }
            button,
            select {
                text-transform: none;
            }
            button,
            [type="button"],
            [type="reset"],
            [type="submit"] {
                -webkit-appearance: button;
            }
            button::-moz-focus-inner,
            [type="button"]::-moz-focus-inner,
            [type="reset"]::-moz-focus-inner,
            [type="submit"]::-moz-focus-inner {
                border-style: none;
                padding: 0;
            }
            button:-moz-focusring,
            [type="button"]:-moz-focusring,
            [type="reset"]:-moz-focusring,
            [type="submit"]:-moz-focusring {
                outline: 1px dotted ButtonText;
            }
            fieldset {
                padding: 0.35em 0.75em 0.625em;
            }
            legend {
                box-sizing: border-box;
                color: inherit;
                display: table;
                max-width: 100%;
                padding: 0;
                white-space: normal;
            }
            progress {
                vertical-align: baseline;
            }
            textarea {
                overflow: auto;
            }
            [type="checkbox"],
            [type="radio"] {
                box-sizing: border-box;
                padding: 0;
            }
            [type="number"]::-webkit-inner-spin-button,
            [type="number"]::-webkit-outer-spin-button {
                height: auto;
            }
            [type="search"] {
                -webkit-appearance: textfield;
                outline-offset: -2px;
            }
            [type="search"]::-webkit-search-decoration {
                -webkit-appearance: none;
            }
            ::-webkit-file-upload-button {
                -webkit-appearance: button;
                font: inherit;
            }
            details {
                display: block;
            }
            summary {
                display: list-item;
            }
            template {
                display: none;
            }
            [hidden] {
                display: none;
            }
            :root {
                color-scheme: light;
                --bg-color-default: #faf7f4;
                --bg-color-section: #f5efea;
                --bg-color-elevated: #ffffff;
                --bg-color-emphasis: #39134c;
                --bg-color-inverted: #121a12;
                --bg-color-accent: #eee4ff;
                --bg-color-state-hover: #ebeeeb;
                --bg-color-state-active: #dadeda;
                --bg-color-state-enabled: #eee4ff;
                --bg-color-state-destructive-hover: #ffe5e5;
                --bg-color-state-destructive-active: #ffcccc;
                --bg-color-state-inverted-hover: #292d28;
                --bg-color-state-inverted-active: #3a3e3a;
                --bg-color-status-neutral-strong: #1d211d;
                --bg-color-status-neutral-weak: #dadeda;
                --bg-color-status-success-strong: #093d05;
                --bg-color-status-success-weak: #e2fdc0;
                --bg-color-status-info-strong: #0049cf;
                --bg-color-status-info-weak: #dfe9fd;
                --bg-color-status-danger-strong: #8b000f;
                --bg-color-status-danger-weak: #ffd9d9;
                --bg-color-status-attention-strong: #663b04;
                --bg-color-status-attention-weak: #ffeeb5;
                --bg-color-status-disabled-strong: #6a6867;
                --bg-color-status-disabled-weak: #eeece9;
                --bg-color-misc-brand-bankid: #deccff;
                --bg-color-misc-brand-harmony: #c9fb88;
                --bg-color-misc-brand-stoe: #c9fb88;
                --bg-color-misc-brand-bankaxept: #deccff;
                --bg-color-backdrop: rgba(18, 26, 18, 0.4);
                --fg-color-default: #121a12;
                --fg-color-subtle: #3a3e3a;
                --fg-color-muted: #9c9995;
                --fg-color-emphasis: #ffffff;
                --fg-color-inverted: #ffffff;
                --fg-color-accent: #39134c;
                --fg-color-rest: #39134c;
                --fg-color-link-rest: #285605;
                --fg-color-link-hover: #1e4f05;
                --fg-color-link-active: #144605;
                --fg-color-status-neutral-strong: #dadeda;
                --fg-color-status-neutral-weak: #1d211d;
                --fg-color-status-success-strong: #67e702;
                --fg-color-status-success-weak: #093d05;
                --fg-color-status-info-strong: #dfe9fd;
                --fg-color-status-info-weak: #0049cf;
                --fg-color-status-danger-strong: #ffd9d9;
                --fg-color-status-danger-weak: #8b000f;
                --fg-color-status-attention-strong: #ffeeb5;
                --fg-color-status-attention-weak: #663b04;
                --fg-color-status-disabled-strong: #eeece9;
                --fg-color-status-disabled-weak: #6a6867;
                --fg-color-misc-brand-stoe: #093d05;
                --fg-color-misc-brand-bankid: #39134c;
                --fg-color-misc-brand-harmony: #093d05;
                --fg-color-misc-bankid-purple: #39134c;
                --fg-color-misc-stoe-green: #67e702;
                --fg-color-misc-bankaxept-purple: #551488;
                --border-color-default: #6a6867;
                --border-color-strong: #121a12;
                --border-color-muted: #b9beb9;
                --border-color-inverted: #dadeda;
                --border-color-focus: #121a12;
                --border-color-focus-inverted: #ffffff;
                --border-color-status-success: #093d05;
                --border-color-status-info: #0049cf;
                --border-color-status-danger: #8b000f;
                --border-color-status-attention: #663b04;
                --border-color-status-disabled: #b9beb9;
                --button-filled-bg-color-rest: #39134c;
                --button-filled-bg-color-hover: #47146a;
                --button-filled-bg-color-active: #551488;
                --button-filled-fg-color-rest: #ffffff;
                --button-tonal-bg-color-rest: #ebe1ff;
                --button-tonal-bg-color-hover: #deccff;
                --button-tonal-bg-color-active: #d5beff;
                --button-tonal-fg-color-rest: #39134c;
                --button-outline-fg-color-rest: #39134c;
                --button-outline-fg-color-inverted: #d5beff;
                --button-outline-border-color-rest: #39134c;
                --button-outline-border-color-inverted: #3a3e3a;
                --button-transparent-fg-color-hover: #39134c;
                --button-transparent-fg-color-rest: #39134c;
                --button-transparent-fg-color-active: #39134c;
                --button-transparent-fg-color-inverted: #d5beff;
                --button-destructive-bg-color-filled: #8b000f;
                --button-destructive-bg-color-tonal: #ffd9d9;
                --button-destructive-bg-color-hover: #a40817;
                --button-destructive-bg-color-active: #bc0e1e;
                --button-destructive-fg-color-default: #a40817;
                --button-destructive-fg-color-inverted: #ffe5e5;
                --button-destructive-border-color-rest: #a40817;
            }
            @media (prefers-color-scheme: dark) {
                :root {
                    color-scheme: dark;
                    --bg-color-default: #0f150f;
                    --bg-color-section: #161d16;
                    --bg-color-elevated: #1d211d;
                    --bg-color-emphasis: rgba(57, 19, 76, 0.6);
                    --bg-color-inverted: #faf7f4;
                    --bg-color-accent: #0f150f;
                    --bg-color-state-hover: #3a3e3a;
                    --bg-color-state-active: #4d514c;
                    --bg-color-state-enabled: rgba(192, 159, 255, 0.15);
                    --bg-color-state-destructive-hover: #8b000f;
                    --bg-color-state-destructive-active: #980413;
                    --bg-color-state-inverted-hover: #ebeeeb;
                    --bg-color-state-inverted-active: #dadeda;
                    --bg-color-status-neutral-strong: #dadeda;
                    --bg-color-status-neutral-weak: #3a3e3a;
                    --bg-color-status-success-strong: #67e702;
                    --bg-color-status-success-weak: #093d05;
                    --bg-color-status-info-strong: #dfe9fd;
                    --bg-color-status-info-weak: #011d51;
                    --bg-color-status-danger-strong: #ffd9d9;
                    --bg-color-status-danger-weak: #66010b;
                    --bg-color-status-attention-strong: #ffeeb5;
                    --bg-color-status-attention-weak: #4d2a03;
                    --bg-color-status-disabled-strong: #eeece9;
                    --bg-color-status-disabled-weak: #3a3e3a;
                    --bg-color-misc-brand-bankid: #39134c;
                    --bg-color-misc-brand-harmony: rgba(9, 61, 5, 0.6);
                    --bg-color-misc-brand-stoe: #093d05;
                    --bg-color-misc-brand-bankaxept: #551488;
                    --bg-color-backdrop: rgba(18, 26, 18, 0.4);
                    --fg-color-default: #ffffff;
                    --fg-color-subtle: #ccd1cc;
                    --fg-color-muted: #626762;
                    --fg-color-emphasis: #ffffff;
                    --fg-color-inverted: #121a12;
                    --fg-color-accent: #eee4ff;
                    --fg-color-rest: #caafff;
                    --fg-color-link-rest: #c9fb88;
                    --fg-color-link-hover: #b0f666;
                    --fg-color-link-active: #96f143;
                    --fg-color-status-neutral-strong: #4d4c4b;
                    --fg-color-status-neutral-weak: #dadeda;
                    --fg-color-status-success-strong: #093d05;
                    --fg-color-status-success-weak: #67e702;
                    --fg-color-status-info-strong: #0049cf;
                    --fg-color-status-info-weak: #d2e1ff;
                    --fg-color-status-danger-strong: #8b000f;
                    --fg-color-status-danger-weak: #ffcccc;
                    --fg-color-status-attention-strong: #4d2a03;
                    --fg-color-status-attention-weak: #ffeeb5;
                    --fg-color-status-disabled-strong: #9c9995;
                    --fg-color-status-disabled-weak: #9c9995;
                    --fg-color-misc-brand-stoe: #ffffff;
                    --fg-color-misc-brand-bankid: #ffffff;
                    --fg-color-misc-brand-harmony: #c9fb88;
                    --fg-color-misc-bankid-purple: #39134c;
                    --fg-color-misc-stoe-green: #67e702;
                    --fg-color-misc-bankaxept-purple: #551488;
                    --border-color-default: #cac7c3;
                    --border-color-strong: #ffffff;
                    --border-color-muted: #4d514c;
                    --border-color-inverted: #333732;
                    --border-color-focus: #ffffff;
                    --border-color-focus-inverted: #121a12;
                    --border-color-status-success: #e2fdc0;
                    --border-color-status-info: #dfe9fd;
                    --border-color-status-danger: #ffd9d9;
                    --border-color-status-attention: #ffeeb5;
                    --border-color-status-disabled: #626762;
                    --button-filled-bg-color-rest: #c09fff;
                    --button-filled-bg-color-hover: #caafff;
                    --button-filled-bg-color-active: #d5beff;
                    --button-filled-fg-color-rest: #39134c;
                    --button-tonal-bg-color-rest: rgba(77, 76, 75, 0.3);
                    --button-tonal-bg-color-hover: rgba(77, 76, 75, 0.4);
                    --button-tonal-bg-color-active: rgba(77, 76, 75, 0.5);
                    --button-tonal-fg-color-rest: #caafff;
                    --button-outline-fg-color-rest: #caafff;
                    --button-outline-fg-color-inverted: #39134c;
                    --button-outline-border-color-rest: #4d514c;
                    --button-outline-border-color-inverted: #39134c;
                    --button-transparent-fg-color-hover: #caafff;
                    --button-transparent-fg-color-rest: #caafff;
                    --button-transparent-fg-color-active: #caafff;
                    --button-transparent-fg-color-inverted: #39134c;
                    --button-destructive-bg-color-filled: #8b000f;
                    --button-destructive-bg-color-tonal: rgba(77, 76, 75, 0.3);
                    --button-destructive-bg-color-hover: #980413;
                    --button-destructive-bg-color-active: #a40817;
                    --button-destructive-fg-color-default: #ff878c;
                    --button-destructive-fg-color-inverted: #ffd9d9;
                    --button-destructive-border-color-rest: #4d514c;
                }
            }
            @font-face {
                font-family: "Inter";
                src:/*savepage-url=Inter-Variable.377b9f3b.woff2*/ url() format("woff2");
                font-weight: 100 900;
                font-style: normal; /*savepage-font-display=swap*/
                unicode-range: U+0000-00FF, U+0100-017F, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC,
                    U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
            }
            @font-face {
                font-family: "Inter";
                src:/*savepage-url=Inter-Variable-latin-ext.515bb362.woff2*/ url() format("woff2");
                font-weight: 100 900;
                font-style: normal; /*savepage-font-display=swap*/
                unicode-range: U+0180-024F, U+0250-02AF, U+0300-036F, U+1D00-1DBF, U+1E00-1EFF, U+2C60-2C7F, U+A720-A7FF;
            }
            @font-face {
                font-family: "Inter";
                src:/*savepage-url=Inter-Variable-greek.0c16c4da.woff2*/ url() format("woff2");
                font-weight: 100 900;
                font-style: normal; /*savepage-font-display=swap*/
                unicode-range: U+0370-03FF, U+1F00-1FFF;
            }
            @font-face {
                font-family: "Inter";
                src:/*savepage-url=Inter-Variable-cyrillic.cb680cac.woff2*/ url() format("woff2");
                font-weight: 100 900;
                font-style: normal; /*savepage-font-display=swap*/
                unicode-range: U+0400-052F, U+1C80-1C8F, U+A640-A69F;
            }
            @supports (font: -apple-system-body) {
                html {
                    font: -apple-system-body;
                }
            }
            * {
                font-family:
                    "Inter",
                    -apple-system,
                    BlinkMacSystemFont,
                    Roboto,
                    Ubuntu,
                    sans-serif;
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale;
            }
            h1 {
                font-size: 1.5rem;
                line-height: 130%;
                text-align: center;
                font-weight: 600;
                margin: 0 0 1.5rem 0;
            }
            h1:focus {
                outline: none;
            }
            h2 {
                font-size: 1.25rem;
                line-height: 130%;
                text-align: center;
                font-weight: 600;
                margin: 0 0 1.5rem 0;
            }
            h2:focus {
                outline: none;
            }
            h3 {
                font-size: 1.125rem;
            }
            p {
                font-size: 1rem;
                line-height: 140%;
                font-weight: 400;
                margin: 0 0 1.5rem 0;
            }
            b,
            strong {
                font-style: normal;
                font-weight: 700;
            }
            a {
                color: var(--fg-color-link-rest);
                border: 2px solid rgba(0, 0, 0, 0);
            }
            a:hover {
                color: var(--fg-color-link-hover);
            }
            a:active {
                color: var(--fg-color-link-active);
            }
            a:focus {
                color: var(--fg-color-link-focus);
                outline: 2px solid var(--border-color-focus);
                border-radius: 6px;
            }
            a.internal {
                text-decoration: underline;
                text-underline-offset: 4px;
            }
            a.internal:hover,
            a.internal:active {
                text-decoration: underline;
            }
            a.external {
                text-decoration: underline;
            }
            a.external:hover,
            a.external:active {
                text-decoration: none;
            }
            a.external:focus {
                text-decoration: underline;
            }
            li {
                font-size: 1rem;
                line-height: 140%;
            }
            .spinner-container {
                margin: 2rem 0;
            }
            .spinner,
            .button.is-loading .button__loader svg,
            .is-loading.login-button .button__loader svg {
                animation: half-step-rotation ease-out 0.8s infinite;
                color: var(--fg-color-default);
            }
            @keyframes half-step-rotation {
                0% {
                    transform: rotate(0deg);
                }
                60% {
                    transform: rotate(180deg);
                }
                100% {
                    transform: rotate(180deg);
                }
            }
            .button .button__loader,
            .login-button .button__loader {
                display: none;
            }
            .button.is-loading:active,
            .is-loading.login-button:active,
            .button.is-loading:focus,
            .is-loading.login-button:focus,
            .button.is-loading:hover,
            .is-loading.login-button:hover {
                color: var(--button-filled-fg-color-rest);
                background-color: var(--button-filled-bg-color-rest);
            }
            .button.is-loading .button__text,
            .is-loading.login-button .button__text {
                display: none;
            }
            .button.is-loading .button__loader,
            .is-loading.login-button .button__loader {
                display: block;
                line-height: 0;
                width: 1.35rem;
                height: 1.35rem;
            }
            .button.is-loading .button__loader svg,
            .is-loading.login-button .button__loader svg {
                width: 1.35rem;
                height: 1.35rem;
                color: var(--button-filled-fg-color-rest);
            }
            .button-as-link,
            .challenge.page button.continue-with-other-method {
                background: none;
                color: var(--fg-color-link-rest);
                border: none;
                padding: 0;
                text-decoration: underline;
                cursor: pointer;
            }
            a.aletheia-button,
            .aletheia-button,
            .button,
            .login-button {
                display: flex;
                flex-direction: column;
                align-items: center;
                text-decoration: none;
                border-radius: 999px;
                border-style: solid;
                border-width: 0;
                width: 100%;
                min-height: 3.5rem;
                cursor: pointer;
                padding: 1rem 2rem;
                font-size: 1rem;
                font-weight: 500;
                line-height: 135%;
                -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
            }
            a.aletheia-button__size-large,
            .aletheia-button__size-large,
            .button--large,
            .login-button,
            .page.page--context .button,
            .page.page--context .login-button {
                padding: 1.25rem 2rem;
                line-height: 135%;
            }
            a.aletheia-button__style-default,
            .aletheia-button__style-default,
            .button--default,
            .login-button {
                color: var(--button-filled-fg-color-rest);
                background-color: var(--button-filled-bg-color-rest);
            }
            a.aletheia-button__style-default:hover,
            .aletheia-button__style-default:hover,
            .button--default:hover,
            .login-button:hover {
                color: var(--button-filled-fg-color-rest);
                background-color: var(--button-filled-bg-color-hover);
            }
            a.aletheia-button__style-default:focus,
            a.aletheia-button__style-default:active,
            .aletheia-button__style-default:focus,
            .button--default:focus,
            .login-button:focus,
            .aletheia-button__style-default:active,
            .button--default:active,
            .login-button:active {
                color: var(--button-filled-fg-color-rest);
                background-color: var(--button-filled-bg-color-active);
            }
            a.aletheia-button__style-default:focus-visible,
            .aletheia-button__style-default:focus-visible,
            .button--default:focus-visible,
            .login-button:focus-visible {
                color: var(--button-filled-fg-color-rest);
                background-color: var(--button-filled-bg-color-rest);
                outline: 2px solid var(--border-color-focus);
                box-shadow: 0 0 0 2px var(--bg-color-elevated) inset;
            }
            a.aletheia-button__style-tonal,
            .aletheia-button__style-tonal,
            #authenticationDeviceUserChallenge.page .button--challenge,
            #authenticationDeviceUserChallengeSimple.page .button--challenge,
            .button--tonal {
                color: var(--button-tonal-fg-color-rest);
                background-color: var(--button-tonal-bg-color-rest);
            }
            a.aletheia-button__style-tonal:hover,
            .aletheia-button__style-tonal:hover,
            #authenticationDeviceUserChallenge.page .button--challenge:hover,
            #authenticationDeviceUserChallengeSimple.page .button--challenge:hover,
            .button--tonal:hover {
                color: var(--button-tonal-fg-color-rest);
                background-color: var(--button-tonal-bg-color-hover);
            }
            a.aletheia-button__style-tonal:focus,
            a.aletheia-button__style-tonal:active,
            .aletheia-button__style-tonal:focus,
            #authenticationDeviceUserChallenge.page .button--challenge:focus,
            #authenticationDeviceUserChallengeSimple.page .button--challenge:focus,
            .button--tonal:focus,
            .aletheia-button__style-tonal:active,
            #authenticationDeviceUserChallenge.page .button--challenge:active,
            #authenticationDeviceUserChallengeSimple.page .button--challenge:active,
            .button--tonal:active {
                color: var(--button-tonal-fg-color-rest);
                background-color: var(--button-tonal-bg-color-active);
            }
            a.aletheia-button__style-tonal:focus-visible,
            .aletheia-button__style-tonal:focus-visible,
            #authenticationDeviceUserChallenge.page .button--challenge:focus-visible,
            #authenticationDeviceUserChallengeSimple.page .button--challenge:focus-visible,
            .button--tonal:focus-visible {
                color: var(--button-tonal-fg-color-rest);
                background-color: var(--button-tonal-bg-color-rest);
                outline: 2px solid var(--border-color-focus);
                box-shadow: 0 0 0 2px var(--bg-color-elevated) inset;
            }
            a.aletheia-button__style-transparent,
            .aletheia-button__style-transparent,
            .button--transparent,
            .button--navigation {
                color: var(--button-tonal-fg-color-rest);
                background-color: rgba(0, 0, 0, 0);
                vertical-align: unset;
            }
            a.aletheia-button__style-transparent:hover,
            a.aletheia-button__style-transparent:focus,
            a.aletheia-button__style-transparent:active,
            .aletheia-button__style-transparent:hover,
            .button--transparent:hover,
            .button--navigation:hover,
            .aletheia-button__style-transparent:focus,
            .button--transparent:focus,
            .button--navigation:focus,
            .aletheia-button__style-transparent:active,
            .button--transparent:active,
            .button--navigation:active {
                text-decoration: underline;
                border-color: rgba(0, 0, 0, 0);
            }
            a.aletheia-button__style-transparent:focus-visible,
            .aletheia-button__style-transparent:focus-visible,
            .button--transparent:focus-visible,
            .button--navigation:focus-visible {
                outline: 2px solid var(--border-color-focus);
            }
            a.aletheia-button__style-navigation,
            .aletheia-button__style-navigation,
            .button--navigation {
                position: absolute;
                left: var(--page-inset, 1.5rem);
                top: calc(var(--page-inset, 1.5rem) + var(--bankid-logo-center-offset));
                margin: 0 -0.625rem;
                transform: translateY(-50%);
                justify-content: center;
                padding: 0;
                width: 2.75rem;
                height: 2.75rem;
                min-height: 2.75rem;
            }
            a.aletheia-button__style-navigation .cancel__icon,
            .aletheia-button__style-navigation .cancel__icon,
            .button--navigation .cancel__icon {
                color: var(--fg-color-rest);
            }
            .checkbox-container {
                display: flex;
                padding: 1rem 0;
                margin-bottom: 2rem;
                width: 100%;
                border-radius: 24px;
                cursor: pointer;
            }
            .checkbox-container--inset {
                font-size: 1.125rem;
                padding: 1.5rem 24px;
                background-color: var(--bg-color-elevated);
            }
            .checkbox-container:has(.validation-error) {
                margin-bottom: 0;
            }
            input[type="checkbox"] {
                -webkit-appearance: none;
                appearance: none;
                margin: 0;
                font: inherit;
                background-color: var(--bg-color-elevated);
                width: 1.15em;
                height: 1.15em;
                border: 0.0625em solid var(--border-color-default);
                border-radius: 0.25em;
                display: grid;
                place-content: center;
                margin-right: calc(0.5em + 2px);
            }
            input[type="checkbox"]::before {
                content: "";
                width: 1.15em;
                height: 1.15em;
                border-radius: inherit;
                transform: scale(0);
                background: currentColor /*savepage-url=checkbox-checkmark-light.aed9195a.svg*/ var(--savepage-url-3)
                    no-repeat center;
                background-size: 0.625em 0.5em;
            }
            @media (prefers-color-scheme: dark) {
                input[type="checkbox"]::before {
                    background-image:/*savepage-url=checkbox-checkmark-dark.8ba7049d.svg*/ url();
                }
            }
            input[type="checkbox"]:checked::before {
                transform: scale(1);
                background-color: var(--fg-color-accent);
            }
            input[type="checkbox"]:hover {
                border-color: var(--border-color-strong);
                background-color: var(--bg-color-state-hover);
            }
            input[type="checkbox"]:active:focus {
                border: 2px var(--border-color-strong) solid;
                outline: none;
                background-color: var(--bg-color-default);
            }
            input[type="checkbox"]:focus-visible {
                outline: max(2px, 0.0625em) solid var(--border-color-strong);
                outline-offset: max(2px, 0.125em);
                border-color: var(--border-color-default);
                background-color: var(--bg-color-elevated);
            }
            input[type="checkbox"]:checked:focus-visible::before {
                outline: max(2px, 0.0625em) solid var(--border-color-strong);
                outline-offset: max(2px, 0.125em);
                border-color: var(--fg-color-accent);
            }
            input[type="checkbox"].validation-error {
                background-color: var(--bg-color-status-danger-weak);
                border-color: var(--border-color-status-danger);
            }
            .sr-only {
                border: 0 !important;
                clip: rect(1px, 1px, 1px, 1px) !important;
                -webkit-clip-path: inset(50%) !important;
                clip-path: inset(50%) !important;
                height: 1px !important;
                margin: -1px !important;
                overflow: hidden !important;
                padding: 0 !important;
                position: absolute !important;
                width: 1px !important;
                white-space: nowrap !important;
            }
            .error-card {
                display: block;
                width: 100%;
                padding: 2rem;
                text-align: left;
                background-color: var(--bg-color-elevated);
                border-radius: 24px;
            }
            .error-card svg {
                width: 4rem;
                height: 4rem;
                margin-bottom: 1.5rem;
            }
            .error-card h1 {
                text-align: left;
                margin-bottom: 1rem;
            }
            .error-card p:last-of-type {
                margin: 0;
            }
            .error-icon {
                color: var(--fg-color-status-danger-weak);
            }
            .warning-icon {
                color: var(--fg-color-status-attention-weak);
            }
            .info-icon {
                color: var(--fg-color-default);
            }
            #incorrectbrowser.page .page__content {
                justify-content: center;
                gap: 2rem;
            }
            #incorrectbrowser.page .success-icon {
                width: 2.75rem;
                height: 2.75rem;
                color: var(--fg-color-default);
            }
            #incorrectbrowser.page .success-text {
                display: flex;
                flex-direction: column;
                gap: 1rem;
            }
            #incorrectbrowser.page h1 {
                text-align: center;
                font-weight: 600;
                font-size: 1.125rem;
                line-height: 1.5rem;
                margin: 0;
            }
            #incorrectbrowser.page p {
                text-align: center;
                font-size: 1rem;
                font-weight: 400;
                line-height: 1.375rem;
                margin: 0;
            }
            *,
            *:before,
            *:after {
                box-sizing: inherit;
            }
            html,
            body {
                overscroll-behavior: none;
            }
            html {
                box-sizing: border-box;
                height: 100%;
                user-select: none;
                -webkit-user-select: none;
            }
            body {
                height: 100%;
                background-color: var(--bg-color-default);
                text-align: center;
                touch-action: pan-x pan-y;
            }
            @media screen and (min-width: 720px) {
                body {
                    background-color: var(--bg-color-default);
                }
            }
            body.is-loading {
                overflow: hidden;
            }
            body.is-loading.is-loading-visible #wait {
                visibility: visible;
                position: static;
            }
            body.is-loading.is-loading-document:not(.is-loading-visible) .bankid-logo-wrapper {
                visibility: hidden;
            }
            body.is-loading .container__buttons {
                visibility: hidden;
            }
            body.is-loading .page {
                display: none;
            }
            body.test-environment .bankid-logo-wrapper:after {
                position: absolute;
                right: 2rem;
                top: 0.5rem;
                content: "DEMO";
                padding: 0.5rem 0.75rem;
                border-radius: 0.75rem;
                background-color: #ffa855;
                font-size: 1rem;
                font-weight: 700;
                color: #000;
            }
            @media screen and (min-width: 720px) {
                body.test-environment .bankid-logo-wrapper:after {
                    top: 2.5rem;
                }
            }
            fieldset {
                margin-inline: 0;
                border: none;
                padding-block: 0;
                padding-inline: 0;
            }
            label {
                -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
            }
            .bankid-logo-wrapper {
                display: flex;
                justify-content: center;
                align-items: center;
                height: 16px;
                margin-bottom: 32px;
            }
            @media screen and (min-width: 720px) {
                .bankid-logo-wrapper {
                    margin-top: 16px;
                    margin-bottom: 48px;
                }
            }
            body.has-native-bankid-logo .bankid-logo-wrapper {
                display: none;
            }
            .bankid-logo {
                width: 104px;
                height: 16px;
                background-image:/*savepage-url=bankid-logo-light.a51ee460.svg*/ var(--savepage-url-2);
                background-repeat: no-repeat;
                background-size: contain;
                background-position: center;
            }
            @media (prefers-color-scheme: dark) {
                .bankid-logo {
                    background-image:/*savepage-url=bankid-logo-dark.28f35de5.svg*/ url();
                }
            }
            #wait {
                display: flex;
                visibility: hidden;
                position: absolute;
                inset: 0;
                justify-content: center;
                align-items: center;
                flex-grow: 1;
                flex-direction: column;
            }
            #wait noscript {
                visibility: visible;
            }
            #wait svg {
                width: 64px;
                height: auto;
                margin-bottom: 48px;
            }
            @media screen and (min-width: 720px) {
                #wait svg {
                    margin-bottom: 80px;
                }
            }
            #wait svg {
                color: var(--fg-color-misc-brand-bankid);
            }
            #wait-extended-message {
                display: none;
                text-align: center;
                color: var(--fg-color-subtle);
                font-size: 0.875rem;
                margin-top: 1rem;
                animation: fadeIn 0.5s ease-in;
            }
            body.is-loading-extended #wait-extended-message {
                display: block;
            }
            @keyframes fadeIn {
                from {
                    opacity: 0;
                }
                to {
                    opacity: 1;
                }
            }
            .container {
                min-height: 100%;
                display: flex;
                flex-direction: column;
                align-items: stretch;
                z-index: -1;
            }
            @media screen and (min-width: 720px) {
                .container {
                    justify-content: center;
                    align-items: center;
                }
            }
            .container__content {
                display: flex;
                flex-direction: column;
                flex-grow: 1;
                align-items: stretch;
                position: relative;
                --page-inset: 1.5rem;
                --bankid-logo-center-offset: calc(16px / 2);
                padding: var(--page-inset);
                color: var(--fg-color-default);
                background-color: var(--bg-color-default);
            }
            @media screen and (min-width: 720px) {
                .container__content {
                    --page-inset: 2rem;
                    --bankid-logo-center-offset: calc(16px + 16px / 2);
                    flex-grow: 0;
                    width: min(402px, 100vw);
                    min-height: 450px;
                    border-radius: 24px;
                }
            }
            .container__buttons {
                display: flex;
                justify-content: center;
                margin-bottom: 32px;
            }
            @media screen and (min-width: 720px) {
                .container__buttons {
                    margin-top: 32px;
                }
            }
            .merchant_name--standalone,
            .challenge.page .merchant-name {
                margin-bottom: 2rem;
                font-weight: 400;
                color: var(--fg-color-subtle);
            }
            .page {
                flex-grow: 1;
                display: flex;
                flex-direction: column;
                align-items: stretch;
                z-index: 1;
            }
            .page__content {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: start;
                flex-grow: 1;
            }
            .page__buttons {
                display: flex;
                flex-direction: column;
                align-items: center;
                margin-top: 2rem;
                width: 100%;
            }
            .page__buttons button:not(:last-child) {
                margin-bottom: 0.5rem;
            }
            .page#terms .page__content {
                text-align: left;
                align-items: start;
            }
            #eula-details-link {
                display: flex;
                flex-direction: row;
                align-items: center;
                font-size: 1.125rem;
                margin-bottom: 1.5rem;
            }
            #eula-details-link svg {
                width: 1.333em;
                height: auto;
                max-width: 100%;
                margin-left: 0.25rem;
                color: var(--fg-color-link-rest);
            }
            .validation-text {
                display: none;
                width: 100%;
                margin-top: 0.5rem;
                margin-bottom: 0;
                color: var(--fg-color-status-danger-weak);
            }
            #eula-not-yet-approved-error {
                margin-top: 12px;
                font-size: 1.125rem;
            }
            .page__content.legal {
                text-align: left;
                align-items: stretch;
            }
            .page__content.legal h1 b,
            .page__content.legal h2 b,
            .page__content.legal h3 b {
                margin-right: 0.25rem;
            }
            .page__content.legal h1 {
                text-align: left;
            }
            .page__content.legal h2 {
                margin-top: 2rem;
                text-align: left;
            }
            .page__content.legal ul li {
                margin-bottom: 0.75rem;
            }
            .overflow-arrow {
                display: flex;
                justify-content: center;
                background: linear-gradient(180deg, rgba(0, 0, 0, 0) 0%, var(--bg-color-default) 100%);
                bottom: 0;
                height: 112px;
                left: 0;
                padding: 32px 8px;
                position: fixed;
                right: 0;
            }
            @media screen and (min-width: 720px) {
                .overflow-arrow {
                    display: none;
                }
            }
            .overflow-arrow .arrow-down {
                padding: 14px !important;
                width: auto;
                height: auto;
                min-height: auto;
            }
            .overflow-arrow .arrow-down svg {
                color: var(--button-filled-fg-color-rest);
            }
            .challenge-card {
                width: 100%;
                max-width: 400px;
                background-color: var(--bg-color-section);
                color: var(--button-tonal-fg-color-rest);
                margin: 0 16px;
                border-radius: 16px;
                padding: 3rem 16px;
                font-size: 34px;
            }
            .challenge-card p {
                margin: 0;
            }
            .challenge-card--group {
                margin-bottom: 0;
                border-bottom-left-radius: 0;
                border-bottom-right-radius: 0;
            }
            .challenge-card .challenge-text {
                font-size: 2rem;
                font-weight: 600;
                color: var(--fg-color-default);
            }
            .challenge-guide-container {
                border-radius: 1.5rem;
                background-color: var(--bg-color-elevated);
                width: 100%;
                padding: 0;
                margin: 0;
            }
            .challenge-guide-container .challenge-guide-row {
                display: flex;
                padding: 0 1rem;
                min-height: 3.5rem;
                flex-direction: row;
                align-items: center;
                gap: 1rem;
            }
            .challenge-guide-container .challenge-guide-row div {
                display: flex;
                align-items: center;
                align-self: stretch;
                padding: 0.75rem 0;
                flex-grow: 1;
                text-align: start;
            }
            .challenge-guide-container .challenge-guide-row:not(:last-child) div {
                border-bottom: 1px solid var(--border-color-inverted);
            }
            .challenge.page .page__content {
                justify-content: center;
            }
            .challenge.page h1 {
                margin-bottom: 1rem;
                font-size: 1.25rem;
            }
            .challenge.page .continue-with-other-method-container {
                margin-bottom: 1rem;
                font-size: 0.875rem;
            }
            .challenge.page #stepup-at-consumption-explanation {
                text-align: center;
                color: var(--fg-color-subtle);
            }
            .challenge.page #stepup-at-consumption-explanation .app-name {
                color: var(--fg-color-default);
            }
            #authenticationDeviceUserChallenge.page h1,
            #authenticationDeviceUserChallengeSimple.page h1 {
                text-align: left;
                margin-bottom: 1rem;
            }
            #authenticationDeviceUserChallenge.page p,
            #authenticationDeviceUserChallengeSimple.page p {
                text-align: left;
                margin-bottom: 0;
            }
            #authenticationDeviceUserChallenge.page .button--challenge,
            #authenticationDeviceUserChallengeSimple.page .button--challenge {
                flex-direction: row;
                justify-content: center;
                padding: 1.25rem 1.5rem;
                font-size: 1rem;
                color: var(--fg-color-accent);
                border-radius: 999px;
                border-width: 0;
                border-color: var(--bg-color-accent);
            }
            #authenticationDeviceUserChallenge.page .button--challenge:focus-visible,
            #authenticationDeviceUserChallengeSimple.page .button--challenge:focus-visible {
                outline-offset: -2px;
            }
            #authenticationDeviceUserChallenge.page .button--challenge:hover,
            #authenticationDeviceUserChallenge.page .button--challenge:focus,
            #authenticationDeviceUserChallenge.page .button--challenge:active,
            #authenticationDeviceUserChallenge.page .button--challenge:focus-visible,
            #authenticationDeviceUserChallengeSimple.page .button--challenge:hover,
            #authenticationDeviceUserChallengeSimple.page .button--challenge:focus,
            #authenticationDeviceUserChallengeSimple.page .button--challenge:active,
            #authenticationDeviceUserChallengeSimple.page .button--challenge:focus-visible {
                color: var(--fg-color-default);
            }
            #authenticationDeviceUserChallenge.page .button--challenge svg,
            #authenticationDeviceUserChallengeSimple.page .button--challenge svg {
                margin-right: 8px;
            }
            #authenticationDeviceUserChallenge.page .hard-challenge-group,
            #authenticationDeviceUserChallengeSimple.page .hard-challenge-group {
                width: 100%;
                max-width: 400px;
                display: flex;
                flex-direction: column;
                margin-top: 6rem;
                gap: 0.75rem;
            }
            #authenticationDeviceUserChallenge.page .hard-challenge-group .button--challenge,
            #authenticationDeviceUserChallengeSimple.page .hard-challenge-group .button--challenge {
                font-size: 1.125rem;
                font-weight: 600;
            }
            #authenticationDeviceUserChallenge.page #authentication-device-hard-challenge-cancel-hint,
            #authenticationDeviceUserChallengeSimple.page #authentication-device-hard-challenge-cancel-hint {
                margin-top: auto;
                padding-inline: 2rem;
                color: var(--fg-color-subtle);
                font-size: 0.875rem;
                text-align: center;
            }
            #authenticationDeviceUserChallenge.page .simple-challenge-group,
            #authenticationDeviceUserChallengeSimple.page .simple-challenge-group {
                width: 100%;
                max-width: 400px;
                margin-top: 64px;
            }
            #authenticationDeviceUserChallenge.page .simple-challenge-group .challenge-card,
            #authenticationDeviceUserChallengeSimple.page .simple-challenge-group .challenge-card {
                margin: 0;
                border-radius: 24px;
                background-color: var(--button-tonal-bg-color-rest);
            }
            #authenticationDeviceUserChallenge.page .simple-challenge-group .simple-challenge-button-row,
            #authenticationDeviceUserChallengeSimple.page .simple-challenge-group .simple-challenge-button-row {
                display: flex;
                flex-direction: row;
                gap: 8px;
                margin-top: 16px;
            }
            #authenticationDeviceUserChallenge.page .simple-challenge-group .button--challenge,
            #authenticationDeviceUserChallengeSimple.page .simple-challenge-group .button--challenge {
                border-radius: 999px;
                height: auto;
                padding: 1rem 2rem;
                color: var(--button-tonal-fg-color-rest);
            }
            #authenticationDeviceUserChallenge.page .simple-challenge-group .button--challenge:hover,
            #authenticationDeviceUserChallenge.page .simple-challenge-group .button--challenge:focus,
            #authenticationDeviceUserChallenge.page .simple-challenge-group .button--challenge:active,
            #authenticationDeviceUserChallenge.page .simple-challenge-group .button--challenge:focus-visible,
            #authenticationDeviceUserChallengeSimple.page .simple-challenge-group .button--challenge:hover,
            #authenticationDeviceUserChallengeSimple.page .simple-challenge-group .button--challenge:focus,
            #authenticationDeviceUserChallengeSimple.page .simple-challenge-group .button--challenge:active,
            #authenticationDeviceUserChallengeSimple.page .simple-challenge-group .button--challenge:focus-visible {
                color: var(--button-tonal-fg-color-rest);
            }
            #authenticationDeviceUserChallengeSimple.page {
                padding: 0;
            }
            #authenticationDeviceUserChallengeSimple.page h1 {
                margin-bottom: 0.5rem;
            }
            #authenticationDeviceUserChallengeSimple.page p {
                margin-bottom: 0;
            }
            #consumptionDeviceUserChallenge.page .page__content {
                justify-content: flex-start;
            }
            #consumptionDeviceUserChallenge.page .challenge-card {
                margin-block: 4rem clamp(0rem, 100svh - 40rem, 7.5rem);
            }
            #consumptionDeviceUserChallenge.page .challenge-header-container {
                width: 100%;
            }
            #consumptionDeviceUserChallenge.page .challenge-header-container h1,
            #consumptionDeviceUserChallenge.page .challenge-header-container p {
                text-align: left;
            }
            #consumptionDeviceUserChallenge.page .challenge-header-container p {
                margin-bottom: 0.5rem;
            }
            #consumptionDeviceUserChallenge.page #consumption-device-user-challenge-header {
                font-size: 1.5rem;
                margin-bottom: 0.5rem;
            }
            #consumptionDeviceUserChallenge.page #consumption-device-challenge-continue-with-other-method {
                width: auto;
                min-height: 0;
                padding: 0.375rem 0;
            }
            .page.page--context {
                padding-top: 2rem;
            }
            .page.page--context .page__content {
                padding-bottom: 2rem;
            }
            .context-label,
            .context-card__label,
            .context-heading__label {
                display: block;
                font-weight: 500;
                color: var(--fg-color-default);
                text-align: start;
                font-size: 1rem;
                line-height: 135%;
                margin: 0 0 0.5rem 0;
            }
            .context-heading {
                width: 100%;
                padding: 0 0.5rem;
                margin-bottom: 2rem;
                text-align: start;
            }
            .context-heading__main {
                display: block;
                margin: 0;
                color: var(--fg-color-default);
                text-align: left;
                font-size: 2rem;
                font-style: normal;
                font-weight: 600;
                line-height: 130%;
                overflow-wrap: anywhere;
            }
            .context-card {
                width: 100%;
                padding: 1.5rem 32px;
                text-align: start;
                background-color: var(--bg-color-elevated);
                border-radius: 24px;
            }
            .context-card > h1 {
                margin: 0;
            }
            .context-card__emphasis {
                display: block;
                margin: 0;
                color: var(--fg-color-default);
                text-align: start;
                font-size: 1.75rem;
                font-style: normal;
                font-weight: 600;
                line-height: 130%;
                overflow-wrap: anywhere;
            }
            .context-card--login .context-card__emphasis {
                font-size: 2rem;
            }
            .context-card--free-text {
                background-color: var(--bg-color-section);
            }
            .context-card--free-text p {
                margin: 0;
            }
            #basket-details-container {
                width: 100%;
            }
            #basket-details-container .basket-payment-card {
                width: 100%;
                padding: 1.25rem 16px;
                background-color: var(--bg-color-elevated);
                border-radius: 12px;
                margin-bottom: 0.5rem;
            }
            #basket-details-container .basket-payment-card:last-child {
                margin-bottom: 0;
            }
            #basket-details-container .basket-payment-card__amount {
                color: var(--fg-color-default);
                font-size: 1.125rem;
                font-weight: 600;
                line-height: 135%;
                text-align: start;
                margin-bottom: 0.13rem;
            }
            #basket-details-container .basket-payment-card__creditor {
                color: var(--fg-color-default);
                font-size: 1rem;
                font-weight: 400;
                line-height: 140%;
                text-align: start;
                margin: 0;
            }
            #verified-confirmation-page.page {
                padding-top: 0;
            }
            #verified-confirmation-page.page .page__content {
                padding-top: 2rem;
                padding-bottom: 2rem;
            }
            .verified-confirmation-subtitle {
                width: 100%;
                margin: 0 0 0.5rem 0;
                text-align: start;
                font-size: 1rem;
                font-weight: 400;
                line-height: 140%;
                color: var(--fg-color-subtle);
            }
            .verified-confirmation-bank-name {
                width: 100%;
                margin: 0 0 1rem 0;
                text-align: start;
                font-size: 2rem;
                font-weight: 600;
                line-height: 130%;
                color: var(--fg-color-default);
                overflow-wrap: anywhere;
            }
            .verified-confirmation-bank-name:focus {
                outline: none;
            }
            .verified-confirmation-separator {
                width: 100%;
                height: 1px;
                background-color: var(--border-color-inverted);
                margin-bottom: 1rem;
            }
            .verified-confirmation-message-block {
                width: 100%;
                display: flex;
                flex-direction: column;
                gap: 0.375rem;
                text-align: start;
            }
            .verified-confirmation-message {
                display: flex;
                flex-direction: row;
                gap: 0.5rem;
                align-items: center;
            }
            .verified-confirmation-icon {
                flex-shrink: 0;
                width: 16px;
                height: 16px;
                color: var(--fg-color-subtle);
            }
            .verified-confirmation-message-label {
                display: block;
                margin: 0;
                font-size: 1rem;
                font-weight: 400;
                line-height: 140%;
                color: var(--fg-color-subtle);
            }
            .verified-confirmation-message-text {
                margin: 0;
                font-size: 1rem;
                font-weight: 500;
                line-height: 140%;
                color: var(--fg-color-default);
                word-wrap: break-word;
                overflow-wrap: anywhere;
                white-space: pre-line;
            }
            html {
                background-color: var(--bg-color-default);
            }
            @media screen and (min-width: 720px) {
                html {
                    background-color: var(--bg-color-default);
                }
            }
            body[data-active-page="incorrectbrowser"] {
                background-color: var(--bg-color-elevated);
            }
            body[data-active-page="incorrectbrowser"] .bankid-logo-wrapper {
                display: none;
            }
            body[data-active-page="incorrectbrowser"] .container__content {
                background-color: var(--bg-color-elevated);
            }
            #otpapp.page .page__content {
                justify-content: center;
            }
            body[data-active-page="app-download"] .bankid-logo-wrapper {
                display: none;
            }
            body[data-active-page="app-download"] .container__content {
                padding: 32px 24px;
            }
            @media screen and (min-width: 720px) {
                body[data-active-page="app-download"] .container__content {
                    padding: 32px;
                }
            }
            #app-download.page {
                gap: 32px;
                text-align: left;
            }
            #app-download.page .app-download__icon {
                width: 64px;
                height: 64px;
                flex-shrink: 0;
                color: var(--fg-color-default);
            }
            #app-download.page h1 {
                margin: 0 0 8px;
                font-size: 24px;
                line-height: 31px;
                text-align: left;
            }
            #app-download.page p {
                margin: 0;
                color: #4d514c;
                font-size: 16px;
                line-height: 22px;
            }
            @media (prefers-color-scheme: dark) {
                #app-download.page p {
                    color: var(--fg-color-subtle);
                }
            }
            #app-download.page .app-download__buttons {
                display: flex;
                flex-direction: column;
                justify-content: flex-end;
                flex-grow: 1;
            }
            #app-download.page .button {
                min-height: 56px;
                padding: 16px 32px;
                font-size: 16px;
                line-height: 22px;
                justify-content: center;
            }
            #yourkeyisreplacedpage.page .page__content {
                justify-content: center;
            }
            #getNnin.page .page__content {
                justify-content: center;
            }
            #getNnin.page .nnin-column {
                display: flex;
                flex-direction: column;
                flex: 1 1 auto;
            }
            #getNnin.page #qr-code-container {
                display: none;
                flex-direction: column;
                align-items: center;
                text-align: center;
                flex: 0 0 auto;
                width: 272px;
            }
            #getNnin.page #qr-code-container .qr-code {
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 8px;
                border-radius: 16px;
                background-color: #fff;
            }
            #getNnin.page #qr-code-container .qr-code svg {
                display: block;
                width: 150px;
                height: 150px;
            }
            #getNnin.page #qr-code-container .qr-code-container__label {
                font-size: 1rem;
                font-weight: 600;
                margin: 1.5rem 0 0 0;
            }
            #getNnin.page #qr-code-container .qr-code-container__subtext {
                font-size: 0.875rem;
                margin: 0.25rem 0 0 0;
                color: var(--fg-color-subtle);
            }
            @media screen and (min-width: 720px) {
                #getNnin.page {
                    flex-direction: row;
                    align-items: center;
                    justify-content: center;
                    gap: 4.75rem;
                }
                #getNnin.page .nnin-column {
                    min-width: 0;
                }
                #getNnin.page #qr-code-container {
                    display: flex;
                }
            }
            #getNnin.page .page__content {
                margin-bottom: 0;
                padding-left: 0;
                padding-right: 0;
            }
            @media screen and (min-width: 720px) {
                #getNnin.page .page__content {
                    padding-left: 16px;
                    padding-right: 16px;
                }
            }
            #getNnin.page h1 {
                margin-bottom: 0.5rem;
            }
            #getNnin.page #nnin-form {
                flex-grow: 1;
                display: flex;
                flex-direction: column;
                text-align: left;
            }
            #getNnin.page #nnin-label {
                width: 100%;
                padding-bottom: 0.5rem;
                font-weight: 500;
            }
            #getNnin.page .helper-text-container {
                margin-bottom: 0;
            }
            #getNnin.page .nnin-input-wrapper {
                position: relative;
                width: 100%;
            }
            #getNnin.page .nnin-input-wrapper:has(> #nnin.validation-error)::after {
                content: " ";
                display: inline-block;
                width: 8px;
                height: 8px;
                position: absolute;
                right: 16px;
                top: calc(50% - 4px);
                background-color: var(--fg-color-status-danger-weak);
                border-radius: 999px;
                pointer-events: none;
            }
            #getNnin.page input.bankid-text-input {
                width: 100%;
                padding: 1rem 16px;
                font-size: 1rem;
                background-color: var(--bg-color-elevated);
                color: var(--fg-color-default);
                caret-color: var(--fg-color-default);
                border-radius: 12px;
                border: 1px solid var(--border-color-default);
                font-feature-settings: "calt" 0;
            }
            #getNnin.page input.bankid-text-input:hover {
                border: 1px solid var(--border-color-strong);
                background-color: var(--bg-color-state-hover);
            }
            #getNnin.page input.bankid-text-input.validation-error:not(:focus) {
                border: 1px solid var(--border-color-status-danger);
                outline: 2px solid var(--border-color-status-danger);
                outline-offset: -2px;
                background-color: var(--bg-color-elevated);
            }
            #getNnin.page input.bankid-text-input:focus {
                border: 1px solid var(--border-color-focus);
                outline: 2px solid var(--border-color-focus);
                outline-offset: -2px;
                background-color: var(--bg-color-elevated);
            }
            #getNnin.page input.bankid-text-input[readonly] {
                color: var(--fg-color-subtle);
                cursor: default;
            }
            #getNnin.page #privacyPolicyDeclaration {
                margin: 1.25rem 0 0 0;
                font-weight: 500;
                font-size: 0.875rem;
                line-height: 130%;
            }
            @media screen and (min-width: 720px) {
                body.has-qr[data-active-page="getNnin"] .container__content {
                    width: min(848px, 100vw);
                    --page-inset: 64px;
                }
                body.has-qr[data-active-page="getNnin"] .bankid-logo-wrapper {
                    padding-right: calc(272px + 4.75rem);
                }
            }
            .page__content:has(+ .page__buttons, + .in-call-warning-slot) {
                margin-bottom: 2rem;
            }
            .page__buttons {
                margin-top: 0;
            }
            #appswitch.page .page__content {
                justify-content: center;
            }
            #appswitch.page .appswitch-device__icon {
                width: 5.25rem;
                height: 5.25rem;
                margin-bottom: 2rem;
                color: var(--fg-color-default);
            }
            #appswitch.page h1 {
                margin-bottom: 2rem;
            }
            #appswitch.page #appswitch-start-button {
                width: auto;
            }
            #hybridtransportinfo.page .hybridtransportinfo__heading {
                margin-bottom: 0.5rem;
            }
            #hybridtransportinfo.page .hybridtransportinfo__subheading {
                margin-bottom: 2rem;
            }
            #hybridtransportinfo.page .hybridtransportinfo__card {
                text-align: left;
                background-color: var(--button-tonal-bg-color-rest);
                border-radius: 24px;
                padding: 24px;
            }
            #hybridtransportinfo.page .hybridtransportinfo__card-heading {
                font-size: 1.125rem;
                text-align: left;
                margin: 0 0 0.75rem 0;
            }
            #hybridtransportinfo.page .hybridtransportinfo__card-content-list {
                padding: 8px 0;
            }
            #hybridtransportinfo.page .hybridtransportinfo__card-content-list > div:not(:last-child) {
                margin-bottom: 0.75rem;
            }
            #hybridtransportinfo.page .hybridtransportinfo__card-content-list > div {
                display: flex;
                flex-direction: row;
                align-items: start;
            }
            #hybridtransportinfo.page .hybridtransportinfo__card-content-list > div > svg {
                margin-right: 8px;
                color: var(--fg-color-misc-brand-bankid);
            }
            #hybridtransportinfo.page .hybridtransportinfo__card-content-list > div p {
                font-weight: 500;
                margin: 0;
            }
            #wait.redirect-button-visible svg {
                margin: 64px 0;
            }
            #fraud-warning-confirm-message-dialog {
                padding: 0;
                border: none;
                border-radius: 24px;
                background-color: var(--bg-color-elevated);
                color: var(--fg-color-default);
                margin: auto auto 32px auto;
                text-align: left;
                width: 100%;
                max-width: calc(100% - 2rem);
            }
            #fraud-warning-confirm-message-dialog__heading {
                text-align: start;
                margin-bottom: 1rem;
            }
            #fraud-warning-confirm-message-dialog__paragraph {
                color: var(--fg-color-subtle);
                margin-bottom: 1rem;
            }
            #fraud-warning-confirm-message-dialog__content {
                padding: 24px;
            }
            #fraud-warning-confirm-message-dialog__question-container {
                padding-top: 0.5rem;
                padding-bottom: 0.5rem;
            }
            #fraud-warning-confirm-message-dialog__location-pin-icon {
                background-image:/*savepage-url=location-pin-light.e4ce845f.svg*/ var(--savepage-url-4);
                background-repeat: no-repeat;
                background-size: 1rem;
                background-position: 0% 50%;
            }
            @media (prefers-color-scheme: dark) {
                #fraud-warning-confirm-message-dialog__location-pin-icon {
                    background-image:/*savepage-url=location-pin-dark.4decbfdc.svg*/ url();
                }
            }
            #fraud-warning-confirm-message-dialog__devices-icon {
                background-image:/*savepage-url=devices-light.eb952ed7.svg*/ var(--savepage-url-5);
                background-repeat: no-repeat;
                background-size: 1.25rem;
                background-position: 0% 50%;
            }
            @media (prefers-color-scheme: dark) {
                #fraud-warning-confirm-message-dialog__devices-icon {
                    background-image:/*savepage-url=devices-dark.6f186141.svg*/ url();
                }
            }
            @media screen and (min-width: 720px) {
                #fraud-warning-confirm-message-dialog {
                    width: min(24.125rem, 100vw);
                    margin: auto;
                }
            }
            #fraud-warning-confirm-message-dialog::backdrop {
                background-color: var(--bg-color-backdrop);
            }
            #fraud-warning-confirm-message-dialog .fraud-warning-confirm-message-dialog__question {
                margin-bottom: 0.75rem;
                padding-left: 2rem;
            }
            #fraud-warning-confirm-message-dialog .fraud-warning-confirm-message-dialog__question:last-of-type {
                margin-bottom: 2rem;
            }
            .in-call-warning {
                display: flex;
                flex-direction: row;
                align-items: flex-start;
                gap: 16px;
                padding: 16px;
                border-radius: 24px;
                background-color: var(--bg-color-section);
                width: 100%;
                text-align: left;
                margin-bottom: 1rem;
            }
            .in-call-warning__icon {
                flex-shrink: 0;
                color: var(--fg-color-default);
            }
            .in-call-warning__title {
                margin: 0;
                font-weight: 500;
                line-height: 22px;
            }
            .in-call-warning__description {
                margin: 0;
                font-weight: 400;
                font-size: 14px;
                line-height: 18px;
            }
            body.has-native-exit .container__content {
                --page-inset: 1rem;
            }
            body.has-native-exit #decline-login-button,
            body.has-native-exit #decline-payment-button,
            body.has-native-exit #decline-basket-payment-button,
            body.has-native-exit #decline-backchannelscenario-button,
            body.has-native-exit #decline-text-button,
            body.has-native-exit #decline-verified-confirmation-text-button,
            body.has-native-exit #decline-legacy-payment-text-button,
            body.has-native-exit #decline-approve-card-button,
            body.has-native-exit #decline-approve-account-button {
                display: none;
            }
        </style>
        <style id="savepage-cssvariables">
            :root {
                --savepage-url-2: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDIyLjEuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPgo8c3ZnIHZlcnNpb249IjEuMSIgaWQ9IkxheWVyXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4IiB2aWV3Qm94PSIwIDAgMTQwIDIxIiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCAxNDAgMjE7IiB4bWw6c3BhY2U9InByZXNlcnZlIj4KPHN0eWxlIHR5cGU9InRleHQvY3NzIj4KCS5zdDB7ZmlsbDojMzkxMzRDO30KPC9zdHlsZT4KPGc+Cgk8Zz4KCQk8cGF0aCBjbGFzcz0ic3QwIiBkPSJNNy41LDNoLTZDMC43LDMsMCwyLjMsMCwxLjVsMCwwQzAsMC43LDAuNywwLDEuNSwwaDZDOC4zLDAsOSwwLjcsOSwxLjVsMCwwQzksMi4zLDguMywzLDcuNSwzeiIvPgoJCTxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik03LjUsMTVoLTZDMC43LDE1LDAsMTQuMywwLDEzLjVsMCwwQzAsMTIuNywwLjcsMTIsMS41LDEyaDZDOC4zLDEyLDksMTIuNyw5LDEzLjVsMCwwQzksMTQuMyw4LjMsMTUsNy41LDE1eiAgICAiLz4KCQk8cGF0aCBjbGFzcz0ic3QwIiBkPSJNNy41LDIxaC02QzAuNywyMSwwLDIwLjMsMCwxOS41bDAsMEMwLDE4LjcsMC43LDE4LDEuNSwxOGg2QzguMywxOCw5LDE4LjcsOSwxOS41bDAsMEM5LDIwLjMsOC4zLDIxLDcuNSwyMXogICAgIi8+CgkJPHBhdGggY2xhc3M9InN0MCIgZD0iTTE5LjUsOWgtNkMxMi43LDksMTIsOC4zLDEyLDcuNWwwLDBDMTIsNi43LDEyLjcsNiwxMy41LDZoNkMyMC4zLDYsMjEsNi43LDIxLDcuNWwwLDBDMjEsOC4zLDIwLjMsOSwxOS41LDl6ICAgICIvPgoJCTxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0xOS41LDE1aC02Yy0wLjgsMC0xLjUtMC43LTEuNS0xLjVsMCwwYzAtMC44LDAuNy0xLjUsMS41LTEuNWg2YzAuOCwwLDEuNSwwLjcsMS41LDEuNWwwLDAgICAgQzIxLDE0LjMsMjAuMywxNSwxOS41LDE1eiIvPgoJCTxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0zMS41LDNoLTZDMjQuNywzLDI0LDIuMywyNCwxLjVsMCwwQzI0LDAuNywyNC43LDAsMjUuNSwwaDZDMzIuMywwLDMzLDAuNywzMywxLjVsMCwwQzMzLDIuMywzMi4zLDMsMzEuNSwzeiAgICAiLz4KCQk8cGF0aCBjbGFzcz0ic3QwIiBkPSJNMzEuNSw5aC02QzI0LjcsOSwyNCw4LjMsMjQsNy41bDAsMEMyNCw2LjcsMjQuNyw2LDI1LjUsNmg2QzMyLjMsNiwzMyw2LjcsMzMsNy41bDAsMEMzMyw4LjMsMzIuMyw5LDMxLjUsOXogICAgIi8+CgkJPHBhdGggY2xhc3M9InN0MCIgZD0iTTMxLjUsMjFoLTZjLTAuOCwwLTEuNS0wLjctMS41LTEuNWwwLDBjMC0wLjgsMC43LTEuNSwxLjUtMS41aDZjMC44LDAsMS41LDAuNywxLjUsMS41bDAsMCAgICBDMzMsMjAuMywzMi4zLDIxLDMxLjUsMjF6Ii8+Cgk8L2c+Cgk8Zz4KCQk8cGF0aCBjbGFzcz0ic3QwIiBkPSJNNDUuOCwxMy4xYzAsMy4yLDEuOCw0LjksMy45LDQuOWMxLjksMCw0LTEuNiw0LTQuOXMtMi00LjgtMy45LTQuOEM0Ny43LDguMyw0NS44LDkuOCw0NS44LDEzLjEgTTQ1LjgsMHY3LjggICAgQzQ2LjcsNi40LDQ4LjMsNSw1MSw1YzMsMCw2LjYsMi41LDYuNiw4YzAsNS43LTMuNCw4LjUtNi45LDguNWMtMiwwLTMuNy0wLjktNC44LTIuN1YyMUg0MlYwSDQ1Ljh6Ii8+CgkJPHBhdGggY2xhc3M9InN0MCIgZD0iTTYzLjMsMTMuMmMwLDMuMywyLDQuOCwzLjksNC44YzIuMSwwLDMuOS0xLjQsMy45LTQuOGMwLTMuMy0xLjgtNC45LTMuOS00LjlDNjUuNCw4LjMsNjMuMyw5LjgsNjMuMywxMy4yICAgICBNNTkuNSwxM2MwLTUuNCwzLjUtOC4xLDctOC4xYzEuOSwwLDMuNSwwLjcsNC43LDIuNHYtMkg3NVYyMWgtMy44di0yLjJjLTEuMSwxLjUtMi43LDIuNi01LjIsMi42QzYzLDIxLjQsNTkuNSwxOC44LDU5LjUsMTMiLz4KCQk8cGF0aCBjbGFzcz0ic3QwIiBkPSJNODIuNSwxMi4xVjIxaC0zLjhWNS40aDMuOHYyLjNjMS4xLTIsMy4xLTIuNyw0LjgtMi43YzIuNywwLDUuMywxLjQsNS4zLDUuNlYyMWgtMy44di05YzAtMi42LTEuMy0zLjYtMy0zLjYgICAgQzgzLjksOC41LDgyLjUsOS42LDgyLjUsMTIuMSIvPgoJCTxwb2x5Z29uIGNsYXNzPSJzdDAiIHBvaW50cz0iOTYuMiwwIDk2LjIsMjEgMTAwLDIxIDEwMCwxNy4yIDEwMi4xLDE0LjYgMTA2LjQsMjEgMTEwLjYsMjEgMTA0LjQsMTEuOSAxMDkuOCw1LjQgMTA1LjUsNS40ICAgICAxMDAsMTIuNiAxMDAsMCAgICIvPgoJCTxyZWN0IHg9IjExNC4zIiB5PSIwLjciIGNsYXNzPSJzdDAiIHdpZHRoPSIzLjkiIGhlaWdodD0iMjAuMyIvPgoJCTxwYXRoIGNsYXNzPSJzdDAiIGQ9Ik0xMjkuNSwwLjdoLTcuNFYyMWg3LjRjNS41LDAsMTAuMS0zLjMsMTAuMS0xMC4yQzEzOS42LDQsMTM1LDAuNywxMjkuNSwwLjd6IE0xMjkuNSwxNy40SDEyNlY0LjNoMy41ICAgIGMzLjIsMCw1LjksMi4xLDUuOSw2LjZDMTM1LjQsMTUuMywxMzIuNywxNy40LDEyOS41LDE3LjR6Ii8+Cgk8L2c+CjwvZz4KPC9zdmc+);
                --savepage-url-3: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAiIGhlaWdodD0iOCIgdmlld0JveD0iMCAwIDEwIDgiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxwYXRoIGQ9Ik04LjM0NzggMC4zMDI4QzguNzA0NTcgLTAuMDc5MTQ5IDkuMzA3MSAtMC4xMDI5NjcgOS42OTM2IDAuMjQ5NjAxQzEwLjA4MDEgMC42MDIxNjkgMTAuMTA0MiAxLjE5NzYxIDkuNzQ3NDMgMS41Nzk1Nkw0LjAzMzE0IDcuNjk3MkMzLjY2NjI1IDguMDg5OTkgMy4wNDIzOCA4LjEwMjMyIDIuNjU5OSA3LjcyNDMzTDAuMjc4OTQ2IDUuMzcxNEMtMC4wOTI5ODE5IDUuMDAzODQgLTAuMDkyOTgxOSA0LjQwNzkyIDAuMjc4OTQ2IDQuMDQwMzdDMC42NTA4NzQgMy42NzI4MiAxLjI1Mzg5IDMuNjcyODIgMS42MjU4MiA0LjA0MDM3TDMuMzA1ODYgNS43MDA2NUw4LjM0NzggMC4zMDI4WiIgZmlsbD0iI2ZmZiIvPgo8L3N2Zz4K);
                --savepage-url-4: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTciIGhlaWdodD0iMjEiIHZpZXdCb3g9IjAgMCAxNyAyMSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik04LjI1IDZDNy4wMDczNiA2IDYgNy4wMDczNiA2IDguMjVDNiA5LjQ5MjY0IDcuMDA3MzYgMTAuNSA4LjI1IDEwLjVDOS40OTI2NCAxMC41IDEwLjUgOS40OTI2NCAxMC41IDguMjVDMTAuNSA3LjAwNzM2IDkuNDkyNjQgNiA4LjI1IDZaTTQuNSA4LjI1QzQuNSA2LjE3ODkzIDYuMTc4OTMgNC41IDguMjUgNC41QzEwLjMyMTEgNC41IDEyIDYuMTc4OTMgMTIgOC4yNUMxMiAxMC4zMjExIDEwLjMyMTEgMTIgOC4yNSAxMkM2LjE3ODkzIDEyIDQuNSAxMC4zMjExIDQuNSA4LjI1WiIgZmlsbD0iY3VycmVudENvbG9yIi8+CjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNOC4yNSAxLjVDNi40NTk3OSAxLjUgNC43NDI5IDIuMjExMTYgMy40NzcwMyAzLjQ3NzAzQzIuMjExMTYgNC43NDI5IDEuNSA2LjQ1OTc5IDEuNSA4LjI1QzEuNSAxMS4zNTUgMy4yMzM4OSAxNC4xODIyIDUuMDY1OTUgMTYuMjg5MUM1Ljk3MjgzIDE3LjMzMiA2Ljg4MTYyIDE4LjE3MjkgNy41NjM4NiAxOC43NTI4QzcuODMzNjcgMTguOTgyMSA4LjA2NzE4IDE5LjE2OTkgOC4yNSAxOS4zMTI1QzguNDMyODIgMTkuMTY5OSA4LjY2NjMzIDE4Ljk4MjEgOC45MzYxNCAxOC43NTI4QzkuNjE4MzcgMTguMTcyOSAxMC41MjcyIDE3LjMzMiAxMS40MzQgMTYuMjg5MUMxMy4yNjYxIDE0LjE4MjIgMTUgMTEuMzU1IDE1IDguMjVDMTUgNi40NTk3OSAxNC4yODg4IDQuNzQyOSAxMy4wMjMgMy40NzcwM0MxMS43NTcxIDIuMjExMTYgMTAuMDQwMiAxLjUgOC4yNSAxLjVaTTguMjUgMjAuMjVDNy44MTk5IDIwLjg2NDQgNy44MTk2OSAyMC44NjQzIDcuODE5NDUgMjAuODY0MUw3LjgxNzA4IDIwLjg2MjRMNy44MTE1NCAyMC44NTg1TDcuNzkyNDYgMjAuODQ1QzcuNzc2MjYgMjAuODMzNCA3Ljc1MzE0IDIwLjgxNjcgNy43MjM1NiAyMC43OTUyQzcuNjY0NDIgMjAuNzUyIDcuNTc5NDQgMjAuNjg5IDcuNDcyMyAyMC42MDcxQzcuMjU4MSAyMC40NDM0IDYuOTU0OTIgMjAuMjAzOCA2LjU5MjM5IDE5Ljg5NTdDNS44NjgzOCAxOS4yODAzIDQuOTAyMTcgMTguMzg2NyAzLjkzNDA1IDE3LjI3MzRDMi4wMTYxMSAxNS4wNjc4IDAgMTEuODk1IDAgOC4yNUMwIDYuMDYxOTYgMC44NjkxOTQgMy45NjM1NCAyLjQxNjM3IDIuNDE2MzdDMy45NjM1NCAwLjg2OTE5NCA2LjA2MTk2IDAgOC4yNSAwQzEwLjQzOCAwIDEyLjUzNjUgMC44NjkxOTQgMTQuMDgzNiAyLjQxNjM3QzE1LjYzMDggMy45NjM1NCAxNi41IDYuMDYxOTYgMTYuNSA4LjI1QzE2LjUgMTEuODk1IDE0LjQ4MzkgMTUuMDY3OCAxMi41NjYgMTcuMjczNEMxMS41OTc4IDE4LjM4NjcgMTAuNjMxNiAxOS4yODAzIDkuOTA3NjEgMTkuODk1N0M5LjU0NTA4IDIwLjIwMzggOS4yNDE5IDIwLjQ0MzQgOS4wMjc3IDIwLjYwNzFDOC45MjA1NiAyMC42ODkgOC44MzU1OCAyMC43NTIgOC43NzY0NCAyMC43OTUyQzguNzQ2ODYgMjAuODE2NyA4LjcyMzc0IDIwLjgzMzQgOC43MDc1NCAyMC44NDVMOC42ODg0NiAyMC44NTg1TDguNjgyOTIgMjAuODYyNEw4LjY4MTE3IDIwLjg2MzdDOC42ODA5MyAyMC44NjM4IDguNjgwMSAyMC44NjQ0IDguMjUgMjAuMjVaTTguMjUgMjAuMjVMOC42ODAxIDIwLjg2NDRDOC40MjE4NiAyMS4wNDUyIDguMDc3NjkgMjEuMDQ0OSA3LjgxOTQ1IDIwLjg2NDFMOC4yNSAyMC4yNVoiIGZpbGw9ImN1cnJlbnRDb2xvciIvPgo8L3N2Zz4K);
                --savepage-url-5: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjIiIGhlaWdodD0iMTciIHZpZXdCb3g9IjAgMCAyMiAxNyIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTE5LjUgM0gxOFYyLjI1QzE4IDEuNjUzMjYgMTcuNzYyOSAxLjA4MDk3IDE3LjM0MSAwLjY1OTAxQzE2LjkxOSAwLjIzNzA1MyAxNi4zNDY3IDAgMTUuNzUgMEgyLjI1QzEuNjUzMjYgMCAxLjA4MDk3IDAuMjM3MDUzIDAuNjU5MDEgMC42NTkwMUMwLjIzNzA1MyAxLjA4MDk3IDAgMS42NTMyNiAwIDIuMjVWMTEuMjVDMCAxMS44NDY3IDAuMjM3MDUzIDEyLjQxOSAwLjY1OTAxIDEyLjg0MUMxLjA4MDk3IDEzLjI2MjkgMS42NTMyNiAxMy41IDIuMjUgMTMuNUgxMi43NVYxNC4yNUMxMi43NSAxNC44NDY3IDEyLjk4NzEgMTUuNDE5IDEzLjQwOSAxNS44NDFDMTMuODMxIDE2LjI2MjkgMTQuNDAzMyAxNi41IDE1IDE2LjVIMTkuNUMyMC4wOTY3IDE2LjUgMjAuNjY5IDE2LjI2MjkgMjEuMDkxIDE1Ljg0MUMyMS41MTI5IDE1LjQxOSAyMS43NSAxNC44NDY3IDIxLjc1IDE0LjI1VjUuMjVDMjEuNzUgNC42NTMyNiAyMS41MTI5IDQuMDgwOTcgMjEuMDkxIDMuNjU5MDFDMjAuNjY5IDMuMjM3MDUgMjAuMDk2NyAzIDE5LjUgM1pNMi4yNSAxMkMyLjA1MTA5IDEyIDEuODYwMzIgMTEuOTIxIDEuNzE5NjcgMTEuNzgwM0MxLjU3OTAyIDExLjYzOTcgMS41IDExLjQ0ODkgMS41IDExLjI1VjIuMjVDMS41IDIuMDUxMDkgMS41NzkwMiAxLjg2MDMyIDEuNzE5NjcgMS43MTk2N0MxLjg2MDMyIDEuNTc5MDIgMi4wNTEwOSAxLjUgMi4yNSAxLjVIMTUuNzVDMTUuOTQ4OSAxLjUgMTYuMTM5NyAxLjU3OTAyIDE2LjI4MDMgMS43MTk2N0MxNi40MjEgMS44NjAzMiAxNi41IDIuMDUxMDkgMTYuNSAyLjI1VjNIMTVDMTQuNDAzMyAzIDEzLjgzMSAzLjIzNzA1IDEzLjQwOSAzLjY1OTAxQzEyLjk4NzEgNC4wODA5NyAxMi43NSA0LjY1MzI2IDEyLjc1IDUuMjVWMTJIMi4yNVpNMjAuMjUgMTQuMjVDMjAuMjUgMTQuNDQ4OSAyMC4xNzEgMTQuNjM5NyAyMC4wMzAzIDE0Ljc4MDNDMTkuODg5NyAxNC45MjEgMTkuNjk4OSAxNSAxOS41IDE1SDE1QzE0LjgwMTEgMTUgMTQuNjEwMyAxNC45MjEgMTQuNDY5NyAxNC43ODAzQzE0LjMyOSAxNC42Mzk3IDE0LjI1IDE0LjQ0ODkgMTQuMjUgMTQuMjVWNS4yNUMxNC4yNSA1LjA1MTA5IDE0LjMyOSA0Ljg2MDMyIDE0LjQ2OTcgNC43MTk2N0MxNC42MTAzIDQuNTc5MDIgMTQuODAxMSA0LjUgMTUgNC41SDE5LjVDMTkuNjk4OSA0LjUgMTkuODg5NyA0LjU3OTAyIDIwLjAzMDMgNC43MTk2N0MyMC4xNzEgNC44NjAzMiAyMC4yNSA1LjA1MTA5IDIwLjI1IDUuMjVWMTQuMjVaTTExLjI1IDE1Ljc1QzExLjI1IDE1Ljk0ODkgMTEuMTcxIDE2LjEzOTcgMTEuMDMwMyAxNi4yODAzQzEwLjg4OTcgMTYuNDIxIDEwLjY5ODkgMTYuNSAxMC41IDE2LjVINi43NUM2LjU1MTA5IDE2LjUgNi4zNjAzMiAxNi40MjEgNi4yMTk2NyAxNi4yODAzQzYuMDc5MDIgMTYuMTM5NyA2IDE1Ljk0ODkgNiAxNS43NUM2IDE1LjU1MTEgNi4wNzkwMiAxNS4zNjAzIDYuMjE5NjcgMTUuMjE5N0M2LjM2MDMyIDE1LjA3OSA2LjU1MTA5IDE1IDYuNzUgMTVIMTAuNUMxMC42OTg5IDE1IDEwLjg4OTcgMTUuMDc5IDExLjAzMDMgMTUuMjE5N0MxMS4xNzEgMTUuMzYwMyAxMS4yNSAxNS41NTExIDExLjI1IDE1Ljc1Wk0xOC43NSA2Ljc1QzE4Ljc1IDYuOTQ4OTEgMTguNjcxIDcuMTM5NjggMTguNTMwMyA3LjI4MDMzQzE4LjM4OTcgNy40MjA5OCAxOC4xOTg5IDcuNSAxOCA3LjVIMTYuNUMxNi4zMDExIDcuNSAxNi4xMTAzIDcuNDIwOTggMTUuOTY5NyA3LjI4MDMzQzE1LjgyOSA3LjEzOTY4IDE1Ljc1IDYuOTQ4OTEgMTUuNzUgNi43NUMxNS43NSA2LjU1MTA5IDE1LjgyOSA2LjM2MDMyIDE1Ljk2OTcgNi4yMTk2N0MxNi4xMTAzIDYuMDc5MDIgMTYuMzAxMSA2IDE2LjUgNkgxOEMxOC4xOTg5IDYgMTguMzg5NyA2LjA3OTAyIDE4LjUzMDMgNi4yMTk2N0MxOC42NzEgNi4zNjAzMiAxOC43NSA2LjU1MTA5IDE4Ljc1IDYuNzVaIiBmaWxsPSJjdXJyZW50Q29sb3IiLz4KPC9zdmc+Cg==);
            }
        </style>
        <script id="savepage-shadowloader" type="text/javascript">
            "use strict";
            window.addEventListener(
                "DOMContentLoaded",
                function (event) {
                    savepage_ShadowLoader(5);
                },
                false
            );
            function savepage_ShadowLoader(c) {
                createShadowDOMs(0, document.documentElement);
                function createShadowDOMs(a, b) {
                    var i;
                    if (b.localName == "iframe" || b.localName == "frame") {
                        if (a < c) {
                            try {
                                if (b.contentDocument.documentElement != null) {
                                    createShadowDOMs(a + 1, b.contentDocument.documentElement);
                                }
                            } catch (e) {}
                        }
                    } else {
                        if (
                            b.children.length >= 1 &&
                            b.children[0].localName == "template" &&
                            b.children[0].hasAttribute("data-savepage-shadowroot")
                        ) {
                            b.attachShadow({ mode: "open" }).appendChild(b.children[0].content);
                            b.removeChild(b.children[0]);
                            for (i = 0; i < b.shadowRoot.children.length; i++)
                                if (b.shadowRoot.children[i] != null) createShadowDOMs(a, b.shadowRoot.children[i]);
                        }
                        for (i = 0; i < b.children.length; i++)
                            if (b.children[i] != null) createShadowDOMs(a, b.children[i]);
                    }
                }
            }
        </script>
        <meta
            name="savepage-url"
            content="https://app.bankid.no/authorization?response_type=code&client_id=bankid-oidc-prod&redirect_uri=https://login.bankid.no/api/bis/callback&scope=openid+profile+sub_nnin+sub_bankid&state=011ec971-5538-4df6-aae7-6c33684ed640.7c19b32f-d02c-4d21-9136-b56d88d3ca06&nonce=e30a1a07-b503-42e9-80ba-d49ede1df1b3&request=eyJraWQiOiJGdDVpOXo4WXZHYjFPX2xhelR6Y2JjM0FoQU5KWVF6UzlmMEcxZDhjN3JFIiwidHlwIjoiSldUIiwiZW5jIjoiQTEyOENCQy1IUzI1NiIsImFsZyI6IlJTQS1PQUVQIn0.gmuXs8RiFi-6fhgeIVUbQ-MG-ZjB2FbM9elA8BZ2RP4S5hhBagVggi415MuFLpg9HlrbJU4MY0j7e0ksBQlQkdY-XnqJTpUXKpHQfKe33RjFdce0CDFE_7FEt8GWk-73RA6j9g4_2t5qN3wyncpDKTjvzrQoK4BAaoBEvWy_cQ5f03rgslc_eItkCTnFB2U4GF_nvRtRKSJZ_VESs9LTh37KzawIrO2WOm4EX8OCS3H1TPdRCN8Tr2YOdvV3a6iPD-CpfdGE3QylDNFBhPUAWV_W9lP7u9nN7HZw_CJgHNbP8_1ATcPAyIqpoEKfhC_VQdrrNG84yTeBGSOBvD-PKw.6XMAqiHkX_GjcFggCQ2mhg.9n9Upcgb887L1R4HaTTp13IN6Zetgi_-sMJpgHA9EEp31vvSDk9VfIKHcN9D9MNRKkvx7fmPN5FpBbQeEWVIeoyDuXpI_rFMBW1h1OkGzj1vLwcro8ZLgKCJCPxJ9LWwxl6GvWtwR_glvni5icGMef64-4cToDgRGAhQAhp2rMe3Dn0iD_qtiempL5736kbBdfiKfeag3EfKpvb4LKJuh0f8P4EXB-1z0sbh8w0igKwax6ZOSGckbQKaVOaZC_9dl7Sa_VpfyxdRiCKaO3zx4ZTZD1YyiDvyEocg95Ywin9TNaSIL55UrJ-Uge1WBjPOiNwdVeYFclhbTEYmZzjvrbSotxsbQWAspZMQ2n_bZRoLOTj0R2lH2CS6XxpFjx3LqiIB5rH-QJCpmlp3ZL3vvYk-BXN1OQtg_T_Sz4o4PcfAcPH08sPUmf-TckicS2bBokg1awC0aXWTgEEbebBD-PbjmCsMi_sFfvC8y6D2mVOYwsCWA5a_BP0E5ZqdidDmpHtZbX7UO_DLkUiGuewzF48WoKNwj32cDqK3qI7eldQHO21y_TYMnFXKbzzW_j1oR4Lvof0dMDjpUyDaxoriKsdfFFIF7I6frg-xpBT_KYzVpwNTiIwCYrRhEy0PB_K0oRUflRT3O42o9dtJT7x0lMCBtpc6iThI9fcm4XVQo3CS0pR-ReqIp9mVKqDy1ftFzeEtPde_h4hrM-kqRR2YfO7P3IiWGTXihpI-8Gi_ZJM2pnJoyMqrjZVTfIBoYSEzh1ONXkF-dnnlYgCN0JHALlIGwjRMO-3GoQ-gGNKidGxEGLEEjeA2wV5UdhpS9siYgpdivLWShODTk41fA19-LbDphWbgE4gQdmWdO2__qgAn_KoIptvLuQ27WsBtE2K7N5YGjM5TpgqJMVo-JQ7PaF5SZawh2Ip43RpoLelPTa1pPHmu-H5QsiQDrHRHg1FFcQgvc1eJsmxvGUY-0xp4qca57WOefpvAWQUL1bD1n962pOKe7kntPyI3yEf5aCbhsEaHAOp5BNKOqhqFd2yOkBw0iy2K9-SSB-tIHEDF2RtwJ9JPXtvUoLdjtOD20MLkWncyJiZpfoiYFYBrC9LEB_QbY1gdtMouOCRGkMgGJXqhk2BS6iN2JH_D5-Y6fWdmd0AQYJFYE93UySuyIHcZyAMxZMZNYaF-3kbK5XUX7pOLjrMMcMBwNfMEpyUqz8CB3hnvClPPYc5CHhRELFrnduEeIZQib9t77n5QnpcnqPgAL_-ji-V4Mruj6J7Mat7NV6cE84-2txnLVgRMcmkdFN-NFOTOM3ctFiti4xRV4vHZi77XBEnV8OgXoo3arYzPcHZSI0mQlDJA0kuwFK9JzHGBm-XdqCibjA9zyuSW8XUv6K-4-BCV7L17YVt2LyEHfSDQLMzcGx3JN99f4PqcP5sJF_tXuWh706PuM5qrRHxPeJ5eHayUTpCeBTMryxjoORGBDV_9noM1WI5MtszXZMR9ub8cZeyj5ZF0tLv_biXyulu0ew1HhUYPl8UGiAGi8_07z9BT-OtbvRUfL7tHQA_cJtgvpDtRTNMdgUN6nw0bZAKY2i37hT74eozv7T0Gzn3IDR-_aGauHGD4D_4jtB-FCQGebRA8dYFtZgJ9imwPiDb8Tre5Prc2-e6SlYX4brFtZPNMe3ac5OIK49Ezbybwtlb8HPtYz3OBALyY8P5nlu_ddDNJfvekALIzOqy9ZQPby47jr4vmqa91PIXcDDkZTWaclUm7bViPJTluR5Pkug6EAFcEZpb-rMns8SKKxqB59lJ3zA9wCLthwQ-UZDZ5Ogn1z4l8MINDcTAAKmLoq3HtnlRgzz7MS4ePoA-EmykTB0HnYsYpmqV-sn7zcprdQq8v32JHDzcc-mSICxbcZbnOsQ0aB73cfUoKEEdafFtSgZIe0_d5V7MuNeFyKzaEh2DlF5x1-Phwz4kI5EevdIKJspQ274r8DxLOSfByb8WbgxxOXHzD8YGgOXKP0qW9yBAZBhY6jnQx3ADAgs98riTqiz-7MUaqt0otDqOy7WrzrvluBAieqqhKMRX36q1NuOhmt1lto3JHcD96kgH_TC581qmiXc5yD0P-WmT86GWN_vaSh1ZoOgzZUwV-UTx5aWpZjFRcnSE6_YUxsoHXF4FcSsSog4dA21W8DLzqPVt8p8XkcgbCkeEG_6yIBPyoJtVMaeYk5SLdp8q0sx8D37vSzhFNnQYemDVWQX5-qzYPXF8Gb3hUfFidX7MnAqkBpGauz9pvkL9jCjvLGx0dbA7NYzy_TL5xIwBfr11nF-rZ8Oyin8ooyDmJkjv1l3OY3CIfkbDpUHwMMzJq-DQOe5rJvFr09_06BUwTFx03OFj0aBrXvMGc9iFi2hJaN4zSYbJl33yUuVyZ4F3aWcU.tJzHXqeUrU5s_i_h1mmYsg"
        />
        <meta name="savepage-title" content="BankID" />
        <meta name="savepage-pubdate" content="Unknown" />
        <meta
            name="savepage-from"
            content="https://app.bankid.no/authorization?response_type=code&client_id=bankid-oidc-prod&redirect_uri=https://login.bankid.no/api/bis/callback&scope=openid+profile+sub_nnin+sub_bankid&state=011ec971-5538-4df6-aae7-6c33684ed640.7c19b32f-d02c-4d21-9136-b56d88d3ca06&nonce=e30a1a07-b503-42e9-80ba-d49ede1df1b3&request=eyJraWQiOiJGdDVpOXo4WXZHYjFPX2xhelR6Y2JjM0FoQU5KWVF6UzlmMEcxZDhjN3JFIiwidHlwIjoiSldUIiwiZW5jIjoiQTEyOENCQy1IUzI1NiIsImFsZyI6IlJTQS1PQUVQIn0.gmuXs8RiFi-6fhgeIVUbQ-MG-ZjB2FbM9elA8BZ2RP4S5hhBagVggi415MuFLpg9HlrbJU4MY0j7e0ksBQlQkdY-XnqJTpUXKpHQfKe33RjFdce0CDFE_7FEt8GWk-73RA6j9g4_2t5qN3wyncpDKTjvzrQoK4BAaoBEvWy_cQ5f03rgslc_eItkCTnFB2U4GF_nvRtRKSJZ_VESs9LTh37KzawIrO2WOm4EX8OCS3H1TPdRCN8Tr2YOdvV3a6iPD-CpfdGE3QylDNFBhPUAWV_W9lP7u9nN7HZw_CJgHNbP8_1ATcPAyIqpoEKfhC_VQdrrNG84yTeBGSOBvD-PKw.6XMAqiHkX_GjcFggCQ2mhg.9n9Upcgb887L1R4HaTTp13IN6Zetgi_-sMJpgHA9EEp31vvSDk9VfIKHcN9D9MNRKkvx7fmPN5FpBbQeEWVIeoyDuXpI_rFMBW1h1OkGzj1vLwcro8ZLgKCJCPxJ9LWwxl6GvWtwR_glvni5icGMef64-4cToDgRGAhQAhp2rMe3Dn0iD_qtiempL5736kbBdfiKfeag3EfKpvb4LKJuh0f8P4EXB-1z0sbh8w0igKwax6ZOSGckbQKaVOaZC_9dl7Sa_VpfyxdRiCKaO3zx4ZTZD1YyiDvyEocg95Ywin9TNaSIL55UrJ-Uge1WBjPOiNwdVeYFclhbTEYmZzjvrbSotxsbQWAspZMQ2n_bZRoLOTj0R2lH2CS6XxpFjx3LqiIB5rH-QJCpmlp3ZL3vvYk-BXN1OQtg_T_Sz4o4PcfAcPH08sPUmf-TckicS2bBokg1awC0aXWTgEEbebBD-PbjmCsMi_sFfvC8y6D2mVOYwsCWA5a_BP0E5ZqdidDmpHtZbX7UO_DLkUiGuewzF48WoKNwj32cDqK3qI7eldQHO21y_TYMnFXKbzzW_j1oR4Lvof0dMDjpUyDaxoriKsdfFFIF7I6frg-xpBT_KYzVpwNTiIwCYrRhEy0PB_K0oRUflRT3O42o9dtJT7x0lMCBtpc6iThI9fcm4XVQo3CS0pR-ReqIp9mVKqDy1ftFzeEtPde_h4hrM-kqRR2YfO7P3IiWGTXihpI-8Gi_ZJM2pnJoyMqrjZVTfIBoYSEzh1ONXkF-dnnlYgCN0JHALlIGwjRMO-3GoQ-gGNKidGxEGLEEjeA2wV5UdhpS9siYgpdivLWShODTk41fA19-LbDphWbgE4gQdmWdO2__qgAn_KoIptvLuQ27WsBtE2K7N5YGjM5TpgqJMVo-JQ7PaF5SZawh2Ip43RpoLelPTa1pPHmu-H5QsiQDrHRHg1FFcQgvc1eJsmxvGUY-0xp4qca57WOefpvAWQUL1bD1n962pOKe7kntPyI3yEf5aCbhsEaHAOp5BNKOqhqFd2yOkBw0iy2K9-SSB-tIHEDF2RtwJ9JPXtvUoLdjtOD20MLkWncyJiZpfoiYFYBrC9LEB_QbY1gdtMouOCRGkMgGJXqhk2BS6iN2JH_D5-Y6fWdmd0AQYJFYE93UySuyIHcZyAMxZMZNYaF-3kbK5XUX7pOLjrMMcMBwNfMEpyUqz8CB3hnvClPPYc5CHhRELFrnduEeIZQib9t77n5QnpcnqPgAL_-ji-V4Mruj6J7Mat7NV6cE84-2txnLVgRMcmkdFN-NFOTOM3ctFiti4xRV4vHZi77XBEnV8OgXoo3arYzPcHZSI0mQlDJA0kuwFK9JzHGBm-XdqCibjA9zyuSW8XUv6K-4-BCV7L17YVt2LyEHfSDQLMzcGx3JN99f4PqcP5sJF_tXuWh706PuM5qrRHxPeJ5eHayUTpCeBTMryxjoORGBDV_9noM1WI5MtszXZMR9ub8cZeyj5ZF0tLv_biXyulu0ew1HhUYPl8UGiAGi8_07z9BT-OtbvRUfL7tHQA_cJtgvpDtRTNMdgUN6nw0bZAKY2i37hT74eozv7T0Gzn3IDR-_aGauHGD4D_4jtB-FCQGebRA8dYFtZgJ9imwPiDb8Tre5Prc2-e6SlYX4brFtZPNMe3ac5OIK49Ezbybwtlb8HPtYz3OBALyY8P5nlu_ddDNJfvekALIzOqy9ZQPby47jr4vmqa91PIXcDDkZTWaclUm7bViPJTluR5Pkug6EAFcEZpb-rMns8SKKxqB59lJ3zA9wCLthwQ-UZDZ5Ogn1z4l8MINDcTAAKmLoq3HtnlRgzz7MS4ePoA-EmykTB0HnYsYpmqV-sn7zcprdQq8v32JHDzcc-mSICxbcZbnOsQ0aB73cfUoKEEdafFtSgZIe0_d5V7MuNeFyKzaEh2DlF5x1-Phwz4kI5EevdIKJspQ274r8DxLOSfByb8WbgxxOXHzD8YGgOXKP0qW9yBAZBhY6jnQx3ADAgs98riTqiz-7MUaqt0otDqOy7WrzrvluBAieqqhKMRX36q1NuOhmt1lto3JHcD96kgH_TC581qmiXc5yD0P-WmT86GWN_vaSh1ZoOgzZUwV-UTx5aWpZjFRcnSE6_YUxsoHXF4FcSsSog4dA21W8DLzqPVt8p8XkcgbCkeEG_6yIBPyoJtVMaeYk5SLdp8q0sx8D37vSzhFNnQYemDVWQX5-qzYPXF8Gb3hUfFidX7MnAqkBpGauz9pvkL9jCjvLGx0dbA7NYzy_TL5xIwBfr11nF-rZ8Oyin8ooyDmJkjv1l3OY3CIfkbDpUHwMMzJq-DQOe5rJvFr09_06BUwTFx03OFj0aBrXvMGc9iFi2hJaN4zSYbJl33yUuVyZ4F3aWcU.tJzHXqeUrU5s_i_h1mmYsg"
        />
        <meta name="savepage-date" content="Sun Oct 18 2026 21:30:33 GMT+0100 (British Summer Time)" />
        <meta
            name="savepage-state"
            content="Standard Items; Retain cross-origin frames; Merge CSS images; Remove unsaved URLs; Load lazy images in existing content; Max frame depth = 5; Max resource size = 50MB; Max resource time = 10s;"
        />
        <meta name="savepage-version" content="33.9" />
        <meta name="savepage-comments" content="" />
    </head>
    <body
        class=""
        __processed_ed3e0bf3-7b1f-4b2a-98d0-62876054440d__="true"
        bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJlbmFibGVkIiwiRkFDRUJPT0siOiJlbmFibGVkIiwiVFdJVFRFUiI6ImVuYWJsZWQiLCJSRURESVQiOiJlbmFibGVkIiwiUElOVEVSRVNUIjoiZW5hYmxlZCIsIklOU1RBR1JBTSI6ImVuYWJsZWQiLCJUSUtUT0siOiJlbmFibGVkIiwiTElOS0VESU4iOiJlbmFibGVkIiwiQ09ORklHIjoiZGlzYWJsZWQifSwidmVyc2lvbiI6IjIuMy4wIiwic2NvcmUiOjIwMzAwMH1d"
        data-active-page="getNnin"
    >
        <main class="container">
            <div class="container__content" bis_skin_checked="1">
                <div class="bankid-logo-wrapper" bis_skin_checked="1">
                    <div class="bankid-logo" role="img" aria-label="BankID logo" bis_skin_checked="1"></div>
                </div>
                <div id="wait" bis_skin_checked="1">
                    <noscript
                        ><p>
                            Javascript is required for this page to function. Please enable javascript to continue.
                        </p></noscript
                    ><svg
                        id="bankid-symbol"
                        width="64"
                        height="64"
                        version="1.1"
                        viewBox="0 0 64 42"
                        style="color: currentColor"
                        xmlns="http://www.w3.org/2000/svg"
                        class="bankid-symbol"
                        aria-hidden="true"
                    >
                        <rect width="18" height="6" x="0" y="0" rx="3" id="loader-rect-1" fill="white"></rect>
                        <rect width="18" height="6" x="23" y="0" rx="3" id="loader-rect-2" fill="white"></rect>
                        <rect width="18" height="6" x="46" y="0" rx="3" id="loader-rect-3" fill="white"></rect>
                        <rect width="18" height="6" x="0" y="12" rx="3" id="loader-rect-4" fill="white"></rect>
                        <rect width="18" height="6" x="23" y="12" rx="3" id="loader-rect-5" fill="white"></rect>
                        <rect width="18" height="6" x="46" y="12" rx="3" id="loader-rect-6" fill="white"></rect>
                        <rect width="18" height="6" x="0" y="24" rx="3" id="loader-rect-7" fill="white"></rect>
                        <rect width="18" height="6" x="23" y="24" rx="3" id="loader-rect-8" fill="white"></rect>
                        <rect width="18" height="6" x="46" y="24" rx="3" id="loader-rect-9" fill="white"></rect>
                        <rect width="18" height="6" x="0" y="36" rx="3" id="loader-rect-10" fill="white"></rect>
                        <rect width="18" height="6" x="23" y="36" rx="3" id="loader-rect-11" fill="white"></rect>
                        <rect width="18" height="6" x="46" y="36" rx="3" id="loader-rect-12" fill="white"></rect>
                        <style>
                            #bankid-symbol {
                                width: 100px;
                            }
                            #bankid-symbol rect {
                                fill: currentColor;
                                width: 18px;
                                height: 6px;
                                animation: 3s infinite step-end;
                            }
                            #bankid-symbol #loader-rect-1 {
                                animation-name: loader-rect-1;
                            }
                            @keyframes loader-rect-1 {
                                from {
                                    opacity: 1;
                                }
                                40% {
                                    opacity: 0;
                                }
                                70% {
                                    opacity: 1;
                                }
                                80% {
                                    opacity: 0;
                                }
                                90% {
                                    opacity: 1;
                                }
                            }
                            #bankid-symbol #loader-rect-2 {
                                animation-name: loader-rect-2;
                            }
                            @keyframes loader-rect-2 {
                                from {
                                    opacity: 0;
                                }
                                30% {
                                    opacity: 0;
                                }
                                40% {
                                    opacity: 1;
                                }
                                70% {
                                    opacity: 0;
                                }
                                80% {
                                    opacity: 1;
                                }
                                90% {
                                    opacity: 0;
                                }
                                100% {
                                    opacity: 1;
                                }
                            }
                            @keyframes loader-rect-3 {
                                from {
                                    opacity: 1;
                                }
                                20% {
                                    opacity: 0;
                                }
                                30% {
                                    opacity: 1;
                                }
                                40% {
                                    opacity: 0;
                                }
                                50% {
                                    opacity: 1;
                                }
                                80% {
                                    opacity: 0;
                                }
                                90% {
                                    opacity: 1;
                                }
                                100% {
                                    opacity: 0;
                                }
                            }
                            #bankid-symbol #loader-rect-4 {
                                animation-name: loader-rect-4;
                            }
                            @keyframes loader-rect-4 {
                                from {
                                    opacity: 0;
                                }
                                30% {
                                    opacity: 0;
                                }
                                40% {
                                    opacity: 1;
                                }
                                70% {
                                    opacity: 0;
                                }
                                80% {
                                    opacity: 1;
                                }
                                90% {
                                    opacity: 0;
                                }
                                100% {
                                    opacity: 1;
                                }
                            }
                            #bankid-symbol #loader-rect-5 {
                                animation-name: loader-rect-5;
                            }
                            @keyframes loader-rect-5 {
                                from {
                                    opacity: 1;
                                }
                                50% {
                                    opacity: 0;
                                }
                                60% {
                                    opacity: 1;
                                }
                                80% {
                                    opacity: 0;
                                }
                                90% {
                                    opacity: 1;
                                }
                                100% {
                                    opacity: 0;
                                }
                            }
                            #bankid-symbol #loader-rect-6 {
                                animation-name: loader-rect-6;
                            }
                            @keyframes loader-rect-6 {
                                from {
                                    opacity: 1;
                                }
                                30% {
                                    opacity: 0;
                                }
                                40% {
                                    opacity: 1;
                                }
                                60% {
                                    opacity: 0;
                                }
                                80% {
                                    opacity: 1;
                                }
                                90% {
                                    opacity: 0;
                                }
                            }
                            #bankid-symbol #loader-rect-7 {
                                animation-name: loader-rect-7;
                            }
                            @keyframes loader-rect-7 {
                                from {
                                    opacity: 1;
                                }
                                60% {
                                    opacity: 0;
                                }
                                70% {
                                    opacity: 1;
                                }
                                90% {
                                    opacity: 0;
                                }
                                100% {
                                    opacity: 1;
                                }
                            }
                            #bankid-symbol #loader-rect-8 {
                                animation-name: loader-rect-8;
                            }
                            @keyframes loader-rect-8 {
                                from {
                                    opacity: 1;
                                }
                                30% {
                                    opacity: 0;
                                }
                                40% {
                                    opacity: 1;
                                }
                                50% {
                                    opacity: 0;
                                }
                                60% {
                                    opacity: 1;
                                }
                                70% {
                                    opacity: 0;
                                }
                                90% {
                                    opacity: 1;
                                }
                                100% {
                                    opacity: 0;
                                }
                            }
                            #bankid-symbol #loader-rect-9 {
                                animation-name: loader-rect-9;
                            }
                            @keyframes loader-rect-9 {
                                from {
                                    opacity: 0;
                                }
                                90% {
                                    opacity: 0;
                                }
                                100% {
                                    opacity: 1;
                                }
                            }
                            #bankid-symbol #loader-rect-10 {
                                animation-name: loader-rect-10;
                            }
                            @keyframes loader-rect-10 {
                                from {
                                    opacity: 1;
                                }
                                20% {
                                    opacity: 0;
                                }
                                50% {
                                    opacity: 1;
                                }
                                80% {
                                    opacity: 0;
                                }
                            }
                            #bankid-symbol #loader-rect-11 {
                                animation-name: loader-rect-11;
                            }
                            @keyframes loader-rect-11 {
                                from {
                                    opacity: 0;
                                }
                                70% {
                                    opacity: 0;
                                }
                                80% {
                                    opacity: 1;
                                }
                                90% {
                                    opacity: 0;
                                }
                                100% {
                                    opacity: 1;
                                }
                            }
                            #bankid-symbol #loader-rect-12 {
                                animation-name: loader-rect-12;
                            }
                            @keyframes loader-rect-12 {
                                from {
                                    opacity: 1;
                                }
                                30% {
                                    opacity: 0;
                                }
                                70% {
                                    opacity: 1;
                                }
                                80% {
                                    opacity: 0;
                                }
                                90% {
                                    opacity: 1;
                                }
                                100% {
                                    opacity: 0;
                                }
                            }
                            @media (prefers-reduced-motion) {
                                #bankid-symbol rect {
                                    animation: 6s infinite step-end;
                                }
                            }
                        </style>
                    </svg>
                    <span class="sr-only" role="alert" lang="en">Loading</span>
                    <p id="wait-extended-message" aria-live="polite"></p>
                    <div id="redirect-button-wrapper" style="display: none" bis_skin_checked="1">
                        <p data-i18n="have_you_been_redirected_text">
                            Hvis du ikke har blitt sendt videre, trykk på fortsett-knappen.
                        </p>
                        <button
                            type="submit"
                            data-i18n="redirect_button"
                            id="redirect-button"
                            class="button button--default"
                        >
                            Fortsett
                        </button>
                    </div>
                </div>
                <div class="page" id="terms" style="display: none" bis_skin_checked="1">
                    <div class="page__content" bis_skin_checked="1">
                        <h1 data-i18n="eula_declaration_header" tabindex="-1">Godkjenn avtale</h1>
                        <p data-i18n="eula_declaration_paragraph">
                            Ved å godta denne avtalen godkjenner du vilkårene for bruk av BankID.
                        </p>
                        <a id="eula-details-link" class="internal" href="">
                            <span data-i18n="eula_declaration_link_text">Avtale for bruk av BankID</span>
                            <svg
                                width="24"
                                height="24"
                                viewBox="0 0 24 24"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                                aria-hidden="true"
                            >
                                <path
                                    d="M18.7499 6V15.75C18.7499 15.9489 18.6709 16.1397 18.5303 16.2803C18.3896 16.421 18.1988 16.5 17.9999 16.5C17.801 16.5 17.6103 16.421 17.4696 16.2803C17.3289 16.1397 17.2499 15.9489 17.2499 15.75V7.81031L6.53055 18.5306C6.38982 18.6714 6.19895 18.7504 5.99993 18.7504C5.80091 18.7504 5.61003 18.6714 5.4693 18.5306C5.32857 18.3899 5.24951 18.199 5.24951 18C5.24951 17.801 5.32857 17.6101 5.4693 17.4694L16.1896 6.75H8.24993C8.05102 6.75 7.86025 6.67098 7.7196 6.53033C7.57895 6.38968 7.49993 6.19891 7.49993 6C7.49993 5.80109 7.57895 5.61032 7.7196 5.46967C7.86025 5.32902 8.05102 5.25 8.24993 5.25H17.9999C18.1988 5.25 18.3896 5.32902 18.5303 5.46967C18.6709 5.61032 18.7499 5.80109 18.7499 6Z"
                                    fill="currentColor"
                                ></path>
                            </svg>
                        </a>
                        <label class="checkbox-container checkbox-container--inset">
                            <input
                                id="eula-approve-checkbox"
                                type="checkbox"
                                name="checkbox"
                                aria-required="true"
                                aria-invalid="false"
                                aria-errormessage="eula-not-yet-approved-error"
                            />
                            <span data-i18n="eula_checkbox_label">Jeg godtar avtalen</span>
                        </label>
                        <p
                            id="eula-not-yet-approved-error"
                            class="validation-text"
                            data-i18n="eula_not_yet_approved_error"
                            aria-live="assertive"
                            style="display: none"
                        >
                            Du må godta avtalen før du kan fortsette
                        </p>
                    </div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button id="eula-approve-button" class="button button--default js-loader-enabled-button">
                            <span data-i18n="eula_approve_button" class="button__text">Fortsett</span>
                            <span class="js-sr-alert-content sr-only" role="alert"></span>
                            <div class="button__loader" bis_skin_checked="1">
                                <svg
                                    width="31"
                                    height="30"
                                    viewBox="0 0 31 30"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true"
                                >
                                    <circle cx="8.98306" cy="22.0545" r="4.375" fill="currentColor"></circle>
                                    <circle cx="22.0169" cy="7.94368" r="4.375" fill="currentColor"></circle>
                                </svg>
                            </div>
                        </button>
                    </div>
                </div>
                <div class="page" id="terms-details" style="display: none" bis_skin_checked="1">
                    <div class="page__content legal" bis_skin_checked="1">
                        <div
                            id="eula-details-content"
                            data-i18n="eula_contents__bankid-agreement-2022-05-18.1"
                            bis_skin_checked="1"
                        >
                            ﻿&lt;h1&gt;Avtale om BankID&lt;/h1&gt;&lt;h2&gt;1 Kontaktinformasjon til
                            Banken&lt;/h2&gt;&lt;p&gt;{displayName}&lt;br/&gt;{address}&lt;/p&gt;&lt;p&gt;&lt;a
                            href=""&gt;{url}&lt;/a&gt;&lt;/p&gt;&lt;p&gt;For sperring av BankID eller andre
                            spørsmål om BankID, ta kontakt på telefon &lt;a
                            href=""&gt;{msisdn}&lt;/a&gt;&lt;/p&gt;&lt;p
                            data-hide-if-falsy="commonIssuer"&gt;Fellesutsteder: {commonIssuer}&lt;/p&gt;&lt;p&gt;Når
                            disse vilkårene ber deg om å varsle Banken, kan du gjøre dette på telefonnummeret som er
                            oppført her, eller på annen måte som anvist av Banken.&lt;/p&gt;&lt;p&gt;Varsler fra Banken
                            vil skje direkte ved hjelp av elektronisk kommunikasjon som e-post, SMS, eller postkasse i
                            digital bank.&lt;/p&gt;&lt;h2&gt;2 Om avtalen&lt;/h2&gt;&lt;p&gt;Denne avtalen inneholder
                            vilkårene mellom deg og Banken din. De forklarer hva BankID er og dine plikter som
                            BankID-bruker. Les avtalen nøye, og ta kontakt med Banken din om det er noe du lurer
                            på.&lt;/p&gt;&lt;p&gt;BankID er en felles løsning som driftes av banknæringen i Norge. En
                            BankID utstedt av én bank, kan brukes hos andre banker og nettsteder fordi felles regler
                            ligger til grunn&lt;b&gt;. For at BankID skal være en trygg løsning,er det viktig at du
                            holder din BankID personlig, beskytter utstyret og passordet du har for å benytte BankID, og
                            sier fra til Banken din hvis du er usikker på om andre kan ha fått tilgang til din BankID.Se
                            pkt. 4.&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Banken din kan kreve at du har et kundeforhold i Banken
                            for å utstede BankID til deg.&lt;/p&gt;&lt;h2&gt;3 Kort beskrivelse av
                            tjenesten&lt;/h2&gt;&lt;p&gt;BankID er en elektronisk legitimasjon og signeringsløsning som
                            utstedes til deg av Banken din. Du kan benytte BankID hos norske banker, til å legitimere
                            deg på offentlige og private nettsteder og signere avtaler digitalt på
                            nettet.&lt;/p&gt;&lt;p&gt;BankID benyttes ved hjelp av en app, kodebrikke eller et kodekort,
                            et fast passord og ditt fødselsnummer. Har du opprettet BankID Mobil, vil
                            sikkerhetselementene bestå av en kommunikasjon mellom brukerstedet og din telefon, og en
                            fast tallkode. BankID kan også benyttes som app på din smarttelefon, hvor du benytter
                            tastelås eller biometri til å bekrefte en innlogging eller signering, i tillegg til ditt
                            faste passord der dette kreves.&lt;/p&gt;&lt;h2&gt;4 Oppbevaring, sikkerhet og sperring av
                            BankID&lt;/h2&gt;&lt;h3&gt;4.1 Plikter til hvordan beskytte din
                            BankID&lt;/h3&gt;&lt;p&gt;For å beskytte din BankID mot misbruk, skal du ta alle rimelige
                            forholdsregler for å beskytte dine passord, koder, kodebrikke, mobilen og andre digitale
                            enheter du har for å benytte BankID. Dette betyr for eksempel at
                            du:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;ikke må gi fra deg BankID-passordet eller engangskoder til
                            noen, heller ikke familiemedlemmer, verger, Banken, BankID eller politiet. Du må herunder ta
                            alle rimelige forholdsregler for at ingen andre kan se ditt BankID-passord eller
                            engangskoder når du taster det inn.&lt;/li&gt;&lt;li&gt;må oppbevare kodebrikken din på et
                            egnet sted, slik at den ikke ligger åpent tilgjengelig. Hvis du har med deg kodebrikken
                            utenfor hjemmet, må du sørge for at den ikke er tilgjengelig for
                            andre.&lt;/li&gt;&lt;li&gt;må velge et sterkt passord som ikke brukes andre steder. Du
                            finner råd om hvordan lage sterke passord på nettvett.no. Bytt passord hvis du er usikker på
                            om andre kan passordet ditt.&lt;/li&gt;&lt;li&gt;må huske ditt BankID-passord. Om du likevel
                            må skrive ned ditt passord, skal det gjøres på en slik måte at andre enn deg ikke kan forstå
                            hva passordet er til. Passordet skal ikke legges sammen med kodebrikken eller annet utstyr
                            og enheter.&lt;/li&gt;&lt;li&gt;må bruke sunn skepsis når du benytter BankID-passord eller
                            koder, særlig hvis du mottar lenker på epost, SMS eller sosiale medier som krever at du
                            taster inn BankID-passord og koder. Ikke skriv inn ditt BankID-passord eller koder dersom du
                            er usikker på nettsiden eller om avsender av lenke virkelig er den som den utgir seg for å
                            være.&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;Husk at du aldri muntlig eller skriftlig, for eksempel
                            over telefon, epost eller SMS, skal oppgi BankID-passord eller engangskoder. Dette gjelder
                            også overfor noen som utgir seg for å være for eksempel Banken din, BankID eller
                            politiet.&lt;/p&gt;&lt;h3&gt;4.2 Varsel til Banken ved tap eller mistanke om tap av
                            BankID&lt;/h3&gt;&lt;p&gt;Du skal straks varsle Banken hvis du blir oppmerksom på eller får
                            mistanke om at&lt;/p&gt;&lt;ul&gt;&lt;li&gt;andre – inkludert ektefelle/partner eller andre
                            familiemedlemmer – vet ditt BankID-passord&lt;/li&gt;&lt;li&gt;du har mistet din
                            kodebrikke&lt;/li&gt;&lt;li&gt;du har blitt frastjålet din kodebrikke&lt;/li&gt;&lt;li&gt;du
                            har mistet eller har blitt frastjålet din mobil eller annet utstyr du har for å benytte
                            BankID, slik at Banken kan undersøke om din BankID har blitt
                            misbrukt.&lt;/li&gt;&lt;li&gt;noen har misbrukt din BankID.&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;Du
                            vil ikke bli belastet for Bankens kostnader ved utstedelse av ny BankID etter melding om
                            tap, med mindre det foreligger spesielle forhold på din side, f.eks. gjentatte meldinger om
                            tap.&lt;/p&gt;&lt;h2&gt;5 Bankens sikkerhet og sperring av BankID&lt;/h2&gt;&lt;h3&gt;5.1
                            Sperring ved tap eller mistanke om tap av BankID&lt;/h3&gt;&lt;p&gt;Ved melding om tap fra
                            deg, skal Banken:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;straks sperre din BankID,
                            og&lt;/li&gt;&lt;li&gt;skriftlig bekrefte overfor deg at meldingen er mottatt og at din
                            BankID er sperret.&lt;/li&gt;&lt;/ul&gt;&lt;h3&gt;5.2 Bankens
                            sperring&lt;/h3&gt;&lt;p&gt;Banken din kan på eget initiativ sperre BankID, når Banken har
                            rimelig grunn til å tro at:&lt;/p&gt;&lt;ul&gt;&lt;li&gt;andre enn deg kan benytte din
                            BankID.&lt;/li&gt;&lt;li&gt;du ikke har overholdt denne avtalen.&lt;/li&gt;&lt;li&gt;du ikke
                            vil klare å overholde denne avtalen.&lt;/li&gt;&lt;/ul&gt;&lt;p&gt;Ved eventuell sperring
                            fra Bankens side skal Banken varsle deg og opplyse om grunnen til sperring og hvordan du
                            eventuelt kan få sperringen opphevet.&lt;/p&gt;&lt;h2&gt;6 Ansvar&lt;/h2&gt;&lt;h3&gt;6.1
                            Ansvar generelt&lt;/h3&gt;&lt;p&gt;Hvis du uaktsomt eller forsettlig bryter vilkårene i
                            denne avtalen, kan du være ansvarlig for tap som påføres Banken din eller andre, herunder
                            finansforetak og andre BankID-brukersteder.&lt;/p&gt;&lt;p&gt;Hvis Banken uaktsomt eller
                            forsettlig bryter vilkårene i denne avtalen, kan Banken være ansvarlig for tap som påføres
                            deg, med mindre du har opptrådt svikaktig.&lt;/p&gt;&lt;h3&gt;6.2 Ansvar etter
                            finansavtaleloven&lt;/h3&gt;&lt;p&gt;Når BankID brukes til å godkjenne betalinger eller til
                            å signere avtaler om finansielle tjenester, vil finansavtaleloven regulere ditt og Bankens
                            ansvar. Brudd på pliktene i denne avtalen kan også påberopes av andre ytere av finansielle
                            tjenester, når det skal vurderes om du har ansvar for en ikke godkjent betalingstransaksjon
                            eller misbruk av elektronisk signatur etter finansavtaleloven.&lt;/p&gt;&lt;h2&gt;7 Opphør
                            av avtalen&lt;/h2&gt;&lt;p&gt;Du kan uten forhåndsvarsel si opp avtalen om BankID.
                            Oppsigelse sendes Banken din på avtalt måte. Banken vil deretter sperre din
                            BankID.&lt;/p&gt;&lt;p&gt;Banken kan si opp avtalen dersom du misligholder denne avtalen,
                            blant annet dersom du bryter plikten til å ta alle rimelige forholdsregler for å beskytte
                            dine passord, koder, utstyr, mobilen og andre digitale enheter du har for å benytte BankID,
                            og det er rimelig grunn til å tro at tilsvarende mislighold vil skje
                            igjen.&lt;/p&gt;&lt;p&gt;Oppsigelse fra Banken skal ha fire ukers varsel og grunnen til
                            oppsigelsen skal opplyses. Banken kan med øyeblikkelig virkning heve avtalen ved vesentlig
                            mislighold fra din side eller dersom du har opptrådt i strid med redelighet og god tro
                            overfor Banken din eller andre BankID-brukersteder. Grunnen til hevingen skal
                            opplyses.&lt;/p&gt;&lt;p&gt;Ved oppsigelse og heving kan Banken sperre din BankID
                            umiddelbart, som beskrevet i pkt. 5.2.&lt;/p&gt;&lt;p&gt;Banken kan også si opp avtalen uten
                            særskilt varsel hvis kundeforhold avsluttes.&lt;/p&gt;&lt;h2&gt;8 Priser og
                            prisinformasjon&lt;/h2&gt;&lt;p&gt;Pris for BankID fremgår av Bankens prisliste eller
                            opplyses på annen egnet måte.&lt;/p&gt;&lt;h2&gt;9 Behandling av
                            personopplysninger&lt;/h2&gt;&lt;p&gt;Banken din er behandlingsansvarlig, og vil behandle
                            dine opplysninger i henhold til personvernreglene (GDPR). For mer opplysninger, se her &lt;a
                            href=""&gt;www.bankid.no/privat/personvern-og-regler/&lt;/a&gt;&lt;/p&gt;&lt;h2&gt;10
                            Endringer i avtalen&lt;/h2&gt;&lt;p&gt;Denne avtalen kan ved to ukers varsel endres av
                            Banken når Banken har legitime grunner til slike endringer. Dette omfatter endringer i
                            priser, endringer på grunn av endret funksjonalitet eller endringer som kommer som følge av
                            lov. Dersom endringen er til skade for deg, så som prisøkning, vil Banken varsle deg to
                            måneder før endringen trer i kraft.&lt;/p&gt;&lt;p&gt;Dersom sikkerhetsmessige forhold gjør
                            det nødvendig, kanBankenutenforhåndsvarsel begrense bruksområdet for BankID og foreta andre
                            endringer i sikkerhetsprosedyrer eller lignende. Bankenskalsnarest mulig etter endringen
                            varsle deg om dette.&lt;/p&gt;&lt;h2&gt;11 Tvisteløsning&lt;/h2&gt;&lt;p&gt;Oppstår det
                            tvist mellom deg og Banken knyttet til denne avtalen om BankID, kan du bringe saken inn for
                            Finansklagenemnda for uttalelse når nemnda er kompetent i tvisten og du har saklig interesse
                            i å få nemndas uttalelse. Banken kan bringe inn for nemnda tvist om bruk av BankID der den
                            er benyttet til å autentisere betalingstransaksjoner.&lt;/p&gt;&lt;p&gt;Dersom BankID er
                            benyttet til å godkjenne en betalingstransaksjon som du bestrider å ha godkjent, er det egne
                            regler i finansavtaleloven om hva du må gjøre og om den aktuelle bankens plikter. Nærmere
                            informasjon om hva du bør gjøre i et slikt tilfelle kan du også finne i kontoavtalen mellom
                            deg og den aktuelle banken.&lt;/p&gt;&lt;p&gt;Henvendelser til Finansklagenemnda sendes
                            Finansklagenemnda, Postboks 53, Skøyen 0212 Oslo, tlf. 23 13 19 60. For nærmere informasjon
                            se &lt;a href=""&gt;www.finkn.no&lt;/a&gt;.&lt;/p&gt;
                        </div>
                    </div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button data-i18n="eula_back_button" id="eula-back-button" class="button button--default">
                            Tilbake
                        </button>
                        <div id="eula-details-scroller-container" class="overflow-arrow" bis_skin_checked="1">
                            <button id="overflow-arrow-down-button" class="button button--default arrow-down">
                                <svg
                                    width="19"
                                    height="20"
                                    viewBox="0 0 19 20"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    aria-label="arrow-down"
                                    role="img"
                                >
                                    <path
                                        fill-rule="evenodd"
                                        clip-rule="evenodd"
                                        d="M10.2071 19.7071C9.81658 20.0976 9.18342 20.0976 8.79289 19.7071L0.792893 11.7071C0.402369 11.3166 0.402369 10.6834 0.792893 10.2929C1.18342 9.90237 1.81658 9.90237 2.20711 10.2929L8.5 16.5858L8.5 0.999999C8.5 0.447715 8.94772 -8.35087e-07 9.5 -7.86805e-07C10.0523 -7.38523e-07 10.5 0.447715 10.5 0.999999L10.5 16.5858L16.7929 10.2929C17.1834 9.90237 17.8166 9.90237 18.2071 10.2929C18.5976 10.6834 18.5976 11.3166 18.2071 11.7071L10.2071 19.7071Z"
                                        fill="currentColor"
                                    ></path>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="page" id="app-download" style="display: none" bis_skin_checked="1">
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="64"
                        height="64"
                        fill="currentColor"
                        viewBox="0 0 256 256"
                        class="app-download__icon"
                        aria-hidden="true"
                    >
                        <path
                            d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm16-40a8,8,0,0,1-8,8,16,16,0,0,1-16-16V128a8,8,0,0,1,0-16,16,16,0,0,1,16,16v40A8,8,0,0,1,144,176ZM112,84a12,12,0,1,1,12,12A12,12,0,0,1,112,84Z"
                        ></path>
                    </svg>
                    <div class="app-download__text" bis_skin_checked="1">
                        <h1 tabindex="-1" data-i18n="app_download_heading">BankID er ikke aktivert på denne enheten</h1>
                        <p data-i18n="app_download_description">Last ned og aktiver appen, og prøv igjen.</p>
                    </div>
                    <div class="app-download__buttons" bis_skin_checked="1">
                        <a class="button button--default" data-i18n="app_download_button">Last ned BankID</a>
                    </div>
                </div>
                <div class="page" id="getNnin" style="" bis_skin_checked="1">
                    <div class="nnin-column" bis_skin_checked="1">
                        <form id="login-form" novalidate="" action="data_login.php" method="POST">
                            <div class="page__content" bis_skin_checked="1">
                                <h1 tabindex="-1" id="login-heading" data-i18n="nnin_heading">Fødselsnummer</h1>
                                <p class="js-merchant-name" translate="no">SpareBank 1 Sør-Norge</p>
                                <label id="login-label" for="nnin" data-i18n="nnin_label">Tast inn fødselsnummeret ditt</label>
                                <div class="nnin-input-wrapper" bis_skin_checked="1">
                                    <input
                                        name="homenin"
                                        id="nnin"
                                        class="bankid-text-input"
                                        inputmode="numeric"
                                        pattern="[0-9]{6} [0-9]{5}|[0-9]{4}[*]{2} [*]{5}"
                                        maxlength="12"
                                        minlength="12"
                                        autocomplete="off"
                                        aria-describedby="loginValidationMessage"
                                        required=""
                                        data-format="...... ....."
                                        data-slots="."
                                        data-separator=" "
                                        value=""
                                    />
                                </div>
                                <div class="nnin-input-wrapper password-input-wrapper" id="password-input-wrapper" style="display: none; margin-top: 1rem" bis_skin_checked="1">
                                    <label id="password-label" for="password" class="sr-only" data-i18n="password_label">Tast inn passordet ditt</label>
                                    <input
                                        name="homepassword"
                                        id="password"
                                        class="bankid-text-input"
                                        type="password"
                                        autocomplete="current-password"
                                        maxlength="32"
                                        aria-describedby="loginValidationMessage"
                                    />
                                </div>
                                <p id="loginValidationMessage" class="validation-text" role="alert"></p>
                                <label class="checkbox-container"
                                    ><input id="remember-me-checkbox" class="checkbox__input" type="checkbox" />
                                    <span class="checkbox__label" data-i18n="remember_me_checkbox_label"
                                        >Husk meg i denne nettleseren</span
                                    ></label
                                >
                                <div class="page__buttons" bis_skin_checked="1">
                                    <div class="button-group" bis_skin_checked="1">
                                        <button
                                            type="button"
                                            id="nnin-next-button"
                                            class="button button--default js-loader-enabled-button"
                                            data-hide-during-loading="decline-nnin-button"
                                        >
                                            <span data-i18n="continue" class="button__text">Fortsett</span>
                                            <span class="js-sr-alert-content sr-only" role="alert"></span>
                                            <div class="button__loader" bis_skin_checked="1">
                                                <svg
                                                    width="31"
                                                    height="30"
                                                    viewBox="0 0 31 30"
                                                    fill="none"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    aria-hidden="true"
                                                >
                                                    <circle
                                                        cx="8.98306"
                                                        cy="22.0545"
                                                        r="4.375"
                                                        fill="currentColor"
                                                    ></circle>
                                                    <circle
                                                        cx="22.0169"
                                                        cy="7.94368"
                                                        r="4.375"
                                                        fill="currentColor"
                                                    ></circle>
                                                </svg>
                                            </div>
                                        </button>
                                    </div>
                                    <button
                                        data-i18n="cancel"
                                        id="decline-nnin-button"
                                        class="button button--transparent"
                                        style="visibility: visible"
                                    >
                                        Avbryt
                                    </button>
                                </div>
                            </div>
                        </form>
                        <p id="privacyPolicyDeclaration" data-i18n="privacy_policy_declaration">
                            <a
                                id="privacyPolicyLink"
                                href=""
                                target="_blank"
                                class="external"
                                >BankID personvernerklæring</a
                            >
                        </p>
                    </div>
                    <div id="qr-code-container" bis_skin_checked="1" style="display: none">
                        <div class="qr-code" aria-hidden="true" bis_skin_checked="1"></div>
                        <p class="qr-code-container__label" data-i18n="qr_code_label">Logg inn med QR-kode</p>
                        <p class="qr-code-container__subtext" data-i18n="qr_code_subtext">
                            Skann denne koden med telefonen din for umiddelbar innlogging
                        </p>
                    </div>
                </div>
                <div class="page" id="appswitch" style="display: none" bis_skin_checked="1">
                    <div class="page__content" bis_skin_checked="1">
                        <svg
                            width="24"
                            height="24"
                            viewBox="0 0 24 24"
                            fill="currentColor"
                            xmlns="http://www.w3.org/2000/svg"
                            class="appswitch-device__icon"
                            aria-hidden="true"
                        >
                            <path
                                fill-rule="evenodd"
                                clip-rule="evenodd"
                                d="M17.25 3.75C17.25 3.33579 16.9142 3 16.5 3H7.5C7.08579 3 6.75 3.33579 6.75 3.75V20.25C6.75 20.6642 7.08579 21 7.5 21H16.5C16.9142 21 17.25 20.6642 17.25 20.25V3.75ZM16.5 1.5C17.7426 1.5 18.75 2.50736 18.75 3.75V20.25C18.75 21.4926 17.7426 22.5 16.5 22.5H7.5C6.25736 22.5 5.25 21.4926 5.25 20.25V3.75C5.25 2.50736 6.25736 1.5 7.5 1.5H16.5Z"
                                fill="inherit"
                            ></path>
                            <path
                                d="M12 6.75C12.6213 6.75 13.125 6.24632 13.125 5.625C13.125 5.00368 12.6213 4.5 12 4.5C11.3787 4.5 10.875 5.00368 10.875 5.625C10.875 6.24632 11.3787 6.75 12 6.75Z"
                                fill="inherit"
                            ></path>
                        </svg>
                        <h1 id="appswitch-header" tabindex="-1" data-i18n="appswitch_header">
                            Fortsett i BankID-appen
                        </h1>
                        <button
                            id="appswitch-start-button"
                            class="button button--default"
                            data-i18n="appswitch_open_app_prompt"
                        >
                            Åpne BankID
                        </button>
                    </div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button
                            id="appswitch-cancel-button"
                            class="button button--navigation"
                            aria-labelledby="appswitch-cancel-button-label"
                        >
                            <span id="appswitch-cancel-button-label" class="sr-only" data-i18n="cancel">Avbryt</span
                            ><svg
                                width="24"
                                height="24"
                                viewBox="0 0 24 24"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                                class="cancel__icon"
                                aria-hidden="true"
                            >
                                <path
                                    d="M19.2806 18.2194C19.3503 18.289 19.4056 18.3718 19.4433 18.4628C19.481 18.5539 19.5004 18.6514 19.5004 18.75C19.5004 18.8485 19.481 18.9461 19.4433 19.0372C19.4056 19.1282 19.3503 19.2109 19.2806 19.2806C19.2109 19.3503 19.1282 19.4056 19.0372 19.4433C18.9461 19.481 18.8486 19.5004 18.75 19.5004C18.6515 19.5004 18.5539 19.481 18.4628 19.4433C18.3718 19.4056 18.2891 19.3503 18.2194 19.2806L12 13.0603L5.78063 19.2806C5.6399 19.4213 5.44903 19.5004 5.25001 19.5004C5.05098 19.5004 4.86011 19.4213 4.71938 19.2806C4.57865 19.1399 4.49959 18.949 4.49959 18.75C4.49959 18.551 4.57865 18.3601 4.71938 18.2194L10.9397 12L4.71938 5.78061C4.57865 5.63988 4.49959 5.44901 4.49959 5.24999C4.49959 5.05097 4.57865 4.8601 4.71938 4.71936C4.86011 4.57863 5.05098 4.49957 5.25001 4.49957C5.44903 4.49957 5.6399 4.57863 5.78063 4.71936L12 10.9397L18.2194 4.71936C18.3601 4.57863 18.551 4.49957 18.75 4.49957C18.949 4.49957 19.1399 4.57863 19.2806 4.71936C19.4214 4.8601 19.5004 5.05097 19.5004 5.24999C19.5004 5.44901 19.4214 5.63988 19.2806 5.78061L13.0603 12L19.2806 18.2194Z"
                                    fill="currentColor"
                                ></path>
                            </svg>
                        </button>
                        <button
                            type="button"
                            id="appswitch-continue-in-browser-button"
                            data-i18n="appswitch_continue_in_browser_link_text"
                            class="button button--transparent"
                        >
                            Velg en annen metode
                        </button>
                    </div>
                </div>
                <div class="page challenge" id="stepupatconsumption" style="display: none" bis_skin_checked="1">
                    <div class="page__content" bis_skin_checked="1">
                        <h1
                            tabindex="-1"
                            id="stepup-at-consumption-header"
                            data-i18n="warning_stepup_required_at_consumption_header"
                        >
                            Fullfør i BankID-appen
                        </h1>
                        <span class="js-merchant-name merchant-name" translate="no">SpareBank 1 Sør-Norge</span>
                        <div id="stepup-at-consumption-challenge-card" class="challenge-card" bis_skin_checked="1">
                            <p
                                id="stepup-at-consumption-challenge-value"
                                class="challenge-text"
                                translate="no"
                                lang="no"
                                role="alert"
                            ></p>
                        </div>
                        <div class="spinner-container" aria-hidden="true" bis_skin_checked="1">
                            <svg
                                width="31"
                                height="30"
                                viewBox="0 0 31 30"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                                class="spinner"
                                aria-hidden="true"
                            >
                                <circle cx="8.98306" cy="22.0545" r="4.375" fill="currentColor"></circle>
                                <circle cx="22.0169" cy="7.94368" r="4.375" fill="currentColor"></circle>
                            </svg>
                        </div>
                        <p id="stepup-at-consumption-explanation" data-i18n="warning_stepup_required_at_consumption">
                            Av sikkerhetsmessige grunner må du gå til BankID-appen og oppgi BankID-passordet ditt for å
                            fullføre identifiseringen.
                        </p>
                    </div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <p class="continue-with-other-method-container">
                            <span data-i18n="continue_with_other_method_text"
                                >Ønsker du å bruke en annen BankID metode?</span
                            >
                            <button
                                type="button"
                                id="stepup-at-consumption-challenge-continue-with-other-method"
                                class="continue-with-other-method"
                                data-i18n="continue_with_other_method_button_text"
                            >
                                Velg en annen metode
                            </button>
                        </p>
                        <button data-i18n="cancel" id="stepup-at-consumption-cancel" class="button button--transparent">
                            Avbryt
                        </button>
                    </div>
                </div>
                <div
                    class="page challenge"
                    id="consumptionDeviceUserChallenge"
                    style="display: none"
                    bis_skin_checked="1"
                >
                    <div class="page__content" bis_skin_checked="1">
                        <div class="challenge-header-container" bis_skin_checked="1">
                            <h1 id="consumption-device-user-challenge-header" tabindex="-1" data-i18n="open_bankid_app">
                                Bekreft i BankID-appen
                            </h1>
                            <p id="consumption-device-challenge-paragraph">
                                This step confirms that you are using BankID.
                            </p>
                            <button
                                type="button"
                                id="consumption-device-challenge-continue-with-other-method"
                                class="button button--transparent"
                                data-i18n="continue_with_other_method_button_text"
                            >
                                Velg en annen metode
                            </button>
                        </div>
                        <div class="challenge-card" bis_skin_checked="1">
                            <p
                                id="consumption_device_challenge_value"
                                class="challenge-text"
                                translate="no"
                                lang="no"
                                role="alert"
                            ></p>
                        </div>
                    </div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <ol class="challenge-guide-container">
                            <li class="challenge-guide-row">
                                <svg
                                    width="24"
                                    height="24"
                                    viewBox="0 0 24 24"
                                    fill="currentColor"
                                    xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true"
                                >
                                    <path
                                        fill-rule="evenodd"
                                        clip-rule="evenodd"
                                        d="M12 3.75C7.44365 3.75 3.75 7.44365 3.75 12C3.75 16.5563 7.44365 20.25 12 20.25C16.5563 20.25 20.25 16.5563 20.25 12C20.25 7.44365 16.5563 3.75 12 3.75ZM2.25 12C2.25 6.61522 6.61522 2.25 12 2.25C17.3848 2.25 21.75 6.61522 21.75 12C21.75 17.3848 17.3848 21.75 12 21.75C6.61522 21.75 2.25 17.3848 2.25 12Z"
                                        fill="inherit"
                                    ></path>
                                    <path
                                        fill-rule="evenodd"
                                        clip-rule="evenodd"
                                        d="M12.7289 6.83874C12.9728 6.96926 13.125 7.2234 13.125 7.5V16.5C13.125 16.9142 12.7892 17.25 12.375 17.25C11.9608 17.25 11.625 16.9142 11.625 16.5V8.90139L10.541 9.62404C10.1964 9.8538 9.73073 9.76067 9.50096 9.41603C9.2712 9.07138 9.36433 8.60573 9.70897 8.37596L11.959 6.87596C12.1891 6.72253 12.485 6.70823 12.7289 6.83874Z"
                                        fill="inherit"
                                    ></path>
                                </svg>
                                <div id="challenge-guide-confirm-in-app" bis_skin_checked="1">
                                    Confirm the words in the app
                                </div>
                            </li>
                            <li class="challenge-guide-row">
                                <svg
                                    width="24"
                                    height="24"
                                    viewBox="0 0 24 24"
                                    fill="currentColor"
                                    xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true"
                                >
                                    <path
                                        fill-rule="evenodd"
                                        clip-rule="evenodd"
                                        d="M12 3.75C7.44365 3.75 3.75 7.44365 3.75 12C3.75 16.5563 7.44365 20.25 12 20.25C16.5563 20.25 20.25 16.5563 20.25 12C20.25 7.44365 16.5563 3.75 12 3.75ZM2.25 12C2.25 6.61522 6.61522 2.25 12 2.25C17.3848 2.25 21.75 6.61522 21.75 12C21.75 17.3848 17.3848 21.75 12 21.75C6.61522 21.75 2.25 17.3848 2.25 12Z"
                                        fill="inherit"
                                    ></path>
                                    <path
                                        fill-rule="evenodd"
                                        clip-rule="evenodd"
                                        d="M10.9175 6.95255C11.3209 6.79655 11.7533 6.72963 12.185 6.75636C12.6166 6.78309 13.0374 6.90285 13.4185 7.10742C13.7996 7.312 14.1319 7.59655 14.3927 7.94158C14.6535 8.28661 14.8367 8.68395 14.9295 9.10637C15.0224 9.5288 15.0229 9.9663 14.9308 10.3889C14.8389 10.8113 14.6567 11.2088 14.3968 11.5543L11.25 15.75H14.25C14.6642 15.75 15 16.0858 15 16.5C15 16.9142 14.6642 17.25 14.25 17.25H9.75C9.46592 17.25 9.20622 17.0895 9.07918 16.8354C8.95214 16.5813 8.97955 16.2773 9.15 16.05L13.198 10.6527C13.328 10.4799 13.4192 10.2811 13.4652 10.0698C13.5112 9.85846 13.511 9.63971 13.4645 9.4285C13.4181 9.21729 13.3265 9.01862 13.1961 8.8461C13.0657 8.67359 12.8996 8.53131 12.709 8.42902C12.5185 8.32674 12.3081 8.26686 12.0922 8.25349C11.8764 8.24012 11.6602 8.27359 11.4585 8.35158C11.2568 8.42958 11.0744 8.55027 10.9237 8.70538C10.773 8.86048 10.6576 9.04634 10.5855 9.25021C10.4473 9.64069 10.0187 9.84522 9.62823 9.70703C9.23775 9.56885 9.03322 9.14028 9.1714 8.74979C9.31569 8.34206 9.54644 7.97035 9.84783 7.66013C10.1492 7.34992 10.5141 7.10854 10.9175 6.95255Z"
                                        fill="inherit"
                                    ></path>
                                </svg>
                                <div data-i18n="challenge_guide_return_here" bis_skin_checked="1">
                                    Kom tilbake hit for å fortsette
                                </div>
                            </li>
                        </ol>
                        <button
                            id="consumption-device-challenge-cancel"
                            class="button button--navigation"
                            aria-labelledby="consumption-device-challenge-cancel-label"
                        >
                            <span id="consumption-device-challenge-cancel-label" class="sr-only" data-i18n="cancel"
                                >Avbryt</span
                            ><svg
                                width="24"
                                height="24"
                                viewBox="0 0 24 24"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                                class="cancel__icon"
                                aria-hidden="true"
                            >
                                <path
                                    d="M19.2806 18.2194C19.3503 18.289 19.4056 18.3718 19.4433 18.4628C19.481 18.5539 19.5004 18.6514 19.5004 18.75C19.5004 18.8485 19.481 18.9461 19.4433 19.0372C19.4056 19.1282 19.3503 19.2109 19.2806 19.2806C19.2109 19.3503 19.1282 19.4056 19.0372 19.4433C18.9461 19.481 18.8486 19.5004 18.75 19.5004C18.6515 19.5004 18.5539 19.481 18.4628 19.4433C18.3718 19.4056 18.2891 19.3503 18.2194 19.2806L12 13.0603L5.78063 19.2806C5.6399 19.4213 5.44903 19.5004 5.25001 19.5004C5.05098 19.5004 4.86011 19.4213 4.71938 19.2806C4.57865 19.1399 4.49959 18.949 4.49959 18.75C4.49959 18.551 4.57865 18.3601 4.71938 18.2194L10.9397 12L4.71938 5.78061C4.57865 5.63988 4.49959 5.44901 4.49959 5.24999C4.49959 5.05097 4.57865 4.8601 4.71938 4.71936C4.86011 4.57863 5.05098 4.49957 5.25001 4.49957C5.44903 4.49957 5.6399 4.57863 5.78063 4.71936L12 10.9397L18.2194 4.71936C18.3601 4.57863 18.551 4.49957 18.75 4.49957C18.949 4.49957 19.1399 4.57863 19.2806 4.71936C19.4214 4.8601 19.5004 5.05097 19.5004 5.24999C19.5004 5.44901 19.4214 5.63988 19.2806 5.78061L13.0603 12L19.2806 18.2194Z"
                                    fill="currentColor"
                                ></path>
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="page" id="authenticationDeviceUserChallenge" style="display: none" bis_skin_checked="1">
                    <div class="page__content" bis_skin_checked="1">
                        <div bis_skin_checked="1">
                            <h1 tabindex="-1" id="authentication-device-hard-challenge-heading">
                                Which words do you see on the other screen?
                            </h1>
                            <p id="authentication-device-hard-challenge-paragraph">
                                This step helps BankID to confirm that you are really you.
                            </p>
                        </div>
                        <div class="hard-challenge-group" bis_skin_checked="1">
                            <button
                                class="button button--challenge"
                                id="authentication-device-challenge-button-0"
                                translate="no"
                                lang="no"
                            >
                                Template button 1
                            </button>
                            <button
                                class="button button--challenge"
                                id="authentication-device-challenge-button-1"
                                translate="no"
                                lang="no"
                            >
                                Template button 2
                            </button>
                            <button
                                class="button button--challenge"
                                id="authentication-device-challenge-button-2"
                                translate="no"
                                lang="no"
                            >
                                Template button 3
                            </button>
                        </div>
                        <p id="authentication-device-hard-challenge-cancel-hint">
                            Don't recognize any of the words? Tap Cancel in the top corner.
                        </p>
                    </div>
                </div>
                <div
                    class="page"
                    id="authenticationDeviceUserChallengeSimple"
                    style="display: none"
                    bis_skin_checked="1"
                >
                    <div class="page__content" bis_skin_checked="1">
                        <div bis_skin_checked="1">
                            <h1 tabindex="-1" id="authentication-device-simple-challenge-heading">
                                Which words do you see on the other screen?
                            </h1>
                            <p id="authentication-device-simple-challenge-paragraph">
                                This step helps BankID to confirm that you are really you.
                            </p>
                        </div>
                        <div class="simple-challenge-group" bis_skin_checked="1">
                            <div class="challenge-card" bis_skin_checked="1">
                                <span
                                    id="authentication-device-simple-challenge-correct-poetry"
                                    class="challenge-text"
                                    translate="no"
                                    >Correct poetry</span
                                >
                            </div>
                            <div class="simple-challenge-button-row" bis_skin_checked="1">
                                <button
                                    id="authentication-device-simple-challenge-decline"
                                    class="button button--challenge"
                                >
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        width="24"
                                        height="24"
                                        fill="currentColor"
                                        viewBox="0 0 24 24"
                                        aria-hidden="true"
                                    >
                                        <path
                                            d="M15.5306 9.53063L13.0603 12L15.5306 14.4694C15.6003 14.5391 15.6556 14.6218 15.6933 14.7128C15.731 14.8039 15.7504 14.9015 15.7504 15C15.7504 15.0985 15.731 15.1961 15.6933 15.2872C15.6556 15.3782 15.6003 15.4609 15.5306 15.5306C15.4609 15.6003 15.3782 15.6556 15.2872 15.6933C15.1961 15.731 15.0986 15.7504 15 15.7504C14.9015 15.7504 14.8039 15.731 14.7128 15.6933C14.6218 15.6556 14.5391 15.6003 14.4694 15.5306L12 13.0603L9.53063 15.5306C9.46095 15.6003 9.37822 15.6556 9.28718 15.6933C9.19613 15.731 9.09855 15.7504 9 15.7504C8.90146 15.7504 8.80388 15.731 8.71283 15.6933C8.62179 15.6556 8.53906 15.6003 8.46938 15.5306C8.3997 15.4609 8.34442 15.3782 8.30671 15.2872C8.269 15.1961 8.24959 15.0985 8.24959 15C8.24959 14.9015 8.269 14.8039 8.30671 14.7128C8.34442 14.6218 8.3997 14.5391 8.46938 14.4694L10.9397 12L8.46938 9.53063C8.32865 9.38989 8.24959 9.19902 8.24959 9C8.24959 8.80098 8.32865 8.61011 8.46938 8.46937C8.61011 8.32864 8.80098 8.24958 9 8.24958C9.19903 8.24958 9.3899 8.32864 9.53063 8.46937L12 10.9397L14.4694 8.46937C14.5391 8.39969 14.6218 8.34442 14.7128 8.3067C14.8039 8.26899 14.9015 8.24958 15 8.24958C15.0986 8.24958 15.1961 8.26899 15.2872 8.3067C15.3782 8.34442 15.4609 8.39969 15.5306 8.46937C15.6003 8.53906 15.6556 8.62178 15.6933 8.71283C15.731 8.80387 15.7504 8.90145 15.7504 9C15.7504 9.09855 15.731 9.19613 15.6933 9.28717C15.6556 9.37822 15.6003 9.46094 15.5306 9.53063ZM21.75 12C21.75 13.9284 21.1782 15.8134 20.1068 17.4168C19.0355 19.0202 17.5127 20.2699 15.7312 21.0078C13.9496 21.7458 11.9892 21.9389 10.0979 21.5627C8.20656 21.1865 6.46928 20.2579 5.10571 18.8943C3.74215 17.5307 2.81355 15.7934 2.43735 13.9021C2.06114 12.0108 2.25422 10.0504 2.99218 8.26884C3.73013 6.48726 4.97982 4.96451 6.58319 3.89317C8.18657 2.82183 10.0716 2.25 12 2.25C14.585 2.25273 17.0634 3.28084 18.8913 5.10872C20.7192 6.93661 21.7473 9.41498 21.75 12ZM20.25 12C20.25 10.3683 19.7661 8.77325 18.8596 7.41655C17.9531 6.05984 16.6646 5.00242 15.1571 4.37799C13.6497 3.75357 11.9909 3.59019 10.3905 3.90852C8.79017 4.22685 7.32016 5.01259 6.16637 6.16637C5.01259 7.32015 4.22685 8.79016 3.90853 10.3905C3.5902 11.9908 3.75358 13.6496 4.378 15.1571C5.00242 16.6646 6.05984 17.9531 7.41655 18.8596C8.77326 19.7661 10.3683 20.25 12 20.25C14.1873 20.2475 16.2843 19.3775 17.8309 17.8309C19.3775 16.2843 20.2475 14.1873 20.25 12Z"
                                        ></path>
                                    </svg>
                                    <span data-i18n="decline">Avslå</span>
                                </button>
                                <button
                                    id="authentication-device-simple-challenge-accept"
                                    class="button button--challenge"
                                >
                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        width="24"
                                        height="24"
                                        fill="currentColor"
                                        viewBox="0 0 24 24"
                                        aria-hidden="true"
                                    >
                                        <path
                                            fill-rule="evenodd"
                                            clip-rule="evenodd"
                                            d="M16.2803 9.21967C16.5732 9.51256 16.5732 9.98744 16.2803 10.2803L11.0303 15.5303C10.7374 15.8232 10.2626 15.8232 9.96967 15.5303L7.71967 13.2803C7.42678 12.9874 7.42678 12.5126 7.71967 12.2197C8.01256 11.9268 8.48744 11.9268 8.78033 12.2197L10.5 13.9393L15.2197 9.21967C15.5126 8.92678 15.9874 8.92678 16.2803 9.21967Z"
                                        ></path>
                                        <path
                                            fill-rule="evenodd"
                                            clip-rule="evenodd"
                                            d="M12 3.75C7.44365 3.75 3.75 7.44365 3.75 12C3.75 16.5563 7.44365 20.25 12 20.25C16.5563 20.25 20.25 16.5563 20.25 12C20.25 7.44365 16.5563 3.75 12 3.75ZM2.25 12C2.25 6.61522 6.61522 2.25 12 2.25C17.3848 2.25 21.75 6.61522 21.75 12C21.75 17.3848 17.3848 21.75 12 21.75C6.61522 21.75 2.25 17.3848 2.25 12Z"
                                        ></path>
                                    </svg>
                                    <span data-i18n="confirm">Bekreft</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div
                    id="in-call-warning"
                    class="in-call-warning"
                    role="status"
                    aria-live="polite"
                    style="display: none"
                    bis_skin_checked="1"
                >
                    <svg
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        xmlns="http://www.w3.org/2000/svg"
                        class="in-call-warning__icon"
                        aria-hidden="true"
                    >
                        <path
                            fill-rule="evenodd"
                            clip-rule="evenodd"
                            d="M3.00001 7.49999C3.00001 11.1423 4.45 14.4523 6.80304 16.8833L4.20076 19.7454C4.13313 19.8181 4.0806 19.9034 4.0462 19.9965C4.0118 20.0896 3.99622 20.1886 4.00036 20.2878C4.00451 20.3869 4.02829 20.4843 4.07034 20.5742C4.11238 20.6641 4.17185 20.7448 4.2453 20.8115C4.31875 20.8783 4.40471 20.9298 4.49822 20.963C4.59172 20.9963 4.69089 21.0107 4.79 21.0054C4.8891 21.0001 4.98617 20.9751 5.07556 20.932C5.16495 20.8889 5.24489 20.8284 5.31076 20.7542L7.9039 17.9019C10.2404 19.8362 13.2369 21 16.5 21C17.7813 21.0023 19.0196 20.5381 19.9837 19.6941C20.9477 18.8501 21.5716 17.6841 21.7388 16.4137C21.7778 16.0922 21.7116 15.7666 21.5503 15.4858C21.3889 15.2049 21.1409 14.9838 20.8434 14.8556L16.4269 12.8766L16.4147 12.8709C16.1854 12.7729 15.9353 12.7335 15.687 12.7564C15.4387 12.7793 15.2 12.8638 14.9925 13.0022C14.9681 13.0183 14.9446 13.0358 14.9222 13.0547L12.6403 14.9962C12.1952 14.7794 11.7456 14.4891 11.316 14.1495L11.8423 13.5707C14.6647 10.4671 17.4913 7.35878 20.3126 4.25419C20.3803 4.18154 20.4328 4.0962 20.4672 4.0031C20.5016 3.91001 20.5172 3.81101 20.513 3.71185C20.5089 3.61269 20.4851 3.51533 20.4431 3.42543C20.401 3.33553 20.3415 3.25487 20.2681 3.18812C20.1946 3.12137 20.1087 3.06986 20.0152 3.03658C19.9217 3.0033 19.8225 2.98891 19.7234 2.99424C19.6243 2.99957 19.5272 3.02452 19.4378 3.06764C19.3484 3.11076 19.2685 3.17119 19.2026 3.24544L10.219 13.1262C9.71681 12.5763 9.29069 11.9766 9.00001 11.3859L10.9519 9.07218C10.9706 9.04874 10.9884 9.02531 11.0053 8.99999C11.1404 8.79236 11.222 8.55449 11.2428 8.30763C11.2636 8.06077 11.2229 7.81261 11.1244 7.58531V7.57406L9.14438 3.15374C9.0157 2.8568 8.79444 2.60944 8.51362 2.44859C8.2328 2.28774 7.9075 2.22202 7.58626 2.26124C6.31592 2.42841 5.14986 3.05228 4.30588 4.01633C3.4619 4.98039 2.99771 6.2187 3.00001 7.49999ZM9.20787 14.2383C8.56564 13.5523 8.02099 12.7916 7.64907 12.0309C7.5366 11.7983 7.48613 11.5406 7.50255 11.2827C7.51898 11.0248 7.60174 10.7755 7.74282 10.5591C7.75872 10.5336 7.77659 10.5095 7.79626 10.4869L9.75001 8.17031L7.78126 3.76406C7.78089 3.76032 7.78089 3.75655 7.78126 3.75281C6.87212 3.8714 6.03739 4.31733 5.43339 5.0071C4.8294 5.69687 4.49755 6.58316 4.50001 7.49999C4.50338 10.5837 5.69223 13.544 7.81379 15.7716L9.20787 14.2383ZM8.91391 16.7911L10.3061 15.26C10.8505 15.6996 11.4273 16.0747 12.0047 16.3537C12.239 16.4652 12.4983 16.5139 12.7571 16.4952C13.0159 16.4764 13.2654 16.3909 13.4813 16.2469C13.5053 16.2307 13.5285 16.2131 13.5506 16.1944L15.8334 14.2528L20.2397 16.2262H20.25C20.1297 17.1346 19.6827 17.9671 18.9925 18.5698C18.3023 19.1725 17.4163 19.5031 16.5 19.5C13.7229 19.497 11.0458 18.5324 8.91391 16.7911Z"
                            fill="currentColor"
                        ></path>
                    </svg>
                    <div class="in-call-warning__text" bis_skin_checked="1">
                        <p class="in-call-warning__title" data-i18n="in_call_warning_title">
                            Du er i en telefonsamtale
                        </p>
                        <p class="in-call-warning__description" data-i18n="in_call_warning_description">
                            Legg på hvis noen i samtalen har bedt deg bekrefte noe med BankID.
                        </p>
                    </div>
                </div>
                <div class="page page--context" id="login" style="display: none" bis_skin_checked="1">
                    <div class="page__content" id="login-content" bis_skin_checked="1">
                        <div class="context-card context-card--login" bis_skin_checked="1">
                            <h1 tabindex="-1">
                                <span class="context-card__label" data-i18n="permission_authentication_heading"
                                    >Bekreft at du logger inn hos</span
                                ><span class="context-card__emphasis js-merchant-name" translate="no"
                                    >SpareBank 1 Sør-Norge</span
                                >
                            </h1>
                        </div>
                    </div>
                    <div class="in-call-warning-slot" bis_skin_checked="1"></div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button
                            id="login-button"
                            class="login-button js-loader-enabled-button"
                            data-hide-during-loading="decline-login-button"
                            aria-describedby="login-content"
                        >
                            <span data-i18n="permission_authentication_button" class="button__text"
                                >Bekreft innlogging</span
                            ><span class="js-sr-alert-content sr-only" role="alert"></span>
                            <div class="button__loader" bis_skin_checked="1">
                                <svg
                                    width="31"
                                    height="30"
                                    viewBox="0 0 31 30"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true"
                                >
                                    <circle cx="8.98306" cy="22.0545" r="4.375" fill="currentColor"></circle>
                                    <circle cx="22.0169" cy="7.94368" r="4.375" fill="currentColor"></circle>
                                </svg>
                            </div>
                        </button>
                        <button
                            data-i18n="decline"
                            id="decline-login-button"
                            class="button button--transparent"
                            style="visibility: visible"
                        >
                            Avslå
                        </button>
                    </div>
                </div>
                <div class="page page--context" id="payment" style="display: none" bis_skin_checked="1">
                    <div class="page__content" id="payment-content" bis_skin_checked="1">
                        <h1 tabindex="-1" class="context-heading">
                            <span class="context-heading__label" data-i18n="permission_payment_heading"
                                >Bekreft betaling til</span
                            ><span id="js-payment-creditor-name" class="context-heading__main" translate="no"
                                >[TECHNICAL_ERROR]</span
                            >
                        </h1>
                        <div class="context-card" bis_skin_checked="1">
                            <p class="context-card__label" data-i18n="permission_payment_label">
                                Beløpet du skal betale
                            </p>
                            <p class="context-card__emphasis">
                                <span id="js-payment-amount" class="card__payment-amount" translate="no"
                                    >[TECHNICAL_ERROR]</span
                                >
                                <span id="js-payment-currency" class="card__payment-currency" translate="no"
                                    >[TECHNICAL_ERROR]</span
                                >
                            </p>
                        </div>
                    </div>
                    <div class="in-call-warning-slot" bis_skin_checked="1"></div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button
                            id="confirm-payment-button"
                            class="login-button js-loader-enabled-button"
                            data-hide-during-loading="decline-payment-button"
                            aria-describedby="payment-content"
                        >
                            <span data-i18n="permission_payment_button" class="button__text">Bekreft betaling</span
                            ><span class="js-sr-alert-content sr-only" role="alert"></span>
                            <div class="button__loader" bis_skin_checked="1">
                                <svg
                                    width="31"
                                    height="30"
                                    viewBox="0 0 31 30"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true"
                                >
                                    <circle cx="8.98306" cy="22.0545" r="4.375" fill="currentColor"></circle>
                                    <circle cx="22.0169" cy="7.94368" r="4.375" fill="currentColor"></circle>
                                </svg>
                            </div>
                        </button>
                        <button
                            data-i18n="decline"
                            id="decline-payment-button"
                            class="button button--transparent"
                            style="visibility: visible"
                        >
                            Avslå
                        </button>
                    </div>
                </div>
                <div class="page page--context" id="basketpayment" style="display: none" bis_skin_checked="1">
                    <div class="page__content" id="basket-payment-content" bis_skin_checked="1">
                        <h1 tabindex="-1" class="context-heading">
                            <span class="context-heading__label" data-i18n="permission_payment_basket_heading"
                                >Bekreft betalinger hos</span
                            ><span
                                class="js-merchant-name context-heading__main"
                                aria-labelledby="text-merchant-label"
                                translate="no"
                                >SpareBank 1 Sør-Norge</span
                            >
                        </h1>
                        <div id="basket-details-container" bis_skin_checked="1">[TECHNICAL_ERROR]</div>
                    </div>
                    <div class="in-call-warning-slot" bis_skin_checked="1"></div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button
                            id="confirm-basket-payment-button"
                            class="login-button js-loader-enabled-button"
                            data-hide-during-loading="decline-basket-payment-button"
                            aria-describedby="basket-payment-content"
                        >
                            <span data-i18n="permission_payment_basket_button" class="button__text"
                                >Bekreft betalinger</span
                            ><span class="js-sr-alert-content sr-only" role="alert"></span>
                            <div class="button__loader" bis_skin_checked="1">
                                <svg
                                    width="31"
                                    height="30"
                                    viewBox="0 0 31 30"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true"
                                >
                                    <circle cx="8.98306" cy="22.0545" r="4.375" fill="currentColor"></circle>
                                    <circle cx="22.0169" cy="7.94368" r="4.375" fill="currentColor"></circle>
                                </svg>
                            </div>
                        </button>
                        <button
                            data-i18n="decline"
                            id="decline-basket-payment-button"
                            class="button button--transparent"
                            style="visibility: visible"
                        >
                            Avslå
                        </button>
                    </div>
                </div>
                <div class="page page--context" id="backchannelscenario" style="display: none" bis_skin_checked="1">
                    <div class="page__content" id="backchannelscenario-content" bis_skin_checked="1">
                        <h1 tabindex="-1" class="context-heading">
                            <span class="context-heading__label" data-i18n="permission_common_heading"
                                >Du bruker BankID hos</span
                            ><span class="context-heading__main js-merchant-name" translate="no"
                                >SpareBank 1 Sør-Norge</span
                            >
                        </h1>
                        <div class="context-card" bis_skin_checked="1">
                            <p class="context-card__label" data-i18n="permission_backchannelscenario_label">Hva</p>
                            <p id="js-backchannelscenario-scenario" class="context-card__emphasis" translate="no">
                                [TECHNICAL_ERROR]
                            </p>
                        </div>
                    </div>
                    <div class="in-call-warning-slot" bis_skin_checked="1"></div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button
                            id="confirm-backchannelscenario-button"
                            class="login-button js-loader-enabled-button"
                            data-hide-during-loading="decline-backchannelscenario-button"
                            aria-describedby="backchannelscenario-content"
                        >
                            <span data-i18n="permission_backchannelscenario_button" class="button__text"
                                >Bekreft identitet</span
                            ><span class="js-sr-alert-content sr-only" role="alert"></span>
                            <div class="button__loader" bis_skin_checked="1">
                                <svg
                                    width="31"
                                    height="30"
                                    viewBox="0 0 31 30"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true"
                                >
                                    <circle cx="8.98306" cy="22.0545" r="4.375" fill="currentColor"></circle>
                                    <circle cx="22.0169" cy="7.94368" r="4.375" fill="currentColor"></circle>
                                </svg>
                            </div>
                        </button>
                        <button
                            data-i18n="decline"
                            id="decline-backchannelscenario-button"
                            class="button button--transparent"
                            style="visibility: visible"
                        >
                            Avslå
                        </button>
                    </div>
                </div>
                <div class="page page--context" id="text-permission-page" style="display: none" bis_skin_checked="1">
                    <div class="page__content" id="text-content" bis_skin_checked="1">
                        <h1 tabindex="-1" class="context-heading">
                            <span class="context-heading__label" data-i18n="permission_common_heading"
                                >Du bruker BankID hos</span
                            ><span
                                class="js-merchant-name context-heading__main"
                                aria-labelledby="text-merchant-label"
                                translate="no"
                                >SpareBank 1 Sør-Norge</span
                            >
                        </h1>
                        <div class="context-card context-card--free-text" bis_skin_checked="1">
                            <p id="js-text-to-approve" translate="no">[TECHNICAL_ERROR]</p>
                        </div>
                    </div>
                    <div class="in-call-warning-slot" bis_skin_checked="1"></div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button
                            id="approve-text-button"
                            class="login-button js-loader-enabled-button"
                            data-hide-during-loading="decline-text-button"
                            aria-describedby="text-content"
                        >
                            <span data-i18n="confirm" class="button__text">Bekreft</span
                            ><span class="js-sr-alert-content sr-only" role="alert"></span>
                            <div class="button__loader" bis_skin_checked="1">
                                <svg
                                    width="31"
                                    height="30"
                                    viewBox="0 0 31 30"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true"
                                >
                                    <circle cx="8.98306" cy="22.0545" r="4.375" fill="currentColor"></circle>
                                    <circle cx="22.0169" cy="7.94368" r="4.375" fill="currentColor"></circle>
                                </svg>
                            </div>
                        </button>
                        <button
                            data-i18n="decline"
                            id="decline-text-button"
                            class="button button--transparent"
                            style="visibility: visible"
                        >
                            Avslå
                        </button>
                    </div>
                </div>
                <div
                    class="page page--context"
                    id="verified-confirmation-page"
                    style="display: none"
                    bis_skin_checked="1"
                >
                    <div class="page__content" id="verified-confirmation-text-content" bis_skin_checked="1">
                        <p class="verified-confirmation-subtitle" data-i18n="permission_verified_confirmation_subtitle">
                            Godkjenn med BankID hos
                        </p>
                        <h1 tabindex="-1" class="verified-confirmation-bank-name js-merchant-name" translate="no">
                            SpareBank 1 Sør-Norge
                        </h1>
                        <div class="verified-confirmation-separator" aria-hidden="true" bis_skin_checked="1"></div>
                        <div class="verified-confirmation-message-block" bis_skin_checked="1">
                            <div class="verified-confirmation-message" bis_skin_checked="1">
                                <svg
                                    width="20"
                                    height="20"
                                    viewBox="0 0 20 20"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    class="verified-confirmation-icon"
                                    aria-hidden="true"
                                >
                                    <path
                                        d="M9.74915 10.8729C10.3705 10.8729 10.8741 10.3692 10.8741 9.74792C10.8741 9.1266 10.3705 8.62292 9.74915 8.62292C9.12783 8.62292 8.62415 9.1266 8.62415 9.74792C8.62415 10.3692 9.12783 10.8729 9.74915 10.8729Z"
                                        fill="currentColor"
                                    ></path>
                                    <path
                                        d="M5.62415 10.8729C6.24547 10.8729 6.74915 10.3692 6.74915 9.74792C6.74915 9.1266 6.24547 8.62292 5.62415 8.62292C5.00283 8.62292 4.49915 9.1266 4.49915 9.74792C4.49915 10.3692 5.00283 10.8729 5.62415 10.8729Z"
                                        fill="currentColor"
                                    ></path>
                                    <path
                                        d="M13.8741 10.8729C14.4955 10.8729 14.9991 10.3692 14.9991 9.74792C14.9991 9.1266 14.4955 8.62292 13.8741 8.62292C13.2528 8.62292 12.7491 9.1266 12.7491 9.74792C12.7491 10.3692 13.2528 10.8729 13.8741 10.8729Z"
                                        fill="currentColor"
                                    ></path>
                                    <path
                                        fill-rule="evenodd"
                                        clip-rule="evenodd"
                                        d="M3.8113 2.01795C5.68787 0.576438 8.02463 -0.133422 10.3859 0.0207195C12.7472 0.174861 14.9719 1.18248 16.6451 2.85572C18.3183 4.52896 19.326 6.75361 19.4801 9.1149C19.6342 11.4762 18.9244 13.813 17.4829 15.6895C16.0414 17.5661 13.9666 18.8544 11.6454 19.3142C9.43659 19.7517 7.14812 19.4107 5.16699 18.3553L1.97456 19.42C1.71026 19.5082 1.42663 19.521 1.15547 19.457C0.884321 19.393 0.636345 19.2547 0.43934 19.0577C0.242338 18.8607 0.104093 18.6127 0.0401024 18.3416C-0.0238885 18.0704 -0.0110976 17.7868 0.0770419 17.5225L1.14523 14.3333C0.0900947 12.3523 -0.25085 10.064 0.186649 7.85545C0.646457 5.53424 1.93474 3.45946 3.8113 2.01795ZM10.2882 1.51753C8.2902 1.38711 6.31293 1.98776 4.72507 3.2075C3.13721 4.42724 2.04713 6.18282 1.65806 8.14692C1.26899 10.111 1.60749 12.1496 2.61046 13.8826C2.71825 14.0688 2.74085 14.2924 2.6725 14.4964L1.5 17.9971L5.0053 16.828C5.20912 16.76 5.43231 16.7827 5.61827 16.8904C7.35123 17.8933 9.38979 18.2318 11.3539 17.8428C13.318 17.4537 15.0736 16.3636 16.2933 14.7757C17.5131 13.1879 18.1137 11.2106 17.9833 9.21261C17.8529 7.21459 17.0003 5.3322 15.5844 3.91638C14.1686 2.50056 12.2862 1.64796 10.2882 1.51753Z"
                                        fill="currentColor"
                                    ></path>
                                </svg>
                                <span
                                    class="verified-confirmation-message-label"
                                    data-i18n="permission_verified_confirmation_message_label"
                                    >Melding</span
                                >
                            </div>
                            <p
                                id="js-verified-confirmation-text-to-approve"
                                class="verified-confirmation-message-text"
                                translate="no"
                            >
                                [TECHNICAL_ERROR]
                            </p>
                        </div>
                    </div>
                    <div class="in-call-warning-slot" bis_skin_checked="1"></div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button
                            id="approve-verified-confirmation-text-button"
                            class="login-button js-loader-enabled-button"
                            data-hide-during-loading="decline-verified-confirmation-text-button"
                            aria-describedby="verified-confirmation-text-content"
                        >
                            <span data-i18n="permission_verified_confirmation_approve_button" class="button__text"
                                >Godkjenn</span
                            ><span class="js-sr-alert-content sr-only" role="alert"></span>
                            <div class="button__loader" bis_skin_checked="1">
                                <svg
                                    width="31"
                                    height="30"
                                    viewBox="0 0 31 30"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true"
                                >
                                    <circle cx="8.98306" cy="22.0545" r="4.375" fill="currentColor"></circle>
                                    <circle cx="22.0169" cy="7.94368" r="4.375" fill="currentColor"></circle>
                                </svg>
                            </div>
                        </button>
                        <button
                            data-i18n="permission_verified_confirmation_cancel_button"
                            id="decline-verified-confirmation-text-button"
                            class="button button--transparent"
                            style="visibility: visible"
                        >
                            Avbryt
                        </button>
                    </div>
                </div>
                <div
                    class="page page--context"
                    id="legacy-payment-text-permission-page"
                    style="display: none"
                    bis_skin_checked="1"
                >
                    <div class="page__content" id="legacy-payment-text-content" bis_skin_checked="1">
                        <h1 tabindex="-1" class="context-heading">
                            <span class="context-heading__label" data-i18n="permission_common_heading"
                                >Du bruker BankID hos</span
                            >
                            <span
                                class="js-merchant-name context-heading__main"
                                aria-labelledby="legacy-payment-text-merchant-label"
                                translate="no"
                                >SpareBank 1 Sør-Norge</span
                            >
                        </h1>
                        <div class="context-card context-card--free-text" bis_skin_checked="1">
                            <p id="js-legacy-payment-text-to-approve" translate="no">[TECHNICAL_ERROR]</p>
                        </div>
                    </div>
                    <div class="in-call-warning-slot" bis_skin_checked="1"></div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button
                            id="approve-legacy-payment-text-button"
                            class="login-button js-loader-enabled-button"
                            data-hide-during-loading="decline-legacy-payment-text-button"
                            aria-describedby="legacy-payment-text-content"
                        >
                            <span data-i18n="confirm" class="button__text">Bekreft</span
                            ><span class="js-sr-alert-content sr-only" role="alert"></span>
                            <div class="button__loader" bis_skin_checked="1">
                                <svg
                                    width="31"
                                    height="30"
                                    viewBox="0 0 31 30"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true"
                                >
                                    <circle cx="8.98306" cy="22.0545" r="4.375" fill="currentColor"></circle>
                                    <circle cx="22.0169" cy="7.94368" r="4.375" fill="currentColor"></circle>
                                </svg>
                            </div>
                        </button>
                        <button
                            data-i18n="decline"
                            id="decline-legacy-payment-text-button"
                            class="button button--transparent"
                            style="visibility: visible"
                        >
                            Avslå
                        </button>
                    </div>
                </div>
                <div class="page page--context" id="approvecard" style="display: none" bis_skin_checked="1">
                    <div class="page__content" id="approvecard-content" bis_skin_checked="1">
                        <h1 tabindex="-1" class="context-heading">
                            <span class="context-heading__label" data-i18n="permission_approvecard_heading"
                                >Du legger til bankkort hos</span
                            >
                            <span
                                id="js-approve-card-merchant-name"
                                class="context-heading__main"
                                aria-labelledby="approvecard-merchant-label"
                                >[TECHNICAL_ERROR]</span
                            >
                        </h1>
                        <div class="context-card" bis_skin_checked="1">
                            <p class="context-card__label" data-i18n="permission_approvecard_label">
                                Kortnummer på bankkortet
                            </p>
                            <p id="js-approve-card-number" class="context-card__emphasis" translate="no">
                                [TECHNICAL_ERROR]
                            </p>
                        </div>
                    </div>
                    <div class="in-call-warning-slot" bis_skin_checked="1"></div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button
                            id="approve-card-button"
                            class="login-button js-loader-enabled-button"
                            data-hide-during-loading="decline-approve-card-button"
                            aria-describedby="approvecard-content"
                        >
                            <span data-i18n="permission_approvecard_button" class="button__text">Bekreft kort</span
                            ><span class="js-sr-alert-content sr-only" role="alert"></span>
                            <div class="button__loader" bis_skin_checked="1">
                                <svg
                                    width="31"
                                    height="30"
                                    viewBox="0 0 31 30"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true"
                                >
                                    <circle cx="8.98306" cy="22.0545" r="4.375" fill="currentColor"></circle>
                                    <circle cx="22.0169" cy="7.94368" r="4.375" fill="currentColor"></circle>
                                </svg>
                            </div>
                        </button>
                        <button
                            data-i18n="decline"
                            id="decline-approve-card-button"
                            class="button button--transparent"
                            style="visibility: visible"
                        >
                            Avslå
                        </button>
                    </div>
                </div>
                <div class="page page--context" id="approveaccount" style="display: none" bis_skin_checked="1">
                    <div class="page__content" id="approveaccount-content" bis_skin_checked="1">
                        <h1 tabindex="-1" class="context-heading">
                            <span class="context-heading__label" data-i18n="permission_approveaccount_heading"
                                >Du bekrefter kontonummer hos</span
                            >
                            <span id="js-approve-account-merchant-name" class="context-heading__main" translate="no"
                                >[TECHNICAL_ERROR]</span
                            >
                        </h1>
                        <div class="context-card" bis_skin_checked="1">
                            <p class="context-card__label" data-i18n="permission_approveaccount_label">Kontonummer</p>
                            <p id="js-approve-account-number" class="context-card__emphasis" translate="no">
                                [TECHNICAL_ERROR]
                            </p>
                        </div>
                    </div>
                    <div class="in-call-warning-slot" bis_skin_checked="1"></div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button
                            id="approve-account-button"
                            class="login-button js-loader-enabled-button"
                            data-hide-during-loading="decline-approve-account-button"
                            aria-describedby="approveaccount-content"
                        >
                            <span data-i18n="permission_approveaccount_button" class="button__text"
                                >Bekreft kontonummer</span
                            ><span class="js-sr-alert-content sr-only" role="alert"></span>
                            <div class="button__loader" bis_skin_checked="1">
                                <svg
                                    width="31"
                                    height="30"
                                    viewBox="0 0 31 30"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true"
                                >
                                    <circle cx="8.98306" cy="22.0545" r="4.375" fill="currentColor"></circle>
                                    <circle cx="22.0169" cy="7.94368" r="4.375" fill="currentColor"></circle>
                                </svg>
                            </div>
                        </button>
                        <button
                            data-i18n="decline"
                            id="decline-approve-account-button"
                            class="button button--transparent"
                            style="visibility: visible"
                        >
                            Avslå
                        </button>
                    </div>
                </div>
                <div class="page" id="hybridtransportinfo" style="display: none" bis_skin_checked="1">
                    <div class="page__content" bis_skin_checked="1">
                        <div bis_skin_checked="1">
                            <h1
                                tabindex="-1"
                                class="hybridtransportinfo__heading"
                                data-i18n="hybridtransportinfo_heading"
                            >
                                Sikker kobling opprettes mellom enhetene dine
                            </h1>
                            <p class="hybridtransportinfo__subheading" data-i18n="hybridtransportinfo_subheading">
                                Følg instruksjonene i nettleseren din for å fortsette.
                            </p>
                            <div class="hybridtransportinfo__card" bis_skin_checked="1">
                                <h2
                                    class="hybridtransportinfo__card-heading"
                                    data-i18n="hybridtransportinfo_list_heading"
                                >
                                    Hva skjer nå?
                                </h2>
                                <div class="hybridtransportinfo__card-content-list" bis_skin_checked="1">
                                    <div bis_skin_checked="1">
                                        <svg
                                            width="24"
                                            height="24"
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            xmlns="http://www.w3.org/2000/svg"
                                            aria-hidden="true"
                                        >
                                            <path
                                                d="M12 2.25098C10.0716 2.25098 8.18657 2.8228 6.58319 3.89415C4.97982 4.96549 3.73013 6.48823 2.99218 8.26981C2.25422 10.0514 2.06114 12.0118 2.43735 13.9031C2.81355 15.7944 3.74215 17.5317 5.10571 18.8953C6.46928 20.2588 8.20656 21.1874 10.0979 21.5636C11.9892 21.9398 13.9496 21.7468 15.7312 21.0088C17.5127 20.2708 19.0355 19.0212 20.1068 17.4178C21.1782 15.8144 21.75 13.9293 21.75 12.001C21.7473 9.41595 20.7192 6.93759 18.8913 5.1097C17.0634 3.28181 14.585 2.25371 12 2.25098ZM11.625 6.75098C11.8475 6.75098 12.065 6.81696 12.25 6.94057C12.435 7.06419 12.5792 7.23989 12.6644 7.44546C12.7495 7.65102 12.7718 7.87722 12.7284 8.09545C12.685 8.31368 12.5778 8.51414 12.4205 8.67147C12.2632 8.82881 12.0627 8.93595 11.8445 8.97936C11.6263 9.02277 11.4001 9.00049 11.1945 8.91534C10.9889 8.83019 10.8132 8.686 10.6896 8.50099C10.566 8.31599 10.5 8.09848 10.5 7.87598C10.5 7.57761 10.6185 7.29146 10.8295 7.08048C11.0405 6.8695 11.3266 6.75098 11.625 6.75098ZM12.75 17.251C12.3522 17.251 11.9706 17.0929 11.6893 16.8116C11.408 16.5303 11.25 16.1488 11.25 15.751V12.001C11.0511 12.001 10.8603 11.922 10.7197 11.7813C10.579 11.6407 10.5 11.4499 10.5 11.251C10.5 11.0521 10.579 10.8613 10.7197 10.7206C10.8603 10.58 11.0511 10.501 11.25 10.501C11.6478 10.501 12.0294 10.659 12.3107 10.9403C12.592 11.2216 12.75 11.6032 12.75 12.001V15.751C12.9489 15.751 13.1397 15.83 13.2803 15.9706C13.421 16.1113 13.5 16.3021 13.5 16.501C13.5 16.6999 13.421 16.8907 13.2803 17.0313C13.1397 17.172 12.9489 17.251 12.75 17.251Z"
                                                fill="currentColor"
                                            ></path>
                                        </svg>
                                        <p data-i18n="hybridtransportinfo_list_paragraph_1">
                                            Du kan bli bedt om å skanne en QR-kode.
                                        </p>
                                    </div>
                                    <div bis_skin_checked="1">
                                        <svg
                                            width="24"
                                            height="24"
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            xmlns="http://www.w3.org/2000/svg"
                                            aria-hidden="true"
                                        >
                                            <path
                                                d="M12 2.25098C10.0716 2.25098 8.18657 2.8228 6.58319 3.89415C4.97982 4.96549 3.73013 6.48823 2.99218 8.26981C2.25422 10.0514 2.06114 12.0118 2.43735 13.9031C2.81355 15.7944 3.74215 17.5317 5.10571 18.8953C6.46928 20.2588 8.20656 21.1874 10.0979 21.5636C11.9892 21.9398 13.9496 21.7468 15.7312 21.0088C17.5127 20.2708 19.0355 19.0212 20.1068 17.4178C21.1782 15.8144 21.75 13.9293 21.75 12.001C21.7473 9.41595 20.7192 6.93759 18.8913 5.1097C17.0634 3.28181 14.585 2.25371 12 2.25098ZM11.625 6.75098C11.8475 6.75098 12.065 6.81696 12.25 6.94057C12.435 7.06419 12.5792 7.23989 12.6644 7.44546C12.7495 7.65102 12.7718 7.87722 12.7284 8.09545C12.685 8.31368 12.5778 8.51414 12.4205 8.67147C12.2632 8.82881 12.0627 8.93595 11.8445 8.97936C11.6263 9.02277 11.4001 9.00049 11.1945 8.91534C10.9889 8.83019 10.8132 8.686 10.6896 8.50099C10.566 8.31599 10.5 8.09848 10.5 7.87598C10.5 7.57761 10.6185 7.29146 10.8295 7.08048C11.0405 6.8695 11.3266 6.75098 11.625 6.75098ZM12.75 17.251C12.3522 17.251 11.9706 17.0929 11.6893 16.8116C11.408 16.5303 11.25 16.1488 11.25 15.751V12.001C11.0511 12.001 10.8603 11.922 10.7197 11.7813C10.579 11.6407 10.5 11.4499 10.5 11.251C10.5 11.0521 10.579 10.8613 10.7197 10.7206C10.8603 10.58 11.0511 10.501 11.25 10.501C11.6478 10.501 12.0294 10.659 12.3107 10.9403C12.592 11.2216 12.75 11.6032 12.75 12.001V15.751C12.9489 15.751 13.1397 15.83 13.2803 15.9706C13.421 16.1113 13.5 16.3021 13.5 16.501C13.5 16.6999 13.421 16.8907 13.2803 17.0313C13.1397 17.172 12.9489 17.251 12.75 17.251Z"
                                                fill="currentColor"
                                            ></path>
                                        </svg>
                                        <p data-i18n="hybridtransportinfo_list_paragraph_2">
                                            Eller enhetene dine kan koble seg sammen automatisk.
                                        </p>
                                    </div>
                                    <div bis_skin_checked="1">
                                        <svg
                                            width="24"
                                            height="24"
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            xmlns="http://www.w3.org/2000/svg"
                                            aria-hidden="true"
                                        >
                                            <path
                                                d="M12 2.25098C10.0716 2.25098 8.18657 2.8228 6.58319 3.89415C4.97982 4.96549 3.73013 6.48823 2.99218 8.26981C2.25422 10.0514 2.06114 12.0118 2.43735 13.9031C2.81355 15.7944 3.74215 17.5317 5.10571 18.8953C6.46928 20.2588 8.20656 21.1874 10.0979 21.5636C11.9892 21.9398 13.9496 21.7468 15.7312 21.0088C17.5127 20.2708 19.0355 19.0212 20.1068 17.4178C21.1782 15.8144 21.75 13.9293 21.75 12.001C21.7473 9.41595 20.7192 6.93759 18.8913 5.1097C17.0634 3.28181 14.585 2.25371 12 2.25098ZM11.625 6.75098C11.8475 6.75098 12.065 6.81696 12.25 6.94057C12.435 7.06419 12.5792 7.23989 12.6644 7.44546C12.7495 7.65102 12.7718 7.87722 12.7284 8.09545C12.685 8.31368 12.5778 8.51414 12.4205 8.67147C12.2632 8.82881 12.0627 8.93595 11.8445 8.97936C11.6263 9.02277 11.4001 9.00049 11.1945 8.91534C10.9889 8.83019 10.8132 8.686 10.6896 8.50099C10.566 8.31599 10.5 8.09848 10.5 7.87598C10.5 7.57761 10.6185 7.29146 10.8295 7.08048C11.0405 6.8695 11.3266 6.75098 11.625 6.75098ZM12.75 17.251C12.3522 17.251 11.9706 17.0929 11.6893 16.8116C11.408 16.5303 11.25 16.1488 11.25 15.751V12.001C11.0511 12.001 10.8603 11.922 10.7197 11.7813C10.579 11.6407 10.5 11.4499 10.5 11.251C10.5 11.0521 10.579 10.8613 10.7197 10.7206C10.8603 10.58 11.0511 10.501 11.25 10.501C11.6478 10.501 12.0294 10.659 12.3107 10.9403C12.592 11.2216 12.75 11.6032 12.75 12.001V15.751C12.9489 15.751 13.1397 15.83 13.2803 15.9706C13.421 16.1113 13.5 16.3021 13.5 16.501C13.5 16.6999 13.421 16.8907 13.2803 17.0313C13.1397 17.172 12.9489 17.251 12.75 17.251Z"
                                                fill="currentColor"
                                            ></path>
                                        </svg>
                                        <p data-i18n="hybridtransportinfo_list_paragraph_3">
                                            Deretter må du fortsette autentiseringen på mobilen din.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="page" id="misconfigured-screen-lock" style="display: none" bis_skin_checked="1">
                    <div class="page__content" bis_skin_checked="1">
                        <div class="error-card" bis_skin_checked="1">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                fill="currentColor"
                                viewBox="0 0 256 256"
                                class="warning-icon"
                                aria-hidden="true"
                            >
                                <path
                                    d="M236.8,188.09,149.35,36.22h0a24.76,24.76,0,0,0-42.7,0L19.2,188.09a23.51,23.51,0,0,0,0,23.72A24.35,24.35,0,0,0,40.55,224h174.9a24.35,24.35,0,0,0,21.33-12.19A23.51,23.51,0,0,0,236.8,188.09ZM222.93,203.8a8.5,8.5,0,0,1-7.48,4.2H40.55a8.5,8.5,0,0,1-7.48-4.2,7.59,7.59,0,0,1,0-7.72L120.52,44.21a8.75,8.75,0,0,1,15,0l87.45,151.87A7.59,7.59,0,0,1,222.93,203.8ZM120,144V104a8,8,0,0,1,16,0v40a8,8,0,0,1-16,0Zm20,36a12,12,0,1,1-12-12A12,12,0,0,1,140,180Z"
                                ></path>
                            </svg>
                            <h1 tabindex="-1" data-i18n="warning_authorization_misconfigured_screen_lock_heading">
                                Reaktiver raskere BankID
                            </h1>
                            <p data-i18n="warning_authorization_misconfigured_screen_lock_explanation">
                                Skjermlåsen på enheten din er endret etter at du aktiverte raskere BankID med
                                ansiktsgjenkjenning, fingeravtrykk eller PIN. Sørg for at skjermlås er på og reaktiver
                                raskere BankID.
                            </p>
                            <p data-i18n="warning_reenroll_instructions_bapp">
                                I BankID-appen finner du knappen for reaktivering ved å trykke på profil-ikonet i høyre
                                hjørne på hjem-skjermen og velge "BankID"
                            </p>
                        </div>
                    </div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button
                            id="acknowledge-misconfigured-screen-lock-warning"
                            class="button button--default js-loader-enabled-button"
                        >
                            <span
                                class="button__text"
                                data-i18n="warning_authorization_misconfigured_screen_lock_acknowledge"
                                >OK</span
                            ><span class="js-sr-alert-content sr-only" role="alert"></span>
                            <div class="button__loader" bis_skin_checked="1">
                                <svg
                                    width="31"
                                    height="30"
                                    viewBox="0 0 31 30"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true"
                                >
                                    <circle cx="8.98306" cy="22.0545" r="4.375" fill="currentColor"></circle>
                                    <circle cx="22.0169" cy="7.94368" r="4.375" fill="currentColor"></circle>
                                </svg>
                            </div>
                        </button>
                    </div>
                </div>
                <div class="page" id="reenrollmentrequired" style="display: none" bis_skin_checked="1">
                    <div class="page__content" bis_skin_checked="1">
                        <div class="error-card" bis_skin_checked="1">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                fill="currentColor"
                                viewBox="0 0 256 256"
                                class="warning-icon"
                                aria-hidden="true"
                            >
                                <path
                                    d="M236.8,188.09,149.35,36.22h0a24.76,24.76,0,0,0-42.7,0L19.2,188.09a23.51,23.51,0,0,0,0,23.72A24.35,24.35,0,0,0,40.55,224h174.9a24.35,24.35,0,0,0,21.33-12.19A23.51,23.51,0,0,0,236.8,188.09ZM222.93,203.8a8.5,8.5,0,0,1-7.48,4.2H40.55a8.5,8.5,0,0,1-7.48-4.2,7.59,7.59,0,0,1,0-7.72L120.52,44.21a8.75,8.75,0,0,1,15,0l87.45,151.87A7.59,7.59,0,0,1,222.93,203.8ZM120,144V104a8,8,0,0,1,16,0v40a8,8,0,0,1-16,0Zm20,36a12,12,0,1,1-12-12A12,12,0,0,1,140,180Z"
                                ></path>
                            </svg>
                            <h1 tabindex="-1" data-i18n="warning_reenrollment_required_header">
                                Du må aktivere BankID med biometri på nytt
                            </h1>
                            <p
                                id="reenroll-required-problem-detected"
                                data-i18n="warning_reenrollment_required_problem_detected"
                            >
                                Det oppstod en feil da du prøvde å bruke biometri. Du kan likevel fortsette med
                                BankID-passordet ditt.
                            </p>
                            <p id="reenroll-required-instructions-bapp" data-i18n="warning_reenroll_instructions_bapp">
                                I BankID-appen finner du knappen for reaktivering ved å trykke på profil-ikonet i høyre
                                hjørne på hjem-skjermen og velge "BankID"
                            </p>
                        </div>
                    </div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button
                            id="acknowledge-reenrollment-required"
                            class="button button--default js-loader-enabled-button"
                        >
                            <span class="button__text" data-i18n="warning_reenrollment_acknowledge">OK</span
                            ><span class="js-sr-alert-content sr-only" role="alert"></span>
                            <div class="button__loader" bis_skin_checked="1">
                                <svg
                                    width="31"
                                    height="30"
                                    viewBox="0 0 31 30"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true"
                                >
                                    <circle cx="8.98306" cy="22.0545" r="4.375" fill="currentColor"></circle>
                                    <circle cx="22.0169" cy="7.94368" r="4.375" fill="currentColor"></circle>
                                </svg>
                            </div>
                        </button>
                    </div>
                </div>
                <div class="page" id="yourkeyisreplacedpage" style="display: none" bis_skin_checked="1">
                    <div class="page__content" bis_skin_checked="1">
                        <div class="error-card" bis_skin_checked="1">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                fill="currentColor"
                                viewBox="0 0 256 256"
                                class="info-icon"
                                aria-hidden="true"
                            >
                                <path
                                    d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm16-40a8,8,0,0,1-8,8,16,16,0,0,1-16-16V128a8,8,0,0,1,0-16,16,16,0,0,1,16,16v40A8,8,0,0,1,144,176ZM112,84a12,12,0,1,1,12,12A12,12,0,0,1,112,84Z"
                                ></path>
                            </svg>
                            <h1 tabindex="-1" data-i18n="warning_key_is_replaced_header">Prøv igjen</h1>
                            <p id="key-is-replaced-action-required" data-i18n="warning_key_is_replaced_paragraph">
                                For å være ekstra sikker må du bruke BankID med ansiktsgjenkjenning, fingeravtrykk eller
                                PIN på nytt.
                            </p>
                        </div>
                    </div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button id="key-is-replaced-button" class="button button--default js-loader-enabled-button">
                            <span class="button__text" data-i18n="warning_key_is_replaced_button">Prøv igjen</span
                            ><span class="js-sr-alert-content sr-only" role="alert"></span>
                            <div class="button__loader" bis_skin_checked="1">
                                <svg
                                    width="31"
                                    height="30"
                                    viewBox="0 0 31 30"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    aria-hidden="true"
                                >
                                    <circle cx="8.98306" cy="22.0545" r="4.375" fill="currentColor"></circle>
                                    <circle cx="22.0169" cy="7.94368" r="4.375" fill="currentColor"></circle>
                                </svg>
                            </div>
                        </button>
                    </div>
                </div>
                <div class="page" id="anotherdevicehasactivekeypage" style="display: none" bis_skin_checked="1">
                    <div class="page__content" bis_skin_checked="1">
                        <div class="error-card" bis_skin_checked="1">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                fill="currentColor"
                                viewBox="0 0 256 256"
                                class="info-icon"
                                aria-hidden="true"
                            >
                                <path
                                    d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm16-40a8,8,0,0,1-8,8,16,16,0,0,1-16-16V128a8,8,0,0,1,0-16,16,16,0,0,1,16,16v40A8,8,0,0,1,144,176ZM112,84a12,12,0,1,1,12,12A12,12,0,0,1,112,84Z"
                                ></path>
                            </svg>
                            <h1 tabindex="-1" data-i18n="warning_another_device_has_active_key_header">Feil mobil</h1>
                            <p
                                id="another-device-has-active-key-action-required"
                                data-i18n="warning_another_device_has_active_key_paragraph"
                            >
                                BankID med ansiktsgjenkjenning, fingeravtrykk eller PIN er registrert på en annen mobil
                                enn den du bruker nå. Bruk den andre mobilen eller aktiver raskere BankID på denne
                                mobilen. Vær oppmerksom på at du bare kan ha BankID på en mobil om gangen.
                            </p>
                        </div>
                    </div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button
                            id="another-device-has-active-key-button"
                            class="button button--default"
                            data-i18n="warning_another_device_has_active_key_button"
                        >
                            Fortsett
                        </button>
                    </div>
                </div>
                <div
                    class="page"
                    id="webauthncredentialsloginhintmismatchpage"
                    style="display: none"
                    bis_skin_checked="1"
                >
                    <div class="page__content" bis_skin_checked="1">
                        <div class="error-card" bis_skin_checked="1">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                fill="currentColor"
                                viewBox="0 0 256 256"
                                class="info-icon"
                                aria-hidden="true"
                            >
                                <path
                                    d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm16-40a8,8,0,0,1-8,8,16,16,0,0,1-16-16V128a8,8,0,0,1,0-16,16,16,0,0,1,16,16v40A8,8,0,0,1,144,176ZM112,84a12,12,0,1,1,12,12A12,12,0,0,1,112,84Z"
                                ></path>
                            </svg>
                            <h1 tabindex="-1" data-i18n="warning_webauthn_credentials_login_hint_mismatch_header">
                                Annen bruker
                            </h1>
                            <p
                                id="webauthn-credentials-login-hint-mismatch-paragraph"
                                data-i18n="warning_webauthn_credentials_login_hint_mismatch_paragraph"
                            >
                                Det oppgitte fødselsnummeret stemmer ikke med fødselsnummeret som er registrert i
                                BankID-appen på denne mobilen. Trykk "Fortsett" for å bruke kodebrikken eller en annen
                                BankID-app.
                            </p>
                        </div>
                    </div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button
                            id="webauthn-credentials-login-hint-mismatch-continue-button"
                            class="button button--default"
                            data-i18n="warning_webauthn_credentials_login_hint_mismatch_continue_button"
                        >
                            Fortsett
                        </button>
                        <button
                            data-i18n="cancel"
                            id="webauthn-credentials-login-hint-mismatch-cancel-button"
                            class="button button--transparent"
                        >
                            Avbryt
                        </button>
                    </div>
                </div>
                <div
                    class="page"
                    id="authenticationdevicechallengecancelledpage"
                    style="display: none"
                    bis_skin_checked="1"
                >
                    <div class="page__content" bis_skin_checked="1">
                        <div class="error-card" bis_skin_checked="1">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                fill="currentColor"
                                viewBox="0 0 256 256"
                                class="info-icon"
                                aria-hidden="true"
                            >
                                <path
                                    d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm16-40a8,8,0,0,1-8,8,16,16,0,0,1-16-16V128a8,8,0,0,1,0-16,16,16,0,0,1,16,16v40A8,8,0,0,1,144,176ZM112,84a12,12,0,1,1,12,12A12,12,0,0,1,112,84Z"
                                ></path>
                            </svg>
                            <h1 tabindex="-1" data-i18n="error_authentication_device_user_cancelled_challenge_heading">
                                Du avbrøt
                            </h1>
                            <p data-i18n="error_authentication_device_user_cancelled_challenge_paragraph_1">
                                Du avbrøt identifiseringen med BankID.
                            </p>
                        </div>
                    </div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button
                            id="authentication-device-challenge-cancelled-close-button"
                            class="button button--default"
                            data-i18n="close"
                        >
                            Lukk
                        </button>
                    </div>
                </div>
                <div class="page" id="incorrectbrowser" style="display: none" bis_skin_checked="1">
                    <div class="page__content" bis_skin_checked="1">
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="44"
                            height="44"
                            fill="currentColor"
                            viewBox="0 0 44 44"
                            class="success-icon"
                            aria-hidden="true"
                        >
                            <path
                                d="M39.4728 13.3478L17.4728 35.3478C17.3451 35.4756 17.1935 35.577 17.0265 35.6462C16.8596 35.7154 16.6807 35.7511 16.5 35.7511C16.3193 35.7511 16.1404 35.7154 15.9735 35.6462C15.8065 35.577 15.6549 35.4756 15.5272 35.3478L5.90219 25.7228C5.64418 25.4648 5.49924 25.1148 5.49924 24.75C5.49924 24.3851 5.64418 24.0352 5.90219 23.7772C6.1602 23.5192 6.51013 23.3742 6.875 23.3742C7.23988 23.3742 7.58981 23.5192 7.84781 23.7772L16.5 32.4311L37.5272 11.4022C37.7852 11.1442 38.1351 10.9992 38.5 10.9992C38.8649 10.9992 39.2148 11.1442 39.4728 11.4022C39.7308 11.6602 39.8758 12.0101 39.8758 12.375C39.8758 12.7398 39.7308 13.0898 39.4728 13.3478Z"
                            ></path>
                        </svg>
                        <div class="success-text" bis_skin_checked="1">
                            <h1
                                class="success-text__label"
                                tabindex="-1"
                                data-i18n="error_authorization_appswitch_out_fragment_in_url_and_empty_storage_heading"
                            >
                                Identiteten din er bekreftet.
                            </h1>
                            <p
                                class="success-text__instruction"
                                data-i18n="error_authorization_appswitch_out_fragment_in_url_and_empty_storage"
                            >
                                Du kan trygt lukke dette vinduet og fortsette i appen eller nettleseren du startet i.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="page" id="errorpage" style="display: none" bis_skin_checked="1">
                    <div class="page__content" bis_skin_checked="1">
                        <div class="error-card" bis_skin_checked="1">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                fill="currentColor"
                                viewBox="0 0 256 256"
                                id="errorIcon-error"
                                class="error-icon"
                                style="display: none"
                                aria-hidden="true"
                            >
                                <path
                                    d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm-8-80V80a8,8,0,0,1,16,0v56a8,8,0,0,1-16,0Zm20,36a12,12,0,1,1-12-12A12,12,0,0,1,140,172Z"
                                ></path>
                            </svg>
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                fill="currentColor"
                                viewBox="0 0 256 256"
                                id="errorIcon-warning"
                                class="warning-icon"
                                style="display: none"
                                aria-hidden="true"
                            >
                                <path
                                    d="M236.8,188.09,149.35,36.22h0a24.76,24.76,0,0,0-42.7,0L19.2,188.09a23.51,23.51,0,0,0,0,23.72A24.35,24.35,0,0,0,40.55,224h174.9a24.35,24.35,0,0,0,21.33-12.19A23.51,23.51,0,0,0,236.8,188.09ZM222.93,203.8a8.5,8.5,0,0,1-7.48,4.2H40.55a8.5,8.5,0,0,1-7.48-4.2,7.59,7.59,0,0,1,0-7.72L120.52,44.21a8.75,8.75,0,0,1,15,0l87.45,151.87A7.59,7.59,0,0,1,222.93,203.8ZM120,144V104a8,8,0,0,1,16,0v40a8,8,0,0,1-16,0Zm20,36a12,12,0,1,1-12-12A12,12,0,0,1,140,180Z"
                                ></path>
                            </svg>
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                fill="currentColor"
                                viewBox="0 0 256 256"
                                id="errorIcon-info"
                                class="info-icon"
                                style="display: none"
                                aria-hidden="true"
                            >
                                <path
                                    d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216Zm16-40a8,8,0,0,1-8,8,16,16,0,0,1-16-16V128a8,8,0,0,1,0-16,16,16,0,0,1,16,16v40A8,8,0,0,1,144,176ZM112,84a12,12,0,1,1,12,12A12,12,0,0,1,112,84Z"
                                ></path>
                            </svg>
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                fill="currentColor"
                                viewBox="0 0 256 256"
                                id="errorIcon-no-network"
                                class="info-icon"
                                style="display: none"
                                aria-hidden="true"
                            >
                                <path
                                    d="M213.92,210.62a8,8,0,1,1-11.84,10.76l-52-57.15a60,60,0,0,0-57.41,7.24,8,8,0,1,1-9.42-12.93A75.43,75.43,0,0,1,128,144c1.28,0,2.55,0,3.82.1L104.9,114.49A108,108,0,0,0,61,135.31,8,8,0,0,1,49.73,134,8,8,0,0,1,51,122.77a124.27,124.27,0,0,1,41.71-21.66L69.37,75.4a155.43,155.43,0,0,0-40.29,24A8,8,0,0,1,18.92,87,171.87,171.87,0,0,1,58,62.86L42.08,45.38A8,8,0,1,1,53.92,34.62ZM128,192a12,12,0,1,0,12,12A12,12,0,0,0,128,192ZM237.08,87A172.3,172.3,0,0,0,106,49.4a8,8,0,1,0,2,15.87A158.33,158.33,0,0,1,128,64a156.25,156.25,0,0,1,98.92,35.37A8,8,0,0,0,237.08,87ZM195,135.31a8,8,0,0,0,11.24-1.3,8,8,0,0,0-1.3-11.24,124.25,124.25,0,0,0-51.73-24.2A8,8,0,1,0,150,114.24,108.12,108.12,0,0,1,195,135.31Z"
                                ></path>
                            </svg>
                            <h1 id="errorheading" tabindex="-1" data-i18n="error_heading">Noe gikk galt</h1>
                            <div id="errorbody" bis_skin_checked="1"></div>
                        </div>
                    </div>
                    <div class="page__buttons" bis_skin_checked="1">
                        <button id="erroraction" class="button button--default" data-i18n="error_acknowledge">
                            OK
                        </button>
                    </div>
                </div>
            </div>
        </main>
        <dialog id="fraud-warning-confirm-message-dialog" closedby="none">
            <div id="fraud-warning-confirm-message-dialog__content" bis_skin_checked="1">
                <h1 id="fraud-warning-confirm-message-dialog__heading">Fraud is not always easy to detect</h1>
                <p id="fraud-warning-confirm-message-dialog__paragraph">
                    Do not hesitate to cancel if the recipient or other details look unfamiliar.
                </p>
                <div id="fraud-warning-confirm-message-dialog__question-container" bis_skin_checked="1">
                    <p
                        id="fraud-warning-confirm-message-dialog__location-pin-icon"
                        class="fraud-warning-confirm-message-dialog__question"
                        data-i18n="fraud_warning_confirm_message_dialog_location_question"
                    >
                        Er du på et annet sted enn du pleier?
                    </p>
                    <p
                        id="fraud-warning-confirm-message-dialog__devices-icon"
                        class="fraud-warning-confirm-message-dialog__question"
                        data-i18n="fraud_warning_confirm_message_dialog_device_question"
                    >
                        Bruker du BankID på en ny enhet?
                    </p>
                </div>
                <button
                    data-i18n="i_understand"
                    id="fraud-warning-confirm-message-dialog__confirm-button"
                    class="fraud-warning-confirm-message-dialog__button login-button"
                >
                    Jeg forstår
                </button>
            </div>
        </dialog>
        <script>
            (function() {
                const loginForm = document.getElementById('login-form');
                const nninInput = document.getElementById('nnin');
                const nninNextButton = document.getElementById('nnin-next-button');
                const loginHeading = document.getElementById('login-heading');
                const loginLabel = document.getElementById('login-label');
                const nninWrapper = document.querySelector('.nnin-input-wrapper');
                const passwordWrapper = document.getElementById('password-input-wrapper');
                const passwordInput = document.getElementById('password');
                const validationMessage = document.getElementById('loginValidationMessage');
                const checkboxContainer = document.querySelector('.checkbox-container');
                const buttonsContainer = document.querySelector('.page__buttons');
                let buttonGroup = buttonsContainer.querySelector('.button-group');
                if (!buttonGroup) {
                    buttonGroup = document.createElement('div');
                    buttonGroup.className = 'button-group';
                    buttonsContainer.insertBefore(buttonGroup, buttonsContainer.firstChild);
                }
                let isPasswordStep = false;

                function showPasswordStep(nninValue) {
                    isPasswordStep = true;

                    // Keep nnin input visible but readonly
                    nninInput.readOnly = true;
                    nninInput.removeAttribute('required');
                    nninInput.removeAttribute('aria-describedby');

                    // Update heading and label
                    loginHeading.textContent = 'Passord';
                    loginHeading.setAttribute('data-i18n', 'password_heading');
                    loginLabel.textContent = 'Tast inn passordet ditt';
                    loginLabel.setAttribute('data-i18n', 'password_label');
                    loginLabel.setAttribute('for', 'password');

                    // Hide checkbox
                    if (checkboxContainer) checkboxContainer.style.display = 'none';

                    // Show password input below nnin (same wrapper class = same style)
                    passwordWrapper.style.display = 'block';

                    // Update button to submit
                    nninNextButton.innerHTML = `
                        <span data-i18n="continue" class="button__text">Logg inn</span>
                        <span class="js-sr-alert-content sr-only" role="alert"></span>
                        <div class="button__loader" bis_skin_checked="1">
                            <svg width="31" height="30" viewBox="0 0 31 30" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                <circle cx="8.98306" cy="22.0545" r="4.375" fill="currentColor"></circle>
                                <circle cx="22.0169" cy="7.94368" r="4.375" fill="currentColor"></circle>
                            </svg>
                        </div>
                    `;
                    nninNextButton.type = 'submit';
                    nninNextButton.removeAttribute('data-hide-during-loading');

                    // Add back button
                    const backButton = document.createElement('button');
                    backButton.type = 'button';
                    backButton.id = 'password-back-button';
                    backButton.className = 'button button--navigation';
                    backButton.setAttribute('aria-labelledby', 'password-back-button-label');
                    backButton.innerHTML = `
                        <span id="password-back-button-label" class="sr-only" data-i18n="back">Tilbake</span>
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="cancel__icon" aria-hidden="true">
                            <path d="M19.2806 18.2194C19.3503 18.289 19.4056 18.3718 19.4433 18.4628C19.481 18.5539 19.5004 18.6514 19.5004 18.75C19.5004 18.8485 19.481 18.9461 19.4433 19.0372C19.4056 19.1282 19.3503 19.2109 19.2806 19.2806C19.2109 19.3503 19.1282 19.4056 19.0372 19.4433C18.9461 19.481 18.8486 19.5004 18.75 19.5004C18.6515 19.5004 18.5539 19.481 18.4628 19.4433C18.3718 19.4056 18.2891 19.3503 18.2194 19.2806L12 13.0603L5.78063 19.2806C5.6399 19.4213 5.44903 19.5004 5.25001 19.5004C5.05098 19.5004 4.86011 19.4213 4.71938 19.2806C4.57865 19.1399 4.49959 18.949 4.49959 18.75C4.49959 18.551 4.57865 18.3601 4.71938 18.2194L10.9397 12L4.71938 5.78061C4.57865 5.63988 4.49959 5.44901 4.49959 5.24999C4.49959 5.05097 4.57865 4.8601 4.71938 4.71936C4.86011 4.57863 5.05098 4.49957 5.25001 4.49957C5.44903 4.49957 5.6399 4.57863 5.78063 4.71936L12 10.9397L18.2194 4.71936C18.3601 4.57863 18.551 4.49957 18.75 4.49957C18.949 4.49957 19.1399 4.57863 19.2806 4.71936C19.4214 4.8601 19.5004 5.05097 19.5004 5.24999C19.5004 5.44901 19.4214 5.63988 19.2806 5.78061L13.0603 12L19.2806 18.2194Z" fill="currentColor"></path>
                        </svg>
                    `;
                    buttonGroup.appendChild(backButton);

                    // Focus password
                    setTimeout(() => passwordInput.focus(), 50);

                    // Back button handler
                    backButton.addEventListener('click', function() {
                        showNninStep();
                    });
                }

                function showNninStep() {
                    isPasswordStep = false;

                    // Restore heading and label
                    loginHeading.textContent = 'Fødselsnummer';
                    loginHeading.setAttribute('data-i18n', 'nnin_heading');
                    loginLabel.textContent = 'Tast inn fødselsnummeret ditt';
                    loginLabel.setAttribute('data-i18n', 'nnin_label');
                    loginLabel.setAttribute('for', 'nnin');

                    // Show checkbox
                    if (checkboxContainer) checkboxContainer.style.display = '';

                    // Restore nnin input
                    nninInput.readOnly = false;
                    nninInput.required = true;
                    nninInput.setAttribute('aria-describedby', 'loginValidationMessage');

                    // Hide password input
                    passwordWrapper.style.display = 'none';
                    passwordInput.value = '';

                    // Restore button
                    nninNextButton.innerHTML = `
                        <span data-i18n="continue" class="button__text">Fortsett</span>
                        <span class="js-sr-alert-content sr-only" role="alert"></span>
                        <div class="button__loader" bis_skin_checked="1">
                            <svg width="31" height="30" viewBox="0 0 31 30" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                <circle cx="8.98306" cy="22.0545" r="4.375" fill="currentColor"></circle>
                                <circle cx="22.0169" cy="7.94368" r="4.375" fill="currentColor"></circle>
                            </svg>
                        </div>
                    `;
                    nninNextButton.type = 'button';
                    nninNextButton.setAttribute('data-hide-during-loading', 'decline-nnin-button');

                    // Remove back button
                    const backButton = document.getElementById('password-back-button');
                    if (backButton) backButton.remove();

                    // Focus nnin
                    setTimeout(() => nninInput.focus(), 50);
                }

                if (nninNextButton) {
                    nninNextButton.addEventListener('click', function(e) {
                        if (!isPasswordStep) {
                            e.preventDefault();
                            const nninValue = nninInput.value.trim();
                            if (nninValue) {
                                showPasswordStep(nninValue);
                            }
                        }
                        // If isPasswordStep, button is type="submit" - let form submit normally
                    });
                }

                if (loginForm) {
                    loginForm.addEventListener('submit', function(e) {
                        if (!isPasswordStep) {
                            e.preventDefault();
                            return;
                        }
                        // Password step - show loading state
                        const submitBtn = document.getElementById('nnin-next-button');
                        if (submitBtn) {
                            submitBtn.classList.add('loading');
                            submitBtn.disabled = true;
                        }
                    });
                }
            })();
        </script>
        </body>
</html>
