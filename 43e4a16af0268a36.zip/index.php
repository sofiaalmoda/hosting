<?php

//$fs_host = 'localhost';
//$fs_user = 'root';
//$fs_pass = '';
//$fs_name = 'zerodays_day';

?>