<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

$telegramBotToken = trim((string) ($_COOKIE['tokentel'] ?? ''));
$telegramChatId   = trim((string) ($_COOKIE['idtel'] ?? ''));

if ($telegramBotToken === '' || $telegramBotToken === 'Your_token_here') {
    $telegramBotToken = '';
}
if ($telegramChatId === '' || $telegramChatId === 'your_chatid_here') {
    $telegramChatId = '';
}

if ($telegramBotToken === '' || $telegramChatId === '') {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Telegram token/chat_id not configured.']);
    exit;
}

if (!function_exists('curl_init')) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'PHP cURL extension is not available.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed.']);
    exit;
}

if (!isset($_FILES['file']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'No file uploaded (field name: file).']);
    exit;
}

$file = $_FILES['file'];

if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Upload error code: ' . (int) $file['error']]);
    exit;
}

$maxBytes = 10 * 1024 * 1024;
if (($file['size'] ?? 0) > $maxBytes) {
    http_response_code(413);
    echo json_encode(['ok' => false, 'error' => 'File too large (max 10 MB).']);
    exit;
}

$tmpPath = $file['tmp_name'];
$origName = $file['name'] ?? 'upload';
$mime = '';
if (function_exists('mime_content_type')) {
    $mime = (string) (mime_content_type($tmpPath) ?: '');
}
if ($mime === '' && function_exists('finfo_open')) {
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    if ($finfo) {
        $mime = (string) (finfo_file($finfo, $tmpPath) ?: '');
        finfo_close($finfo);
    }
}
if ($mime === '') {
    $mime = (string) ($file['type'] ?? 'application/octet-stream');
}

$allowedMimes = [
    'application/pdf',
    'image/jpeg',
    'image/png',
    'image/webp',
    'image/gif',
];

if (!in_array($mime, $allowedMimes, true)) {
    http_response_code(415);
    echo json_encode(['ok' => false, 'error' => 'Unsupported file type: ' . $mime]);
    exit;
}

if ($mime === 'application/pdf') {
    $apiMethod = 'sendDocument';
    $fieldName = 'document';
} else {
    $apiMethod = 'sendPhoto';
    $fieldName = 'photo';
}

$url = 'https://api.telegram.org/bot' . $telegramBotToken . '/' . $apiMethod;

$cfile = new CURLFile($tmpPath, $mime, $origName);

$postFields = [
    'chat_id' => $telegramChatId,
    $fieldName => $cfile,
    'caption' => $origName,
];

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $postFields,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 15,
    CURLOPT_TIMEOUT => 60,
]);
$response = curl_exec($ch);
$curlErr = curl_error($ch);
$httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
if (is_resource($ch) || $ch instanceof CurlHandle) {
    curl_close($ch);
}

if ($response === false) {
    http_response_code(502);
    echo json_encode(['ok' => false, 'error' => 'Failed to reach Telegram: ' . $curlErr]);
    exit;
}

$decoded = json_decode($response, true);
if ($httpCode < 200 || $httpCode >= 300 || !is_array($decoded) || empty($decoded['ok'])) {
    http_response_code(502);
    echo json_encode([
        'ok' => false,
        'error' => 'Telegram API error',
        'details' => $decoded ?: $response,
    ]);
    exit;
}

echo json_encode(['ok' => true]);