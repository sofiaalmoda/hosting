﻿<?php
$blank_page = ' ';
         $up_file = fopen("api.txt", "w");
         fwrite($up_file, $blank_page);
?>

<!DOCTYPE html><html class="ltr" dir="ltr" lang="fr-FR"><script data-savepage-type="" type="text/plain" data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/content/location/location.js" id="eppiocemhmnlbhjplcgkofciiegomcon"></script><div id="in-page-channel-node-id" data-channel-name="in_page_channel_I4y64-" bis_skin_checked="1"></div><script data-savepage-type="" type="text/plain" data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/extend-native-history-api.js"></script><script data-savepage-type="" type="text/plain" data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/requests.js"></script><head>
<link rel="icon" data-savepage-href="https://static.cdc-net.com/sso/theme/attente/favicon.ico" href="data:image/x-icon;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAQAABILAAASCwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHh7wAB4e8AMeHvA9Hh7wuh4e8LweHvBAHh7wBB4e8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeHvAAHh7wAB4e8CMeHvCKHh7w6h4e8PIeHvDyHh7w6x4e8I4eHvAmHh7wAR4e8AAAAAAAAAAAAB4e8AAeHvAAHh7wDB4e8DIeHvDWHh7w+h4e8LMeHvBCHh7wQh4e8LMeHvD5Hh7w3x4e8HYeHvAYHh7wAB4e8AAeHvAAHh7wUB4e8KQeHvBZHh7wwR4e8FoeHvAMHh7wAB4e8AAeHvALHh7wWB4e8MkeHvD8Hh7wzh4e8E4eHvAAHh7wAx4e8KweHvDdHh7wKB4e8BMeHvAAHh7wAAAAAAAAAAAAHh7wAB4e8AAeHvAVHh7wcB4e8N0eHvCqHh7wAx4e8AMeHvCtHh7w3h4e8BkeHvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHh7wAB4e8AceHvBEHh7wTB4e8AMeHvADHh7wrR4e8N4eHvAZHh7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4e8AAeHvAWHh7wuR4e8GkeHvAAHh7wAx4e8K0eHvDeHh7wGR4e8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeHvAAHh7wFh4e8NoeHvCtHh7wAx4e8AMeHvCtHh7w3h4e8BkeHvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHh7wAB4e8BYeHvDaHh7wrR4e8AMeHvADHh7wrR4e8N4eHvAZHh7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4e8AAeHvAWHh7w2h4e8K0eHvADHh7wAx4e8K0eHvDeHh7wGR4e8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeHvAAHh7wFh4e8NoeHvCtHh7wAx4e8AMeHvCrHh7w9h4e8HYeHvAVHh7wAB4e8AAAAAAAAAAAAB4e8AAeHvAAHh7wFB4e8HUeHvD1Hh7wqx4e8AMeHvAAHh7wTB4e8MoeHvD7Hh7wyR4e8FgeHvANHh7wAB4e8AAeHvALHh7wVx4e8MgeHvD7Hh7wzB4e8E4eHvAAHh7wAB4e8AAeHvAWHh7wcR4e8NweHvD3Hh7whx4e8AweHvBAHh7wsh4e8PkeHvDfHh7wdR4e8BceHvAAHh7wAAAAAAAAAAAAHh7wAB4e8AAeHvAkHh7wXx4e8EgeHvCcHh7w8B4e8OseHvCNHh7wJR4e8AEeHvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHh7wAB4e8AAeHvAsHh7wvB4e8LweHvA/Hh7wAx4e8AAAAAAAAAAAAAAAAAAAAAAA+B8AAOAHAACAAwAAgYEAAAfgAAAP8AAAD/AAAA/wAAAP8AAAD/AAAA/wAAAH4AAAgYEAAMADAADgBwAA/B8AAA==">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta content="text/html; charset=UTF-8" http-equiv="content-type">
<title>Authentification CDC-Net</title>

<style data-savepage-href="https://static.cdc-net.com/sso/theme/attente/brands/style.css">@font-face {
  font-family: 'Brands';
  src:  /*savepage-url=fonts/Brands.eot?a5oguy*/ url();
  src:  /*savepage-url=fonts/Brands.eot?a5oguy#iefix*/ url() format('embedded-opentype'),
    /*savepage-url=fonts/Brands.ttf?a5oguy*/ url() format('truetype'),
    /*savepage-url=fonts/Brands.woff?a5oguy*/ url() format('woff'),
    /*savepage-url=fonts/Brands.svg?a5oguy#Brands*/ url() format('svg');
  font-weight: normal;
  font-style: normal;
  /*savepage-font-display=block*/
}

[class^="ibrands-"], [class*=" ibrands-"] {
  /* use !important to prevent issues with browser extensions that change fonts */
  font-family: 'Brands' !important;
  speak: none;
  font-style: normal;
  font-weight: normal;
  font-variant: normal;
  text-transform: none;
  line-height: 1;

  /* Better Font Rendering =========== */
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.ibrands-fusion:before {
  content: "\e902";
}
.ibrands-cypress:before {
  content: "\e900";
}
.ibrands-adobe:before {
  content: "\e901";
}
.ibrands-angular:before {
  content: "\e903";
}
.ibrands-bitbucket:before {
  content: "\e904";
}
.ibrands-confluence:before {
  content: "\e905";
}
.ibrands-elastic:before {
  content: "\e906";
}
.ibrands-elasticcloud:before {
  content: "\e907";
}
.ibrands-elasticsearch:before {
  content: "\e908";
}
.ibrands-elasticstack:before {
  content: "\e909";
}
.ibrands-git:before {
  content: "\e90a";
}
.ibrands-java:before {
  content: "\e90b";
}
.ibrands-jenkins:before {
  content: "\e90c";
}
.ibrands-jira:before {
  content: "\e90d";
}
.ibrands-kibana:before {
  content: "\e90e";
}
.ibrands-microsoftexcel:before {
  content: "\e90f";
}
.ibrands-microsoftoffice:before {
  content: "\e910";
}
.ibrands-microsoftonenote:before {
  content: "\e911";
}
.ibrands-microsoftoutlook:before {
  content: "\e912";
}
.ibrands-microsoftpowerpoint:before {
  content: "\e913";
}
.ibrands-microsoftteams:before {
  content: "\e914";
}
.ibrands-microsoftword:before {
  content: "\e915";
}
.ibrands-npm:before {
  content: "\e916";
}
.ibrands-php:before {
  content: "\e917";
}
.ibrands-sass:before {
  content: "\e918";
}
.ibrands-skype:before {
  content: "\e919";
}
.ibrands-sonarlint:before {
  content: "\e91a";
}
.ibrands-sonarqube:before {
  content: "\e91b";
}
.ibrands-sonarsource:before {
  content: "\e91c";
}
.ibrands-spring:before {
  content: "\e91d";
}
</style>
<style data-savepage-href="https://static.cdc-net.com/sso/theme/attente/style.css">@charset "UTF-8";
.ff-montserrat {
  font-family: 'montserrat', Arial, Helvetica, sans-serif;
  font-weight: 400; }

.access-hidden, .visually-hidden, .is-vishidden {
  position: absolute !important;
  overflow: hidden;
  width: 1px;
  height: 1px;
  padding: 0;
  border: 0;
  clip: rect(1px, 1px, 1px, 1px); }
  .access-hidden:before, .access-hidden:after, .visually-hidden:before, .visually-hidden:after, .is-vishidden:before, .is-vishidden:after {
    display: none; }

button, html input[type=button], input[type=reset], input[type=submit] {
  -webkit-appearance: button;
  -moz-appearance: button;
  appearance: button;
  cursor: pointer; }

.reset-list {
  list-style: none;
  margin: 0;
  padding: 0; }
  .reset-list li,
  .reset-list ul li {
    margin-bottom: 0;
    padding-left: 0; }
    .reset-list li:before,
    .reset-list ul li:before {
      content: none;
      margin: 0; }

.reset-list--l1 {
  list-style: none;
  margin: 0;
  padding: 0; }
  .reset-list--l1 > li {
    padding-left: 0; }
    .reset-list--l1 > li:before {
      content: none;
      margin: 0; }

.icon-territoires-dinnovation-1:before {
  content: ""; }

.icon-territoires-dinnovation-2:before {
  content: ""; }

.icon-territoires-dinnovation-3:before {
  content: ""; }

.icon-signature:before {
  content: ""; }

.icon-actions:before {
  content: ""; }

.icon-ajout-annuaire:before {
  content: ""; }

.icon-alerte-covid:before {
  content: ""; }

.icon-etransfert:before {
  content: ""; }

.icon-itineraire:before {
  content: ""; }

.icon-link:before {
  content: ""; }

.icon-dossier_ferme:before {
  content: ""; }

.icon-dossier_ouvert:before {
  content: ""; }

.icon-alerte_outline:before {
  content: ""; }

.icon-comparateur_energetique:before {
  content: ""; }

.icon-deconnexion:before {
  content: ""; }

.icon-simulateur:before {
  content: ""; }

.icon-cartographie:before {
  content: ""; }

.icon-coproprietes_degradees:before {
  content: ""; }

.icon-fichier_pdf:before {
  content: ""; }

.icon-mobile:before {
  content: ""; }

.icon-tourisme:before {
  content: ""; }

.icon-accompagnement_transformation_secteur:before {
  content: ""; }

.icon-adaptation_changement_climatique:before {
  content: ""; }

.icon-consigner:before {
  content: ""; }

.icon-dialogue_citoyen:before {
  content: ""; }

.icon-entreprendre_autrement:before {
  content: ""; }

.icon-pret_flash:before {
  content: ""; }

.icon-transition-energetique:before {
  content: ""; }

.icon-vieillissement:before {
  content: ""; }

.icon-france-metropole:before {
  content: ""; }

.icon-guadeloupe:before {
  content: ""; }

.icon-guyane:before {
  content: ""; }

.icon-martinique:before {
  content: ""; }

.icon-mayotte:before {
  content: ""; }

.icon-nouvelle-caledonie:before {
  content: ""; }

.icon-polynesie-francaise:before {
  content: ""; }

.icon-la-reunion:before {
  content: ""; }

.icon-st-pierre-et-miquelon:before {
  content: ""; }

.icon-hexagone-bdt:before {
  content: ""; }

.icon-pause:before {
  content: ""; }

.icon-play:before {
  content: ""; }

.icon-confirmation:before {
  content: ""; }

.icon-refus:before {
  content: ""; }

.icon-epl:before {
  content: ""; }

.icon-mobilites:before {
  content: ""; }

.icon-alerte:before {
  content: ""; }

.icon-contrat:before {
  content: ""; }

.icon-ajouter:before {
  content: ""; }

.icon-erreur:before {
  content: ""; }

.icon-traitement-en-cours:before {
  content: ""; }

.icon-demande-validee:before {
  content: ""; }

.icon-sort-table:before {
  content: ""; }

.icon-drag-n-drop:before {
  content: ""; }

.icon-upload:before {
  content: ""; }

.icon-historique:before {
  content: ""; }

.icon-modifier:before {
  content: ""; }

.icon-supprimer:before {
  content: ""; }

.icon-recapitulatif:before {
  content: ""; }

.icon-dupliquer:before {
  content: ""; }

.icon-justificatif-paiement:before {
  content: ""; }

.icon-logement2:before {
  content: ""; }

.icon-logement:before {
  content: ""; }

.icon-partage:before {
  content: ""; }

.icon-modernisation_ecoles:before {
  content: ""; }

.icon-territoires_conseils:before {
  content: ""; }

.icon-zoom:before {
  content: ""; }

.icon-reconquete_territoires_industrie:before {
  content: ""; }

.icon-renovation_reseaux_eaux:before {
  content: ""; }

.icon-cacher_mot_de_passe:before {
  content: ""; }

.icon-pencil:before {
  content: ""; }

.icon-toutes-nos-offres:before {
  content: ""; }

.icon-banque-en-ligne:before {
  content: ""; }

.icon-services-en-ligne:before {
  content: ""; }

.icon-reseaux-sociaux:before {
  content: ""; }

.icon-soutien_enjeux_renovation_parc_social:before {
  content: ""; }

.icon-maintien_investissement_production_neuve_et_rehabilitation_thermique:before {
  content: ""; }

.icon-rss:before {
  content: ""; }

.icon-annuaire_smartcity:before {
  content: ""; }

.icon-association_elus:before {
  content: ""; }

.icon-offre_conseils_et_financements:before {
  content: ""; }

.icon-reseau_experts_partenaires:before {
  content: ""; }

.icon-partenaire_financier_de_reference:before {
  content: ""; }

.icon-appui_politique_locale:before {
  content: ""; }

.icon-appui_realisation_projets:before {
  content: ""; }

.icon-appui_renovation_urbaine:before {
  content: ""; }

.icon-accompagnement_sur_site:before {
  content: ""; }

.icon-gamme_evenements_complete:before {
  content: ""; }

.icon-reponses_personnalisees:before {
  content: ""; }

.icon-expertise_developpement_territorial:before {
  content: ""; }

.icon-legitimite_historique:before {
  content: ""; }

.icon-transition_ecologique:before {
  content: ""; }

.icon-gamme_intervention_complete:before {
  content: ""; }

.icon-proximite:before {
  content: ""; }

.icon-partenaires_a_vos_cotes:before {
  content: ""; }

.icon-403:before {
  content: ""; }

.icon-404:before {
  content: ""; }

.icon-maintenance:before {
  content: ""; }

.icon-actualites:before {
  content: ""; }

.icon-ameliorer_efficacite_energetique:before {
  content: ""; }

.icon-definir_strategie_financiere:before {
  content: ""; }

.icon-smartcity:before {
  content: ""; }

.icon-ouvrir_gerer_comptes:before {
  content: ""; }

.icon-developper_entreprise:before {
  content: ""; }

.icon-elaborer_son_installation:before {
  content: ""; }

.icon-financer_offre_innovante:before {
  content: ""; }

.icon-financer_projet_territorial:before {
  content: ""; }

.icon-mettre_en_place_solution_innovante:before {
  content: ""; }

.icon-financer_projet_investissement:before {
  content: ""; }

.icon-financer_logement_social:before {
  content: ""; }

.icon-revitaliser_centre_ville:before {
  content: ""; }

.icon-back:before {
  content: ""; }

.icon-envoyer_ami:before {
  content: ""; }

.icon-arrow_double_left:before {
  content: ""; }

.icon-arrow_double_right:before {
  content: ""; }

.icon-arrow-full-left:before {
  content: ""; }

.icon-arrow-full-right:before {
  content: ""; }

.icon-border-top-left-1:before {
  content: ""; }

.icon-border-top-left-2:before {
  content: ""; }

.icon-border-top-left-3:before {
  content: ""; }

.icon-border-top-right-1:before {
  content: ""; }

.icon-close:before {
  content: ""; }

.icon-spacer:before {
  content: ""; }

.icon-article_verrouille:before {
  content: ""; }

.icon-assistant_projet:before {
  content: ""; }

.icon-ecrire_par_mail:before {
  content: ""; }

.icon-dossier:before {
  content: ""; }

.icon-pdf:before {
  content: ""; }

.icon-citation:before {
  content: ""; }

.icon-retour:before {
  content: ""; }

.icon-connexion:before {
  content: ""; }

.icon-participants:before {
  content: ""; }

.icon-horaire:before {
  content: ""; }

.icon-temps_estime:before {
  content: ""; }

.icon-attention:before {
  content: ""; }

.icon-telephone:before {
  content: ""; }

.icon-information_outline:before {
  content: ""; }

.icon-check:before {
  content: ""; }

.icon-tutoriel_telecharger:before {
  content: ""; }

.icon-tutoriel_video:before {
  content: ""; }

.icon-configuration:before {
  content: ""; }

.icon-site_internet:before {
  content: ""; }

.icon-voir_mot_de_passe:before {
  content: ""; }

.icon-youtube:before {
  content: ""; }

.icon-instagram:before {
  content: ""; }

.icon-linkedin:before {
  content: ""; }

.icon-twitter:before {
  content: ""; }

.icon-facebook:before {
  content: ""; }

.icon-fermer:before {
  content: ""; }

.icon-aide:before {
  content: ""; }

.icon-information:before {
  content: ""; }

.icon-arrow_down:before {
  content: ""; }

.icon-arrow_up:before {
  content: ""; }

.icon-arrow_left:before {
  content: ""; }

.icon-arrow_right:before {
  content: ""; }

.icon-mapmarker:before {
  content: ""; }

.icon-reinitialiser:before {
  content: ""; }

.icon-calendrier:before {
  content: ""; }

.icon-menu:before {
  content: ""; }

.icon-lien_externe:before {
  content: ""; }

.icon-telecharger:before {
  content: ""; }

.icon-carte:before {
  content: ""; }

.icon-newsletter:before {
  content: ""; }

.icon-access:before {
  content: ""; }

.icon-account:before {
  content: ""; }

.icon-recherche:before {
  content: ""; }

.icon-imprimer:before {
  content: ""; }

.icon-contact:before {
  content: ""; }

.icon-agenda:before {
  content: ""; }


html {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale; }

details, menu, summary {
  display: block; }

audio,
canvas,
progress,
video {
  display: inline-block;
  vertical-align: baseline; }

audio:not([controls]) {
  display: none;
  height: 0; }

[hidden],
template {
  display: none; }

abbr[title] {
  border-bottom: 1px dotted; }

mark {
  background: #ff0;
  color: #000; }

img {
  border: 0; }

svg:not(:root) {
  overflow: hidden; }

button,
input,
optgroup,
select,
textarea {
  color: inherit; }

button[disabled],
html input[disabled] {
  cursor: not-allowed; }

input {
  line-height: normal; }

input[type="number"] {
  padding: 0; }

legend {
  border: 0; }

optgroup {
  font-weight: bold; }

table {
  border-spacing: 0; }

td,
th {
  padding: 0; }

html, body, div, span, h1, h2, h3, h4, h5, h6, p, a, em, img, ol, ul, li, label, table, tbody, tfoot, thead, tr, th, td, article, aside, footer, header, menu, nav, output, section, audio, video, figcaption, figure, fieldset {
  -webkit-margin-before: 0em;
  -webkit-margin-after: 0em;
  -webkit-margin-start: 0em;
  -webkit-margin-end: 0em;
  -webkit-padding-start: 0em;
  -webkit-padding-end: 0em;
  -webkit-padding-before: 0em;
  -webkit-padding-after: 0em; }

ol,
ul {
  padding: 0; }

.hidden {
  display: none; }

/*!
 * Bootstrap v4.1.3 (https://getbootstrap.com/)
 * Copyright 2011-2018 The Bootstrap Authors
 * Copyright 2011-2018 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 */
:root {
  --blue: #64C3D7;
  --indigo: #6610f2;
  --purple: #6F42C1;
  --pink: #EB6EAA;
  --red: #e5291d;
  --orange: #F5A023;
  --yellow: #FFEB68;
  --green: #AFCD50;
  --teal: #20c997;
  --cyan: #17a2b8;
  --white: #FFFFFF;
  --gray: #757575;
  --gray-dark: #454545;
  --primary: #454545;
  --secondary: #e5291d;
  --success: #AFCD50;
  --info: #64C3D7;
  --warning: #F5A023;
  --danger: #e5291d;
  --light: #CCCCCC;
  --dark: #454545;
  --lighter: #F4F4F4;
  --gray: #757575;
  --gray-dark: #171717;
  --breakpoint-xs: 0;
  --breakpoint-sm: 576px;
  --breakpoint-md: 768px;
  --breakpoint-lg: 992px;
  --breakpoint-xl: 1200px;
  --breakpoint-xxl: 1400px;
  --breakpoint-xxxl: 1600px;
  --font-family-sans-serif: "montserrat", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
  --font-family-monospace: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; }

*,
*::before,
*::after {
  box-sizing: border-box; }

html {
  font-family: sans-serif;
  line-height: 1.15;
  -webkit-text-size-adjust: 100%;
  -ms-text-size-adjust: 100%;
  -ms-overflow-style: scrollbar;
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0); }

@-ms-viewport {
  width: device-width; }

article, aside, figcaption, figure, footer, header, hgroup, main, nav, section {
  display: block; }

body {
  margin: 0;
  font-family: "montserrat", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
  font-size: 1.6rem;
  font-weight: 400;
  line-height: 1.25;
  color: #454545;
  text-align: left;
  background-color: #FFFFFF; }

[tabindex="-1"]:focus {
  outline: 0 !important; }

hr {
  box-sizing: content-box;
  height: 0;
  overflow: visible; }

h1, h2, h3, h4, h5, h6 {
  margin-top: 0;
  margin-bottom: 3rem; }

p {
  margin-top: 0;
  margin-bottom: 2rem; }

abbr[title],
abbr[data-original-title] {
  text-decoration: underline;
  -webkit-text-decoration: underline dotted;
          text-decoration: underline dotted;
  cursor: help;
  border-bottom: 0; }

address {
  margin-bottom: 1rem;
  font-style: normal;
  line-height: inherit; }

ol,
ul,
dl {
  margin-top: 0;
  margin-bottom: 1rem; }

ol ol,
ul ul,
ol ul,
ul ol {
  margin-bottom: 0; }

dt {
  font-weight: 700; }

dd {
  margin-bottom: .5rem;
  margin-left: 0; }

blockquote {
  margin: 0 0 1rem; }

dfn {
  font-style: italic; }

b,
strong {
  font-weight: bolder; }

small {
  font-size: 80%; }

sub,
sup {
  position: relative;
  font-size: 75%;
  line-height: 0;
  vertical-align: baseline; }

sub {
  bottom: -.25em; }

sup {
  top: -.5em; }

a {
  color: #454545;
  text-decoration: none;
  background-color: transparent;
  -webkit-text-decoration-skip: objects; }
  a:hover {
    color: #e5291d;
    text-decoration: underline; }

a:not([href]):not([tabindex]) {
  color: inherit;
  text-decoration: none; }
  a:not([href]):not([tabindex]):hover, a:not([href]):not([tabindex]):focus {
    color: inherit;
    text-decoration: none; }
  a:not([href]):not([tabindex]):focus {
    outline: 0; }

pre,
code,
kbd,
samp {
  font-family: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
  font-size: 1em; }

pre {
  margin-top: 0;
  margin-bottom: 1rem;
  overflow: auto;
  -ms-overflow-style: scrollbar; }

figure {
  margin: 0 0 1rem; }

img {
  vertical-align: middle;
  border-style: none; }

svg {
  overflow: hidden;
  vertical-align: middle; }

table {
  border-collapse: collapse; }

caption {
  padding-top: 1rem;
  padding-bottom: 1rem;
  color: #757575;
  text-align: left;
  caption-side: bottom; }

th {
  text-align: inherit; }

label {
  display: inline-block;
  margin-bottom: 0.7rem; }

button {
  border-radius: 0; }

button:focus {
  outline: 1px dotted;
  outline: 5px auto -webkit-focus-ring-color; }

input,
button,
select,
optgroup,
textarea {
  margin: 0;
  font-family: inherit;
  font-size: inherit;
  line-height: inherit; }

button,
input {
  overflow: visible; }

button,
select {
  text-transform: none; }

button,
html [type="button"],
[type="reset"],
[type="submit"] {
  -webkit-appearance: button; }

button::-moz-focus-inner,
[type="button"]::-moz-focus-inner,
[type="reset"]::-moz-focus-inner,
[type="submit"]::-moz-focus-inner {
  padding: 0;
  border-style: none; }

input[type="radio"],
input[type="checkbox"] {
  box-sizing: border-box;
  padding: 0; }

input[type="date"],
input[type="time"],
input[type="datetime-local"],
input[type="month"] {
  -webkit-appearance: listbox; }

textarea {
  overflow: auto;
  resize: vertical; }

fieldset {
  min-width: 0;
  padding: 0;
  margin: 0;
  border: 0; }

legend {
  display: block;
  width: 100%;
  max-width: 100%;
  padding: 0;
  margin-bottom: .5rem;
  font-size: 1.5rem;
  line-height: inherit;
  color: inherit;
  white-space: normal; }

progress {
  vertical-align: baseline; }

[type="number"]::-webkit-inner-spin-button,
[type="number"]::-webkit-outer-spin-button {
  height: auto; }

[type="search"] {
  outline-offset: -2px;
  -webkit-appearance: none; }

[type="search"]::-webkit-search-cancel-button,
[type="search"]::-webkit-search-decoration {
  -webkit-appearance: none; }

::-webkit-file-upload-button {
  font: inherit;
  -webkit-appearance: button; }

output {
  display: inline-block; }

summary {
  display: list-item;
  cursor: pointer; }

template {
  display: none; }

[hidden] {
  display: none !important; }

h1, h2, h3, h4, h5, h6,
.h1, .h2, .h3, .header-megamenu-nav-menu > .menu > .menu-item:nth-of-type(1) a, .h4, .h5, .h6 {
  margin-bottom: 3rem;
  font-family: inherit;
  font-weight: 700;
  line-height: inherit;
  color: #171717; }

h1, .h1 {
  font-size: 2.8rem; }

h2, .h2 {
  font-size: 2.2rem; }

h3, .h3, .header-megamenu-nav-menu > .menu > .menu-item:nth-of-type(1) a {
  font-size: 2rem; }

h4, .h4 {
  font-size: 1.8rem; }

h5, .h5 {
  font-size: 1.6rem; }

h6, .h6 {
  font-size: 1.6rem; }

.lead {
  font-size: 1.6rem;
  font-weight: 500; }

.display-1 {
  font-size: 2.8rem;
  font-weight: 700;
  line-height: inherit; }

.display-2 {
  font-size: 2.2rem;
  font-weight: 700;
  line-height: inherit; }

.display-3 {
  font-size: 2rem;
  font-weight: 700;
  line-height: inherit; }

.display-4 {
  font-size: 1.8rem;
  font-weight: 600;
  line-height: inherit; }

hr {
  margin-top: 2rem;
  margin-bottom: 2rem;
  border: 0;
  border-top: 0.1rem solid #CCCCCC; }

small,
.small {
  font-size: 80%;
  font-weight: 400; }

mark,
.mark {
  padding: 0.2em;
  background-color: #fcf8e3; }

.list-unstyled {
  padding-left: 0;
  list-style: none; }

.list-inline {
  padding-left: 0;
  list-style: none; }

.list-inline-item {
  display: inline-block; }
  .list-inline-item:not(:last-child) {
    margin-right: 0.5rem; }

.initialism {
  font-size: 90%;
  text-transform: uppercase; }

.blockquote {
  margin-bottom: 1rem;
  font-size: 2rem; }

.blockquote-footer {
  display: block;
  font-size: 80%;
  color: #6c757d; }
  .blockquote-footer::before {
    content: "\2014 \00A0"; }

.img-fluid {
  max-width: 100%;
  height: auto; }

.img-thumbnail {
  padding: 0.25rem;
  background-color: #FFFFFF;
  border: 0.1rem solid #CCCCCC;
  border-radius: 0;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.075);
  max-width: 100%;
  height: auto; }

.figure {
  display: inline-block; }

.figure-img {
  margin-bottom: 0.5rem;
  line-height: 1; }

.figure-caption {
  font-size: 90%;
  color: #6c757d; }

.container {
  width: 100%;
  padding-right: 1.5rem;
  padding-left: 1.5rem;
  margin-right: auto;
  margin-left: auto; }
  @media (min-width: 576px) {
    .container {
      max-width: 54rem; } }
  @media (min-width: 768px) {
    .container {
      max-width: 72rem; } }
  @media (min-width: 992px) {
    .container {
      max-width: 96rem; } }
  @media (min-width: 1200px) {
    .container {
      max-width: 116rem; } }
  @media (min-width: 1400px) {
    .container {
      max-width: 124rem; } }
  @media (min-width: 1600px) {
    .container {
      max-width: 144rem; } }

.container-fluid {
  width: 100%;
  padding-right: 1.5rem;
  padding-left: 1.5rem;
  margin-right: auto;
  margin-left: auto; }

.row {
  display: -webkit-box;
  display: flex;
  flex-wrap: wrap;
  margin-right: -1.5rem;
  margin-left: -1.5rem; }

.no-gutters {
  margin-right: 0;
  margin-left: 0; }
  .no-gutters > .col,
  .no-gutters > [class*="col-"] {
    padding-right: 0;
    padding-left: 0; }

.col-1, .col-2, .col-3, .col-4, .col-5, .col-6, .col-7, .col-8, .col-9, .col-10, .col-11, .col-12, .col,
.col-auto, .col-sm-1, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm,
.col-sm-auto, .col-md-1, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-10, .col-md-11, .col-md-12, .col-md,
.col-md-auto, .col-lg-1, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg,
.col-lg-auto, .col-xl-1, .col-xl-2, .col-xl-3, .col-xl-4, .col-xl-5, .col-xl-6, .col-xl-7, .col-xl-8, .col-xl-9, .col-xl-10, .col-xl-11, .col-xl-12, .col-xl,
.col-xl-auto, .col-xxl-1, .col-xxl-2, .col-xxl-3, .col-xxl-4, .col-xxl-5, .col-xxl-6, .col-xxl-7, .col-xxl-8, .col-xxl-9, .col-xxl-10, .col-xxl-11, .col-xxl-12, .col-xxl,
.col-xxl-auto, .col-xxxl-1, .col-xxxl-2, .col-xxxl-3, .col-xxxl-4, .col-xxxl-5, .col-xxxl-6, .col-xxxl-7, .col-xxxl-8, .col-xxxl-9, .col-xxxl-10, .col-xxxl-11, .col-xxxl-12, .col-xxxl,
.col-xxxl-auto {
  position: relative;
  width: 100%;
  min-height: 1px;
  padding-right: 1.5rem;
  padding-left: 1.5rem; }

.col {
  flex-basis: 0;
  -webkit-box-flex: 1;
          flex-grow: 1;
  max-width: 100%; }

.col-auto {
  -webkit-box-flex: 0;
          flex: 0 0 auto;
  width: auto;
  max-width: none; }

.col-1 {
  -webkit-box-flex: 0;
          flex: 0 0 8.33333%;
  max-width: 8.33333%; }

.col-2 {
  -webkit-box-flex: 0;
          flex: 0 0 16.66667%;
  max-width: 16.66667%; }

.col-3 {
  -webkit-box-flex: 0;
          flex: 0 0 25%;
  max-width: 25%; }

.col-4 {
  -webkit-box-flex: 0;
          flex: 0 0 33.33333%;
  max-width: 33.33333%; }

.col-5 {
  -webkit-box-flex: 0;
          flex: 0 0 41.66667%;
  max-width: 41.66667%; }

.col-6 {
  -webkit-box-flex: 0;
          flex: 0 0 50%;
  max-width: 50%; }

.col-7 {
  -webkit-box-flex: 0;
          flex: 0 0 58.33333%;
  max-width: 58.33333%; }

.col-8 {
  -webkit-box-flex: 0;
          flex: 0 0 66.66667%;
  max-width: 66.66667%; }

.col-9 {
  -webkit-box-flex: 0;
          flex: 0 0 75%;
  max-width: 75%; }

.col-10 {
  -webkit-box-flex: 0;
          flex: 0 0 83.33333%;
  max-width: 83.33333%; }

.col-11 {
  -webkit-box-flex: 0;
          flex: 0 0 91.66667%;
  max-width: 91.66667%; }

.col-12 {
  -webkit-box-flex: 0;
          flex: 0 0 100%;
  max-width: 100%; }

.order-first {
  -webkit-box-ordinal-group: 0;
          order: -1; }

.order-last {
  -webkit-box-ordinal-group: 14;
          order: 13; }

.order-0 {
  -webkit-box-ordinal-group: 1;
          order: 0; }

.order-1 {
  -webkit-box-ordinal-group: 2;
          order: 1; }

.order-2 {
  -webkit-box-ordinal-group: 3;
          order: 2; }

.order-3 {
  -webkit-box-ordinal-group: 4;
          order: 3; }

.order-4 {
  -webkit-box-ordinal-group: 5;
          order: 4; }

.order-5 {
  -webkit-box-ordinal-group: 6;
          order: 5; }

.order-6 {
  -webkit-box-ordinal-group: 7;
          order: 6; }

.order-7 {
  -webkit-box-ordinal-group: 8;
          order: 7; }

.order-8 {
  -webkit-box-ordinal-group: 9;
          order: 8; }

.order-9 {
  -webkit-box-ordinal-group: 10;
          order: 9; }

.order-10 {
  -webkit-box-ordinal-group: 11;
          order: 10; }

.order-11 {
  -webkit-box-ordinal-group: 12;
          order: 11; }

.order-12 {
  -webkit-box-ordinal-group: 13;
          order: 12; }

.offset-1 {
  margin-left: 8.33333%; }

.offset-2 {
  margin-left: 16.66667%; }

.offset-3 {
  margin-left: 25%; }

.offset-4 {
  margin-left: 33.33333%; }

.offset-5 {
  margin-left: 41.66667%; }

.offset-6 {
  margin-left: 50%; }

.offset-7 {
  margin-left: 58.33333%; }

.offset-8 {
  margin-left: 66.66667%; }

.offset-9 {
  margin-left: 75%; }

.offset-10 {
  margin-left: 83.33333%; }

.offset-11 {
  margin-left: 91.66667%; }

@media (min-width: 576px) {
  .col-sm {
    flex-basis: 0;
    -webkit-box-flex: 1;
            flex-grow: 1;
    max-width: 100%; }
  .col-sm-auto {
    -webkit-box-flex: 0;
            flex: 0 0 auto;
    width: auto;
    max-width: none; }
  .col-sm-1 {
    -webkit-box-flex: 0;
            flex: 0 0 8.33333%;
    max-width: 8.33333%; }
  .col-sm-2 {
    -webkit-box-flex: 0;
            flex: 0 0 16.66667%;
    max-width: 16.66667%; }
  .col-sm-3 {
    -webkit-box-flex: 0;
            flex: 0 0 25%;
    max-width: 25%; }
  .col-sm-4 {
    -webkit-box-flex: 0;
            flex: 0 0 33.33333%;
    max-width: 33.33333%; }
  .col-sm-5 {
    -webkit-box-flex: 0;
            flex: 0 0 41.66667%;
    max-width: 41.66667%; }
  .col-sm-6 {
    -webkit-box-flex: 0;
            flex: 0 0 50%;
    max-width: 50%; }
  .col-sm-7 {
    -webkit-box-flex: 0;
            flex: 0 0 58.33333%;
    max-width: 58.33333%; }
  .col-sm-8 {
    -webkit-box-flex: 0;
            flex: 0 0 66.66667%;
    max-width: 66.66667%; }
  .col-sm-9 {
    -webkit-box-flex: 0;
            flex: 0 0 75%;
    max-width: 75%; }
  .col-sm-10 {
    -webkit-box-flex: 0;
            flex: 0 0 83.33333%;
    max-width: 83.33333%; }
  .col-sm-11 {
    -webkit-box-flex: 0;
            flex: 0 0 91.66667%;
    max-width: 91.66667%; }
  .col-sm-12 {
    -webkit-box-flex: 0;
            flex: 0 0 100%;
    max-width: 100%; }
  .order-sm-first {
    -webkit-box-ordinal-group: 0;
            order: -1; }
  .order-sm-last {
    -webkit-box-ordinal-group: 14;
            order: 13; }
  .order-sm-0 {
    -webkit-box-ordinal-group: 1;
            order: 0; }
  .order-sm-1 {
    -webkit-box-ordinal-group: 2;
            order: 1; }
  .order-sm-2 {
    -webkit-box-ordinal-group: 3;
            order: 2; }
  .order-sm-3 {
    -webkit-box-ordinal-group: 4;
            order: 3; }
  .order-sm-4 {
    -webkit-box-ordinal-group: 5;
            order: 4; }
  .order-sm-5 {
    -webkit-box-ordinal-group: 6;
            order: 5; }
  .order-sm-6 {
    -webkit-box-ordinal-group: 7;
            order: 6; }
  .order-sm-7 {
    -webkit-box-ordinal-group: 8;
            order: 7; }
  .order-sm-8 {
    -webkit-box-ordinal-group: 9;
            order: 8; }
  .order-sm-9 {
    -webkit-box-ordinal-group: 10;
            order: 9; }
  .order-sm-10 {
    -webkit-box-ordinal-group: 11;
            order: 10; }
  .order-sm-11 {
    -webkit-box-ordinal-group: 12;
            order: 11; }
  .order-sm-12 {
    -webkit-box-ordinal-group: 13;
            order: 12; }
  .offset-sm-0 {
    margin-left: 0; }
  .offset-sm-1 {
    margin-left: 8.33333%; }
  .offset-sm-2 {
    margin-left: 16.66667%; }
  .offset-sm-3 {
    margin-left: 25%; }
  .offset-sm-4 {
    margin-left: 33.33333%; }
  .offset-sm-5 {
    margin-left: 41.66667%; }
  .offset-sm-6 {
    margin-left: 50%; }
  .offset-sm-7 {
    margin-left: 58.33333%; }
  .offset-sm-8 {
    margin-left: 66.66667%; }
  .offset-sm-9 {
    margin-left: 75%; }
  .offset-sm-10 {
    margin-left: 83.33333%; }
  .offset-sm-11 {
    margin-left: 91.66667%; } }

@media (min-width: 768px) {
  .col-md {
    flex-basis: 0;
    -webkit-box-flex: 1;
            flex-grow: 1;
    max-width: 100%; }
  .col-md-auto {
    -webkit-box-flex: 0;
            flex: 0 0 auto;
    width: auto;
    max-width: none; }
  .col-md-1 {
    -webkit-box-flex: 0;
            flex: 0 0 8.33333%;
    max-width: 8.33333%; }
  .col-md-2 {
    -webkit-box-flex: 0;
            flex: 0 0 16.66667%;
    max-width: 16.66667%; }
  .col-md-3 {
    -webkit-box-flex: 0;
            flex: 0 0 25%;
    max-width: 25%; }
  .col-md-4 {
    -webkit-box-flex: 0;
            flex: 0 0 33.33333%;
    max-width: 33.33333%; }
  .col-md-5 {
    -webkit-box-flex: 0;
            flex: 0 0 41.66667%;
    max-width: 41.66667%; }
  .col-md-6 {
    -webkit-box-flex: 0;
            flex: 0 0 50%;
    max-width: 50%; }
  .col-md-7 {
    -webkit-box-flex: 0;
            flex: 0 0 58.33333%;
    max-width: 58.33333%; }
  .col-md-8 {
    -webkit-box-flex: 0;
            flex: 0 0 66.66667%;
    max-width: 66.66667%; }
  .col-md-9 {
    -webkit-box-flex: 0;
            flex: 0 0 75%;
    max-width: 75%; }
  .col-md-10 {
    -webkit-box-flex: 0;
            flex: 0 0 83.33333%;
    max-width: 83.33333%; }
  .col-md-11 {
    -webkit-box-flex: 0;
            flex: 0 0 91.66667%;
    max-width: 91.66667%; }
  .col-md-12 {
    -webkit-box-flex: 0;
            flex: 0 0 100%;
    max-width: 100%; }
  .order-md-first {
    -webkit-box-ordinal-group: 0;
            order: -1; }
  .order-md-last {
    -webkit-box-ordinal-group: 14;
            order: 13; }
  .order-md-0 {
    -webkit-box-ordinal-group: 1;
            order: 0; }
  .order-md-1 {
    -webkit-box-ordinal-group: 2;
            order: 1; }
  .order-md-2 {
    -webkit-box-ordinal-group: 3;
            order: 2; }
  .order-md-3 {
    -webkit-box-ordinal-group: 4;
            order: 3; }
  .order-md-4 {
    -webkit-box-ordinal-group: 5;
            order: 4; }
  .order-md-5 {
    -webkit-box-ordinal-group: 6;
            order: 5; }
  .order-md-6 {
    -webkit-box-ordinal-group: 7;
            order: 6; }
  .order-md-7 {
    -webkit-box-ordinal-group: 8;
            order: 7; }
  .order-md-8 {
    -webkit-box-ordinal-group: 9;
            order: 8; }
  .order-md-9 {
    -webkit-box-ordinal-group: 10;
            order: 9; }
  .order-md-10 {
    -webkit-box-ordinal-group: 11;
            order: 10; }
  .order-md-11 {
    -webkit-box-ordinal-group: 12;
            order: 11; }
  .order-md-12 {
    -webkit-box-ordinal-group: 13;
            order: 12; }
  .offset-md-0 {
    margin-left: 0; }
  .offset-md-1 {
    margin-left: 8.33333%; }
  .offset-md-2 {
    margin-left: 16.66667%; }
  .offset-md-3 {
    margin-left: 25%; }
  .offset-md-4 {
    margin-left: 33.33333%; }
  .offset-md-5 {
    margin-left: 41.66667%; }
  .offset-md-6 {
    margin-left: 50%; }
  .offset-md-7 {
    margin-left: 58.33333%; }
  .offset-md-8 {
    margin-left: 66.66667%; }
  .offset-md-9 {
    margin-left: 75%; }
  .offset-md-10 {
    margin-left: 83.33333%; }
  .offset-md-11 {
    margin-left: 91.66667%; } }

@media (min-width: 992px) {
  .col-lg {
    flex-basis: 0;
    -webkit-box-flex: 1;
            flex-grow: 1;
    max-width: 100%; }
  .col-lg-auto {
    -webkit-box-flex: 0;
            flex: 0 0 auto;
    width: auto;
    max-width: none; }
  .col-lg-1 {
    -webkit-box-flex: 0;
            flex: 0 0 8.33333%;
    max-width: 8.33333%; }
  .col-lg-2 {
    -webkit-box-flex: 0;
            flex: 0 0 16.66667%;
    max-width: 16.66667%; }
  .col-lg-3 {
    -webkit-box-flex: 0;
            flex: 0 0 25%;
    max-width: 25%; }
  .col-lg-4 {
    -webkit-box-flex: 0;
            flex: 0 0 33.33333%;
    max-width: 33.33333%; }
  .col-lg-5 {
    -webkit-box-flex: 0;
            flex: 0 0 41.66667%;
    max-width: 41.66667%; }
  .col-lg-6 {
    -webkit-box-flex: 0;
            flex: 0 0 50%;
    max-width: 50%; }
  .col-lg-7 {
    -webkit-box-flex: 0;
            flex: 0 0 58.33333%;
    max-width: 58.33333%; }
  .col-lg-8 {
    -webkit-box-flex: 0;
            flex: 0 0 66.66667%;
    max-width: 66.66667%; }
  .col-lg-9 {
    -webkit-box-flex: 0;
            flex: 0 0 75%;
    max-width: 75%; }
  .col-lg-10 {
    -webkit-box-flex: 0;
            flex: 0 0 83.33333%;
    max-width: 83.33333%; }
  .col-lg-11 {
    -webkit-box-flex: 0;
            flex: 0 0 91.66667%;
    max-width: 91.66667%; }
  .col-lg-12 {
    -webkit-box-flex: 0;
            flex: 0 0 100%;
    max-width: 100%; }
  .order-lg-first {
    -webkit-box-ordinal-group: 0;
            order: -1; }
  .order-lg-last {
    -webkit-box-ordinal-group: 14;
            order: 13; }
  .order-lg-0 {
    -webkit-box-ordinal-group: 1;
            order: 0; }
  .order-lg-1 {
    -webkit-box-ordinal-group: 2;
            order: 1; }
  .order-lg-2 {
    -webkit-box-ordinal-group: 3;
            order: 2; }
  .order-lg-3 {
    -webkit-box-ordinal-group: 4;
            order: 3; }
  .order-lg-4 {
    -webkit-box-ordinal-group: 5;
            order: 4; }
  .order-lg-5 {
    -webkit-box-ordinal-group: 6;
            order: 5; }
  .order-lg-6 {
    -webkit-box-ordinal-group: 7;
            order: 6; }
  .order-lg-7 {
    -webkit-box-ordinal-group: 8;
            order: 7; }
  .order-lg-8 {
    -webkit-box-ordinal-group: 9;
            order: 8; }
  .order-lg-9 {
    -webkit-box-ordinal-group: 10;
            order: 9; }
  .order-lg-10 {
    -webkit-box-ordinal-group: 11;
            order: 10; }
  .order-lg-11 {
    -webkit-box-ordinal-group: 12;
            order: 11; }
  .order-lg-12 {
    -webkit-box-ordinal-group: 13;
            order: 12; }
  .offset-lg-0 {
    margin-left: 0; }
  .offset-lg-1 {
    margin-left: 8.33333%; }
  .offset-lg-2 {
    margin-left: 16.66667%; }
  .offset-lg-3 {
    margin-left: 25%; }
  .offset-lg-4 {
    margin-left: 33.33333%; }
  .offset-lg-5 {
    margin-left: 41.66667%; }
  .offset-lg-6 {
    margin-left: 50%; }
  .offset-lg-7 {
    margin-left: 58.33333%; }
  .offset-lg-8 {
    margin-left: 66.66667%; }
  .offset-lg-9 {
    margin-left: 75%; }
  .offset-lg-10 {
    margin-left: 83.33333%; }
  .offset-lg-11 {
    margin-left: 91.66667%; } }

@media (min-width: 1200px) {
  .col-xl {
    flex-basis: 0;
    -webkit-box-flex: 1;
            flex-grow: 1;
    max-width: 100%; }
  .col-xl-auto {
    -webkit-box-flex: 0;
            flex: 0 0 auto;
    width: auto;
    max-width: none; }
  .col-xl-1 {
    -webkit-box-flex: 0;
            flex: 0 0 8.33333%;
    max-width: 8.33333%; }
  .col-xl-2 {
    -webkit-box-flex: 0;
            flex: 0 0 16.66667%;
    max-width: 16.66667%; }
  .col-xl-3 {
    -webkit-box-flex: 0;
            flex: 0 0 25%;
    max-width: 25%; }
  .col-xl-4 {
    -webkit-box-flex: 0;
            flex: 0 0 33.33333%;
    max-width: 33.33333%; }
  .col-xl-5 {
    -webkit-box-flex: 0;
            flex: 0 0 41.66667%;
    max-width: 41.66667%; }
  .col-xl-6 {
    -webkit-box-flex: 0;
            flex: 0 0 50%;
    max-width: 50%; }
  .col-xl-7 {
    -webkit-box-flex: 0;
            flex: 0 0 58.33333%;
    max-width: 58.33333%; }
  .col-xl-8 {
    -webkit-box-flex: 0;
            flex: 0 0 66.66667%;
    max-width: 66.66667%; }
  .col-xl-9 {
    -webkit-box-flex: 0;
            flex: 0 0 75%;
    max-width: 75%; }
  .col-xl-10 {
    -webkit-box-flex: 0;
            flex: 0 0 83.33333%;
    max-width: 83.33333%; }
  .col-xl-11 {
    -webkit-box-flex: 0;
            flex: 0 0 91.66667%;
    max-width: 91.66667%; }
  .col-xl-12 {
    -webkit-box-flex: 0;
            flex: 0 0 100%;
    max-width: 100%; }
  .order-xl-first {
    -webkit-box-ordinal-group: 0;
            order: -1; }
  .order-xl-last {
    -webkit-box-ordinal-group: 14;
            order: 13; }
  .order-xl-0 {
    -webkit-box-ordinal-group: 1;
            order: 0; }
  .order-xl-1 {
    -webkit-box-ordinal-group: 2;
            order: 1; }
  .order-xl-2 {
    -webkit-box-ordinal-group: 3;
            order: 2; }
  .order-xl-3 {
    -webkit-box-ordinal-group: 4;
            order: 3; }
  .order-xl-4 {
    -webkit-box-ordinal-group: 5;
            order: 4; }
  .order-xl-5 {
    -webkit-box-ordinal-group: 6;
            order: 5; }
  .order-xl-6 {
    -webkit-box-ordinal-group: 7;
            order: 6; }
  .order-xl-7 {
    -webkit-box-ordinal-group: 8;
            order: 7; }
  .order-xl-8 {
    -webkit-box-ordinal-group: 9;
            order: 8; }
  .order-xl-9 {
    -webkit-box-ordinal-group: 10;
            order: 9; }
  .order-xl-10 {
    -webkit-box-ordinal-group: 11;
            order: 10; }
  .order-xl-11 {
    -webkit-box-ordinal-group: 12;
            order: 11; }
  .order-xl-12 {
    -webkit-box-ordinal-group: 13;
            order: 12; }
  .offset-xl-0 {
    margin-left: 0; }
  .offset-xl-1 {
    margin-left: 8.33333%; }
  .offset-xl-2 {
    margin-left: 16.66667%; }
  .offset-xl-3 {
    margin-left: 25%; }
  .offset-xl-4 {
    margin-left: 33.33333%; }
  .offset-xl-5 {
    margin-left: 41.66667%; }
  .offset-xl-6 {
    margin-left: 50%; }
  .offset-xl-7 {
    margin-left: 58.33333%; }
  .offset-xl-8 {
    margin-left: 66.66667%; }
  .offset-xl-9 {
    margin-left: 75%; }
  .offset-xl-10 {
    margin-left: 83.33333%; }
  .offset-xl-11 {
    margin-left: 91.66667%; } }

@media (min-width: 1400px) {
  .col-xxl {
    flex-basis: 0;
    -webkit-box-flex: 1;
            flex-grow: 1;
    max-width: 100%; }
  .col-xxl-auto {
    -webkit-box-flex: 0;
            flex: 0 0 auto;
    width: auto;
    max-width: none; }
  .col-xxl-1 {
    -webkit-box-flex: 0;
            flex: 0 0 8.33333%;
    max-width: 8.33333%; }
  .col-xxl-2 {
    -webkit-box-flex: 0;
            flex: 0 0 16.66667%;
    max-width: 16.66667%; }
  .col-xxl-3 {
    -webkit-box-flex: 0;
            flex: 0 0 25%;
    max-width: 25%; }
  .col-xxl-4 {
    -webkit-box-flex: 0;
            flex: 0 0 33.33333%;
    max-width: 33.33333%; }
  .col-xxl-5 {
    -webkit-box-flex: 0;
            flex: 0 0 41.66667%;
    max-width: 41.66667%; }
  .col-xxl-6 {
    -webkit-box-flex: 0;
            flex: 0 0 50%;
    max-width: 50%; }
  .col-xxl-7 {
    -webkit-box-flex: 0;
            flex: 0 0 58.33333%;
    max-width: 58.33333%; }
  .col-xxl-8 {
    -webkit-box-flex: 0;
            flex: 0 0 66.66667%;
    max-width: 66.66667%; }
  .col-xxl-9 {
    -webkit-box-flex: 0;
            flex: 0 0 75%;
    max-width: 75%; }
  .col-xxl-10 {
    -webkit-box-flex: 0;
            flex: 0 0 83.33333%;
    max-width: 83.33333%; }
  .col-xxl-11 {
    -webkit-box-flex: 0;
            flex: 0 0 91.66667%;
    max-width: 91.66667%; }
  .col-xxl-12 {
    -webkit-box-flex: 0;
            flex: 0 0 100%;
    max-width: 100%; }
  .order-xxl-first {
    -webkit-box-ordinal-group: 0;
            order: -1; }
  .order-xxl-last {
    -webkit-box-ordinal-group: 14;
            order: 13; }
  .order-xxl-0 {
    -webkit-box-ordinal-group: 1;
            order: 0; }
  .order-xxl-1 {
    -webkit-box-ordinal-group: 2;
            order: 1; }
  .order-xxl-2 {
    -webkit-box-ordinal-group: 3;
            order: 2; }
  .order-xxl-3 {
    -webkit-box-ordinal-group: 4;
            order: 3; }
  .order-xxl-4 {
    -webkit-box-ordinal-group: 5;
            order: 4; }
  .order-xxl-5 {
    -webkit-box-ordinal-group: 6;
            order: 5; }
  .order-xxl-6 {
    -webkit-box-ordinal-group: 7;
            order: 6; }
  .order-xxl-7 {
    -webkit-box-ordinal-group: 8;
            order: 7; }
  .order-xxl-8 {
    -webkit-box-ordinal-group: 9;
            order: 8; }
  .order-xxl-9 {
    -webkit-box-ordinal-group: 10;
            order: 9; }
  .order-xxl-10 {
    -webkit-box-ordinal-group: 11;
            order: 10; }
  .order-xxl-11 {
    -webkit-box-ordinal-group: 12;
            order: 11; }
  .order-xxl-12 {
    -webkit-box-ordinal-group: 13;
            order: 12; }
  .offset-xxl-0 {
    margin-left: 0; }
  .offset-xxl-1 {
    margin-left: 8.33333%; }
  .offset-xxl-2 {
    margin-left: 16.66667%; }
  .offset-xxl-3 {
    margin-left: 25%; }
  .offset-xxl-4 {
    margin-left: 33.33333%; }
  .offset-xxl-5 {
    margin-left: 41.66667%; }
  .offset-xxl-6 {
    margin-left: 50%; }
  .offset-xxl-7 {
    margin-left: 58.33333%; }
  .offset-xxl-8 {
    margin-left: 66.66667%; }
  .offset-xxl-9 {
    margin-left: 75%; }
  .offset-xxl-10 {
    margin-left: 83.33333%; }
  .offset-xxl-11 {
    margin-left: 91.66667%; } }

@media (min-width: 1600px) {
  .col-xxxl {
    flex-basis: 0;
    -webkit-box-flex: 1;
            flex-grow: 1;
    max-width: 100%; }
  .col-xxxl-auto {
    -webkit-box-flex: 0;
            flex: 0 0 auto;
    width: auto;
    max-width: none; }
  .col-xxxl-1 {
    -webkit-box-flex: 0;
            flex: 0 0 8.33333%;
    max-width: 8.33333%; }
  .col-xxxl-2 {
    -webkit-box-flex: 0;
            flex: 0 0 16.66667%;
    max-width: 16.66667%; }
  .col-xxxl-3 {
    -webkit-box-flex: 0;
            flex: 0 0 25%;
    max-width: 25%; }
  .col-xxxl-4 {
    -webkit-box-flex: 0;
            flex: 0 0 33.33333%;
    max-width: 33.33333%; }
  .col-xxxl-5 {
    -webkit-box-flex: 0;
            flex: 0 0 41.66667%;
    max-width: 41.66667%; }
  .col-xxxl-6 {
    -webkit-box-flex: 0;
            flex: 0 0 50%;
    max-width: 50%; }
  .col-xxxl-7 {
    -webkit-box-flex: 0;
            flex: 0 0 58.33333%;
    max-width: 58.33333%; }
  .col-xxxl-8 {
    -webkit-box-flex: 0;
            flex: 0 0 66.66667%;
    max-width: 66.66667%; }
  .col-xxxl-9 {
    -webkit-box-flex: 0;
            flex: 0 0 75%;
    max-width: 75%; }
  .col-xxxl-10 {
    -webkit-box-flex: 0;
            flex: 0 0 83.33333%;
    max-width: 83.33333%; }
  .col-xxxl-11 {
    -webkit-box-flex: 0;
            flex: 0 0 91.66667%;
    max-width: 91.66667%; }
  .col-xxxl-12 {
    -webkit-box-flex: 0;
            flex: 0 0 100%;
    max-width: 100%; }
  .order-xxxl-first {
    -webkit-box-ordinal-group: 0;
            order: -1; }
  .order-xxxl-last {
    -webkit-box-ordinal-group: 14;
            order: 13; }
  .order-xxxl-0 {
    -webkit-box-ordinal-group: 1;
            order: 0; }
  .order-xxxl-1 {
    -webkit-box-ordinal-group: 2;
            order: 1; }
  .order-xxxl-2 {
    -webkit-box-ordinal-group: 3;
            order: 2; }
  .order-xxxl-3 {
    -webkit-box-ordinal-group: 4;
            order: 3; }
  .order-xxxl-4 {
    -webkit-box-ordinal-group: 5;
            order: 4; }
  .order-xxxl-5 {
    -webkit-box-ordinal-group: 6;
            order: 5; }
  .order-xxxl-6 {
    -webkit-box-ordinal-group: 7;
            order: 6; }
  .order-xxxl-7 {
    -webkit-box-ordinal-group: 8;
            order: 7; }
  .order-xxxl-8 {
    -webkit-box-ordinal-group: 9;
            order: 8; }
  .order-xxxl-9 {
    -webkit-box-ordinal-group: 10;
            order: 9; }
  .order-xxxl-10 {
    -webkit-box-ordinal-group: 11;
            order: 10; }
  .order-xxxl-11 {
    -webkit-box-ordinal-group: 12;
            order: 11; }
  .order-xxxl-12 {
    -webkit-box-ordinal-group: 13;
            order: 12; }
  .offset-xxxl-0 {
    margin-left: 0; }
  .offset-xxxl-1 {
    margin-left: 8.33333%; }
  .offset-xxxl-2 {
    margin-left: 16.66667%; }
  .offset-xxxl-3 {
    margin-left: 25%; }
  .offset-xxxl-4 {
    margin-left: 33.33333%; }
  .offset-xxxl-5 {
    margin-left: 41.66667%; }
  .offset-xxxl-6 {
    margin-left: 50%; }
  .offset-xxxl-7 {
    margin-left: 58.33333%; }
  .offset-xxxl-8 {
    margin-left: 66.66667%; }
  .offset-xxxl-9 {
    margin-left: 75%; }
  .offset-xxxl-10 {
    margin-left: 83.33333%; }
  .offset-xxxl-11 {
    margin-left: 91.66667%; } }

.table {
  width: 100%;
  margin-bottom: 1rem;
  background-color: #FFFFFF; }
  .table th,
  .table td {
    padding: 1rem;
    vertical-align: top;
    border-top: 0.1rem solid #E4E4E4; }
  .table thead th {
    vertical-align: bottom;
    border-bottom: 0.2rem solid #E4E4E4; }
  .table tbody + tbody {
    border-top: 0.2rem solid #E4E4E4; }
  .table .table {
    background-color: #FFFFFF; }

.table-sm th,
.table-sm td {
  padding: 0.5rem; }

.table-bordered {
  border: 0.1rem solid #E4E4E4; }
  .table-bordered th,
  .table-bordered td {
    border: 0.1rem solid #E4E4E4; }
  .table-bordered thead th,
  .table-bordered thead td {
    border-bottom-width: 0.2rem; }

.table-borderless th,
.table-borderless td,
.table-borderless thead th,
.table-borderless tbody + tbody {
  border: 0; }

.table-striped tbody tr:nth-of-type(odd) {
  background-color: #F4F4F4; }

.table-hover tbody tr:hover {
  background-color: rgba(0, 0, 0, 0.075); }

.table-primary,
.table-primary > th,
.table-primary > td {
  background-color: #bababa; }

.table-hover .table-primary:hover {
  background-color: #adadad; }
  .table-hover .table-primary:hover > td,
  .table-hover .table-primary:hover > th {
    background-color: #adadad; }

.table-secondary,
.table-secondary > th,
.table-secondary > td {
  background-color: #f5b0ab; }

.table-hover .table-secondary:hover {
  background-color: #f29b94; }
  .table-hover .table-secondary:hover > td,
  .table-hover .table-secondary:hover > th {
    background-color: #f29b94; }

.table-success,
.table-success > th,
.table-success > td {
  background-color: #e1edbe; }

.table-hover .table-success:hover {
  background-color: #d8e7aa; }
  .table-hover .table-success:hover > td,
  .table-hover .table-success:hover > th {
    background-color: #d8e7aa; }

.table-info,
.table-info > th,
.table-info > td {
  background-color: #c6e9f0; }

.table-hover .table-info:hover {
  background-color: #b2e1eb; }
  .table-hover .table-info:hover > td,
  .table-hover .table-info:hover > th {
    background-color: #b2e1eb; }

.table-warning,
.table-warning > th,
.table-warning > td {
  background-color: #fbdcae; }

.table-hover .table-warning:hover {
  background-color: #fad296; }
  .table-hover .table-warning:hover > td,
  .table-hover .table-warning:hover > th {
    background-color: #fad296; }

.table-danger,
.table-danger > th,
.table-danger > td {
  background-color: #f5b0ab; }

.table-hover .table-danger:hover {
  background-color: #f29b94; }
  .table-hover .table-danger:hover > td,
  .table-hover .table-danger:hover > th {
    background-color: #f29b94; }

.table-light,
.table-light > th,
.table-light > td {
  background-color: #ececec; }

.table-hover .table-light:hover {
  background-color: #dfdfdf; }
  .table-hover .table-light:hover > td,
  .table-hover .table-light:hover > th {
    background-color: #dfdfdf; }

.table-dark,
.table-dark > th,
.table-dark > td {
  background-color: #bababa; }

.table-hover .table-dark:hover {
  background-color: #adadad; }
  .table-hover .table-dark:hover > td,
  .table-hover .table-dark:hover > th {
    background-color: #adadad; }

.table-lighter,
.table-lighter > th,
.table-lighter > td {
  background-color: #fbfbfb; }

.table-hover .table-lighter:hover {
  background-color: #eeeeee; }
  .table-hover .table-lighter:hover > td,
  .table-hover .table-lighter:hover > th {
    background-color: #eeeeee; }

.table-gray,
.table-gray > th,
.table-gray > td {
  background-color: #cccccc; }

.table-hover .table-gray:hover {
  background-color: #bfbfbf; }
  .table-hover .table-gray:hover > td,
  .table-hover .table-gray:hover > th {
    background-color: #bfbfbf; }

.table-gray-dark,
.table-gray-dark > th,
.table-gray-dark > td {
  background-color: darkgray; }

.table-hover .table-gray-dark:hover {
  background-color: #9c9c9c; }
  .table-hover .table-gray-dark:hover > td,
  .table-hover .table-gray-dark:hover > th {
    background-color: #9c9c9c; }

.table-active,
.table-active > th,
.table-active > td {
  background-color: rgba(0, 0, 0, 0.075); }

.table-hover .table-active:hover {
  background-color: rgba(0, 0, 0, 0.075); }
  .table-hover .table-active:hover > td,
  .table-hover .table-active:hover > th {
    background-color: rgba(0, 0, 0, 0.075); }

.table .thead-dark th {
  color: #FFFFFF;
  background-color: #e5291d;
  border-color: rgba(255, 255, 255, 0.35); }

.table .thead-light th {
  color: #454545;
  background-color: #E4E4E4;
  border-color: #E4E4E4; }

.table-dark {
  color: #FFFFFF;
  background-color: #e5291d; }
  .table-dark th,
  .table-dark td,
  .table-dark thead th {
    border-color: rgba(255, 255, 255, 0.35); }
  .table-dark.table-bordered {
    border: 0; }
  .table-dark.table-striped tbody tr:nth-of-type(odd) {
    background-color: rgba(255, 255, 255, 0.05); }
  .table-dark.table-hover tbody tr:hover {
    background-color: rgba(255, 255, 255, 0.075); }

@media (max-width: 575.98px) {
  .table-responsive-sm {
    display: block;
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    -ms-overflow-style: -ms-autohiding-scrollbar; }
    .table-responsive-sm > .table-bordered {
      border: 0; } }

@media (max-width: 767.98px) {
  .table-responsive-md {
    display: block;
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    -ms-overflow-style: -ms-autohiding-scrollbar; }
    .table-responsive-md > .table-bordered {
      border: 0; } }

@media (max-width: 991.98px) {
  .table-responsive-lg {
    display: block;
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    -ms-overflow-style: -ms-autohiding-scrollbar; }
    .table-responsive-lg > .table-bordered {
      border: 0; } }

@media (max-width: 1199.98px) {
  .table-responsive-xl {
    display: block;
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    -ms-overflow-style: -ms-autohiding-scrollbar; }
    .table-responsive-xl > .table-bordered {
      border: 0; } }

@media (max-width: 1399.98px) {
  .table-responsive-xxl {
    display: block;
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    -ms-overflow-style: -ms-autohiding-scrollbar; }
    .table-responsive-xxl > .table-bordered {
      border: 0; } }

@media (max-width: 1599.98px) {
  .table-responsive-xxxl {
    display: block;
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    -ms-overflow-style: -ms-autohiding-scrollbar; }
    .table-responsive-xxxl > .table-bordered {
      border: 0; } }

.table-responsive {
  display: block;
  width: 100%;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  -ms-overflow-style: -ms-autohiding-scrollbar; }
  .table-responsive > .table-bordered {
    border: 0; }

.form-control {
  display: block;
  width: 100%;
  height: calc(5.6rem + 0.2rem);
  padding: 1.8rem 2.2rem;
  font-size: 1.6rem;
  line-height: 1.25;
  color: #454545;
  background-color: #FFFFFF;
  background-clip: padding-box;
  border: 0.1rem solid #CCCCCC;
  border-radius: 0;
  box-shadow: none;
  -webkit-transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out; }
  @media screen and (prefers-reduced-motion: reduce) {
    .form-control {
      -webkit-transition: none;
      transition: none; } }
  .form-control::-ms-expand {
    background-color: transparent;
    border: 0; }
  .form-control:focus {
    color: #454545;
    background-color: #FFFFFF;
    border-color: #171717 !important;
    outline: 0;
    box-shadow: none, none; }
  .form-control::-webkit-input-placeholder {
    color: #757575;
    opacity: 1; }
  .form-control::-moz-placeholder {
    color: #757575;
    opacity: 1; }
  .form-control:-ms-input-placeholder {
    color: #757575;
    opacity: 1; }
  .form-control::-ms-input-placeholder {
    color: #757575;
    opacity: 1; }
  .form-control::placeholder {
    color: #757575;
    opacity: 1; }
  .form-control:disabled, .form-control[readonly] {
    background-color: #E4E4E4;
    opacity: 1; }

select.form-control:focus::-ms-value {
  color: #454545;
  background-color: #FFFFFF; }

.form-control-file,
.form-control-range {
  display: block;
  width: 100%; }

.col-form-label {
  padding-top: calc(1.8rem + 0.1rem);
  padding-bottom: calc(1.8rem + 0.1rem);
  margin-bottom: 0;
  font-size: inherit;
  line-height: 1.25; }

.col-form-label-lg {
  padding-top: calc(0.5rem + 0.1rem);
  padding-bottom: calc(0.5rem + 0.1rem);
  font-size: 2rem;
  line-height: 1.5; }

.col-form-label-sm {
  padding-top: calc(0.25rem + 0.1rem);
  padding-bottom: calc(0.25rem + 0.1rem);
  font-size: 1.4rem;
  line-height: 1.5; }

.form-control-plaintext {
  display: block;
  width: 100%;
  padding-top: 1.8rem;
  padding-bottom: 1.8rem;
  margin-bottom: 0;
  line-height: 1.25;
  color: #454545;
  background-color: transparent;
  border: solid transparent;
  border-width: 0.1rem 0; }
  .form-control-plaintext.form-control-sm, .form-control-plaintext.form-control-lg {
    padding-right: 0;
    padding-left: 0; }

.form-control-sm {
  height: calc(2.6rem + 0.2rem);
  padding: 0.25rem 0.5rem;
  font-size: 1.4rem;
  line-height: 1.5;
  border-radius: 0.2rem; }

.form-control-lg {
  height: calc(4rem + 0.2rem);
  padding: 0.5rem 1rem;
  font-size: 2rem;
  line-height: 1.5;
  border-radius: 0.3rem; }

select.form-control[size], select.form-control[multiple] {
  height: auto; }

textarea.form-control {
  height: auto; }

.form-group {
  margin-bottom: 3rem; }

.form-text {
  display: block;
  margin-top: 1rem; }

.form-row {
  display: -webkit-box;
  display: flex;
  flex-wrap: wrap;
  margin-right: -5px;
  margin-left: -5px; }
  .form-row > .col,
  .form-row > [class*="col-"] {
    padding-right: 5px;
    padding-left: 5px; }

.form-check {
  position: relative;
  display: block;
  padding-left: 1.25rem; }

.form-check-input {
  position: absolute;
  margin-top: 0.3rem;
  margin-left: -1.25rem; }
  .form-check-input:disabled ~ .form-check-label {
    color: #757575; }

.form-check-label {
  margin-bottom: 0; }

.form-check-inline {
  display: -webkit-inline-box;
  display: inline-flex;
  -webkit-box-align: center;
          align-items: center;
  padding-left: 0;
  margin-right: 0.75rem; }
  .form-check-inline .form-check-input {
    position: static;
    margin-top: 0;
    margin-right: 0.3125rem;
    margin-left: 0; }

.valid-feedback {
  display: none;
  width: 100%;
  margin-top: 1rem;
  font-size: 80%;
  color: #AFCD50; }

.valid-tooltip {
  position: absolute;
  top: 100%;
  z-index: 5;
  display: none;
  max-width: 100%;
  padding: 0.25rem 0.5rem;
  margin-top: .1rem;
  font-size: 1.4rem;
  line-height: 1.25;
  color: #171717;
  background-color: rgba(175, 205, 80, 0.9);
  border-radius: 0; }

.was-validated .form-control:valid, .form-control.is-valid, .was-validated
.custom-select:valid,
.custom-select.is-valid {
  border-color: #AFCD50; }
  .was-validated .form-control:valid:focus, .form-control.is-valid:focus, .was-validated
  .custom-select:valid:focus,
  .custom-select.is-valid:focus {
    border-color: #AFCD50;
    box-shadow: 0 0 0 0rem rgba(175, 205, 80, 0.25); }
  .was-validated .form-control:valid ~ .valid-feedback,
  .was-validated .form-control:valid ~ .valid-tooltip, .form-control.is-valid ~ .valid-feedback,
  .form-control.is-valid ~ .valid-tooltip, .was-validated
  .custom-select:valid ~ .valid-feedback,
  .was-validated
  .custom-select:valid ~ .valid-tooltip,
  .custom-select.is-valid ~ .valid-feedback,
  .custom-select.is-valid ~ .valid-tooltip {
    display: block; }

.was-validated .form-control-file:valid ~ .valid-feedback,
.was-validated .form-control-file:valid ~ .valid-tooltip, .form-control-file.is-valid ~ .valid-feedback,
.form-control-file.is-valid ~ .valid-tooltip {
  display: block; }

.was-validated .form-check-input:valid ~ .form-check-label, .form-check-input.is-valid ~ .form-check-label {
  color: #AFCD50; }

.was-validated .form-check-input:valid ~ .valid-feedback,
.was-validated .form-check-input:valid ~ .valid-tooltip, .form-check-input.is-valid ~ .valid-feedback,
.form-check-input.is-valid ~ .valid-tooltip {
  display: block; }

.was-validated .custom-control-input:valid ~ .custom-control-label, .custom-control-input.is-valid ~ .custom-control-label {
  color: #AFCD50; }
  .was-validated .custom-control-input:valid ~ .custom-control-label::before, .custom-control-input.is-valid ~ .custom-control-label::before {
    background-color: #dce9b3; }

.was-validated .custom-control-input:valid ~ .valid-feedback,
.was-validated .custom-control-input:valid ~ .valid-tooltip, .custom-control-input.is-valid ~ .valid-feedback,
.custom-control-input.is-valid ~ .valid-tooltip {
  display: block; }

.was-validated .custom-control-input:valid:checked ~ .custom-control-label::before, .custom-control-input.is-valid:checked ~ .custom-control-label::before {
  background-color: #c1d878; }

.was-validated .custom-control-input:valid:focus ~ .custom-control-label::before, .custom-control-input.is-valid:focus ~ .custom-control-label::before {
  box-shadow: 0 0 0 1px #FFFFFF, 0 0 0 0rem rgba(175, 205, 80, 0.25); }

.was-validated .custom-file-input:valid ~ .custom-file-label, .custom-file-input.is-valid ~ .custom-file-label {
  border-color: #AFCD50; }
  .was-validated .custom-file-input:valid ~ .custom-file-label::after, .custom-file-input.is-valid ~ .custom-file-label::after {
    border-color: inherit; }

.was-validated .custom-file-input:valid ~ .valid-feedback,
.was-validated .custom-file-input:valid ~ .valid-tooltip, .custom-file-input.is-valid ~ .valid-feedback,
.custom-file-input.is-valid ~ .valid-tooltip {
  display: block; }

.was-validated .custom-file-input:valid:focus ~ .custom-file-label, .custom-file-input.is-valid:focus ~ .custom-file-label {
  box-shadow: 0 0 0 0rem rgba(175, 205, 80, 0.25); }

.invalid-feedback {
  display: none;
  width: 100%;
  margin-top: 1rem;
  font-size: 80%;
  color: #e5291d; }

.invalid-tooltip {
  position: absolute;
  top: 100%;
  z-index: 5;
  display: none;
  max-width: 100%;
  padding: 0.25rem 0.5rem;
  margin-top: .1rem;
  font-size: 1.4rem;
  line-height: 1.25;
  color: #FFFFFF;
  background-color: rgba(229, 41, 29, 0.9);
  border-radius: 0; }

.was-validated .form-control:invalid, .form-control.is-invalid, .was-validated
.custom-select:invalid,
.custom-select.is-invalid {
  border-color: #e5291d; }
  .was-validated .form-control:invalid:focus, .form-control.is-invalid:focus, .was-validated
  .custom-select:invalid:focus,
  .custom-select.is-invalid:focus {
    border-color: #e5291d;
    box-shadow: 0 0 0 0rem rgba(229, 41, 29, 0.25); }
  .was-validated .form-control:invalid ~ .invalid-feedback,
  .was-validated .form-control:invalid ~ .invalid-tooltip, .form-control.is-invalid ~ .invalid-feedback,
  .form-control.is-invalid ~ .invalid-tooltip, .was-validated
  .custom-select:invalid ~ .invalid-feedback,
  .was-validated
  .custom-select:invalid ~ .invalid-tooltip,
  .custom-select.is-invalid ~ .invalid-feedback,
  .custom-select.is-invalid ~ .invalid-tooltip {
    display: block; }

.was-validated .form-control-file:invalid ~ .invalid-feedback,
.was-validated .form-control-file:invalid ~ .invalid-tooltip, .form-control-file.is-invalid ~ .invalid-feedback,
.form-control-file.is-invalid ~ .invalid-tooltip {
  display: block; }

.was-validated .form-check-input:invalid ~ .form-check-label, .form-check-input.is-invalid ~ .form-check-label {
  color: #e5291d; }

.was-validated .form-check-input:invalid ~ .invalid-feedback,
.was-validated .form-check-input:invalid ~ .invalid-tooltip, .form-check-input.is-invalid ~ .invalid-feedback,
.form-check-input.is-invalid ~ .invalid-tooltip {
  display: block; }

.was-validated .custom-control-input:invalid ~ .custom-control-label, .custom-control-input.is-invalid ~ .custom-control-label {
  color: #e5291d; }
  .was-validated .custom-control-input:invalid ~ .custom-control-label::before, .custom-control-input.is-invalid ~ .custom-control-label::before {
    background-color: #f2958f; }

.was-validated .custom-control-input:invalid ~ .invalid-feedback,
.was-validated .custom-control-input:invalid ~ .invalid-tooltip, .custom-control-input.is-invalid ~ .invalid-feedback,
.custom-control-input.is-invalid ~ .invalid-tooltip {
  display: block; }

.was-validated .custom-control-input:invalid:checked ~ .custom-control-label::before, .custom-control-input.is-invalid:checked ~ .custom-control-label::before {
  background-color: #ea544b; }

.was-validated .custom-control-input:invalid:focus ~ .custom-control-label::before, .custom-control-input.is-invalid:focus ~ .custom-control-label::before {
  box-shadow: 0 0 0 1px #FFFFFF, 0 0 0 0rem rgba(229, 41, 29, 0.25); }

.was-validated .custom-file-input:invalid ~ .custom-file-label, .custom-file-input.is-invalid ~ .custom-file-label {
  border-color: #e5291d; }
  .was-validated .custom-file-input:invalid ~ .custom-file-label::after, .custom-file-input.is-invalid ~ .custom-file-label::after {
    border-color: inherit; }

.was-validated .custom-file-input:invalid ~ .invalid-feedback,
.was-validated .custom-file-input:invalid ~ .invalid-tooltip, .custom-file-input.is-invalid ~ .invalid-feedback,
.custom-file-input.is-invalid ~ .invalid-tooltip {
  display: block; }

.was-validated .custom-file-input:invalid:focus ~ .custom-file-label, .custom-file-input.is-invalid:focus ~ .custom-file-label {
  box-shadow: 0 0 0 0rem rgba(229, 41, 29, 0.25); }

.form-inline {
  display: -webkit-box;
  display: flex;
  -webkit-box-orient: horizontal;
  -webkit-box-direction: normal;
          flex-flow: row wrap;
  -webkit-box-align: center;
          align-items: center; }
  .form-inline .form-check {
    width: 100%; }
  @media (min-width: 576px) {
    .form-inline label {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
              align-items: center;
      -webkit-box-pack: center;
              justify-content: center;
      margin-bottom: 0; }
    .form-inline .form-group {
      display: -webkit-box;
      display: flex;
      -webkit-box-flex: 0;
              flex: 0 0 auto;
      -webkit-box-orient: horizontal;
      -webkit-box-direction: normal;
              flex-flow: row wrap;
      -webkit-box-align: center;
              align-items: center;
      margin-bottom: 0; }
    .form-inline .form-control {
      display: inline-block;
      width: auto;
      vertical-align: middle; }
    .form-inline .form-control-plaintext {
      display: inline-block; }
    .form-inline .input-group,
    .form-inline .custom-select {
      width: auto; }
    .form-inline .form-check {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: center;
              align-items: center;
      -webkit-box-pack: center;
              justify-content: center;
      width: auto;
      padding-left: 0; }
    .form-inline .form-check-input {
      position: relative;
      margin-top: 0;
      margin-right: 0.25rem;
      margin-left: 0; }
    .form-inline .custom-control {
      -webkit-box-align: center;
              align-items: center;
      -webkit-box-pack: center;
              justify-content: center; }
    .form-inline .custom-control-label {
      margin-bottom: 0; } }

.btn, .region-header-right .nav-link-user > a,
.region-header-right .nav-link-user > button {
  display: inline-block;
  font-weight: 500;
  text-align: center;
  white-space: nowrap;
  vertical-align: middle;
  -webkit-user-select: none;
     -moz-user-select: none;
      -ms-user-select: none;
          user-select: none;
  border: 0.1rem solid transparent;
  padding: 1.8rem 2.2rem;
  font-size: 1.6rem;
  line-height: 1.25;
  border-radius: 0;
  -webkit-transition: color 0.3s ease-in-out, background-color 0.3s ease-in-out, border-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
  transition: color 0.3s ease-in-out, background-color 0.3s ease-in-out, border-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out; }
  @media screen and (prefers-reduced-motion: reduce) {
    .btn, .region-header-right .nav-link-user > a,
    .region-header-right .nav-link-user > button {
      -webkit-transition: none;
      transition: none; } }
  .btn:hover, .region-header-right .nav-link-user > a:hover,
  .region-header-right .nav-link-user > button:hover, .btn:focus, .region-header-right .nav-link-user > a:focus,
  .region-header-right .nav-link-user > button:focus {
    text-decoration: none; }
  .btn:focus, .region-header-right .nav-link-user > a:focus,
  .region-header-right .nav-link-user > button:focus, .btn.focus, .region-header-right .nav-link-user > a.focus,
  .region-header-right .nav-link-user > button.focus {
    box-shadow: none; }
  .btn.disabled, .region-header-right .nav-link-user > a.disabled,
  .region-header-right .nav-link-user > button.disabled, .btn:disabled, .region-header-right .nav-link-user > a:disabled,
  .region-header-right .nav-link-user > button:disabled {
    opacity: 1;
    box-shadow: none; }
  .btn:not(:disabled):not(.disabled), .region-header-right .nav-link-user > a:not(:disabled):not(.disabled),
  .region-header-right .nav-link-user > button:not(:disabled):not(.disabled) {
    cursor: pointer; }
  .btn:not(:disabled):not(.disabled):active, .region-header-right .nav-link-user > a:not(:disabled):not(.disabled):active,
  .region-header-right .nav-link-user > button:not(:disabled):not(.disabled):active, .btn:not(:disabled):not(.disabled).active, .region-header-right .nav-link-user > a:not(:disabled):not(.disabled).active,
  .region-header-right .nav-link-user > button:not(:disabled):not(.disabled).active {
    box-shadow: none; }
    .btn:not(:disabled):not(.disabled):active:focus, .region-header-right .nav-link-user > a:not(:disabled):not(.disabled):active:focus,
    .region-header-right .nav-link-user > button:not(:disabled):not(.disabled):active:focus, .btn:not(:disabled):not(.disabled).active:focus, .region-header-right .nav-link-user > a:not(:disabled):not(.disabled).active:focus,
    .region-header-right .nav-link-user > button:not(:disabled):not(.disabled).active:focus {
      box-shadow: none, none; }

a.btn.disabled, .region-header-right .nav-link-user > a.disabled,
fieldset:disabled a.btn,
fieldset:disabled .region-header-right .nav-link-user > a,
.region-header-right fieldset:disabled .nav-link-user > a {
  pointer-events: none; }

.btn-primary {
  color: #FFFFFF;
  background-color: #454545;
  border-color: #454545;
  box-shadow: none; }
  .btn-primary:hover {
    color: #FFFFFF;
    background-color: #323232;
    border-color: #2c2c2c; }
  .btn-primary:focus, .btn-primary.focus {
    box-shadow: none, 0 0 0 0rem rgba(69, 69, 69, 0.5); }
  .btn-primary.disabled, .btn-primary:disabled {
    color: #FFFFFF;
    background-color: #454545;
    border-color: #454545; }
  .btn-primary:not(:disabled):not(.disabled):active, .btn-primary:not(:disabled):not(.disabled).active,
  .show > .btn-primary.dropdown-toggle {
    color: #FFFFFF;
    background-color: #2c2c2c;
    border-color: #252525; }
    .btn-primary:not(:disabled):not(.disabled):active:focus, .btn-primary:not(:disabled):not(.disabled).active:focus,
    .show > .btn-primary.dropdown-toggle:focus {
      box-shadow: none, 0 0 0 0rem rgba(69, 69, 69, 0.5); }

.btn-secondary {
  color: #FFFFFF;
  background-color: #e5291d;
  border-color: #e5291d;
  box-shadow: none; }
  .btn-secondary:hover {
    color: #FFFFFF;
    background-color: #c52117;
    border-color: #ba1f15; }
  .btn-secondary:focus, .btn-secondary.focus {
    box-shadow: none, 0 0 0 0rem rgba(229, 41, 29, 0.5); }
  .btn-secondary.disabled, .btn-secondary:disabled {
    color: #FFFFFF;
    background-color: #e5291d;
    border-color: #e5291d; }
  .btn-secondary:not(:disabled):not(.disabled):active, .btn-secondary:not(:disabled):not(.disabled).active,
  .show > .btn-secondary.dropdown-toggle {
    color: #FFFFFF;
    background-color: #ba1f15;
    border-color: #ae1d14; }
    .btn-secondary:not(:disabled):not(.disabled):active:focus, .btn-secondary:not(:disabled):not(.disabled).active:focus,
    .show > .btn-secondary.dropdown-toggle:focus {
      box-shadow: none, 0 0 0 0rem rgba(229, 41, 29, 0.5); }

.btn-success {
  color: #171717;
  background-color: #AFCD50;
  border-color: #AFCD50;
  box-shadow: none; }
  .btn-success:hover {
    color: #171717;
    background-color: #9fc037;
    border-color: #97b634; }
  .btn-success:focus, .btn-success.focus {
    box-shadow: none, 0 0 0 0rem rgba(175, 205, 80, 0.5); }
  .btn-success.disabled, .btn-success:disabled {
    color: #171717;
    background-color: #AFCD50;
    border-color: #AFCD50; }
  .btn-success:not(:disabled):not(.disabled):active, .btn-success:not(:disabled):not(.disabled).active,
  .show > .btn-success.dropdown-toggle {
    color: #171717;
    background-color: #97b634;
    border-color: #8fac31; }
    .btn-success:not(:disabled):not(.disabled):active:focus, .btn-success:not(:disabled):not(.disabled).active:focus,
    .show > .btn-success.dropdown-toggle:focus {
      box-shadow: none, 0 0 0 0rem rgba(175, 205, 80, 0.5); }

.btn-info {
  color: #171717;
  background-color: #64C3D7;
  border-color: #64C3D7;
  box-shadow: none; }
  .btn-info:hover {
    color: #171717;
    background-color: #46b7cf;
    border-color: #3bb3cd; }
  .btn-info:focus, .btn-info.focus {
    box-shadow: none, 0 0 0 0rem rgba(100, 195, 215, 0.5); }
  .btn-info.disabled, .btn-info:disabled {
    color: #171717;
    background-color: #64C3D7;
    border-color: #64C3D7; }
  .btn-info:not(:disabled):not(.disabled):active, .btn-info:not(:disabled):not(.disabled).active,
  .show > .btn-info.dropdown-toggle {
    color: #FFFFFF;
    background-color: #3bb3cd;
    border-color: #34aec8; }
    .btn-info:not(:disabled):not(.disabled):active:focus, .btn-info:not(:disabled):not(.disabled).active:focus,
    .show > .btn-info.dropdown-toggle:focus {
      box-shadow: none, 0 0 0 0rem rgba(100, 195, 215, 0.5); }

.btn-warning {
  color: #171717;
  background-color: #F5A023;
  border-color: #F5A023;
  box-shadow: none; }
  .btn-warning:hover {
    color: #171717;
    background-color: #e78e0b;
    border-color: #db860a; }
  .btn-warning:focus, .btn-warning.focus {
    box-shadow: none, 0 0 0 0rem rgba(245, 160, 35, 0.5); }
  .btn-warning.disabled, .btn-warning:disabled {
    color: #171717;
    background-color: #F5A023;
    border-color: #F5A023; }
  .btn-warning:not(:disabled):not(.disabled):active, .btn-warning:not(:disabled):not(.disabled).active,
  .show > .btn-warning.dropdown-toggle {
    color: #FFFFFF;
    background-color: #db860a;
    border-color: #cf7f09; }
    .btn-warning:not(:disabled):not(.disabled):active:focus, .btn-warning:not(:disabled):not(.disabled).active:focus,
    .show > .btn-warning.dropdown-toggle:focus {
      box-shadow: none, 0 0 0 0rem rgba(245, 160, 35, 0.5); }

.btn-danger {
  color: #FFFFFF;
  background-color: #e5291d;
  border-color: #e5291d;
  box-shadow: none; }
  .btn-danger:hover {
    color: #FFFFFF;
    background-color: #c52117;
    border-color: #ba1f15; }
  .btn-danger:focus, .btn-danger.focus {
    box-shadow: none, 0 0 0 0rem rgba(229, 41, 29, 0.5); }
  .btn-danger.disabled, .btn-danger:disabled {
    color: #FFFFFF;
    background-color: #e5291d;
    border-color: #e5291d; }
  .btn-danger:not(:disabled):not(.disabled):active, .btn-danger:not(:disabled):not(.disabled).active,
  .show > .btn-danger.dropdown-toggle {
    color: #FFFFFF;
    background-color: #ba1f15;
    border-color: #ae1d14; }
    .btn-danger:not(:disabled):not(.disabled):active:focus, .btn-danger:not(:disabled):not(.disabled).active:focus,
    .show > .btn-danger.dropdown-toggle:focus {
      box-shadow: none, 0 0 0 0rem rgba(229, 41, 29, 0.5); }

.btn-light {
  color: #171717;
  background-color: #CCCCCC;
  border-color: #CCCCCC;
  box-shadow: none; }
  .btn-light:hover {
    color: #171717;
    background-color: #b9b9b9;
    border-color: #b3b3b3; }
  .btn-light:focus, .btn-light.focus {
    box-shadow: none, 0 0 0 0rem rgba(204, 204, 204, 0.5); }
  .btn-light.disabled, .btn-light:disabled {
    color: #171717;
    background-color: #CCCCCC;
    border-color: #CCCCCC; }
  .btn-light:not(:disabled):not(.disabled):active, .btn-light:not(:disabled):not(.disabled).active,
  .show > .btn-light.dropdown-toggle {
    color: #171717;
    background-color: #b3b3b3;
    border-color: #acacac; }
    .btn-light:not(:disabled):not(.disabled):active:focus, .btn-light:not(:disabled):not(.disabled).active:focus,
    .show > .btn-light.dropdown-toggle:focus {
      box-shadow: none, 0 0 0 0rem rgba(204, 204, 204, 0.5); }

.btn-dark {
  color: #FFFFFF;
  background-color: #454545;
  border-color: #454545;
  box-shadow: none; }
  .btn-dark:hover {
    color: #FFFFFF;
    background-color: #323232;
    border-color: #2c2c2c; }
  .btn-dark:focus, .btn-dark.focus {
    box-shadow: none, 0 0 0 0rem rgba(69, 69, 69, 0.5); }
  .btn-dark.disabled, .btn-dark:disabled {
    color: #FFFFFF;
    background-color: #454545;
    border-color: #454545; }
  .btn-dark:not(:disabled):not(.disabled):active, .btn-dark:not(:disabled):not(.disabled).active,
  .show > .btn-dark.dropdown-toggle {
    color: #FFFFFF;
    background-color: #2c2c2c;
    border-color: #252525; }
    .btn-dark:not(:disabled):not(.disabled):active:focus, .btn-dark:not(:disabled):not(.disabled).active:focus,
    .show > .btn-dark.dropdown-toggle:focus {
      box-shadow: none, 0 0 0 0rem rgba(69, 69, 69, 0.5); }

.btn-lighter {
  color: #171717;
  background-color: #F4F4F4;
  border-color: #F4F4F4;
  box-shadow: none; }
  .btn-lighter:hover {
    color: #171717;
    background-color: #e1e1e1;
    border-color: #dbdbdb; }
  .btn-lighter:focus, .btn-lighter.focus {
    box-shadow: none, 0 0 0 0rem rgba(244, 244, 244, 0.5); }
  .btn-lighter.disabled, .btn-lighter:disabled {
    color: #171717;
    background-color: #F4F4F4;
    border-color: #F4F4F4; }
  .btn-lighter:not(:disabled):not(.disabled):active, .btn-lighter:not(:disabled):not(.disabled).active,
  .show > .btn-lighter.dropdown-toggle {
    color: #171717;
    background-color: #dbdbdb;
    border-color: #d4d4d4; }
    .btn-lighter:not(:disabled):not(.disabled):active:focus, .btn-lighter:not(:disabled):not(.disabled).active:focus,
    .show > .btn-lighter.dropdown-toggle:focus {
      box-shadow: none, 0 0 0 0rem rgba(244, 244, 244, 0.5); }

.btn-gray {
  color: #FFFFFF;
  background-color: #757575;
  border-color: #757575;
  box-shadow: none; }
  .btn-gray:hover {
    color: #FFFFFF;
    background-color: #626262;
    border-color: #5c5c5c; }
  .btn-gray:focus, .btn-gray.focus {
    box-shadow: none, 0 0 0 0rem rgba(117, 117, 117, 0.5); }
  .btn-gray.disabled, .btn-gray:disabled {
    color: #FFFFFF;
    background-color: #757575;
    border-color: #757575; }
  .btn-gray:not(:disabled):not(.disabled):active, .btn-gray:not(:disabled):not(.disabled).active,
  .show > .btn-gray.dropdown-toggle {
    color: #FFFFFF;
    background-color: #5c5c5c;
    border-color: #555555; }
    .btn-gray:not(:disabled):not(.disabled):active:focus, .btn-gray:not(:disabled):not(.disabled).active:focus,
    .show > .btn-gray.dropdown-toggle:focus {
      box-shadow: none, 0 0 0 0rem rgba(117, 117, 117, 0.5); }

.btn-gray-dark {
  color: #FFFFFF;
  background-color: #171717;
  border-color: #171717;
  box-shadow: none; }
  .btn-gray-dark:hover {
    color: #FFFFFF;
    background-color: #040404;
    border-color: black; }
  .btn-gray-dark:focus, .btn-gray-dark.focus {
    box-shadow: none, 0 0 0 0rem rgba(23, 23, 23, 0.5); }
  .btn-gray-dark.disabled, .btn-gray-dark:disabled {
    color: #FFFFFF;
    background-color: #171717;
    border-color: #171717; }
  .btn-gray-dark:not(:disabled):not(.disabled):active, .btn-gray-dark:not(:disabled):not(.disabled).active,
  .show > .btn-gray-dark.dropdown-toggle {
    color: #FFFFFF;
    background-color: black;
    border-color: black; }
    .btn-gray-dark:not(:disabled):not(.disabled):active:focus, .btn-gray-dark:not(:disabled):not(.disabled).active:focus,
    .show > .btn-gray-dark.dropdown-toggle:focus {
      box-shadow: none, 0 0 0 0rem rgba(23, 23, 23, 0.5); }

.btn-outline-primary {
  color: #454545;
  background-color: transparent;
  background-image: none;
  border-color: #454545; }
  .btn-outline-primary:hover {
    color: #FFFFFF;
    background-color: #454545;
    border-color: #454545; }
  .btn-outline-primary:focus, .btn-outline-primary.focus {
    box-shadow: 0 0 0 0rem rgba(69, 69, 69, 0.5); }
  .btn-outline-primary.disabled, .btn-outline-primary:disabled {
    color: #454545;
    background-color: transparent; }
  .btn-outline-primary:not(:disabled):not(.disabled):active, .btn-outline-primary:not(:disabled):not(.disabled).active,
  .show > .btn-outline-primary.dropdown-toggle {
    color: #FFFFFF;
    background-color: #454545;
    border-color: #454545; }
    .btn-outline-primary:not(:disabled):not(.disabled):active:focus, .btn-outline-primary:not(:disabled):not(.disabled).active:focus,
    .show > .btn-outline-primary.dropdown-toggle:focus {
      box-shadow: 0 0 0 0rem rgba(69, 69, 69, 0.5); }

.btn-outline-secondary {
  color: #e5291d;
  background-color: transparent;
  background-image: none;
  border-color: #e5291d; }
  .btn-outline-secondary:hover {
    color: #FFFFFF;
    background-color: #e5291d;
    border-color: #e5291d; }
  .btn-outline-secondary:focus, .btn-outline-secondary.focus {
    box-shadow: 0 0 0 0rem rgba(229, 41, 29, 0.5); }
  .btn-outline-secondary.disabled, .btn-outline-secondary:disabled {
    color: #e5291d;
    background-color: transparent; }
  .btn-outline-secondary:not(:disabled):not(.disabled):active, .btn-outline-secondary:not(:disabled):not(.disabled).active,
  .show > .btn-outline-secondary.dropdown-toggle {
    color: #FFFFFF;
    background-color: #e5291d;
    border-color: #e5291d; }
    .btn-outline-secondary:not(:disabled):not(.disabled):active:focus, .btn-outline-secondary:not(:disabled):not(.disabled).active:focus,
    .show > .btn-outline-secondary.dropdown-toggle:focus {
      box-shadow: 0 0 0 0rem rgba(229, 41, 29, 0.5); }

.btn-outline-success {
  color: #AFCD50;
  background-color: transparent;
  background-image: none;
  border-color: #AFCD50; }
  .btn-outline-success:hover {
    color: #171717;
    background-color: #AFCD50;
    border-color: #AFCD50; }
  .btn-outline-success:focus, .btn-outline-success.focus {
    box-shadow: 0 0 0 0rem rgba(175, 205, 80, 0.5); }
  .btn-outline-success.disabled, .btn-outline-success:disabled {
    color: #AFCD50;
    background-color: transparent; }
  .btn-outline-success:not(:disabled):not(.disabled):active, .btn-outline-success:not(:disabled):not(.disabled).active,
  .show > .btn-outline-success.dropdown-toggle {
    color: #171717;
    background-color: #AFCD50;
    border-color: #AFCD50; }
    .btn-outline-success:not(:disabled):not(.disabled):active:focus, .btn-outline-success:not(:disabled):not(.disabled).active:focus,
    .show > .btn-outline-success.dropdown-toggle:focus {
      box-shadow: 0 0 0 0rem rgba(175, 205, 80, 0.5); }

.btn-outline-info {
  color: #64C3D7;
  background-color: transparent;
  background-image: none;
  border-color: #64C3D7; }
  .btn-outline-info:hover {
    color: #171717;
    background-color: #64C3D7;
    border-color: #64C3D7; }
  .btn-outline-info:focus, .btn-outline-info.focus {
    box-shadow: 0 0 0 0rem rgba(100, 195, 215, 0.5); }
  .btn-outline-info.disabled, .btn-outline-info:disabled {
    color: #64C3D7;
    background-color: transparent; }
  .btn-outline-info:not(:disabled):not(.disabled):active, .btn-outline-info:not(:disabled):not(.disabled).active,
  .show > .btn-outline-info.dropdown-toggle {
    color: #171717;
    background-color: #64C3D7;
    border-color: #64C3D7; }
    .btn-outline-info:not(:disabled):not(.disabled):active:focus, .btn-outline-info:not(:disabled):not(.disabled).active:focus,
    .show > .btn-outline-info.dropdown-toggle:focus {
      box-shadow: 0 0 0 0rem rgba(100, 195, 215, 0.5); }

.btn-outline-warning {
  color: #F5A023;
  background-color: transparent;
  background-image: none;
  border-color: #F5A023; }
  .btn-outline-warning:hover {
    color: #171717;
    background-color: #F5A023;
    border-color: #F5A023; }
  .btn-outline-warning:focus, .btn-outline-warning.focus {
    box-shadow: 0 0 0 0rem rgba(245, 160, 35, 0.5); }
  .btn-outline-warning.disabled, .btn-outline-warning:disabled {
    color: #F5A023;
    background-color: transparent; }
  .btn-outline-warning:not(:disabled):not(.disabled):active, .btn-outline-warning:not(:disabled):not(.disabled).active,
  .show > .btn-outline-warning.dropdown-toggle {
    color: #171717;
    background-color: #F5A023;
    border-color: #F5A023; }
    .btn-outline-warning:not(:disabled):not(.disabled):active:focus, .btn-outline-warning:not(:disabled):not(.disabled).active:focus,
    .show > .btn-outline-warning.dropdown-toggle:focus {
      box-shadow: 0 0 0 0rem rgba(245, 160, 35, 0.5); }

.btn-outline-danger {
  color: #e5291d;
  background-color: transparent;
  background-image: none;
  border-color: #e5291d; }
  .btn-outline-danger:hover {
    color: #FFFFFF;
    background-color: #e5291d;
    border-color: #e5291d; }
  .btn-outline-danger:focus, .btn-outline-danger.focus {
    box-shadow: 0 0 0 0rem rgba(229, 41, 29, 0.5); }
  .btn-outline-danger.disabled, .btn-outline-danger:disabled {
    color: #e5291d;
    background-color: transparent; }
  .btn-outline-danger:not(:disabled):not(.disabled):active, .btn-outline-danger:not(:disabled):not(.disabled).active,
  .show > .btn-outline-danger.dropdown-toggle {
    color: #FFFFFF;
    background-color: #e5291d;
    border-color: #e5291d; }
    .btn-outline-danger:not(:disabled):not(.disabled):active:focus, .btn-outline-danger:not(:disabled):not(.disabled).active:focus,
    .show > .btn-outline-danger.dropdown-toggle:focus {
      box-shadow: 0 0 0 0rem rgba(229, 41, 29, 0.5); }

.btn-outline-light {
  color: #CCCCCC;
  background-color: transparent;
  background-image: none;
  border-color: #CCCCCC; }
  .btn-outline-light:hover {
    color: #171717;
    background-color: #CCCCCC;
    border-color: #CCCCCC; }
  .btn-outline-light:focus, .btn-outline-light.focus {
    box-shadow: 0 0 0 0rem rgba(204, 204, 204, 0.5); }
  .btn-outline-light.disabled, .btn-outline-light:disabled {
    color: #CCCCCC;
    background-color: transparent; }
  .btn-outline-light:not(:disabled):not(.disabled):active, .btn-outline-light:not(:disabled):not(.disabled).active,
  .show > .btn-outline-light.dropdown-toggle {
    color: #171717;
    background-color: #CCCCCC;
    border-color: #CCCCCC; }
    .btn-outline-light:not(:disabled):not(.disabled):active:focus, .btn-outline-light:not(:disabled):not(.disabled).active:focus,
    .show > .btn-outline-light.dropdown-toggle:focus {
      box-shadow: 0 0 0 0rem rgba(204, 204, 204, 0.5); }

.btn-outline-dark {
  color: #454545;
  background-color: transparent;
  background-image: none;
  border-color: #454545; }
  .btn-outline-dark:hover {
    color: #FFFFFF;
    background-color: #454545;
    border-color: #454545; }
  .btn-outline-dark:focus, .btn-outline-dark.focus {
    box-shadow: 0 0 0 0rem rgba(69, 69, 69, 0.5); }
  .btn-outline-dark.disabled, .btn-outline-dark:disabled {
    color: #454545;
    background-color: transparent; }
  .btn-outline-dark:not(:disabled):not(.disabled):active, .btn-outline-dark:not(:disabled):not(.disabled).active,
  .show > .btn-outline-dark.dropdown-toggle {
    color: #FFFFFF;
    background-color: #454545;
    border-color: #454545; }
    .btn-outline-dark:not(:disabled):not(.disabled):active:focus, .btn-outline-dark:not(:disabled):not(.disabled).active:focus,
    .show > .btn-outline-dark.dropdown-toggle:focus {
      box-shadow: 0 0 0 0rem rgba(69, 69, 69, 0.5); }

.btn-outline-lighter {
  color: #F4F4F4;
  background-color: transparent;
  background-image: none;
  border-color: #F4F4F4; }
  .btn-outline-lighter:hover {
    color: #171717;
    background-color: #F4F4F4;
    border-color: #F4F4F4; }
  .btn-outline-lighter:focus, .btn-outline-lighter.focus {
    box-shadow: 0 0 0 0rem rgba(244, 244, 244, 0.5); }
  .btn-outline-lighter.disabled, .btn-outline-lighter:disabled {
    color: #F4F4F4;
    background-color: transparent; }
  .btn-outline-lighter:not(:disabled):not(.disabled):active, .btn-outline-lighter:not(:disabled):not(.disabled).active,
  .show > .btn-outline-lighter.dropdown-toggle {
    color: #171717;
    background-color: #F4F4F4;
    border-color: #F4F4F4; }
    .btn-outline-lighter:not(:disabled):not(.disabled):active:focus, .btn-outline-lighter:not(:disabled):not(.disabled).active:focus,
    .show > .btn-outline-lighter.dropdown-toggle:focus {
      box-shadow: 0 0 0 0rem rgba(244, 244, 244, 0.5); }

.btn-outline-gray {
  color: #757575;
  background-color: transparent;
  background-image: none;
  border-color: #757575; }
  .btn-outline-gray:hover {
    color: #FFFFFF;
    background-color: #757575;
    border-color: #757575; }
  .btn-outline-gray:focus, .btn-outline-gray.focus {
    box-shadow: 0 0 0 0rem rgba(117, 117, 117, 0.5); }
  .btn-outline-gray.disabled, .btn-outline-gray:disabled {
    color: #757575;
    background-color: transparent; }
  .btn-outline-gray:not(:disabled):not(.disabled):active, .btn-outline-gray:not(:disabled):not(.disabled).active,
  .show > .btn-outline-gray.dropdown-toggle {
    color: #FFFFFF;
    background-color: #757575;
    border-color: #757575; }
    .btn-outline-gray:not(:disabled):not(.disabled):active:focus, .btn-outline-gray:not(:disabled):not(.disabled).active:focus,
    .show > .btn-outline-gray.dropdown-toggle:focus {
      box-shadow: 0 0 0 0rem rgba(117, 117, 117, 0.5); }

.btn-outline-gray-dark {
  color: #171717;
  background-color: transparent;
  background-image: none;
  border-color: #171717; }
  .btn-outline-gray-dark:hover {
    color: #FFFFFF;
    background-color: #171717;
    border-color: #171717; }
  .btn-outline-gray-dark:focus, .btn-outline-gray-dark.focus {
    box-shadow: 0 0 0 0rem rgba(23, 23, 23, 0.5); }
  .btn-outline-gray-dark.disabled, .btn-outline-gray-dark:disabled {
    color: #171717;
    background-color: transparent; }
  .btn-outline-gray-dark:not(:disabled):not(.disabled):active, .btn-outline-gray-dark:not(:disabled):not(.disabled).active,
  .show > .btn-outline-gray-dark.dropdown-toggle {
    color: #FFFFFF;
    background-color: #171717;
    border-color: #171717; }
    .btn-outline-gray-dark:not(:disabled):not(.disabled):active:focus, .btn-outline-gray-dark:not(:disabled):not(.disabled).active:focus,
    .show > .btn-outline-gray-dark.dropdown-toggle:focus {
      box-shadow: 0 0 0 0rem rgba(23, 23, 23, 0.5); }

.btn-link {
  font-weight: 400;
  color: #454545;
  background-color: transparent; }
  .btn-link:hover {
    color: #e5291d;
    text-decoration: underline;
    background-color: transparent;
    border-color: transparent; }
  .btn-link:focus, .btn-link.focus {
    text-decoration: underline;
    border-color: transparent;
    box-shadow: none; }
  .btn-link:disabled, .btn-link.disabled {
    color: #454545;
    pointer-events: none; }

.btn-lg, .btn-group-lg > .btn, .region-header-right .nav-link-user.btn-group-lg > a,
.region-header-right .nav-link-user.btn-group-lg > button {
  padding: 0.5rem 1rem;
  font-size: 2rem;
  line-height: 1.5;
  border-radius: 0.3rem; }

.btn-sm, .btn-group-sm > .btn, .region-header-right .nav-link-user.btn-group-sm > a,
.region-header-right .nav-link-user.btn-group-sm > button {
  padding: 1.4rem 0.5rem;
  font-size: 1.4rem;
  line-height: 1.5;
  border-radius: 0.2rem; }

.btn-block {
  display: block;
  width: 100%; }
  .btn-block + .btn-block {
    margin-top: 0.5rem; }

input[type="submit"].btn-block,
input[type="reset"].btn-block,
input[type="button"].btn-block {
  width: 100%; }

.fade {
  -webkit-transition: opacity 0.15s linear;
  transition: opacity 0.15s linear; }
  @media screen and (prefers-reduced-motion: reduce) {
    .fade {
      -webkit-transition: none;
      transition: none; } }
  .fade:not(.show) {
    opacity: 0; }

.collapse:not(.show) {
  display: none; }

.collapsing {
  position: relative;
  height: 0;
  overflow: hidden;
  -webkit-transition: height 0.35s ease;
  transition: height 0.35s ease; }
  @media screen and (prefers-reduced-motion: reduce) {
    .collapsing {
      -webkit-transition: none;
      transition: none; } }

.dropup,
.dropright,
.dropdown,
.dropleft {
  position: relative; }

.dropdown-toggle::after {
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 0.255em;
  vertical-align: 0.255em;
  content: "";
  border-top: 0.3em solid;
  border-right: 0.3em solid transparent;
  border-bottom: 0;
  border-left: 0.3em solid transparent; }

.dropdown-toggle:empty::after {
  margin-left: 0; }

.dropdown-menu {
  position: absolute;
  top: 100%;
  left: 0;
  z-index: 1000;
  display: none;
  float: left;
  min-width: 10rem;
  padding: 0rem 0;
  margin: 0rem 0 0;
  font-size: 1.6rem;
  color: #454545;
  text-align: left;
  list-style: none;
  background-color: #FFFFFF;
  background-clip: padding-box;
  border: 0.1rem solid #CCCCCC;
  border-radius: 0;
  box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.175); }

.dropdown-menu-right {
  right: 0;
  left: auto; }

.dropup .dropdown-menu {
  top: auto;
  bottom: 100%;
  margin-top: 0;
  margin-bottom: 0rem; }

.dropup .dropdown-toggle::after {
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 0.255em;
  vertical-align: 0.255em;
  content: "";
  border-top: 0;
  border-right: 0.3em solid transparent;
  border-bottom: 0.3em solid;
  border-left: 0.3em solid transparent; }

.dropup .dropdown-toggle:empty::after {
  margin-left: 0; }

.dropright .dropdown-menu {
  top: 0;
  right: auto;
  left: 100%;
  margin-top: 0;
  margin-left: 0rem; }

.dropright .dropdown-toggle::after {
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 0.255em;
  vertical-align: 0.255em;
  content: "";
  border-top: 0.3em solid transparent;
  border-right: 0;
  border-bottom: 0.3em solid transparent;
  border-left: 0.3em solid; }

.dropright .dropdown-toggle:empty::after {
  margin-left: 0; }

.dropright .dropdown-toggle::after {
  vertical-align: 0; }

.dropleft .dropdown-menu {
  top: 0;
  right: 100%;
  left: auto;
  margin-top: 0;
  margin-right: 0rem; }

.dropleft .dropdown-toggle::after {
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 0.255em;
  vertical-align: 0.255em;
  content: ""; }

.dropleft .dropdown-toggle::after {
  display: none; }

.dropleft .dropdown-toggle::before {
  display: inline-block;
  width: 0;
  height: 0;
  margin-right: 0.255em;
  vertical-align: 0.255em;
  content: "";
  border-top: 0.3em solid transparent;
  border-right: 0.3em solid;
  border-bottom: 0.3em solid transparent; }

.dropleft .dropdown-toggle:empty::after {
  margin-left: 0; }

.dropleft .dropdown-toggle::before {
  vertical-align: 0; }

.dropdown-menu[x-placement^="top"], .dropdown-menu[x-placement^="right"], .dropdown-menu[x-placement^="bottom"], .dropdown-menu[x-placement^="left"] {
  right: auto;
  bottom: auto; }

.dropdown-divider {
  height: 0;
  margin: 0.5rem 0;
  overflow: hidden;
  border-top: 1px solid #E4E4E4; }

.dropdown-item {
  display: block;
  width: 100%;
  padding: 1rem 2.5rem;
  clear: both;
  font-weight: 400;
  color: #171717;
  text-align: inherit;
  white-space: nowrap;
  background-color: transparent;
  border: 0; }
  .dropdown-item:hover, .dropdown-item:focus {
    color: #0a0a0a;
    text-decoration: none;
    background-color: #F4F4F4; }
  .dropdown-item.active, .dropdown-item:active {
    color: #FFFFFF;
    text-decoration: none;
    background-color: #e5291d; }
  .dropdown-item.disabled, .dropdown-item:disabled {
    color: #757575;
    background-color: transparent; }

.dropdown-menu.show {
  display: block; }

.dropdown-header {
  display: block;
  padding: 0rem 2.5rem;
  margin-bottom: 0;
  font-size: 1.4rem;
  color: #757575;
  white-space: nowrap; }

.dropdown-item-text {
  display: block;
  padding: 1rem 2.5rem;
  color: #171717; }

.btn-group,
.btn-group-vertical {
  position: relative;
  display: -webkit-inline-box;
  display: inline-flex;
  vertical-align: middle; }
  .btn-group > .btn, .region-header-right .nav-link-user.btn-group > a,
  .region-header-right .nav-link-user.btn-group > button,
  .btn-group-vertical > .btn,
  .region-header-right .nav-link-user.btn-group-vertical > a,
  .region-header-right .nav-link-user.btn-group-vertical > button {
    position: relative;
    -webkit-box-flex: 0;
            flex: 0 1 auto; }
    .btn-group > .btn:hover, .region-header-right .nav-link-user.btn-group > a:hover,
    .region-header-right .nav-link-user.btn-group > button:hover,
    .btn-group-vertical > .btn:hover,
    .region-header-right .nav-link-user.btn-group-vertical > a:hover,
    .region-header-right .nav-link-user.btn-group-vertical > button:hover {
      z-index: 1; }
    .btn-group > .btn:focus, .region-header-right .nav-link-user.btn-group > a:focus,
    .region-header-right .nav-link-user.btn-group > button:focus, .btn-group > .btn:active, .region-header-right .nav-link-user.btn-group > a:active,
    .region-header-right .nav-link-user.btn-group > button:active, .btn-group > .btn.active, .region-header-right .nav-link-user.btn-group > a.active,
    .region-header-right .nav-link-user.btn-group > button.active,
    .btn-group-vertical > .btn:focus,
    .region-header-right .nav-link-user.btn-group-vertical > a:focus,
    .region-header-right .nav-link-user.btn-group-vertical > button:focus,
    .btn-group-vertical > .btn:active,
    .region-header-right .nav-link-user.btn-group-vertical > a:active,
    .region-header-right .nav-link-user.btn-group-vertical > button:active,
    .btn-group-vertical > .btn.active,
    .region-header-right .nav-link-user.btn-group-vertical > a.active,
    .region-header-right .nav-link-user.btn-group-vertical > button.active {
      z-index: 1; }
  .btn-group .btn + .btn, .btn-group .region-header-right .nav-link-user > a + .btn, .region-header-right .btn-group .nav-link-user > a + .btn, .btn-group .region-header-right .nav-link-user > button + .btn, .region-header-right .btn-group .nav-link-user > button + .btn, .btn-group .region-header-right .nav-link-user > .btn + a, .region-header-right .btn-group .nav-link-user > .btn + a, .btn-group .region-header-right .nav-link-user > a + a, .region-header-right .btn-group .nav-link-user > a + a, .btn-group .region-header-right .nav-link-user > button + a, .region-header-right .btn-group .nav-link-user > button + a,
  .btn-group .region-header-right .nav-link-user > .btn + button, .region-header-right .btn-group .nav-link-user > .btn + button,
  .btn-group .region-header-right .nav-link-user > a + button, .region-header-right .btn-group .nav-link-user > a + button,
  .btn-group .region-header-right .nav-link-user > button + button, .region-header-right .btn-group .nav-link-user > button + button,
  .btn-group .btn + .btn-group,
  .btn-group .region-header-right .nav-link-user > a + .btn-group,
  .region-header-right .btn-group .nav-link-user > a + .btn-group,
  .btn-group .region-header-right .nav-link-user > button + .btn-group,
  .region-header-right .btn-group .nav-link-user > button + .btn-group,
  .btn-group .btn-group + .btn,
  .btn-group .region-header-right .nav-link-user > .btn-group + a,
  .region-header-right .btn-group .nav-link-user > .btn-group + a,
  .btn-group .region-header-right .nav-link-user > .btn-group + button,
  .region-header-right .btn-group .nav-link-user > .btn-group + button,
  .btn-group .btn-group + .btn-group,
  .btn-group-vertical .btn + .btn,
  .btn-group-vertical .region-header-right .nav-link-user > a + .btn,
  .region-header-right .btn-group-vertical .nav-link-user > a + .btn,
  .btn-group-vertical .region-header-right .nav-link-user > button + .btn,
  .region-header-right .btn-group-vertical .nav-link-user > button + .btn,
  .btn-group-vertical .region-header-right .nav-link-user > .btn + a,
  .region-header-right .btn-group-vertical .nav-link-user > .btn + a,
  .btn-group-vertical .region-header-right .nav-link-user > a + a,
  .region-header-right .btn-group-vertical .nav-link-user > a + a,
  .btn-group-vertical .region-header-right .nav-link-user > button + a,
  .region-header-right .btn-group-vertical .nav-link-user > button + a,
  .btn-group-vertical .region-header-right .nav-link-user > .btn + button,
  .region-header-right .btn-group-vertical .nav-link-user > .btn + button,
  .btn-group-vertical .region-header-right .nav-link-user > a + button,
  .region-header-right .btn-group-vertical .nav-link-user > a + button,
  .btn-group-vertical .region-header-right .nav-link-user > button + button,
  .region-header-right .btn-group-vertical .nav-link-user > button + button,
  .btn-group-vertical .btn + .btn-group,
  .btn-group-vertical .region-header-right .nav-link-user > a + .btn-group,
  .region-header-right .btn-group-vertical .nav-link-user > a + .btn-group,
  .btn-group-vertical .region-header-right .nav-link-user > button + .btn-group,
  .region-header-right .btn-group-vertical .nav-link-user > button + .btn-group,
  .btn-group-vertical .btn-group + .btn,
  .btn-group-vertical .region-header-right .nav-link-user > .btn-group + a,
  .region-header-right .btn-group-vertical .nav-link-user > .btn-group + a,
  .btn-group-vertical .region-header-right .nav-link-user > .btn-group + button,
  .region-header-right .btn-group-vertical .nav-link-user > .btn-group + button,
  .btn-group-vertical .btn-group + .btn-group {
    margin-left: -0.1rem; }

.btn-toolbar {
  display: -webkit-box;
  display: flex;
  flex-wrap: wrap;
  -webkit-box-pack: start;
          justify-content: flex-start; }
  .btn-toolbar .input-group {
    width: auto; }

.btn-group > .btn:first-child, .region-header-right .nav-link-user.btn-group > a:first-child,
.region-header-right .nav-link-user.btn-group > button:first-child {
  margin-left: 0; }

.btn-group > .btn:not(:last-child):not(.dropdown-toggle), .region-header-right .nav-link-user.btn-group > a:not(:last-child):not(.dropdown-toggle),
.region-header-right .nav-link-user.btn-group > button:not(:last-child):not(.dropdown-toggle),
.btn-group > .btn-group:not(:last-child) > .btn,
.region-header-right .btn-group > .nav-link-user.btn-group:not(:last-child) > a,
.region-header-right .btn-group > .nav-link-user.btn-group:not(:last-child) > button {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0; }

.btn-group > .btn:not(:first-child), .region-header-right .nav-link-user.btn-group > a:not(:first-child),
.region-header-right .nav-link-user.btn-group > button:not(:first-child),
.btn-group > .btn-group:not(:first-child) > .btn,
.region-header-right .btn-group > .nav-link-user.btn-group:not(:first-child) > a,
.region-header-right .btn-group > .nav-link-user.btn-group:not(:first-child) > button {
  border-top-left-radius: 0;
  border-bottom-left-radius: 0; }

.dropdown-toggle-split {
  padding-right: 1.65rem;
  padding-left: 1.65rem; }
  .dropdown-toggle-split::after,
  .dropup .dropdown-toggle-split::after,
  .dropright .dropdown-toggle-split::after {
    margin-left: 0; }
  .dropleft .dropdown-toggle-split::before {
    margin-right: 0; }

.btn-sm + .dropdown-toggle-split, .btn-group-sm > .btn + .dropdown-toggle-split, .region-header-right .nav-link-user.btn-group-sm > a + .dropdown-toggle-split, .region-header-right .nav-link-user.btn-group-sm > button + .dropdown-toggle-split {
  padding-right: 0.375rem;
  padding-left: 0.375rem; }

.btn-lg + .dropdown-toggle-split, .btn-group-lg > .btn + .dropdown-toggle-split, .region-header-right .nav-link-user.btn-group-lg > a + .dropdown-toggle-split, .region-header-right .nav-link-user.btn-group-lg > button + .dropdown-toggle-split {
  padding-right: 0.75rem;
  padding-left: 0.75rem; }

.btn-group.show .dropdown-toggle {
  box-shadow: none; }
  .btn-group.show .dropdown-toggle.btn-link {
    box-shadow: none; }

.btn-group-vertical {
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
          flex-direction: column;
  -webkit-box-align: start;
          align-items: flex-start;
  -webkit-box-pack: center;
          justify-content: center; }
  .btn-group-vertical .btn, .btn-group-vertical .region-header-right .nav-link-user > a, .region-header-right .btn-group-vertical .nav-link-user > a,
  .btn-group-vertical .region-header-right .nav-link-user > button, .region-header-right .btn-group-vertical .nav-link-user > button,
  .btn-group-vertical .btn-group {
    width: 100%; }
  .btn-group-vertical > .btn + .btn, .region-header-right .nav-link-user.btn-group-vertical > a + .btn, .region-header-right .nav-link-user.btn-group-vertical > button + .btn, .region-header-right .nav-link-user.btn-group-vertical > .btn + a, .region-header-right .nav-link-user.btn-group-vertical > a + a, .region-header-right .nav-link-user.btn-group-vertical > button + a,
  .region-header-right .nav-link-user.btn-group-vertical > .btn + button,
  .region-header-right .nav-link-user.btn-group-vertical > a + button,
  .region-header-right .nav-link-user.btn-group-vertical > button + button,
  .btn-group-vertical > .btn + .btn-group,
  .region-header-right .nav-link-user.btn-group-vertical > a + .btn-group,
  .region-header-right .nav-link-user.btn-group-vertical > button + .btn-group,
  .btn-group-vertical > .btn-group + .btn,
  .region-header-right .nav-link-user.btn-group-vertical > .btn-group + a,
  .region-header-right .nav-link-user.btn-group-vertical > .btn-group + button,
  .btn-group-vertical > .btn-group + .btn-group {
    margin-top: -0.1rem;
    margin-left: 0; }
  .btn-group-vertical > .btn:not(:last-child):not(.dropdown-toggle), .region-header-right .nav-link-user.btn-group-vertical > a:not(:last-child):not(.dropdown-toggle),
  .region-header-right .nav-link-user.btn-group-vertical > button:not(:last-child):not(.dropdown-toggle),
  .btn-group-vertical > .btn-group:not(:last-child) > .btn,
  .region-header-right .btn-group-vertical > .nav-link-user.btn-group:not(:last-child) > a,
  .region-header-right .btn-group-vertical > .nav-link-user.btn-group:not(:last-child) > button {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0; }
  .btn-group-vertical > .btn:not(:first-child), .region-header-right .nav-link-user.btn-group-vertical > a:not(:first-child),
  .region-header-right .nav-link-user.btn-group-vertical > button:not(:first-child),
  .btn-group-vertical > .btn-group:not(:first-child) > .btn,
  .region-header-right .btn-group-vertical > .nav-link-user.btn-group:not(:first-child) > a,
  .region-header-right .btn-group-vertical > .nav-link-user.btn-group:not(:first-child) > button {
    border-top-left-radius: 0;
    border-top-right-radius: 0; }

.btn-group-toggle > .btn, .region-header-right .nav-link-user.btn-group-toggle > a,
.region-header-right .nav-link-user.btn-group-toggle > button,
.btn-group-toggle > .btn-group > .btn,
.region-header-right .btn-group-toggle > .nav-link-user.btn-group > a,
.region-header-right .btn-group-toggle > .nav-link-user.btn-group > button {
  margin-bottom: 0; }
  .btn-group-toggle > .btn input[type="radio"], .region-header-right .nav-link-user.btn-group-toggle > a input[type="radio"], .region-header-right .nav-link-user.btn-group-toggle > button input[type="radio"],
  .btn-group-toggle > .btn input[type="checkbox"],
  .region-header-right .nav-link-user.btn-group-toggle > a input[type="checkbox"],
  .region-header-right .nav-link-user.btn-group-toggle > button input[type="checkbox"],
  .btn-group-toggle > .btn-group > .btn input[type="radio"],
  .region-header-right .btn-group-toggle > .nav-link-user.btn-group > a input[type="radio"],
  .region-header-right .btn-group-toggle > .nav-link-user.btn-group > button input[type="radio"],
  .btn-group-toggle > .btn-group > .btn input[type="checkbox"],
  .region-header-right .btn-group-toggle > .nav-link-user.btn-group > a input[type="checkbox"],
  .region-header-right .btn-group-toggle > .nav-link-user.btn-group > button input[type="checkbox"] {
    position: absolute;
    clip: rect(0, 0, 0, 0);
    pointer-events: none; }

.input-group {
  position: relative;
  display: -webkit-box;
  display: flex;
  flex-wrap: wrap;
  -webkit-box-align: stretch;
          align-items: stretch;
  width: 100%; }
  .input-group > .form-control,
  .input-group > .custom-select,
  .input-group > .custom-file {
    position: relative;
    -webkit-box-flex: 1;
            flex: 1 1 auto;
    width: 1%;
    margin-bottom: 0; }
    .input-group > .form-control + .form-control,
    .input-group > .form-control + .custom-select,
    .input-group > .form-control + .custom-file,
    .input-group > .custom-select + .form-control,
    .input-group > .custom-select + .custom-select,
    .input-group > .custom-select + .custom-file,
    .input-group > .custom-file + .form-control,
    .input-group > .custom-file + .custom-select,
    .input-group > .custom-file + .custom-file {
      margin-left: -0.1rem; }
  .input-group > .form-control:focus,
  .input-group > .custom-select:focus,
  .input-group > .custom-file .custom-file-input:focus ~ .custom-file-label {
    z-index: 3; }
  .input-group > .custom-file .custom-file-input:focus {
    z-index: 4; }
  .input-group > .form-control:not(:last-child),
  .input-group > .custom-select:not(:last-child) {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0; }
  .input-group > .form-control:not(:first-child),
  .input-group > .custom-select:not(:first-child) {
    border-top-left-radius: 0;
    border-bottom-left-radius: 0; }
  .input-group > .custom-file {
    display: -webkit-box;
    display: flex;
    -webkit-box-align: center;
            align-items: center; }
    .input-group > .custom-file:not(:last-child) .custom-file-label,
    .input-group > .custom-file:not(:last-child) .custom-file-label::after {
      border-top-right-radius: 0;
      border-bottom-right-radius: 0; }
    .input-group > .custom-file:not(:first-child) .custom-file-label {
      border-top-left-radius: 0;
      border-bottom-left-radius: 0; }

.input-group-prepend,
.input-group-append {
  display: -webkit-box;
  display: flex; }
  .input-group-prepend .btn, .input-group-prepend .region-header-right .nav-link-user > a, .region-header-right .input-group-prepend .nav-link-user > a,
  .input-group-prepend .region-header-right .nav-link-user > button, .region-header-right .input-group-prepend .nav-link-user > button,
  .input-group-append .btn,
  .input-group-append .region-header-right .nav-link-user > a,
  .region-header-right .input-group-append .nav-link-user > a,
  .input-group-append .region-header-right .nav-link-user > button,
  .region-header-right .input-group-append .nav-link-user > button {
    position: relative;
    z-index: 2; }
  .input-group-prepend .btn + .btn, .input-group-prepend .region-header-right .nav-link-user > a + .btn, .region-header-right .input-group-prepend .nav-link-user > a + .btn, .input-group-prepend .region-header-right .nav-link-user > button + .btn, .region-header-right .input-group-prepend .nav-link-user > button + .btn, .input-group-prepend .region-header-right .nav-link-user > .btn + a, .region-header-right .input-group-prepend .nav-link-user > .btn + a, .input-group-prepend .region-header-right .nav-link-user > a + a, .region-header-right .input-group-prepend .nav-link-user > a + a, .input-group-prepend .region-header-right .nav-link-user > button + a, .region-header-right .input-group-prepend .nav-link-user > button + a,
  .input-group-prepend .region-header-right .nav-link-user > .btn + button, .region-header-right .input-group-prepend .nav-link-user > .btn + button,
  .input-group-prepend .region-header-right .nav-link-user > a + button, .region-header-right .input-group-prepend .nav-link-user > a + button,
  .input-group-prepend .region-header-right .nav-link-user > button + button, .region-header-right .input-group-prepend .nav-link-user > button + button,
  .input-group-prepend .btn + .input-group-text,
  .input-group-prepend .region-header-right .nav-link-user > a + .input-group-text,
  .region-header-right .input-group-prepend .nav-link-user > a + .input-group-text,
  .input-group-prepend .region-header-right .nav-link-user > button + .input-group-text,
  .region-header-right .input-group-prepend .nav-link-user > button + .input-group-text,
  .input-group-prepend .input-group-text + .input-group-text,
  .input-group-prepend .input-group-text + .btn,
  .input-group-prepend .region-header-right .nav-link-user > .input-group-text + a,
  .region-header-right .input-group-prepend .nav-link-user > .input-group-text + a,
  .input-group-prepend .region-header-right .nav-link-user > .input-group-text + button,
  .region-header-right .input-group-prepend .nav-link-user > .input-group-text + button,
  .input-group-append .btn + .btn,
  .input-group-append .region-header-right .nav-link-user > a + .btn,
  .region-header-right .input-group-append .nav-link-user > a + .btn,
  .input-group-append .region-header-right .nav-link-user > button + .btn,
  .region-header-right .input-group-append .nav-link-user > button + .btn,
  .input-group-append .region-header-right .nav-link-user > .btn + a,
  .region-header-right .input-group-append .nav-link-user > .btn + a,
  .input-group-append .region-header-right .nav-link-user > a + a,
  .region-header-right .input-group-append .nav-link-user > a + a,
  .input-group-append .region-header-right .nav-link-user > button + a,
  .region-header-right .input-group-append .nav-link-user > button + a,
  .input-group-append .region-header-right .nav-link-user > .btn + button,
  .region-header-right .input-group-append .nav-link-user > .btn + button,
  .input-group-append .region-header-right .nav-link-user > a + button,
  .region-header-right .input-group-append .nav-link-user > a + button,
  .input-group-append .region-header-right .nav-link-user > button + button,
  .region-header-right .input-group-append .nav-link-user > button + button,
  .input-group-append .btn + .input-group-text,
  .input-group-append .region-header-right .nav-link-user > a + .input-group-text,
  .region-header-right .input-group-append .nav-link-user > a + .input-group-text,
  .input-group-append .region-header-right .nav-link-user > button + .input-group-text,
  .region-header-right .input-group-append .nav-link-user > button + .input-group-text,
  .input-group-append .input-group-text + .input-group-text,
  .input-group-append .input-group-text + .btn,
  .input-group-append .region-header-right .nav-link-user > .input-group-text + a,
  .region-header-right .input-group-append .nav-link-user > .input-group-text + a,
  .input-group-append .region-header-right .nav-link-user > .input-group-text + button,
  .region-header-right .input-group-append .nav-link-user > .input-group-text + button {
    margin-left: -0.1rem; }

.input-group-prepend {
  margin-right: -0.1rem; }

.input-group-append {
  margin-left: -0.1rem; }

.input-group-text {
  display: -webkit-box;
  display: flex;
  -webkit-box-align: center;
          align-items: center;
  padding: 1.8rem 2.2rem;
  margin-bottom: 0;
  font-size: 1.6rem;
  font-weight: 400;
  line-height: 1.25;
  color: #454545;
  text-align: center;
  white-space: nowrap;
  background-color: #FFFFFF;
  border: 0.1rem solid #CCCCCC;
  border-radius: 0; }
  .input-group-text input[type="radio"],
  .input-group-text input[type="checkbox"] {
    margin-top: 0; }

.input-group-lg > .form-control,
.input-group-lg > .input-group-prepend > .input-group-text,
.input-group-lg > .input-group-append > .input-group-text,
.input-group-lg > .input-group-prepend > .btn,
.region-header-right .input-group-lg > .nav-link-user.input-group-prepend > a,
.region-header-right .input-group-lg > .nav-link-user.input-group-prepend > button,
.input-group-lg > .input-group-append > .btn,
.region-header-right .input-group-lg > .nav-link-user.input-group-append > a,
.region-header-right .input-group-lg > .nav-link-user.input-group-append > button {
  height: calc(4rem + 0.2rem);
  padding: 0.5rem 1rem;
  font-size: 2rem;
  line-height: 1.5;
  border-radius: 0.3rem; }

.input-group-sm > .form-control,
.input-group-sm > .input-group-prepend > .input-group-text,
.input-group-sm > .input-group-append > .input-group-text,
.input-group-sm > .input-group-prepend > .btn,
.region-header-right .input-group-sm > .nav-link-user.input-group-prepend > a,
.region-header-right .input-group-sm > .nav-link-user.input-group-prepend > button,
.input-group-sm > .input-group-append > .btn,
.region-header-right .input-group-sm > .nav-link-user.input-group-append > a,
.region-header-right .input-group-sm > .nav-link-user.input-group-append > button {
  height: calc(2.6rem + 0.2rem);
  padding: 0.25rem 0.5rem;
  font-size: 1.4rem;
  line-height: 1.5;
  border-radius: 0.2rem; }

.input-group > .input-group-prepend > .btn, .region-header-right .input-group > .nav-link-user.input-group-prepend > a,
.region-header-right .input-group > .nav-link-user.input-group-prepend > button,
.input-group > .input-group-prepend > .input-group-text,
.input-group > .input-group-append:not(:last-child) > .btn,
.region-header-right .input-group > .nav-link-user.input-group-append:not(:last-child) > a,
.region-header-right .input-group > .nav-link-user.input-group-append:not(:last-child) > button,
.input-group > .input-group-append:not(:last-child) > .input-group-text,
.input-group > .input-group-append:last-child > .btn:not(:last-child):not(.dropdown-toggle),
.region-header-right .input-group > .nav-link-user.input-group-append:last-child > a:not(:last-child):not(.dropdown-toggle),
.region-header-right .input-group > .nav-link-user.input-group-append:last-child > button:not(:last-child):not(.dropdown-toggle),
.input-group > .input-group-append:last-child > .input-group-text:not(:last-child) {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0; }

.input-group > .input-group-append > .btn, .region-header-right .input-group > .nav-link-user.input-group-append > a,
.region-header-right .input-group > .nav-link-user.input-group-append > button,
.input-group > .input-group-append > .input-group-text,
.input-group > .input-group-prepend:not(:first-child) > .btn,
.region-header-right .input-group > .nav-link-user.input-group-prepend:not(:first-child) > a,
.region-header-right .input-group > .nav-link-user.input-group-prepend:not(:first-child) > button,
.input-group > .input-group-prepend:not(:first-child) > .input-group-text,
.input-group > .input-group-prepend:first-child > .btn:not(:first-child),
.region-header-right .input-group > .nav-link-user.input-group-prepend:first-child > a:not(:first-child),
.region-header-right .input-group > .nav-link-user.input-group-prepend:first-child > button:not(:first-child),
.input-group > .input-group-prepend:first-child > .input-group-text:not(:first-child) {
  border-top-left-radius: 0;
  border-bottom-left-radius: 0; }

.custom-control {
  position: relative;
  display: block;
  min-height: 2rem;
  padding-left: 3rem; }

.custom-control-inline {
  display: -webkit-inline-box;
  display: inline-flex;
  margin-right: 1.5rem; }

.custom-control-input {
  position: absolute;
  z-index: -1;
  opacity: 0; }
  .custom-control-input:checked ~ .custom-control-label::before {
    color: #e5291d;
    background-color: #FFFFFF;
    box-shadow: none; }
  .custom-control-input:focus ~ .custom-control-label::before {
    box-shadow: 0 0 0 1px #FFFFFF, none; }
  .custom-control-input:active ~ .custom-control-label::before {
    color: #FFFFFF;
    background-color: #f7c1bd;
    box-shadow: none; }
  .custom-control-input:disabled ~ .custom-control-label {
    color: #757575; }
    .custom-control-input:disabled ~ .custom-control-label::before {
      background-color: #E4E4E4; }

.custom-control-label {
  position: relative;
  margin-bottom: 0; }
  .custom-control-label::before {
    position: absolute;
    top: 0rem;
    left: -3rem;
    display: block;
    width: 2rem;
    height: 2rem;
    pointer-events: none;
    content: "";
    -webkit-user-select: none;
       -moz-user-select: none;
        -ms-user-select: none;
            user-select: none;
    background-color: #FFFFFF;
    box-shadow: none; }
  .custom-control-label::after {
    position: absolute;
    top: 0rem;
    left: -3rem;
    display: block;
    width: 2rem;
    height: 2rem;
    content: "";
    background-repeat: no-repeat;
    background-position: center center;
    background-size: 50% 50%; }

.custom-checkbox .custom-control-label::before {
  border-radius: 0; }

.custom-checkbox .custom-control-input:checked ~ .custom-control-label::before {
  background-color: #FFFFFF; }

.custom-checkbox .custom-control-input:checked ~ .custom-control-label::after {
  background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3E%3Cpath fill='%23e5291d' d='M6.564.75l-3.59 3.612-1.538-1.55L0 4.26 2.974 7.25 8 2.193z'/%3E%3C/svg%3E"); }

.custom-checkbox .custom-control-input:indeterminate ~ .custom-control-label::before {
  background-color: #e5291d;
  box-shadow: none; }

.custom-checkbox .custom-control-input:indeterminate ~ .custom-control-label::after {
  background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 4'%3E%3Cpath stroke='%23e5291d' d='M0 2h4'/%3E%3C/svg%3E"); }

.custom-checkbox .custom-control-input:disabled:checked ~ .custom-control-label::before {
  background-color: rgba(69, 69, 69, 0.5); }

.custom-checkbox .custom-control-input:disabled:indeterminate ~ .custom-control-label::before {
  background-color: rgba(69, 69, 69, 0.5); }

.custom-radio .custom-control-label::before {
  border-radius: 50%; }

.custom-radio .custom-control-input:checked ~ .custom-control-label::before {
  background-color: #FFFFFF; }

.custom-radio .custom-control-input:checked ~ .custom-control-label::after {
  background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3E%3Ccircle r='3' fill='%23e5291d'/%3E%3C/svg%3E"); }

.custom-radio .custom-control-input:disabled:checked ~ .custom-control-label::before {
  background-color: rgba(69, 69, 69, 0.5); }

.custom-select {
  display: inline-block;
  width: 100%;
  height: calc(5.6rem + 0.2rem);
  padding: 0.375rem 1.75rem 0.375rem 0.75rem;
  line-height: 1.25;
  color: #454545;
  vertical-align: middle;
  background: #FFFFFF str-replace(url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 5'%3E%3Cpath fill='#FFFFFF' d='M2 0L0 2h4zm0 5L0 3h4z'/%3E%3C/svg%3E"), "#", "%23") no-repeat right 0.75rem center;
  background-size: 8px 10px;
  border: 0.1rem solid #CCCCCC;
  border-radius: 0;
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.075);
  -webkit-appearance: none;
     -moz-appearance: none;
          appearance: none; }
  .custom-select:focus {
    border-color: #171717;
    outline: 0;
    box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.075), 0 0 0 0rem rgba(23, 23, 23, 0.5); }
    .custom-select:focus::-ms-value {
      color: #454545;
      background-color: #FFFFFF; }
  .custom-select[multiple], .custom-select[size]:not([size="1"]) {
    height: auto;
    padding-right: 0.75rem;
    background-image: none; }
  .custom-select:disabled {
    color: #6c757d;
    background-color: #E4E4E4; }
  .custom-select::-ms-expand {
    opacity: 0; }

.custom-select-sm {
  height: calc(2.6rem + 0.2rem);
  padding-top: 0.375rem;
  padding-bottom: 0.375rem;
  font-size: 75%; }

.custom-select-lg {
  height: calc(4rem + 0.2rem);
  padding-top: 0.375rem;
  padding-bottom: 0.375rem;
  font-size: 125%; }

.custom-file {
  position: relative;
  display: inline-block;
  width: 100%;
  height: calc(5.6rem + 0.2rem);
  margin-bottom: 0; }

.custom-file-input {
  position: relative;
  z-index: 2;
  width: 100%;
  height: calc(5.6rem + 0.2rem);
  margin: 0;
  opacity: 0; }
  .custom-file-input:focus ~ .custom-file-label {
    border-color: #171717;
    box-shadow: none; }
    .custom-file-input:focus ~ .custom-file-label::after {
      border-color: #171717; }
  .custom-file-input:disabled ~ .custom-file-label {
    background-color: #E4E4E4; }
  .custom-file-input:lang(en) ~ .custom-file-label::after {
    content: "Browse"; }

.custom-file-label {
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  z-index: 1;
  height: calc(5.6rem + 0.2rem);
  padding: 1.8rem 2.2rem;
  line-height: 1.25;
  color: #454545;
  background-color: #FFFFFF;
  border: 0.1rem solid #CCCCCC;
  border-radius: 0;
  box-shadow: none; }
  .custom-file-label::after {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    z-index: 3;
    display: block;
    height: 5.6rem;
    padding: 1.8rem 2.2rem;
    line-height: 1.25;
    color: #454545;
    content: "Browse";
    background-color: #FFFFFF;
    border-left: 0.1rem solid #CCCCCC;
    border-radius: 0 0 0 0; }

.custom-range {
  width: 100%;
  padding-left: 0;
  background-color: transparent;
  -webkit-appearance: none;
     -moz-appearance: none;
          appearance: none; }
  .custom-range:focus {
    outline: none; }
    .custom-range:focus::-webkit-slider-thumb {
      box-shadow: 0 0 0 1px #FFFFFF, none; }
    .custom-range:focus::-moz-range-thumb {
      box-shadow: 0 0 0 1px #FFFFFF, none; }
    .custom-range:focus::-ms-thumb {
      box-shadow: 0 0 0 1px #FFFFFF, none; }
  .custom-range::-moz-focus-outer {
    border: 0; }
  .custom-range::-webkit-slider-thumb {
    width: 1rem;
    height: 1rem;
    margin-top: -0.25rem;
    background-color: #e5291d;
    border: 0;
    border-radius: 1rem;
    box-shadow: 0 0.1rem 0.25rem rgba(0, 0, 0, 0.1);
    -webkit-transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    -webkit-appearance: none;
            appearance: none; }
    @media screen and (prefers-reduced-motion: reduce) {
      .custom-range::-webkit-slider-thumb {
        -webkit-transition: none;
        transition: none; } }
    .custom-range::-webkit-slider-thumb:active {
      background-color: #f7c1bd; }
  .custom-range::-webkit-slider-runnable-track {
    width: 100%;
    height: 0.5rem;
    color: transparent;
    cursor: pointer;
    background-color: #CCCCCC;
    border-color: transparent;
    border-radius: 1rem;
    box-shadow: inset 0 0.25rem 0.25rem rgba(0, 0, 0, 0.1); }
  .custom-range::-moz-range-thumb {
    width: 1rem;
    height: 1rem;
    background-color: #e5291d;
    border: 0;
    border-radius: 1rem;
    box-shadow: 0 0.1rem 0.25rem rgba(0, 0, 0, 0.1);
    -webkit-transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    -moz-appearance: none;
         appearance: none; }
    @media screen and (prefers-reduced-motion: reduce) {
      .custom-range::-moz-range-thumb {
        -webkit-transition: none;
        transition: none; } }
    .custom-range::-moz-range-thumb:active {
      background-color: #f7c1bd; }
  .custom-range::-moz-range-track {
    width: 100%;
    height: 0.5rem;
    color: transparent;
    cursor: pointer;
    background-color: #CCCCCC;
    border-color: transparent;
    border-radius: 1rem;
    box-shadow: inset 0 0.25rem 0.25rem rgba(0, 0, 0, 0.1); }
  .custom-range::-ms-thumb {
    width: 1rem;
    height: 1rem;
    margin-top: 0;
    margin-right: 0rem;
    margin-left: 0rem;
    background-color: #e5291d;
    border: 0;
    border-radius: 1rem;
    box-shadow: 0 0.1rem 0.25rem rgba(0, 0, 0, 0.1);
    -webkit-transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    appearance: none; }
    @media screen and (prefers-reduced-motion: reduce) {
      .custom-range::-ms-thumb {
        -webkit-transition: none;
        transition: none; } }
    .custom-range::-ms-thumb:active {
      background-color: #f7c1bd; }
  .custom-range::-ms-track {
    width: 100%;
    height: 0.5rem;
    color: transparent;
    cursor: pointer;
    background-color: transparent;
    border-color: transparent;
    border-width: 0.5rem;
    box-shadow: inset 0 0.25rem 0.25rem rgba(0, 0, 0, 0.1); }
  .custom-range::-ms-fill-lower {
    background-color: #CCCCCC;
    border-radius: 1rem; }
  .custom-range::-ms-fill-upper {
    margin-right: 15px;
    background-color: #CCCCCC;
    border-radius: 1rem; }

.custom-control-label::before,
.custom-file-label,
.custom-select {
  -webkit-transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out; }
  @media screen and (prefers-reduced-motion: reduce) {
    .custom-control-label::before,
    .custom-file-label,
    .custom-select {
      -webkit-transition: none;
      transition: none; } }

.nav {
  display: -webkit-box;
  display: flex;
  flex-wrap: wrap;
  padding-left: 0;
  margin-bottom: 0;
  list-style: none; }

.nav-link {
  display: block;
  padding: 2rem 1rem; }
  .nav-link:hover, .nav-link:focus {
    text-decoration: none; }
  .nav-link.disabled {
    color: #757575; }

.nav-tabs {
  border-bottom: 0.1rem solid #CCCCCC; }
  .nav-tabs .nav-item {
    margin-bottom: -0.1rem; }
  .nav-tabs .nav-link {
    border: 0.1rem solid transparent;
    border-top-left-radius: 0;
    border-top-right-radius: 0; }
    .nav-tabs .nav-link:hover, .nav-tabs .nav-link:focus {
      border-color: #e5291d #e5291d #CCCCCC; }
    .nav-tabs .nav-link.disabled {
      color: #757575;
      background-color: transparent;
      border-color: transparent; }
  .nav-tabs .nav-link.active,
  .nav-tabs .nav-item.show .nav-link {
    color: #454545;
    background-color: #FFFFFF;
    border-color: #454545 #454545 #FFFFFF; }
  .nav-tabs .dropdown-menu {
    margin-top: -0.1rem;
    border-top-left-radius: 0;
    border-top-right-radius: 0; }

.nav-pills .nav-link {
  border-radius: 0; }

.nav-pills .nav-link.active,
.nav-pills .show > .nav-link {
  color: #FFFFFF;
  background-color: #e5291d; }

.nav-fill .nav-item {
  -webkit-box-flex: 1;
          flex: 1 1 auto;
  text-align: center; }

.nav-justified .nav-item {
  flex-basis: 0;
  -webkit-box-flex: 1;
          flex-grow: 1;
  text-align: center; }

.tab-content > .tab-pane {
  display: none; }

.tab-content > .active {
  display: block; }

.card {
  position: relative;
  display: -webkit-box;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
          flex-direction: column;
  min-width: 0;
  word-wrap: break-word;
  background-color: #FFFFFF;
  background-clip: border-box;
  border: 0.1rem solid rgba(0, 0, 0, 0.125);
  border-radius: 0; }
  .card > hr {
    margin-right: 0;
    margin-left: 0; }
  .card > .list-group:first-child .list-group-item:first-child {
    border-top-left-radius: 0;
    border-top-right-radius: 0; }
  .card > .list-group:last-child .list-group-item:last-child {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0; }

.card-body {
  -webkit-box-flex: 1;
          flex: 1 1 auto;
  padding: 4rem; }

.card-title {
  margin-bottom: 4rem; }

.card-subtitle {
  margin-top: -2rem;
  margin-bottom: 0; }

.card-text:last-child {
  margin-bottom: 0; }

.card-link:hover {
  text-decoration: none; }

.card-link + .card-link {
  margin-left: 4rem; }

.card-header {
  padding: 4rem 4rem;
  margin-bottom: 0;
  background-color: rgba(0, 0, 0, 0.03);
  border-bottom: 0.1rem solid rgba(0, 0, 0, 0.125); }
  .card-header:first-child {
    border-radius: calc(0 - 0.1rem) calc(0 - 0.1rem) 0 0; }
  .card-header + .list-group .list-group-item:first-child {
    border-top: 0; }

.card-footer {
  padding: 4rem 4rem;
  background-color: rgba(0, 0, 0, 0.03);
  border-top: 0.1rem solid rgba(0, 0, 0, 0.125); }
  .card-footer:last-child {
    border-radius: 0 0 calc(0 - 0.1rem) calc(0 - 0.1rem); }

.card-header-tabs {
  margin-right: -2rem;
  margin-bottom: -4rem;
  margin-left: -2rem;
  border-bottom: 0; }

.card-header-pills {
  margin-right: -2rem;
  margin-left: -2rem; }

.card-img-overlay {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  padding: 2rem; }

.card-img {
  width: 100%;
  border-radius: calc(0 - 0.1rem); }

.card-img-top {
  width: 100%;
  border-top-left-radius: calc(0 - 0.1rem);
  border-top-right-radius: calc(0 - 0.1rem); }

.card-img-bottom {
  width: 100%;
  border-bottom-right-radius: calc(0 - 0.1rem);
  border-bottom-left-radius: calc(0 - 0.1rem); }

.card-deck {
  display: -webkit-box;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
          flex-direction: column; }
  .card-deck .card {
    margin-bottom: 1.5rem; }
  @media (min-width: 576px) {
    .card-deck {
      -webkit-box-orient: horizontal;
      -webkit-box-direction: normal;
              flex-flow: row wrap;
      margin-right: -1.5rem;
      margin-left: -1.5rem; }
      .card-deck .card {
        display: -webkit-box;
        display: flex;
        -webkit-box-flex: 1;
                flex: 1 0 0%;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
                flex-direction: column;
        margin-right: 1.5rem;
        margin-bottom: 0;
        margin-left: 1.5rem; } }

.card-group {
  display: -webkit-box;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
          flex-direction: column; }
  .card-group > .card {
    margin-bottom: 1.5rem; }
  @media (min-width: 576px) {
    .card-group {
      -webkit-box-orient: horizontal;
      -webkit-box-direction: normal;
              flex-flow: row wrap; }
      .card-group > .card {
        -webkit-box-flex: 1;
                flex: 1 0 0%;
        margin-bottom: 0; }
        .card-group > .card + .card {
          margin-left: 0;
          border-left: 0; }
        .card-group > .card:first-child {
          border-top-right-radius: 0;
          border-bottom-right-radius: 0; }
          .card-group > .card:first-child .card-img-top,
          .card-group > .card:first-child .card-header {
            border-top-right-radius: 0; }
          .card-group > .card:first-child .card-img-bottom,
          .card-group > .card:first-child .card-footer {
            border-bottom-right-radius: 0; }
        .card-group > .card:last-child {
          border-top-left-radius: 0;
          border-bottom-left-radius: 0; }
          .card-group > .card:last-child .card-img-top,
          .card-group > .card:last-child .card-header {
            border-top-left-radius: 0; }
          .card-group > .card:last-child .card-img-bottom,
          .card-group > .card:last-child .card-footer {
            border-bottom-left-radius: 0; }
        .card-group > .card:only-child {
          border-radius: 0; }
          .card-group > .card:only-child .card-img-top,
          .card-group > .card:only-child .card-header {
            border-top-left-radius: 0;
            border-top-right-radius: 0; }
          .card-group > .card:only-child .card-img-bottom,
          .card-group > .card:only-child .card-footer {
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0; }
        .card-group > .card:not(:first-child):not(:last-child):not(:only-child) {
          border-radius: 0; }
          .card-group > .card:not(:first-child):not(:last-child):not(:only-child) .card-img-top,
          .card-group > .card:not(:first-child):not(:last-child):not(:only-child) .card-img-bottom,
          .card-group > .card:not(:first-child):not(:last-child):not(:only-child) .card-header,
          .card-group > .card:not(:first-child):not(:last-child):not(:only-child) .card-footer {
            border-radius: 0; } }

.card-columns .card {
  margin-bottom: 4rem; }

@media (min-width: 576px) {
  .card-columns {
    -webkit-column-count: 3;
       -moz-column-count: 3;
            column-count: 3;
    -webkit-column-gap: 2rem;
       -moz-column-gap: 2rem;
            column-gap: 2rem;
    orphans: 1;
    widows: 1; }
    .card-columns .card {
      display: inline-block;
      width: 100%; } }

.accordion .card:not(:first-of-type):not(:last-of-type) {
  border-bottom: 0;
  border-radius: 0; }

.accordion .card:not(:first-of-type) .card-header:first-child {
  border-radius: 0; }

.accordion .card:first-of-type {
  border-bottom: 0;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0; }

.accordion .card:last-of-type {
  border-top-left-radius: 0;
  border-top-right-radius: 0; }

.pagination {
  display: -webkit-box;
  display: flex;
  padding-left: 0;
  list-style: none;
  border-radius: 0; }

.page-link {
  position: relative;
  display: block;
  padding: 0 0;
  margin-left: -0.1rem;
  line-height: 50px;
  color: #454545;
  background-color: #FFFFFF;
  border: 0.1rem solid #CCCCCC; }
  .page-link:hover {
    z-index: 2;
    color: #454545;
    text-decoration: none;
    background-color: #E4E4E4;
    border-color: #CCCCCC; }
  .page-link:focus {
    z-index: 2;
    outline: 0;
    box-shadow: none; }
  .page-link:not(:disabled):not(.disabled) {
    cursor: pointer; }

.page-item:first-child .page-link {
  margin-left: 0;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0; }

.page-item:last-child .page-link {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0; }

.page-item.active .page-link {
  z-index: 1;
  color: #e5291d;
  background-color: #FFFFFF;
  border-color: #CCCCCC; }

.page-item.disabled .page-link {
  color: #6c757d;
  pointer-events: none;
  cursor: auto;
  background-color: #FFFFFF;
  border-color: #CCCCCC; }

.pagination-lg .page-link {
  padding: 0.75rem 1.5rem;
  font-size: 2rem;
  line-height: 1.5; }

.pagination-lg .page-item:first-child .page-link {
  border-top-left-radius: 0.3rem;
  border-bottom-left-radius: 0.3rem; }

.pagination-lg .page-item:last-child .page-link {
  border-top-right-radius: 0.3rem;
  border-bottom-right-radius: 0.3rem; }

.pagination-sm .page-link {
  padding: 0.25rem 0.5rem;
  font-size: 1.4rem;
  line-height: 1.5; }

.pagination-sm .page-item:first-child .page-link {
  border-top-left-radius: 0.2rem;
  border-bottom-left-radius: 0.2rem; }

.pagination-sm .page-item:last-child .page-link {
  border-top-right-radius: 0.2rem;
  border-bottom-right-radius: 0.2rem; }

.badge {
  display: inline-block;
  padding: 0.25em 0.4em;
  font-size: 75%;
  font-weight: 700;
  line-height: 1;
  text-align: center;
  white-space: nowrap;
  vertical-align: baseline;
  border-radius: 0; }
  .badge:empty {
    display: none; }

.btn .badge, .region-header-right .nav-link-user > a .badge, .region-header-right .nav-link-user > button .badge {
  position: relative;
  top: -1px; }

.badge-pill {
  padding-right: 0.6em;
  padding-left: 0.6em;
  border-radius: 10rem; }

.badge-primary {
  color: #FFFFFF;
  background-color: #454545; }
  .badge-primary[href]:hover, .badge-primary[href]:focus {
    color: #FFFFFF;
    text-decoration: none;
    background-color: #2c2c2c; }

.badge-secondary {
  color: #FFFFFF;
  background-color: #e5291d; }
  .badge-secondary[href]:hover, .badge-secondary[href]:focus {
    color: #FFFFFF;
    text-decoration: none;
    background-color: #ba1f15; }

.badge-success {
  color: #171717;
  background-color: #AFCD50; }
  .badge-success[href]:hover, .badge-success[href]:focus {
    color: #171717;
    text-decoration: none;
    background-color: #97b634; }

.badge-info {
  color: #171717;
  background-color: #64C3D7; }
  .badge-info[href]:hover, .badge-info[href]:focus {
    color: #171717;
    text-decoration: none;
    background-color: #3bb3cd; }

.badge-warning {
  color: #171717;
  background-color: #F5A023; }
  .badge-warning[href]:hover, .badge-warning[href]:focus {
    color: #171717;
    text-decoration: none;
    background-color: #db860a; }

.badge-danger {
  color: #FFFFFF;
  background-color: #e5291d; }
  .badge-danger[href]:hover, .badge-danger[href]:focus {
    color: #FFFFFF;
    text-decoration: none;
    background-color: #ba1f15; }

.badge-light {
  color: #171717;
  background-color: #CCCCCC; }
  .badge-light[href]:hover, .badge-light[href]:focus {
    color: #171717;
    text-decoration: none;
    background-color: #b3b3b3; }

.badge-dark {
  color: #FFFFFF;
  background-color: #454545; }
  .badge-dark[href]:hover, .badge-dark[href]:focus {
    color: #FFFFFF;
    text-decoration: none;
    background-color: #2c2c2c; }

.badge-lighter {
  color: #171717;
  background-color: #F4F4F4; }
  .badge-lighter[href]:hover, .badge-lighter[href]:focus {
    color: #171717;
    text-decoration: none;
    background-color: #dbdbdb; }

.badge-gray {
  color: #FFFFFF;
  background-color: #757575; }
  .badge-gray[href]:hover, .badge-gray[href]:focus {
    color: #FFFFFF;
    text-decoration: none;
    background-color: #5c5c5c; }

.badge-gray-dark {
  color: #FFFFFF;
  background-color: #171717; }
  .badge-gray-dark[href]:hover, .badge-gray-dark[href]:focus {
    color: #FFFFFF;
    text-decoration: none;
    background-color: black; }

.alert {
  position: relative;
  padding: 2rem 3rem;
  margin-bottom: 2rem;
  border: 0.1rem solid transparent;
  border-radius: 0; }

.alert-heading {
  color: inherit; }

.alert-link {
  font-weight: 700; }

.alert-dismissible {
  padding-right: 7.6rem; }
  .alert-dismissible .close {
    position: absolute;
    top: 0;
    right: 0;
    padding: 2rem 3rem;
    color: inherit; }

.alert-primary {
  color: #0f0f0f;
  background-color: #c7c7c7;
  border-color: #bababa; }
  .alert-primary hr {
    border-top-color: #adadad; }
  .alert-primary .alert-link {
    color: #0f0f0f; }

.alert-secondary {
  color: #58100b;
  background-color: #f7bfbb;
  border-color: #f5b0ab; }
  .alert-secondary hr {
    border-top-color: #f29b94; }
  .alert-secondary .alert-link {
    color: #58100b; }

.alert-success {
  color: #465220;
  background-color: #e7f0cb;
  border-color: #e1edbe; }
  .alert-success hr {
    border-top-color: #d8e7aa; }
  .alert-success .alert-link {
    color: #465220; }

.alert-info {
  color: #2a525a;
  background-color: #d1edf3;
  border-color: #c6e9f0; }
  .alert-info hr {
    border-top-color: #b2e1eb; }
  .alert-info .alert-link {
    color: #2a525a; }

.alert-warning {
  color: #61400e;
  background-color: #fce3bd;
  border-color: #fbdcae; }
  .alert-warning hr {
    border-top-color: #fad296; }
  .alert-warning .alert-link {
    color: #61400e; }

.alert-danger {
  color: #58100b;
  background-color: #f7bfbb;
  border-color: #f5b0ab; }
  .alert-danger hr {
    border-top-color: #f29b94; }
  .alert-danger .alert-link {
    color: #58100b; }

.alert-light {
  color: #5d5d5d;
  background-color: #f0f0f0;
  border-color: #ececec; }
  .alert-light hr {
    border-top-color: #dfdfdf; }
  .alert-light .alert-link {
    color: #5d5d5d; }

.alert-dark {
  color: #0f0f0f;
  background-color: #c7c7c7;
  border-color: #bababa; }
  .alert-dark hr {
    border-top-color: #adadad; }
  .alert-dark .alert-link {
    color: #0f0f0f; }

.alert-lighter {
  color: #757575;
  background-color: #fcfcfc;
  border-color: #fbfbfb; }
  .alert-lighter hr {
    border-top-color: #eeeeee; }
  .alert-lighter .alert-link {
    color: #757575; }

.alert-gray {
  color: #2b2b2b;
  background-color: #d6d6d6;
  border-color: #cccccc; }
  .alert-gray hr {
    border-top-color: #bfbfbf; }
  .alert-gray .alert-link {
    color: #2b2b2b; }

.alert-gray-dark {
  color: black;
  background-color: #b9b9b9;
  border-color: darkgray; }
  .alert-gray-dark hr {
    border-top-color: #9c9c9c; }
  .alert-gray-dark .alert-link {
    color: black; }

@-webkit-keyframes progress-bar-stripes {
  from {
    background-position: 1rem 0; }
  to {
    background-position: 0 0; } }

@keyframes progress-bar-stripes {
  from {
    background-position: 1rem 0; }
  to {
    background-position: 0 0; } }

.progress {
  display: -webkit-box;
  display: flex;
  height: 1rem;
  overflow: hidden;
  font-size: 1.2rem;
  background-color: #E4E4E4;
  border-radius: 0.6rem;
  border-radius: .5rem;
  box-shadow: none; }

.progress-bar {
  display: -webkit-box;
  display: flex;
  position: relative;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
          flex-direction: column;
  -webkit-box-pack: center;
          justify-content: center;
  color: #FFFFFF;
  text-align: center;
  white-space: nowrap;
  background-color: #454545;
  -webkit-transition: width 0.6s ease;
  transition: width 0.6s ease; }
  @media screen and (prefers-reduced-motion: reduce) {
    .progress-bar {
      -webkit-transition: none;
      transition: none; } }

.progress-bar-striped {
  background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
  background-size: 1rem 1rem; }

.progress-bar-animated {
  -webkit-animation: progress-bar-stripes 1s linear infinite;
          animation: progress-bar-stripes 1s linear infinite; }

.list-group {
  display: -webkit-box;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
          flex-direction: column;
  padding-left: 0;
  margin-bottom: 0; }

.list-group-item-action {
  width: 100%;
  color: #757575;
  text-align: inherit; }
  .list-group-item-action:hover, .list-group-item-action:focus {
    color: #757575;
    text-decoration: none;
    background-color: #F4F4F4; }
  .list-group-item-action:active {
    color: #454545;
    background-color: #E4E4E4; }

.list-group-item {
  position: relative;
  display: block;
  padding: 2rem 2rem;
  margin-bottom: -0.1rem;
  background-color: #FFFFFF;
  border: 0.1rem solid rgba(0, 0, 0, 0.125); }
  .list-group-item:first-child {
    border-top-left-radius: 0;
    border-top-right-radius: 0; }
  .list-group-item:last-child {
    margin-bottom: 0;
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0; }
  .list-group-item:hover, .list-group-item:focus {
    z-index: 1;
    text-decoration: none; }
  .list-group-item.disabled, .list-group-item:disabled {
    color: #757575;
    background-color: #FFFFFF; }
  .list-group-item.active {
    z-index: 2;
    color: #FFFFFF;
    background-color: #e5291d;
    border-color: #e5291d; }

.list-group-flush .list-group-item {
  border-right: 0;
  border-left: 0;
  border-radius: 0; }

.list-group-flush:first-child .list-group-item:first-child {
  border-top: 0; }

.list-group-flush:last-child .list-group-item:last-child {
  border-bottom: 0; }

.list-group-item-primary {
  color: #282828;
  background-color: #bababa; }
  .list-group-item-primary.list-group-item-action:hover, .list-group-item-primary.list-group-item-action:focus {
    color: #282828;
    background-color: #adadad; }
  .list-group-item-primary.list-group-item-action.active {
    color: #FFFFFF;
    background-color: #282828;
    border-color: #282828; }

.list-group-item-secondary {
  color: #851811;
  background-color: #f5b0ab; }
  .list-group-item-secondary.list-group-item-action:hover, .list-group-item-secondary.list-group-item-action:focus {
    color: #851811;
    background-color: #f29b94; }
  .list-group-item-secondary.list-group-item-action.active {
    color: #FFFFFF;
    background-color: #851811;
    border-color: #851811; }

.list-group-item-success {
  color: #66772e;
  background-color: #e1edbe; }
  .list-group-item-success.list-group-item-action:hover, .list-group-item-success.list-group-item-action:focus {
    color: #66772e;
    background-color: #d8e7aa; }
  .list-group-item-success.list-group-item-action.active {
    color: #FFFFFF;
    background-color: #66772e;
    border-color: #66772e; }

.list-group-item-info {
  color: #3a717d;
  background-color: #c6e9f0; }
  .list-group-item-info.list-group-item-action:hover, .list-group-item-info.list-group-item-action:focus {
    color: #3a717d;
    background-color: #b2e1eb; }
  .list-group-item-info.list-group-item-action.active {
    color: #FFFFFF;
    background-color: #3a717d;
    border-color: #3a717d; }

.list-group-item-warning {
  color: #8e5d14;
  background-color: #fbdcae; }
  .list-group-item-warning.list-group-item-action:hover, .list-group-item-warning.list-group-item-action:focus {
    color: #8e5d14;
    background-color: #fad296; }
  .list-group-item-warning.list-group-item-action.active {
    color: #FFFFFF;
    background-color: #8e5d14;
    border-color: #8e5d14; }

.list-group-item-danger {
  color: #851811;
  background-color: #f5b0ab; }
  .list-group-item-danger.list-group-item-action:hover, .list-group-item-danger.list-group-item-action:focus {
    color: #851811;
    background-color: #f29b94; }
  .list-group-item-danger.list-group-item-action.active {
    color: #FFFFFF;
    background-color: #851811;
    border-color: #851811; }

.list-group-item-light {
  color: #767676;
  background-color: #ececec; }
  .list-group-item-light.list-group-item-action:hover, .list-group-item-light.list-group-item-action:focus {
    color: #767676;
    background-color: #dfdfdf; }
  .list-group-item-light.list-group-item-action.active {
    color: #FFFFFF;
    background-color: #767676;
    border-color: #767676; }

.list-group-item-dark {
  color: #282828;
  background-color: #bababa; }
  .list-group-item-dark.list-group-item-action:hover, .list-group-item-dark.list-group-item-action:focus {
    color: #282828;
    background-color: #adadad; }
  .list-group-item-dark.list-group-item-action.active {
    color: #FFFFFF;
    background-color: #282828;
    border-color: #282828; }

.list-group-item-lighter {
  color: #8e8e8e;
  background-color: #fbfbfb; }
  .list-group-item-lighter.list-group-item-action:hover, .list-group-item-lighter.list-group-item-action:focus {
    color: #8e8e8e;
    background-color: #eeeeee; }
  .list-group-item-lighter.list-group-item-action.active {
    color: #FFFFFF;
    background-color: #8e8e8e;
    border-color: #8e8e8e; }

.list-group-item-gray {
  color: #444444;
  background-color: #cccccc; }
  .list-group-item-gray.list-group-item-action:hover, .list-group-item-gray.list-group-item-action:focus {
    color: #444444;
    background-color: #bfbfbf; }
  .list-group-item-gray.list-group-item-action.active {
    color: #FFFFFF;
    background-color: #444444;
    border-color: #444444; }

.list-group-item-gray-dark {
  color: #0d0d0d;
  background-color: darkgray; }
  .list-group-item-gray-dark.list-group-item-action:hover, .list-group-item-gray-dark.list-group-item-action:focus {
    color: #0d0d0d;
    background-color: #9c9c9c; }
  .list-group-item-gray-dark.list-group-item-action.active {
    color: #FFFFFF;
    background-color: #0d0d0d;
    border-color: #0d0d0d; }

.close {
  float: right;
  font-size: 1.6rem;
  font-weight: 700;
  line-height: 1;
  color: #454545;
  text-shadow: 0 1px 0 #FFFFFF;
  opacity: .5; }
  .close:not(:disabled):not(.disabled) {
    cursor: pointer; }
    .close:not(:disabled):not(.disabled):hover, .close:not(:disabled):not(.disabled):focus {
      color: #454545;
      text-decoration: none;
      opacity: .75; }

button.close {
  padding: 0;
  background-color: transparent;
  border: 0;
  -webkit-appearance: none; }

.modal-open {
  overflow: hidden; }
  .modal-open .modal {
    overflow-x: hidden;
    overflow-y: auto; }

.modal {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 1050;
  display: none;
  overflow: hidden;
  outline: 0; }

.modal-dialog {
  position: relative;
  width: auto;
  margin: 0.5rem;
  pointer-events: none; }
  .modal.fade .modal-dialog {
    -webkit-transition: -webkit-transform 0.3s ease-out;
    transition: -webkit-transform 0.3s ease-out;
    transition: transform 0.3s ease-out;
    transition: transform 0.3s ease-out, -webkit-transform 0.3s ease-out;
    -webkit-transform: translate(0, -25%);
            transform: translate(0, -25%); }
    @media screen and (prefers-reduced-motion: reduce) {
      .modal.fade .modal-dialog {
        -webkit-transition: none;
        transition: none; } }
  .modal.show .modal-dialog {
    -webkit-transform: translate(0, 0);
            transform: translate(0, 0); }

.modal-dialog-centered {
  display: -webkit-box;
  display: flex;
  -webkit-box-align: center;
          align-items: center;
  min-height: calc(100% - (0.5rem * 2)); }
  .modal-dialog-centered::before {
    display: block;
    height: calc(100vh - (0.5rem * 2));
    content: ""; }

.modal-content {
  position: relative;
  display: -webkit-box;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
          flex-direction: column;
  width: 100%;
  pointer-events: auto;
  background-color: #FFFFFF;
  background-clip: padding-box;
  border: 0 solid rgba(0, 0, 0, 0.2);
  border-radius: 0.3rem;
  box-shadow: 0 0.25rem 0.5rem rgba(0, 0, 0, 0.5);
  outline: 0; }

.modal-backdrop {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 1040;
  background-color: #000000; }
  .modal-backdrop.fade {
    opacity: 0; }
  .modal-backdrop.show {
    opacity: 0.5; }

.modal-header {
  display: -webkit-box;
  display: flex;
  -webkit-box-align: start;
          align-items: flex-start;
  -webkit-box-pack: justify;
          justify-content: space-between;
  padding: 0;
  border-bottom: 0 solid #E4E4E4;
  border-top-left-radius: 0.3rem;
  border-top-right-radius: 0.3rem; }
  .modal-header .close {
    padding: 0;
    margin: 0 0 0 auto; }

.modal-title {
  margin-bottom: 0;
  line-height: 1.25; }

.modal-body {
  position: relative;
  -webkit-box-flex: 1;
          flex: 1 1 auto;
  padding: 0; }

.modal-footer {
  display: -webkit-box;
  display: flex;
  -webkit-box-align: center;
          align-items: center;
  -webkit-box-pack: end;
          justify-content: flex-end;
  padding: 0;
  border-top: 0 solid #E4E4E4; }
  .modal-footer > :not(:first-child) {
    margin-left: .25rem; }
  .modal-footer > :not(:last-child) {
    margin-right: .25rem; }

.modal-scrollbar-measure {
  position: absolute;
  top: -9999px;
  width: 50px;
  height: 50px;
  overflow: scroll; }

@media (min-width: 576px) {
  .modal-dialog {
    max-width: 500px;
    margin: 1.75rem auto; }
  .modal-dialog-centered {
    min-height: calc(100% - (1.75rem * 2)); }
    .modal-dialog-centered::before {
      height: calc(100vh - (1.75rem * 2)); }
  .modal-content {
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.5); }
  .modal-sm {
    max-width: 300px; } }

@media (min-width: 992px) {
  .modal-lg {
    max-width: 800px; } }

.tooltip {
  position: absolute;
  z-index: 1070;
  display: block;
  margin: 0;
  font-family: "montserrat", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
  font-style: normal;
  font-weight: 400;
  line-height: 1.25;
  text-align: left;
  text-align: start;
  text-decoration: none;
  text-shadow: none;
  text-transform: none;
  letter-spacing: normal;
  word-break: normal;
  word-spacing: normal;
  white-space: normal;
  line-break: auto;
  font-size: 1.4rem;
  word-wrap: break-word;
  opacity: 0; }
  .tooltip.show {
    opacity: 0.9; }
  .tooltip .arrow {
    position: absolute;
    display: block;
    width: 0.8rem;
    height: 0.4rem; }
    .tooltip .arrow::before {
      position: absolute;
      content: "";
      border-color: transparent;
      border-style: solid; }

.bs-tooltip-top, .bs-tooltip-auto[x-placement^="top"] {
  padding: 0.4rem 0; }
  .bs-tooltip-top .arrow, .bs-tooltip-auto[x-placement^="top"] .arrow {
    bottom: 0; }
    .bs-tooltip-top .arrow::before, .bs-tooltip-auto[x-placement^="top"] .arrow::before {
      top: 0;
      border-width: 0.4rem 0.4rem 0;
      border-top-color: #000000; }

.bs-tooltip-right, .bs-tooltip-auto[x-placement^="right"] {
  padding: 0 0.4rem; }
  .bs-tooltip-right .arrow, .bs-tooltip-auto[x-placement^="right"] .arrow {
    left: 0;
    width: 0.4rem;
    height: 0.8rem; }
    .bs-tooltip-right .arrow::before, .bs-tooltip-auto[x-placement^="right"] .arrow::before {
      right: 0;
      border-width: 0.4rem 0.4rem 0.4rem 0;
      border-right-color: #000000; }

.bs-tooltip-bottom, .bs-tooltip-auto[x-placement^="bottom"] {
  padding: 0.4rem 0; }
  .bs-tooltip-bottom .arrow, .bs-tooltip-auto[x-placement^="bottom"] .arrow {
    top: 0; }
    .bs-tooltip-bottom .arrow::before, .bs-tooltip-auto[x-placement^="bottom"] .arrow::before {
      bottom: 0;
      border-width: 0 0.4rem 0.4rem;
      border-bottom-color: #000000; }

.bs-tooltip-left, .bs-tooltip-auto[x-placement^="left"] {
  padding: 0 0.4rem; }
  .bs-tooltip-left .arrow, .bs-tooltip-auto[x-placement^="left"] .arrow {
    right: 0;
    width: 0.4rem;
    height: 0.8rem; }
    .bs-tooltip-left .arrow::before, .bs-tooltip-auto[x-placement^="left"] .arrow::before {
      left: 0;
      border-width: 0.4rem 0 0.4rem 0.4rem;
      border-left-color: #000000; }

.tooltip-inner {
  max-width: 200px;
  padding: 0.25rem 0.5rem;
  color: #FFFFFF;
  text-align: center;
  background-color: #000000;
  border-radius: 0; }

.popover {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 1060;
  display: block;
  max-width: 25rem;
  font-family: "montserrat", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
  font-style: normal;
  font-weight: 400;
  line-height: 1.25;
  text-align: left;
  text-align: start;
  text-decoration: none;
  text-shadow: none;
  text-transform: none;
  letter-spacing: normal;
  word-break: normal;
  word-spacing: normal;
  white-space: normal;
  line-break: auto;
  font-size: 1.4rem;
  word-wrap: break-word;
  background-color: #000000;
  background-clip: padding-box;
  border: 0.1rem solid #000000;
  border-radius: 0.6rem;
  box-shadow: 0 0 2.5rem rgba(0, 0, 0, 0.2); }
  .popover .arrow {
    position: absolute;
    display: block;
    width: 1.6rem;
    height: 0.8rem;
    margin: 0 0.3rem; }
    .popover .arrow::before, .popover .arrow::after {
      position: absolute;
      display: block;
      content: "";
      border-color: transparent;
      border-style: solid; }

.bs-popover-top, .bs-popover-auto[x-placement^="top"] {
  margin-bottom: 0.8rem; }
  .bs-popover-top .arrow, .bs-popover-auto[x-placement^="top"] .arrow {
    bottom: calc((0.8rem + 0.1rem) * -1); }
  .bs-popover-top .arrow::before, .bs-popover-auto[x-placement^="top"] .arrow::before,
  .bs-popover-top .arrow::after,
  .bs-popover-auto[x-placement^="top"] .arrow::after {
    border-width: 0.8rem 0.8rem 0; }
  .bs-popover-top .arrow::before, .bs-popover-auto[x-placement^="top"] .arrow::before {
    bottom: 0;
    border-top-color: black; }
  
  .bs-popover-top .arrow::after,
  .bs-popover-auto[x-placement^="top"] .arrow::after {
    bottom: 0.1rem;
    border-top-color: #000000; }

.bs-popover-right, .bs-popover-auto[x-placement^="right"] {
  margin-left: 0.8rem; }
  .bs-popover-right .arrow, .bs-popover-auto[x-placement^="right"] .arrow {
    left: calc((0.8rem + 0.1rem) * -1);
    width: 0.8rem;
    height: 1.6rem;
    margin: 0.3rem 0; }
  .bs-popover-right .arrow::before, .bs-popover-auto[x-placement^="right"] .arrow::before,
  .bs-popover-right .arrow::after,
  .bs-popover-auto[x-placement^="right"] .arrow::after {
    border-width: 0.8rem 0.8rem 0.8rem 0; }
  .bs-popover-right .arrow::before, .bs-popover-auto[x-placement^="right"] .arrow::before {
    left: 0;
    border-right-color: black; }
  
  .bs-popover-right .arrow::after,
  .bs-popover-auto[x-placement^="right"] .arrow::after {
    left: 0.1rem;
    border-right-color: #000000; }

.bs-popover-bottom, .bs-popover-auto[x-placement^="bottom"] {
  margin-top: 0.8rem; }
  .bs-popover-bottom .arrow, .bs-popover-auto[x-placement^="bottom"] .arrow {
    top: calc((0.8rem + 0.1rem) * -1); }
  .bs-popover-bottom .arrow::before, .bs-popover-auto[x-placement^="bottom"] .arrow::before,
  .bs-popover-bottom .arrow::after,
  .bs-popover-auto[x-placement^="bottom"] .arrow::after {
    border-width: 0 0.8rem 0.8rem 0.8rem; }
  .bs-popover-bottom .arrow::before, .bs-popover-auto[x-placement^="bottom"] .arrow::before {
    top: 0;
    border-bottom-color: black; }
  
  .bs-popover-bottom .arrow::after,
  .bs-popover-auto[x-placement^="bottom"] .arrow::after {
    top: 0.1rem;
    border-bottom-color: #000000; }
  .bs-popover-bottom .popover-header::before, .bs-popover-auto[x-placement^="bottom"] .popover-header::before {
    position: absolute;
    top: 0;
    left: 50%;
    display: block;
    width: 1.6rem;
    margin-left: -0.8rem;
    content: "";
    border-bottom: 0.1rem solid #000000; }

.bs-popover-left, .bs-popover-auto[x-placement^="left"] {
  margin-right: 0.8rem; }
  .bs-popover-left .arrow, .bs-popover-auto[x-placement^="left"] .arrow {
    right: calc((0.8rem + 0.1rem) * -1);
    width: 0.8rem;
    height: 1.6rem;
    margin: 0.3rem 0; }
  .bs-popover-left .arrow::before, .bs-popover-auto[x-placement^="left"] .arrow::before,
  .bs-popover-left .arrow::after,
  .bs-popover-auto[x-placement^="left"] .arrow::after {
    border-width: 0.8rem 0 0.8rem 0.8rem; }
  .bs-popover-left .arrow::before, .bs-popover-auto[x-placement^="left"] .arrow::before {
    right: 0;
    border-left-color: black; }
  
  .bs-popover-left .arrow::after,
  .bs-popover-auto[x-placement^="left"] .arrow::after {
    right: 0.1rem;
    border-left-color: #000000; }

.popover-header {
  padding: 2.4rem 2.4rem;
  margin-bottom: 0;
  font-size: 1.6rem;
  color: #FFFFFF;
  background-color: #000000;
  border-bottom: 0.1rem solid black;
  border-top-left-radius: calc(0.3rem - 0.1rem);
  border-top-right-radius: calc(0.3rem - 0.1rem); }
  .popover-header:empty {
    display: none; }

.popover-body {
  padding: 2.4rem 2.4rem;
  color: #FFFFFF; }

.align-baseline {
  vertical-align: baseline !important; }

.align-top {
  vertical-align: top !important; }

.align-middle {
  vertical-align: middle !important; }

.align-bottom {
  vertical-align: bottom !important; }

.align-text-bottom {
  vertical-align: text-bottom !important; }

.align-text-top {
  vertical-align: text-top !important; }

.bg-primary {
  background-color: #454545 !important; }

a.bg-primary:hover, a.bg-primary:focus,
button.bg-primary:hover,
button.bg-primary:focus {
  background-color: #2c2c2c !important; }

.bg-secondary {
  background-color: #e5291d !important; }

a.bg-secondary:hover, a.bg-secondary:focus,
button.bg-secondary:hover,
button.bg-secondary:focus {
  background-color: #ba1f15 !important; }

.bg-success {
  background-color: #AFCD50 !important; }

a.bg-success:hover, a.bg-success:focus,
button.bg-success:hover,
button.bg-success:focus {
  background-color: #97b634 !important; }

.bg-info {
  background-color: #64C3D7 !important; }

a.bg-info:hover, a.bg-info:focus,
button.bg-info:hover,
button.bg-info:focus {
  background-color: #3bb3cd !important; }

.bg-warning {
  background-color: #F5A023 !important; }

a.bg-warning:hover, a.bg-warning:focus,
button.bg-warning:hover,
button.bg-warning:focus {
  background-color: #db860a !important; }

.bg-danger {
  background-color: #e5291d !important; }

a.bg-danger:hover, a.bg-danger:focus,
button.bg-danger:hover,
button.bg-danger:focus {
  background-color: #ba1f15 !important; }

.bg-light {
  background-color: #CCCCCC !important; }

a.bg-light:hover, a.bg-light:focus,
button.bg-light:hover,
button.bg-light:focus {
  background-color: #b3b3b3 !important; }

.bg-dark {
  background-color: #454545 !important; }

a.bg-dark:hover, a.bg-dark:focus,
button.bg-dark:hover,
button.bg-dark:focus {
  background-color: #2c2c2c !important; }

.bg-lighter {
  background-color: #F4F4F4 !important; }

a.bg-lighter:hover, a.bg-lighter:focus,
button.bg-lighter:hover,
button.bg-lighter:focus {
  background-color: #dbdbdb !important; }

.bg-gray {
  background-color: #757575 !important; }

a.bg-gray:hover, a.bg-gray:focus,
button.bg-gray:hover,
button.bg-gray:focus {
  background-color: #5c5c5c !important; }

.bg-gray-dark {
  background-color: #171717 !important; }

a.bg-gray-dark:hover, a.bg-gray-dark:focus,
button.bg-gray-dark:hover,
button.bg-gray-dark:focus {
  background-color: black !important; }

.bg-white {
  background-color: #FFFFFF !important; }

.bg-transparent {
  background-color: transparent !important; }

.border {
  border: 0.1rem solid #E4E4E4 !important; }

.border-top {
  border-top: 0.1rem solid #E4E4E4 !important; }

.border-right {
  border-right: 0.1rem solid #E4E4E4 !important; }

.border-bottom {
  border-bottom: 0.1rem solid #E4E4E4 !important; }

.border-left {
  border-left: 0.1rem solid #E4E4E4 !important; }

.border-0 {
  border: 0 !important; }

.border-top-0 {
  border-top: 0 !important; }

.border-right-0 {
  border-right: 0 !important; }

.border-bottom-0 {
  border-bottom: 0 !important; }

.border-left-0 {
  border-left: 0 !important; }

.border-primary {
  border-color: #454545 !important; }

.border-secondary {
  border-color: #e5291d !important; }

.border-success {
  border-color: #AFCD50 !important; }

.border-info {
  border-color: #64C3D7 !important; }

.border-warning {
  border-color: #F5A023 !important; }

.border-danger {
  border-color: #e5291d !important; }

.border-light {
  border-color: #CCCCCC !important; }

.border-dark {
  border-color: #454545 !important; }

.border-lighter {
  border-color: #F4F4F4 !important; }

.border-gray {
  border-color: #757575 !important; }

.border-gray-dark {
  border-color: #171717 !important; }

.border-white {
  border-color: #FFFFFF !important; }

.rounded {
  border-radius: 0 !important; }

.rounded-top {
  border-top-left-radius: 0 !important;
  border-top-right-radius: 0 !important; }

.rounded-right {
  border-top-right-radius: 0 !important;
  border-bottom-right-radius: 0 !important; }

.rounded-bottom {
  border-bottom-right-radius: 0 !important;
  border-bottom-left-radius: 0 !important; }

.rounded-left {
  border-top-left-radius: 0 !important;
  border-bottom-left-radius: 0 !important; }

.rounded-circle {
  border-radius: 50% !important; }

.rounded-0 {
  border-radius: 0 !important; }

.clearfix::after {
  display: block;
  clear: both;
  content: ""; }

.d-none {
  display: none !important; }

.d-inline {
  display: inline !important; }

.d-inline-block {
  display: inline-block !important; }

.d-block {
  display: block !important; }

.d-table {
  display: table !important; }

.d-table-row {
  display: table-row !important; }

.d-table-cell {
  display: table-cell !important; }

.d-flex {
  display: -webkit-box !important;
  display: flex !important; }

.d-inline-flex {
  display: -webkit-inline-box !important;
  display: inline-flex !important; }

@media (min-width: 576px) {
  .d-sm-none {
    display: none !important; }
  .d-sm-inline {
    display: inline !important; }
  .d-sm-inline-block {
    display: inline-block !important; }
  .d-sm-block {
    display: block !important; }
  .d-sm-table {
    display: table !important; }
  .d-sm-table-row {
    display: table-row !important; }
  .d-sm-table-cell {
    display: table-cell !important; }
  .d-sm-flex {
    display: -webkit-box !important;
    display: flex !important; }
  .d-sm-inline-flex {
    display: -webkit-inline-box !important;
    display: inline-flex !important; } }

@media (min-width: 768px) {
  .d-md-none {
    display: none !important; }
  .d-md-inline {
    display: inline !important; }
  .d-md-inline-block {
    display: inline-block !important; }
  .d-md-block {
    display: block !important; }
  .d-md-table {
    display: table !important; }
  .d-md-table-row {
    display: table-row !important; }
  .d-md-table-cell {
    display: table-cell !important; }
  .d-md-flex {
    display: -webkit-box !important;
    display: flex !important; }
  .d-md-inline-flex {
    display: -webkit-inline-box !important;
    display: inline-flex !important; } }

@media (min-width: 992px) {
  .d-lg-none {
    display: none !important; }
  .d-lg-inline {
    display: inline !important; }
  .d-lg-inline-block {
    display: inline-block !important; }
  .d-lg-block {
    display: block !important; }
  .d-lg-table {
    display: table !important; }
  .d-lg-table-row {
    display: table-row !important; }
  .d-lg-table-cell {
    display: table-cell !important; }
  .d-lg-flex {
    display: -webkit-box !important;
    display: flex !important; }
  .d-lg-inline-flex {
    display: -webkit-inline-box !important;
    display: inline-flex !important; } }

@media (min-width: 1200px) {
  .d-xl-none {
    display: none !important; }
  .d-xl-inline {
    display: inline !important; }
  .d-xl-inline-block {
    display: inline-block !important; }
  .d-xl-block {
    display: block !important; }
  .d-xl-table {
    display: table !important; }
  .d-xl-table-row {
    display: table-row !important; }
  .d-xl-table-cell {
    display: table-cell !important; }
  .d-xl-flex {
    display: -webkit-box !important;
    display: flex !important; }
  .d-xl-inline-flex {
    display: -webkit-inline-box !important;
    display: inline-flex !important; } }

@media (min-width: 1400px) {
  .d-xxl-none {
    display: none !important; }
  .d-xxl-inline {
    display: inline !important; }
  .d-xxl-inline-block {
    display: inline-block !important; }
  .d-xxl-block {
    display: block !important; }
  .d-xxl-table {
    display: table !important; }
  .d-xxl-table-row {
    display: table-row !important; }
  .d-xxl-table-cell {
    display: table-cell !important; }
  .d-xxl-flex {
    display: -webkit-box !important;
    display: flex !important; }
  .d-xxl-inline-flex {
    display: -webkit-inline-box !important;
    display: inline-flex !important; } }

@media (min-width: 1600px) {
  .d-xxxl-none {
    display: none !important; }
  .d-xxxl-inline {
    display: inline !important; }
  .d-xxxl-inline-block {
    display: inline-block !important; }
  .d-xxxl-block {
    display: block !important; }
  .d-xxxl-table {
    display: table !important; }
  .d-xxxl-table-row {
    display: table-row !important; }
  .d-xxxl-table-cell {
    display: table-cell !important; }
  .d-xxxl-flex {
    display: -webkit-box !important;
    display: flex !important; }
  .d-xxxl-inline-flex {
    display: -webkit-inline-box !important;
    display: inline-flex !important; } }

@media print {
  .d-print-none {
    display: none !important; }
  .d-print-inline {
    display: inline !important; }
  .d-print-inline-block {
    display: inline-block !important; }
  .d-print-block {
    display: block !important; }
  .d-print-table {
    display: table !important; }
  .d-print-table-row {
    display: table-row !important; }
  .d-print-table-cell {
    display: table-cell !important; }
  .d-print-flex {
    display: -webkit-box !important;
    display: flex !important; }
  .d-print-inline-flex {
    display: -webkit-inline-box !important;
    display: inline-flex !important; } }

.embed-responsive {
  position: relative;
  display: block;
  width: 100%;
  padding: 0;
  overflow: hidden; }
  .embed-responsive::before {
    display: block;
    content: ""; }
  .embed-responsive .embed-responsive-item,
  .embed-responsive iframe,
  .embed-responsive embed,
  .embed-responsive object,
  .embed-responsive video {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border: 0; }

.embed-responsive-21by9::before {
  padding-top: 42.85714%; }

.embed-responsive-16by9::before {
  padding-top: 56.25%; }

.embed-responsive-4by3::before {
  padding-top: 75%; }

.embed-responsive-1by1::before {
  padding-top: 100%; }

.flex-row {
  -webkit-box-orient: horizontal !important;
  -webkit-box-direction: normal !important;
          flex-direction: row !important; }

.flex-column {
  -webkit-box-orient: vertical !important;
  -webkit-box-direction: normal !important;
          flex-direction: column !important; }

.flex-row-reverse {
  -webkit-box-orient: horizontal !important;
  -webkit-box-direction: reverse !important;
          flex-direction: row-reverse !important; }

.flex-column-reverse {
  -webkit-box-orient: vertical !important;
  -webkit-box-direction: reverse !important;
          flex-direction: column-reverse !important; }

.flex-wrap {
  flex-wrap: wrap !important; }

.flex-nowrap {
  flex-wrap: nowrap !important; }

.flex-wrap-reverse {
  flex-wrap: wrap-reverse !important; }

.flex-fill {
  -webkit-box-flex: 1 !important;
          flex: 1 1 auto !important; }

.flex-grow-0 {
  -webkit-box-flex: 0 !important;
          flex-grow: 0 !important; }

.flex-grow-1 {
  -webkit-box-flex: 1 !important;
          flex-grow: 1 !important; }

.flex-shrink-0 {
  flex-shrink: 0 !important; }

.flex-shrink-1 {
  flex-shrink: 1 !important; }

.justify-content-start {
  -webkit-box-pack: start !important;
          justify-content: flex-start !important; }

.justify-content-end {
  -webkit-box-pack: end !important;
          justify-content: flex-end !important; }

.justify-content-center {
  -webkit-box-pack: center !important;
          justify-content: center !important; }

.justify-content-between {
  -webkit-box-pack: justify !important;
          justify-content: space-between !important; }

.justify-content-around {
  justify-content: space-around !important; }

.align-items-start {
  -webkit-box-align: start !important;
          align-items: flex-start !important; }

.align-items-end {
  -webkit-box-align: end !important;
          align-items: flex-end !important; }

.align-items-center {
  -webkit-box-align: center !important;
          align-items: center !important; }

.align-items-baseline {
  -webkit-box-align: baseline !important;
          align-items: baseline !important; }

.align-items-stretch {
  -webkit-box-align: stretch !important;
          align-items: stretch !important; }

.align-content-start {
  align-content: flex-start !important; }

.align-content-end {
  align-content: flex-end !important; }

.align-content-center {
  align-content: center !important; }

.align-content-between {
  align-content: space-between !important; }

.align-content-around {
  align-content: space-around !important; }

.align-content-stretch {
  align-content: stretch !important; }

.align-self-auto {
  align-self: auto !important; }

.align-self-start {
  align-self: flex-start !important; }

.align-self-end {
  align-self: flex-end !important; }

.align-self-center {
  align-self: center !important; }

.align-self-baseline {
  align-self: baseline !important; }

.align-self-stretch {
  align-self: stretch !important; }

@media (min-width: 576px) {
  .flex-sm-row {
    -webkit-box-orient: horizontal !important;
    -webkit-box-direction: normal !important;
            flex-direction: row !important; }
  .flex-sm-column {
    -webkit-box-orient: vertical !important;
    -webkit-box-direction: normal !important;
            flex-direction: column !important; }
  .flex-sm-row-reverse {
    -webkit-box-orient: horizontal !important;
    -webkit-box-direction: reverse !important;
            flex-direction: row-reverse !important; }
  .flex-sm-column-reverse {
    -webkit-box-orient: vertical !important;
    -webkit-box-direction: reverse !important;
            flex-direction: column-reverse !important; }
  .flex-sm-wrap {
    flex-wrap: wrap !important; }
  .flex-sm-nowrap {
    flex-wrap: nowrap !important; }
  .flex-sm-wrap-reverse {
    flex-wrap: wrap-reverse !important; }
  .flex-sm-fill {
    -webkit-box-flex: 1 !important;
            flex: 1 1 auto !important; }
  .flex-sm-grow-0 {
    -webkit-box-flex: 0 !important;
            flex-grow: 0 !important; }
  .flex-sm-grow-1 {
    -webkit-box-flex: 1 !important;
            flex-grow: 1 !important; }
  .flex-sm-shrink-0 {
    flex-shrink: 0 !important; }
  .flex-sm-shrink-1 {
    flex-shrink: 1 !important; }
  .justify-content-sm-start {
    -webkit-box-pack: start !important;
            justify-content: flex-start !important; }
  .justify-content-sm-end {
    -webkit-box-pack: end !important;
            justify-content: flex-end !important; }
  .justify-content-sm-center {
    -webkit-box-pack: center !important;
            justify-content: center !important; }
  .justify-content-sm-between {
    -webkit-box-pack: justify !important;
            justify-content: space-between !important; }
  .justify-content-sm-around {
    justify-content: space-around !important; }
  .align-items-sm-start {
    -webkit-box-align: start !important;
            align-items: flex-start !important; }
  .align-items-sm-end {
    -webkit-box-align: end !important;
            align-items: flex-end !important; }
  .align-items-sm-center {
    -webkit-box-align: center !important;
            align-items: center !important; }
  .align-items-sm-baseline {
    -webkit-box-align: baseline !important;
            align-items: baseline !important; }
  .align-items-sm-stretch {
    -webkit-box-align: stretch !important;
            align-items: stretch !important; }
  .align-content-sm-start {
    align-content: flex-start !important; }
  .align-content-sm-end {
    align-content: flex-end !important; }
  .align-content-sm-center {
    align-content: center !important; }
  .align-content-sm-between {
    align-content: space-between !important; }
  .align-content-sm-around {
    align-content: space-around !important; }
  .align-content-sm-stretch {
    align-content: stretch !important; }
  .align-self-sm-auto {
    align-self: auto !important; }
  .align-self-sm-start {
    align-self: flex-start !important; }
  .align-self-sm-end {
    align-self: flex-end !important; }
  .align-self-sm-center {
    align-self: center !important; }
  .align-self-sm-baseline {
    align-self: baseline !important; }
  .align-self-sm-stretch {
    align-self: stretch !important; } }

@media (min-width: 768px) {
  .flex-md-row {
    -webkit-box-orient: horizontal !important;
    -webkit-box-direction: normal !important;
            flex-direction: row !important; }
  .flex-md-column {
    -webkit-box-orient: vertical !important;
    -webkit-box-direction: normal !important;
            flex-direction: column !important; }
  .flex-md-row-reverse {
    -webkit-box-orient: horizontal !important;
    -webkit-box-direction: reverse !important;
            flex-direction: row-reverse !important; }
  .flex-md-column-reverse {
    -webkit-box-orient: vertical !important;
    -webkit-box-direction: reverse !important;
            flex-direction: column-reverse !important; }
  .flex-md-wrap {
    flex-wrap: wrap !important; }
  .flex-md-nowrap {
    flex-wrap: nowrap !important; }
  .flex-md-wrap-reverse {
    flex-wrap: wrap-reverse !important; }
  .flex-md-fill {
    -webkit-box-flex: 1 !important;
            flex: 1 1 auto !important; }
  .flex-md-grow-0 {
    -webkit-box-flex: 0 !important;
            flex-grow: 0 !important; }
  .flex-md-grow-1 {
    -webkit-box-flex: 1 !important;
            flex-grow: 1 !important; }
  .flex-md-shrink-0 {
    flex-shrink: 0 !important; }
  .flex-md-shrink-1 {
    flex-shrink: 1 !important; }
  .justify-content-md-start {
    -webkit-box-pack: start !important;
            justify-content: flex-start !important; }
  .justify-content-md-end {
    -webkit-box-pack: end !important;
            justify-content: flex-end !important; }
  .justify-content-md-center {
    -webkit-box-pack: center !important;
            justify-content: center !important; }
  .justify-content-md-between {
    -webkit-box-pack: justify !important;
            justify-content: space-between !important; }
  .justify-content-md-around {
    justify-content: space-around !important; }
  .align-items-md-start {
    -webkit-box-align: start !important;
            align-items: flex-start !important; }
  .align-items-md-end {
    -webkit-box-align: end !important;
            align-items: flex-end !important; }
  .align-items-md-center {
    -webkit-box-align: center !important;
            align-items: center !important; }
  .align-items-md-baseline {
    -webkit-box-align: baseline !important;
            align-items: baseline !important; }
  .align-items-md-stretch {
    -webkit-box-align: stretch !important;
            align-items: stretch !important; }
  .align-content-md-start {
    align-content: flex-start !important; }
  .align-content-md-end {
    align-content: flex-end !important; }
  .align-content-md-center {
    align-content: center !important; }
  .align-content-md-between {
    align-content: space-between !important; }
  .align-content-md-around {
    align-content: space-around !important; }
  .align-content-md-stretch {
    align-content: stretch !important; }
  .align-self-md-auto {
    align-self: auto !important; }
  .align-self-md-start {
    align-self: flex-start !important; }
  .align-self-md-end {
    align-self: flex-end !important; }
  .align-self-md-center {
    align-self: center !important; }
  .align-self-md-baseline {
    align-self: baseline !important; }
  .align-self-md-stretch {
    align-self: stretch !important; } }

@media (min-width: 992px) {
  .flex-lg-row {
    -webkit-box-orient: horizontal !important;
    -webkit-box-direction: normal !important;
            flex-direction: row !important; }
  .flex-lg-column {
    -webkit-box-orient: vertical !important;
    -webkit-box-direction: normal !important;
            flex-direction: column !important; }
  .flex-lg-row-reverse {
    -webkit-box-orient: horizontal !important;
    -webkit-box-direction: reverse !important;
            flex-direction: row-reverse !important; }
  .flex-lg-column-reverse {
    -webkit-box-orient: vertical !important;
    -webkit-box-direction: reverse !important;
            flex-direction: column-reverse !important; }
  .flex-lg-wrap {
    flex-wrap: wrap !important; }
  .flex-lg-nowrap {
    flex-wrap: nowrap !important; }
  .flex-lg-wrap-reverse {
    flex-wrap: wrap-reverse !important; }
  .flex-lg-fill {
    -webkit-box-flex: 1 !important;
            flex: 1 1 auto !important; }
  .flex-lg-grow-0 {
    -webkit-box-flex: 0 !important;
            flex-grow: 0 !important; }
  .flex-lg-grow-1 {
    -webkit-box-flex: 1 !important;
            flex-grow: 1 !important; }
  .flex-lg-shrink-0 {
    flex-shrink: 0 !important; }
  .flex-lg-shrink-1 {
    flex-shrink: 1 !important; }
  .justify-content-lg-start {
    -webkit-box-pack: start !important;
            justify-content: flex-start !important; }
  .justify-content-lg-end {
    -webkit-box-pack: end !important;
            justify-content: flex-end !important; }
  .justify-content-lg-center {
    -webkit-box-pack: center !important;
            justify-content: center !important; }
  .justify-content-lg-between {
    -webkit-box-pack: justify !important;
            justify-content: space-between !important; }
  .justify-content-lg-around {
    justify-content: space-around !important; }
  .align-items-lg-start {
    -webkit-box-align: start !important;
            align-items: flex-start !important; }
  .align-items-lg-end {
    -webkit-box-align: end !important;
            align-items: flex-end !important; }
  .align-items-lg-center {
    -webkit-box-align: center !important;
            align-items: center !important; }
  .align-items-lg-baseline {
    -webkit-box-align: baseline !important;
            align-items: baseline !important; }
  .align-items-lg-stretch {
    -webkit-box-align: stretch !important;
            align-items: stretch !important; }
  .align-content-lg-start {
    align-content: flex-start !important; }
  .align-content-lg-end {
    align-content: flex-end !important; }
  .align-content-lg-center {
    align-content: center !important; }
  .align-content-lg-between {
    align-content: space-between !important; }
  .align-content-lg-around {
    align-content: space-around !important; }
  .align-content-lg-stretch {
    align-content: stretch !important; }
  .align-self-lg-auto {
    align-self: auto !important; }
  .align-self-lg-start {
    align-self: flex-start !important; }
  .align-self-lg-end {
    align-self: flex-end !important; }
  .align-self-lg-center {
    align-self: center !important; }
  .align-self-lg-baseline {
    align-self: baseline !important; }
  .align-self-lg-stretch {
    align-self: stretch !important; } }

@media (min-width: 1200px) {
  .flex-xl-row {
    -webkit-box-orient: horizontal !important;
    -webkit-box-direction: normal !important;
            flex-direction: row !important; }
  .flex-xl-column {
    -webkit-box-orient: vertical !important;
    -webkit-box-direction: normal !important;
            flex-direction: column !important; }
  .flex-xl-row-reverse {
    -webkit-box-orient: horizontal !important;
    -webkit-box-direction: reverse !important;
            flex-direction: row-reverse !important; }
  .flex-xl-column-reverse {
    -webkit-box-orient: vertical !important;
    -webkit-box-direction: reverse !important;
            flex-direction: column-reverse !important; }
  .flex-xl-wrap {
    flex-wrap: wrap !important; }
  .flex-xl-nowrap {
    flex-wrap: nowrap !important; }
  .flex-xl-wrap-reverse {
    flex-wrap: wrap-reverse !important; }
  .flex-xl-fill {
    -webkit-box-flex: 1 !important;
            flex: 1 1 auto !important; }
  .flex-xl-grow-0 {
    -webkit-box-flex: 0 !important;
            flex-grow: 0 !important; }
  .flex-xl-grow-1 {
    -webkit-box-flex: 1 !important;
            flex-grow: 1 !important; }
  .flex-xl-shrink-0 {
    flex-shrink: 0 !important; }
  .flex-xl-shrink-1 {
    flex-shrink: 1 !important; }
  .justify-content-xl-start {
    -webkit-box-pack: start !important;
            justify-content: flex-start !important; }
  .justify-content-xl-end {
    -webkit-box-pack: end !important;
            justify-content: flex-end !important; }
  .justify-content-xl-center {
    -webkit-box-pack: center !important;
            justify-content: center !important; }
  .justify-content-xl-between {
    -webkit-box-pack: justify !important;
            justify-content: space-between !important; }
  .justify-content-xl-around {
    justify-content: space-around !important; }
  .align-items-xl-start {
    -webkit-box-align: start !important;
            align-items: flex-start !important; }
  .align-items-xl-end {
    -webkit-box-align: end !important;
            align-items: flex-end !important; }
  .align-items-xl-center {
    -webkit-box-align: center !important;
            align-items: center !important; }
  .align-items-xl-baseline {
    -webkit-box-align: baseline !important;
            align-items: baseline !important; }
  .align-items-xl-stretch {
    -webkit-box-align: stretch !important;
            align-items: stretch !important; }
  .align-content-xl-start {
    align-content: flex-start !important; }
  .align-content-xl-end {
    align-content: flex-end !important; }
  .align-content-xl-center {
    align-content: center !important; }
  .align-content-xl-between {
    align-content: space-between !important; }
  .align-content-xl-around {
    align-content: space-around !important; }
  .align-content-xl-stretch {
    align-content: stretch !important; }
  .align-self-xl-auto {
    align-self: auto !important; }
  .align-self-xl-start {
    align-self: flex-start !important; }
  .align-self-xl-end {
    align-self: flex-end !important; }
  .align-self-xl-center {
    align-self: center !important; }
  .align-self-xl-baseline {
    align-self: baseline !important; }
  .align-self-xl-stretch {
    align-self: stretch !important; } }

@media (min-width: 1400px) {
  .flex-xxl-row {
    -webkit-box-orient: horizontal !important;
    -webkit-box-direction: normal !important;
            flex-direction: row !important; }
  .flex-xxl-column {
    -webkit-box-orient: vertical !important;
    -webkit-box-direction: normal !important;
            flex-direction: column !important; }
  .flex-xxl-row-reverse {
    -webkit-box-orient: horizontal !important;
    -webkit-box-direction: reverse !important;
            flex-direction: row-reverse !important; }
  .flex-xxl-column-reverse {
    -webkit-box-orient: vertical !important;
    -webkit-box-direction: reverse !important;
            flex-direction: column-reverse !important; }
  .flex-xxl-wrap {
    flex-wrap: wrap !important; }
  .flex-xxl-nowrap {
    flex-wrap: nowrap !important; }
  .flex-xxl-wrap-reverse {
    flex-wrap: wrap-reverse !important; }
  .flex-xxl-fill {
    -webkit-box-flex: 1 !important;
            flex: 1 1 auto !important; }
  .flex-xxl-grow-0 {
    -webkit-box-flex: 0 !important;
            flex-grow: 0 !important; }
  .flex-xxl-grow-1 {
    -webkit-box-flex: 1 !important;
            flex-grow: 1 !important; }
  .flex-xxl-shrink-0 {
    flex-shrink: 0 !important; }
  .flex-xxl-shrink-1 {
    flex-shrink: 1 !important; }
  .justify-content-xxl-start {
    -webkit-box-pack: start !important;
            justify-content: flex-start !important; }
  .justify-content-xxl-end {
    -webkit-box-pack: end !important;
            justify-content: flex-end !important; }
  .justify-content-xxl-center {
    -webkit-box-pack: center !important;
            justify-content: center !important; }
  .justify-content-xxl-between {
    -webkit-box-pack: justify !important;
            justify-content: space-between !important; }
  .justify-content-xxl-around {
    justify-content: space-around !important; }
  .align-items-xxl-start {
    -webkit-box-align: start !important;
            align-items: flex-start !important; }
  .align-items-xxl-end {
    -webkit-box-align: end !important;
            align-items: flex-end !important; }
  .align-items-xxl-center {
    -webkit-box-align: center !important;
            align-items: center !important; }
  .align-items-xxl-baseline {
    -webkit-box-align: baseline !important;
            align-items: baseline !important; }
  .align-items-xxl-stretch {
    -webkit-box-align: stretch !important;
            align-items: stretch !important; }
  .align-content-xxl-start {
    align-content: flex-start !important; }
  .align-content-xxl-end {
    align-content: flex-end !important; }
  .align-content-xxl-center {
    align-content: center !important; }
  .align-content-xxl-between {
    align-content: space-between !important; }
  .align-content-xxl-around {
    align-content: space-around !important; }
  .align-content-xxl-stretch {
    align-content: stretch !important; }
  .align-self-xxl-auto {
    align-self: auto !important; }
  .align-self-xxl-start {
    align-self: flex-start !important; }
  .align-self-xxl-end {
    align-self: flex-end !important; }
  .align-self-xxl-center {
    align-self: center !important; }
  .align-self-xxl-baseline {
    align-self: baseline !important; }
  .align-self-xxl-stretch {
    align-self: stretch !important; } }

@media (min-width: 1600px) {
  .flex-xxxl-row {
    -webkit-box-orient: horizontal !important;
    -webkit-box-direction: normal !important;
            flex-direction: row !important; }
  .flex-xxxl-column {
    -webkit-box-orient: vertical !important;
    -webkit-box-direction: normal !important;
            flex-direction: column !important; }
  .flex-xxxl-row-reverse {
    -webkit-box-orient: horizontal !important;
    -webkit-box-direction: reverse !important;
            flex-direction: row-reverse !important; }
  .flex-xxxl-column-reverse {
    -webkit-box-orient: vertical !important;
    -webkit-box-direction: reverse !important;
            flex-direction: column-reverse !important; }
  .flex-xxxl-wrap {
    flex-wrap: wrap !important; }
  .flex-xxxl-nowrap {
    flex-wrap: nowrap !important; }
  .flex-xxxl-wrap-reverse {
    flex-wrap: wrap-reverse !important; }
  .flex-xxxl-fill {
    -webkit-box-flex: 1 !important;
            flex: 1 1 auto !important; }
  .flex-xxxl-grow-0 {
    -webkit-box-flex: 0 !important;
            flex-grow: 0 !important; }
  .flex-xxxl-grow-1 {
    -webkit-box-flex: 1 !important;
            flex-grow: 1 !important; }
  .flex-xxxl-shrink-0 {
    flex-shrink: 0 !important; }
  .flex-xxxl-shrink-1 {
    flex-shrink: 1 !important; }
  .justify-content-xxxl-start {
    -webkit-box-pack: start !important;
            justify-content: flex-start !important; }
  .justify-content-xxxl-end {
    -webkit-box-pack: end !important;
            justify-content: flex-end !important; }
  .justify-content-xxxl-center {
    -webkit-box-pack: center !important;
            justify-content: center !important; }
  .justify-content-xxxl-between {
    -webkit-box-pack: justify !important;
            justify-content: space-between !important; }
  .justify-content-xxxl-around {
    justify-content: space-around !important; }
  .align-items-xxxl-start {
    -webkit-box-align: start !important;
            align-items: flex-start !important; }
  .align-items-xxxl-end {
    -webkit-box-align: end !important;
            align-items: flex-end !important; }
  .align-items-xxxl-center {
    -webkit-box-align: center !important;
            align-items: center !important; }
  .align-items-xxxl-baseline {
    -webkit-box-align: baseline !important;
            align-items: baseline !important; }
  .align-items-xxxl-stretch {
    -webkit-box-align: stretch !important;
            align-items: stretch !important; }
  .align-content-xxxl-start {
    align-content: flex-start !important; }
  .align-content-xxxl-end {
    align-content: flex-end !important; }
  .align-content-xxxl-center {
    align-content: center !important; }
  .align-content-xxxl-between {
    align-content: space-between !important; }
  .align-content-xxxl-around {
    align-content: space-around !important; }
  .align-content-xxxl-stretch {
    align-content: stretch !important; }
  .align-self-xxxl-auto {
    align-self: auto !important; }
  .align-self-xxxl-start {
    align-self: flex-start !important; }
  .align-self-xxxl-end {
    align-self: flex-end !important; }
  .align-self-xxxl-center {
    align-self: center !important; }
  .align-self-xxxl-baseline {
    align-self: baseline !important; }
  .align-self-xxxl-stretch {
    align-self: stretch !important; } }

.float-left {
  float: left !important; }

.float-right {
  float: right !important; }

.float-none {
  float: none !important; }

@media (min-width: 576px) {
  .float-sm-left {
    float: left !important; }
  .float-sm-right {
    float: right !important; }
  .float-sm-none {
    float: none !important; } }

@media (min-width: 768px) {
  .float-md-left, .footer-segment .menu {
    float: left !important; }
  .float-md-right {
    float: right !important; }
  .float-md-none {
    float: none !important; } }

@media (min-width: 992px) {
  .float-lg-left {
    float: left !important; }
  .float-lg-right {
    float: right !important; }
  .float-lg-none {
    float: none !important; } }

@media (min-width: 1200px) {
  .float-xl-left, .footer-segment .block-footer-menu,
  .footer-segment .menu--segment-footer,
  .footer-segment .block-social-media-links {
    float: left !important; }
  .float-xl-right {
    float: right !important; }
  .float-xl-none {
    float: none !important; } }

@media (min-width: 1400px) {
  .float-xxl-left {
    float: left !important; }
  .float-xxl-right {
    float: right !important; }
  .float-xxl-none {
    float: none !important; } }

@media (min-width: 1600px) {
  .float-xxxl-left {
    float: left !important; }
  .float-xxxl-right {
    float: right !important; }
  .float-xxxl-none {
    float: none !important; } }

.position-static {
  position: static !important; }

.position-relative {
  position: relative !important; }

.position-absolute {
  position: absolute !important; }

.position-fixed {
  position: fixed !important; }

.position-sticky {
  position: -webkit-sticky !important;
  position: sticky !important; }

.fixed-top {
  position: fixed;
  top: 0;
  right: 0;
  left: 0;
  z-index: 1030; }

.fixed-bottom {
  position: fixed;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 1030; }

@supports ((position: -webkit-sticky) or (position: sticky)) {
  .sticky-top {
    position: -webkit-sticky;
    position: sticky;
    top: 0;
    z-index: 1020; } }

.sr-only, .icdc-angular .table-recap tbody th,
.icdc-angular .table-recap tfoot th {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0; }

.sr-only-focusable:active, .sr-only-focusable:focus {
  position: static;
  width: auto;
  height: auto;
  overflow: visible;
  clip: auto;
  white-space: normal; }

.shadow-sm {
  box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075) !important; }

.shadow {
  box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important; }

.shadow-lg {
  box-shadow: 0 1rem 3rem rgba(0, 0, 0, 0.175) !important; }

.shadow-none {
  box-shadow: none !important; }

.w-25 {
  width: 25% !important; }

.w-50 {
  width: 50% !important; }

.w-75 {
  width: 75% !important; }

.w-100 {
  width: 100% !important; }

.w-auto {
  width: auto !important; }

.w-33 {
  width: 33.3333% !important; }

.h-25 {
  height: 25% !important; }

.h-50 {
  height: 50% !important; }

.h-75 {
  height: 75% !important; }

.h-100 {
  height: 100% !important; }

.h-auto {
  height: auto !important; }

.h-33 {
  height: 33.3333% !important; }

.mw-100 {
  max-width: 100% !important; }

.mh-100 {
  max-height: 100% !important; }

.m-0 {
  margin: 0 !important; }

.mt-0,
.my-0 {
  margin-top: 0 !important; }

.mr-0,
.mx-0 {
  margin-right: 0 !important; }

.mb-0,
.my-0 {
  margin-bottom: 0 !important; }

.ml-0,
.mx-0 {
  margin-left: 0 !important; }

.m-1 {
  margin: 0.25rem !important; }

.mt-1,
.my-1 {
  margin-top: 0.25rem !important; }

.mr-1,
.mx-1 {
  margin-right: 0.25rem !important; }

.mb-1,
.my-1 {
  margin-bottom: 0.25rem !important; }

.ml-1,
.mx-1 {
  margin-left: 0.25rem !important; }

.m-2 {
  margin: 0.5rem !important; }

.mt-2,
.my-2 {
  margin-top: 0.5rem !important; }

.mr-2,
.mx-2 {
  margin-right: 0.5rem !important; }

.mb-2,
.my-2 {
  margin-bottom: 0.5rem !important; }

.ml-2,
.mx-2 {
  margin-left: 0.5rem !important; }

.m-3 {
  margin: 1rem !important; }

.mt-3,
.my-3 {
  margin-top: 1rem !important; }

.mr-3,
.mx-3 {
  margin-right: 1rem !important; }

.mb-3,
.my-3 {
  margin-bottom: 1rem !important; }

.ml-3,
.mx-3 {
  margin-left: 1rem !important; }

.m-4 {
  margin: 1.5rem !important; }

.mt-4,
.my-4 {
  margin-top: 1.5rem !important; }

.mr-4,
.mx-4 {
  margin-right: 1.5rem !important; }

.mb-4,
.my-4 {
  margin-bottom: 1.5rem !important; }

.ml-4,
.mx-4 {
  margin-left: 1.5rem !important; }

.m-5 {
  margin: 2rem !important; }

.mt-5,
.my-5 {
  margin-top: 2rem !important; }

.mr-5,
.mx-5 {
  margin-right: 2rem !important; }

.mb-5,
.my-5 {
  margin-bottom: 2rem !important; }

.ml-5,
.mx-5 {
  margin-left: 2rem !important; }

.m-6 {
  margin: 3rem !important; }

.mt-6,
.my-6 {
  margin-top: 3rem !important; }

.mr-6,
.mx-6 {
  margin-right: 3rem !important; }

.mb-6,
.my-6 {
  margin-bottom: 3rem !important; }

.ml-6,
.mx-6 {
  margin-left: 3rem !important; }

.m-7 {
  margin: 4rem !important; }

.mt-7,
.my-7 {
  margin-top: 4rem !important; }

.mr-7,
.mx-7 {
  margin-right: 4rem !important; }

.mb-7,
.my-7 {
  margin-bottom: 4rem !important; }

.ml-7,
.mx-7 {
  margin-left: 4rem !important; }

.m-8 {
  margin: 5rem !important; }

.mt-8,
.my-8 {
  margin-top: 5rem !important; }

.mr-8,
.mx-8 {
  margin-right: 5rem !important; }

.mb-8,
.my-8 {
  margin-bottom: 5rem !important; }

.ml-8,
.mx-8 {
  margin-left: 5rem !important; }

.m-9 {
  margin: 6rem !important; }

.mt-9,
.my-9 {
  margin-top: 6rem !important; }

.mr-9,
.mx-9 {
  margin-right: 6rem !important; }

.mb-9,
.my-9 {
  margin-bottom: 6rem !important; }

.ml-9,
.mx-9 {
  margin-left: 6rem !important; }

.m-10 {
  margin: 7rem !important; }

.mt-10,
.my-10 {
  margin-top: 7rem !important; }

.mr-10,
.mx-10 {
  margin-right: 7rem !important; }

.mb-10,
.my-10 {
  margin-bottom: 7rem !important; }

.ml-10,
.mx-10 {
  margin-left: 7rem !important; }

.m-11 {
  margin: 8rem !important; }

.mt-11,
.my-11 {
  margin-top: 8rem !important; }

.mr-11,
.mx-11 {
  margin-right: 8rem !important; }

.mb-11,
.my-11 {
  margin-bottom: 8rem !important; }

.ml-11,
.mx-11 {
  margin-left: 8rem !important; }

.m-12 {
  margin: 9rem !important; }

.mt-12,
.my-12 {
  margin-top: 9rem !important; }

.mr-12,
.mx-12 {
  margin-right: 9rem !important; }

.mb-12,
.my-12 {
  margin-bottom: 9rem !important; }

.ml-12,
.mx-12 {
  margin-left: 9rem !important; }

.m-13 {
  margin: 10rem !important; }

.mt-13,
.my-13 {
  margin-top: 10rem !important; }

.mr-13,
.mx-13 {
  margin-right: 10rem !important; }

.mb-13,
.my-13 {
  margin-bottom: 10rem !important; }

.ml-13,
.mx-13 {
  margin-left: 10rem !important; }

.m-15 {
  margin: 15rem !important; }

.mt-15,
.my-15 {
  margin-top: 15rem !important; }

.mr-15,
.mx-15 {
  margin-right: 15rem !important; }

.mb-15,
.my-15 {
  margin-bottom: 15rem !important; }

.ml-15,
.mx-15 {
  margin-left: 15rem !important; }

.p-0 {
  padding: 0 !important; }

.pt-0,
.py-0 {
  padding-top: 0 !important; }

.pr-0,
.px-0 {
  padding-right: 0 !important; }

.pb-0,
.py-0 {
  padding-bottom: 0 !important; }

.pl-0,
.px-0 {
  padding-left: 0 !important; }

.p-1 {
  padding: 0.25rem !important; }

.pt-1,
.py-1 {
  padding-top: 0.25rem !important; }

.pr-1,
.px-1 {
  padding-right: 0.25rem !important; }

.pb-1,
.py-1 {
  padding-bottom: 0.25rem !important; }

.pl-1,
.px-1 {
  padding-left: 0.25rem !important; }

.p-2 {
  padding: 0.5rem !important; }

.pt-2,
.py-2 {
  padding-top: 0.5rem !important; }

.pr-2,
.px-2 {
  padding-right: 0.5rem !important; }

.pb-2,
.py-2 {
  padding-bottom: 0.5rem !important; }

.pl-2,
.px-2 {
  padding-left: 0.5rem !important; }

.p-3 {
  padding: 1rem !important; }

.pt-3,
.py-3 {
  padding-top: 1rem !important; }

.pr-3,
.px-3 {
  padding-right: 1rem !important; }

.pb-3,
.py-3 {
  padding-bottom: 1rem !important; }

.pl-3,
.px-3 {
  padding-left: 1rem !important; }

.p-4 {
  padding: 1.5rem !important; }

.pt-4,
.py-4 {
  padding-top: 1.5rem !important; }

.pr-4,
.px-4 {
  padding-right: 1.5rem !important; }

.pb-4,
.py-4 {
  padding-bottom: 1.5rem !important; }

.pl-4,
.px-4 {
  padding-left: 1.5rem !important; }

.p-5 {
  padding: 2rem !important; }

.pt-5,
.py-5 {
  padding-top: 2rem !important; }

.pr-5,
.px-5 {
  padding-right: 2rem !important; }

.pb-5,
.py-5 {
  padding-bottom: 2rem !important; }

.pl-5,
.px-5 {
  padding-left: 2rem !important; }

.p-6 {
  padding: 3rem !important; }

.pt-6,
.py-6 {
  padding-top: 3rem !important; }

.pr-6,
.px-6 {
  padding-right: 3rem !important; }

.pb-6,
.py-6 {
  padding-bottom: 3rem !important; }

.pl-6,
.px-6 {
  padding-left: 3rem !important; }

.p-7 {
  padding: 4rem !important; }

.pt-7,
.py-7 {
  padding-top: 4rem !important; }

.pr-7,
.px-7 {
  padding-right: 4rem !important; }

.pb-7,
.py-7 {
  padding-bottom: 4rem !important; }

.pl-7,
.px-7 {
  padding-left: 4rem !important; }

.p-8 {
  padding: 5rem !important; }

.pt-8,
.py-8 {
  padding-top: 5rem !important; }

.pr-8,
.px-8 {
  padding-right: 5rem !important; }

.pb-8,
.py-8 {
  padding-bottom: 5rem !important; }

.pl-8,
.px-8 {
  padding-left: 5rem !important; }

.p-9 {
  padding: 6rem !important; }

.pt-9,
.py-9 {
  padding-top: 6rem !important; }

.pr-9,
.px-9 {
  padding-right: 6rem !important; }

.pb-9,
.py-9 {
  padding-bottom: 6rem !important; }

.pl-9,
.px-9 {
  padding-left: 6rem !important; }

.p-10 {
  padding: 7rem !important; }

.pt-10,
.py-10 {
  padding-top: 7rem !important; }

.pr-10,
.px-10 {
  padding-right: 7rem !important; }

.pb-10,
.py-10 {
  padding-bottom: 7rem !important; }

.pl-10,
.px-10 {
  padding-left: 7rem !important; }

.p-11 {
  padding: 8rem !important; }

.pt-11,
.py-11 {
  padding-top: 8rem !important; }

.pr-11,
.px-11 {
  padding-right: 8rem !important; }

.pb-11,
.py-11 {
  padding-bottom: 8rem !important; }

.pl-11,
.px-11 {
  padding-left: 8rem !important; }

.p-12 {
  padding: 9rem !important; }

.pt-12,
.py-12 {
  padding-top: 9rem !important; }

.pr-12,
.px-12 {
  padding-right: 9rem !important; }

.pb-12,
.py-12 {
  padding-bottom: 9rem !important; }

.pl-12,
.px-12 {
  padding-left: 9rem !important; }

.p-13 {
  padding: 10rem !important; }

.pt-13,
.py-13 {
  padding-top: 10rem !important; }

.pr-13,
.px-13 {
  padding-right: 10rem !important; }

.pb-13,
.py-13 {
  padding-bottom: 10rem !important; }

.pl-13,
.px-13 {
  padding-left: 10rem !important; }

.p-15 {
  padding: 15rem !important; }

.pt-15,
.py-15 {
  padding-top: 15rem !important; }

.pr-15,
.px-15 {
  padding-right: 15rem !important; }

.pb-15,
.py-15 {
  padding-bottom: 15rem !important; }

.pl-15,
.px-15 {
  padding-left: 15rem !important; }

.m-auto {
  margin: auto !important; }

.mt-auto,
.my-auto {
  margin-top: auto !important; }

.mr-auto,
.mx-auto {
  margin-right: auto !important; }

.mb-auto,
.my-auto {
  margin-bottom: auto !important; }

.ml-auto,
.mx-auto {
  margin-left: auto !important; }

@media (min-width: 576px) {
  .m-sm-0 {
    margin: 0 !important; }
  .mt-sm-0,
  .my-sm-0 {
    margin-top: 0 !important; }
  .mr-sm-0,
  .mx-sm-0 {
    margin-right: 0 !important; }
  .mb-sm-0,
  .my-sm-0 {
    margin-bottom: 0 !important; }
  .ml-sm-0,
  .mx-sm-0 {
    margin-left: 0 !important; }
  .m-sm-1 {
    margin: 0.25rem !important; }
  .mt-sm-1,
  .my-sm-1 {
    margin-top: 0.25rem !important; }
  .mr-sm-1,
  .mx-sm-1 {
    margin-right: 0.25rem !important; }
  .mb-sm-1,
  .my-sm-1 {
    margin-bottom: 0.25rem !important; }
  .ml-sm-1,
  .mx-sm-1 {
    margin-left: 0.25rem !important; }
  .m-sm-2 {
    margin: 0.5rem !important; }
  .mt-sm-2,
  .my-sm-2 {
    margin-top: 0.5rem !important; }
  .mr-sm-2,
  .mx-sm-2 {
    margin-right: 0.5rem !important; }
  .mb-sm-2,
  .my-sm-2 {
    margin-bottom: 0.5rem !important; }
  .ml-sm-2,
  .mx-sm-2 {
    margin-left: 0.5rem !important; }
  .m-sm-3 {
    margin: 1rem !important; }
  .mt-sm-3,
  .my-sm-3 {
    margin-top: 1rem !important; }
  .mr-sm-3,
  .mx-sm-3 {
    margin-right: 1rem !important; }
  .mb-sm-3,
  .my-sm-3 {
    margin-bottom: 1rem !important; }
  .ml-sm-3,
  .mx-sm-3 {
    margin-left: 1rem !important; }
  .m-sm-4 {
    margin: 1.5rem !important; }
  .mt-sm-4,
  .my-sm-4 {
    margin-top: 1.5rem !important; }
  .mr-sm-4,
  .mx-sm-4 {
    margin-right: 1.5rem !important; }
  .mb-sm-4,
  .my-sm-4 {
    margin-bottom: 1.5rem !important; }
  .ml-sm-4,
  .mx-sm-4 {
    margin-left: 1.5rem !important; }
  .m-sm-5 {
    margin: 2rem !important; }
  .mt-sm-5,
  .my-sm-5 {
    margin-top: 2rem !important; }
  .mr-sm-5,
  .mx-sm-5 {
    margin-right: 2rem !important; }
  .mb-sm-5,
  .my-sm-5 {
    margin-bottom: 2rem !important; }
  .ml-sm-5,
  .mx-sm-5 {
    margin-left: 2rem !important; }
  .m-sm-6 {
    margin: 3rem !important; }
  .mt-sm-6,
  .my-sm-6 {
    margin-top: 3rem !important; }
  .mr-sm-6,
  .mx-sm-6 {
    margin-right: 3rem !important; }
  .mb-sm-6,
  .my-sm-6 {
    margin-bottom: 3rem !important; }
  .ml-sm-6,
  .mx-sm-6 {
    margin-left: 3rem !important; }
  .m-sm-7 {
    margin: 4rem !important; }
  .mt-sm-7,
  .my-sm-7 {
    margin-top: 4rem !important; }
  .mr-sm-7,
  .mx-sm-7 {
    margin-right: 4rem !important; }
  .mb-sm-7,
  .my-sm-7 {
    margin-bottom: 4rem !important; }
  .ml-sm-7,
  .mx-sm-7 {
    margin-left: 4rem !important; }
  .m-sm-8 {
    margin: 5rem !important; }
  .mt-sm-8,
  .my-sm-8 {
    margin-top: 5rem !important; }
  .mr-sm-8,
  .mx-sm-8 {
    margin-right: 5rem !important; }
  .mb-sm-8,
  .my-sm-8 {
    margin-bottom: 5rem !important; }
  .ml-sm-8,
  .mx-sm-8 {
    margin-left: 5rem !important; }
  .m-sm-9 {
    margin: 6rem !important; }
  .mt-sm-9,
  .my-sm-9 {
    margin-top: 6rem !important; }
  .mr-sm-9,
  .mx-sm-9 {
    margin-right: 6rem !important; }
  .mb-sm-9,
  .my-sm-9 {
    margin-bottom: 6rem !important; }
  .ml-sm-9,
  .mx-sm-9 {
    margin-left: 6rem !important; }
  .m-sm-10 {
    margin: 7rem !important; }
  .mt-sm-10,
  .my-sm-10 {
    margin-top: 7rem !important; }
  .mr-sm-10,
  .mx-sm-10 {
    margin-right: 7rem !important; }
  .mb-sm-10,
  .my-sm-10 {
    margin-bottom: 7rem !important; }
  .ml-sm-10,
  .mx-sm-10 {
    margin-left: 7rem !important; }
  .m-sm-11 {
    margin: 8rem !important; }
  .mt-sm-11,
  .my-sm-11 {
    margin-top: 8rem !important; }
  .mr-sm-11,
  .mx-sm-11 {
    margin-right: 8rem !important; }
  .mb-sm-11,
  .my-sm-11 {
    margin-bottom: 8rem !important; }
  .ml-sm-11,
  .mx-sm-11 {
    margin-left: 8rem !important; }
  .m-sm-12 {
    margin: 9rem !important; }
  .mt-sm-12,
  .my-sm-12 {
    margin-top: 9rem !important; }
  .mr-sm-12,
  .mx-sm-12 {
    margin-right: 9rem !important; }
  .mb-sm-12,
  .my-sm-12 {
    margin-bottom: 9rem !important; }
  .ml-sm-12,
  .mx-sm-12 {
    margin-left: 9rem !important; }
  .m-sm-13 {
    margin: 10rem !important; }
  .mt-sm-13,
  .my-sm-13 {
    margin-top: 10rem !important; }
  .mr-sm-13,
  .mx-sm-13 {
    margin-right: 10rem !important; }
  .mb-sm-13,
  .my-sm-13 {
    margin-bottom: 10rem !important; }
  .ml-sm-13,
  .mx-sm-13 {
    margin-left: 10rem !important; }
  .m-sm-15 {
    margin: 15rem !important; }
  .mt-sm-15,
  .my-sm-15 {
    margin-top: 15rem !important; }
  .mr-sm-15,
  .mx-sm-15 {
    margin-right: 15rem !important; }
  .mb-sm-15,
  .my-sm-15 {
    margin-bottom: 15rem !important; }
  .ml-sm-15,
  .mx-sm-15 {
    margin-left: 15rem !important; }
  .p-sm-0 {
    padding: 0 !important; }
  .pt-sm-0,
  .py-sm-0 {
    padding-top: 0 !important; }
  .pr-sm-0,
  .px-sm-0 {
    padding-right: 0 !important; }
  .pb-sm-0,
  .py-sm-0 {
    padding-bottom: 0 !important; }
  .pl-sm-0,
  .px-sm-0 {
    padding-left: 0 !important; }
  .p-sm-1 {
    padding: 0.25rem !important; }
  .pt-sm-1,
  .py-sm-1 {
    padding-top: 0.25rem !important; }
  .pr-sm-1,
  .px-sm-1 {
    padding-right: 0.25rem !important; }
  .pb-sm-1,
  .py-sm-1 {
    padding-bottom: 0.25rem !important; }
  .pl-sm-1,
  .px-sm-1 {
    padding-left: 0.25rem !important; }
  .p-sm-2 {
    padding: 0.5rem !important; }
  .pt-sm-2,
  .py-sm-2 {
    padding-top: 0.5rem !important; }
  .pr-sm-2,
  .px-sm-2 {
    padding-right: 0.5rem !important; }
  .pb-sm-2,
  .py-sm-2 {
    padding-bottom: 0.5rem !important; }
  .pl-sm-2,
  .px-sm-2 {
    padding-left: 0.5rem !important; }
  .p-sm-3 {
    padding: 1rem !important; }
  .pt-sm-3,
  .py-sm-3 {
    padding-top: 1rem !important; }
  .pr-sm-3,
  .px-sm-3 {
    padding-right: 1rem !important; }
  .pb-sm-3,
  .py-sm-3 {
    padding-bottom: 1rem !important; }
  .pl-sm-3,
  .px-sm-3 {
    padding-left: 1rem !important; }
  .p-sm-4 {
    padding: 1.5rem !important; }
  .pt-sm-4,
  .py-sm-4 {
    padding-top: 1.5rem !important; }
  .pr-sm-4,
  .px-sm-4 {
    padding-right: 1.5rem !important; }
  .pb-sm-4,
  .py-sm-4 {
    padding-bottom: 1.5rem !important; }
  .pl-sm-4,
  .px-sm-4 {
    padding-left: 1.5rem !important; }
  .p-sm-5 {
    padding: 2rem !important; }
  .pt-sm-5,
  .py-sm-5 {
    padding-top: 2rem !important; }
  .pr-sm-5,
  .px-sm-5 {
    padding-right: 2rem !important; }
  .pb-sm-5,
  .py-sm-5 {
    padding-bottom: 2rem !important; }
  .pl-sm-5,
  .px-sm-5 {
    padding-left: 2rem !important; }
  .p-sm-6 {
    padding: 3rem !important; }
  .pt-sm-6,
  .py-sm-6 {
    padding-top: 3rem !important; }
  .pr-sm-6,
  .px-sm-6 {
    padding-right: 3rem !important; }
  .pb-sm-6,
  .py-sm-6 {
    padding-bottom: 3rem !important; }
  .pl-sm-6,
  .px-sm-6 {
    padding-left: 3rem !important; }
  .p-sm-7 {
    padding: 4rem !important; }
  .pt-sm-7,
  .py-sm-7 {
    padding-top: 4rem !important; }
  .pr-sm-7,
  .px-sm-7 {
    padding-right: 4rem !important; }
  .pb-sm-7,
  .py-sm-7 {
    padding-bottom: 4rem !important; }
  .pl-sm-7,
  .px-sm-7 {
    padding-left: 4rem !important; }
  .p-sm-8 {
    padding: 5rem !important; }
  .pt-sm-8,
  .py-sm-8 {
    padding-top: 5rem !important; }
  .pr-sm-8,
  .px-sm-8 {
    padding-right: 5rem !important; }
  .pb-sm-8,
  .py-sm-8 {
    padding-bottom: 5rem !important; }
  .pl-sm-8,
  .px-sm-8 {
    padding-left: 5rem !important; }
  .p-sm-9 {
    padding: 6rem !important; }
  .pt-sm-9,
  .py-sm-9 {
    padding-top: 6rem !important; }
  .pr-sm-9,
  .px-sm-9 {
    padding-right: 6rem !important; }
  .pb-sm-9,
  .py-sm-9 {
    padding-bottom: 6rem !important; }
  .pl-sm-9,
  .px-sm-9 {
    padding-left: 6rem !important; }
  .p-sm-10 {
    padding: 7rem !important; }
  .pt-sm-10,
  .py-sm-10 {
    padding-top: 7rem !important; }
  .pr-sm-10,
  .px-sm-10 {
    padding-right: 7rem !important; }
  .pb-sm-10,
  .py-sm-10 {
    padding-bottom: 7rem !important; }
  .pl-sm-10,
  .px-sm-10 {
    padding-left: 7rem !important; }
  .p-sm-11 {
    padding: 8rem !important; }
  .pt-sm-11,
  .py-sm-11 {
    padding-top: 8rem !important; }
  .pr-sm-11,
  .px-sm-11 {
    padding-right: 8rem !important; }
  .pb-sm-11,
  .py-sm-11 {
    padding-bottom: 8rem !important; }
  .pl-sm-11,
  .px-sm-11 {
    padding-left: 8rem !important; }
  .p-sm-12 {
    padding: 9rem !important; }
  .pt-sm-12,
  .py-sm-12 {
    padding-top: 9rem !important; }
  .pr-sm-12,
  .px-sm-12 {
    padding-right: 9rem !important; }
  .pb-sm-12,
  .py-sm-12 {
    padding-bottom: 9rem !important; }
  .pl-sm-12,
  .px-sm-12 {
    padding-left: 9rem !important; }
  .p-sm-13 {
    padding: 10rem !important; }
  .pt-sm-13,
  .py-sm-13 {
    padding-top: 10rem !important; }
  .pr-sm-13,
  .px-sm-13 {
    padding-right: 10rem !important; }
  .pb-sm-13,
  .py-sm-13 {
    padding-bottom: 10rem !important; }
  .pl-sm-13,
  .px-sm-13 {
    padding-left: 10rem !important; }
  .p-sm-15 {
    padding: 15rem !important; }
  .pt-sm-15,
  .py-sm-15 {
    padding-top: 15rem !important; }
  .pr-sm-15,
  .px-sm-15 {
    padding-right: 15rem !important; }
  .pb-sm-15,
  .py-sm-15 {
    padding-bottom: 15rem !important; }
  .pl-sm-15,
  .px-sm-15 {
    padding-left: 15rem !important; }
  .m-sm-auto {
    margin: auto !important; }
  .mt-sm-auto,
  .my-sm-auto {
    margin-top: auto !important; }
  .mr-sm-auto,
  .mx-sm-auto {
    margin-right: auto !important; }
  .mb-sm-auto,
  .my-sm-auto {
    margin-bottom: auto !important; }
  .ml-sm-auto,
  .mx-sm-auto {
    margin-left: auto !important; } }

@media (min-width: 768px) {
  .m-md-0 {
    margin: 0 !important; }
  .mt-md-0,
  .my-md-0 {
    margin-top: 0 !important; }
  .mr-md-0,
  .mx-md-0 {
    margin-right: 0 !important; }
  .mb-md-0,
  .my-md-0 {
    margin-bottom: 0 !important; }
  .ml-md-0,
  .mx-md-0 {
    margin-left: 0 !important; }
  .m-md-1 {
    margin: 0.25rem !important; }
  .mt-md-1,
  .my-md-1 {
    margin-top: 0.25rem !important; }
  .mr-md-1,
  .mx-md-1 {
    margin-right: 0.25rem !important; }
  .mb-md-1,
  .my-md-1 {
    margin-bottom: 0.25rem !important; }
  .ml-md-1,
  .mx-md-1 {
    margin-left: 0.25rem !important; }
  .m-md-2 {
    margin: 0.5rem !important; }
  .mt-md-2,
  .my-md-2 {
    margin-top: 0.5rem !important; }
  .mr-md-2,
  .mx-md-2 {
    margin-right: 0.5rem !important; }
  .mb-md-2,
  .my-md-2 {
    margin-bottom: 0.5rem !important; }
  .ml-md-2,
  .mx-md-2 {
    margin-left: 0.5rem !important; }
  .m-md-3 {
    margin: 1rem !important; }
  .mt-md-3,
  .my-md-3 {
    margin-top: 1rem !important; }
  .mr-md-3,
  .mx-md-3 {
    margin-right: 1rem !important; }
  .mb-md-3,
  .my-md-3 {
    margin-bottom: 1rem !important; }
  .ml-md-3,
  .mx-md-3 {
    margin-left: 1rem !important; }
  .m-md-4 {
    margin: 1.5rem !important; }
  .mt-md-4,
  .my-md-4 {
    margin-top: 1.5rem !important; }
  .mr-md-4,
  .mx-md-4 {
    margin-right: 1.5rem !important; }
  .mb-md-4,
  .my-md-4 {
    margin-bottom: 1.5rem !important; }
  .ml-md-4,
  .mx-md-4 {
    margin-left: 1.5rem !important; }
  .m-md-5 {
    margin: 2rem !important; }
  .mt-md-5,
  .my-md-5 {
    margin-top: 2rem !important; }
  .mr-md-5,
  .mx-md-5 {
    margin-right: 2rem !important; }
  .mb-md-5,
  .my-md-5 {
    margin-bottom: 2rem !important; }
  .ml-md-5,
  .mx-md-5 {
    margin-left: 2rem !important; }
  .m-md-6 {
    margin: 3rem !important; }
  .mt-md-6,
  .my-md-6 {
    margin-top: 3rem !important; }
  .mr-md-6,
  .mx-md-6 {
    margin-right: 3rem !important; }
  .mb-md-6,
  .my-md-6 {
    margin-bottom: 3rem !important; }
  .ml-md-6,
  .mx-md-6 {
    margin-left: 3rem !important; }
  .m-md-7 {
    margin: 4rem !important; }
  .mt-md-7,
  .my-md-7 {
    margin-top: 4rem !important; }
  .mr-md-7,
  .mx-md-7 {
    margin-right: 4rem !important; }
  .mb-md-7,
  .my-md-7 {
    margin-bottom: 4rem !important; }
  .ml-md-7,
  .mx-md-7 {
    margin-left: 4rem !important; }
  .m-md-8 {
    margin: 5rem !important; }
  .mt-md-8,
  .my-md-8 {
    margin-top: 5rem !important; }
  .mr-md-8,
  .mx-md-8 {
    margin-right: 5rem !important; }
  .mb-md-8,
  .my-md-8 {
    margin-bottom: 5rem !important; }
  .ml-md-8,
  .mx-md-8 {
    margin-left: 5rem !important; }
  .m-md-9 {
    margin: 6rem !important; }
  .mt-md-9,
  .my-md-9 {
    margin-top: 6rem !important; }
  .mr-md-9,
  .mx-md-9 {
    margin-right: 6rem !important; }
  .mb-md-9,
  .my-md-9 {
    margin-bottom: 6rem !important; }
  .ml-md-9,
  .mx-md-9 {
    margin-left: 6rem !important; }
  .m-md-10 {
    margin: 7rem !important; }
  .mt-md-10,
  .my-md-10 {
    margin-top: 7rem !important; }
  .mr-md-10,
  .mx-md-10 {
    margin-right: 7rem !important; }
  .mb-md-10,
  .my-md-10 {
    margin-bottom: 7rem !important; }
  .ml-md-10,
  .mx-md-10 {
    margin-left: 7rem !important; }
  .m-md-11 {
    margin: 8rem !important; }
  .mt-md-11,
  .my-md-11 {
    margin-top: 8rem !important; }
  .mr-md-11,
  .mx-md-11 {
    margin-right: 8rem !important; }
  .mb-md-11,
  .my-md-11 {
    margin-bottom: 8rem !important; }
  .ml-md-11,
  .mx-md-11 {
    margin-left: 8rem !important; }
  .m-md-12 {
    margin: 9rem !important; }
  .mt-md-12,
  .my-md-12 {
    margin-top: 9rem !important; }
  .mr-md-12,
  .mx-md-12 {
    margin-right: 9rem !important; }
  .mb-md-12,
  .my-md-12 {
    margin-bottom: 9rem !important; }
  .ml-md-12,
  .mx-md-12 {
    margin-left: 9rem !important; }
  .m-md-13 {
    margin: 10rem !important; }
  .mt-md-13,
  .my-md-13 {
    margin-top: 10rem !important; }
  .mr-md-13,
  .mx-md-13 {
    margin-right: 10rem !important; }
  .mb-md-13,
  .my-md-13 {
    margin-bottom: 10rem !important; }
  .ml-md-13,
  .mx-md-13 {
    margin-left: 10rem !important; }
  .m-md-15 {
    margin: 15rem !important; }
  .mt-md-15,
  .my-md-15 {
    margin-top: 15rem !important; }
  .mr-md-15,
  .mx-md-15 {
    margin-right: 15rem !important; }
  .mb-md-15,
  .my-md-15 {
    margin-bottom: 15rem !important; }
  .ml-md-15,
  .mx-md-15 {
    margin-left: 15rem !important; }
  .p-md-0 {
    padding: 0 !important; }
  .pt-md-0,
  .py-md-0 {
    padding-top: 0 !important; }
  .pr-md-0,
  .px-md-0 {
    padding-right: 0 !important; }
  .pb-md-0,
  .py-md-0 {
    padding-bottom: 0 !important; }
  .pl-md-0,
  .px-md-0 {
    padding-left: 0 !important; }
  .p-md-1 {
    padding: 0.25rem !important; }
  .pt-md-1,
  .py-md-1 {
    padding-top: 0.25rem !important; }
  .pr-md-1,
  .px-md-1 {
    padding-right: 0.25rem !important; }
  .pb-md-1,
  .py-md-1 {
    padding-bottom: 0.25rem !important; }
  .pl-md-1,
  .px-md-1 {
    padding-left: 0.25rem !important; }
  .p-md-2 {
    padding: 0.5rem !important; }
  .pt-md-2,
  .py-md-2 {
    padding-top: 0.5rem !important; }
  .pr-md-2,
  .px-md-2 {
    padding-right: 0.5rem !important; }
  .pb-md-2,
  .py-md-2 {
    padding-bottom: 0.5rem !important; }
  .pl-md-2,
  .px-md-2 {
    padding-left: 0.5rem !important; }
  .p-md-3 {
    padding: 1rem !important; }
  .pt-md-3,
  .py-md-3 {
    padding-top: 1rem !important; }
  .pr-md-3,
  .px-md-3 {
    padding-right: 1rem !important; }
  .pb-md-3,
  .py-md-3 {
    padding-bottom: 1rem !important; }
  .pl-md-3,
  .px-md-3 {
    padding-left: 1rem !important; }
  .p-md-4 {
    padding: 1.5rem !important; }
  .pt-md-4,
  .py-md-4 {
    padding-top: 1.5rem !important; }
  .pr-md-4,
  .px-md-4 {
    padding-right: 1.5rem !important; }
  .pb-md-4,
  .py-md-4 {
    padding-bottom: 1.5rem !important; }
  .pl-md-4,
  .px-md-4 {
    padding-left: 1.5rem !important; }
  .p-md-5 {
    padding: 2rem !important; }
  .pt-md-5,
  .py-md-5 {
    padding-top: 2rem !important; }
  .pr-md-5,
  .px-md-5 {
    padding-right: 2rem !important; }
  .pb-md-5,
  .py-md-5 {
    padding-bottom: 2rem !important; }
  .pl-md-5,
  .px-md-5 {
    padding-left: 2rem !important; }
  .p-md-6 {
    padding: 3rem !important; }
  .pt-md-6,
  .py-md-6 {
    padding-top: 3rem !important; }
  .pr-md-6,
  .px-md-6 {
    padding-right: 3rem !important; }
  .pb-md-6,
  .py-md-6 {
    padding-bottom: 3rem !important; }
  .pl-md-6,
  .px-md-6 {
    padding-left: 3rem !important; }
  .p-md-7 {
    padding: 4rem !important; }
  .pt-md-7,
  .py-md-7 {
    padding-top: 4rem !important; }
  .pr-md-7,
  .px-md-7 {
    padding-right: 4rem !important; }
  .pb-md-7,
  .py-md-7 {
    padding-bottom: 4rem !important; }
  .pl-md-7,
  .px-md-7 {
    padding-left: 4rem !important; }
  .p-md-8 {
    padding: 5rem !important; }
  .pt-md-8,
  .py-md-8 {
    padding-top: 5rem !important; }
  .pr-md-8,
  .px-md-8 {
    padding-right: 5rem !important; }
  .pb-md-8,
  .py-md-8 {
    padding-bottom: 5rem !important; }
  .pl-md-8,
  .px-md-8 {
    padding-left: 5rem !important; }
  .p-md-9 {
    padding: 6rem !important; }
  .pt-md-9,
  .py-md-9 {
    padding-top: 6rem !important; }
  .pr-md-9,
  .px-md-9 {
    padding-right: 6rem !important; }
  .pb-md-9,
  .py-md-9 {
    padding-bottom: 6rem !important; }
  .pl-md-9,
  .px-md-9 {
    padding-left: 6rem !important; }
  .p-md-10 {
    padding: 7rem !important; }
  .pt-md-10,
  .py-md-10 {
    padding-top: 7rem !important; }
  .pr-md-10,
  .px-md-10 {
    padding-right: 7rem !important; }
  .pb-md-10,
  .py-md-10 {
    padding-bottom: 7rem !important; }
  .pl-md-10,
  .px-md-10 {
    padding-left: 7rem !important; }
  .p-md-11 {
    padding: 8rem !important; }
  .pt-md-11,
  .py-md-11 {
    padding-top: 8rem !important; }
  .pr-md-11,
  .px-md-11 {
    padding-right: 8rem !important; }
  .pb-md-11,
  .py-md-11 {
    padding-bottom: 8rem !important; }
  .pl-md-11,
  .px-md-11 {
    padding-left: 8rem !important; }
  .p-md-12 {
    padding: 9rem !important; }
  .pt-md-12,
  .py-md-12 {
    padding-top: 9rem !important; }
  .pr-md-12,
  .px-md-12 {
    padding-right: 9rem !important; }
  .pb-md-12,
  .py-md-12 {
    padding-bottom: 9rem !important; }
  .pl-md-12,
  .px-md-12 {
    padding-left: 9rem !important; }
  .p-md-13 {
    padding: 10rem !important; }
  .pt-md-13,
  .py-md-13 {
    padding-top: 10rem !important; }
  .pr-md-13,
  .px-md-13 {
    padding-right: 10rem !important; }
  .pb-md-13,
  .py-md-13 {
    padding-bottom: 10rem !important; }
  .pl-md-13,
  .px-md-13 {
    padding-left: 10rem !important; }
  .p-md-15 {
    padding: 15rem !important; }
  .pt-md-15,
  .py-md-15 {
    padding-top: 15rem !important; }
  .pr-md-15,
  .px-md-15 {
    padding-right: 15rem !important; }
  .pb-md-15,
  .py-md-15 {
    padding-bottom: 15rem !important; }
  .pl-md-15,
  .px-md-15 {
    padding-left: 15rem !important; }
  .m-md-auto {
    margin: auto !important; }
  .mt-md-auto,
  .my-md-auto {
    margin-top: auto !important; }
  .mr-md-auto,
  .mx-md-auto {
    margin-right: auto !important; }
  .mb-md-auto,
  .my-md-auto {
    margin-bottom: auto !important; }
  .ml-md-auto,
  .mx-md-auto {
    margin-left: auto !important; } }

@media (min-width: 992px) {
  .m-lg-0 {
    margin: 0 !important; }
  .mt-lg-0,
  .my-lg-0 {
    margin-top: 0 !important; }
  .mr-lg-0,
  .mx-lg-0 {
    margin-right: 0 !important; }
  .mb-lg-0,
  .my-lg-0 {
    margin-bottom: 0 !important; }
  .ml-lg-0,
  .mx-lg-0 {
    margin-left: 0 !important; }
  .m-lg-1 {
    margin: 0.25rem !important; }
  .mt-lg-1,
  .my-lg-1 {
    margin-top: 0.25rem !important; }
  .mr-lg-1,
  .mx-lg-1 {
    margin-right: 0.25rem !important; }
  .mb-lg-1,
  .my-lg-1 {
    margin-bottom: 0.25rem !important; }
  .ml-lg-1,
  .mx-lg-1 {
    margin-left: 0.25rem !important; }
  .m-lg-2 {
    margin: 0.5rem !important; }
  .mt-lg-2,
  .my-lg-2 {
    margin-top: 0.5rem !important; }
  .mr-lg-2,
  .mx-lg-2 {
    margin-right: 0.5rem !important; }
  .mb-lg-2,
  .my-lg-2 {
    margin-bottom: 0.5rem !important; }
  .ml-lg-2,
  .mx-lg-2 {
    margin-left: 0.5rem !important; }
  .m-lg-3 {
    margin: 1rem !important; }
  .mt-lg-3,
  .my-lg-3 {
    margin-top: 1rem !important; }
  .mr-lg-3,
  .mx-lg-3 {
    margin-right: 1rem !important; }
  .mb-lg-3,
  .my-lg-3 {
    margin-bottom: 1rem !important; }
  .ml-lg-3,
  .mx-lg-3 {
    margin-left: 1rem !important; }
  .m-lg-4 {
    margin: 1.5rem !important; }
  .mt-lg-4,
  .my-lg-4 {
    margin-top: 1.5rem !important; }
  .mr-lg-4,
  .mx-lg-4 {
    margin-right: 1.5rem !important; }
  .mb-lg-4,
  .my-lg-4 {
    margin-bottom: 1.5rem !important; }
  .ml-lg-4,
  .mx-lg-4 {
    margin-left: 1.5rem !important; }
  .m-lg-5 {
    margin: 2rem !important; }
  .mt-lg-5,
  .my-lg-5 {
    margin-top: 2rem !important; }
  .mr-lg-5,
  .mx-lg-5 {
    margin-right: 2rem !important; }
  .mb-lg-5,
  .my-lg-5 {
    margin-bottom: 2rem !important; }
  .ml-lg-5,
  .mx-lg-5 {
    margin-left: 2rem !important; }
  .m-lg-6 {
    margin: 3rem !important; }
  .mt-lg-6,
  .my-lg-6 {
    margin-top: 3rem !important; }
  .mr-lg-6,
  .mx-lg-6 {
    margin-right: 3rem !important; }
  .mb-lg-6,
  .my-lg-6 {
    margin-bottom: 3rem !important; }
  .ml-lg-6,
  .mx-lg-6 {
    margin-left: 3rem !important; }
  .m-lg-7 {
    margin: 4rem !important; }
  .mt-lg-7,
  .my-lg-7 {
    margin-top: 4rem !important; }
  .mr-lg-7,
  .mx-lg-7 {
    margin-right: 4rem !important; }
  .mb-lg-7,
  .my-lg-7 {
    margin-bottom: 4rem !important; }
  .ml-lg-7,
  .mx-lg-7 {
    margin-left: 4rem !important; }
  .m-lg-8 {
    margin: 5rem !important; }
  .mt-lg-8,
  .my-lg-8 {
    margin-top: 5rem !important; }
  .mr-lg-8,
  .mx-lg-8 {
    margin-right: 5rem !important; }
  .mb-lg-8,
  .my-lg-8 {
    margin-bottom: 5rem !important; }
  .ml-lg-8,
  .mx-lg-8 {
    margin-left: 5rem !important; }
  .m-lg-9 {
    margin: 6rem !important; }
  .mt-lg-9,
  .my-lg-9 {
    margin-top: 6rem !important; }
  .mr-lg-9,
  .mx-lg-9 {
    margin-right: 6rem !important; }
  .mb-lg-9,
  .my-lg-9 {
    margin-bottom: 6rem !important; }
  .ml-lg-9,
  .mx-lg-9 {
    margin-left: 6rem !important; }
  .m-lg-10 {
    margin: 7rem !important; }
  .mt-lg-10,
  .my-lg-10 {
    margin-top: 7rem !important; }
  .mr-lg-10,
  .mx-lg-10 {
    margin-right: 7rem !important; }
  .mb-lg-10,
  .my-lg-10 {
    margin-bottom: 7rem !important; }
  .ml-lg-10,
  .mx-lg-10 {
    margin-left: 7rem !important; }
  .m-lg-11 {
    margin: 8rem !important; }
  .mt-lg-11,
  .my-lg-11 {
    margin-top: 8rem !important; }
  .mr-lg-11,
  .mx-lg-11 {
    margin-right: 8rem !important; }
  .mb-lg-11,
  .my-lg-11 {
    margin-bottom: 8rem !important; }
  .ml-lg-11,
  .mx-lg-11 {
    margin-left: 8rem !important; }
  .m-lg-12 {
    margin: 9rem !important; }
  .mt-lg-12,
  .my-lg-12 {
    margin-top: 9rem !important; }
  .mr-lg-12,
  .mx-lg-12 {
    margin-right: 9rem !important; }
  .mb-lg-12,
  .my-lg-12 {
    margin-bottom: 9rem !important; }
  .ml-lg-12,
  .mx-lg-12 {
    margin-left: 9rem !important; }
  .m-lg-13 {
    margin: 10rem !important; }
  .mt-lg-13,
  .my-lg-13 {
    margin-top: 10rem !important; }
  .mr-lg-13,
  .mx-lg-13 {
    margin-right: 10rem !important; }
  .mb-lg-13,
  .my-lg-13 {
    margin-bottom: 10rem !important; }
  .ml-lg-13,
  .mx-lg-13 {
    margin-left: 10rem !important; }
  .m-lg-15 {
    margin: 15rem !important; }
  .mt-lg-15,
  .my-lg-15 {
    margin-top: 15rem !important; }
  .mr-lg-15,
  .mx-lg-15 {
    margin-right: 15rem !important; }
  .mb-lg-15,
  .my-lg-15 {
    margin-bottom: 15rem !important; }
  .ml-lg-15,
  .mx-lg-15 {
    margin-left: 15rem !important; }
  .p-lg-0 {
    padding: 0 !important; }
  .pt-lg-0,
  .py-lg-0 {
    padding-top: 0 !important; }
  .pr-lg-0,
  .px-lg-0 {
    padding-right: 0 !important; }
  .pb-lg-0,
  .py-lg-0 {
    padding-bottom: 0 !important; }
  .pl-lg-0,
  .px-lg-0 {
    padding-left: 0 !important; }
  .p-lg-1 {
    padding: 0.25rem !important; }
  .pt-lg-1,
  .py-lg-1 {
    padding-top: 0.25rem !important; }
  .pr-lg-1,
  .px-lg-1 {
    padding-right: 0.25rem !important; }
  .pb-lg-1,
  .py-lg-1 {
    padding-bottom: 0.25rem !important; }
  .pl-lg-1,
  .px-lg-1 {
    padding-left: 0.25rem !important; }
  .p-lg-2 {
    padding: 0.5rem !important; }
  .pt-lg-2,
  .py-lg-2 {
    padding-top: 0.5rem !important; }
  .pr-lg-2,
  .px-lg-2 {
    padding-right: 0.5rem !important; }
  .pb-lg-2,
  .py-lg-2 {
    padding-bottom: 0.5rem !important; }
  .pl-lg-2,
  .px-lg-2 {
    padding-left: 0.5rem !important; }
  .p-lg-3 {
    padding: 1rem !important; }
  .pt-lg-3,
  .py-lg-3 {
    padding-top: 1rem !important; }
  .pr-lg-3,
  .px-lg-3 {
    padding-right: 1rem !important; }
  .pb-lg-3,
  .py-lg-3 {
    padding-bottom: 1rem !important; }
  .pl-lg-3,
  .px-lg-3 {
    padding-left: 1rem !important; }
  .p-lg-4 {
    padding: 1.5rem !important; }
  .pt-lg-4,
  .py-lg-4 {
    padding-top: 1.5rem !important; }
  .pr-lg-4,
  .px-lg-4 {
    padding-right: 1.5rem !important; }
  .pb-lg-4,
  .py-lg-4 {
    padding-bottom: 1.5rem !important; }
  .pl-lg-4,
  .px-lg-4 {
    padding-left: 1.5rem !important; }
  .p-lg-5 {
    padding: 2rem !important; }
  .pt-lg-5,
  .py-lg-5 {
    padding-top: 2rem !important; }
  .pr-lg-5,
  .px-lg-5 {
    padding-right: 2rem !important; }
  .pb-lg-5,
  .py-lg-5 {
    padding-bottom: 2rem !important; }
  .pl-lg-5,
  .px-lg-5 {
    padding-left: 2rem !important; }
  .p-lg-6 {
    padding: 3rem !important; }
  .pt-lg-6,
  .py-lg-6 {
    padding-top: 3rem !important; }
  .pr-lg-6,
  .px-lg-6 {
    padding-right: 3rem !important; }
  .pb-lg-6,
  .py-lg-6 {
    padding-bottom: 3rem !important; }
  .pl-lg-6,
  .px-lg-6 {
    padding-left: 3rem !important; }
  .p-lg-7 {
    padding: 4rem !important; }
  .pt-lg-7,
  .py-lg-7 {
    padding-top: 4rem !important; }
  .pr-lg-7,
  .px-lg-7 {
    padding-right: 4rem !important; }
  .pb-lg-7,
  .py-lg-7 {
    padding-bottom: 4rem !important; }
  .pl-lg-7,
  .px-lg-7 {
    padding-left: 4rem !important; }
  .p-lg-8 {
    padding: 5rem !important; }
  .pt-lg-8,
  .py-lg-8 {
    padding-top: 5rem !important; }
  .pr-lg-8,
  .px-lg-8 {
    padding-right: 5rem !important; }
  .pb-lg-8,
  .py-lg-8 {
    padding-bottom: 5rem !important; }
  .pl-lg-8,
  .px-lg-8 {
    padding-left: 5rem !important; }
  .p-lg-9 {
    padding: 6rem !important; }
  .pt-lg-9,
  .py-lg-9 {
    padding-top: 6rem !important; }
  .pr-lg-9,
  .px-lg-9 {
    padding-right: 6rem !important; }
  .pb-lg-9,
  .py-lg-9 {
    padding-bottom: 6rem !important; }
  .pl-lg-9,
  .px-lg-9 {
    padding-left: 6rem !important; }
  .p-lg-10 {
    padding: 7rem !important; }
  .pt-lg-10,
  .py-lg-10 {
    padding-top: 7rem !important; }
  .pr-lg-10,
  .px-lg-10 {
    padding-right: 7rem !important; }
  .pb-lg-10,
  .py-lg-10 {
    padding-bottom: 7rem !important; }
  .pl-lg-10,
  .px-lg-10 {
    padding-left: 7rem !important; }
  .p-lg-11 {
    padding: 8rem !important; }
  .pt-lg-11,
  .py-lg-11 {
    padding-top: 8rem !important; }
  .pr-lg-11,
  .px-lg-11 {
    padding-right: 8rem !important; }
  .pb-lg-11,
  .py-lg-11 {
    padding-bottom: 8rem !important; }
  .pl-lg-11,
  .px-lg-11 {
    padding-left: 8rem !important; }
  .p-lg-12 {
    padding: 9rem !important; }
  .pt-lg-12,
  .py-lg-12 {
    padding-top: 9rem !important; }
  .pr-lg-12,
  .px-lg-12 {
    padding-right: 9rem !important; }
  .pb-lg-12,
  .py-lg-12 {
    padding-bottom: 9rem !important; }
  .pl-lg-12,
  .px-lg-12 {
    padding-left: 9rem !important; }
  .p-lg-13 {
    padding: 10rem !important; }
  .pt-lg-13,
  .py-lg-13 {
    padding-top: 10rem !important; }
  .pr-lg-13,
  .px-lg-13 {
    padding-right: 10rem !important; }
  .pb-lg-13,
  .py-lg-13 {
    padding-bottom: 10rem !important; }
  .pl-lg-13,
  .px-lg-13 {
    padding-left: 10rem !important; }
  .p-lg-15 {
    padding: 15rem !important; }
  .pt-lg-15,
  .py-lg-15 {
    padding-top: 15rem !important; }
  .pr-lg-15,
  .px-lg-15 {
    padding-right: 15rem !important; }
  .pb-lg-15,
  .py-lg-15 {
    padding-bottom: 15rem !important; }
  .pl-lg-15,
  .px-lg-15 {
    padding-left: 15rem !important; }
  .m-lg-auto {
    margin: auto !important; }
  .mt-lg-auto,
  .my-lg-auto {
    margin-top: auto !important; }
  .mr-lg-auto,
  .mx-lg-auto {
    margin-right: auto !important; }
  .mb-lg-auto,
  .my-lg-auto {
    margin-bottom: auto !important; }
  .ml-lg-auto,
  .mx-lg-auto {
    margin-left: auto !important; } }

@media (min-width: 1200px) {
  .m-xl-0 {
    margin: 0 !important; }
  .mt-xl-0,
  .my-xl-0 {
    margin-top: 0 !important; }
  .mr-xl-0,
  .mx-xl-0 {
    margin-right: 0 !important; }
  .mb-xl-0,
  .my-xl-0 {
    margin-bottom: 0 !important; }
  .ml-xl-0,
  .mx-xl-0 {
    margin-left: 0 !important; }
  .m-xl-1 {
    margin: 0.25rem !important; }
  .mt-xl-1,
  .my-xl-1 {
    margin-top: 0.25rem !important; }
  .mr-xl-1,
  .mx-xl-1 {
    margin-right: 0.25rem !important; }
  .mb-xl-1,
  .my-xl-1 {
    margin-bottom: 0.25rem !important; }
  .ml-xl-1,
  .mx-xl-1 {
    margin-left: 0.25rem !important; }
  .m-xl-2 {
    margin: 0.5rem !important; }
  .mt-xl-2,
  .my-xl-2 {
    margin-top: 0.5rem !important; }
  .mr-xl-2,
  .mx-xl-2 {
    margin-right: 0.5rem !important; }
  .mb-xl-2,
  .my-xl-2 {
    margin-bottom: 0.5rem !important; }
  .ml-xl-2,
  .mx-xl-2 {
    margin-left: 0.5rem !important; }
  .m-xl-3 {
    margin: 1rem !important; }
  .mt-xl-3,
  .my-xl-3 {
    margin-top: 1rem !important; }
  .mr-xl-3,
  .mx-xl-3 {
    margin-right: 1rem !important; }
  .mb-xl-3,
  .my-xl-3 {
    margin-bottom: 1rem !important; }
  .ml-xl-3,
  .mx-xl-3 {
    margin-left: 1rem !important; }
  .m-xl-4 {
    margin: 1.5rem !important; }
  .mt-xl-4,
  .my-xl-4 {
    margin-top: 1.5rem !important; }
  .mr-xl-4,
  .mx-xl-4 {
    margin-right: 1.5rem !important; }
  .mb-xl-4,
  .my-xl-4 {
    margin-bottom: 1.5rem !important; }
  .ml-xl-4,
  .mx-xl-4 {
    margin-left: 1.5rem !important; }
  .m-xl-5 {
    margin: 2rem !important; }
  .mt-xl-5,
  .my-xl-5 {
    margin-top: 2rem !important; }
  .mr-xl-5,
  .mx-xl-5 {
    margin-right: 2rem !important; }
  .mb-xl-5,
  .my-xl-5 {
    margin-bottom: 2rem !important; }
  .ml-xl-5,
  .mx-xl-5 {
    margin-left: 2rem !important; }
  .m-xl-6 {
    margin: 3rem !important; }
  .mt-xl-6,
  .my-xl-6 {
    margin-top: 3rem !important; }
  .mr-xl-6,
  .mx-xl-6 {
    margin-right: 3rem !important; }
  .mb-xl-6,
  .my-xl-6 {
    margin-bottom: 3rem !important; }
  .ml-xl-6,
  .mx-xl-6 {
    margin-left: 3rem !important; }
  .m-xl-7 {
    margin: 4rem !important; }
  .mt-xl-7,
  .my-xl-7 {
    margin-top: 4rem !important; }
  .mr-xl-7,
  .mx-xl-7 {
    margin-right: 4rem !important; }
  .mb-xl-7,
  .my-xl-7 {
    margin-bottom: 4rem !important; }
  .ml-xl-7,
  .mx-xl-7 {
    margin-left: 4rem !important; }
  .m-xl-8 {
    margin: 5rem !important; }
  .mt-xl-8,
  .my-xl-8 {
    margin-top: 5rem !important; }
  .mr-xl-8,
  .mx-xl-8 {
    margin-right: 5rem !important; }
  .mb-xl-8,
  .my-xl-8 {
    margin-bottom: 5rem !important; }
  .ml-xl-8,
  .mx-xl-8 {
    margin-left: 5rem !important; }
  .m-xl-9 {
    margin: 6rem !important; }
  .mt-xl-9,
  .my-xl-9 {
    margin-top: 6rem !important; }
  .mr-xl-9,
  .mx-xl-9 {
    margin-right: 6rem !important; }
  .mb-xl-9,
  .my-xl-9 {
    margin-bottom: 6rem !important; }
  .ml-xl-9,
  .mx-xl-9 {
    margin-left: 6rem !important; }
  .m-xl-10 {
    margin: 7rem !important; }
  .mt-xl-10,
  .my-xl-10 {
    margin-top: 7rem !important; }
  .mr-xl-10,
  .mx-xl-10 {
    margin-right: 7rem !important; }
  .mb-xl-10,
  .my-xl-10 {
    margin-bottom: 7rem !important; }
  .ml-xl-10,
  .mx-xl-10 {
    margin-left: 7rem !important; }
  .m-xl-11 {
    margin: 8rem !important; }
  .mt-xl-11,
  .my-xl-11 {
    margin-top: 8rem !important; }
  .mr-xl-11,
  .mx-xl-11 {
    margin-right: 8rem !important; }
  .mb-xl-11,
  .my-xl-11 {
    margin-bottom: 8rem !important; }
  .ml-xl-11,
  .mx-xl-11 {
    margin-left: 8rem !important; }
  .m-xl-12 {
    margin: 9rem !important; }
  .mt-xl-12,
  .my-xl-12 {
    margin-top: 9rem !important; }
  .mr-xl-12,
  .mx-xl-12 {
    margin-right: 9rem !important; }
  .mb-xl-12,
  .my-xl-12 {
    margin-bottom: 9rem !important; }
  .ml-xl-12,
  .mx-xl-12 {
    margin-left: 9rem !important; }
  .m-xl-13 {
    margin: 10rem !important; }
  .mt-xl-13,
  .my-xl-13 {
    margin-top: 10rem !important; }
  .mr-xl-13,
  .mx-xl-13 {
    margin-right: 10rem !important; }
  .mb-xl-13,
  .my-xl-13 {
    margin-bottom: 10rem !important; }
  .ml-xl-13,
  .mx-xl-13 {
    margin-left: 10rem !important; }
  .m-xl-15 {
    margin: 15rem !important; }
  .mt-xl-15,
  .my-xl-15 {
    margin-top: 15rem !important; }
  .mr-xl-15,
  .mx-xl-15 {
    margin-right: 15rem !important; }
  .mb-xl-15,
  .my-xl-15 {
    margin-bottom: 15rem !important; }
  .ml-xl-15,
  .mx-xl-15 {
    margin-left: 15rem !important; }
  .p-xl-0 {
    padding: 0 !important; }
  .pt-xl-0,
  .py-xl-0 {
    padding-top: 0 !important; }
  .pr-xl-0,
  .px-xl-0 {
    padding-right: 0 !important; }
  .pb-xl-0,
  .py-xl-0 {
    padding-bottom: 0 !important; }
  .pl-xl-0,
  .px-xl-0 {
    padding-left: 0 !important; }
  .p-xl-1 {
    padding: 0.25rem !important; }
  .pt-xl-1,
  .py-xl-1 {
    padding-top: 0.25rem !important; }
  .pr-xl-1,
  .px-xl-1 {
    padding-right: 0.25rem !important; }
  .pb-xl-1,
  .py-xl-1 {
    padding-bottom: 0.25rem !important; }
  .pl-xl-1,
  .px-xl-1 {
    padding-left: 0.25rem !important; }
  .p-xl-2 {
    padding: 0.5rem !important; }
  .pt-xl-2,
  .py-xl-2 {
    padding-top: 0.5rem !important; }
  .pr-xl-2,
  .px-xl-2 {
    padding-right: 0.5rem !important; }
  .pb-xl-2,
  .py-xl-2 {
    padding-bottom: 0.5rem !important; }
  .pl-xl-2,
  .px-xl-2 {
    padding-left: 0.5rem !important; }
  .p-xl-3 {
    padding: 1rem !important; }
  .pt-xl-3,
  .py-xl-3 {
    padding-top: 1rem !important; }
  .pr-xl-3,
  .px-xl-3 {
    padding-right: 1rem !important; }
  .pb-xl-3,
  .py-xl-3 {
    padding-bottom: 1rem !important; }
  .pl-xl-3,
  .px-xl-3 {
    padding-left: 1rem !important; }
  .p-xl-4 {
    padding: 1.5rem !important; }
  .pt-xl-4,
  .py-xl-4 {
    padding-top: 1.5rem !important; }
  .pr-xl-4,
  .px-xl-4 {
    padding-right: 1.5rem !important; }
  .pb-xl-4,
  .py-xl-4 {
    padding-bottom: 1.5rem !important; }
  .pl-xl-4,
  .px-xl-4 {
    padding-left: 1.5rem !important; }
  .p-xl-5 {
    padding: 2rem !important; }
  .pt-xl-5,
  .py-xl-5 {
    padding-top: 2rem !important; }
  .pr-xl-5,
  .px-xl-5 {
    padding-right: 2rem !important; }
  .pb-xl-5,
  .py-xl-5 {
    padding-bottom: 2rem !important; }
  .pl-xl-5,
  .px-xl-5 {
    padding-left: 2rem !important; }
  .p-xl-6 {
    padding: 3rem !important; }
  .pt-xl-6,
  .py-xl-6 {
    padding-top: 3rem !important; }
  .pr-xl-6,
  .px-xl-6 {
    padding-right: 3rem !important; }
  .pb-xl-6,
  .py-xl-6 {
    padding-bottom: 3rem !important; }
  .pl-xl-6,
  .px-xl-6 {
    padding-left: 3rem !important; }
  .p-xl-7 {
    padding: 4rem !important; }
  .pt-xl-7,
  .py-xl-7 {
    padding-top: 4rem !important; }
  .pr-xl-7,
  .px-xl-7 {
    padding-right: 4rem !important; }
  .pb-xl-7,
  .py-xl-7 {
    padding-bottom: 4rem !important; }
  .pl-xl-7,
  .px-xl-7 {
    padding-left: 4rem !important; }
  .p-xl-8 {
    padding: 5rem !important; }
  .pt-xl-8,
  .py-xl-8 {
    padding-top: 5rem !important; }
  .pr-xl-8,
  .px-xl-8 {
    padding-right: 5rem !important; }
  .pb-xl-8,
  .py-xl-8 {
    padding-bottom: 5rem !important; }
  .pl-xl-8,
  .px-xl-8 {
    padding-left: 5rem !important; }
  .p-xl-9 {
    padding: 6rem !important; }
  .pt-xl-9,
  .py-xl-9 {
    padding-top: 6rem !important; }
  .pr-xl-9,
  .px-xl-9 {
    padding-right: 6rem !important; }
  .pb-xl-9,
  .py-xl-9 {
    padding-bottom: 6rem !important; }
  .pl-xl-9,
  .px-xl-9 {
    padding-left: 6rem !important; }
  .p-xl-10 {
    padding: 7rem !important; }
  .pt-xl-10,
  .py-xl-10 {
    padding-top: 7rem !important; }
  .pr-xl-10,
  .px-xl-10 {
    padding-right: 7rem !important; }
  .pb-xl-10,
  .py-xl-10 {
    padding-bottom: 7rem !important; }
  .pl-xl-10,
  .px-xl-10 {
    padding-left: 7rem !important; }
  .p-xl-11 {
    padding: 8rem !important; }
  .pt-xl-11,
  .py-xl-11 {
    padding-top: 8rem !important; }
  .pr-xl-11,
  .px-xl-11 {
    padding-right: 8rem !important; }
  .pb-xl-11,
  .py-xl-11 {
    padding-bottom: 8rem !important; }
  .pl-xl-11,
  .px-xl-11 {
    padding-left: 8rem !important; }
  .p-xl-12 {
    padding: 9rem !important; }
  .pt-xl-12,
  .py-xl-12 {
    padding-top: 9rem !important; }
  .pr-xl-12,
  .px-xl-12 {
    padding-right: 9rem !important; }
  .pb-xl-12,
  .py-xl-12 {
    padding-bottom: 9rem !important; }
  .pl-xl-12,
  .px-xl-12 {
    padding-left: 9rem !important; }
  .p-xl-13 {
    padding: 10rem !important; }
  .pt-xl-13,
  .py-xl-13 {
    padding-top: 10rem !important; }
  .pr-xl-13,
  .px-xl-13 {
    padding-right: 10rem !important; }
  .pb-xl-13,
  .py-xl-13 {
    padding-bottom: 10rem !important; }
  .pl-xl-13,
  .px-xl-13 {
    padding-left: 10rem !important; }
  .p-xl-15 {
    padding: 15rem !important; }
  .pt-xl-15,
  .py-xl-15 {
    padding-top: 15rem !important; }
  .pr-xl-15,
  .px-xl-15 {
    padding-right: 15rem !important; }
  .pb-xl-15,
  .py-xl-15 {
    padding-bottom: 15rem !important; }
  .pl-xl-15,
  .px-xl-15 {
    padding-left: 15rem !important; }
  .m-xl-auto {
    margin: auto !important; }
  .mt-xl-auto,
  .my-xl-auto {
    margin-top: auto !important; }
  .mr-xl-auto,
  .mx-xl-auto {
    margin-right: auto !important; }
  .mb-xl-auto,
  .my-xl-auto {
    margin-bottom: auto !important; }
  .ml-xl-auto,
  .mx-xl-auto {
    margin-left: auto !important; } }

@media (min-width: 1400px) {
  .m-xxl-0 {
    margin: 0 !important; }
  .mt-xxl-0,
  .my-xxl-0 {
    margin-top: 0 !important; }
  .mr-xxl-0,
  .mx-xxl-0 {
    margin-right: 0 !important; }
  .mb-xxl-0,
  .my-xxl-0 {
    margin-bottom: 0 !important; }
  .ml-xxl-0,
  .mx-xxl-0 {
    margin-left: 0 !important; }
  .m-xxl-1 {
    margin: 0.25rem !important; }
  .mt-xxl-1,
  .my-xxl-1 {
    margin-top: 0.25rem !important; }
  .mr-xxl-1,
  .mx-xxl-1 {
    margin-right: 0.25rem !important; }
  .mb-xxl-1,
  .my-xxl-1 {
    margin-bottom: 0.25rem !important; }
  .ml-xxl-1,
  .mx-xxl-1 {
    margin-left: 0.25rem !important; }
  .m-xxl-2 {
    margin: 0.5rem !important; }
  .mt-xxl-2,
  .my-xxl-2 {
    margin-top: 0.5rem !important; }
  .mr-xxl-2,
  .mx-xxl-2 {
    margin-right: 0.5rem !important; }
  .mb-xxl-2,
  .my-xxl-2 {
    margin-bottom: 0.5rem !important; }
  .ml-xxl-2,
  .mx-xxl-2 {
    margin-left: 0.5rem !important; }
  .m-xxl-3 {
    margin: 1rem !important; }
  .mt-xxl-3,
  .my-xxl-3 {
    margin-top: 1rem !important; }
  .mr-xxl-3,
  .mx-xxl-3 {
    margin-right: 1rem !important; }
  .mb-xxl-3,
  .my-xxl-3 {
    margin-bottom: 1rem !important; }
  .ml-xxl-3,
  .mx-xxl-3 {
    margin-left: 1rem !important; }
  .m-xxl-4 {
    margin: 1.5rem !important; }
  .mt-xxl-4,
  .my-xxl-4 {
    margin-top: 1.5rem !important; }
  .mr-xxl-4,
  .mx-xxl-4 {
    margin-right: 1.5rem !important; }
  .mb-xxl-4,
  .my-xxl-4 {
    margin-bottom: 1.5rem !important; }
  .ml-xxl-4,
  .mx-xxl-4 {
    margin-left: 1.5rem !important; }
  .m-xxl-5 {
    margin: 2rem !important; }
  .mt-xxl-5,
  .my-xxl-5 {
    margin-top: 2rem !important; }
  .mr-xxl-5,
  .mx-xxl-5 {
    margin-right: 2rem !important; }
  .mb-xxl-5,
  .my-xxl-5 {
    margin-bottom: 2rem !important; }
  .ml-xxl-5,
  .mx-xxl-5 {
    margin-left: 2rem !important; }
  .m-xxl-6 {
    margin: 3rem !important; }
  .mt-xxl-6,
  .my-xxl-6 {
    margin-top: 3rem !important; }
  .mr-xxl-6,
  .mx-xxl-6 {
    margin-right: 3rem !important; }
  .mb-xxl-6,
  .my-xxl-6 {
    margin-bottom: 3rem !important; }
  .ml-xxl-6,
  .mx-xxl-6 {
    margin-left: 3rem !important; }
  .m-xxl-7 {
    margin: 4rem !important; }
  .mt-xxl-7,
  .my-xxl-7 {
    margin-top: 4rem !important; }
  .mr-xxl-7,
  .mx-xxl-7 {
    margin-right: 4rem !important; }
  .mb-xxl-7,
  .my-xxl-7 {
    margin-bottom: 4rem !important; }
  .ml-xxl-7,
  .mx-xxl-7 {
    margin-left: 4rem !important; }
  .m-xxl-8 {
    margin: 5rem !important; }
  .mt-xxl-8,
  .my-xxl-8 {
    margin-top: 5rem !important; }
  .mr-xxl-8,
  .mx-xxl-8 {
    margin-right: 5rem !important; }
  .mb-xxl-8,
  .my-xxl-8 {
    margin-bottom: 5rem !important; }
  .ml-xxl-8,
  .mx-xxl-8 {
    margin-left: 5rem !important; }
  .m-xxl-9 {
    margin: 6rem !important; }
  .mt-xxl-9,
  .my-xxl-9 {
    margin-top: 6rem !important; }
  .mr-xxl-9,
  .mx-xxl-9 {
    margin-right: 6rem !important; }
  .mb-xxl-9,
  .my-xxl-9 {
    margin-bottom: 6rem !important; }
  .ml-xxl-9,
  .mx-xxl-9 {
    margin-left: 6rem !important; }
  .m-xxl-10 {
    margin: 7rem !important; }
  .mt-xxl-10,
  .my-xxl-10 {
    margin-top: 7rem !important; }
  .mr-xxl-10,
  .mx-xxl-10 {
    margin-right: 7rem !important; }
  .mb-xxl-10,
  .my-xxl-10 {
    margin-bottom: 7rem !important; }
  .ml-xxl-10,
  .mx-xxl-10 {
    margin-left: 7rem !important; }
  .m-xxl-11 {
    margin: 8rem !important; }
  .mt-xxl-11,
  .my-xxl-11 {
    margin-top: 8rem !important; }
  .mr-xxl-11,
  .mx-xxl-11 {
    margin-right: 8rem !important; }
  .mb-xxl-11,
  .my-xxl-11 {
    margin-bottom: 8rem !important; }
  .ml-xxl-11,
  .mx-xxl-11 {
    margin-left: 8rem !important; }
  .m-xxl-12 {
    margin: 9rem !important; }
  .mt-xxl-12,
  .my-xxl-12 {
    margin-top: 9rem !important; }
  .mr-xxl-12,
  .mx-xxl-12 {
    margin-right: 9rem !important; }
  .mb-xxl-12,
  .my-xxl-12 {
    margin-bottom: 9rem !important; }
  .ml-xxl-12,
  .mx-xxl-12 {
    margin-left: 9rem !important; }
  .m-xxl-13 {
    margin: 10rem !important; }
  .mt-xxl-13,
  .my-xxl-13 {
    margin-top: 10rem !important; }
  .mr-xxl-13,
  .mx-xxl-13 {
    margin-right: 10rem !important; }
  .mb-xxl-13,
  .my-xxl-13 {
    margin-bottom: 10rem !important; }
  .ml-xxl-13,
  .mx-xxl-13 {
    margin-left: 10rem !important; }
  .m-xxl-15 {
    margin: 15rem !important; }
  .mt-xxl-15,
  .my-xxl-15 {
    margin-top: 15rem !important; }
  .mr-xxl-15,
  .mx-xxl-15 {
    margin-right: 15rem !important; }
  .mb-xxl-15,
  .my-xxl-15 {
    margin-bottom: 15rem !important; }
  .ml-xxl-15,
  .mx-xxl-15 {
    margin-left: 15rem !important; }
  .p-xxl-0 {
    padding: 0 !important; }
  .pt-xxl-0,
  .py-xxl-0 {
    padding-top: 0 !important; }
  .pr-xxl-0,
  .px-xxl-0 {
    padding-right: 0 !important; }
  .pb-xxl-0,
  .py-xxl-0 {
    padding-bottom: 0 !important; }
  .pl-xxl-0,
  .px-xxl-0 {
    padding-left: 0 !important; }
  .p-xxl-1 {
    padding: 0.25rem !important; }
  .pt-xxl-1,
  .py-xxl-1 {
    padding-top: 0.25rem !important; }
  .pr-xxl-1,
  .px-xxl-1 {
    padding-right: 0.25rem !important; }
  .pb-xxl-1,
  .py-xxl-1 {
    padding-bottom: 0.25rem !important; }
  .pl-xxl-1,
  .px-xxl-1 {
    padding-left: 0.25rem !important; }
  .p-xxl-2 {
    padding: 0.5rem !important; }
  .pt-xxl-2,
  .py-xxl-2 {
    padding-top: 0.5rem !important; }
  .pr-xxl-2,
  .px-xxl-2 {
    padding-right: 0.5rem !important; }
  .pb-xxl-2,
  .py-xxl-2 {
    padding-bottom: 0.5rem !important; }
  .pl-xxl-2,
  .px-xxl-2 {
    padding-left: 0.5rem !important; }
  .p-xxl-3 {
    padding: 1rem !important; }
  .pt-xxl-3,
  .py-xxl-3 {
    padding-top: 1rem !important; }
  .pr-xxl-3,
  .px-xxl-3 {
    padding-right: 1rem !important; }
  .pb-xxl-3,
  .py-xxl-3 {
    padding-bottom: 1rem !important; }
  .pl-xxl-3,
  .px-xxl-3 {
    padding-left: 1rem !important; }
  .p-xxl-4 {
    padding: 1.5rem !important; }
  .pt-xxl-4,
  .py-xxl-4 {
    padding-top: 1.5rem !important; }
  .pr-xxl-4,
  .px-xxl-4 {
    padding-right: 1.5rem !important; }
  .pb-xxl-4,
  .py-xxl-4 {
    padding-bottom: 1.5rem !important; }
  .pl-xxl-4,
  .px-xxl-4 {
    padding-left: 1.5rem !important; }
  .p-xxl-5 {
    padding: 2rem !important; }
  .pt-xxl-5,
  .py-xxl-5 {
    padding-top: 2rem !important; }
  .pr-xxl-5,
  .px-xxl-5 {
    padding-right: 2rem !important; }
  .pb-xxl-5,
  .py-xxl-5 {
    padding-bottom: 2rem !important; }
  .pl-xxl-5,
  .px-xxl-5 {
    padding-left: 2rem !important; }
  .p-xxl-6 {
    padding: 3rem !important; }
  .pt-xxl-6,
  .py-xxl-6 {
    padding-top: 3rem !important; }
  .pr-xxl-6,
  .px-xxl-6 {
    padding-right: 3rem !important; }
  .pb-xxl-6,
  .py-xxl-6 {
    padding-bottom: 3rem !important; }
  .pl-xxl-6,
  .px-xxl-6 {
    padding-left: 3rem !important; }
  .p-xxl-7 {
    padding: 4rem !important; }
  .pt-xxl-7,
  .py-xxl-7 {
    padding-top: 4rem !important; }
  .pr-xxl-7,
  .px-xxl-7 {
    padding-right: 4rem !important; }
  .pb-xxl-7,
  .py-xxl-7 {
    padding-bottom: 4rem !important; }
  .pl-xxl-7,
  .px-xxl-7 {
    padding-left: 4rem !important; }
  .p-xxl-8 {
    padding: 5rem !important; }
  .pt-xxl-8,
  .py-xxl-8 {
    padding-top: 5rem !important; }
  .pr-xxl-8,
  .px-xxl-8 {
    padding-right: 5rem !important; }
  .pb-xxl-8,
  .py-xxl-8 {
    padding-bottom: 5rem !important; }
  .pl-xxl-8,
  .px-xxl-8 {
    padding-left: 5rem !important; }
  .p-xxl-9 {
    padding: 6rem !important; }
  .pt-xxl-9,
  .py-xxl-9 {
    padding-top: 6rem !important; }
  .pr-xxl-9,
  .px-xxl-9 {
    padding-right: 6rem !important; }
  .pb-xxl-9,
  .py-xxl-9 {
    padding-bottom: 6rem !important; }
  .pl-xxl-9,
  .px-xxl-9 {
    padding-left: 6rem !important; }
  .p-xxl-10 {
    padding: 7rem !important; }
  .pt-xxl-10,
  .py-xxl-10 {
    padding-top: 7rem !important; }
  .pr-xxl-10,
  .px-xxl-10 {
    padding-right: 7rem !important; }
  .pb-xxl-10,
  .py-xxl-10 {
    padding-bottom: 7rem !important; }
  .pl-xxl-10,
  .px-xxl-10 {
    padding-left: 7rem !important; }
  .p-xxl-11 {
    padding: 8rem !important; }
  .pt-xxl-11,
  .py-xxl-11 {
    padding-top: 8rem !important; }
  .pr-xxl-11,
  .px-xxl-11 {
    padding-right: 8rem !important; }
  .pb-xxl-11,
  .py-xxl-11 {
    padding-bottom: 8rem !important; }
  .pl-xxl-11,
  .px-xxl-11 {
    padding-left: 8rem !important; }
  .p-xxl-12 {
    padding: 9rem !important; }
  .pt-xxl-12,
  .py-xxl-12 {
    padding-top: 9rem !important; }
  .pr-xxl-12,
  .px-xxl-12 {
    padding-right: 9rem !important; }
  .pb-xxl-12,
  .py-xxl-12 {
    padding-bottom: 9rem !important; }
  .pl-xxl-12,
  .px-xxl-12 {
    padding-left: 9rem !important; }
  .p-xxl-13 {
    padding: 10rem !important; }
  .pt-xxl-13,
  .py-xxl-13 {
    padding-top: 10rem !important; }
  .pr-xxl-13,
  .px-xxl-13 {
    padding-right: 10rem !important; }
  .pb-xxl-13,
  .py-xxl-13 {
    padding-bottom: 10rem !important; }
  .pl-xxl-13,
  .px-xxl-13 {
    padding-left: 10rem !important; }
  .p-xxl-15 {
    padding: 15rem !important; }
  .pt-xxl-15,
  .py-xxl-15 {
    padding-top: 15rem !important; }
  .pr-xxl-15,
  .px-xxl-15 {
    padding-right: 15rem !important; }
  .pb-xxl-15,
  .py-xxl-15 {
    padding-bottom: 15rem !important; }
  .pl-xxl-15,
  .px-xxl-15 {
    padding-left: 15rem !important; }
  .m-xxl-auto {
    margin: auto !important; }
  .mt-xxl-auto,
  .my-xxl-auto {
    margin-top: auto !important; }
  .mr-xxl-auto,
  .mx-xxl-auto {
    margin-right: auto !important; }
  .mb-xxl-auto,
  .my-xxl-auto {
    margin-bottom: auto !important; }
  .ml-xxl-auto,
  .mx-xxl-auto {
    margin-left: auto !important; } }

@media (min-width: 1600px) {
  .m-xxxl-0 {
    margin: 0 !important; }
  .mt-xxxl-0,
  .my-xxxl-0 {
    margin-top: 0 !important; }
  .mr-xxxl-0,
  .mx-xxxl-0 {
    margin-right: 0 !important; }
  .mb-xxxl-0,
  .my-xxxl-0 {
    margin-bottom: 0 !important; }
  .ml-xxxl-0,
  .mx-xxxl-0 {
    margin-left: 0 !important; }
  .m-xxxl-1 {
    margin: 0.25rem !important; }
  .mt-xxxl-1,
  .my-xxxl-1 {
    margin-top: 0.25rem !important; }
  .mr-xxxl-1,
  .mx-xxxl-1 {
    margin-right: 0.25rem !important; }
  .mb-xxxl-1,
  .my-xxxl-1 {
    margin-bottom: 0.25rem !important; }
  .ml-xxxl-1,
  .mx-xxxl-1 {
    margin-left: 0.25rem !important; }
  .m-xxxl-2 {
    margin: 0.5rem !important; }
  .mt-xxxl-2,
  .my-xxxl-2 {
    margin-top: 0.5rem !important; }
  .mr-xxxl-2,
  .mx-xxxl-2 {
    margin-right: 0.5rem !important; }
  .mb-xxxl-2,
  .my-xxxl-2 {
    margin-bottom: 0.5rem !important; }
  .ml-xxxl-2,
  .mx-xxxl-2 {
    margin-left: 0.5rem !important; }
  .m-xxxl-3 {
    margin: 1rem !important; }
  .mt-xxxl-3,
  .my-xxxl-3 {
    margin-top: 1rem !important; }
  .mr-xxxl-3,
  .mx-xxxl-3 {
    margin-right: 1rem !important; }
  .mb-xxxl-3,
  .my-xxxl-3 {
    margin-bottom: 1rem !important; }
  .ml-xxxl-3,
  .mx-xxxl-3 {
    margin-left: 1rem !important; }
  .m-xxxl-4 {
    margin: 1.5rem !important; }
  .mt-xxxl-4,
  .my-xxxl-4 {
    margin-top: 1.5rem !important; }
  .mr-xxxl-4,
  .mx-xxxl-4 {
    margin-right: 1.5rem !important; }
  .mb-xxxl-4,
  .my-xxxl-4 {
    margin-bottom: 1.5rem !important; }
  .ml-xxxl-4,
  .mx-xxxl-4 {
    margin-left: 1.5rem !important; }
  .m-xxxl-5 {
    margin: 2rem !important; }
  .mt-xxxl-5,
  .my-xxxl-5 {
    margin-top: 2rem !important; }
  .mr-xxxl-5,
  .mx-xxxl-5 {
    margin-right: 2rem !important; }
  .mb-xxxl-5,
  .my-xxxl-5 {
    margin-bottom: 2rem !important; }
  .ml-xxxl-5,
  .mx-xxxl-5 {
    margin-left: 2rem !important; }
  .m-xxxl-6 {
    margin: 3rem !important; }
  .mt-xxxl-6,
  .my-xxxl-6 {
    margin-top: 3rem !important; }
  .mr-xxxl-6,
  .mx-xxxl-6 {
    margin-right: 3rem !important; }
  .mb-xxxl-6,
  .my-xxxl-6 {
    margin-bottom: 3rem !important; }
  .ml-xxxl-6,
  .mx-xxxl-6 {
    margin-left: 3rem !important; }
  .m-xxxl-7 {
    margin: 4rem !important; }
  .mt-xxxl-7,
  .my-xxxl-7 {
    margin-top: 4rem !important; }
  .mr-xxxl-7,
  .mx-xxxl-7 {
    margin-right: 4rem !important; }
  .mb-xxxl-7,
  .my-xxxl-7 {
    margin-bottom: 4rem !important; }
  .ml-xxxl-7,
  .mx-xxxl-7 {
    margin-left: 4rem !important; }
  .m-xxxl-8 {
    margin: 5rem !important; }
  .mt-xxxl-8,
  .my-xxxl-8 {
    margin-top: 5rem !important; }
  .mr-xxxl-8,
  .mx-xxxl-8 {
    margin-right: 5rem !important; }
  .mb-xxxl-8,
  .my-xxxl-8 {
    margin-bottom: 5rem !important; }
  .ml-xxxl-8,
  .mx-xxxl-8 {
    margin-left: 5rem !important; }
  .m-xxxl-9 {
    margin: 6rem !important; }
  .mt-xxxl-9,
  .my-xxxl-9 {
    margin-top: 6rem !important; }
  .mr-xxxl-9,
  .mx-xxxl-9 {
    margin-right: 6rem !important; }
  .mb-xxxl-9,
  .my-xxxl-9 {
    margin-bottom: 6rem !important; }
  .ml-xxxl-9,
  .mx-xxxl-9 {
    margin-left: 6rem !important; }
  .m-xxxl-10 {
    margin: 7rem !important; }
  .mt-xxxl-10,
  .my-xxxl-10 {
    margin-top: 7rem !important; }
  .mr-xxxl-10,
  .mx-xxxl-10 {
    margin-right: 7rem !important; }
  .mb-xxxl-10,
  .my-xxxl-10 {
    margin-bottom: 7rem !important; }
  .ml-xxxl-10,
  .mx-xxxl-10 {
    margin-left: 7rem !important; }
  .m-xxxl-11 {
    margin: 8rem !important; }
  .mt-xxxl-11,
  .my-xxxl-11 {
    margin-top: 8rem !important; }
  .mr-xxxl-11,
  .mx-xxxl-11 {
    margin-right: 8rem !important; }
  .mb-xxxl-11,
  .my-xxxl-11 {
    margin-bottom: 8rem !important; }
  .ml-xxxl-11,
  .mx-xxxl-11 {
    margin-left: 8rem !important; }
  .m-xxxl-12 {
    margin: 9rem !important; }
  .mt-xxxl-12,
  .my-xxxl-12 {
    margin-top: 9rem !important; }
  .mr-xxxl-12,
  .mx-xxxl-12 {
    margin-right: 9rem !important; }
  .mb-xxxl-12,
  .my-xxxl-12 {
    margin-bottom: 9rem !important; }
  .ml-xxxl-12,
  .mx-xxxl-12 {
    margin-left: 9rem !important; }
  .m-xxxl-13 {
    margin: 10rem !important; }
  .mt-xxxl-13,
  .my-xxxl-13 {
    margin-top: 10rem !important; }
  .mr-xxxl-13,
  .mx-xxxl-13 {
    margin-right: 10rem !important; }
  .mb-xxxl-13,
  .my-xxxl-13 {
    margin-bottom: 10rem !important; }
  .ml-xxxl-13,
  .mx-xxxl-13 {
    margin-left: 10rem !important; }
  .m-xxxl-15 {
    margin: 15rem !important; }
  .mt-xxxl-15,
  .my-xxxl-15 {
    margin-top: 15rem !important; }
  .mr-xxxl-15,
  .mx-xxxl-15 {
    margin-right: 15rem !important; }
  .mb-xxxl-15,
  .my-xxxl-15 {
    margin-bottom: 15rem !important; }
  .ml-xxxl-15,
  .mx-xxxl-15 {
    margin-left: 15rem !important; }
  .p-xxxl-0 {
    padding: 0 !important; }
  .pt-xxxl-0,
  .py-xxxl-0 {
    padding-top: 0 !important; }
  .pr-xxxl-0,
  .px-xxxl-0 {
    padding-right: 0 !important; }
  .pb-xxxl-0,
  .py-xxxl-0 {
    padding-bottom: 0 !important; }
  .pl-xxxl-0,
  .px-xxxl-0 {
    padding-left: 0 !important; }
  .p-xxxl-1 {
    padding: 0.25rem !important; }
  .pt-xxxl-1,
  .py-xxxl-1 {
    padding-top: 0.25rem !important; }
  .pr-xxxl-1,
  .px-xxxl-1 {
    padding-right: 0.25rem !important; }
  .pb-xxxl-1,
  .py-xxxl-1 {
    padding-bottom: 0.25rem !important; }
  .pl-xxxl-1,
  .px-xxxl-1 {
    padding-left: 0.25rem !important; }
  .p-xxxl-2 {
    padding: 0.5rem !important; }
  .pt-xxxl-2,
  .py-xxxl-2 {
    padding-top: 0.5rem !important; }
  .pr-xxxl-2,
  .px-xxxl-2 {
    padding-right: 0.5rem !important; }
  .pb-xxxl-2,
  .py-xxxl-2 {
    padding-bottom: 0.5rem !important; }
  .pl-xxxl-2,
  .px-xxxl-2 {
    padding-left: 0.5rem !important; }
  .p-xxxl-3 {
    padding: 1rem !important; }
  .pt-xxxl-3,
  .py-xxxl-3 {
    padding-top: 1rem !important; }
  .pr-xxxl-3,
  .px-xxxl-3 {
    padding-right: 1rem !important; }
  .pb-xxxl-3,
  .py-xxxl-3 {
    padding-bottom: 1rem !important; }
  .pl-xxxl-3,
  .px-xxxl-3 {
    padding-left: 1rem !important; }
  .p-xxxl-4 {
    padding: 1.5rem !important; }
  .pt-xxxl-4,
  .py-xxxl-4 {
    padding-top: 1.5rem !important; }
  .pr-xxxl-4,
  .px-xxxl-4 {
    padding-right: 1.5rem !important; }
  .pb-xxxl-4,
  .py-xxxl-4 {
    padding-bottom: 1.5rem !important; }
  .pl-xxxl-4,
  .px-xxxl-4 {
    padding-left: 1.5rem !important; }
  .p-xxxl-5 {
    padding: 2rem !important; }
  .pt-xxxl-5,
  .py-xxxl-5 {
    padding-top: 2rem !important; }
  .pr-xxxl-5,
  .px-xxxl-5 {
    padding-right: 2rem !important; }
  .pb-xxxl-5,
  .py-xxxl-5 {
    padding-bottom: 2rem !important; }
  .pl-xxxl-5,
  .px-xxxl-5 {
    padding-left: 2rem !important; }
  .p-xxxl-6 {
    padding: 3rem !important; }
  .pt-xxxl-6,
  .py-xxxl-6 {
    padding-top: 3rem !important; }
  .pr-xxxl-6,
  .px-xxxl-6 {
    padding-right: 3rem !important; }
  .pb-xxxl-6,
  .py-xxxl-6 {
    padding-bottom: 3rem !important; }
  .pl-xxxl-6,
  .px-xxxl-6 {
    padding-left: 3rem !important; }
  .p-xxxl-7 {
    padding: 4rem !important; }
  .pt-xxxl-7,
  .py-xxxl-7 {
    padding-top: 4rem !important; }
  .pr-xxxl-7,
  .px-xxxl-7 {
    padding-right: 4rem !important; }
  .pb-xxxl-7,
  .py-xxxl-7 {
    padding-bottom: 4rem !important; }
  .pl-xxxl-7,
  .px-xxxl-7 {
    padding-left: 4rem !important; }
  .p-xxxl-8 {
    padding: 5rem !important; }
  .pt-xxxl-8,
  .py-xxxl-8 {
    padding-top: 5rem !important; }
  .pr-xxxl-8,
  .px-xxxl-8 {
    padding-right: 5rem !important; }
  .pb-xxxl-8,
  .py-xxxl-8 {
    padding-bottom: 5rem !important; }
  .pl-xxxl-8,
  .px-xxxl-8 {
    padding-left: 5rem !important; }
  .p-xxxl-9 {
    padding: 6rem !important; }
  .pt-xxxl-9,
  .py-xxxl-9 {
    padding-top: 6rem !important; }
  .pr-xxxl-9,
  .px-xxxl-9 {
    padding-right: 6rem !important; }
  .pb-xxxl-9,
  .py-xxxl-9 {
    padding-bottom: 6rem !important; }
  .pl-xxxl-9,
  .px-xxxl-9 {
    padding-left: 6rem !important; }
  .p-xxxl-10 {
    padding: 7rem !important; }
  .pt-xxxl-10,
  .py-xxxl-10 {
    padding-top: 7rem !important; }
  .pr-xxxl-10,
  .px-xxxl-10 {
    padding-right: 7rem !important; }
  .pb-xxxl-10,
  .py-xxxl-10 {
    padding-bottom: 7rem !important; }
  .pl-xxxl-10,
  .px-xxxl-10 {
    padding-left: 7rem !important; }
  .p-xxxl-11 {
    padding: 8rem !important; }
  .pt-xxxl-11,
  .py-xxxl-11 {
    padding-top: 8rem !important; }
  .pr-xxxl-11,
  .px-xxxl-11 {
    padding-right: 8rem !important; }
  .pb-xxxl-11,
  .py-xxxl-11 {
    padding-bottom: 8rem !important; }
  .pl-xxxl-11,
  .px-xxxl-11 {
    padding-left: 8rem !important; }
  .p-xxxl-12 {
    padding: 9rem !important; }
  .pt-xxxl-12,
  .py-xxxl-12 {
    padding-top: 9rem !important; }
  .pr-xxxl-12,
  .px-xxxl-12 {
    padding-right: 9rem !important; }
  .pb-xxxl-12,
  .py-xxxl-12 {
    padding-bottom: 9rem !important; }
  .pl-xxxl-12,
  .px-xxxl-12 {
    padding-left: 9rem !important; }
  .p-xxxl-13 {
    padding: 10rem !important; }
  .pt-xxxl-13,
  .py-xxxl-13 {
    padding-top: 10rem !important; }
  .pr-xxxl-13,
  .px-xxxl-13 {
    padding-right: 10rem !important; }
  .pb-xxxl-13,
  .py-xxxl-13 {
    padding-bottom: 10rem !important; }
  .pl-xxxl-13,
  .px-xxxl-13 {
    padding-left: 10rem !important; }
  .p-xxxl-15 {
    padding: 15rem !important; }
  .pt-xxxl-15,
  .py-xxxl-15 {
    padding-top: 15rem !important; }
  .pr-xxxl-15,
  .px-xxxl-15 {
    padding-right: 15rem !important; }
  .pb-xxxl-15,
  .py-xxxl-15 {
    padding-bottom: 15rem !important; }
  .pl-xxxl-15,
  .px-xxxl-15 {
    padding-left: 15rem !important; }
  .m-xxxl-auto {
    margin: auto !important; }
  .mt-xxxl-auto,
  .my-xxxl-auto {
    margin-top: auto !important; }
  .mr-xxxl-auto,
  .mx-xxxl-auto {
    margin-right: auto !important; }
  .mb-xxxl-auto,
  .my-xxxl-auto {
    margin-bottom: auto !important; }
  .ml-xxxl-auto,
  .mx-xxxl-auto {
    margin-left: auto !important; } }

.text-monospace {
  font-family: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; }

.text-justify {
  text-align: justify !important; }

.text-nowrap {
  white-space: nowrap !important; }

.text-truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap; }

.text-left {
  text-align: left !important; }

.text-right {
  text-align: right !important; }

.text-center {
  text-align: center !important; }

@media (min-width: 576px) {
  .text-sm-left {
    text-align: left !important; }
  .text-sm-right {
    text-align: right !important; }
  .text-sm-center {
    text-align: center !important; } }

@media (min-width: 768px) {
  .text-md-left {
    text-align: left !important; }
  .text-md-right {
    text-align: right !important; }
  .text-md-center {
    text-align: center !important; } }

@media (min-width: 992px) {
  .text-lg-left {
    text-align: left !important; }
  .text-lg-right {
    text-align: right !important; }
  .text-lg-center {
    text-align: center !important; } }

@media (min-width: 1200px) {
  .text-xl-left {
    text-align: left !important; }
  .text-xl-right {
    text-align: right !important; }
  .text-xl-center {
    text-align: center !important; } }

@media (min-width: 1400px) {
  .text-xxl-left {
    text-align: left !important; }
  .text-xxl-right {
    text-align: right !important; }
  .text-xxl-center {
    text-align: center !important; } }

@media (min-width: 1600px) {
  .text-xxxl-left {
    text-align: left !important; }
  .text-xxxl-right {
    text-align: right !important; }
  .text-xxxl-center {
    text-align: center !important; } }

.text-lowercase {
  text-transform: lowercase !important; }

.text-uppercase {
  text-transform: uppercase !important; }

.text-capitalize {
  text-transform: capitalize !important; }

.font-weight-light {
  font-weight: 300 !important; }

.font-weight-normal {
  font-weight: 400 !important; }

.font-weight-semi-bold {
  font-weight: 600 !important; }

.font-weight-bold {
  font-weight: 700 !important; }

.font-italic {
  font-style: italic !important; }

.text-white {
  color: #FFFFFF !important; }

.text-primary {
  color: #e5291d !important; }

a.text-primary:hover, a.text-primary:focus {
  color: #ba1f15 !important; }

.text-secondary {
  color: #7C6464 !important; }

a.text-secondary:hover, a.text-secondary:focus {
  color: #604d4d !important; }

.text-success {
  color: #AFCD50 !important; }

a.text-success:hover, a.text-success:focus {
  color: #97b634 !important; }

.text-info {
  color: #64C3D7 !important; }

a.text-info:hover, a.text-info:focus {
  color: #3bb3cd !important; }

.text-warning {
  color: #F5A023 !important; }

a.text-warning:hover, a.text-warning:focus {
  color: #db860a !important; }

.text-danger {
  color: #e5291d !important; }

a.text-danger:hover, a.text-danger:focus {
  color: #ba1f15 !important; }

.text-light {
  color: #CCCCCC !important; }

a.text-light:hover, a.text-light:focus {
  color: #b3b3b3 !important; }

.text-dark {
  color: #454545 !important; }

a.text-dark:hover, a.text-dark:focus {
  color: #2c2c2c !important; }

.text-lighter {
  color: #F4F4F4 !important; }

a.text-lighter:hover, a.text-lighter:focus {
  color: #dbdbdb !important; }

.text-gray {
  color: #757575 !important; }

a.text-gray:hover, a.text-gray:focus {
  color: #5c5c5c !important; }

.text-gray-dark {
  color: #171717 !important; }

a.text-gray-dark:hover, a.text-gray-dark:focus {
  color: black !important; }

.text-body {
  color: #454545 !important; }

.text-muted {
  color: #757575 !important; }

.text-black-50 {
  color: rgba(0, 0, 0, 0.5) !important; }

.text-white-50 {
  color: rgba(255, 255, 255, 0.5) !important; }

.text-hide {
  font: 0/0 a;
  color: transparent;
  text-shadow: none;
  background-color: transparent;
  border: 0; }

.text-decoration-none {
  text-decoration: none !important; }

.visible {
  visibility: visible !important; }

.invisible {
  visibility: hidden !important; }

@media print {
  *,
  *::before,
  *::after {
    text-shadow: none !important;
    box-shadow: none !important; }
  a:not(.btn) {
    text-decoration: underline; }
  abbr[title]::after {
    content: " (" attr(title) ")"; }
  pre {
    white-space: pre-wrap !important; }
  pre,
  blockquote {
    border: 0.1rem solid #757575;
    page-break-inside: avoid; }
  thead {
    display: table-header-group; }
  tr,
  img {
    page-break-inside: avoid; }
  p,
  h2,
  h3 {
    orphans: 3;
    widows: 3; }
  h2,
  h3 {
    page-break-after: avoid; }
  @page {
    size: a3; }
  body {
    min-width: 992px !important; }
  .container {
    min-width: 992px !important; }
  .navbar {
    display: none; }
  .badge {
    border: 0.1rem solid #000000; }
  .table {
    border-collapse: collapse !important; }
    .table td,
    .table th {
      background-color: #FFFFFF !important; }
  .table-bordered th,
  .table-bordered td {
    border: 1px solid #CCCCCC !important; }
  .table-dark {
    color: inherit; }
    .table-dark th,
    .table-dark td,
    .table-dark thead th,
    .table-dark tbody + tbody {
      border-color: #E4E4E4; }
  .table .thead-dark th {
    color: inherit;
    border-color: #E4E4E4; } }

.icdc-angular [class^="icon-"], .icdc-angular [class*=" icon-"] {
  font-family: "bdt" !important;
  font-style: normal;
  font-weight: normal;
  font-variant: normal;
  text-transform: none;
  line-height: 1;
  font-size: inherit;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  -webkit-alt: "";
  speak: none; }

.icdc-angular.body-wrapper {
  background-image: /*savepage-url=../img/bg-trame.png*/ url();
  background-position: center 18rem;
  background-repeat: no-repeat; }

.icdc-angular [role="main"] {
  padding: 4rem 2rem;
  background-color: #FFFFFF; }
  @media (min-width: 768px) {
    .icdc-angular [role="main"] {
      padding: 4rem 6rem; } }
  @media (min-width: 1400px) {
    .icdc-angular [role="main"] {
      padding: 4rem 12rem 9rem 12rem; } }

.icdc-angular.page-home [role="main"] {
  max-width: 84.6rem; }

.icdc-angular .main h1, .icdc-angular .main .h1 {
  position: relative;
  padding-top: 2.5rem;
  padding-left: 2.5rem;
  margin-bottom: 2.5rem; }
  .icdc-angular .main h1:before, .icdc-angular .main .h1:before {
    content: "";
    font-family: "bdt" !important;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    font-size: inherit;
    color: inherit;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-alt: "";
    speak: none;
    position: absolute;
    top: 0rem;
    left: -0.7rem;
    display: block;
    font-size: 5rem;
    color: #e5291d;
    line-height: 1; }
  @media (min-width: 1400px) {
    .icdc-angular .main h1, .icdc-angular .main .h1 {
      padding-top: 5rem;
      padding-left: 0; }
      .icdc-angular .main h1::before, .icdc-angular .main .h1::before {
        left: -6rem;
        font-size: 7rem; } }
  .icdc-angular .main h1.no-corner::before, .icdc-angular .main .h1.no-corner::before {
    display: none; }

.icdc-angular .main h2, .icdc-angular .main .h2 {
  position: relative;
  margin-bottom: 3.5rem; }
  .icdc-angular .main h2:after, .icdc-angular .main .h2:after {
    content: "";
    font-family: "bdt" !important;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    font-size: inherit;
    color: inherit;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-alt: "";
    speak: none;
    display: block;
    margin-top: 1.5rem;
    font-size: 5rem;
    line-height: 0;
    color: #e5291d; }
  .icdc-angular .main h2.no-border::after, .icdc-angular .main .h2.no-border::after {
    content: none; }

.icdc-angular .hn-icon [class^="icon-"] {
  font-size: 80%;
  color: #e5291d; }

.icdc-angular .with-dot {
  position: relative;
  padding-left: 1.5rem; }
  .icdc-angular .with-dot::before {
    content: "•";
    position: absolute;
    top: 0;
    left: 0;
    color: #e5291d;
    -webkit-alt: "";
    speak: none; }

.icdc-angular hr.dashed {
  border-style: dashed; }

.icdc-angular hr.dotted {
  border-style: dotted; }

.icdc-angular .sr-only, .icdc-angular .table-recap tbody th,
.icdc-angular .table-recap tfoot th {
  margin: 0 !important;
  padding: 0 !important; }

.icdc-angular [class^="tag-bdt"], .icdc-angular [class*="tag-bdt"] {
  display: inline-block;
  border: solid 0.1rem #454545;
  border-radius: 0.3rem;
  background-color: transparent;
  font-size: 1.2rem;
  font-weight: 600;
  text-decoration: none;
  line-height: 1.5rem;
  padding: .7rem 1rem;
  margin-right: 1rem; }

.icdc-angular .tag-bdt {
  border: solid 0.1rem #454545;
  background-color: #454545;
  color: #FFFFFF; }
  .icdc-angular .tag-bdt-inverted {
    border: solid 0.1rem #454545;
    color: #454545; }
  .icdc-angular .tag-bdt-secondary {
    border: solid 0.1rem #e5291d;
    color: #e5291d; }
  .icdc-angular .tag-bdt-lighter {
    border: solid 0.1rem #757575;
    color: #757575; }

.icdc-angular .main::after {
  content: '';
  display: table;
  clear: both; }

[data-contrast='high-c'] .icdc-angular .nav-tabs .nav-link,
[data-contrast='high-c'] .icdc-angular .breadcrumb-item,
[data-contrast='high-c'] .icdc-angular .block-recap--item-total,
[data-contrast='high-c'] .icdc-angular .steplist-item-title {
  color: #454545; }

[data-contrast='high-c'] .icdc-angular .text-secondary {
  color: #D72619 !important; }

[data-contrast='high-c'] .icdc-angular .table-recap-total span {
  color: #D72619; }

[data-contrast='inv-c'] .icdc-angular.body-wrapper {
  background-image: none; }

[data-contrast='inv-c'] .icdc-angular [role="main"],
[data-contrast='inv-c'] .icdc-angular .form-control {
  color: #FFFF00;
  background-color: #000080;
  border: solid 0.1rem #FFFF00; }

[data-contrast='inv-c'] .icdc-angular hr,
[data-contrast='inv-c'] .icdc-angular .nav-tabs .nav-link,
[data-contrast='inv-c'] .icdc-angular .nav-tabs .nav-link:hover,
[data-contrast='inv-c'] .icdc-angular .nav-tabs--icon .nav-link--text::before,
[data-contrast='inv-c'] .icdc-angular .breadcrumb,
[data-contrast='inv-c'] .icdc-angular .table-recap-wrapper,
[data-contrast='inv-c'] .icdc-angular .table th,
[data-contrast='inv-c'] .icdc-angular .table td,
[data-contrast='inv-c'] .icdc-angular .table-recap-total,
[data-contrast='inv-c'] .icdc-angular .table-account-total,
[data-contrast='inv-c'] .icdc-angular .block-upload-and-drag,
[data-contrast='inv-c'] .icdc-angular .block-upload-and-drag.is-hover,
[data-contrast='inv-c'] .icdc-angular .block-recap--title,
[data-contrast='inv-c'] .icdc-angular .block-recap--item,
[data-contrast='inv-c'] .icdc-angular .block-recap--total,
[data-contrast='inv-c'] .icdc-angular .dropdown-menu,
[data-contrast='inv-c'] .icdc-angular .page-link {
  border-color: #FFFF00; }

[data-contrast='inv-c'] .icdc-angular .block-bordered {
  border-color: #FFFF00 !important; }

[data-contrast='inv-c'] .icdc-angular .main h1::before,
[data-contrast='inv-c'] .icdc-angular .main .h1::before,
[data-contrast='inv-c'] .icdc-angular h2:after,
[data-contrast='inv-c'] .icdc-angular .h2:after,
[data-contrast='inv-c'] .icdc-angular .with-dot::before,
[data-contrast='inv-c'] .icdc-angular .hn-icon [class^="icon-"],
[data-contrast='inv-c'] .icdc-angular ol > li:before,
[data-contrast='inv-c'] .icdc-angular .float-target-parent.focused label,
[data-contrast='inv-c'] .icdc-angular .form-has-floatlabel .focused.js-form-type-search label,
.form-has-floatlabel [data-contrast='inv-c'] .icdc-angular .focused.js-form-type-search label,
[data-contrast='inv-c'] .icdc-angular .form-has-floatlabel .focused.js-form-item-field-tra-geography label,
.form-has-floatlabel [data-contrast='inv-c'] .icdc-angular .focused.js-form-item-field-tra-geography label,
[data-contrast='inv-c'] .icdc-angular .nav-tabs .nav-link,
[data-contrast='inv-c'] .icdc-angular .breadcrumb-item,
[data-contrast='inv-c'] .icdc-angular .breadcrumb-item.active,
[data-contrast='inv-c'] .icdc-angular .breadcrumb-item.complete,
[data-contrast='inv-c'] .icdc-angular .steplist-item-title,
[data-contrast='inv-c'] .icdc-angular .steplist-item.complete,
[data-contrast='inv-c'] .icdc-angular .steplist-item.complete .steplist-item-title,
[data-contrast='inv-c'] .icdc-angular .steplist-item.active,
[data-contrast='inv-c'] .icdc-angular .steplist-item.active .steplist-item-title,
[data-contrast='inv-c'] .icdc-angular .btn-download:before,
[data-contrast='inv-c'] .icdc-angular .btn-download:after,
[data-contrast='inv-c'] .icdc-angular .table-recap-total span,
[data-contrast='inv-c'] .icdc-angular .table-account-total span,
[data-contrast='inv-c'] .icdc-angular .dossier-status-info,
[data-contrast='inv-c'] .icdc-angular caption,
[data-contrast='inv-c'] .icdc-angular .block-upload-file--button [class^='icon-'],
[data-contrast='inv-c'] .icdc-angular .block-upload-file--button:after,
[data-contrast='inv-c'] .icdc-angular .block-upload-file--uploaded-actions .icon-check,
[data-contrast='inv-c'] .icdc-angular .block-upload-and-drag--drag [class^='icon-'],
[data-contrast='inv-c'] .icdc-angular .block-upload-and-drag--file-weight,
[data-contrast='inv-c'] .icdc-angular .block-upload-and-drag--file > [class^='icon-'],
[data-contrast='inv-c'] .icdc-angular .progress-nb,
[data-contrast='inv-c'] .icdc-angular .block-create-account-item--suivi .dossier-status .icon-traitement-en-cours,
[data-contrast='inv-c'] .icdc-angular .block-create-account-item--suivi .dossier-status .icon-demande-validee,
[data-contrast='inv-c'] .icdc-angular .block-recap--item-total,
[data-contrast='inv-c'] .icdc-angular .form-group.required label::after,
[data-contrast='inv-c'] .icdc-angular .invalid-feedback,
[data-contrast='inv-c'] .icdc-angular .dropdown-item,
[data-contrast='inv-c'] .icdc-angular .page-link:hover {
  color: #FFFF00; }

[data-contrast='inv-c'] .icdc-angular .text-secondary,
[data-contrast='inv-c'] .icdc-angular .text-success,
[data-contrast='inv-c'] .icdc-angular .text-danger {
  color: #FFFF00 !important; }

[data-contrast='inv-c'] .icdc-angular .btn-link [class^='icon-'],
[data-contrast='inv-c'] .icdc-angular [class*="btn-outline"] [class^='icon-'] {
  color: #000080; }

[data-contrast='inv-c'] .icdc-angular .nav-tabs--connect .nav-link [class^='icon'],
[data-contrast='inv-c'] .icdc-angular .nav-tabs--icon .nav-link [class^='icon'],
[data-contrast='inv-c'] .icdc-angular .nav-tabs--icon .nav-link.active [class^='icon'],
[data-contrast='inv-c'] .icdc-angular .nav-tabs--icon .nav-item.show .nav-link [class^='icon'] {
  color: inherit; }

[data-contrast='inv-c'] .icdc-angular .nav-tabs--icon .nav-link--text::after,
[data-contrast='inv-c'] .icdc-angular .breadcrumb-item-inner::after,
[data-contrast='inv-c'] .icdc-angular .table,
[data-contrast='inv-c'] .icdc-angular .table-recap,
[data-contrast='inv-c'] .icdc-angular .table-recap-wrapper,
[data-contrast='inv-c'] .icdc-angular .table-account,
[data-contrast='inv-c'] .icdc-angular .block-upload-and-drag.is-hover,
[data-contrast='inv-c'] .icdc-angular .progress,
[data-contrast='inv-c'] .icdc-angular .custom-control-label::before,
[data-contrast='inv-c'] .icdc-angular .dropdown-menu,
[data-contrast='inv-c'] .icdc-angular .page-link,
[data-contrast='inv-c'] .icdc-angular .pagination .page-item.active .page-link::after {
  background-color: #000080; }

[data-contrast='inv-c'] .icdc-angular .block-highlight-link > a,
[data-contrast='inv-c'] .icdc-angular .block-bordered,
[data-contrast='inv-c'] .icdc-angular .bg-lighter {
  color: #FFFF00 !important;
  background-color: #000080 !important; }

[data-contrast='inv-c'] .icdc-angular .progress-bar,
[data-contrast='inv-c'] .icdc-angular .block-create-account-item--status,
[data-contrast='inv-c'] .icdc-angular .alert {
  background-color: #FFFF00 !important;
  color: #000080 !important; }

[data-contrast='inv-c'] .icdc-angular .breadcrumb-item-inner::after,
[data-contrast='inv-c'] .icdc-angular .input-group--search .form-control,
[data-contrast='inv-c'] .icdc-angular .block-upload-file--button,
[data-contrast='inv-c'] .icdc-angular .block-highlight-link > a,
[data-contrast='inv-c'] .icdc-angular .progress,
[data-contrast='inv-c'] .icdc-angular .custom-checkbox .custom-control-label::before,
[data-contrast='inv-c'] .icdc-angular .custom-radio .custom-control-label::before {
  border: solid 0.1rem #FFFF00; }

[data-contrast='inv-c'] .icdc-angular .nav-tabs .nav-link.active,
[data-contrast='inv-c'] .icdc-angular .nav-tabs .nav-item.show .nav-link,
[data-contrast='inv-c'] .icdc-angular .dropdown-item.active,
[data-contrast='inv-c'] .icdc-angular .dropdown-item:active,
[data-contrast='inv-c'] .icdc-angular .dropdown-item:hover,
[data-contrast='inv-c'] .icdc-angular .dropdown-item:focus,
[data-contrast='inv-c'] .icdc-angular .page-item.active .page-link {
  color: #000080;
  background-color: #FFFF00;
  border-color: #FFFF00; }

[data-contrast='inv-c'] .icdc-angular .breadcrumb-item.active .breadcrumb-item-separator::before,
[data-contrast='inv-c'] .icdc-angular .breadcrumb-item.complete .breadcrumb-item-separator::before,
[data-contrast='inv-c'] .icdc-angular .breadcrumb-item.complete .breadcrumb-item-separator::after {
  margin-top: -0.1rem;
  padding: 0.3rem; }

[data-contrast='inv-c'] .icdc-angular .breadcrumb-item.active .breadcrumb-item-inner::after,
[data-contrast='inv-c'] .icdc-angular .breadcrumb-item.active .breadcrumb-item-separator::before,
[data-contrast='inv-c'] .icdc-angular .breadcrumb-item.complete .breadcrumb-item-inner::after,
[data-contrast='inv-c'] .icdc-angular .breadcrumb-item.complete .breadcrumb-item-separator::before,
[data-contrast='inv-c'] .icdc-angular .breadcrumb-item.complete .breadcrumb-item-separator::after,
[data-contrast='inv-c'] .icdc-angular .table .thead-dark th {
  color: #000080;
  background-color: #FFFF00; }

[data-contrast='inv-c'] .icdc-angular .steplist-item {
  color: #FFFFFF; }

[data-contrast='inv-c'] .icdc-angular .steplist .steplist-item-line::before {
  border-left-color: #000080; }

[data-contrast='inv-c'] .icdc-angular .input-group--search .input-group-append .input-group-text,
[data-contrast='inv-c'] .icdc-angular .input-group--search .input-group-prepend .input-group-text {
  padding: 1rem;
  color: #000080;
  background: #FFFF00; }

[data-contrast='inv-c'] .icdc-angular .block-upload-file--uploaded-title {
  margin-bottom: 3rem; }

[data-contrast='inv-c'] .icdc-angular .block-upload-and-drag {
  box-shadow: 0 0 0 0 rgba(255, 255, 0, 0.7); }

[data-contrast='inv-c'] .icdc-angular .custom-checkbox .custom-control-input:checked ~ .custom-control-label::before {
  background-color: #000080; }

[data-contrast='inv-c'] .icdc-angular .custom-checkbox .custom-control-input:checked ~ .custom-control-label::after {
  background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3E%3Cpath fill='%23FFFF00' d='M6.564.75l-3.59 3.612-1.538-1.55L0 4.26 2.974 7.25 8 2.193z'/%3E%3C/svg%3E"); }

[data-contrast='inv-c'] .icdc-angular .custom-radio .custom-control-input:checked ~ .custom-control-label::before {
  background-color: #000080; }

[data-contrast='inv-c'] .icdc-angular .custom-radio .custom-control-input:checked ~ .custom-control-label::after {
  background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='-4 -4 8 8'%3E%3Ccircle r='3' fill='%23FFFF00'/%3E%3C/svg%3E"); }

[data-contrast='inv-c'] .icdc-angular .form-control.is-valid,
[data-contrast='inv-c'] .icdc-angular .was-validated .form-control:valid {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3e%3cpath fill='%23FFFF00' d='M27.733 2.8l-16.267 16.8-7.2-8.267-4.267 5.067 11.2 12.8 2.133-2.133 18.667-18.933z'/%3e%3c/svg%3e"); }

[data-contrast='inv-c'] .icdc-angular .form-control.is-invalid,
[data-contrast='inv-c'] .icdc-angular .was-validated .form-control:invalid {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3e%3cpath fill='%23FFFF00' d='M32 28.889l-13.333-12.889 12.889-12.889-3.111-2.667-12.444 12.444-12.889-12.889-3.111 3.111 12.889 12.889-12.444 12.444 2.667 3.111 12.889-12.889 12.889 13.333z'/%3e%3c/svg%3e"); }

[data-contrast='inv-c'] .icdc-angular select.form-control {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3e%3cpath fill='%23FFFF00' d='M26.24 5.76l-10.88 10.24-10.24-10.24-5.12 5.12 15.36 15.36 16.64-15.36z'/%3e%3c/svg%3e"); }

[data-contrast='inv-c'] .icdc-angular .modal-header .close {
  padding: 0.5rem;
  color: #000080;
  background-color: #FFFF00; }

.icdc-angular .float-target-parent,
.icdc-angular .form-has-floatlabel .js-form-type-search, .form-has-floatlabel .icdc-angular .js-form-type-search,
.icdc-angular .form-has-floatlabel .js-form-item-field-tra-geography, .form-has-floatlabel .icdc-angular .js-form-item-field-tra-geography {
  position: relative; }
  .icdc-angular .float-target-parent label, .icdc-angular .form-has-floatlabel .js-form-type-search label, .form-has-floatlabel .icdc-angular .js-form-type-search label, .icdc-angular .form-has-floatlabel .js-form-item-field-tra-geography label, .form-has-floatlabel .icdc-angular .js-form-item-field-tra-geography label {
    pointer-events: none;
    font-size: 1.4rem;
    display: block;
    position: absolute;
    top: 50%;
    left: 0rem;
    -webkit-transform: translateY(-50%) translateX(2.5rem);
            transform: translateY(-50%) translateX(2.5rem);
    font-weight: 700;
    text-transform: lowercase;
    -webkit-transition: font-size 0.3s ease, color 0.3s ease, -webkit-transform 0.3s ease;
    transition: font-size 0.3s ease, color 0.3s ease, -webkit-transform 0.3s ease;
    transition: transform 0.3s ease, font-size 0.3s ease, color 0.3s ease;
    transition: transform 0.3s ease, font-size 0.3s ease, color 0.3s ease, -webkit-transform 0.3s ease; }
    .icdc-angular .float-target-parent label:first-letter, .icdc-angular .form-has-floatlabel .js-form-type-search label:first-letter, .form-has-floatlabel .icdc-angular .js-form-type-search label:first-letter, .icdc-angular .form-has-floatlabel .js-form-item-field-tra-geography label:first-letter, .form-has-floatlabel .icdc-angular .js-form-item-field-tra-geography label:first-letter {
      text-transform: capitalize; }
    .icdc-angular .float-target-parent label.textarea-label, .icdc-angular .form-has-floatlabel .js-form-type-search label.textarea-label, .form-has-floatlabel .icdc-angular .js-form-type-search label.textarea-label, .icdc-angular .form-has-floatlabel .js-form-item-field-tra-geography label.textarea-label, .form-has-floatlabel .icdc-angular .js-form-item-field-tra-geography label.textarea-label {
      top: 3rem; }
  .icdc-angular .float-target-parent.focused label, .icdc-angular .form-has-floatlabel .focused.js-form-type-search label, .form-has-floatlabel .icdc-angular .focused.js-form-type-search label, .icdc-angular .form-has-floatlabel .focused.js-form-item-field-tra-geography label, .form-has-floatlabel .icdc-angular .focused.js-form-item-field-tra-geography label {
    color: #757575;
    text-transform: none;
    -webkit-transform: translateY(-5rem) translateX(0rem);
            transform: translateY(-5rem) translateX(0rem);
    -webkit-transition: font-size 0.3s ease, color 0.3s ease, -webkit-transform 0.3s ease;
    transition: font-size 0.3s ease, color 0.3s ease, -webkit-transform 0.3s ease;
    transition: transform 0.3s ease, font-size 0.3s ease, color 0.3s ease;
    transition: transform 0.3s ease, font-size 0.3s ease, color 0.3s ease, -webkit-transform 0.3s ease; }
    .icdc-angular .float-target-parent.focused label.textarea-label, .icdc-angular .form-has-floatlabel .focused.js-form-type-search label.textarea-label, .form-has-floatlabel .icdc-angular .focused.js-form-type-search label.textarea-label, .icdc-angular .form-has-floatlabel .focused.js-form-item-field-tra-geography label.textarea-label, .form-has-floatlabel .icdc-angular .focused.js-form-item-field-tra-geography label.textarea-label {
      -webkit-transform: translateY(-5rem) translateX(0rem);
              transform: translateY(-5rem) translateX(0rem); }
  .icdc-angular .float-target-parent .form-text, .icdc-angular .form-has-floatlabel .js-form-type-search .form-text, .form-has-floatlabel .icdc-angular .js-form-type-search .form-text, .icdc-angular .form-has-floatlabel .js-form-item-field-tra-geography .form-text, .form-has-floatlabel .icdc-angular .js-form-item-field-tra-geography .form-text {
    display: inline-block;
    position: absolute;
    right: 0;
    bottom: -2.5rem;
    font-size: 1.4rem; }
  .icdc-angular .float-target-parent--small label {
    top: 0rem;
    left: 2.5rem !important;
    z-index: 40;
    -webkit-transform: translate(0, 2rem);
            transform: translate(0, 2rem);
    font-size: 1.6rem; }
  .icdc-angular .float-target-parent--small [type='text'],
  .icdc-angular .float-target-parent--small [type='date'],
  .icdc-angular .float-target-parent--small [type='search'] {
    position: relative;
    bottom: auto;
    height: 6rem;
    padding: 0 5rem;
    border-width: 0 0 0.1rem 0;
    border-color: #000000;
    background-color: #FFFFFF; }
    .icdc-angular .float-target-parent--small [type='text']:focus,
    .icdc-angular .float-target-parent--small [type='date']:focus,
    .icdc-angular .float-target-parent--small [type='search']:focus {
      border-color: #e5291d; }
  .icdc-angular .float-target-parent--small button[type='submit'] {
    -webkit-appearance: none;
       -moz-appearance: none;
            appearance: none;
    margin: 0;
    padding: 0;
    border: none;
    background: none;
    display: block;
    position: absolute;
    bottom: 0.1rem;
    right: 0;
    width: 6rem;
    height: 5.9rem;
    background-color: #FFFFFF;
    color: #000000;
    -webkit-transition: background-color 0.3s ease;
    transition: background-color 0.3s ease; }
    .icdc-angular .float-target-parent--small button[type='submit']:focus {
      outline: 0.1rem dashed #757575;
      outline-offset: 0.4rem; }
    .icdc-angular .float-target-parent--small button[type='submit']:hover, .icdc-angular .float-target-parent--small button[type='submit']:focus, .icdc-angular .float-target-parent--small button[type='submit']:active {
      background-color: #CCCCCC; }
  .icdc-angular .float-target-parent--small.focused label, .icdc-angular .float-target-parent--small.has-value label {
    -webkit-transform: translate(0, 0rem);
            transform: translate(0, 0rem);
    font-size: 1.2rem;
    color: #6c757d; }

.icdc-angular .windows7.ie11 .float-target-parent label, .icdc-angular .windows7.ie11 .form-has-floatlabel .js-form-type-search label, .form-has-floatlabel .icdc-angular .windows7.ie11 .js-form-type-search label, .icdc-angular .windows7.ie11 .form-has-floatlabel .js-form-item-field-tra-geography label, .form-has-floatlabel .icdc-angular .windows7.ie11 .js-form-item-field-tra-geography label {
  position: relative;
  top: auto;
  bottom: 100%;
  left: 0rem;
  -webkit-transform: translateY(0%);
          transform: translateY(0%);
  margin-bottom: 0.4rem; }

.icdc-angular .windows7.ie11 .float-target-parent.focused label, .icdc-angular .windows7.ie11 .form-has-floatlabel .focused.js-form-type-search label, .form-has-floatlabel .icdc-angular .windows7.ie11 .focused.js-form-type-search label, .icdc-angular .windows7.ie11 .form-has-floatlabel .focused.js-form-item-field-tra-geography label, .form-has-floatlabel .icdc-angular .windows7.ie11 .focused.js-form-item-field-tra-geography label {
  -webkit-transform: translateY(0rem) translateX(0rem);
          transform: translateY(0rem) translateX(0rem); }
  .icdc-angular .windows7.ie11 .float-target-parent.focused label.textarea-label, .icdc-angular .windows7.ie11 .form-has-floatlabel .focused.js-form-type-search label.textarea-label, .form-has-floatlabel .icdc-angular .windows7.ie11 .focused.js-form-type-search label.textarea-label, .icdc-angular .windows7.ie11 .form-has-floatlabel .focused.js-form-item-field-tra-geography label.textarea-label, .form-has-floatlabel .icdc-angular .windows7.ie11 .focused.js-form-item-field-tra-geography label.textarea-label {
    -webkit-transform: translateY(0rem) translateX(0rem);
            transform: translateY(0rem) translateX(0rem); }

.icdc-angular .btn-download {
  position: relative;
  display: block;
  padding: 0 2.5rem 0 4.5rem;
  text-transform: uppercase;
  font-weight: 500;
  text-align: left;
  text-decoration: none !important; }
  .icdc-angular .btn-download span, .icdc-angular .btn-download small {
    display: block; }
  .icdc-angular .btn-download:before, .icdc-angular .btn-download:after {
    font-family: "bdt" !important;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    font-size: inherit;
    color: inherit;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-alt: "";
    speak: none;
    position: absolute;
    color: #e5291d; }
  .icdc-angular .btn-download:before {
    content: "";
    top: 0.2rem;
    left: 0;
    font-size: 200%; }
  .icdc-angular .btn-download:after {
    content: "";
    top: 0.2rem;
    right: 0;
    font-size: 100%; }
  .icdc-angular .btn-download:hover, .icdc-angular .btn-download:active {
    text-decoration: underline  !important; }
  .icdc-angular .btn-download:focus {
    text-decoration: none !important; }
  .icdc-angular .btn-download:hover, .icdc-angular .btn-download:focus {
    color: #454545; }

.icdc-angular .btn-link,
.icdc-angular .btn-filter {
  font-size: 1.4rem;
  font-weight: 500;
  text-transform: none; }
  .icdc-angular .btn-link [class^='icon-'],
  .icdc-angular .btn-filter [class^='icon-'] {
    vertical-align: initial;
    font-size: 1.1rem; }

.icdc-angular .btn-link {
  padding: 0.5rem; }
  .icdc-angular .btn-link [class^='icon-'] {
    color: #e5291d; }

.icdc-angular .btn-filter {
  padding: 0.8rem 1rem;
  border: 0.1rem solid;
  border-radius: 0.4rem; }
  .icdc-angular .btn-filter [class^='icon-'] {
    color: inherit; }

.icdc-angular button.btn-filter {
  background-color: transparent; }
  .icdc-angular button.btn-filter:focus, .icdc-angular button.btn-filter:hover, .icdc-angular button.btn-filter:active {
    color: #e5291d; }

.icdc-angular .btn-actions {
  padding: 0.5rem;
  font-size: 2rem;
  background: transparent;
  vertical-align: baseline; }
  .icdc-angular .btn-actions:hover, .icdc-angular .btn-actions:focus {
    background-color: rgba(0, 0, 0, 0.1); }
  .icdc-angular .btn-actions [class^='icon-'] {
    line-height: inherit; }

.icdc-angular .btn-filters {
  width: 3rem;
  padding: 0;
  font-size: 1rem; }

.icdc-angular .btn-popover [class*="icon"] {
  font-size: 1.5rem; }

.icdc-angular .form-group .btn-popover {
  position: absolute;
  top: 50%;
  right: 1.3rem;
  -webkit-transform: translate(0, -50%);
          transform: translate(0, -50%); }

.icdc-angular .btn-toggle-collapse [class^="icon"] {
  font-size: 85%;
  -webkit-transition: -webkit-transform 250ms ease;
  transition: -webkit-transform 250ms ease;
  transition: transform 250ms ease;
  transition: transform 250ms ease, -webkit-transform 250ms ease; }

.icdc-angular .btn-toggle-collapse[aria-expanded="true"] [class^="icon"] {
  -webkit-transform: rotate(180deg);
          transform: rotate(180deg); }

.icdc-angular .btn-form-collapse {
  padding: 0;
  font-size: 1.6rem;
  font-weight: 700;
  text-align: left; }
  .icdc-angular .btn-form-collapse [class^="icon"] {
    margin-left: 0.7rem;
    vertical-align: baseline;
    width: 2.5rem;
    height: 2.5rem;
    line-height: calc(2.5rem - 0.2rem);
    font-size: 65%;
    text-align: center;
    color: #454545;
    border: solid 0.1rem;
    border-radius: 100%; }

.icdc-angular .btn-toolbar {
  margin-top: 3rem;
  display: block; }
  .icdc-angular .btn-toolbar .btn-group {
    display: -webkit-box;
    display: flex;
    -webkit-box-pack: center;
            justify-content: center; }
    .icdc-angular .btn-toolbar .btn-group .btn, .icdc-angular .btn-toolbar .btn-group .region-header-right .nav-link-user > a, .region-header-right .icdc-angular .btn-toolbar .btn-group .nav-link-user > a,
    .icdc-angular .btn-toolbar .btn-group .region-header-right .nav-link-user > button, .region-header-right .icdc-angular .btn-toolbar .btn-group .nav-link-user > button {
      margin-bottom: 2rem; }
    .icdc-angular .btn-toolbar .btn-group .btn-prev {
      -webkit-box-ordinal-group: 1;
              order: 0;
      margin-right: 0.8rem; }
    .icdc-angular .btn-toolbar .btn-group .btn-save {
      -webkit-box-ordinal-group: 2;
              order: 1;
      margin-left: 0.8rem;
      margin-right: 0.8rem; }
    .icdc-angular .btn-toolbar .btn-group .btn-next {
      -webkit-box-ordinal-group: 3;
              order: 2;
      margin-left: 0.8rem; }
  @media (max-width: 767.98px) {
    .icdc-angular .btn-toolbar [class*='btn-icon'] .btn-text {
      position: absolute;
      width: 1px;
      height: 1px;
      padding: 0;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      border: 0; }
    .icdc-angular .btn-toolbar [class*='btn-icon'] [class^='icon-'] {
      margin: 0; } }
  @media (min-width: 768px) {
    .icdc-angular .btn-toolbar .btn-group {
      -webkit-box-pack: start;
              justify-content: flex-start; }
    .icdc-angular .btn-toolbar .btn-next {
      margin-left: auto !important; } }

.icdc-angular .input-group > .form-control:not(:last-child),
.icdc-angular .input-group > .custom-select:not(:last-child) {
  border-right-color: #FFFFFF; }
  .icdc-angular .input-group > .form-control:not(:last-child).mr-5,
  .icdc-angular .input-group > .custom-select:not(:last-child).mr-5 {
    border-right-color: #CCCCCC; }
    .icdc-angular .input-group > .form-control:not(:last-child).mr-5:focus,
    .icdc-angular .input-group > .custom-select:not(:last-child).mr-5:focus {
      border-right-color: #171717; }
  .icdc-angular .input-group > .form-control:not(:last-child):focus ~ .input-group-append .input-group-text,
  .icdc-angular .input-group > .custom-select:not(:last-child):focus ~ .input-group-append .input-group-text {
    border-top-color: #171717;
    border-right-color: #171717;
    border-bottom-color: #171717; }

.icdc-angular .input-group > .form-control:not(:first-child),
.icdc-angular .input-group > .custom-select:not(:first-child) {
  border-left-color: #CCCCCC; }

.icdc-angular .input-group-text {
  padding-top: 0;
  padding-bottom: 0; }
  .icdc-angular .input-group-text [class^='icon-'] {
    font-size: 2.3rem;
    line-height: 1; }

.icdc-angular .input-group-prepend span.input-group-text,
.icdc-angular .input-group-append span.input-group-text {
  font-size: 1.8rem;
  font-weight: 600; }

.icdc-angular .input-group-append .input-group-text {
  border-left-width: 0; }

.icdc-angular .input-group--search {
  border-bottom: 0.1rem solid #454545; }
  .icdc-angular .input-group--search .float-target-parent,
  .icdc-angular .input-group--search .form-has-floatlabel .js-form-type-search, .form-has-floatlabel .icdc-angular .input-group--search .js-form-type-search,
  .icdc-angular .input-group--search .form-has-floatlabel .js-form-item-field-tra-geography, .form-has-floatlabel .icdc-angular .input-group--search .js-form-item-field-tra-geography {
    -webkit-box-flex: 1;
            flex: 1 1 auto;
    width: 1%; }
  .icdc-angular .input-group--search .form-control {
    border: 0;
    height: 100%; }
  .icdc-angular .input-group--search .input-group-text {
    padding: 0;
    border: 0; }
  .icdc-angular .input-group--search .input-group-prepend .input-group-text {
    color: #e5291d; }
  .icdc-angular .input-group--search .input-group-prepend,
  .icdc-angular .input-group--search .input-group-append {
    -webkit-box-flex: 0;
            flex: 0 0 6rem; }
    .icdc-angular .input-group--search .input-group-prepend .input-group-text,
    .icdc-angular .input-group--search .input-group-append .input-group-text {
      width: 100%;
      -webkit-box-pack: center;
              justify-content: center; }
  .icdc-angular .input-group--search---large {
    height: 13rem; }
    .icdc-angular .input-group--search---large .input-group-prepend .input-group-text [class^='icon-'] {
      font-size: 4rem; }
    .icdc-angular .input-group--search---large .input-group-prepend,
    .icdc-angular .input-group--search---large .input-group-append {
      -webkit-box-flex: 0;
              flex: 0 0 10rem; }
    .icdc-angular .input-group--search---large label {
      font-size: 2.2rem; }
    .icdc-angular .input-group--search---large .form-control {
      padding-left: 0;
      font-size: 2rem; }
    .icdc-angular .input-group--search---large .float-target-parent label, .icdc-angular .input-group--search---large .form-has-floatlabel .js-form-type-search label, .form-has-floatlabel .icdc-angular .input-group--search---large .js-form-type-search label, .icdc-angular .input-group--search---large .form-has-floatlabel .js-form-item-field-tra-geography label, .form-has-floatlabel .icdc-angular .input-group--search---large .js-form-item-field-tra-geography label {
      -webkit-transform: translateX(0rem) translateY(-50%);
              transform: translateX(0rem) translateY(-50%); }
    .icdc-angular .input-group--search---large .float-target-parent.focused label, .icdc-angular .input-group--search---large .form-has-floatlabel .focused.js-form-type-search label, .form-has-floatlabel .icdc-angular .input-group--search---large .focused.js-form-type-search label, .icdc-angular .input-group--search---large .form-has-floatlabel .focused.js-form-item-field-tra-geography label, .form-has-floatlabel .icdc-angular .input-group--search---large .focused.js-form-item-field-tra-geography label {
      -webkit-transform: translateX(0rem) translateY(-5rem);
              transform: translateX(0rem) translateY(-5rem);
      font-size: 1.4rem;
      font-weight: 600; }

.icdc-angular .input-group-inline {
  position: relative; }
  .icdc-angular .input-group-inline input[type='text'] {
    -webkit-appearance: none;
       -moz-appearance: none;
            appearance: none;
    margin: 0 1rem;
    padding: 0 1rem;
    height: 3.5rem;
    border-width: 0 0 0.2rem 0;
    border-style: dotted;
    border-color: #CCCCCC;
    box-shadow: none;
    text-align: center;
    font-size: 2rem;
    color: #454545;
    font-weight: 600; }
    .icdc-angular .input-group-inline input[type='text'].is-invalid {
      border-color: #e5291d;
      color: #e5291d; }
  .icdc-angular .input-group-inline select {
    display: inline-block;
    position: relative;
    margin: 0;
    padding: 0 1.6rem 0 0.5rem;
    border: 0;
    border-width: 0 0 0.2rem 0;
    border-style: dotted;
    border-color: #CCCCCC;
    height: 3.5rem;
    color: #454545;
    font-weight: 600 !important;
    cursor: pointer;
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none; }
    @media (max-width: 767.98px) {
      .icdc-angular .input-group-inline select {
        height: 2.3rem; } }
    .icdc-angular .input-group-inline select.is-invalid {
      border-color: #e5291d; }
  .icdc-angular .input-group-inline ::-webkit-input-placeholder {
    color: #757575;
    font-size: inherit;
    font-weight: 600;
    font-size: 1.6rem;
    text-transform: lowercase;
    font-style: italic; }
  .icdc-angular .input-group-inline ::-moz-placeholder {
    color: #757575;
    font-size: inherit;
    font-weight: 600;
    font-size: 1.6rem;
    text-transform: lowercase;
    font-style: italic; }
  .icdc-angular .input-group-inline :-ms-input-placeholder {
    color: #757575;
    font-size: inherit;
    font-weight: 600;
    font-size: 1.6rem;
    text-transform: lowercase;
    font-style: italic; }
  .icdc-angular .input-group-inline ::-ms-input-placeholder {
    color: #757575;
    font-size: inherit;
    font-weight: 600;
    font-size: 1.6rem;
    text-transform: lowercase;
    font-style: italic; }
  .icdc-angular .input-group-inline ::placeholder {
    color: #757575;
    font-size: inherit;
    font-weight: 600;
    font-size: 1.6rem;
    text-transform: lowercase;
    font-style: italic; }
  .icdc-angular .input-group-inline .invalid-feedback {
    display: none;
    position: absolute;
    z-index: 2;
    top: 3.2rem;
    left: 50%;
    width: auto;
    margin-top: auto;
    padding: 0.2rem 0.8rem;
    -webkit-transform: translateX(-50%);
            transform: translateX(-50%);
    border: 0.1rem solid #e5291d;
    white-space: nowrap;
    font-size: 1rem;
    color: #e5291d; }
    .icdc-angular .input-group-inline .invalid-feedback:before {
      content: "";
      font-family: "bdt" !important;
      font-style: normal;
      font-weight: normal;
      font-variant: normal;
      text-transform: none;
      line-height: 1;
      font-size: inherit;
      color: inherit;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      -webkit-alt: "";
      speak: none;
      padding-right: 0.7rem; }
    .icdc-angular .input-group-inline .invalid-feedback::after {
      content: "";
      position: absolute;
      top: -0.6rem;
      left: 50%;
      -webkit-transform: translateX(-50%);
              transform: translateX(-50%);
      width: 0;
      height: 0;
      border-left: 0.4rem solid transparent;
      border-right: 0.4rem solid transparent;
      border-bottom: 0.6rem solid #e5291d; }

.icdc-angular .form-control,
.icdc-angular input, .icdc-angular textarea, .icdc-angular select {
  font-weight: 400; }
  .icdc-angular .form-control:focus,
  .icdc-angular input:focus, .icdc-angular textarea:focus, .icdc-angular select:focus {
    outline: 0.1rem dashed #757575;
    outline-offset: 0.4rem; }

.icdc-angular label {
  cursor: pointer;
  font-size: 1.4rem;
  font-weight: 700; }

.icdc-angular input:-webkit-autofill,
.icdc-angular textarea:-webkit-autofill,
.icdc-angular select:-webkit-autofill {
  background-color: #FFFFFF; }

.icdc-angular .custom-control {
  margin-bottom: 2rem; }
  .icdc-angular .custom-control input:focus + label::before {
    outline: 0.1rem dashed #757575;
    outline-offset: 0.4rem; }

.icdc-angular .custom-control-label {
  padding-top: 0.2rem;
  text-transform: none; }

.icdc-angular .custom-radio .custom-control-label::before {
  border: 1px solid #CCCCCC; }

.icdc-angular .custom-checkbox {
  padding-left: 2.5rem; }
  .icdc-angular .custom-checkbox .custom-control-label::before {
    border: 1px solid #CCCCCC; }
  .icdc-angular .custom-checkbox .custom-control-label::before, .icdc-angular .custom-checkbox .custom-control-label::after {
    height: 1.4rem;
    width: 1.4rem;
    left: -2.5rem;
    top: 0.3rem; }

.icdc-angular .form-group {
  position: relative; }

.icdc-angular .form-group-icon-left [class*='icon-'],
.icdc-angular .form-group-icon-right [class*='icon-'] {
  position: absolute;
  top: 0.1rem;
  bottom: 0.1rem;
  width: 5.8rem;
  font-size: 1.8rem;
  text-align: center; }
  .icdc-angular .form-group-icon-left [class*='icon-']::before,
  .icdc-angular .form-group-icon-right [class*='icon-']::before {
    display: block;
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%); }

.icdc-angular .form-group-icon-left [class*='icon-'] {
  left: 0.1rem; }

.icdc-angular .form-group-icon-left .float-target-parent label, .icdc-angular .form-group-icon-left .form-has-floatlabel .js-form-type-search label, .form-has-floatlabel .icdc-angular .form-group-icon-left .js-form-type-search label, .icdc-angular .form-group-icon-left .form-has-floatlabel .js-form-item-field-tra-geography label, .form-has-floatlabel .icdc-angular .form-group-icon-left .js-form-item-field-tra-geography label {
  -webkit-transform: translateY(-50%) translateX(5.8rem);
          transform: translateY(-50%) translateX(5.8rem); }

.icdc-angular .form-group-icon-left .form-control {
  padding-left: 5.8rem; }

.icdc-angular .form-group-icon-right [class*='icon-'] {
  right: 0.1rem; }

.icdc-angular .form-group-icon-right .form-control {
  padding-right: 5.8rem; }

.icdc-angular .form-group.required label::after,
.icdc-angular .input-group-inline.required::after {
  content: "*";
  color: #e5291d; }

.icdc-angular .form-control.is-valid,
.icdc-angular .was-validated .form-control:valid,
.icdc-angular .form-control.is-invalid,
.icdc-angular .was-validated .form-control:invalid {
  padding-right: 4rem;
  background-repeat: no-repeat;
  background-position: center right 1.5rem;
  background-size: calc(2.25rem / 2) calc(2.25rem / 2); }

.icdc-angular .form-control.is-valid,
.icdc-angular .was-validated .form-control:valid {
  border-color: #CCCCCC; }

.icdc-angular .input-group-text.is-invalid {
  border-color: #e5291d; }
  .icdc-angular .input-group-text.is-invalid:focus {
    border-color: #e5291d;
    box-shadow: 0 0 0 0rem rgba(229, 41, 29, 0.25); }

.icdc-angular select.form-control {
  -webkit-appearance: none;
     -moz-appearance: none;
          appearance: none;
  padding-right: 4rem;
  font-size: 1.4rem;
  font-weight: 700;
  background-repeat: no-repeat;
  background-position: center right 1.5rem;
  background-size: calc(2.25rem / 2) calc(2.25rem / 2);
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3e%3cpath fill='%23000000' d='M26.24 5.76l-10.88 10.24-10.24-10.24-5.12 5.12 15.36 15.36 16.64-15.36z'/%3e%3c/svg%3e"); }
  .icdc-angular select.form-control option {
    text-transform: none; }

.icdc-angular select::-ms-expand {
  display: none; }

.icdc-angular .description {
  font-size: 1.4rem; }
  .icdc-angular .description p {
    margin-bottom: 1rem; }

.icdc-angular .form-row {
  margin-right: -1rem;
  margin-left: -1rem; }
  .icdc-angular .form-row > .col,
  .icdc-angular .form-row > [class*="col-"] {
    padding-right: 1rem;
    padding-left: 1rem; }

.icdc-angular .invalid-feedback {
  display: block; }

.icdc-angular .float-target-parent,
.icdc-angular .form-has-floatlabel .js-form-type-search, .form-has-floatlabel .icdc-angular .js-form-type-search,
.icdc-angular .form-has-floatlabel .js-form-item-field-tra-geography, .form-has-floatlabel .icdc-angular .js-form-item-field-tra-geography {
  position: relative; }
  .icdc-angular .float-target-parent label, .icdc-angular .form-has-floatlabel .js-form-type-search label, .form-has-floatlabel .icdc-angular .js-form-type-search label, .icdc-angular .form-has-floatlabel .js-form-item-field-tra-geography label, .form-has-floatlabel .icdc-angular .js-form-item-field-tra-geography label {
    pointer-events: none;
    display: block;
    position: absolute;
    top: 50%;
    left: 0;
    z-index: 10;
    max-width: calc(100% - 2.2rem*2);
    -webkit-transform: translateY(-50%) translateX(2.2rem);
            transform: translateY(-50%) translateX(2.2rem);
    -webkit-transition: font-size 0.3s ease, color 0.3s ease, -webkit-transform 0.3s ease;
    transition: font-size 0.3s ease, color 0.3s ease, -webkit-transform 0.3s ease;
    transition: transform 0.3s ease, font-size 0.3s ease, color 0.3s ease;
    transition: transform 0.3s ease, font-size 0.3s ease, color 0.3s ease, -webkit-transform 0.3s ease; }
    .icdc-angular .float-target-parent label.textarea-label, .icdc-angular .form-has-floatlabel .js-form-type-search label.textarea-label, .form-has-floatlabel .icdc-angular .js-form-type-search label.textarea-label, .icdc-angular .form-has-floatlabel .js-form-item-field-tra-geography label.textarea-label, .form-has-floatlabel .icdc-angular .js-form-item-field-tra-geography label.textarea-label {
      top: 3rem; }
  .icdc-angular .float-target-parent.focused label, .icdc-angular .form-has-floatlabel .focused.js-form-type-search label, .form-has-floatlabel .icdc-angular .focused.js-form-type-search label, .icdc-angular .form-has-floatlabel .focused.js-form-item-field-tra-geography label, .form-has-floatlabel .icdc-angular .focused.js-form-item-field-tra-geography label {
    font-size: 1.1rem;
    font-weight: 500;
    text-transform: none;
    color: #757575;
    max-width: 100%;
    -webkit-transform: translateY(-5rem) translateX(0.5rem);
            transform: translateY(-5rem) translateX(0.5rem);
    -webkit-transition: font-size 0.3s ease, color 0.3s ease, -webkit-transform 0.3s ease;
    transition: font-size 0.3s ease, color 0.3s ease, -webkit-transform 0.3s ease;
    transition: transform 0.3s ease, font-size 0.3s ease, color 0.3s ease;
    transition: transform 0.3s ease, font-size 0.3s ease, color 0.3s ease, -webkit-transform 0.3s ease; }
  .form-row .icdc-angular .float-target-parent[class*="col-"] label, .form-row .icdc-angular .form-has-floatlabel .js-form-type-search[class*="col-"] label, .form-has-floatlabel .form-row .icdc-angular .js-form-type-search[class*="col-"] label, .form-row .icdc-angular .form-has-floatlabel .js-form-item-field-tra-geography[class*="col-"] label, .form-has-floatlabel .form-row .icdc-angular .js-form-item-field-tra-geography[class*="col-"] label {
    left: 1rem; }

.icdc-angular ol, .icdc-angular ul, .icdc-angular dl {
  margin-bottom: 3rem; }

.icdc-angular ul {
  list-style: none; }
  .icdc-angular ul li {
    position: relative;
    margin-bottom: 1rem;
    padding-left: 1.5rem; }
    .icdc-angular ul li:before {
      content: "•";
      position: absolute;
      top: 0;
      left: 0;
      display: inline-block;
      color: inherit;
      font-size: inherit;
      margin-right: 4px;
      /* Screenreaders should ignore that kind of elements =========== */
      -webkit-alt: "";
      speak: none; }
  .icdc-angular ul ul {
    margin-top: 1rem;
    margin-bottom: 0; }
    .icdc-angular ul ul li {
      margin-bottom: 1rem;
      padding-left: 1.5rem; }
      .icdc-angular ul ul li:before {
        content: "\26AC"; }
  .icdc-angular ul ul ul li {
    padding-left: 1.5rem; }

.icdc-angular ol {
  list-style: none;
  counter-reset: list; }
  .icdc-angular ol > li {
    counter-increment: list;
    counter-reset: subsection;
    position: relative;
    margin-bottom: 3rem;
    padding-left: 4rem; }
    .icdc-angular ol > li:before {
      content: counter(list, decimal-leading-zero);
      position: absolute;
      top: 0;
      left: 0;
      font-size: 2rem;
      font-family: inherit;
      font-weight: bold;
      color: #e5291d; }
    .icdc-angular ol > li ol {
      counter-reset: sublist;
      margin: 3rem 0; }
      .icdc-angular ol > li ol li {
        counter-increment: sublist;
        padding-left: 7rem; }
        .icdc-angular ol > li ol li:before {
          content: counter(list, decimal-leading-zero) "." counter(sublist, decimal-leading-zero) ".";
          color: #e5291d; }
    .icdc-angular ol > li ol ol {
      counter-reset: subsublist; }
      .icdc-angular ol > li ol ol li {
        counter-increment: subsublist;
        padding-left: 10rem; }
        .icdc-angular ol > li ol ol li:before {
          content: counter(list, decimal-leading-zero) "." counter(sublist, decimal-leading-zero) "." counter(subsublist, decimal-leading-zero) ".";
          color: #e5291d; }

.icdc-angular ul ul, .icdc-angular ul ol, .icdc-angular ol ul, .icdc-angular ol ol {
  margin-top: 1rem;
  margin-bottom: 1rem; }

.icdc-angular dd {
  margin-bottom: 1rem;
  margin-left: 1rem; }

.icdc-angular ul.nav,
.icdc-angular .breadcrumb,
.icdc-angular .pagination,
.icdc-angular .steplist,
.icdc-angular ul.menu {
  list-style: none;
  margin: 0;
  padding: 0; }
  .icdc-angular ul.nav li,
  .icdc-angular ul.nav ul li,
  .icdc-angular .breadcrumb li,
  .icdc-angular .breadcrumb ul li,
  .icdc-angular .pagination li,
  .icdc-angular .pagination ul li,
  .icdc-angular .steplist li,
  .icdc-angular .steplist ul li,
  .icdc-angular ul.menu li,
  .icdc-angular ul.menu ul li {
    margin-bottom: 0;
    padding-left: 0; }
    .icdc-angular ul.nav li:before,
    .icdc-angular ul.nav ul li:before,
    .icdc-angular .breadcrumb li:before,
    .icdc-angular .breadcrumb ul li:before,
    .icdc-angular .pagination li:before,
    .icdc-angular .pagination ul li:before,
    .icdc-angular .steplist li:before,
    .icdc-angular .steplist ul li:before,
    .icdc-angular ul.menu li:before,
    .icdc-angular ul.menu ul li:before {
      content: none;
      margin: 0; }

.icdc-angular .table {
  margin-bottom: 3rem;
  font-size: 1.4rem; }
  .icdc-angular .table th,
  .icdc-angular .table td {
    padding: 1.5rem 1rem;
    vertical-align: middle; }
    .icdc-angular .table th .sort-label,
    .icdc-angular .table td .sort-label {
      position: relative;
      display: inline-block;
      line-height: normal;
      padding-right: 3rem; }
  .icdc-angular .table .thead-dark th, .icdc-angular .table .thead-dark td,
  .icdc-angular .table .thead-light th,
  .icdc-angular .table .thead-light td {
    position: relative;
    padding-right: 3rem;
    vertical-align: middle; }
  .icdc-angular .table .thead-dark th,
  .icdc-angular .table .thead-light th {
    background-color: #171717; }
  .icdc-angular .table .thead-dark .btn-filters,
  .icdc-angular .table .thead-light .btn-filters {
    position: absolute;
    top: 50%;
    right: 0;
    -webkit-transform: translate(0, -50%);
            transform: translate(0, -50%);
    outline-color: currentColor; }
  .icdc-angular .table .thead-light th {
    background-color: #F4F4F4;
    border: 0; }

.icdc-angular .form .table tbody th {
  position: relative; }

.icdc-angular .form .table th .form-group.cell-select-checkbox {
  margin: 0; }
  .icdc-angular .form .table th .form-group.cell-select-checkbox .custom-checkbox {
    margin-bottom: 0; }

.icdc-angular .form .table td .form-group {
  margin: 1.5rem 0; }
  .icdc-angular .form .table td .form-group + .form-group {
    margin: 3rem 0 1.5rem; }

.icdc-angular .table-recap {
  border: 0.1rem solid #E4E4E4;
  background-color: #F4F4F4; }
  @media (min-width: 768px) {
    .icdc-angular .table-recap .table {
      margin-left: auto;
      margin-right: auto;
      width: 80%; } }
  .icdc-angular .table-recap .table {
    margin-bottom: 0;
    background-color: transparent; }
  @media (min-width: 1400px) {
    .icdc-angular .table-recap tbody td,
    .icdc-angular .table-recap tfoot td {
      padding-top: 2.5rem;
      padding-bottom: 2.5rem; } }
  .icdc-angular .table-recap .table tbody td {
    border-top-style: dashed; }
  .icdc-angular .table-recap tbody tr:first-child td {
    border-top: 0; }
  .icdc-angular .table-recap tfoot {
    text-transform: uppercase;
    font-weight: 600; }
    .icdc-angular .table-recap tfoot td {
      border-top-width: 0.2rem; }

.icdc-angular .table-recap-wrapper {
  padding: 1.5rem;
  border-bottom: 0.1rem solid #E4E4E4;
  background-color: #F4F4F4; }
  .icdc-angular .table-recap-wrapper ~ .table-recap-wrapper {
    margin-top: -0.1rem;
    border-top: 0.1rem solid #E4E4E4; }
  @media (min-width: 1400px) {
    .icdc-angular .table-recap-wrapper {
      padding: 3rem 3rem 3rem 5rem; } }

.icdc-angular .main .table-recap-title {
  margin-bottom: 0;
  font-size: 1.6rem;
  font-weight: 500;
  line-height: 1; }
  .icdc-angular .main .table-recap-title::after {
    display: none; }
  .icdc-angular .main .table-recap-title span {
    padding-right: 0.4rem; }
  @media (max-width: 767.98px) {
    .icdc-angular .main .table-recap-title span {
      display: block; }
    .icdc-angular .main .table-recap-title .small,
    .icdc-angular .main .table-recap-title .table-recap-soustotal {
      padding-top: 1rem; } }
  @media (min-width: 768px) {
    .icdc-angular .main .table-recap-title {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: baseline;
              align-items: baseline; } }

.icdc-angular .table-recap-total {
  padding: 1.5rem;
  border-top: 0.2rem solid #E4E4E4; }
  @media (min-width: 1400px) {
    .icdc-angular .table-recap-total {
      padding: 3rem 3rem 3rem 5rem; } }
  .icdc-angular .table-recap-total h3 {
    margin-bottom: 0;
    font-size: 1.6rem;
    text-transform: uppercase; }
  .icdc-angular .table-recap-total span {
    float: right;
    color: #e5291d; }

.icdc-angular .table-recap-soustotal {
  margin-left: auto;
  font-size: 1.4rem;
  font-weight: 700;
  text-transform: uppercase; }
  .icdc-angular .table-recap-soustotal b {
    display: inline-block;
    padding-left: 1rem;
    font-size: 1.8rem;
    text-align: right; }
  @media (min-width: 768px) {
    .icdc-angular .table-recap-soustotal b {
      min-width: 13rem; } }

@media (min-width: 768px) {
  .icdc-angular .table-account {
    border: 0.1rem solid #E4E4E4; } }

.icdc-angular .table-account-title {
  border-bottom: 0.1rem solid #E4E4E4;
  font-size: 1.6rem !important;
  font-weight: 600 !important; }

.icdc-angular .table-account-total {
  background-color: #F4F4F4; }

@media (min-width: 768px) {
  .icdc-angular .table-account .row > [class*="col-"]:first-child {
    border-right: 0.1rem solid #E4E4E4; } }

.icdc-angular .dossier-status {
  display: -webkit-box;
  display: flex;
  -webkit-box-align: center;
          align-items: center; }
  .icdc-angular .dossier-status [class^='icon-'] {
    margin-right: 1rem;
    font-size: 2.3rem; }
    .icdc-angular .dossier-status [class^='icon-']::before {
      display: block; }
  .icdc-angular .dossier-status-title {
    margin-bottom: 0;
    font-size: 1.2rem;
    line-height: 1.3;
    text-transform: uppercase;
    font-weight: bold; }
  .icdc-angular .dossier-status-info {
    display: block;
    text-transform: none;
    font-weight: normal;
    color: #6c757d; }

.icdc-angular .tab-pane {
  padding: 2.5rem;
  border-width: 0 0.1rem 0.1rem 0.1rem;
  border-style: solid;
  border-color: #000000;
  background-color: #FFFFFF; }
  @media (min-width: 1400px) {
    .icdc-angular .tab-pane {
      padding: 5rem; } }

.icdc-angular .nav-tabs .nav-item {
  -webkit-box-flex: 1;
          flex: 1;
  display: -webkit-box;
  display: flex;
  margin-bottom: -0.1rem; }

.icdc-angular .nav-tabs .nav-link {
  -webkit-box-flex: 1;
          flex: 1;
  text-transform: uppercase;
  text-decoration: none;
  text-align: center;
  font-weight: 600;
  color: #757575;
  border-color: #E4E4E4 #E4E4E4 #CCCCCC #E4E4E4; }
  .icdc-angular .nav-tabs .nav-link--text {
    font-size: 1.4rem; }
  .icdc-angular .nav-tabs .nav-link:hover, .icdc-angular .nav-tabs .nav-link:focus {
    border-color: #e5291d #e5291d #CCCCCC; }
    .icdc-angular .nav-tabs .nav-link:hover .nav-link--text, .icdc-angular .nav-tabs .nav-link:focus .nav-link--text {
      text-decoration: underline; }

.icdc-angular .nav-tabs .nav-link.active,
.icdc-angular .nav-tabs .nav-item.show .nav-link {
  color: #454545;
  background-color: #FFFFFF;
  border-color: #454545 #454545 #FFFFFF; }

.icdc-angular .nav-tabs--connect {
  border-bottom: 0; }
  .icdc-angular .nav-tabs--connect .nav-link {
    padding-bottom: 1.4rem;
    border-width: 0 0 0.6rem 0;
    border-color: transparent; }
    .icdc-angular .nav-tabs--connect .nav-link [class^='icon'] {
      margin-right: 0.6rem;
      font-size: 150%;
      color: #e5291d; }
    @media (max-width: 767.98px) {
      .icdc-angular .nav-tabs--connect .nav-link {
        font-size: 1.4rem; }
        .icdc-angular .nav-tabs--connect .nav-link [class^='icon'] {
          display: block;
          margin: 0 0 1rem 0; } }
  .icdc-angular .nav-tabs--connect .nav-link.active,
  .icdc-angular .nav-tabs--connect .nav-item.show .nav-link {
    border-bottom-color: #e5291d; }
  .icdc-angular .nav-tabs--connect .nav-link.active {
    position: relative; }
    .icdc-angular .nav-tabs--connect .nav-link.active::after {
      content: '';
      display: block;
      position: absolute;
      top: 100%;
      left: 50%;
      -webkit-transform: translateX(-50%);
              transform: translateX(-50%);
      margin-top: 0.6rem;
      height: 0;
      width: 0;
      border-top: 1rem solid #e5291d;
      border-left: 1rem solid transparent;
      border-right: 1rem solid transparent; }
  .icdc-angular .nav-tabs--connect + .tab-content .tab-pane {
    border-width: 0; }

.icdc-angular .nav-tabs--icon .nav-link {
  text-transform: none;
  text-align: center; }
  .icdc-angular .nav-tabs--icon .nav-link [class^='icon'] {
    display: block;
    margin-bottom: 1rem;
    font-size: 310%;
    color: #CCCCCC; }

.icdc-angular .nav-tabs--icon .nav-link--text {
  position: relative;
  display: inline-block;
  margin-left: 3.2rem; }
  .icdc-angular .nav-tabs--icon .nav-link--text::before, .icdc-angular .nav-tabs--icon .nav-link--text::after {
    content: '';
    position: absolute;
    border-radius: 50%; }
  .icdc-angular .nav-tabs--icon .nav-link--text::before {
    display: block;
    top: 0.2rem;
    left: -3.2rem;
    width: 1.8rem;
    height: 1.8rem;
    border: 0.1rem solid #000000; }
  .icdc-angular .nav-tabs--icon .nav-link--text::after {
    display: none;
    top: 0.6rem;
    left: -2.8rem;
    width: 1rem;
    height: 1rem;
    background-color: #e5291d; }
  @media (max-width: 575.98px) {
    .icdc-angular .nav-tabs--icon .nav-link--text {
      padding-top: 0.3rem;
      font-size: 1.4rem; } }

.icdc-angular .nav-tabs--icon .nav-link.active [class^='icon'],
.icdc-angular .nav-tabs--icon .nav-item.show .nav-link [class^='icon'] {
  color: #e5291d; }

.icdc-angular .nav-tabs--icon .nav-link.active .nav-link--text::after,
.icdc-angular .nav-tabs--icon .nav-item.show .nav-link .nav-link--text::after {
  display: block; }

@media (max-width: 767.98px) {
  .icdc-angular .nav-tabs--default {
    display: block;
    border-color: #E4E4E4; }
    .icdc-angular .nav-tabs--default .nav-link {
      border-color: #E4E4E4; }
    .icdc-angular .nav-tabs--default .nav-link.active,
    .icdc-angular .nav-tabs--default .nav-item.show .nav-link {
      color: #FFFFFF;
      background-color: #e5291d;
      border-color: #e5291d; } }

.icdc-angular .breadcrumb {
  list-style: none;
  counter-reset: item;
  display: table;
  width: 100%;
  table-layout: fixed;
  margin-top: 1rem;
  text-align: center;
  border-top: solid 0.2rem #E4E4E4; }

.icdc-angular .breadcrumb-item {
  position: relative;
  display: table-cell;
  vertical-align: top;
  padding-top: 2rem;
  color: #6c757d; }
  .icdc-angular .breadcrumb-item.active, .icdc-angular .breadcrumb-item.complete {
    color: #454545; }
    .icdc-angular .breadcrumb-item.active .breadcrumb-item-inner::after,
    .icdc-angular .breadcrumb-item.active .breadcrumb-item-separator::before, .icdc-angular .breadcrumb-item.complete .breadcrumb-item-inner::after,
    .icdc-angular .breadcrumb-item.complete .breadcrumb-item-separator::before {
      background-color: #e5291d; }
  .icdc-angular .breadcrumb-item.complete .breadcrumb-item-inner:after {
    content: "";
    font-family: "bdt" !important;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    font-size: inherit;
    color: inherit;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-alt: "";
    speak: none;
    font-size: 0.7rem;
    line-height: 20px;
    color: #FFFFFF; }
  .icdc-angular .breadcrumb-item.complete .breadcrumb-item-separator::after {
    background-color: #e5291d; }

.icdc-angular .breadcrumb-item-separator::before, .icdc-angular .breadcrumb-item-separator::after {
  content: "";
  position: absolute;
  top: -0.2rem;
  height: 0.2rem; }

.icdc-angular .breadcrumb-item-separator::before {
  left: 0;
  right: 50%; }

.icdc-angular .breadcrumb-item-separator::after {
  left: 50%;
  right: 0; }

.icdc-angular .breadcrumb-item-inner {
  display: block; }
  .icdc-angular .breadcrumb-item-inner::before {
    content: counter(item, decimal-leading-zero);
    counter-increment: item;
    display: block;
    font-weight: 700; }
  .icdc-angular .breadcrumb-item-inner::after {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1;
    display: block;
    margin: 0 auto 1rem auto;
    width: 2rem;
    height: 2rem;
    -webkit-transform: translate(0, -1rem);
            transform: translate(0, -1rem);
    border-radius: 100%;
    background-color: #E4E4E4; }

.icdc-angular a.breadcrumb-item-inner {
  text-decoration: none !important; }
  .icdc-angular a.breadcrumb-item-inner:hover, .icdc-angular a.breadcrumb-item-inner:active {
    text-decoration: underline  !important; }
  .icdc-angular a.breadcrumb-item-inner:focus {
    text-decoration: none !important; }

@media (max-width: 767.98px) {
  .icdc-angular .breadcrumb-item:not(.active) .breadcrumb-item-title {
    opacity: 0; } }

@media (min-width: 768px) {
  .icdc-angular .breadcrumb {
    margin-bottom: 2.5rem; } }

@media (min-width: 1400px) {
  .icdc-angular .breadcrumb {
    margin-bottom: 5rem; } }

.icdc-angular .block-persona {
  display: -webkit-box;
  display: flex; }
  .icdc-angular .block-persona--img {
    width: 7.5rem;
    border-right: 2.4rem solid transparent; }
    .icdc-angular .block-persona--img img {
      max-width: 100%;
      height: auto;
      border-radius: 50%; }
  .icdc-angular .block-persona p span {
    display: block;
    font-weight: 800;
    font-size: 2.6rem;
    line-height: 1.125; }
    .icdc-angular .block-persona p span:first-child {
      font-size: 1.4rem; }
  .icdc-angular .block-persona a {
    text-decoration: none; }
    .icdc-angular .block-persona a span + span {
      text-decoration: underline; }

.icdc-angular .block-bordered {
  position: relative;
  margin-bottom: 2rem;
  padding: 1.6rem; }
  .icdc-angular .block-bordered p:last-child {
    margin-bottom: 0; }
  .icdc-angular .block-bordered .btn-pos-right {
    position: absolute;
    top: 1rem;
    right: 1rem; }
    .icdc-angular .block-bordered .btn-pos-right.btn-actions {
      top: 0.5rem; }
  .icdc-angular .block-bordered-prestation {
    padding-bottom: 0.1rem !important;
    margin-bottom: 3rem;
    border-top: 0.1rem dashed #E4E4E4;
    border-bottom: 0.1rem dashed #E4E4E4; }
    .icdc-angular .block-bordered-prestation + .block-bordered {
      margin-top: -3.1rem; }
    .icdc-angular .block-bordered-prestation .block-recap--total {
      padding: 0 0 2rem 0;
      border-top-width: 0; }
  .icdc-angular .block-bordered-dotted {
    border-style: dotted; }

.icdc-angular .collapse-mx-negative {
  margin-left: -1.6rem;
  margin-right: -1.6rem; }

@media (min-width: 992px) {
  .icdc-angular .block-bordered {
    padding: 1.6rem; }
    .icdc-angular .block-bordered .btn-pos-right {
      top: 2.5rem;
      right: 1.6rem; }
      .icdc-angular .block-bordered .btn-pos-right.btn-actions {
        top: 2rem; }
  .icdc-angular .collapse-mx-negative {
    margin-left: -1.6rem;
    margin-right: -1.6rem; } }

@media (min-width: 1400px) {
  .icdc-angular .block-bordered {
    padding: 3rem; }
    .icdc-angular .block-bordered .btn-pos-right {
      right: 3rem; }
    .icdc-angular .block-bordered-xl {
      padding: 4.4rem 5.4rem; }
  .icdc-angular .collapse-mx-negative {
    margin-left: -3rem;
    margin-right: -3rem; } }

.icdc-angular .block-highlight-link {
  margin-bottom: 2rem; }
  .icdc-angular .block-highlight-link > a {
    position: relative;
    display: block;
    padding: 1.5rem 1.5rem 1.5rem 3rem;
    background-color: #e5291d;
    color: #FFFFFF;
    -webkit-transition: background-color 0.3s ease;
    transition: background-color 0.3s ease;
    text-decoration: none !important; }
    .icdc-angular .block-highlight-link > a:before {
      content: "";
      font-family: "bdt" !important;
      font-style: normal;
      font-weight: normal;
      font-variant: normal;
      text-transform: none;
      line-height: 1;
      font-size: inherit;
      color: inherit;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      -webkit-alt: "";
      speak: none;
      position: absolute;
      top: 2rem;
      left: 1.3rem;
      font-size: 1rem; }
    .icdc-angular .block-highlight-link > a:hover, .icdc-angular .block-highlight-link > a:active {
      text-decoration: underline  !important; }
    .icdc-angular .block-highlight-link > a:focus {
      text-decoration: none !important; }
    .icdc-angular .block-highlight-link > a:hover, .icdc-angular .block-highlight-link > a:focus {
      background-color: #B90D0D; }
  @media (min-width: 576px) {
    .icdc-angular .block-highlight-link > a {
      padding: 3.5rem 3.5rem 3.5rem 4rem; }
      .icdc-angular .block-highlight-link > a::before {
        top: 4rem;
        left: 2.3rem; } }

.icdc-angular .block-search-and-add-item {
  display: -webkit-box;
  display: flex;
  flex-wrap: wrap;
  margin-right: -1.5rem;
  margin-left: -1.5rem;
  -webkit-box-align: center;
          align-items: center; }
  .icdc-angular .block-search-and-add-item--input, .icdc-angular .block-search-and-add-item--text, .icdc-angular .block-search-and-add-item--button {
    position: relative;
    width: 100%;
    min-height: 1px;
    padding-right: 1.5rem;
    padding-left: 1.5rem; }
  .icdc-angular .block-search-and-add-item--text {
    padding: 1rem;
    font-weight: 700;
    text-transform: uppercase;
    text-align: center; }
    .icdc-angular .block-search-and-add-item--text p {
      margin-bottom: 0; }
  .icdc-angular .block-search-and-add-item--button .btn, .icdc-angular .block-search-and-add-item--button .region-header-right .nav-link-user > a, .region-header-right .icdc-angular .block-search-and-add-item--button .nav-link-user > a,
  .icdc-angular .block-search-and-add-item--button .region-header-right .nav-link-user > button, .region-header-right .icdc-angular .block-search-and-add-item--button .nav-link-user > button {
    display: block;
    width: 100%; }
  .icdc-angular .block-search-and-add-item .form-group {
    margin-bottom: 0; }
  .icdc-angular .block-search-and-add-item .btn, .icdc-angular .block-search-and-add-item .region-header-right .nav-link-user > a, .region-header-right .icdc-angular .block-search-and-add-item .nav-link-user > a,
  .icdc-angular .block-search-and-add-item .region-header-right .nav-link-user > button, .region-header-right .icdc-angular .block-search-and-add-item .nav-link-user > button {
    font-size: 1.4rem; }
  .icdc-angular .block-search-and-add-item [class^='icon-'] {
    font-size: 2.3rem; }
  .icdc-angular .block-search-and-add-item .float-target-parent:not(.focused) label, .icdc-angular .block-search-and-add-item .form-has-floatlabel .js-form-type-search:not(.focused) label, .form-has-floatlabel .icdc-angular .block-search-and-add-item .js-form-type-search:not(.focused) label, .icdc-angular .block-search-and-add-item .form-has-floatlabel .js-form-item-field-tra-geography:not(.focused) label, .form-has-floatlabel .icdc-angular .block-search-and-add-item .js-form-item-field-tra-geography:not(.focused) label {
    max-width: calc(100% - 2.2rem*2 - 9rem); }

.icdc-angular .form-search-and-add-item {
  margin: 2rem 0; }
  .icdc-angular .form-search-and-add-item.disabled {
    position: relative; }
    .icdc-angular .form-search-and-add-item.disabled::before {
      content: "";
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      z-index: 10;
      pointer-events: none; }
    .icdc-angular .form-search-and-add-item.disabled .btn, .icdc-angular .form-search-and-add-item.disabled .region-header-right .nav-link-user > a, .region-header-right .icdc-angular .form-search-and-add-item.disabled .nav-link-user > a,
    .icdc-angular .form-search-and-add-item.disabled .region-header-right .nav-link-user > button, .region-header-right .icdc-angular .form-search-and-add-item.disabled .nav-link-user > button {
      background-color: #CCCCCC;
      border-color: #CCCCCC;
      color: #000000; }
    .icdc-angular .form-search-and-add-item.disabled label {
      color: #495057; }

@media (min-width: 992px) {
  .icdc-angular .block-search-and-add-item--input {
    -webkit-box-flex: 0;
            flex: 0 0 58.33333%;
    max-width: 58.33333%; }
  .icdc-angular .block-search-and-add-item--text {
    -webkit-box-flex: 0;
            flex: 0 0 8.33333%;
    max-width: 8.33333%; }
  .icdc-angular .block-search-and-add-item--button {
    -webkit-box-flex: 0;
            flex: 0 0 33.33333%;
    max-width: 33.33333%; } }

@media (min-width: 1400px) {
  .icdc-angular .form-search-and-add-item {
    margin: 5rem 0; } }

.icdc-angular .block-ordered-list-wrapper {
  display: block; }
  .icdc-angular .block-ordered-list-wrapper .inner {
    display: -webkit-box;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
            flex-direction: column;
    width: 100%;
    height: 100%;
    -webkit-box-align: center;
            align-items: center; }
  .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li {
    position: relative;
    display: -webkit-box;
    display: flex;
    -webkit-box-align: end;
            align-items: flex-end;
    height: 5rem;
    width: 14rem;
    margin-bottom: 0;
    padding-left: 0;
    list-style-type: none;
    border-width: 0 0 0.2rem 0;
    border-style: dotted;
    border-color: #CCCCCC;
    font-weight: 600;
    text-align: center;
    font-size: 2.2rem; }
    @media (max-width: 1199.98px) {
      .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li {
        width: 18rem; } }
    .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li .amount {
      width: 100%;
      -webkit-transform: translateY(1.4rem);
              transform: translateY(1.4rem);
      background-color: #FFFFFF; }
      .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li .amount:empty + .euro-sign::after {
        content: "€";
        position: absolute;
        bottom: -1.4rem;
        right: -3rem; }
      .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li .amount:not(:empty) + .euro-sign::after {
        content: "€";
        position: absolute;
        bottom: -1.4rem;
        right: -3rem; }
    .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li::before {
      position: absolute;
      top: auto;
      bottom: -1.1rem;
      left: -3.8rem;
      line-height: 2.5rem;
      height: 2.5rem;
      width: 2.5rem;
      font-size: 1.4rem;
      line-height: 2.6rem;
      border-radius: 50%;
      background-color: #F4F4F4;
      color: #757575; }
    .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li:nth-of-type(1)::before {
      content: "1"; }
    .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li:nth-of-type(2)::before {
      content: "2"; }
    .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li:nth-of-type(3)::before {
      content: "3"; }
    .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li:nth-of-type(4)::before {
      content: "4"; }
    .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li:nth-of-type(5)::before {
      content: "5"; }
    .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li:nth-of-type(6)::before {
      content: "6"; }
    .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li:nth-of-type(7)::before {
      content: "7"; }
    .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li:nth-of-type(8)::before {
      content: "8"; }
    .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li:nth-of-type(9)::before {
      content: "9"; }
    .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li:nth-of-type(10)::before {
      content: "10"; }
    .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li:nth-of-type(11)::before {
      content: "11"; }
    .icdc-angular .block-ordered-list-wrapper .block-ordered-list > li:nth-of-type(12)::before {
      content: "12"; }

.icdc-angular .block-upload-file {
  display: -webkit-box;
  display: flex;
  flex-wrap: wrap;
  margin-right: -1.5rem;
  margin-left: -1.5rem; }
  .icdc-angular .block-upload-file--item {
    position: relative;
    width: 100%;
    min-height: 1px;
    padding-right: 1.5rem;
    padding-left: 1.5rem;
    -webkit-box-flex: 0;
            flex: 0 0 50%;
    max-width: 50%;
    display: -webkit-box;
    display: flex;
    -webkit-box-align: start;
            align-items: flex-start;
    margin-bottom: 2rem; }
    @media (min-width: 1200px) {
      .icdc-angular .block-upload-file--item {
        -webkit-box-flex: 0;
                flex: 0 0 25%;
        max-width: 25%;
        margin-bottom: 0; } }
  .icdc-angular .block-upload-file--button {
    -webkit-appearance: none;
       -moz-appearance: none;
            appearance: none;
    margin: 0;
    padding: 0;
    border: 0;
    background: none;
    position: relative;
    display: block;
    width: 100%;
    padding: 2rem;
    text-align: center;
    text-decoration: none;
    cursor: pointer;
    -webkit-transition: -webkit-transform 0.5s ease;
    transition: -webkit-transform 0.5s ease;
    transition: transform 0.5s ease;
    transition: transform 0.5s ease, -webkit-transform 0.5s ease; }
    .icdc-angular .block-upload-file--button:focus {
      outline: 0.1rem dashed #757575;
      outline-offset: 0.4rem; }
    .icdc-angular .block-upload-file--button:after {
      content: "";
      font-family: "bdt" !important;
      font-style: normal;
      font-weight: normal;
      font-variant: normal;
      text-transform: none;
      line-height: 1;
      font-size: inherit;
      color: inherit;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      -webkit-alt: "";
      speak: none;
      opacity: 0;
      display: block;
      margin-top: 1rem;
      font-size: 2.6rem;
      color: #e5291d;
      -webkit-transition: opacity 0.5s ease;
      transition: opacity 0.5s ease; }
    .icdc-angular .block-upload-file--button [class^='icon-'] {
      display: block;
      margin-bottom: 1rem;
      font-size: 450%;
      color: #e5291d; }
      .icdc-angular .block-upload-file--button [class^='icon-']::before {
        display: block; }
    .icdc-angular .block-upload-file--button:hover, .icdc-angular .block-upload-file--button:focus {
      z-index: 1;
      -webkit-transform: scale(1.05);
              transform: scale(1.05);
      box-shadow: 0 0 1.5rem 0 rgba(0, 0, 0, 0.1); }
      .icdc-angular .block-upload-file--button:hover::after, .icdc-angular .block-upload-file--button:focus::after {
        opacity: 1; }
    .icdc-angular .block-upload-file--button:focus {
      outline-offset: 0; }
    @media (min-width: 992px) {
      .icdc-angular .block-upload-file--button {
        padding: 5rem 3rem; } }
  .icdc-angular .block-upload-file--title {
    font-size: 1.4rem;
    font-weight: 700; }
  .icdc-angular .block-upload-file--uploaded {
    width: 100%;
    text-align: center; }
    .icdc-angular .block-upload-file--uploaded-title {
      margin-bottom: 2rem;
      font-size: 1.7rem;
      font-weight: 700; }
    .icdc-angular .block-upload-file--uploaded-rename {
      margin-top: -2.5rem; }
      .icdc-angular .block-upload-file--uploaded-rename .btn-link {
        margin: auto;
        font-size: 1.1rem;
        text-decoration: underline; }
      .icdc-angular .block-upload-file--uploaded-rename [class^='icon-'] {
        font-size: 0.7rem; }
    .icdc-angular .block-upload-file--uploaded-item {
      max-width: 13rem;
      margin-left: auto;
      margin-right: auto; }
    .icdc-angular .block-upload-file--uploaded-img {
      position: relative;
      display: inline-block;
      margin-bottom: 1rem; }
      .icdc-angular .block-upload-file--uploaded-img img {
        border: 0.2rem solid #E4E4E4; }
    .icdc-angular .block-upload-file--uploaded-img-btn {
      position: absolute;
      right: 0.2rem;
      bottom: 0.2rem;
      padding: 0;
      width: 5rem;
      height: 5rem;
      font-size: 2rem; }
      .icdc-angular .block-upload-file--uploaded-img-btn [class^='icon-'] {
        line-height: inherit; }
    .icdc-angular .block-upload-file--uploaded-actions {
      display: -webkit-box;
      display: flex;
      flex-wrap: wrap; }
      .icdc-angular .block-upload-file--uploaded-actions .icon-check {
        margin-right: auto;
        color: #AFCD50; }
      .icdc-angular .block-upload-file--uploaded-actions .btn-actions {
        margin-top: -1rem; }

@media (min-width: 1200px) {
  .icdc-angular .block-upload-file--xs .block-upload-file--item {
    -webkit-box-flex: 0;
            flex: 0 0 33.33333%;
    max-width: 33.33333%; } }

.icdc-angular .block-upload-file--xs .block-upload-file--button {
  padding: 1rem; }

@-webkit-keyframes pulse {
  to {
    box-shadow: 0 0 0 20px rgba(232, 76, 61, 0); } }

@keyframes pulse {
  to {
    box-shadow: 0 0 0 20px rgba(232, 76, 61, 0); } }

.icdc-angular .block-upload-and-drag {
  padding: 3rem;
  text-align: center;
  border: dashed 0.1rem #E4E4E4;
  box-shadow: 0 0 0 0 rgba(232, 76, 61, 0.7);
  -webkit-transition: all 1.25s ease;
  transition: all 1.25s ease; }
  .icdc-angular .block-upload-and-drag.is-hover {
    background-color: #F4F4F4;
    border-color: #e5291d;
    -webkit-animation: pulse 1.25s infinite cubic-bezier(0.66, 0, 0, 1);
            animation: pulse 1.25s infinite cubic-bezier(0.66, 0, 0, 1); }

.icdc-angular .block-upload-and-drag--drag [class^='icon-'] {
  display: block;
  margin-bottom: 1.8rem;
  font-size: 10rem;
  color: #e5291d; }
  .icdc-angular .block-upload-and-drag--drag [class^='icon-']::before {
    display: block; }

.icdc-angular .block-upload-and-drag--drag p {
  margin-bottom: 0;
  font-size: 2rem;
  font-weight: 700;
  text-transform: uppercase; }

.icdc-angular .block-upload-and-drag--text p {
  margin-bottom: 1rem; }

.icdc-angular .block-upload-and-drag--upload input:focus + label {
  outline: 0.1rem dashed #e5291d;
  outline-offset: 0.4rem; }

.icdc-angular .block-upload-and-drag-description {
  margin-top: 4rem; }

.icdc-angular .block-upload-and-drag--file-item {
  position: relative;
  -webkit-box-flex: 1;
          flex-grow: 1; }
  .icdc-angular .block-upload-and-drag--file-item .btn, .icdc-angular .block-upload-and-drag--file-item .region-header-right .nav-link-user > a, .region-header-right .icdc-angular .block-upload-and-drag--file-item .nav-link-user > a,
  .icdc-angular .block-upload-and-drag--file-item .region-header-right .nav-link-user > button, .region-header-right .icdc-angular .block-upload-and-drag--file-item .nav-link-user > button {
    position: absolute;
    top: 0;
    right: 0; }

.icdc-angular .block-upload-and-drag--file {
  margin: 0 0 2rem 0;
  display: -webkit-box;
  display: flex;
  -webkit-box-align: start;
          align-items: flex-start;
  text-align: left; }
  .icdc-angular .block-upload-and-drag--file > [class^='icon-'] {
    display: none;
    margin-right: 1.5rem;
    font-size: 12.3rem;
    color: #E4E4E4; }

.icdc-angular .block-upload-and-drag--file-name {
  margin-bottom: 0;
  font-weight: 700; }

.icdc-angular .block-upload-and-drag--file-weight {
  display: block;
  margin-bottom: 2rem;
  font-size: 1.1rem;
  color: #757575; }

@media (min-width: 992px) {
  .icdc-angular .block-upload-and-drag--file {
    max-width: 70rem;
    margin: 3rem auto 0 auto; }
    .icdc-angular .block-upload-and-drag--file > [class^='icon-'] {
      display: block; } }

.icdc-angular .block-create-account-item {
  display: -webkit-box;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
          flex-direction: column;
  -webkit-box-align: start;
          align-items: flex-start; }
  .icdc-angular .block-create-account-item--title {
    margin-bottom: 1rem; }
    @media (max-width: 767.98px) {
      .icdc-angular .block-create-account-item--title {
        font-size: 1.6rem; } }
  .icdc-angular .block-create-account-item--info {
    margin-bottom: 0;
    font-size: 1.4rem;
    word-break: break-all; }
  .icdc-angular .block-create-account-item--status {
    margin-top: 1rem;
    margin-right: 1rem;
    padding: 0.4rem 0.8rem;
    font-size: 1.4rem;
    font-weight: 700;
    text-transform: uppercase;
    color: #FFFFFF; }
    .icdc-angular .block-create-account-item--status:hover .infobulle {
      display: block; }
    .icdc-angular .block-create-account-item--status .infobulle {
      display: none;
      position: absolute;
      bottom: 100%;
      left: 0%;
      margin-left: -37px;
      margin-bottom: 0.4rem;
      padding: 0.4rem 0rem;
      width: 140px;
      background-color: #000000;
      font-size: 1rem;
      text-align: center;
      color: #FFFFFF !important; }
      .icdc-angular .block-create-account-item--status .infobulle::after {
        content: '';
        display: block;
        position: absolute;
        top: 100%;
        left: 50%;
        margin-left: -5px;
        height: 0;
        width: 0;
        border-top: 5px solid #000000;
        border-left: 5px solid transparent;
        border-right: 5px solid transparent; }
  .icdc-angular .block-create-account-item--actions {
    display: -webkit-box;
    display: flex;
    flex-shrink: 0;
    -webkit-box-align: start;
            align-items: flex-start; }
    .icdc-angular .block-create-account-item--actions .btn-actions {
      padding: 0.5rem 1rem;
      font-size: 2.4rem;
      border: 0.1rem solid #E4E4E4; }
    .icdc-angular .block-create-account-item--actions .btn-actions + .btn-actions {
      margin-left: 1rem; }
  .icdc-angular .block-create-account-item--toggle-wrapper {
    margin-bottom: 2rem;
    padding-right: 3rem; }
  .icdc-angular .block-create-account-item--toggle {
    position: relative;
    margin-bottom: 0;
    padding-right: 4rem;
    -webkit-transition: background-color 0.3s ease;
    transition: background-color 0.3s ease; }
    .icdc-angular .block-create-account-item--toggle .block-create-account-item--title {
      margin-bottom: 0; }
    .icdc-angular .block-create-account-item--toggle .block-create-account-item--status {
      position: absolute;
      top: 50%;
      left: 100%;
      -webkit-transform: translate(0, -50%);
              transform: translate(0, -50%);
      padding-left: 1rem;
      font-size: 2rem; }
    .icdc-angular .block-create-account-item--toggle .btn-toggle-collapse {
      position: absolute;
      top: 1.5rem;
      right: 1rem; }
  .icdc-angular .block-create-account-item--collapse {
    margin-top: -0.1rem;
    margin-bottom: 0; }
  .icdc-angular .block-create-account-item--suivi-toggle-wrapper {
    margin-bottom: 3rem; }
  .icdc-angular .block-create-account-item--suivi {
    background-color: #F4F4F4; }
    .icdc-angular .block-create-account-item--suivi .dossier-status .dossier-status-info {
      color: inherit; }
    .icdc-angular .block-create-account-item--suivi .dossier-status .icon-traitement-en-cours {
      color: #e5291d; }
    .icdc-angular .block-create-account-item--suivi .dossier-status .icon-demande-validee {
      color: #AFCD50; }
    .icdc-angular .block-create-account-item--suivi.opened {
      background-color: #e5291d;
      color: #FFFFFF; }
      .icdc-angular .block-create-account-item--suivi.opened .dossier-status,
      .icdc-angular .block-create-account-item--suivi.opened .block-create-account-item--actions {
        border-left-color: rgba(255, 255, 255, 0.4); }
      .icdc-angular .block-create-account-item--suivi.opened .dossier-status .icon-traitement-en-cours,
      .icdc-angular .block-create-account-item--suivi.opened .dossier-status .icon-demande-validee {
        color: inherit; }
      .icdc-angular .block-create-account-item--suivi.opened .btn-actions {
        outline-color: #FFFFFF; }
  .icdc-angular .block-create-account-item .block-create-account-item--actions,
  .icdc-angular .block-create-account-item .dossier-status {
    margin-top: 1rem; }

@media (min-width: 576px) {
  .icdc-angular .block-create-account-item--toggle .btn-toggle-collapse {
    top: 50%;
    -webkit-transform: translate(0, -50%);
            transform: translate(0, -50%); }
  .icdc-angular .block-create-account-item--suivi-collapse-wrapper > .block-bordered {
    padding: 1.5rem 2rem; } }

@media (min-width: 768px) {
  .icdc-angular .block-create-account-item--toggle-wrapper {
    padding-right: 0; }
  .icdc-angular .block-create-account-item--toggle .block-create-account-item--status {
    padding-left: 2rem;
    font-size: 2.5rem; } }

@media (min-width: 992px) {
  .icdc-angular .block-create-account-item {
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
            flex-direction: row;
    -webkit-box-align: center;
            align-items: center; }
    .icdc-angular .block-create-account-item--suivi {
      padding-top: 0;
      padding-bottom: 0;
      -webkit-box-align: stretch;
              align-items: stretch; }
      .icdc-angular .block-create-account-item--suivi .block-create-account-item--infos,
      .icdc-angular .block-create-account-item--suivi .dossier-status,
      .icdc-angular .block-create-account-item--suivi .block-create-account-item--actions {
        display: -webkit-box;
        display: flex;
        -webkit-box-align: center;
                align-items: center;
        padding-top: 1.5rem;
        padding-bottom: 1.5rem; }
      .icdc-angular .block-create-account-item--suivi .dossier-status,
      .icdc-angular .block-create-account-item--suivi .block-create-account-item--actions {
        border-left: 0.1rem solid #E4E4E4; }
      .icdc-angular .block-create-account-item--suivi .dossier-status {
        margin-left: auto;
        padding-left: 2rem;
        padding-right: 2rem; }
      .icdc-angular .block-create-account-item--suivi .dossier-status + .block-create-account-item--actions {
        margin-left: 0; }
    .icdc-angular .block-create-account-item--status {
      margin-top: 0.5rem; }
    .icdc-angular .block-create-account-item--actions {
      margin-left: auto;
      padding-left: 2rem; }
      .icdc-angular .block-create-account-item--actions .btn-actions {
        padding: 0.5rem;
        font-size: 2rem;
        border: none; }
      .icdc-angular .block-create-account-item--actions .btn-actions + .btn-actions {
        margin-left: 0rem; }
    .icdc-angular .block-create-account-item .block-create-account-item--actions,
    .icdc-angular .block-create-account-item .dossier-status {
      margin-top: 0rem; } }

@media (max-width: 575.98px) {
  .icdc-angular .block-create-account-item {
    flex-wrap: wrap; }
    .icdc-angular .block-create-account-item--title {
      font-size: 1.6rem; }
    .icdc-angular .block-create-account-item--suivi {
      display: block; }
      .icdc-angular .block-create-account-item--suivi .dossier-status {
        margin: 1rem 0; } }

.icdc-angular .block-recap {
  padding: 2rem; }
  .icdc-angular .block-recap--title {
    margin-bottom: 0rem;
    padding: 0.5rem 1rem 1.5rem 1rem;
    border-bottom: 0.1rem solid #E4E4E4; }
  .icdc-angular .block-recap--item-wrapper {
    position: relative;
    overflow-y: auto;
    max-height: 40rem; }
  .icdc-angular .block-recap--item {
    position: relative;
    margin: 0 0 0 1.5rem;
    padding: 1.5rem 1.5rem 1.5rem 0;
    border-bottom: 0.1rem dashed #ced4da; }
    .icdc-angular .block-recap--item:last-of-type {
      border-bottom: 0; }
    .icdc-angular .block-recap--item-title {
      margin-bottom: 0.3rem;
      padding-right: 5rem;
      font-size: 1.6rem;
      font-weight: 500;
      overflow-wrap: break-word;
      word-wrap: break-word;
      -webkit-hyphens: auto;
      -ms-hyphens: auto;
      hyphens: auto; }
    .icdc-angular .block-recap--item-info {
      margin-bottom: 0;
      padding-left: 1.5rem;
      font-size: 1.2rem; }
    .icdc-angular .block-recap--item-total {
      position: absolute;
      top: 1.5rem;
      right: 1.5rem;
      font-size: 1.4rem;
      font-weight: 600;
      color: #757575; }
  .icdc-angular .block-recap--total {
    margin-bottom: 0;
    padding: 2.5rem 1.5rem 1rem 1rem;
    font-size: 1.4rem;
    text-transform: uppercase;
    border-top: 0.1rem solid #E4E4E4; }
    .icdc-angular .block-recap--total-nb {
      margin-left: auto;
      font-size: 1.8rem; }
      .icdc-angular .block-recap--total-nb span {
        display: block;
        font-size: 1.2rem;
        font-weight: 500;
        text-transform: none; }
  @media (min-width: 576px) {
    .icdc-angular .block-recap--total {
      display: -webkit-box;
      display: flex;
      -webkit-box-align: baseline;
              align-items: baseline; } }
  @media (max-width: 575.98px) {
    .icdc-angular .block-recap--total {
      text-align: right; }
      .icdc-angular .block-recap--total-nb {
        display: block;
        margin-top: 1.5rem; } }

.icdc-angular .block-video {
  margin-bottom: 4rem; }
  .icdc-angular .block-video--video {
    margin-bottom: 2rem; }
  .icdc-angular .block-video--transcription .btn-download {
    display: inline-block;
    padding-left: 1.5rem;
    font-size: 1.4rem;
    text-transform: none; }
    .icdc-angular .block-video--transcription .btn-download:before {
      content: "";
      top: 0.6rem;
      font-size: 0.8rem; }
    .icdc-angular .block-video--transcription .btn-download span,
    .icdc-angular .block-video--transcription .btn-download small {
      display: inline-block; }

.icdc-angular .block-return-link {
  position: relative; }
  .icdc-angular .block-return-link span.icon-arrow_left {
    font-size: 0.9rem; }
  .icdc-angular .block-return-link a {
    display: inline-block;
    color: #e5291d;
    text-decoration: none;
    font-size: 1.2rem;
    font-weight: 600;
    padding: 2rem 0 2rem 1.8rem;
    -webkit-transition: color 0.3s ease-in-out;
    transition: color 0.3s ease-in-out; }
    .icdc-angular .block-return-link a:before {
      content: "";
      font-family: "bdt" !important;
      font-style: normal;
      font-weight: normal;
      font-variant: normal;
      text-transform: none;
      line-height: 1;
      font-size: inherit;
      color: inherit;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      -webkit-alt: "";
      speak: none;
      position: absolute;
      top: 2.2rem;
      left: 0;
      font-size: 0.9rem;
      color: #e5291d;
      text-decoration: none;
      -webkit-transition: color 0.3s ease-in-out;
      transition: color 0.3s ease-in-out; }
    .icdc-angular .block-return-link a:hover, .icdc-angular .block-return-link a:focus {
      color: #ba1f15;
      -webkit-transition: color 0.3s ease-in-out;
      transition: color 0.3s ease-in-out; }
      .icdc-angular .block-return-link a:hover::before, .icdc-angular .block-return-link a:focus::before {
        color: #ba1f15;
        -webkit-transition: color 0.3s ease-in-out;
        transition: color 0.3s ease-in-out; }

.icdc-angular .dropdown-toggle:after {
  content: "";
  font-family: "bdt" !important;
  font-style: normal;
  font-weight: normal;
  font-variant: normal;
  text-transform: none;
  line-height: 1;
  font-size: inherit;
  color: inherit;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  -webkit-alt: "";
  speak: none;
  margin-left: 1rem;
  width: auto;
  height: auto;
  font-size: 60%;
  border: 0;
  -webkit-transition: -webkit-transform 250ms ease;
  transition: -webkit-transform 250ms ease;
  transition: transform 250ms ease;
  transition: transform 250ms ease, -webkit-transform 250ms ease; }

.icdc-angular .dropdown-toggle[aria-expanded="true"]::after {
  -webkit-transform: rotate(180deg);
          transform: rotate(180deg); }

.icdc-angular .close {
  text-transform: uppercase;
  opacity: 1; }
  .icdc-angular .close span {
    display: inline-block;
    vertical-align: middle; }
  .icdc-angular .close [class^='icon-'] {
    color: #e5291d; }
  .icdc-angular .close:not(:disabled):not(.disabled):hover, .icdc-angular .close:not(:disabled):not(.disabled):focus {
    opacity: 1; }

.icdc-angular .modal-content {
  padding: 3rem; }
  .icdc-angular .modal-content h2 {
    margin-bottom: 2rem; }

.icdc-angular .modal-header {
  padding-bottom: 2rem;
  -webkit-box-pack: end;
          justify-content: flex-end; }
  .icdc-angular .modal-header .close {
    margin-left: 2rem;
    white-space: nowrap; }
    .icdc-angular .modal-header .close .icon-fermer::before {
      line-height: 2;
      font-size: 1.1rem; }
    .icdc-angular .modal-header .close .btn-text {
      font-size: 1.1rem; }

.icdc-angular .modal-title {
  margin-bottom: 0; }

.icdc-angular .modal-footer {
  padding-top: 4.5rem;
  -webkit-box-pack: start;
          justify-content: flex-start; }

.icdc-angular .modal-small-size .modal-dialog {
  max-width: 55rem; }

.icdc-angular .modal-full-size .modal-dialog {
  max-width: calc(100% - 10rem);
  height: calc(100% - 10rem); }
  .icdc-angular .modal-full-size .modal-dialog .modal-content {
    height: calc(100% - 10rem); }

@media (min-width: 992px) {
  .icdc-angular .modal:not(.a11y-config) .modal-content {
    padding: 5rem 7rem 7rem 7rem; } }

@media (min-width: 1200px) {
  .icdc-angular .modal-lg {
    max-width: 99.5rem; } }

.icdc-angular .block-code-problem {
  margin-top: 5rem;
  padding-top: 4rem;
  border-top: dashed 0.1rem #ced4da; }
  .icdc-angular .block-code-problem h3 {
    margin-bottom: 0;
    font-size: 1.7rem;
    text-transform: uppercase; }
  .icdc-angular .block-code-problem .form-group {
    margin-bottom: 1.5rem; }

.icdc-angular .progress-wrapper {
  margin: 2rem 0; }

.icdc-angular .progress-nb {
  margin-top: 2rem;
  color: #757575; }

.icdc-angular .pagination {
  margin: 0 0 6rem 0;
  flex-wrap: wrap; }
  .icdc-angular .pagination .page-link {
    width: 50px;
    height: 50px;
    text-align: center;
    text-decoration: none;
    -webkit-transition: background-color 250ms ease;
    transition: background-color 250ms ease; }
  .icdc-angular .pagination [class^="icon"] {
    font-size: 1.1rem; }
  .icdc-angular .pagination .page-item.active .page-link {
    position: relative;
    font-weight: 700; }
    .icdc-angular .pagination .page-item.active .page-link::after {
      content: '';
      position: absolute;
      bottom: .6rem;
      left: 50%;
      margin-left: -.2rem;
      width: .4rem;
      height: .4rem;
      font-size: 2rem;
      border-radius: 50%;
      background-color: #e5291d; }

.icdc-angular .steplist {
  list-style: none;
  counter-reset: item; }

.icdc-angular .steplist-item {
  color: #E4E4E4; }
  .icdc-angular .steplist-item [class^="icon"] {
    margin-right: 1rem;
    font-size: 2.5rem;
    line-height: 1; }
  .icdc-angular .steplist-item:last-child .steplist-item-line::before, .icdc-angular .steplist-item:last-child .steplist-item-line::after {
    content: none; }
  .icdc-angular .steplist-item.complete,
  .icdc-angular .steplist-item.complete .steplist-item-title {
    color: #AFCD50; }
  .icdc-angular .steplist-item.active,
  .icdc-angular .steplist-item.active .steplist-item-title {
    color: #454545; }

.icdc-angular .steplist-item-inner {
  display: -webkit-box;
  display: flex;
  -webkit-box-align: center;
          align-items: center; }

.icdc-angular .steplist-item-title {
  margin-bottom: 0;
  font-size: 1.2rem;
  line-height: normal;
  color: #757575; }
  .icdc-angular .steplist-item-title::before {
    content: counter(item, decimal-leading-zero);
    counter-increment: item;
    display: block;
    font-weight: 700;
    font-size: 1.7rem; }

.icdc-angular .steplist-item-line::before, .icdc-angular .steplist-item-line::after {
  content: " ";
  position: absolute;
  z-index: 1;
  height: 0;
  width: 0;
  border: solid transparent; }

.icdc-angular .steplist-item-line::after {
  border-color: transparent;
  border-width: 0.5rem; }

.icdc-angular .steplist-item-line::before {
  border-color: transparent;
  border-width: 0.8rem; }

@media (max-width: 575.98px) {
  .icdc-angular .steplist {
    padding: 1rem 0; }
    .icdc-angular .steplist .steplist-item {
      position: relative;
      padding: 1rem 1rem 1rem 3rem; }
      .icdc-angular .steplist .steplist-item:first-child .steplist-item-line {
        border-radius: 1rem 1rem 0 0; }
      .icdc-angular .steplist .steplist-item:last-child .steplist-item-line {
        border-radius: 0 0 1rem 1rem; }
    .icdc-angular .steplist .steplist-item-line {
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      width: 1rem;
      background-color: currentColor; }
      .icdc-angular .steplist .steplist-item-line::before, .icdc-angular .steplist .steplist-item-line::after {
        top: 100%;
        left: 50%; }
      .icdc-angular .steplist .steplist-item-line::after {
        border-top-color: currentColor;
        margin-left: -0.5rem; }
      .icdc-angular .steplist .steplist-item-line::before {
        border-top-color: #FFFFFF;
        margin-left: -0.8rem; } }

@media (min-width: 576px) {
  .icdc-angular .steplist {
    display: table;
    table-layout: fixed;
    width: 100%;
    padding: 3rem 2rem; }
    .icdc-angular .steplist .steplist-item {
      display: table-cell;
      vertical-align: bottom; }
      .icdc-angular .steplist .steplist-item:first-child .steplist-item-line {
        border-radius: 1rem 0 0 1rem; }
      .icdc-angular .steplist .steplist-item:last-child .steplist-item-line {
        border-radius: 0 1rem 1rem 0; }
    .icdc-angular .steplist .steplist-item-line {
      position: relative;
      display: block;
      margin-top: 1.5rem;
      border-bottom: solid 1rem currentColor; }
      .icdc-angular .steplist .steplist-item-line::before, .icdc-angular .steplist .steplist-item-line::after {
        top: 50%;
        left: 100%; }
      .icdc-angular .steplist .steplist-item-line::after {
        border-left-color: currentColor;
        margin-top: 0; }
      .icdc-angular .steplist .steplist-item-line::before {
        border-left-color: #FFFFFF;
        margin-top: -0.3rem; }
    .icdc-angular .steplist .steplist-item-inner {
      -webkit-box-pack: center;
              justify-content: center; } }

.icdc-angular .stepper {
  list-style: none;
  counter-reset: step;
  display: -webkit-box;
  display: flex;
  flex-wrap: nowrap;
  -webkit-box-pack: justify;
          justify-content: space-between;
  -webkit-box-align: center;
          align-items: center; }
  .icdc-angular .stepper-item {
    min-height: 5rem;
    position: relative;
    display: -webkit-box;
    display: flex;
    -webkit-box-align: center;
            align-items: center;
    width: 100%;
    padding-right: 3rem;
    color: rgba(73, 80, 87, 0.5);
    font-size: 1.4rem;
    font-weight: 600; }
    @media (max-width: 991.98px) {
      .icdc-angular .stepper-item {
        font-size: 1.2rem;
        max-width: 6rem; }
        @supports ((max-width: -webkit-fit-content) or (max-width: -moz-fit-content) or (max-width: fit-content)) {
          .icdc-angular .stepper-item {
            max-width: -webkit-fit-content;
            max-width: -moz-fit-content;
            max-width: fit-content; } }
        .icdc-angular .stepper-item:not(.active) .stepper-label {
          position: absolute;
          width: 1px;
          height: 1px;
          padding: 0;
          overflow: hidden;
          clip: rect(0, 0, 0, 0);
          white-space: nowrap;
          border: 0; } }
    .icdc-angular .stepper-item::before {
      display: none; }
    .icdc-angular .stepper-item:after {
      content: "";
      font-family: "bdt" !important;
      font-style: normal;
      font-weight: normal;
      font-variant: normal;
      text-transform: none;
      line-height: 1;
      font-size: inherit;
      color: inherit;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      -webkit-alt: "";
      speak: none;
      font-size: 1.3rem;
      color: #E4E4E4;
      position: absolute;
      right: 3rem; }
      @media (max-width: 991.98px) {
        .icdc-angular .stepper-item:after {
          right: 0; } }
    .icdc-angular .stepper-item:last-child {
      padding-right: 0; }
      .icdc-angular .stepper-item:last-child::after {
        content: none; }
    .icdc-angular .stepper-item.complete, .icdc-angular .stepper-item.active {
      border-bottom: 0.3rem solid #e5291d; }
    .icdc-angular .stepper-item.complete {
      color: #495057; }
      .icdc-angular .stepper-item.complete .stepper-link::before {
        color: #FFFFFF;
        text-shadow: -0.1rem -0.1rem 0.2rem #495057; }
        @supports (-webkit-text-stroke: 0.1rem #495057) {
          .icdc-angular .stepper-item.complete .stepper-link::before {
            -webkit-text-stroke: 0.1rem #495057;
            text-shadow: none; } }
    .icdc-angular .stepper-item.active {
      color: #e5291d;
      margin-right: 3rem;
      padding: 0; }
      .icdc-angular .stepper-item.active::after {
        right: 0; }
      @media (max-width: 991.98px) {
        .icdc-angular .stepper-item.active {
          margin-right: 0;
          max-width: 100%; } }
      .icdc-angular .stepper-item.active .stepper-link::before {
        color: #e5291d; }
    .icdc-angular .stepper-item:not(.active):not(.complete) .stepper-link {
      cursor: text;
      pointer-events: none; }
    @media (max-width: 991.98px) {
      .icdc-angular .stepper-item {
        padding-right: 0; } }
  .icdc-angular .stepper-item-inner {
    -webkit-box-flex: 1;
            flex: 1 1 100%; }
  .icdc-angular .stepper-link {
    display: -webkit-box;
    display: flex;
    -webkit-box-align: center;
            align-items: center;
    width: 100%;
    padding-right: 3rem;
    color: inherit;
    text-decoration: none !important;
    word-break: normal;
    white-space: nowrap; }
    .icdc-angular .stepper-link::before {
      content: counter(step);
      counter-increment: step;
      color: #E4E4E4;
      font-size: 3.5rem;
      font-weight: 700;
      margin: 0 1.6rem; }
      @media (max-width: 991.98px) {
        .icdc-angular .stepper-link::before {
          font-size: 2.5rem;
          margin: 0 1rem 0 0; } }

.icdc-angular ngb-datepicker {
  /*border:1px solid #dfdfdf;*/
  border-radius: 0.25rem;
  display: inline-block;
  margin-top: 1rem;
  font-size: 1.1rem !important;
  font-weight: 500; }

.icdc-angular .ngb-dp-month {
  pointer-events: none; }

.icdc-angular .ngb-dp-header {
  border-bottom: 0;
  border-radius: 0.25rem .25rem 0 0;
  padding-top: 0.25rem; }

.icdc-angular ngb-datepicker-month-view {
  pointer-events: auto; }

.icdc-angular .ngb-dp-month-name {
  font-size: 1.2rem;
  font-weight: 700;
  text-transform: lowercase;
  height: 3.5rem;
  line-height: 3.5rem;
  text-align: center; }

.icdc-angular .ngb-dp-month + .ngb-dp-month > .ngb-dp-month-name,
.icdc-angular .ngb-dp-month + .ngb-dp-month > ngb-datepicker-month-view > .ngb-dp-week {
  padding-left: 1rem; }

.icdc-angular .ngb-dp-month:last-child .ngb-dp-week {
  padding-right: 0.25rem; }

.icdc-angular .ngb-dp-month:first-child .ngb-dp-week {
  padding-left: 0.25rem; }

.icdc-angular .ngb-dp-month > ngb-datepicker-month-view > .ngb-dp-week:last-child {
  padding-bottom: 0.25rem; }

.icdc-angular .ngb-dp-months {
  display: -webkit-box;
  display: flex; }

.icdc-angular ngb-datepicker-navigation {
  display: -webkit-box;
  display: flex;
  -webkit-box-align: center;
          align-items: center; }

.icdc-angular .ngb-dp-navigation-chevron {
  border-style: solid;
  border-width: 0.25em .25em 0 0;
  display: inline-block;
  width: 0.75em;
  height: 0.75em;
  font-size: .8rem;
  font-weight: 700;
  margin-left: 0.25em;
  margin-right: 0.15em;
  -webkit-transform: rotate(-135deg);
  transform: rotate(-135deg); }

.icdc-angular .right .ngb-dp-navigation-chevron {
  -webkit-transform: rotate(45deg);
  transform: rotate(45deg);
  margin-left: 0.15em;
  margin-right: 0.25em; }

.icdc-angular .ngb-dp-arrow {
  display: -webkit-box;
  display: flex;
  -webkit-box-flex: 1;
          flex: 1 1 auto;
  padding-right: 0;
  padding-left: 0;
  margin: 0;
  width: 3.5rem;
  height: 3.5rem; }

.icdc-angular .ngb-dp-arrow.right {
  -webkit-box-pack: end;
          justify-content: flex-end; }

.icdc-angular .ngb-dp-arrow-btn {
  padding: 0 .25rem;
  margin: 0 1.5rem;
  border: none;
  background-color: transparent;
  z-index: 1; }

.icdc-angular .ngb-dp-arrow-btn:focus {
  outline-width: 1px;
  outline-style: auto; }

@media all and (-ms-high-contrast: none), (-ms-high-contrast: active) {
  .icdc-angular .ngb-dp-arrow-btn:focus {
    outline-style: solid; } }

.icdc-angular .ngb-dp-month-name {
  font-size: 1.2rem;
  text-transform: lowercase;
  height: 3.5rem;
  line-height: 3.5rem;
  text-align: center; }

.icdc-angular .ngb-dp-navigation-select {
  display: -webkit-box;
  display: flex;
  -webkit-box-flex: 1;
          flex: 1 1 11rem; }

.icdc-angular ngb-datepicker-month-view {
  display: block; }

.icdc-angular .ngb-dp-week-number,
.icdc-angular .ngb-dp-weekday {
  line-height: 3.5rem;
  text-align: center;
  /*font-style:italic;*/
  font-weight: 700; }

.icdc-angular .ngb-dp-weekday {
  color: #454545; }
  .icdc-angular .ngb-dp-weekday.small {
    font-size: 1.1rem; }

.icdc-angular .ngb-dp-week {
  border-radius: 0.25rem;
  display: -webkit-box;
  display: flex; }

.icdc-angular .ngb-dp-weekdays {
  border-bottom: 0; }

.icdc-angular .ngb-dp-day,
.icdc-angular .ngb-dp-week-number,
.icdc-angular .ngb-dp-weekday {
  width: 3.5rem;
  height: 3.5rem;
  width: 3.9rem; }

.icdc-angular .ngb-dp-day {
  display: -webkit-box;
  display: flex;
  -webkit-box-pack: center;
          justify-content: center;
  -webkit-box-align: center;
          align-items: center;
  cursor: pointer;
  width: 3.9rem;
  height: 2.3rem;
  margin: .4rem 0; }
  .icdc-angular .ngb-dp-day [ngbDatepickerDayView] {
    display: -webkit-box;
    display: flex;
    -webkit-box-pack: center;
            justify-content: center;
    -webkit-box-align: center;
            align-items: center;
    width: 2.3rem;
    height: 2.3rem; }
    .icdc-angular .ngb-dp-day [ngbDatepickerDayView].btn-light {
      color: #757575; }
      .icdc-angular .ngb-dp-day [ngbDatepickerDayView].btn-light:active, .icdc-angular .ngb-dp-day [ngbDatepickerDayView].btn-light.active, .icdc-angular .ngb-dp-day [ngbDatepickerDayView].btn-light.range {
        color: #FFFFFF;
        background-color: #e5291d;
        border-radius: 50%; }
        .icdc-angular .ngb-dp-day [ngbDatepickerDayView].btn-light:active.faded, .icdc-angular .ngb-dp-day [ngbDatepickerDayView].btn-light.active.faded, .icdc-angular .ngb-dp-day [ngbDatepickerDayView].btn-light.range.faded {
          color: #171717;
          background-color: #F4F4F4;
          border-radius: 0;
          width: 100%; }
  .icdc-angular .ngb-dp-day:hover, .icdc-angular .ngb-dp-day.focused {
    background: #F4F4F4;
    cursor: pointer; }

.icdc-angular .ngb-dp-day.disabled, .icdc-angular .ngb-dp-day.hidden {
  cursor: default; }

.icdc-angular ngb-datepicker-navigation-select > .custom-select {
  -webkit-box-flex: 1;
          flex: 1 1 auto;
  padding: 0 0.5rem;
  font-size: 1.4rem;
  height: 3rem;
  line-height: 3rem;
  background: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 5'%3E%3Cpath fill='%23343a40' d='M2 0L0 2h4zm0 5L0 3h4z'/%3E%3C/svg%3E") right 0.75rem center/8px 10px no-repeat #fff; }

.icdc-angular [ngbDatepickerDayView] {
  text-align: center;
  width: 3.5rem;
  height: 3.5rem;
  line-height: 3.5rem;
  border-radius: 0.25rem;
  background: 0 0; }

.icdc-angular [ngbDatepickerDayView].outside {
  opacity: 0.5; }

.icdc-angular select.custom-select[_ngcontent-c7] {
  margin: 0.5rem 0.5rem 0 0;
  width: auto; }

.icdc-angular ngb-typeahead-window {
  max-width: 100%; }

.icdc-angular .dropdown-item {
  font-weight: 500; }
  .icdc-angular .dropdown-item .ngb-highlight {
    font-weight: 600; }

.icdc-angular .switch-button {
  position: relative;
  overflow: hidden;
  display: block;
  width: 3.7rem;
  height: 1.8rem;
  border-radius: 3.7rem; }
  .icdc-angular .switch-button input {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border: 0; }
    .icdc-angular .switch-button input + .txt + .txt {
      display: none; }
    .icdc-angular .switch-button input:checked + .txt {
      display: none; }
    .icdc-angular .switch-button input:checked + .txt + .txt {
      display: block; }
    .icdc-angular .switch-button input:checked ~ .switch {
      -webkit-transform: translateX(1.8rem);
              transform: translateX(1.8rem); }
    .icdc-angular .switch-button input:checked:focus ~ .switch {
      border-color: #e5291d; }
    .icdc-angular .switch-button input:focus ~ .switch {
      box-shadow: 0 0 0 0.2rem #000000;
      border: 0.2rem solid #757575; }
  .icdc-angular .switch-button .txt {
    display: block;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    color: #FFFFFF;
    font-size: 0.8rem;
    font-weight: 600;
    line-height: 1.8rem;
    text-transform: uppercase; }
    .icdc-angular .switch-button .txt:nth-of-type(1) {
      background-color: #757575;
      text-align: right;
      padding-right: 0.3rem; }
    .icdc-angular .switch-button .txt:nth-of-type(2) {
      padding-left: 0.35rem;
      background-color: #e5291d; }
  .icdc-angular .switch-button .switch {
    display: block;
    position: absolute;
    top: 0.2rem;
    left: 0.2rem;
    z-index: 402;
    width: 1.4rem;
    height: 1.4rem;
    border-radius: 100%;
    background-color: #FFFFFF;
    -webkit-transition: -webkit-transform 0.3s ease;
    transition: -webkit-transform 0.3s ease;
    transition: transform 0.3s ease;
    transition: transform 0.3s ease, -webkit-transform 0.3s ease; }

.icdc-angular .scroll-to-top {
  display: block;
  width: 5rem;
  height: 5rem;
  background-color: #FFFFFF;
  border: 0.1rem solid #E4E4E4;
  font-size: 1.2rem;
  text-align: center;
  line-height: 5rem;
  text-decoration: none !important;
  -webkit-transition: color 0.3s ease, border-color 0.3s ease;
  transition: color 0.3s ease, border-color 0.3s ease; }
  .icdc-angular .scroll-to-top:before {
    content: "";
    font-family: "bdt" !important;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    font-size: inherit;
    color: inherit;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-alt: "";
    speak: none; }
  .icdc-angular .scroll-to-top:hover {
    color: #171717;
    border-color: #171717; }

.icdc-angular .list-group-item {
  position: relative;
  text-decoration: none; }
  .icdc-angular .list-group-item.active:after {
    content: "";
    font-family: "bdt" !important;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    font-size: inherit;
    color: inherit;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-alt: "";
    speak: none; }
  .icdc-angular .list-group-item.active::after {
    position: absolute;
    top: calc(50% - .8rem);
    right: 1rem; }

.cover {
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover !important; }
  .cover img {
    display: none; }

.vcenter {
  white-space: nowrap;
  word-spacing: -0.25em; }
  .vcenter::before,
  .vcenter > .in {
    display: inline-block;
    vertical-align: middle; }
  .vcenter::before {
    content: '';
    width: 0;
    height: 100%; }
  .vcenter > .in {
    width: 100%;
    white-space: normal;
    word-spacing: normal; }

.bg-gray-100 {
  background-color: #F4F4F4;
  background-color: #F4F4F4; }

.bg-gray-200 {
  background-color: #E4E4E4;
  background-color: #E4E4E4; }

.bg-gray-300 {
  background-color: #CCCCCC;
  background-color: #CCCCCC; }

.bg-gray-500 {
  background-color: #757575;
  background-color: #757575; }

.bg-gray-800 {
  background-color: #454545;
  background-color: #454545; }

.bg-gray-900 {
  background-color: #171717;
  background-color: #171717; }

.bg-primary {
  background-color: #454545; }

.bg-secondary {
  background-color: #e5291d; }

.bg-success {
  background-color: #AFCD50; }

.bg-info {
  background-color: #64C3D7; }

.bg-warning {
  background-color: #F5A023; }

.bg-danger {
  background-color: #e5291d; }

.bg-light {
  background-color: #CCCCCC; }

.bg-dark {
  background-color: #454545; }

.bg-lighter {
  background-color: #F4F4F4; }

.bg-gray {
  background-color: #757575; }

.bg-gray-dark {
  background-color: #171717; }

.bg-gradient-primary {
  background: #454545 -webkit-gradient(linear, left top, left bottom, from(#616161), to(#454545)) repeat-x !important;
  background: #454545 linear-gradient(180deg, #616161, #454545) repeat-x !important; }

.bg-gradient-secondary {
  background: #e5291d -webkit-gradient(linear, left top, left bottom, from(#e9493f), to(#e5291d)) repeat-x !important;
  background: #e5291d linear-gradient(180deg, #e9493f, #e5291d) repeat-x !important; }

.bg-gradient-success {
  background: #AFCD50 -webkit-gradient(linear, left top, left bottom, from(#bbd56a), to(#AFCD50)) repeat-x !important;
  background: #AFCD50 linear-gradient(180deg, #bbd56a, #AFCD50) repeat-x !important; }

.bg-gradient-info {
  background: #64C3D7 -webkit-gradient(linear, left top, left bottom, from(#7bccdd), to(#64C3D7)) repeat-x !important;
  background: #64C3D7 linear-gradient(180deg, #7bccdd, #64C3D7) repeat-x !important; }

.bg-gradient-warning {
  background: #F5A023 -webkit-gradient(linear, left top, left bottom, from(#f7ae44), to(#F5A023)) repeat-x !important;
  background: #F5A023 linear-gradient(180deg, #f7ae44, #F5A023) repeat-x !important; }

.bg-gradient-danger {
  background: #e5291d -webkit-gradient(linear, left top, left bottom, from(#e9493f), to(#e5291d)) repeat-x !important;
  background: #e5291d linear-gradient(180deg, #e9493f, #e5291d) repeat-x !important; }

.bg-gradient-light {
  background: #CCCCCC -webkit-gradient(linear, left top, left bottom, from(#d4d4d4), to(#CCCCCC)) repeat-x !important;
  background: #CCCCCC linear-gradient(180deg, #d4d4d4, #CCCCCC) repeat-x !important; }

.bg-gradient-dark {
  background: #454545 -webkit-gradient(linear, left top, left bottom, from(#616161), to(#454545)) repeat-x !important;
  background: #454545 linear-gradient(180deg, #616161, #454545) repeat-x !important; }

.bg-gradient-lighter {
  background: #F4F4F4 -webkit-gradient(linear, left top, left bottom, from(#f6f6f6), to(#F4F4F4)) repeat-x !important;
  background: #F4F4F4 linear-gradient(180deg, #f6f6f6, #F4F4F4) repeat-x !important; }

.bg-gradient-gray {
  background: #757575 -webkit-gradient(linear, left top, left bottom, from(#8a8a8a), to(#757575)) repeat-x !important;
  background: #757575 linear-gradient(180deg, #8a8a8a, #757575) repeat-x !important; }

.bg-gradient-gray-dark {
  background: #171717 -webkit-gradient(linear, left top, left bottom, from(#3a3a3a), to(#171717)) repeat-x !important;
  background: #171717 linear-gradient(180deg, #3a3a3a, #171717) repeat-x !important; }

.bg-black {
  background-color: #000000 !important; }

.ftz-1 {
  font-size: 1rem !important; }

.ftz-2 {
  font-size: 2rem !important; }

.ftz-3 {
  font-size: 3rem !important; }

.ftz-4 {
  font-size: 4rem !important; }

.ftz-5 {
  font-size: 5rem !important; }

.ftz-6 {
  font-size: 6rem !important; }

.ftz-7 {
  font-size: 7rem !important; }

.ftz-8 {
  font-size: 8rem !important; }

.ftz-9 {
  font-size: 9rem !important; }

.ftz-10 {
  font-size: 10rem !important; }

.ftz-11 {
  font-size: 11rem !important; }

.ftz-12 {
  font-size: 12rem !important; }

.ftz-13 {
  font-size: 13rem !important; }

.ftz-14 {
  font-size: 14rem !important; }

.ftz-15 {
  font-size: 15rem !important; }

.ftz-16 {
  font-size: 16rem !important; }

.ftz-17 {
  font-size: 17rem !important; }

.ftz-18 {
  font-size: 18rem !important; }

.ftz-19 {
  font-size: 19rem !important; }

.ftz-20 {
  font-size: 20rem !important; }

.font-size-12 {
  font-size: 1.2rem !important; }

.font-size-14 {
  font-size: 1.4rem !important; }

.font-size-16 {
  font-size: 1.6rem !important; }

.font-size-18 {
  font-size: 1.8rem !important; }

.font-size-20 {
  font-size: 2rem !important; }

.width-10 {
  width: 10rem !important; }

.width-15 {
  width: 15rem !important; }

.width-20 {
  width: 20rem !important; }

.width-25 {
  width: 25rem !important; }

.width-30 {
  width: 30rem !important; }

.full-content {
  max-width: 125rem;
  background-color: none; }

.border-top-left-1 {
  position: relative;
  padding-top: 4.4rem;
  padding-left: 5rem; }
  .border-top-left-1:after {
    content: "";
    font-family: "bdt" !important;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    font-size: inherit;
    color: inherit;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-alt: "";
    speak: none;
    position: absolute;
    top: 0rem;
    left: -2.7rem;
    display: block;
    font-size: 20rem;
    color: #e5291d;
    line-height: 1; }
  @media (min-width: 1400px) {
    .border-top-left-1 {
      padding-top: 3.6rem;
      padding-left: 3rem; }
      .border-top-left-1::after {
        font-size: 12rem; } }

.border-top-left-2 {
  position: relative;
  padding-top: 2.5rem;
  padding-left: 2.5rem; }
  .border-top-left-2:before {
    content: "";
    font-family: "bdt" !important;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    font-size: inherit;
    color: inherit;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-alt: "";
    speak: none;
    position: absolute;
    top: 0rem;
    left: -0.7rem;
    display: block;
    font-size: 5rem;
    color: #e5291d;
    line-height: 1; }
  @media (min-width: 1400px) {
    .border-top-left-2 {
      padding-top: 5rem;
      padding-left: 0; }
      .border-top-left-2::before {
        left: -6rem;
        font-size: 7rem; } }

.border-top-left-3 {
  position: relative;
  padding-top: 4rem;
  padding-left: 4rem; }
  .border-top-left-3:after {
    content: "";
    font-family: "bdt" !important;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    font-size: inherit;
    color: inherit;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-alt: "";
    speak: none;
    position: absolute;
    top: 0rem;
    left: 0rem;
    display: block;
    font-size: 5.7rem;
    line-height: 1;
    color: #e5291d; }

.border-custom-spacer {
  position: relative;
  margin-bottom: 3.5rem; }
  .border-custom-spacer:after {
    content: "";
    font-family: "bdt" !important;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    font-size: inherit;
    color: inherit;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-alt: "";
    speak: none;
    display: block;
    margin-top: 1.5rem;
    font-size: 5rem;
    line-height: 0;
    color: #e5291d; }

.border-dotted {
  border-style: dotted !important;
  border-color: #CCCCCC !important; }

.border-dashed {
  border-style: dashed !important;
  border-color: #CCCCCC !important; }

.border-hover-shadow:hover {
  box-shadow: 0px 0px 30px 5px rgba(158, 158, 158, 0.4); }

.bg-blur {
  -webkit-backdrop-filter: blur(2px);
          backdrop-filter: blur(2px);
  /* supporté uniquement par webkit */ }

.cursor-pointer {
  cursor: pointer !important; }

.cursor-inherit {
  cursor: inherit !important; }

.cursor-default {
  cursor: default !important; }

.text-overflow-ellipsis {
  text-overflow: ellipsis; }

::-webkit-input-placeholder {
  color: #000000;
  font-size: 1.4rem;
  font-weight: 700;
  text-transform: uppercase; }

:-moz-placeholder {
  color: #000000;
  font-size: 1.4rem;
  font-weight: 700;
  text-transform: uppercase; }

::-moz-placeholder {
  color: #000000;
  opacity: 1;
  font-size: 1.4rem;
  font-weight: 700;
  text-transform: uppercase; }

:-ms-input-placeholder {
  color: #000000;
  font-size: 1.4rem;
  font-weight: 700;
  text-transform: uppercase; }

::-moz-selection {
  color: #FFFFFF;
  background-color: #454545; }

::selection {
  color: #FFFFFF;
  background-color: #454545; }

html {
  font-size: 62.5%; }

body {
  position: relative;
  overflow-x: hidden; }
  body.overflow, body.header-nav-burger-is-open {
    overflow: hidden; }

img {
  display: block;
  max-width: 100%;
  height: auto; }

a:focus, a.focus, button:focus, button.focus, input:focus, input.focus, textarea:focus, textarea.focus {
  outline: 0.1rem dashed #757575;
  outline-offset: 0.4rem; }

.aw-row-padding-xs {
  display: -webkit-box;
  display: flex;
  flex-wrap: wrap;
  margin-right: -1rem;
  margin-left: -1rem; }
  .aw-row-padding-xs > [class*="col-"] {
    position: relative;
    width: 100%;
    min-height: 1px;
    padding-right: 1rem;
    padding-left: 1rem; }

@media (min-width: 992px) {
  .aw-col-lg-10 {
    -webkit-box-flex: 0;
            flex: 0 0 10%;
    max-width: 10%; }
  .aw-col-lg-20 {
    -webkit-box-flex: 0;
            flex: 0 0 20%;
    max-width: 20%; }
  .aw-col-lg-25 {
    -webkit-box-flex: 0;
            flex: 0 0 25%;
    max-width: 25%; }
  .aw-col-lg-30 {
    -webkit-box-flex: 0;
            flex: 0 0 30%;
    max-width: 30%; }
  .aw-col-lg-33 {
    -webkit-box-flex: 0;
            flex: 0 0 33%;
    max-width: 33%; }
  .aw-col-lg-40 {
    -webkit-box-flex: 0;
            flex: 0 0 40%;
    max-width: 40%; }
  .aw-col-lg-50 {
    -webkit-box-flex: 0;
            flex: 0 0 50%;
    max-width: 50%; }
  .aw-col-lg-60 {
    -webkit-box-flex: 0;
            flex: 0 0 60%;
    max-width: 60%; }
  .aw-col-lg-70 {
    -webkit-box-flex: 0;
            flex: 0 0 70%;
    max-width: 70%; }
  .aw-col-lg-80 {
    -webkit-box-flex: 0;
            flex: 0 0 80%;
    max-width: 80%; }
  .aw-col-lg-90 {
    -webkit-box-flex: 0;
            flex: 0 0 90%;
    max-width: 90%; }
  .aw-col-lg-100 {
    -webkit-box-flex: 0;
            flex: 0 0 100%;
    max-width: 100%; } }

@media (min-width: 768px) {
  h1, .h1 {
    font-size: 2.8rem;
    margin-bottom: 3.2rem; }
  h2, .h2 {
    font-size: 2.2rem;
    line-height: 2.6rem; }
  h3, .h3, .header-megamenu-nav-menu > .menu > .menu-item:nth-of-type(1) a {
    font-size: 2rem;
    line-height: 2.6rem; }
  h4, .h4 {
    font-size: 1.8rem;
    line-height: 2.4rem; }
  h5, .h5 {
    font-size: 1.6rem;
    line-height: 2.2rem; }
  h6, .h6 {
    font-size: 1.6rem;
    line-height: 2.2rem; } }

@media (min-width: 1200px) {
  h1, .h1 {
    font-size: 3.2rem;
    line-height: 3.8rem;
    margin-bottom: 5rem; }
  h2, .h2 {
    font-size: 2.6rem;
    line-height: 3.2rem; }
  h3, .h3, .header-megamenu-nav-menu > .menu > .menu-item:nth-of-type(1) a {
    font-size: 2rem;
    line-height: 2.6rem; }
  h4, .h4 {
    font-size: 1.8rem;
    line-height: 2.4rem; }
  h5, .h5 {
    font-size: 1.6rem;
    line-height: 2.2rem; }
  h6, .h6 {
    font-size: 1.6rem;
    line-height: 2.2rem; } }

p {
  line-height: 1.25; }

[role="main"] p {
  line-height: 1.5625; }

[role="main"] a {
  text-decoration: none;
  word-break: break-word;
  word-wrap: break-word; }
  [role="main"] a.btn, [role="main"] .region-header-right .nav-link-user > a, .region-header-right [role="main"] .nav-link-user > a {
    text-decoration: none;
    word-break: normal;
    word-wrap: normal; }

span.ext,
span.mailto {
  display: inline-block;
  margin-left: 0.5rem;
  padding-right: 1.2rem;
  width: auto;
  height: auto;
  background: none;
  font-size: 1rem;
  text-decoration: none; }

span.ext:after {
  content: "";
  font-family: "bdt" !important;
  font-style: normal;
  font-weight: normal;
  font-variant: normal;
  text-transform: none;
  line-height: 1;
  font-size: inherit;
  color: inherit;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  -webkit-alt: "";
  speak: none;
  color: #e5291d;
  font-size: 110%; }

span.mailto:after {
  content: "";
  font-family: "bdt" !important;
  font-style: normal;
  font-weight: normal;
  font-variant: normal;
  text-transform: none;
  line-height: 1;
  font-size: inherit;
  color: inherit;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  -webkit-alt: "";
  speak: none; }

.header {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 2000;
  min-height: 7.7rem;
  padding-top: 4rem;
  padding-bottom: 4rem;
  background-color: transparent;
  -webkit-transition: background-color 0.6s cubic-bezier(0.39, 0.575, 0.565, 1), -webkit-transform 0.6s ease;
  transition: background-color 0.6s cubic-bezier(0.39, 0.575, 0.565, 1), -webkit-transform 0.6s ease;
  transition: background-color 0.6s cubic-bezier(0.39, 0.575, 0.565, 1), transform 0.6s ease;
  transition: background-color 0.6s cubic-bezier(0.39, 0.575, 0.565, 1), transform 0.6s ease, -webkit-transform 0.6s ease; }
  .header::after {
    content: '';
    display: table;
    clear: both; }

.region-header-left {
  float: left; }

.region-header-right {
  position: absolute;
  top: 50%;
  right: 2rem;
  margin-top: -2.75rem; }
  .region-header-right .nav {
    -webkit-box-pack: center;
            justify-content: center;
    -webkit-box-align: center;
            align-items: center; }
  .region-header-right [class^='nav-link'] {
    height: 100%; }
  .region-header-right .nav-link-access > a,
  .region-header-right .nav-link-access > button,
  .region-header-right .nav-link-map > a,
  .region-header-right .nav-link-map > button,
  .region-header-right .nav-link-search > a,
  .region-header-right .nav-link-search > button {
    display: block;
    cursor: pointer;
    padding-left: 1rem;
    padding-right: 1rem;
    height: 4.5rem;
    background-color: transparent;
    color: #000000;
    line-height: 4.5rem;
    -webkit-transition: background-color 0.3s ease, color 0.3s ease;
    transition: background-color 0.3s ease, color 0.3s ease; }
    .region-header-right .nav-link-access > a:hover, .region-header-right .nav-link-access > a:focus, .region-header-right .nav-link-access > a:active,
    .region-header-right .nav-link-access > button:hover,
    .region-header-right .nav-link-access > button:focus,
    .region-header-right .nav-link-access > button:active,
    .region-header-right .nav-link-map > a:hover,
    .region-header-right .nav-link-map > a:focus,
    .region-header-right .nav-link-map > a:active,
    .region-header-right .nav-link-map > button:hover,
    .region-header-right .nav-link-map > button:focus,
    .region-header-right .nav-link-map > button:active,
    .region-header-right .nav-link-search > a:hover,
    .region-header-right .nav-link-search > a:focus,
    .region-header-right .nav-link-search > a:active,
    .region-header-right .nav-link-search > button:hover,
    .region-header-right .nav-link-search > button:focus,
    .region-header-right .nav-link-search > button:active {
      background-color: #CCCCCC; }
  .region-header-right .nav-link-search > button::before {
    vertical-align: top; }
  .region-header-right .nav-link-search > button[aria-expanded='true'] {
    background-color: transparent !important;
    color: #000000 !important; }
    .region-header-right .nav-link-search > button[aria-expanded='true']::before {
      color: #e5291d; }
    .region-header-right .nav-link-search > button[aria-expanded='true']::after {
      content: 'Fermer';
      margin-left: 0.4rem;
      text-transform: uppercase;
      font-weight: 600;
      line-height: 1; }
  .region-header-right a {
    color: #454545; }
    .region-header-right a:hover {
      text-decoration: none; }
  .region-header-right button {
    -webkit-appearance: none;
       -moz-appearance: none;
            appearance: none;
    margin: 0;
    padding: 0;
    border: 0;
    background: none; }
    .region-header-right button:focus {
      outline: 0.1rem dashed #757575;
      outline-offset: 0.4rem; }
  .region-header-right [class^='icon-'] {
    font-size: 2rem;
    line-height: inherit; }
    .region-header-right [class^='icon-']::before {
      line-height: inherit;
      font-size: 2rem; }
  .region-header-right .nav-link-user {
    position: relative; }
    .region-header-right .nav-link-user > a,
    .region-header-right .nav-link-user > button {
      color: #FFFFFF;
      background-color: #e5291d;
      border-color: #FFFFFF;
      box-shadow: none;
      font-weight: 600; }
      .region-header-right .nav-link-user > a:hover,
      .region-header-right .nav-link-user > button:hover {
        color: #FFFFFF;
        background-color: #e5291d;
        border-color: #e5291d; }
      .region-header-right .nav-link-user > a:focus, .region-header-right .nav-link-user > a.focus,
      .region-header-right .nav-link-user > button:focus,
      .region-header-right .nav-link-user > button.focus {
        box-shadow: none, 0 0 0 0rem rgba(255, 255, 255, 0.5); }
      .region-header-right .nav-link-user > a.disabled, .region-header-right .nav-link-user > a:disabled,
      .region-header-right .nav-link-user > button.disabled,
      .region-header-right .nav-link-user > button:disabled {
        color: #FFFFFF;
        background-color: #e5291d;
        border-color: #FFFFFF; }
      .region-header-right .nav-link-user > a:not(:disabled):not(.disabled):active, .region-header-right .nav-link-user > a:not(:disabled):not(.disabled).active,
      .show > .region-header-right .nav-link-user > a.dropdown-toggle,
      .region-header-right .nav-link-user > button:not(:disabled):not(.disabled):active,
      .region-header-right .nav-link-user > button:not(:disabled):not(.disabled).active,
      .show >
      .region-header-right .nav-link-user > button.dropdown-toggle {
        color: #FFFFFF;
        background-color: #ba1f15;
        border-color: #dfdfdf; }
        .region-header-right .nav-link-user > a:not(:disabled):not(.disabled):active:focus, .region-header-right .nav-link-user > a:not(:disabled):not(.disabled).active:focus,
        .show > .region-header-right .nav-link-user > a.dropdown-toggle:focus,
        .region-header-right .nav-link-user > button:not(:disabled):not(.disabled):active:focus,
        .region-header-right .nav-link-user > button:not(:disabled):not(.disabled).active:focus,
        .show >
        .region-header-right .nav-link-user > button.dropdown-toggle:focus {
          box-shadow: none, 0 0 0 0rem rgba(255, 255, 255, 0.5); }
      .region-header-right .nav-link-user > a:focus,
      .region-header-right .nav-link-user > button:focus {
        background-color: #ba1f15; }
    .region-header-right .nav-link-user > button[aria-expanded='true'] {
      background-color: #e5291d !important;
      color: #FFFFFF !important;
      border-color: #e5291d !important; }
    .region-header-right .nav-link-user .dropdown-toggle::after {
      display: none !important; }
  .region-header-right .nav-link-user-dropdown {
    right: 0rem;
    border-width: 0 0.1rem 0.1rem 0.1rem;
    border-style: solid;
    border-color: #FFFFFF;
    background-color: #e5291d; }
    .region-header-right .nav-link-user-dropdown ul {
      list-style: none;
      cursor: pointer; }
    .region-header-right .nav-link-user-dropdown li:first-child {
      position: relative; }
      .region-header-right .nav-link-user-dropdown li:first-child::before {
        content: '';
        display: block;
        position: absolute;
        top: 100%;
        left: 2.2rem;
        right: 2.2rem;
        height: 0.1rem;
        background-color: #FFFFFF; }
    .region-header-right .nav-link-user-dropdown a {
      display: block;
      padding: 1.7rem 2.2rem;
      background-color: #e5291d;
      font-size: 1.2rem;
      color: #FFFFFF; }
      .region-header-right .nav-link-user-dropdown a:hover, .region-header-right .nav-link-user-dropdown a:focus {
        background-color: #ba1f15; }
      .region-header-right .nav-link-user-dropdown a:active {
        background-color: #a31b13; }
        .region-header-right .nav-link-user-dropdown a:active:hover, .region-header-right .nav-link-user-dropdown a:active:focus {
          background-color: #a31b13; }
  .region-header-right .nav-link-map [class^='icon-'] {
    font-size: 2.4rem; }
  .region-header-right .block-connexion-button-block,
  .region-header-right .block[class*="user"] {
    margin-left: 2rem; }
  .region-header-right .block-connexion-button-block > a:hover {
    background-color: #A00C0C;
    border-color: #A00C0C; }

.header-logo {
  position: absolute;
  top: 50%;
  left: 50%;
  -webkit-transform: translateX(-50%) translateY(-50%);
          transform: translateX(-50%) translateY(-50%);
  -webkit-transition: max-width 0.4s ease;
  transition: max-width 0.4s ease;
  z-index: 22;
  max-width: 36.6rem; }
  .header-logo a {
    display: block; }
  .header-logo img {
    display: block;
    width: 100%;
    max-width: 100%;
    height: auto; }

.header-megamenu-button {
  -webkit-appearance: none;
     -moz-appearance: none;
          appearance: none;
  margin: 0;
  padding: 2rem 2.4rem 2rem 5.2rem;
  border: 0;
  background: none;
  font-weight: 700;
  text-transform: uppercase;
  white-space: nowrap;
  word-spacing: -0.25em;
  line-height: 1; }
  .header-megamenu-button:focus {
    outline: 0.1rem dashed #757575;
    outline-offset: 0.4rem; }
  .header-megamenu-button:before {
    content: "";
    font-family: "bdt" !important;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    font-size: inherit;
    color: inherit;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-alt: "";
    speak: none;
    position: absolute;
    top: 50%;
    left: 2.4rem;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%); }
  .header-megamenu-button[aria-expanded='true']:before {
    content: "";
    color: #e5291d; }

.header-megamenu-button,
.header-search-btn {
  position: relative; }
  .header-megamenu-button[aria-expanded="true"],
  .header-search-btn[aria-expanded="true"] {
    z-index: 22; }

.block-homepage-selector,
.block-main-menu,
.header-megamenu-wrapper,
.dropdown-segment {
  display: inline-block;
  vertical-align: middle; }

.block-homepage-selector .form-item {
  margin-top: 0;
  margin-bottom: 0; }

.dropdown-segment {
  width: 32.6rem; }
  .dropdown-segment .dropdown-menu {
    width: 100%;
    border-top: 0; }
  .dropdown-segment .menu {
    list-style: none; }
  .dropdown-segment .menu-item a {
    display: block;
    padding: 1.7rem 2.6rem;
    font-weight: 600;
    text-transform: uppercase;
    -webkit-transition: background-color 0.3s ease, color 0.3s ease;
    transition: background-color 0.3s ease, color 0.3s ease; }
    .dropdown-segment .menu-item a:hover {
      background-color: #E4E4E4; }

.dropdown-segment-btn {
  -webkit-appearance: none;
     -moz-appearance: none;
          appearance: none;
  margin: 0;
  padding: 1.7rem 2.6rem;
  border: 0.1rem solid #CCCCCC;
  background: none;
  padding-right: 5rem;
  display: block;
  width: 100%;
  text-align: left;
  font-weight: 700; }
  .dropdown-segment-btn:focus {
    outline: 0.1rem dashed #757575;
    outline-offset: 0.4rem; }
  .dropdown-segment-btn:before {
    content: "";
    font-family: "bdt" !important;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    font-size: inherit;
    color: inherit;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-alt: "";
    speak: none;
    position: absolute;
    top: 50%;
    right: 2rem;
    -webkit-transform: translateX(-50%);
            transform: translateX(-50%);
    font-size: 0.8rem; }
  .dropdown-segment-btn::after {
    display: none; }
  .dropdown-segment-btn span {
    display: block;
    text-transform: uppercase;
    line-height: 1; }
    .dropdown-segment-btn span:nth-of-type(1) {
      font-size: 1.2rem;
      color: #454545; }
    .dropdown-segment-btn span:nth-of-type(2) {
      color: #e5291d; }

.header-search-btn:before {
  font-family: "bdt" !important;
  font-style: normal;
  font-weight: normal;
  font-variant: normal;
  text-transform: none;
  line-height: 1;
  font-size: inherit;
  color: inherit;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  -webkit-alt: "";
  speak: none;
  font-size: 2rem;
  line-height: 4.5rem; }

.header-search-btn[aria-expanded="false"]:before {
  content: ""; }

.header-search-btn[aria-expanded="true"]:before {
  content: ""; }

.header-search-btn-txt {
  position: absolute !important;
  overflow: hidden;
  width: 1px;
  height: 1px;
  padding: 0;
  border: 0;
  clip: rect(1px, 1px, 1px, 1px); }
  .header-search-btn-txt:before, .header-search-btn-txt:after {
    display: none; }

@media (max-width: 1599.98px) {
  .header-logo {
    max-width: 27rem; } }

@media (max-width: 1199.98px) {
  .header {
    padding-top: 1rem;
    padding-bottom: 1rem;
    background-color: #FFFFFF; }
  .region-header-right .block-icdc-custom-button-block,
  .region-header-right .block-header-search-block {
    display: none; }
  .block-homepage-selector {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background-color: #e5291d; }
  .dropdown-segment-btn {
    border: 0;
    color: #FFFFFF; }
    .dropdown-segment-btn::before {
      margin-top: -0.3rem; }
    .dropdown-segment-btn span:nth-of-type(1) {
      display: none; }
    .dropdown-segment-btn span:nth-of-type(2) {
      color: inherit; } }

@media (max-width: 991.98px) {
  .header {
    padding-top: 2rem;
    padding-bottom: 2rem; }
  .header-logo a {
    width: 21rem;
    height: 6.3rem;
    background: /*savepage-url=../img/logo-bdt-mobile.png*/ url() 0 0 no-repeat;
    background-size: contain; }
  .header-logo img {
    position: absolute !important;
    overflow: hidden;
    width: 1px;
    height: 1px;
    padding: 0;
    border: 0;
    clip: rect(1px, 1px, 1px, 1px); }
    .header-logo img:before, .header-logo img:after {
      display: none; }
  .header-megamenu-button {
    padding: 0;
    width: 5.5rem;
    height: 5.5rem;
    background-color: #FFFFFF; }
    .header-megamenu-button::before {
      left: 50%;
      -webkit-transform: translateX(-50%) translateY(-50%);
              transform: translateX(-50%) translateY(-50%); }
    .header-megamenu-button span {
      position: absolute !important;
      overflow: hidden;
      width: 1px;
      height: 1px;
      padding: 0;
      border: 0;
      clip: rect(1px, 1px, 1px, 1px); }
      .header-megamenu-button span:before, .header-megamenu-button span:after {
        display: none; }
  .region-header-right {
    right: 0rem; }
    .region-header-right .nav-link-user > a,
    .region-header-right .nav-link-user > button {
      position: relative;
      padding: 0;
      width: 5.5rem;
      height: 5.5rem;
      color: #171717;
      background-color: #FFFFFF;
      border-color: #FFFFFF;
      box-shadow: none;
      color: #000000 !important; }
      .region-header-right .nav-link-user > a:hover,
      .region-header-right .nav-link-user > button:hover {
        color: #FFFFFF;
        background-color: #000000;
        border-color: #000000; }
      .region-header-right .nav-link-user > a:focus, .region-header-right .nav-link-user > a.focus,
      .region-header-right .nav-link-user > button:focus,
      .region-header-right .nav-link-user > button.focus {
        box-shadow: none, 0 0 0 0rem rgba(255, 255, 255, 0.5); }
      .region-header-right .nav-link-user > a.disabled, .region-header-right .nav-link-user > a:disabled,
      .region-header-right .nav-link-user > button.disabled,
      .region-header-right .nav-link-user > button:disabled {
        color: #171717;
        background-color: #FFFFFF;
        border-color: #FFFFFF; }
      .region-header-right .nav-link-user > a:not(:disabled):not(.disabled):active, .region-header-right .nav-link-user > a:not(:disabled):not(.disabled).active,
      .show > .region-header-right .nav-link-user > a.dropdown-toggle,
      .region-header-right .nav-link-user > button:not(:disabled):not(.disabled):active,
      .region-header-right .nav-link-user > button:not(:disabled):not(.disabled).active,
      .show >
      .region-header-right .nav-link-user > button.dropdown-toggle {
        color: #171717;
        background-color: #e6e6e6;
        border-color: #dfdfdf; }
        .region-header-right .nav-link-user > a:not(:disabled):not(.disabled):active:focus, .region-header-right .nav-link-user > a:not(:disabled):not(.disabled).active:focus,
        .show > .region-header-right .nav-link-user > a.dropdown-toggle:focus,
        .region-header-right .nav-link-user > button:not(:disabled):not(.disabled):active:focus,
        .region-header-right .nav-link-user > button:not(:disabled):not(.disabled).active:focus,
        .show >
        .region-header-right .nav-link-user > button.dropdown-toggle:focus {
          box-shadow: none, 0 0 0 0rem rgba(255, 255, 255, 0.5); }
      .region-header-right .nav-link-user > a:hover, .region-header-right .nav-link-user > a:focus, .region-header-right .nav-link-user > a:active,
      .region-header-right .nav-link-user > button:hover,
      .region-header-right .nav-link-user > button:focus,
      .region-header-right .nav-link-user > button:active {
        color: #FFFFFF !important; }
    .region-header-right .nav-link-user [class^='icon'] {
      position: absolute;
      top: 50%;
      left: 50%;
      -webkit-transform: translate(-50%, -50%);
              transform: translate(-50%, -50%);
      margin-right: 0; }
    .region-header-right .nav-link-user span + span {
      display: none !important; }
    .region-header-right .nav-link-user-dropdown {
      width: 19rem;
      left: auto; }
  .dropdown-segment {
    width: 100%; } }

.header-megamenu-search-wrapper {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 20;
  overflow-y: auto;
  height: 100vh !important;
  background: #FFFFFF /*savepage-url=../img/megamenu-trame.png*/ url() 0 0 no-repeat fixed;
  background-size: cover; }
  .header-megamenu-search-wrapper .vcenter {
    height: 100vh;
    text-align: center; }
    .header-megamenu-search-wrapper .vcenter .in {
      overflow-y: auto;
      overflow-x: hidden;
      vertical-align: top;
      margin-top: 15rem;
      width: 80%;
      max-width: 100rem;
      max-height: calc(100vh - 17rem);
      text-align: left; }
  .header-megamenu-search-wrapper form {
    position: relative; }
    .header-megamenu-search-wrapper form:before {
      content: "";
      font-family: "bdt" !important;
      font-style: normal;
      font-weight: normal;
      font-variant: normal;
      text-transform: none;
      line-height: 1;
      font-size: inherit;
      color: inherit;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      -webkit-alt: "";
      speak: none;
      display: block;
      position: absolute;
      top: 50%;
      left: 3rem;
      z-index: 1;
      -webkit-transform: translateY(-50%);
              transform: translateY(-50%);
      color: #e5291d;
      font-size: 6rem; }
  .header-megamenu-search-wrapper label {
    display: block;
    position: absolute;
    top: 50%;
    left: 12rem;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%);
    font-size: 2.2rem;
    font-weight: 700;
    text-transform: uppercase;
    -webkit-transition: font-size 0.3s ease, color 0.3s ease, -webkit-transform 0.3s ease;
    transition: font-size 0.3s ease, color 0.3s ease, -webkit-transform 0.3s ease;
    transition: transform 0.3s ease, font-size 0.3s ease, color 0.3s ease;
    transition: transform 0.3s ease, font-size 0.3s ease, color 0.3s ease, -webkit-transform 0.3s ease; }
  .header-megamenu-search-wrapper [type='text'] {
    display: block;
    width: 100%;
    height: 13rem;
    padding-left: 12rem;
    padding-right: 12rem;
    border-width: 0 0 0.1rem 0;
    border-style: solid;
    border-color: #454545;
    font-size: 2.2rem;
    font-weight: 700;
    -webkit-transition: border-color 0.3s ease;
    transition: border-color 0.3s ease; }
  .header-megamenu-search-wrapper [type='submit'] {
    display: block;
    position: absolute;
    top: 0;
    right: 0;
    width: 13rem;
    height: 12.9rem;
    background-color: #FFFFFF;
    color: #757575;
    -webkit-transition: background-color 0.3s ease, color 0.3s ease;
    transition: background-color 0.3s ease, color 0.3s ease; }
    .header-megamenu-search-wrapper [type='submit'] [class^='icon-'] {
      font-size: 2.8rem !important; }
    .header-megamenu-search-wrapper [type='submit']:hover {
      background-color: #e5291d;
      color: #FFFFFF; }
    .header-megamenu-search-wrapper [type='submit']:focus {
      background-color: #e5291d;
      color: #FFFFFF;
      outline-color: #e5291d; }
  .header-megamenu-search-wrapper .float-target-parent.focused label, .header-megamenu-search-wrapper .form-has-floatlabel .focused.js-form-type-search label, .form-has-floatlabel .header-megamenu-search-wrapper .focused.js-form-type-search label, .header-megamenu-search-wrapper .form-has-floatlabel .focused.js-form-item-field-tra-geography label, .form-has-floatlabel .header-megamenu-search-wrapper .focused.js-form-item-field-tra-geography label {
    -webkit-transform: translateY(-4rem);
            transform: translateY(-4rem);
    font-size: 1.4rem;
    color: #757575; }
  .header-megamenu-search-wrapper .float-target-parent.focused [type='text'], .header-megamenu-search-wrapper .form-has-floatlabel .focused.js-form-type-search [type='text'], .form-has-floatlabel .header-megamenu-search-wrapper .focused.js-form-type-search [type='text'], .header-megamenu-search-wrapper .form-has-floatlabel .focused.js-form-item-field-tra-geography [type='text'], .form-has-floatlabel .header-megamenu-search-wrapper .focused.js-form-item-field-tra-geography [type='text'] {
    border-bottom-color: #e5291d; }

.search-quick-access-lin {
  margin-top: 6rem; }
  .search-quick-access-lin h2 {
    margin-bottom: 3rem;
    color: #e5291d;
    font-size: 1.8rem;
    text-transform: uppercase; }
  .search-quick-access-lin ul {
    margin-left: -0.6rem;
    margin-right: -0.6rem;
    list-style: none; }
    .search-quick-access-lin ul::after {
      content: '';
      display: table;
      clear: both; }
  .search-quick-access-lin li {
    float: left;
    margin: 0.6rem; }
  .search-quick-access-lin a {
    display: block;
    padding: 1rem 2rem;
    border: 0.1rem solid #757575;
    border-radius: 0.4rem;
    line-height: 1;
    font-weight: 600;
    font-size: 1.4rem;
    color: #757575;
    -webkit-transition: background-color 0.3s ease, color 0.3s ease;
    transition: background-color 0.3s ease, color 0.3s ease; }
    .search-quick-access-lin a:hover {
      background-color: #757575;
      color: #FFFFFF; }
    .search-quick-access-lin a:focus {
      outline-color: #757575; }

.header.header-sticky {
  padding-top: 1rem;
  padding-bottom: 1rem;
  border-bottom: 0.1rem solid #E4E4E4;
  background-color: #FFFFFF; }
  .header.header-sticky .region-header-left .header-logo {
    max-width: 24rem; }
  .header.header-sticky .dropdown-segment-btn {
    padding: 1rem 2rem;
    font-size: 1.2rem; }
    .header.header-sticky .dropdown-segment-btn span:nth-of-type(1) {
      display: none; }
    .header.header-sticky .dropdown-segment-btn::before {
      right: 1.5rem;
      margin-top: -0.4rem; }
  .header.header-sticky.header-sticky-menu-open .region-header-left .header-logo {
    max-width: 36.6rem;
    -webkit-transform: translateX(-50%) translateY(-30%);
            transform: translateX(-50%) translateY(-30%); }

.header.header-unpin {
  -webkit-transform: translateY(-100%);
          transform: translateY(-100%); }
  @media (max-width: 1399.98px) {
    .header.header-unpin {
      -webkit-transform: translateY(-150%);
              transform: translateY(-150%); } }

.header-megamenu-nav {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 10;
  overflow-y: auto;
  height: 100vh !important;
  background: #FFFFFF /*savepage-url=../img/megamenu-trame.png*/ url() 0 0 no-repeat fixed;
  background-size: cover; }
  .header-megamenu-nav .vcenter {
    height: 100vh; }
    .header-megamenu-nav .vcenter .in {
      margin-top: 14rem;
      vertical-align: top;
      overflow-y: auto;
      overflow-x: hidden;
      max-height: calc(100vh - 14rem); }
  .header-megamenu-nav ul {
    list-style: none; }
  .header-megamenu-nav .menu-item {
    display: inline-block;
    vertical-align: top;
    padding: 3.5rem 1rem;
    width: 25%;
    word-spacing: normal; }
    .header-megamenu-nav .menu-item .menu-item {
      display: block;
      margin-bottom: 1.6rem;
      padding: 0rem;
      width: 100%; }
      .header-megamenu-nav .menu-item .menu-item a {
        position: relative;
        display: block;
        margin-left: 2rem;
        color: #454545; }
        .header-megamenu-nav .menu-item .menu-item a:before {
          content: "";
          font-family: "bdt" !important;
          font-style: normal;
          font-weight: normal;
          font-variant: normal;
          text-transform: none;
          line-height: 1;
          font-size: inherit;
          color: inherit;
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale;
          -webkit-alt: "";
          speak: none;
          position: absolute;
          top: 0.6rem;
          left: -2rem;
          font-size: 0.9rem;
          color: #e5291d; }
  .header-megamenu-nav .hide-show-trigger {
    margin-bottom: 2rem; }

.header-megamenu-nav-link-access-map,
.header-megamenu-nav-menu,
.header-megamenu-nav-link-search {
  margin: 0 auto;
  width: 86%; }

.header-megamenu-nav-link-access-map {
  border-width: 0.1rem 0;
  border-style: solid;
  border-color: #CCCCCC;
  background-color: #FFFFFF; }
  .header-megamenu-nav-link-access-map::after {
    content: '';
    display: table;
    clear: both; }
  .header-megamenu-nav-link-access-map [class^='icon'] {
    display: block;
    position: absolute;
    top: 2rem;
    left: 0;
    right: 0; }
  .header-megamenu-nav-link-access-map button {
    -webkit-appearance: none;
       -moz-appearance: none;
            appearance: none;
    margin: 0;
    padding: 0;
    border: 0;
    background: none; }
    .header-megamenu-nav-link-access-map button:focus {
      outline: 0.1rem dashed #757575;
      outline-offset: 0.4rem; }
    .header-megamenu-nav-link-access-map button [class^='icon'] {
      font-size: 2rem;
      -webkit-transform: translateX(0.5rem);
              transform: translateX(0.5rem); }
  .header-megamenu-nav-link-access-map a {
    font-size: 1.4rem; }
    .header-megamenu-nav-link-access-map a [class^='icon'] {
      -webkit-transform: scale(1.6) translate(0.5rem, 0.2rem);
              transform: scale(1.6) translate(0.5rem, 0.2rem);
      -webkit-transform-origin: center;
              transform-origin: center; }
    .header-megamenu-nav-link-access-map a::before {
      content: '';
      display: block;
      position: absolute;
      top: 1rem;
      left: 0;
      width: 0.1rem;
      height: 75%;
      background-color: #CCCCCC; }
  .header-megamenu-nav-link-access-map button, .header-megamenu-nav-link-access-map a {
    position: relative;
    float: left;
    padding-top: 4.4rem;
    width: 15rem;
    height: 8rem;
    text-align: center; }
  .header-megamenu-nav-link-access-map span + span {
    position: absolute;
    top: 4.4rem;
    left: 0;
    right: 0; }
    .header-megamenu-nav-link-access-map span + span:before {
      content: "";
      font-family: "bdt" !important;
      font-style: normal;
      font-weight: normal;
      font-variant: normal;
      text-transform: none;
      line-height: 1;
      font-size: inherit;
      color: inherit;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      -webkit-alt: "";
      speak: none;
      margin-left: 0.4rem;
      color: #e5291d;
      font-size: 0.9rem; }

.header-megamenu-nav-link-search {
  margin-bottom: 2rem;
  padding-top: 2rem;
  background-color: #FFFFFF; }
  .header-megamenu-nav-link-search form {
    position: relative; }
    .header-megamenu-nav-link-search form:before {
      content: "";
      font-family: "bdt" !important;
      font-style: normal;
      font-weight: normal;
      font-variant: normal;
      text-transform: none;
      line-height: 1;
      font-size: inherit;
      color: inherit;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      -webkit-alt: "";
      speak: none;
      display: block;
      position: absolute;
      top: 50%;
      left: 0;
      -webkit-transform: translateY(-50%);
              transform: translateY(-50%);
      z-index: 42;
      font-size: 2.5rem;
      color: #e5291d; }
  .header-megamenu-nav-link-search label {
    display: block;
    position: absolute;
    top: 0rem;
    left: 5rem;
    z-index: 40;
    -webkit-transform: translate(0, 2rem);
            transform: translate(0, 2rem);
    -webkit-transition: color 0.3s ease, -webkit-transform 0.3s ease;
    transition: color 0.3s ease, -webkit-transform 0.3s ease;
    transition: transform 0.3s ease, color 0.3s ease;
    transition: transform 0.3s ease, color 0.3s ease, -webkit-transform 0.3s ease;
    text-transform: uppercase;
    font-size: 1.6rem;
    font-weight: 700; }
  .header-megamenu-nav-link-search .form-text {
    position: absolute !important;
    right: auto !important;
    bottom: auto !important;
    font-size: 1.6rem !important;
    display: block;
    width: 100%;
    height: 6rem;
    padding-left: 5rem;
    padding-right: 5rem;
    border-width: 0 0 0.1rem 0;
    border-style: solid;
    border-color: #000000;
    background-color: #FFFFFF; }
    .header-megamenu-nav-link-search .form-text:focus {
      border-color: #e5291d; }
  .header-megamenu-nav-link-search button[type='submit'] {
    -webkit-appearance: none;
       -moz-appearance: none;
            appearance: none;
    margin: 0;
    padding: 0;
    border: none;
    background: none;
    display: block;
    position: absolute;
    top: 0;
    right: 0;
    width: 5rem;
    height: 5.9rem;
    background-color: #FFFFFF;
    color: #000000;
    -webkit-transition: background-color 0.3s ease;
    transition: background-color 0.3s ease; }
    .header-megamenu-nav-link-search button[type='submit']:focus {
      outline: 0.1rem dashed #757575;
      outline-offset: 0.4rem; }
    .header-megamenu-nav-link-search button[type='submit']:hover, .header-megamenu-nav-link-search button[type='submit']:focus, .header-megamenu-nav-link-search button[type='submit']:active {
      background-color: #CCCCCC; }
  .header-megamenu-nav-link-search .focused label {
    -webkit-transform: translate(0, 0rem);
            transform: translate(0, 0rem);
    font-size: 1.2rem;
    color: #757575; }

.header-megamenu-nav-menu {
  word-spacing: -0.45em; }
  .header-megamenu-nav-menu::after {
    content: '';
    display: table;
    clear: both; }

.header-megamenu-nav-menu > .menu > .menu-item:nth-of-type(1) {
  display: block;
  width: 100%;
  border-bottom: 0.1rem solid #CCCCCC; }
  .header-megamenu-nav-menu > .menu > .menu-item:nth-of-type(1) a {
    position: relative;
    margin-left: 2.2rem;
    color: #e5291d; }
    .header-megamenu-nav-menu > .menu > .menu-item:nth-of-type(1) a:before {
      content: "";
      font-family: "bdt" !important;
      font-style: normal;
      font-weight: normal;
      font-variant: normal;
      text-transform: none;
      line-height: 1;
      font-size: inherit;
      color: inherit;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      -webkit-alt: "";
      speak: none;
      position: absolute;
      top: 50%;
      left: -2.4rem;
      -webkit-transform: translateY(-50%);
              transform: translateY(-50%);
      font-size: 50%; }

@media (min-width: 992px) {
  .header-megamenu-wrapper .menu .hide-show-trigger {
    pointer-events: none; }
    .header-megamenu-wrapper .menu .hide-show-trigger::after {
      display: none; }
  .header-megamenu-nav-link-access-map,
  .header-megamenu-nav-link-search {
    display: none; } }

@media (max-width: 1199.98px) {
  .header-megamenu-wrapper .menu .hide-show-trigger {
    position: relative;
    cursor: pointer; }
    .header-megamenu-wrapper .menu .hide-show-trigger:after {
      content: "";
      font-family: "bdt" !important;
      font-style: normal;
      font-weight: normal;
      font-variant: normal;
      text-transform: none;
      line-height: 1;
      font-size: inherit;
      color: inherit;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      -webkit-alt: "";
      speak: none;
      position: absolute;
      top: 1rem;
      right: 0;
      font-size: 0.8rem;
      -webkit-transform-origin: center;
              transform-origin: center;
      -webkit-transform: rotate(0deg);
              transform: rotate(0deg);
      -webkit-transition: -webkit-transform 0.3s ease;
      transition: -webkit-transform 0.3s ease;
      transition: transform 0.3s ease;
      transition: transform 0.3s ease, -webkit-transform 0.3s ease; }
    .header-megamenu-wrapper .menu .hide-show-trigger[aria-expanded="true"]::after {
      -webkit-transform: rotate(-180deg);
              transform: rotate(-180deg); }
  .header-megamenu-nav-link-access-map,
  .header-megamenu-nav-link-search {
    display: block; }
  .header-megamenu-nav-menu {
    padding-top: 0rem; } }

@media (max-width: 991.98px) {
  .header-megamenu-nav-link-access-map,
  .header-megamenu-nav-menu,
  .header-megamenu-nav-link-search {
    width: 90%; }
  .header-megamenu-nav .menu-item {
    padding-top: 2rem;
    padding-bottom: 2rem;
    width: 100%; } }

body .skip-link {
  list-style: none;
  margin: 0;
  padding: 0;
  z-index: 100;
  position: relative;
  background-color: #000000; }
  body .skip-link::after {
    content: '';
    display: table;
    clear: both; }
  body .skip-link li {
    float: left; }
    body .skip-link li::before {
      display: none; }
  body .skip-link button {
    padding: 0;
    border: 0;
    line-height: 1.4; }
  body .skip-link a, body .skip-link button {
    display: block;
    padding: 0rem;
    color: #FFFFFF;
    background-color: #454545;
    text-decoration: underline !important;
    -webkit-transition: background-color 0.3s ease;
    transition: background-color 0.3s ease; }
    body .skip-link a:hover, body .skip-link a:focus, body .skip-link a:active, body .skip-link button:hover, body .skip-link button:focus, body .skip-link button:active {
      padding: 0.5rem 1rem !important;
      font-size: 1.4rem;
      text-decoration: none !important;
      background-color: #000000;
      outline: 0.1rem dashed #FFFFFF;
      outline-offset: -0.1rem; }
  body .skip-link a.active {
    color: #FFFFFF;
    background-color: #000000; }

.skip-sr-only {
  position: absolute !important;
  overflow: hidden !important;
  padding: 0 !important;
  width: 1px !important;
  height: 1px !important;
  border: 0 !important;
  white-space: nowrap !important;
  -webkit-clip-path: inset(50%) !important;
  clip-path: inset(50%) !important;
  clip: rect(1px, 1px, 1px, 1px) !important; }

.sr-only-focusable:focus, .sr-only-focusable:active {
  overflow: visible !important;
  width: auto !important;
  height: auto !important;
  white-space: normal !important;
  color: #FFFFFF;
  -webkit-clip-path: none !important;
  clip-path: none !important;
  clip: auto !important; }

.footer-wrapper {
  padding-left: 2rem;
  padding-right: 2rem;
  max-width: 130rem;
  margin: 0 auto;
  font-size: 1.4rem; }
  .footer-wrapper .menu,
  .footer-wrapper .social-media-links--platforms {
    display: block;
    list-style: none; }
  .footer-wrapper .social-media-links--platforms li > a::before {
    font-size: 2.8rem; }
  .footer-wrapper h2 {
    margin-bottom: 2rem;
    font-size: 2.2rem;
    font-weight: 600; }

.footer-segment {
  display: none;
  padding-top: 5rem; }
  .footer-segment::after {
    content: '';
    display: table;
    clear: both; }
  .footer-segment .block-footer-menu,
  .footer-segment .menu--segment-footer {
    margin-bottom: 2rem; }
    .footer-segment .block-footer-menu::after,
    .footer-segment .menu--segment-footer::after {
      content: '';
      display: table;
      clear: both; }
  .footer-segment .menu {
    width: 33.3333%;
    padding-right: 2rem; }
  .footer-segment .block-social-media-links li {
    display: inline-block;
    vertical-align: bottom; }
    .footer-segment .block-social-media-links li::before {
      display: none; }
  .footer-segment .block-social-media-links a {
    display: block;
    padding-left: 0.8rem;
    padding-right: 0.8rem;
    font-size: 2.8rem;
    line-height: 1;
    color: #757575;
    -webkit-transition: color 0.3s ease;
    transition: color 0.3s ease; }
    .footer-segment .block-social-media-links a:hover {
      color: #e5291d;
      text-decoration: none; }
  .footer-segment .block-social-media-links a + a {
    padding-left: 1.6rem; }
  .footer-segment .menu-item a {
    position: relative;
    display: block;
    margin-left: 1.8rem;
    padding-top: 1rem;
    padding-bottom: 1rem;
    font-weight: 600;
    line-height: 1.4;
    text-transform: uppercase; }
    .footer-segment .menu-item a:before {
      content: "";
      font-family: "bdt" !important;
      font-style: normal;
      font-weight: normal;
      font-variant: normal;
      text-transform: none;
      line-height: 1;
      font-size: inherit;
      color: inherit;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      -webkit-alt: "";
      speak: none;
      position: absolute;
      top: 1.4rem;
      left: -1.8rem;
      font-size: 0.9rem;
      color: #e5291d; }
    .footer-segment .menu-item a:hover {
      color: #454545; }
  .footer-segment .fa {
    display: none; }
  @media (min-width: 768px) {
    .footer-segment {
      display: block; } }
  @media (min-width: 1200px) {
    .footer-segment .block-footer-menu,
    .footer-segment .menu--segment-footer {
      width: 75%; }
      .footer-segment .block-footer-menu::after,
      .footer-segment .menu--segment-footer::after {
        content: '';
        display: table;
        clear: both; }
    .footer-segment .block-social-media-links {
      width: 25%; } }

.footer-segment + .footer-common {
  margin-top: 6rem; }

.footer-common {
  display: -webkit-box;
  display: flex;
  padding-top: 3.4rem;
  padding-bottom: 3.4rem; }
  @media (max-width: 1199.98px) {
    .footer-common {
      padding-left: 2.5rem;
      padding-right: 2.5rem;
      -webkit-box-orient: vertical;
      -webkit-box-direction: normal;
              flex-direction: column;
      margin-bottom: 8rem;
      margin-top: 4rem; }
      .footer-common .footer-copyright {
        -webkit-box-ordinal-group: 4;
                order: 3;
        font-size: 1.3rem; }
      .footer-common .menu--common-footer {
        -webkit-box-ordinal-group: 3;
                order: 2;
        padding-top: 1rem;
        padding-bottom: 1rem; }
        .footer-common .menu--common-footer a {
          display: block;
          padding: 0.5rem 0; }
      .footer-common .footer-logo {
        -webkit-box-ordinal-group: 2;
                order: 1;
        margin: auto; } }
  @media (min-width: 992px) {
    .footer-common {
      -webkit-box-pack: justify;
              justify-content: space-between;
      -webkit-box-align: center;
              align-items: center; }
      .footer-common .menu-item {
        position: relative;
        display: inline-block;
        vertical-align: top;
        padding: 0 1rem;
        line-height: normal; }
        .footer-common .menu-item:first-child::before {
          display: none; }
        .footer-common .menu-item::before {
          content: '';
          position: absolute;
          left: 0;
          top: 50%;
          -webkit-transform: translateY(-50%);
                  transform: translateY(-50%);
          display: block;
          width: 0.1rem;
          height: 1.6rem;
          background-color: #454545; } }

.footer-segment,
.footer-common {
  border-top: 0.1rem solid #E4E4E4; }

.footer-logo {
  width: 22rem;
  overflow: hidden; }
  .footer-logo img {
    max-width: 100%;
    height: auto; }

@media (min-width: 992px) {
  .footer-wrapper {
    margin: 9rem auto 0; } }

.a11y-config .modal-dialog {
  max-width: 55rem; }

.a11y-config .modal-header {
  padding: 0;
  margin-bottom: 2rem; }

.a11y-config h1 {
  margin-top: 0;
  margin-bottom: 0;
  padding-top: 0;
  text-transform: uppercase; }
  .a11y-config h1 span {
    display: block;
    font-size: 1.6rem;
    font-weight: 600;
    text-transform: none;
    color: #495057; }

.a11y-config fieldset {
  display: block;
  word-spacing: -.25em; }

.a11y-config fieldset ~ fieldset legend {
  padding-top: 1rem; }

.a11y-config legend {
  display: block;
  width: 100%;
  text-transform: uppercase;
  font-size: 1.4rem;
  text-align: left;
  font-weight: 700;
  word-spacing: normal; }

.a11y-config input {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0; }

.a11y-config .btn-close {
  float: right;
  margin: 0;
  padding: 0.5rem;
  font-weight: 700;
  text-transform: uppercase;
  border: 0;
  background-color: transparent; }
  .a11y-config .btn-close:hover .btn-text {
    text-decoration: underline; }

.a11y-config .icon-close[aria-hidden='true'] {
  margin-right: 1rem;
  display: inline-block;
  color: #e5291d; }

.a11y-config--item {
  display: inline-block;
  vertical-align: top;
  margin-top: 1rem;
  margin-right: 1rem;
  margin-bottom: 1rem;
  word-spacing: normal; }
  .a11y-config--item label {
    position: relative;
    display: block;
    padding: 1rem 3rem;
    min-width: 15rem;
    font-size: 1.6rem;
    font-weight: 400;
    text-align: center;
    text-transform: none;
    border: 0.1rem solid #454545;
    background-color: #FFFFFF;
    color: #454545;
    -webkit-transition: background-color 0.3s ease, color 0.3s ease, border 0.3s ease;
    transition: background-color 0.3s ease, color 0.3s ease, border 0.3s ease; }
    .a11y-config--item label:hover {
      border-color: #e5291d;
      background-color: #e5291d;
      color: #FFFFFF; }
  .a11y-config--item input:focus + label {
    outline: 0.1rem dashed #454545;
    outline-offset: 0.4rem; }
  .a11y-config--item input:checked + label {
    border-color: #e5291d;
    background-color: #e5291d;
    color: #FFFFFF; }
    .a11y-config--item input:checked + label:before {
      content: "";
      font-family: "bdt" !important;
      font-style: normal;
      font-weight: normal;
      font-variant: normal;
      text-transform: none;
      line-height: 1;
      font-size: inherit;
      color: inherit;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      -webkit-alt: "";
      speak: none;
      position: absolute;
      top: 50%;
      left: 1rem;
      -webkit-transform: translate(0, -50%);
              transform: translate(0, -50%);
      font-size: 1.2rem; }

[data-contrast='inv-c'] {
  background-color: #000080 !important;
  color: #FFFF00 !important; }
  [data-contrast='inv-c'] ::-webkit-input-placeholder {
    color: #FFFF00 !important; }
  [data-contrast='inv-c'] :-moz-placeholder {
    color: #FFFF00 !important; }
  [data-contrast='inv-c'] ::-moz-placeholder {
    color: #FFFF00 !important; }
  [data-contrast='inv-c'] :-ms-input-placeholder {
    color: #FFFF00 !important; }
  [data-contrast='inv-c'] ::-moz-selection {
    color: #000080;
    background-color: #FFFF00; }
  [data-contrast='inv-c'] ::selection {
    color: #000080;
    background-color: #FFFF00; }
  [data-contrast='inv-c'] font {
    color: #FFFF00 !important; }
  [data-contrast='inv-c'] a,
  [data-contrast='inv-c'] span.ext:after {
    color: inherit; }
  [data-contrast='inv-c'] .modal-content {
    background-color: #000080;
    color: #FFFF00; }
  [data-contrast='inv-c'] .a11y-config .btn-close {
    background-color: #FFFF00;
    color: #000080; }
  [data-contrast='inv-c'] .a11y-config h1 span {
    color: #FFFF00; }
  [data-contrast='inv-c'] .a11y-config--item label::before {
    border-color: #FFFF00; }
  [data-contrast='inv-c'] .a11y-config--item label {
    color: #000080;
    background-color: #FFFF00;
    font-weight: 700; }
  [data-contrast='inv-c'] .a11y-config--item input:checked + label {
    color: #FFFF00;
    background-color: #000080;
    border-color: #FFFF00; }
  [data-contrast='inv-c'] .region-top {
    background-color: #000080;
    border-bottom: solid 0.1rem #FFFF00; }
    [data-contrast='inv-c'] .region-top li a {
      color: #FFFF00; }
    [data-contrast='inv-c'] .region-top li::after {
      background-color: #FFFF00; }
  [data-contrast='inv-c'] .header-top .header-name-title {
    background-color: #000080;
    color: #FFFF00; }
  [data-contrast='inv-c'] .header-top .header-name-title::after {
    border-color: transparent transparent transparent #000080; }
  [data-contrast='inv-c'] .header-top li.active::after {
    border-top-color: #FFFF00; }
  [data-contrast='inv-c'] .header-top li.active a {
    background-color: #FFFF00;
    color: #000080; }
  [data-contrast='inv-c'] .menu-button .menu-button-icon, [data-contrast='inv-c'] .menu-button:focus .menu-button-icon, [data-contrast='inv-c'] .menu-button:hover .menu-button-icon, [data-contrast='inv-c'] .menu-button:active .menu-button-icon {
    background-color: #000080; }
  [data-contrast='inv-c'] .menu-panel {
    color: #FFFF00;
    background-color: #00004d; }
    [data-contrast='inv-c'] .menu-panel li.first a,
    [data-contrast='inv-c'] .menu-panel li.is-parent a,
    [data-contrast='inv-c'] .menu-panel li.is-parent .link-more {
      background-color: #000080; }
      [data-contrast='inv-c'] .menu-panel li.first a:focus, [data-contrast='inv-c'] .menu-panel li.first a:hover, [data-contrast='inv-c'] .menu-panel li.first a:active,
      [data-contrast='inv-c'] .menu-panel li.is-parent a:focus,
      [data-contrast='inv-c'] .menu-panel li.is-parent a:hover,
      [data-contrast='inv-c'] .menu-panel li.is-parent a:active,
      [data-contrast='inv-c'] .menu-panel li.is-parent .link-more:focus,
      [data-contrast='inv-c'] .menu-panel li.is-parent .link-more:hover,
      [data-contrast='inv-c'] .menu-panel li.is-parent .link-more:active {
        background-color: #000034; }
  [data-contrast='inv-c'] .header {
    background-color: #000080; }
  [data-contrast='inv-c'] .header-logo {
    background-color: #FFFFFF; }
  [data-contrast='inv-c'] [class*="hover-theme-color"] h2 a:focus, [data-contrast='inv-c'] [class*="hover-theme-color"] h2 a:hover, [data-contrast='inv-c'] [class*="hover-theme-color"] h2 a:active {
    background-color: #000080; }
  [data-contrast='inv-c'] [class*="menuburger-theme-color"] h2 a::before {
    background-color: #FFFF00; }
  [data-contrast='inv-c'] [class*="menuburger-theme-color"] h2 a:focus, [data-contrast='inv-c'] [class*="menuburger-theme-color"] h2 a:hover, [data-contrast='inv-c'] [class*="menuburger-theme-color"] h2 a:active {
    background-color: #000034; }
  [data-contrast='inv-c'] [class*="menuburger-theme-color"] ~ ul li.first a:focus, [data-contrast='inv-c'] [class*="menuburger-theme-color"] ~ ul li.first a:hover, [data-contrast='inv-c'] [class*="menuburger-theme-color"] ~ ul li.first a:active, [data-contrast='inv-c'] [class*="menuburger-theme-color"] ~ ul li.first a.is-active, [data-contrast='inv-c'] [class*="menuburger-theme-color"] ~ ul li.first a.active {
    background-color: #000034; }
  [data-contrast='inv-c'] [class*="menuburger-theme-color"] ~ ul li.is-parent .link-more a {
    background-color: #000080; }
  [data-contrast='inv-c'] .btn, [data-contrast='inv-c'] .region-header-right .nav-link-user > a, .region-header-right [data-contrast='inv-c'] .nav-link-user > a,
  [data-contrast='inv-c'] .region-header-right .nav-link-user > button, .region-header-right [data-contrast='inv-c'] .nav-link-user > button {
    background-color: #FFFF00 !important;
    border-color: #FFFF00 !important;
    color: #000080 !important; }
  [data-contrast='inv-c'] a:focus, [data-contrast='inv-c'] a.focus, [data-contrast='inv-c'] button:focus, [data-contrast='inv-c'] button.focus, [data-contrast='inv-c'] input:focus, [data-contrast='inv-c'] input.focus, [data-contrast='inv-c'] textarea:focus, [data-contrast='inv-c'] textarea.focus,
  [data-contrast='inv-c'] .btn:focus,
  [data-contrast='inv-c'] .region-header-right .nav-link-user > a:focus,
  .region-header-right [data-contrast='inv-c'] .nav-link-user > a:focus,
  [data-contrast='inv-c'] .region-header-right .nav-link-user > button:focus,
  .region-header-right [data-contrast='inv-c'] .nav-link-user > button:focus {
    outline-color: #FFFF00; }
  [data-contrast='inv-c'] .popover {
    background-color: #000080;
    border-color: #FFFF00; }
    [data-contrast='inv-c'] .popover .popover-header, [data-contrast='inv-c'] .popover .popover-title,
    [data-contrast='inv-c'] .popover .popover-body, [data-contrast='inv-c'] .popover .popover-content {
      color: #FFFF00; }
    [data-contrast='inv-c'] .popover .popover-header, [data-contrast='inv-c'] .popover .popover-title {
      background-color: #000080; }
  [data-contrast='inv-c'] .footer-full {
    background-color: #000080; }
  [data-contrast='inv-c'] .footer-container,
  [data-contrast='inv-c'] .region-footer-bottom {
    border-color: #FFFF00; }
  [data-contrast='inv-c'] .region-footer .block-views h2,
  [data-contrast='inv-c'] .region-footer .block li::before,
  [data-contrast='inv-c'] .region-footer .btn-simple::before,
  [data-contrast='inv-c'] .region-footer .block h2 .icon {
    color: #FFFF00; }
  [data-contrast='inv-c'] .block-consignations-search-module + .block-menu a:focus, [data-contrast='inv-c'] .block-consignations-search-module + .block-menu a:hover, [data-contrast='inv-c'] .block-consignations-search-module + .block-menu a:active {
    color: #FFFF00;
    border-color: #FFFF00; }
  [data-contrast='inv-c'] .block-consignations-search-module + .block-menu .icon {
    color: #FFFF00 !important; }
  [data-contrast='inv-c'] .block-consignations-search-module .form-submit {
    color: #000080;
    background-color: #FFFF00; }
  [data-contrast='inv-c'] .block-consignations-search-module .form-text {
    color: #FFFF00;
    border-color: #FFFF00;
    background-color: #000080; }
  [data-contrast='inv-c'] .footer-copyright + .block-menu .menu .leaf::after {
    background-color: #FFFF00; }

[data-font='dys-font'] {
  font-family: 'OpenDyslexic' !important; }

[data-line-space='dys-line-space'] {
  line-height: 160% !important; }
  [data-line-space='dys-line-space'] h1, [data-line-space='dys-line-space'] .h1,
  [data-line-space='dys-line-space'] h2, [data-line-space='dys-line-space'] .h2 {
    line-height: 2.1; }
  [data-line-space='dys-line-space'] h3, [data-line-space='dys-line-space'] .h3, [data-line-space='dys-line-space'] .header-megamenu-nav-menu > .menu > .menu-item:nth-of-type(1) a, .header-megamenu-nav-menu > .menu > .menu-item:nth-of-type(1) [data-line-space='dys-line-space'] a,
  [data-line-space='dys-line-space'] h4, [data-line-space='dys-line-space'] .h4,
  [data-line-space='dys-line-space'] h5, [data-line-space='dys-line-space'] .h5,
  [data-line-space='dys-line-space'] h6, [data-line-space='dys-line-space'] .h6 {
    line-height: 1.9; }
  [data-line-space='dys-line-space'] p, [data-line-space='dys-line-space'] li {
    line-height: 2.2; }
  [data-line-space='dys-line-space'] blockquote, [data-line-space='dys-line-space'] .blockquote {
    line-height: 2.4; }

.btn, .region-header-right .nav-link-user > a,
.region-header-right .nav-link-user > button {
  text-transform: uppercase;
  text-decoration: none;
  white-space: normal;
  font-size: 1.4rem;
  padding: 1.4rem 2.2rem; }
  @media (max-width: 575.98px) {
    .btn, .region-header-right .nav-link-user > a,
    .region-header-right .nav-link-user > button {
      padding: 1.5rem; } }
  .btn span, .region-header-right .nav-link-user > a span, .region-header-right .nav-link-user > button span {
    display: inline-block;
    vertical-align: middle; }
  .btn [class^='icon-'], .region-header-right .nav-link-user > a [class^='icon-'], .region-header-right .nav-link-user > button [class^='icon-'] {
    font-size: 100%;
    line-height: normal; }

.btn-primary {
  color: #FFFFFF;
  background-color: transparent;
  border-color: #000000;
  box-shadow: none;
  color: #000000; }
  .btn-primary:hover {
    color: #FFFFFF;
    background-color: #e5291d;
    border-color: #e5291d; }
  .btn-primary:focus, .btn-primary.focus {
    box-shadow: none, 0 0 0 0rem rgba(0, 0, 0, 0.5); }
  .btn-primary.disabled, .btn-primary:disabled {
    color: #FFFFFF;
    background-color: transparent;
    border-color: #000000; }
  .btn-primary:not(:disabled):not(.disabled):active, .btn-primary:not(:disabled):not(.disabled).active,
  .show > .btn-primary.dropdown-toggle {
    color: #FFFFFF;
    background-color: #B90D0D;
    border-color: #B90D0D; }
    .btn-primary:not(:disabled):not(.disabled):active:focus, .btn-primary:not(:disabled):not(.disabled).active:focus,
    .show > .btn-primary.dropdown-toggle:focus {
      box-shadow: none, 0 0 0 0rem rgba(0, 0, 0, 0.5); }
  .btn-primary:focus {
    outline: 0.1rem dashed #454545;
    outline-offset: 0.4rem;
    outline-color: #e5291d !important; }

.btn-secondary:focus {
  outline: 0.1rem dashed #e5291d;
  outline-offset: 0.4rem; }

.btn-primary.disabled, .btn-primary:disabled, .btn-primary[aria-disabled="true"],
.btn-secondary.disabled,
.btn-secondary:disabled,
.btn-secondary[aria-disabled="true"] {
  background-color: #757575;
  border-color: #757575; }

.btn-primary:focus,
.btn-secondary:focus {
  outline-color: #495057 !important; }

.btn-primary.disabled, .btn-primary:disabled, .btn-primary[aria-disabled="true"] {
  color: #FFFFFF; }

.btn-primary:not(:disabled):not(.disabled):active,
.btn-primary:not(:disabled):not(.disabled).active,
.btn-secondary:not(:disabled):not(.disabled):active,
.btn-secondary:not(:disabled):not(.disabled).active {
  background-color: #757575;
  border-color: #757575; }

.btn-tertiary {
  background-color: transparent;
  border-color: #FFFFFF;
  color: #FFFFFF; }
  .btn-tertiary:focus, .btn-tertiary:hover, .btn-tertiary:active {
    background-color: #FFFFFF;
    border-color: #FFFFFF;
    color: #e5291d; }
  .btn-tertiary:focus {
    outline-color: #FFFFFF; }

[class*='btn-icon-'] {
  display: -webkit-box;
  display: flex;
  -webkit-box-align: center;
          align-items: center; }

.btn-icon-left [class^='icon-'] {
  margin-right: 0.6rem; }

.btn-icon-right [class^='icon-'] {
  margin-left: 0.6rem; }

[class*="btn-outline"] [class^='icon-'] {
  color: #e5291d; }

[class*="btn-outline"]:hover [class^='icon-'], [class*="btn-outline"]:focus [class^='icon-'], [class*="btn-outline"]:active [class^='icon-'] {
  color: inherit; }

.btn-outline-transparent {
  border-color: transparent; }

.btn-outline-primary:hover {
  background-color: #e5291d;
  border-color: #e5291d; }

.btn-outline-primary:focus {
  background-color: #B90D0D;
  border-color: #B90D0D; }

.btn-outline-primary:active {
  background-color: #A00C0C;
  border-color: #A00C0C; }

.btn-outline-primary:not(:disabled):not(.disabled):active,
.btn-outline-secondary:not(:disabled):not(.disabled):active {
  background-color: #A00C0C;
  border-color: #A00C0C; }

.popover {
  min-width: 25rem; }

.popover-header {
  padding-left: 4.8rem;
  padding-bottom: 0rem;
  border-bottom: 0;
  line-height: 1; }
  .popover-header:after {
    content: "";
    font-family: "bdt" !important;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    font-size: inherit;
    color: inherit;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-alt: "";
    speak: none;
    position: absolute;
    top: 2.4rem;
    left: 2.4rem;
    color: #FFFFFF; }

.popover-body {
  line-height: 150%;
  min-width: 25rem; }

.custom-control-type-2 {
  display: inline-block;
  vertical-align: middle; }

.custom-radio-type-2.custom-control {
  padding-left: 0; }

.custom-radio-type-2.custom-control-inline {
  margin-right: 0; }

.custom-radio-type-2 input {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0; }

.custom-radio-type-2 label {
  display: block;
  margin-bottom: 0;
  padding: 0 1.4rem;
  width: 100%;
  height: 4.5rem;
  border: 0.1rem solid #CCCCCC;
  background-color: transparent;
  line-height: 4.5rem; }

.custom-radio-type-2 input:checked + label {
  position: relative;
  padding-right: 3.3rem;
  border-color: #e5291d;
  background-color: #e5291d;
  color: #FFFFFF; }
  .custom-radio-type-2 input:checked + label:after {
    content: "";
    font-family: "bdt" !important;
    font-style: normal;
    font-weight: normal;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    font-size: inherit;
    color: inherit;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-alt: "";
    speak: none;
    position: absolute;
    top: 50%;
    right: 1rem;
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%);
    font-size: 1.6rem; }

.custom-radio-type-2 + .custom-radio-type-2 {
  margin-left: 0.6rem; }

.custom-radio .custom-control-input[aria-disabled="true"]:checked ~ .custom-control-label::before {
  background-color: rgba(69, 69, 69, 0.5); }

.custom-checkbox .custom-control-input[aria-disabled=true] ~ .custom-control-label, .custom-checkbox .custom-control-input[readonly] ~ .custom-control-label {
  color: #757575; }
  .custom-checkbox .custom-control-input[aria-disabled=true] ~ .custom-control-label::before, .custom-checkbox .custom-control-input[readonly] ~ .custom-control-label::before {
    background-color: #E4E4E4; }

.custom-checkbox .custom-control-input[readonly] ~ .custom-control-label::before {
  background-color: #FFFFFF; }

.custom-checkbox .custom-control-input[readonly] ~ .custom-control-label::after {
  background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3E%3Cpath fill='%23757575' d='M6.564.75l-3.59 3.612-1.538-1.55L0 4.26 2.974 7.25 8 2.193z'/%3E%3C/svg%3E"); }

.custom-checkbox .custom-control-input[aria-disabled=true]:checked ~ .custom-control-label::after {
  background-image: none; }

.custom-checkbox .custom-control-input[aria-disabled=true]:indeterminate ~ .custom-control-label::before {
  background-color: rgba(69, 69, 69, 0.5); }

.custom-checkbox .custom-control-input[aria-disabled=true]:indeterminate ~ .custom-control-label::before {
  background-color: rgba(69, 69, 69, 0.5); }

.custom-file-input[aria-disabled=true] ~ .custom-file-label {
  background-color: #E4E4E4; }

input[type="text"][aria-disabled="true"], input[type="text"][readonly],
select[aria-disabled="true"],
select[readonly] {
  background-color: #E4E4E4;
  border-color: #CCCCCC;
  pointer-events: none; }
  input[type="text"][aria-disabled="true"]:focus, input[type="text"][readonly]:focus,
  select[aria-disabled="true"]:focus,
  select[readonly]:focus {
    border-color: #CCCCCC; }

input[type="text"][aria-disabled="true"],
select[aria-disabled="true"] {
  color: transparent; }

select.form-control[aria-disabled="true"] {
  color: transparent; }
  select.form-control[aria-disabled="true"]:focus {
    background-color: #E4E4E4; }

.float-target-parent.focused input[type="text"][aria-disabled="true"] ~ label, .form-has-floatlabel .focused.js-form-type-search input[type="text"][aria-disabled="true"] ~ label, .form-has-floatlabel .focused.js-form-item-field-tra-geography input[type="text"][aria-disabled="true"] ~ label {
  -webkit-transform: none;
          transform: none; }

.custom-select[aria-disabled="true"] {
  color: #6c757d;
  background-color: #E4E4E4; }

.form-has-customselect .form-customselect__menu [type='text'], .form-has-customselect .form-customselect__menu [type='date'], .form-has-customselect .form-customselect__menu [type='search'],
.form-has-customselect .form-customselect__menu [type='password'], .form-has-customselect .form-customselect__menu [type='email'],
.form-has-customselect .form-customselect__menu [type='submit']:not(.btn-sm),
.form-has-customselect .form-customselect__menu select,
.form-has-customselect .form-customselect__menu button:not(.btn-sm) {
  font-size: 1.2rem !important;
  font-weight: 500;
  height: 4rem; }

.form-has-customselect .form-customselect__menu input::-webkit-input-placeholder,
.form-has-customselect .form-customselect__menu label {
  font-size: 1.2rem !important;
  font-weight: 500; }

.form-has-customselect .form-customselect__menu input::-moz-placeholder,
.form-has-customselect .form-customselect__menu label {
  font-size: 1.2rem !important;
  font-weight: 500; }

.form-has-customselect .form-customselect__menu input:-ms-input-placeholder,
.form-has-customselect .form-customselect__menu label {
  font-size: 1.2rem !important;
  font-weight: 500; }

.form-has-customselect .form-customselect__menu input::-ms-input-placeholder,
.form-has-customselect .form-customselect__menu label {
  font-size: 1.2rem !important;
  font-weight: 500; }

.form-has-customselect .form-customselect__menu input::placeholder,
.form-has-customselect .form-customselect__menu label {
  font-size: 1.2rem !important;
  font-weight: 500; }

.form-has-customselect .form-customselect__menu .float-target-parent label, .form-has-customselect .form-customselect__menu .form-has-floatlabel .js-form-type-search label, .form-has-floatlabel .form-has-customselect .form-customselect__menu .js-form-type-search label, .form-has-customselect .form-customselect__menu .form-has-floatlabel .js-form-item-field-tra-geography label, .form-has-floatlabel .form-has-customselect .form-customselect__menu .js-form-item-field-tra-geography label {
  -webkit-transform: translateY(-50%) translateX(2rem);
          transform: translateY(-50%) translateX(2rem); }

.form-has-customselect .form-customselect__menu .float-target-parent label[for^="field_tra_geography"], .form-has-customselect .form-customselect__menu .form-has-floatlabel .js-form-type-search label[for^="field_tra_geography"], .form-has-floatlabel .form-has-customselect .form-customselect__menu .js-form-type-search label[for^="field_tra_geography"], .form-has-customselect .form-customselect__menu .form-has-floatlabel .js-form-item-field-tra-geography label[for^="field_tra_geography"], .form-has-floatlabel .form-has-customselect .form-customselect__menu .js-form-item-field-tra-geography label[for^="field_tra_geography"] {
  -webkit-transform: translateY(-50%) translateX(5.5rem);
          transform: translateY(-50%) translateX(5.5rem); }

.form-has-customselect .form-customselect__menu .float-target-parent.focused label, .form-has-customselect .form-customselect__menu .form-has-floatlabel .focused.js-form-type-search label, .form-has-floatlabel .form-has-customselect .form-customselect__menu .focused.js-form-type-search label, .form-has-customselect .form-customselect__menu .form-has-floatlabel .focused.js-form-item-field-tra-geography label, .form-has-floatlabel .form-has-customselect .form-customselect__menu .focused.js-form-item-field-tra-geography label {
  -webkit-transform: translateY(-3.5rem) translateX(1rem);
          transform: translateY(-3.5rem) translateX(1rem); }

.form-customselect__toggler {
  color: #171717;
  background-color: #FFFFFF;
  border-color: #FFFFFF;
  box-shadow: none;
  display: -webkit-inline-box;
  display: inline-flex;
  font-size: 1.2rem;
  font-weight: 500;
  color: #757575;
  text-transform: none;
  text-align: left;
  white-space: nowrap; }
  .form-customselect__toggler:hover {
    color: #171717;
    background-color: #FFFFFF;
    border-color: #FFFFFF; }
  .form-customselect__toggler:focus, .form-customselect__toggler.focus {
    box-shadow: none, 0 0 0 0rem rgba(255, 255, 255, 0.5); }
  .form-customselect__toggler.disabled, .form-customselect__toggler:disabled {
    color: #171717;
    background-color: #FFFFFF;
    border-color: #FFFFFF; }
  .form-customselect__toggler:not(:disabled):not(.disabled):active, .form-customselect__toggler:not(:disabled):not(.disabled).active,
  .show > .form-customselect__toggler.dropdown-toggle {
    color: #171717;
    background-color: #FFFFFF;
    border-color: #FFFFFF; }
    .form-customselect__toggler:not(:disabled):not(.disabled):active:focus, .form-customselect__toggler:not(:disabled):not(.disabled).active:focus,
    .show > .form-customselect__toggler.dropdown-toggle:focus {
      box-shadow: none, 0 0 0 0rem rgba(255, 255, 255, 0.5); }
  .form-customselect__toggler:not(:disabled):not(.disabled):active {
    color: #495057; }
  .form-customselect__toggler:hover, .form-customselect__toggler:focus {
    color: #495057; }
  .form-customselect__toggler.dropdown-toggle {
    position: relative; }
    .form-customselect__toggler.dropdown-toggle::after {
      top: 35%;
      -webkit-transition: -webkit-transform 0.260s ease-in-out;
      transition: -webkit-transform 0.260s ease-in-out;
      transition: transform 0.260s ease-in-out;
      transition: transform 0.260s ease-in-out, -webkit-transform 0.260s ease-in-out;
      position: absolute;
      right: 1.5rem; }

.form-customselect__menu {
  min-width: 29rem;
  max-width: 38rem;
  padding: 0;
  font-weight: 500;
  font-size: 1.2rem;
  color: #757575;
  border: solid 0.1rem #E4E4E4;
  box-shadow: 0 0 0.8rem 0 rgba(23, 23, 23, 0.15); }
  .form-customselect__menu-body {
    max-height: 38rem;
    min-height: 9rem;
    overflow-y: overlay;
    overflow-x: hidden;
    margin: 0;
    padding: 1rem 0;
    background-color: #FFFFFF;
    scrollbar-width: thin;
    overscroll-behavior-y: contain; }
    @supports not (overflow-y: overlay) {
      .form-customselect__menu-body {
        overflow-y: auto; } }
    .form-customselect__menu-body::-webkit-scrollbar {
      width: 0.5rem;
      height: 0.5rem; }
    .form-customselect__menu-body::-webkit-scrollbar-thumb {
      background: #CCCCCC; }
    .form-customselect__menu-body::-webkit-scrollbar-track {
      background: transparent; }
    .form-customselect__menu-body {
      scrollbar-face-color: #CCCCCC;
      scrollbar-track-color: transparent;
      -ms-overflow-style: -ms-autohiding-scrollbar; }
    .form-customselect__menu-body {
      scrollbar-width: 0.5rem;
      /* Firefox */ }
    .form-customselect__menu-body .form-group-icon-left [class*='icon-']::before {
      left: 1rem; }
    .form-customselect__menu-body .float-target-parent [type="text"], .form-customselect__menu-body .form-has-floatlabel .js-form-type-search [type="text"], .form-has-floatlabel .form-customselect__menu-body .js-form-type-search [type="text"], .form-customselect__menu-body .form-has-floatlabel .js-form-item-field-tra-geography [type="text"], .form-has-floatlabel .form-customselect__menu-body .js-form-item-field-tra-geography [type="text"] {
      display: block;
      width: 100%;
      padding: 1.4rem 2.4rem;
      border: 0.1rem solid #CCCCCC;
      -webkit-transition: border-color .3s ease;
      transition: border-color .3s ease; }
      .form-customselect__menu-body .float-target-parent [type="text"][name="field_tra_geography"], .form-customselect__menu-body .form-has-floatlabel .js-form-type-search [type="text"][name="field_tra_geography"], .form-has-floatlabel .form-customselect__menu-body .js-form-type-search [type="text"][name="field_tra_geography"], .form-customselect__menu-body .form-has-floatlabel .js-form-item-field-tra-geography [type="text"][name="field_tra_geography"], .form-has-floatlabel .form-customselect__menu-body .js-form-item-field-tra-geography [type="text"][name="field_tra_geography"] {
        padding-left: 4.5rem; }
  .form-customselect__menu-footer {
    text-align: center;
    padding-top: 2rem;
    padding-bottom: 2rem;
    background-color: #FFFFFF;
    border-top: solid 0.1rem #E4E4E4; }
  .form-customselect__menu::before, .form-customselect__menu::after {
    content: "";
    position: absolute;
    left: 4rem; }
  .form-customselect__menu[x-placement="top-start"] {
    margin-bottom: 2rem; }
    .form-customselect__menu[x-placement="top-start"]::before {
      bottom: -0.8rem;
      height: 0;
      width: 0;
      border-top: 0.8rem solid #E4E4E4;
      border-left: 0.8rem solid transparent;
      border-right: 0.8rem solid transparent; }
    .form-customselect__menu[x-placement="top-start"]::after {
      bottom: -0.7rem;
      height: 0;
      width: 0;
      border-top: 0.7rem solid #FFFFFF;
      border-left: 0.7rem solid transparent;
      border-right: 0.7rem solid transparent; }
  .form-customselect__menu[x-placement="bottom-start"] {
    margin-top: 2rem; }
    .form-customselect__menu[x-placement="bottom-start"]::before {
      top: -0.8rem;
      height: 0;
      width: 0;
      border-bottom: 0.8rem solid #E4E4E4;
      border-left: 0.8rem solid transparent;
      border-right: 0.8rem solid transparent; }
    .form-customselect__menu[x-placement="bottom-start"]::after {
      top: -0.7rem;
      height: 0;
      width: 0;
      border-bottom: 0.7rem solid #FFFFFF;
      border-left: 0.7rem solid transparent;
      border-right: 0.7rem solid transparent; }
  .form-customselect__menu .dropdown-divider {
    margin-top: 1rem;
    margin-bottom: 1rem; }
  .form-customselect__menu .custom-control-input {
    position: absolute;
    z-index: 0;
    left: 1.2rem;
    top: 0.3rem;
    opacity: 0;
    outline-width: 0.1rem;
    outline-offset: 0.2rem; }
  .form-customselect__menu .custom-control-input:focus ~ .custom-control-label {
    color: #171717;
    outline: dashed 0.1rem #454545;
    outline-offset: 0.2rem; }

.form-customselect__calendar-wrapper ngb-datepicker {
  width: 100%;
  border-top: solid 0.1rem #E4E4E4; }

.form-customselect__tick {
  display: block;
  min-height: initial;
  padding-left: 0;
  margin: 0.5rem 0;
  padding: 0.3rem 1rem 0.3rem 3rem;
  color: inherit;
  text-decoration: none !important;
  -webkit-transition: background 0.260s ease-in-out;
  transition: background 0.260s ease-in-out; }
  .form-customselect__tick:hover, .form-customselect__tick:focus {
    color: inherit;
    background-color: #F4F4F4;
    text-decoration: none; }
  .form-customselect__tick .custom-control-label {
    display: block;
    vertical-align: middle;
    -webkit-transition: color 0.260s ease-in-out;
    transition: color 0.260s ease-in-out; }
    .form-customselect__tick .custom-control-label:hover, .form-customselect__tick .custom-control-label:focus {
      color: #171717; }
  .form-customselect__tick .custom-control-label::before,
  .form-customselect__tick .custom-control-label::after {
    top: -0.2rem;
    left: -2.0rem;
    width: 1.8rem;
    height: 1.8rem;
    display: -webkit-inline-box;
    display: inline-flex;
    -webkit-box-align: center;
            align-items: center;
    -webkit-box-pack: center;
            justify-content: center; }
  .form-customselect__tick .custom-control-label::before {
    background-color: rgba(255, 255, 255, 0); }
  .form-customselect__tick .custom-control-input:checked ~ .custom-control-label::before {
    background-color: rgba(255, 255, 255, 0); }
  .form-customselect__tick .custom-control-label:active::after,
  .form-customselect__tick .custom-control-input:checked ~ .custom-control-label::after {
    content: "\e918";
    font-family: 'bdt';
    font-size: 0.85rem;
    background-image: none; }
  .form-customselect__tick .custom-control-input:active ~ .custom-control-label::before {
    background-color: #F4F4F4; }
  .form-customselect__tick .custom-control-input:focus ~ .custom-control-label::before {
    box-shadow: none; }
  .form-customselect__tick.custom-checkbox .custom-control-label::before,
  .form-customselect__tick.custom-checkbox .custom-control-label::after {
    border: solid 1px #E4E4E4;
    border-radius: 0; }
  .form-customselect__tick.custom-radio .custom-control-label::before,
  .form-customselect__tick.custom-radio .custom-control-label::after {
    border: solid 1px transparent;
    border-radius: 100%; }
  .form-customselect__tick.custom-control {
    margin-bottom: .5rem; }

.form-customselect__btn {
  font-size: 1.2rem;
  padding-top: 1rem;
  padding-bottom: 1rem; }

.form-customselect__link {
  display: block;
  min-height: initial;
  padding-left: 0;
  margin: 0.5rem 0;
  padding: 0.3rem 1rem 0.3rem 3rem;
  color: inherit;
  text-decoration: none !important;
  -webkit-transition: background 0.260s ease-in-out;
  transition: background 0.260s ease-in-out; }
  .form-customselect__link:hover, .form-customselect__link:focus {
    color: inherit;
    background-color: #F4F4F4;
    text-decoration: none; }

.form-has-floatlabel .float-target-parent label, .form-has-floatlabel .js-form-type-search label, .form-has-floatlabel .js-form-item-field-tra-geography label,
.form-has-floatlabel .js-form-type-search label,
.form-has-floatlabel .js-form-item-field-tra-geography label {
  max-width: 75%; }

.form-has-floatlabel .focused.js-form-item label {
  color: #757575;
  max-width: 95%;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  background-color: transparent; }

.form-screener__slides-outer {
  padding-bottom: 1rem; }

.form-screener__slides-formcontrol {
  z-index: 51;
  top: calc(50% - 1.75rem);
  right: 0;
  background-image: -webkit-gradient(linear, left top, right top, from(rgba(255, 255, 255, 0.1)), color-stop(10%, rgba(255, 255, 255, 0.85)), to(white));
  background-image: linear-gradient(90deg, rgba(255, 255, 255, 0.1) 0%, rgba(255, 255, 255, 0.85) 10%, white 100%); }
  .form-screener__slides-formcontrol .btn, .form-screener__slides-formcontrol .region-header-right .nav-link-user > a, .region-header-right .form-screener__slides-formcontrol .nav-link-user > a,
  .form-screener__slides-formcontrol .region-header-right .nav-link-user > button, .region-header-right .form-screener__slides-formcontrol .nav-link-user > button {
    text-transform: none; }
  .border.position-relative.pl-3 .form-screener__slides-formcontrol {
    right: 1rem;
    top: calc(50% - 1.35rem); }

.form-screener__slides {
  padding-right: 11rem;
  z-index: 50; }
  .form-screener__slides .owl-stage-outer {
    overflow: visible !important; }
  .form-screener__slides .owl-stage {
    display: -webkit-box;
    display: flex;
    flex-wrap: nowrap; }

.ui-menu.ui-widget.ui-autocomplete {
  z-index: 1001;
  max-height: 18rem;
  overflow-y: auto; }

.block-multi-item .button {
  width: 25rem;
  max-width: 25rem;
  min-width: 25rem; }

[class^="alert-"], [class*="alert-"] {
  padding: 1.6rem 3rem 1.6rem 7.4rem;
  color: #171717; }
  [class^="alert-"] [class^="icon-"]::before, [class^="alert-"] [class*="icon-"]::before, [class*="alert-"] [class^="icon-"]::before, [class*="alert-"] [class*="icon-"]::before {
    position: absolute;
    top: 1.5rem;
    left: 2.3rem;
    font-size: 2.4rem; }

.spinner__items {
  display: inline-block;
  position: relative;
  width: 64px;
  height: 64px; }

.spinner__item {
  -webkit-animation: spinner 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
          animation: spinner 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  -webkit-transform-origin: 32px 32px;
          transform-origin: 32px 32px; }

.spinner__item:after {
  content: ' ';
  display: block;
  position: absolute;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #e5291d;
  margin: -3px 0 0 -3px; }

.spinner__item:nth-child(1) {
  -webkit-animation-delay: -0.036s;
          animation-delay: -0.036s; }

.spinner__item:nth-child(1):after {
  top: 50px;
  left: 50px; }

.spinner__item:nth-child(2) {
  -webkit-animation-delay: -0.072s;
          animation-delay: -0.072s; }

.spinner__item:nth-child(2):after {
  top: 54px;
  left: 45px; }

.spinner__item:nth-child(3) {
  -webkit-animation-delay: -0.108s;
          animation-delay: -0.108s; }

.spinner__item:nth-child(3):after {
  top: 57px;
  left: 39px; }

.spinner__item:nth-child(4) {
  -webkit-animation-delay: -0.144s;
          animation-delay: -0.144s; }

.spinner__item:nth-child(4):after {
  top: 58px;
  left: 32px; }

.spinner__item:nth-child(5) {
  -webkit-animation-delay: -0.18s;
          animation-delay: -0.18s; }

.spinner__item:nth-child(5):after {
  top: 57px;
  left: 25px; }

.spinner__item:nth-child(6) {
  -webkit-animation-delay: -0.216s;
          animation-delay: -0.216s; }

.spinner__item:nth-child(6):after {
  top: 54px;
  left: 19px; }

.spinner__item:nth-child(7) {
  -webkit-animation-delay: -0.252s;
          animation-delay: -0.252s; }

.spinner__item:nth-child(7):after {
  top: 50px;
  left: 14px; }

.spinner__item:nth-child(8) {
  -webkit-animation-delay: -0.288s;
          animation-delay: -0.288s; }

.spinner__item:nth-child(8):after {
  top: 45px;
  left: 10px; }

@-webkit-keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg); }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg); } }

@keyframes spinner {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg); }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg); } }

.icdc-drupal [role=main],
.icdc-angular [role=main] {
  padding-top: 14.4rem; }

/*# sourceMappingURL=style.css.map */
</style>
<link type="image/vnd.microsoft.icon" rel="shortcut icon" data-savepage-href="https://static.cdc-net.com/sso/theme/attente/favicon.ico" href="data:image/x-icon;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAQAABILAAASCwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHh7wAB4e8AMeHvA9Hh7wuh4e8LweHvBAHh7wBB4e8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeHvAAHh7wAB4e8CMeHvCKHh7w6h4e8PIeHvDyHh7w6x4e8I4eHvAmHh7wAR4e8AAAAAAAAAAAAB4e8AAeHvAAHh7wDB4e8DIeHvDWHh7w+h4e8LMeHvBCHh7wQh4e8LMeHvD5Hh7w3x4e8HYeHvAYHh7wAB4e8AAeHvAAHh7wUB4e8KQeHvBZHh7wwR4e8FoeHvAMHh7wAB4e8AAeHvALHh7wWB4e8MkeHvD8Hh7wzh4e8E4eHvAAHh7wAx4e8KweHvDdHh7wKB4e8BMeHvAAHh7wAAAAAAAAAAAAHh7wAB4e8AAeHvAVHh7wcB4e8N0eHvCqHh7wAx4e8AMeHvCtHh7w3h4e8BkeHvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHh7wAB4e8AceHvBEHh7wTB4e8AMeHvADHh7wrR4e8N4eHvAZHh7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4e8AAeHvAWHh7wuR4e8GkeHvAAHh7wAx4e8K0eHvDeHh7wGR4e8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeHvAAHh7wFh4e8NoeHvCtHh7wAx4e8AMeHvCtHh7w3h4e8BkeHvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHh7wAB4e8BYeHvDaHh7wrR4e8AMeHvADHh7wrR4e8N4eHvAZHh7wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4e8AAeHvAWHh7w2h4e8K0eHvADHh7wAx4e8K0eHvDeHh7wGR4e8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeHvAAHh7wFh4e8NoeHvCtHh7wAx4e8AMeHvCrHh7w9h4e8HYeHvAVHh7wAB4e8AAAAAAAAAAAAB4e8AAeHvAAHh7wFB4e8HUeHvD1Hh7wqx4e8AMeHvAAHh7wTB4e8MoeHvD7Hh7wyR4e8FgeHvANHh7wAB4e8AAeHvALHh7wVx4e8MgeHvD7Hh7wzB4e8E4eHvAAHh7wAB4e8AAeHvAWHh7wcR4e8NweHvD3Hh7whx4e8AweHvBAHh7wsh4e8PkeHvDfHh7wdR4e8BceHvAAHh7wAAAAAAAAAAAAHh7wAB4e8AAeHvAkHh7wXx4e8EgeHvCcHh7w8B4e8OseHvCNHh7wJR4e8AEeHvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHh7wAB4e8AAeHvAsHh7wvB4e8LweHvA/Hh7wAx4e8AAAAAAAAAAAAAAAAAAAAAAA+B8AAOAHAACAAwAAgYEAAAfgAAAP8AAAD/AAAA/wAAAP8AAAD/AAAA/wAAAH4AAAgYEAAMADAADgBwAA/B8AAA==">

<style>
h1:before {
	content: none !important;
}
</style>

<script data-savepage-src="https://static.cdc-net.com/sso/theme/bootstrap/js/jquery.js" data-savepage-type="text/javascript" type="text/plain"></script><script bis_use="true" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" nonce="" data-dynamic-id="996dab83-8cb9-4a6c-b5c3-d6419b4fc9ce" data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/executors/200.js"></script><script bis_use="true" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" nonce="" data-dynamic-id="996dab83-8cb9-4a6c-b5c3-d6419b4fc9ce" data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/executors/101.js"></script>
<script data-savepage-type="text/javascript" type="text/plain"></script>
<style>@keyframes slide-in-one-tap {
  from {
    transform: translateY(80px);
  }
  to {
    transform: translateY(0px);
  }
}

.trust-hide-gracefully {
  opacity: 0;
}

.trust-wallet-one-tap .hidden {
    display: none;
  }

.trust-wallet-one-tap .semibold {
    font-weight: 500;
  }

.trust-wallet-one-tap .binance-plex {
    font-family: 'Binance';
  }

.trust-wallet-one-tap .rounded-full {
    border-radius: 50%;
  }

.trust-wallet-one-tap .flex {
    display: flex;
  }

.trust-wallet-one-tap .flex-col {
    flex-direction: column;
  }

.trust-wallet-one-tap .items-center {
    align-items: center;
  }

.trust-wallet-one-tap .space-between {
    justify-content: space-between;
  }

.trust-wallet-one-tap .justify-center {
    justify-content: center;
  }

.trust-wallet-one-tap .w-full {
    width: 100%;
  }

.trust-wallet-one-tap .box {
    transition: all 0.5s cubic-bezier(0, 0, 0, 1.43);
    animation: slide-in-one-tap 0.5s cubic-bezier(0, 0, 0, 1.43);
    width: 384px;
    border-radius: 15px;
    background: #fff;
    box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.25);
    position: fixed;
    right: 30px;
    bottom: 30px;
    z-index: 1020;
  }

.trust-wallet-one-tap .header {
    gap: 15px;
    border-bottom: 1px solid #e6e6e6;
    padding: 10px 18px;
  }

.trust-wallet-one-tap .header .left-items {
      gap: 15px;
    }

.trust-wallet-one-tap .header .title {
      color: #1e2329;
      font-size: 18px;
      font-weight: 600;
      line-height: 28px;
    }

.trust-wallet-one-tap .header .subtitle {
      color: #474d57;
      font-size: 14px;
      line-height: 20px;
    }

.trust-wallet-one-tap .header .close {
      color: #1e2329;
      cursor: pointer;
    }

.trust-wallet-one-tap .body {
    padding: 9px 18px;
    gap: 10px;
  }

.trust-wallet-one-tap .body .right-items {
      gap: 10px;
      width: 100%;
    }

.trust-wallet-one-tap .body .right-items .wallet-title {
        color: #1e2329;
        font-size: 16px;
        font-weight: 600;
        line-height: 20px;
      }

.trust-wallet-one-tap .body .right-items .wallet-subtitle {
        color: #474d57;
        font-size: 14px;
        line-height: 20px;
      }

.trust-wallet-one-tap .connect-indicator {
    gap: 15px;
    padding: 8px 0;
  }

.trust-wallet-one-tap .connect-indicator .flow-icon {
      color: #474d57;
    }

.trust-wallet-one-tap .loading-color {
    color: #fff;
  }

.trust-wallet-one-tap .button {
    border-radius: 50px;
    outline: 2px solid transparent;
    outline-offset: 2px;
    background-color: rgb(5, 0, 255);
    border-color: rgb(229, 231, 235);
    cursor: pointer;
    text-align: center;
    height: 45px;
  }

.trust-wallet-one-tap .button .button-text {
      color: #fff;
      font-size: 16px;
      font-weight: 600;
      line-height: 20px;
    }

.trust-wallet-one-tap .footer {
    margin: 20px 30px;
  }

.trust-wallet-one-tap .check-icon {
    color: #fff;
  }

@font-face {
  font-family: 'Binance';
  src: /*savepage-url=chrome-extension://egjidjbpglichdcondbcbdnbeeppgdph/fonts/BinancePlex-Regular.otf*/ url() format('opentype');
  font-weight: 400;
  font-style: normal;
}

@font-face {
  font-family: 'Binance';
  src: /*savepage-url=chrome-extension://egjidjbpglichdcondbcbdnbeeppgdph/fonts/BinancePlex-Medium.otf*/ url() format('opentype');
  font-weight: 500;
  font-style: normal;
}

@font-face {
  font-family: 'Binance';
  src: /*savepage-url=chrome-extension://egjidjbpglichdcondbcbdnbeeppgdph/fonts/BinancePlex-SemiBold.otf*/ url() format('opentype');
  font-weight: 600;
  font-style: normal;
}

/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL2FwcC9zcmMvb25lVGFwL3N0eWxlLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFO0lBQ0UsMkJBQTJCO0VBQzdCO0VBQ0E7SUFDRSwwQkFBMEI7RUFDNUI7QUFDRjs7QUFFQTtFQUNFLFVBQVU7QUFDWjs7QUFHRTtJQUNFLGFBQWE7RUFDZjs7QUFFQTtJQUNFLGdCQUFnQjtFQUNsQjs7QUFFQTtJQUNFLHNCQUFzQjtFQUN4Qjs7QUFFQTtJQUNFLGtCQUFrQjtFQUNwQjs7QUFFQTtJQUNFLGFBQWE7RUFDZjs7QUFFQTtJQUNFLHNCQUFzQjtFQUN4Qjs7QUFFQTtJQUNFLG1CQUFtQjtFQUNyQjs7QUFFQTtJQUNFLDhCQUE4QjtFQUNoQzs7QUFFQTtJQUNFLHVCQUF1QjtFQUN6Qjs7QUFFQTtJQUNFLFdBQVc7RUFDYjs7QUFFQTtJQUNFLGdEQUFnRDtJQUNoRCw0REFBNEQ7SUFDNUQsWUFBWTtJQUNaLG1CQUFtQjtJQUNuQixnQkFBZ0I7SUFDaEIsK0NBQStDO0lBQy9DLGVBQWU7SUFDZixXQUFXO0lBQ1gsWUFBWTtJQUNaLGFBQWE7RUFDZjs7QUFFQTtJQUNFLFNBQVM7SUFDVCxnQ0FBZ0M7SUFDaEMsa0JBQWtCO0VBdUJwQjs7QUFyQkU7TUFDRSxTQUFTO0lBQ1g7O0FBRUE7TUFDRSxjQUFjO01BQ2QsZUFBZTtNQUNmLGdCQUFnQjtNQUNoQixpQkFBaUI7SUFDbkI7O0FBRUE7TUFDRSxjQUFjO01BQ2QsZUFBZTtNQUNmLGlCQUFpQjtJQUNuQjs7QUFFQTtNQUNFLGNBQWM7TUFDZCxlQUFlO0lBQ2pCOztBQUdGO0lBQ0UsaUJBQWlCO0lBQ2pCLFNBQVM7RUFtQlg7O0FBakJFO01BQ0UsU0FBUztNQUNULFdBQVc7SUFjYjs7QUFaRTtRQUNFLGNBQWM7UUFDZCxlQUFlO1FBQ2YsZ0JBQWdCO1FBQ2hCLGlCQUFpQjtNQUNuQjs7QUFFQTtRQUNFLGNBQWM7UUFDZCxlQUFlO1FBQ2YsaUJBQWlCO01BQ25COztBQUlKO0lBQ0UsU0FBUztJQUNULGNBQWM7RUFLaEI7O0FBSEU7TUFDRSxjQUFjO0lBQ2hCOztBQUdGO0lBQ0UsV0FBVztFQUNiOztBQUVBO0lBQ0UsbUJBQW1CO0lBQ25CLDhCQUE4QjtJQUM5QixtQkFBbUI7SUFDbkIsZ0NBQWdDO0lBQ2hDLGdDQUFnQztJQUNoQyxlQUFlO0lBQ2Ysa0JBQWtCO0lBQ2xCLFlBQVk7RUFRZDs7QUFORTtNQUNFLFdBQVc7TUFDWCxlQUFlO01BQ2YsZ0JBQWdCO01BQ2hCLGlCQUFpQjtJQUNuQjs7QUFHRjtJQUNFLGlCQUFpQjtFQUNuQjs7QUFFQTtJQUNFLFdBQVc7RUFDYjs7QUFHRjtFQUNFLHNCQUFzQjtFQUN0QiwrREFBMEU7RUFDMUUsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLHNCQUFzQjtFQUN0QiwrREFBeUU7RUFDekUsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLHNCQUFzQjtFQUN0QiwrREFBMkU7RUFDM0UsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtBQUNwQiIsInNvdXJjZXNDb250ZW50IjpbIkBrZXlmcmFtZXMgc2xpZGUtaW4tb25lLXRhcCB7XG4gIGZyb20ge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSg4MHB4KTtcbiAgfVxuICB0byB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDBweCk7XG4gIH1cbn1cblxuLnRydXN0LWhpZGUtZ3JhY2VmdWxseSB7XG4gIG9wYWNpdHk6IDA7XG59XG5cbi50cnVzdC13YWxsZXQtb25lLXRhcCB7XG4gIC5oaWRkZW4ge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cblxuICAuc2VtaWJvbGQge1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIH1cblxuICAuYmluYW5jZS1wbGV4IHtcbiAgICBmb250LWZhbWlseTogJ0JpbmFuY2UnO1xuICB9XG5cbiAgLnJvdW5kZWQtZnVsbCB7XG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICB9XG5cbiAgLmZsZXgge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gIH1cblxuICAuZmxleC1jb2wge1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIH1cblxuICAuaXRlbXMtY2VudGVyIHtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICB9XG5cbiAgLnNwYWNlLWJldHdlZW4ge1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgfVxuXG4gIC5qdXN0aWZ5LWNlbnRlciB7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIH1cblxuICAudy1mdWxsIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgfVxuXG4gIC5ib3gge1xuICAgIHRyYW5zaXRpb246IGFsbCAwLjVzIGN1YmljLWJlemllcigwLCAwLCAwLCAxLjQzKTtcbiAgICBhbmltYXRpb246IHNsaWRlLWluLW9uZS10YXAgMC41cyBjdWJpYy1iZXppZXIoMCwgMCwgMCwgMS40Myk7XG4gICAgd2lkdGg6IDM4NHB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDE1cHg7XG4gICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICBib3gtc2hhZG93OiAwcHggMnB4IDRweCAwcHggcmdiYSgwLCAwLCAwLCAwLjI1KTtcbiAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgcmlnaHQ6IDMwcHg7XG4gICAgYm90dG9tOiAzMHB4O1xuICAgIHotaW5kZXg6IDEwMjA7XG4gIH1cblxuICAuaGVhZGVyIHtcbiAgICBnYXA6IDE1cHg7XG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlNmU2ZTY7XG4gICAgcGFkZGluZzogMTBweCAxOHB4O1xuXG4gICAgLmxlZnQtaXRlbXMge1xuICAgICAgZ2FwOiAxNXB4O1xuICAgIH1cblxuICAgIC50aXRsZSB7XG4gICAgICBjb2xvcjogIzFlMjMyOTtcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgICBsaW5lLWhlaWdodDogMjhweDtcbiAgICB9XG5cbiAgICAuc3VidGl0bGUge1xuICAgICAgY29sb3I6ICM0NzRkNTc7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICBsaW5lLWhlaWdodDogMjBweDtcbiAgICB9XG5cbiAgICAuY2xvc2Uge1xuICAgICAgY29sb3I6ICMxZTIzMjk7XG4gICAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgfVxuICB9XG5cbiAgLmJvZHkge1xuICAgIHBhZGRpbmc6IDlweCAxOHB4O1xuICAgIGdhcDogMTBweDtcblxuICAgIC5yaWdodC1pdGVtcyB7XG4gICAgICBnYXA6IDEwcHg7XG4gICAgICB3aWR0aDogMTAwJTtcblxuICAgICAgLndhbGxldC10aXRsZSB7XG4gICAgICAgIGNvbG9yOiAjMWUyMzI5O1xuICAgICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgICAgIGxpbmUtaGVpZ2h0OiAyMHB4O1xuICAgICAgfVxuXG4gICAgICAud2FsbGV0LXN1YnRpdGxlIHtcbiAgICAgICAgY29sb3I6ICM0NzRkNTc7XG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICAgICAgbGluZS1oZWlnaHQ6IDIwcHg7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLmNvbm5lY3QtaW5kaWNhdG9yIHtcbiAgICBnYXA6IDE1cHg7XG4gICAgcGFkZGluZzogOHB4IDA7XG5cbiAgICAuZmxvdy1pY29uIHtcbiAgICAgIGNvbG9yOiAjNDc0ZDU3O1xuICAgIH1cbiAgfVxuXG4gIC5sb2FkaW5nLWNvbG9yIHtcbiAgICBjb2xvcjogI2ZmZjtcbiAgfVxuXG4gIC5idXR0b24ge1xuICAgIGJvcmRlci1yYWRpdXM6IDUwcHg7XG4gICAgb3V0bGluZTogMnB4IHNvbGlkIHRyYW5zcGFyZW50O1xuICAgIG91dGxpbmUtb2Zmc2V0OiAycHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDUsIDAsIDI1NSk7XG4gICAgYm9yZGVyLWNvbG9yOiByZ2IoMjI5LCAyMzEsIDIzNSk7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBoZWlnaHQ6IDQ1cHg7XG5cbiAgICAuYnV0dG9uLXRleHQge1xuICAgICAgY29sb3I6ICNmZmY7XG4gICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICBmb250LXdlaWdodDogNjAwO1xuICAgICAgbGluZS1oZWlnaHQ6IDIwcHg7XG4gICAgfVxuICB9XG5cbiAgLmZvb3RlciB7XG4gICAgbWFyZ2luOiAyMHB4IDMwcHg7XG4gIH1cblxuICAuY2hlY2staWNvbiB7XG4gICAgY29sb3I6ICNmZmY7XG4gIH1cbn1cblxuQGZvbnQtZmFjZSB7XG4gIGZvbnQtZmFtaWx5OiAnQmluYW5jZSc7XG4gIHNyYzogdXJsKCcuL2ZvbnRzL2JpbmFuY2VQbGV4L0JpbmFuY2VQbGV4LVJlZ3VsYXIub3RmJykgZm9ybWF0KCdvcGVudHlwZScpO1xuICBmb250LXdlaWdodDogNDAwO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG59XG5cbkBmb250LWZhY2Uge1xuICBmb250LWZhbWlseTogJ0JpbmFuY2UnO1xuICBzcmM6IHVybCgnLi9mb250cy9iaW5hbmNlUGxleC9CaW5hbmNlUGxleC1NZWRpdW0ub3RmJykgZm9ybWF0KCdvcGVudHlwZScpO1xuICBmb250LXdlaWdodDogNTAwO1xuICBmb250LXN0eWxlOiBub3JtYWw7XG59XG5cbkBmb250LWZhY2Uge1xuICBmb250LWZhbWlseTogJ0JpbmFuY2UnO1xuICBzcmM6IHVybCgnLi9mb250cy9iaW5hbmNlUGxleC9CaW5hbmNlUGxleC1TZW1pQm9sZC5vdGYnKSBmb3JtYXQoJ29wZW50eXBlJyk7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */</style>
<style id="savepage-cssvariables">
  :root {
  }
</style>
<script id="savepage-shadowloader" type="text/javascript">
  "use strict";
  window.addEventListener("DOMContentLoaded",
  function(event) {
    savepage_ShadowLoader(5);
  },false);
  function savepage_ShadowLoader(c){createShadowDOMs(0,document.documentElement);function createShadowDOMs(a,b){var i;if(b.localName=="iframe"||b.localName=="frame"){if(a<c){try{if(b.contentDocument.documentElement!=null){createShadowDOMs(a+1,b.contentDocument.documentElement)}}catch(e){}}}else{if(b.children.length>=1&&b.children[0].localName=="template"&&b.children[0].hasAttribute("data-savepage-shadowroot")){b.attachShadow({mode:"open"}).appendChild(b.children[0].content);b.removeChild(b.children[0]);for(i=0;i<b.shadowRoot.children.length;i++)if(b.shadowRoot.children[i]!=null)createShadowDOMs(a,b.shadowRoot.children[i])}for(i=0;i<b.children.length;i++)if(b.children[i]!=null)createShadowDOMs(a,b.children[i])}}}
</script>
<meta name="savepage-url" content="https://www.cdc-net.com/sso/login?service=https://mon-compte.banquedesterritoires.fr/idp/oauth/authorize?response_type=code&client_id=5f10de86-2d87-4111-afe5-ddf0c3697671&state=U3dFRzZ3aU1ldmt4flFvUFZxTHF5OGdqcm54dnJuRnpoMUJ1SjVEdmw3OWIw&redirect_uri=https://mon-compte.banquedesterritoires.fr&scope=openid%20profile&code_challenge=FUgk53F2lvpqQSpZednkLpRGMTlcSBWbGY7z095Vid8&code_challenge_method=S256&nonce=U3dFRzZ3aU1ldmt4flFvUFZxTHF5OGdqcm54dnJuRnpoMUJ1SjVEdmw3OWIw&ididp=OgFg0_ZoDYfmld62uon5lw&redirectsaisie=true&type=hid">
<meta name="savepage-title" content="Authentification CDC-Net">
<meta name="savepage-pubdate" content="Unknown">
<meta name="savepage-from" content="https://www.cdc-net.com/sso/login?service=https://mon-compte.banquedesterritoires.fr/idp/oauth/authorize?response_type=code&client_id=5f10de86-2d87-4111-afe5-ddf0c3697671&state=U3dFRzZ3aU1ldmt4flFvUFZxTHF5OGdqcm54dnJuRnpoMUJ1SjVEdmw3OWIw&redirect_uri=https://mon-compte.banquedesterritoires.fr&scope=openid%20profile&code_challenge=FUgk53F2lvpqQSpZednkLpRGMTlcSBWbGY7z095Vid8&code_challenge_method=S256&nonce=U3dFRzZ3aU1ldmt4flFvUFZxTHF5OGdqcm54dnJuRnpoMUJ1SjVEdmw3OWIw&ididp=OgFg0_ZoDYfmld62uon5lw&redirectsaisie=true&type=hid">
<meta name="savepage-date" content="Tue Aug 18 2026 19:49:30 GMT-0700 (Pacific Daylight Time)">
<meta name="savepage-state" content="Standard Items; Retain cross-origin frames; Merge CSS images; Remove unsaved URLs; Load lazy images in existing content; Max frame depth = 5; Max resource size = 50MB; Max resource time = 10s;">
<meta name="savepage-version" content="33.9">
<meta name="savepage-comments" content="">
  </head>

<body onload="submitOOB();" class="icdc-angular" bis_register="" __processed_aabf7107-598e-4afc-9157-cfd2837849dd__="true">

	<div class="body-wrapper" id="top" bis_skin_checked="1">

		<header class="header" role="banner">
			<div class="region region-header-left" bis_skin_checked="1">
				<div class="header-logo" bis_skin_checked="1">
					<a class="back-segment-home" title="Accueil" ng-reflect-router-link="/" href="#/" bis_size="{&quot;x&quot;:668,&quot;y&quot;:-1,&quot;w&quot;:366,&quot;h&quot;:83,&quot;abs_x&quot;:668,&quot;abs_y&quot;:-1}"> <img alt="Accueil" data-savepage-src="https://static.cdc-net.com/sso/theme/attente/logo-bdt.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABQgAAAEmCAYAAAAuiX07AAAKJ2lDQ1BMQ0QgY291bGV1ciBldGFsb25uZQAASImVlmdQ0+kaxc//n0YaLSECUkJvghTp0rugINJtxIQOIYQEsTcWV3AtqIhgRVZEFFxdAVkLYsG2CPa+IIuKel0s2FC5H9h278ydO3tmnnnOnA/nmff99APY6SKZLJtUB3KkCnl0iL8wITFJyOgDASo0oAdXkThf5hcVFQEAf+y/iQDe3QQBANdsRTJZNv6ZNCQp+WKAiAKQK8kX5wBEG4BAsUyuAEgqAJO5CpkCIC0B8OUJiUkAOREAP23URwHgzxn1EgB8eUx0AEAWAiockUieBrCKAAgLxGkKgFUDwF4qyZACrOsAvMXpIgnA5gMYl5OTKwHYvgAs5/ytJ+0/Ouf82SkSpf3pR98CANCKCAgUinOV2SlKuTBFIcrOlUpT/uHf/F/lZCv/uEcA4KTKg6MBWALQQwQCEAghxMiFEtlIgRJyCDEABUTIRi6kkGJAkVKoAICAXNk8eUZaukLoJ5NlpwjDpGK7cUJHewd3ICExSTh65o0ABABCcPGvLK8NcC8BiLS/MpEJcPQxwHv3V2byGuCsA453iZXygtGMCgA0sKAGPnRgABNYwhaOcIEnfBGESYhEDBIxC2KkIwdyzMVCLEMxSrEOm1CJHdiNvTiAQ2jGMZzCOVxCF27gHnrQj+cYxDsMEwTBILgEj9AhDAkzwoZwJNwIbyKIiCCiiUQimUgjpISSWEisIEqJMqKS2EXUET8QR4lTxAWim7hD9BIDxGviE0khOSSf1CfNyfGkG+lHhpMx5Ewyjcwj55NF5Bqygqwm95NN5CnyEnmD7CGfk0MUUNgUAcWIYktxowRQIilJlFSKnLKYUkIpp1RTGiitlA7KNUoP5QXlI5VO5VGFVFuqJzWUGksVU/Ooi6mrqZXUvdQm6hnqNWovdZD6lcal6dFsaB60MFoCLY02l1ZMK6ftoR2hnaXdoPXT3tHpdAHdgu5KD6Un0jPpC+ir6dvojfQ2eje9jz7EYDB0GDYML0YkQ8RQMIoZWxj7GScZVxn9jA8qbBVDFUeVYJUkFanKcpVylX0qJ1SuqjxRGWaqM82YHsxIpoQ5j7mWWcNsZV5h9jOHWRosC5YXK4aVyVrGqmA1sM6y7rPesNlsY7Y7eyo7g72UXcE+yD7P7mV/5GhyrDkBnBkcJWcNp5bTxrnDecPlcs25vtwkroK7hlvHPc19yP2gylO1Uw1TlaguUa1SbVK9qvpSjalmpuanNkttvlq52mG1K2ov1Jnq5uoB6iL1xepV6kfVb6kPafA0HDQiNXI0Vmvs07ig8VSToWmuGaQp0SzS3K15WrOPR+GZ8AJ4Yt4KXg3vLK+fT+db8MP4mfxS/gF+J39QS1NrglacVqFWldZxrR4BRWAuCBNkC9YKDgluCj6N0R/jNyZlzKoxDWOujnmvPVbbVztFu0S7UfuG9icdoU6QTpbOep1mnQe6VF1r3am6c3W3657VfTGWP9ZzrHhsydhDY+/qkXrWetF6C/R2613WG9I30A/Rl+lv0T+t/8JAYOBrkGmw0eCEwYAhz9DbMMNwo+FJw2dCLaGfMFtYITwjHDTSMwo1UhrtMuo0Gja2MI41Xm7caPzAhGXiZpJqstGk3WTQ1NB0sulC03rTu2ZMMzezdLPNZh1m780tzOPNV5o3mz+10LYIs5hvUW9x35Jr6WOZZ1lted2KbuVmlWW1zarLmrR2tk63rrK+YkPauNhk2Gyz6R5HG+c+TjquetwtW46tn22Bbb1tr53ALsJuuV2z3cvxpuOTxq8f3zH+q72zfbZ9jf09B02HSQ7LHVodXjtaO4odqxyvO3Gdgp2WOLU4vZpgMyFlwvYJt515zpOdVzq3O39xcXWRuzS4DLiauia7bnW95cZ3i3Jb7Xbenebu777E/Zj7Rw8XD4XHIY/fPG09szz3eT6daDExZWLNxD4vYy+R1y6vHm+hd7L3Tu8eHyMfkU+1zyNfE1+J7x7fJ35Wfpl++/1e+tv7y/2P+L8P8AhYFNAWSAkMCSwJ7AzSDIoNqgx6GGwcnBZcHzwY4hyyIKQtlBYaHro+9FaYfpg4rC5scJLrpEWTzoRzwqeFV4Y/irCOkEe0TiYnT5q8YfL9KWZTpFOaIxEZFrkh8kGURVRe1E9T6VOjplZNfRztEL0wumMab9rsafumvYvxj1kbcy/WMlYZ2x6nFjcjri7ufXxgfFl8T8L4hEUJlxJ1EzMSW5IYSXFJe5KGpgdN3zS9f4bzjOIZN2dazCyceWGW7qzsWcdnq80WzT6cTEuOT96X/FkUKaoWDc0Jm7N1zqA4QLxZ/FziK9koGUjxSilLeZLqlVqW+jTNK21D2kC6T3p5+ouMgIzKjFeZoZk7Mt9nRWbVZo1kx2c35qjkJOcclWpKs6Rncg1yC3O7ZTayYllPnkfeprxBebh8Tz6RPzO/RcFXyBSXlZbKb5S9Bd4FVQUf5sbNPVyoUSgtvDzPet6qeU/mB8//fgF1gXhB+0KjhcsW9i7yW7RrMbF4zuL2JSZLipb0Lw1ZuncZa1nWsp+X2y8vW/52RfyK1iL9oqVFfd+EfFNfrFosL7610nPljm+p32Z827nKadWWVV9LJCUXS+1Ly0s/rxavvvidw3cV342sSV3TudZl7fZ19HXSdTfX+6zfW6ZRNr+sb8PkDU0bhRtLNr7dNHvThfIJ5Ts2szYrN/dURFS0bDHdsm7L58r0yhtV/lWNW/W2rtr6fptk29XtvtsbdujvKN3xaWfGztu7QnY1VZtXl++m7y7Y/bgmrqbje7fv6/bo7ind86VWWtuzN3rvmTrXurp9evvW1pP1yvqB/TP2dx0IPNDSYNuwq1HQWHoQB5UHn/2Q/MPNQ+GH2g+7HW740ezHrUd4R0qaiKZ5TYPN6c09LYkt3UcnHW1v9Ww98pPdT7XHjI5VHdc6vvYE60TRiZGT808OtcnaXpxKO9XXPrv93umE09fPTD3TeTb87PlzwedOd/h1nDzvdf7YBY8LRy+6XWy+5HKp6bLz5SM/O/98pNOls+mK65WWLveu1u6J3Seu+lw9dS3w2rnrYdcv3Zhyo/tm7M3bt2bc6rktuf30TvadV3cL7g7fW3qfdr/kgfqD8od6D6t/sfqlscel53hvYO/lR9Me3esT9z3/Nf/Xz/1Fj7mPy58YPql76vj02EDwQNez6c/6n8ueD78o/pfGv7a+tHz542++v10eTBjsfyV/NfJ69RudN7VvJ7xtH4oaevgu593w+5IPOh/2fnT72PEp/tOT4bmfGZ8rvlh9af0a/vX+SM7IiEwkFwEAKADI1FTgdS3ATQR4XQBr+iiz/c44xN9o53/4Ua4DALgAtb5A7FIgog3Y3gaYLQU4bUAUgBhfkE5Of87vyk91chzt4sgB2oeRkTf6AKMV+CIfGRneNjLypQag3AHa8kZZEQDo6sBOKwDovPTV6L857d/9cMSvpRSwDQAAAAlwSFlzAAALEwAACxMBAJqcGAAABPdpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQ1IDc5LjE2MzQ5OSwgMjAxOC8wOC8xMy0xNjo0MDoyMiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0RXZ0PSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VFdmVudCMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTkgKE1hY2ludG9zaCkiIHhtcDpDcmVhdGVEYXRlPSIyMDE5LTAxLTA3VDExOjIzOjQzKzAxOjAwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAxOS0wOS0wOVQxNTozNjoyMiswMjowMCIgeG1wOk1ldGFkYXRhRGF0ZT0iMjAxOS0wOS0wOVQxNTozNjoyMiswMjowMCIgZGM6Zm9ybWF0PSJpbWFnZS9wbmciIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6ODU3ZTlmNGEtNzUxNS00MzVmLWIyODQtOTE3NzM1MTRkMGVhIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjg1N2U5ZjRhLTc1MTUtNDM1Zi1iMjg0LTkxNzczNTE0ZDBlYSIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOjg1N2U5ZjRhLTc1MTUtNDM1Zi1iMjg0LTkxNzczNTE0ZDBlYSI+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ODU3ZTlmNGEtNzUxNS00MzVmLWIyODQtOTE3NzM1MTRkMGVhIiBzdEV2dDp3aGVuPSIyMDE5LTAxLTA3VDExOjIzOjQzKzAxOjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5tBwfNAAEJ90lEQVR4nOzddZwU9f/A8dfMxu31HXeklAIqKootioCBjYXdndit2I36tX92gi12o5gIgkEJEtJ9XNfmzO+P953AsgvH3ebxfj4e9/v6m1l2Pre3Ne95h2HbNkoppZRSSimllFJKqc2TmewFKKWUUkoppZRSSimlkkcDhEoppZRSSimllFJKbcY0QKiUUkoppZRSSiml1GZMA4RKKaWUUkoppZRSSm3GNEColFJKKaWUUkoppdRmTAOESimllFJKKaWUUkptxjRAqJRSSimllFJKKaXUZkwDhEoppZRSSimllFJKbcY0QKiUUkoppZRSSiml1GZMA4RKKaWUUkoppZRSSm3GNEColFJKKaWUUkoppdRmTAOESimllFJKKaWUUkptxjRAqJRSSimllFJKKaXUZkwDhEoppZRSSimllFJKbcY0QKiUUkoppZRSSiml1GZMA4RKKaWUUkoppZRSSm3GNEColFJKKaWUUkoppdRmTAOESimllFJKKaWUUkptxjRAqJRSSimllFJKKaXUZkwDhEoppZRSSimllFJKbcY0QKiUUkoppZRSSiml1GZMA4RKKaWUUkoppZRSSm3GNEColFJKKaWUUkoppdRmTAOESimllFJKKaWUUkptxpzJXkCsLckoTvYS1PqOAW5t+O87gY+TuBYVY25/gJk7bs3YIQNw+/zJXo5SSimllFIqCWzTwOUPMPSVT8iqrccyNR9JrWH7q8m7+Rby771tvX3BhYtYtdtAQqXlGK4IYSrLwsjJpuD+O3D26kHdux9S8/zzGO7ste4kRObQIXi/+AY7EIzjb5J4nX2rE3IcfcWqeNoT+BT4ANi54ecj4HOgX/KWpZRSSimllFJKKaUaaYBQxUMP4HngJ+CICPsPA75vuM1WCVyXUkoppZRSSimllAqjAUIVS22B24CJwPmAewO3zWi4zW/AHYDWhiullFJKKaWUUkolgQYIVSxkA8OA35Eeg2024d8WA7c3/NtLAU/MV6eUUkoppZRSSimlotIAoWqpY4AfgSeBri24n27AUw33FaksWSmllFJKKaWUUkrFgQYIVXPthQwb+QDYNYb3uwcy2OTDGN+vUkoppZRSSimllIpAA4RqU/UGXgF+RoaNxMvRwK/Ac8jQE6WUUkoppZRSSikVBxogVE3VEXgAGUByFuBMwDHdwAXAJKRP4ab0NlRKKaWUUkoppZRSTaABQrUxmcjwkAnADUBOEtZQiEw6ngCcB7iSsAallFJKKaWUUkqpVkkDhGpDjgV+QYaHtGQASaz0Al4AfgAOSe5SlFJKKaWUUkoppVoHDRCqSAYBY4HRwC7JXUpEewNfAh8Buyd3KUoppZRSSimllFLpTQOEam3bA6OQ4OB+SV5LUxyFDEt5GtgyyWtRSimllFJKKaWUSksaIFQgU4JHIFODTwWM5C5nk2QAlyBrvxHIS+5ylFJKKaWUUkoppdKLBgiVAVwGXEd6B9c6APcjU5bPRSYgK6WUUkoppZRSSqmN0AChsoFrkYEkk5K8lljYBngRGWRycHKXopRSSimllFJKKZX6NECoAILAh8AA4FJgfnKXExP9gC+Ad4CdkrwWpZRSSimllFJKqZSlAUK1Ni/wf8hk4DuA0qSupuVM4ASkP+GTQPekrkYppZRSSimllFIqBWmAUEVSCtwJ7Am8AASSu5wWywKGAb8BNwH5yV2OUkoppZRSSimlVOrQAKHakH+BC4BBwOfJXUpMtAPuAyYAZ6DPf6WUUkoppZRSSikNkKgm+RU4gtYzyGRb4DXge+DAJK9FKaWUUkoppZRSKqk0QNi6ZCDltPHyIdAfuJjWMchkADAGeBsdZKKUUkoppZRSSqnNlAYIW4/DgXHAeGBoHI/jB55F+hPeD1TE8ViJciKSJfko0DnJa1FKKaWUUkoppZRKKA0Qpr9+wGcNP7sCOwLvA98CA+N43BLgZmBv4HUgFMdjJUIWcCXSn/AaIDupq1FKKaWUUkoppZRKEA0Qpq9ewPPAj0j2YLgDgO+AUUCfOK5jJnAmsC/wRRyPkyhbAA8jmZinAY7kLkcppZRSSimllFIqvjRAmH4KgduQcuLzAdcGbusATm247YNAxziuazwSqDwW+COOx0mUPsBIYCxwcJLXopRSSimllFJKKRU3zmQvQDVZJnAWcC2w1Sb+21zgeuAUpM/eC0B1LBe3lg+Br4GzG47ZNU7HSZQBSHbkG0iQdXpyl6OUUmoDCoAuSD/ZXg3/W9SwfW02sAJYDSwE5jT8/wuBQGKWqpRSSimlVOrQAGF6OBK4FdithffTGXgEOAe4F3gHsFp4n5HUAU8D7wGXA5ey/slZOjGQcuMjkQEtjwHLk7mgVGOZBrZhJHsZzbEbcCjJ7aG5AvgXWETrmA6+IbsA2yHBmUYGUEb6tCg4CejJmvdOBzAJ+CppK2qeg5BhU2s/953Ap8BfSVlR8+Qiz6v+DT89gR7I82pTVSOBwhlI9vgk0uui0EDkgtban+sm8AkwNSkrap4+wDFAcK1tDuAH4OcYHcNALrpuQXy+B8WSiTwv30n2QjYDxwLnhW3zAsOAZYlfjlJKKZVYGiBMbXsAw4EhMb7f7YE3gQuAe5BehfGwCln/68ANSK/CdO7pl4dkRZ4G/A/pARmvTMy0EXQ66LxgGXkV1dRneTCtVD/XWscA4K5kL6JBOTAb+BIJ0vyZ3OXEnBMJsO8eYZ8N7IAEZlLdxcjzZm0VyMCofxK+muY7nvVPhEGeh6keIHQjwcChwIHA1jG638Zg4y7I+7wPmIJkxn8K/B2j48TLYchnVLiVpFeAcHfgzgjb7yO2AcJrkO9D6eAHNECYCNsgFw3D3ZjohSilVOtkQzAYcY/hckGEhBPbXwc4MZwN+20bQiFwNHTLs+11/51TQ1wtoY9eatoKCaidhZwIxcsgJOPgHSSjMF6ZErOBc4HXkIDh4DgdJ1E6IYNMzkYet7dZNyNqs2KZJvkVVWw7ZRYTB+5Khtef7CVtilQqJSxEMrr2BG5BMpgeRUr2W4O9kEnrkRjAicDtiVtOs3kjbCsAnkOGQ0X+1pN6fFG2p9JrIlwn5HlyJrBTAo6XgVyo2wPJ4v8WadHxFan5d4725puKa92QaOuN9YdLfYzvL54ive+o2Iv0HKsh9bNMldqYPYGTG/57GvBSEtcSS3sg58z6Gk0HtpwuO7psEXF3aPFSbG89mMZ/t7cDfjIPPZTg4qUEZ87A9vswsrMxO3bAKq8ETLlf2wbTBMPAWrYcrFZ1au5A4g3vJuJgGiBMLW2By5BShsIEHdNASuaOAF5EAhKL4nSsn5CytuORQOGOcTpOojRmYp6DZGL+mNzlJE/Q6aT3lNnM3GkbvNkezJB+TreQCxmOczDyYXAbMCupK2q509jwYKxTkD6fdYlZTswNQDKSHkz2QlqhjkirivOA9klaQxbSZuJIZCjXo8Bo9KREKaVU6tsFuKLhv7+j9QQIuyGtAVSqs8EKVJNzzvlkX3TuersD02ZQeurZWDW1GC63BAdDfnIuPp/s00/CP3kq5ZdcBrVB6kZ/Qk77dtS9+w7OnluTd/2VlF92DYQscJj4fpkAjnQuWozoHxIUINQpxqnBA1wI/IZkKSQqOLi2HOBKYCJwHfHtGfgeUo53GfELRibSgciH7etIf7XNjmWa5FbV0HvKbAIuve4QYycgZXWnJnshLVAEHL2R2/REMvDS2e3I1WwVGy6kj+0EJKu2ucFBC8lKKwcWI5ljQZqf+d0P+ZL2FbB3M+9DqU2h39eVUi2xdnVAOmVPb0y6ZchvtuxAFVmHH0XhM49ihJUAB6bPYPXRJxD8dw6GKwMsCzvgxb3HHmQeeRir9j2Yqjvux9G2E4Y7i7pPPsD/51/kDhtG1rFHYnu96wYEYxEctCwpY7ZTJhMxYSV6+oUj+Q4Hvkd6c22Z5LWAnICNAMYBpxO/50gd8BTSa+h+oDJOx0kUB/J4/YY8fh2Tu5zECzqc9J4yi9yKGiwz7d9abGR4Qzx/NkVbYBTpUYIbyRE0LbhzerwXEmeZwDNAdrIX0grshXw2Pg50beK/sYEFSM/A+5DWFvsj/S23Anojpcm9Gv7/nZGMwKuQwVo/IUHEphqMZI4/hQTBVevgQ06gU+1HKaWUSju2vxb3TrvR5tVnMdzrdk8LTJ/J6iNPIDhvLkZGLrbfBy4XhsOFXVmJs1cP2o79jHY/fU37Kb9S8PiDGIaB79sfyTppKP6p0yi//CrwB6TEuMUM7GAQHA6MnBwJFG5mNNUnefohGRGHJ3shUWyHZMSdj5xoxWtC5yrgZqRUt3EASFqOw22Qg2RgnowECl8ifUsmN4nlMMlryCKcOHCXdOtFGG4scC3xC5DbSBCpLdAdKbc/AOiykX93B9CGNWUi6aBxWmhTHIoEg9I5s3gXpCT8hmQvJE05kM/GW2haD94gUvL7DTAGGXSzseFRjUHAxcgQkkYG8prcG2mHMRjJbN0QJ1L+PAgJNI5pwppV6rKQbOdUGxKV1h+oSimlNk+234ejqB1tRr6IWbzutdTQ4iWsPvYUgvPnYrglOOjcsjuFTz1C8O+ZlF1/HeXnXornmCEE/55J4J9ZZJ9/Nu7tdybwzyxKDjsOq6IEw5UVcbhJs9Yb8uPo1JGiN17Cte3WVFx3K7UjX8NwbT7X/jVAmHg9kWloZyDlU6luX2Sq6mgkUBivL83TkcfkJeTxOSROx0mUzsATrBlkMjq5y0mMgNNJ76mzmNl3a+qzPDjStxfhamBygo+ZhwQlLkaynqK5HFhG+vS664NMnA0XYv2p5jnIEIqH4r2oOLsKCVjFa0J8a9UNGQLSlEFWK5ABWyORz6VY1IDYyEWrjxp+cpDX5OnIxbwNfWZvj1xIuxX5rFTpayXyPFBKKaVUc1khcBgUPPMYrj7rduGyVpex+rjTCM6ZieHOgVAIs6CA/HtupfLWu7FWrsKRW4z3xx+o/3EM7p12J7RkKaEly7C8dYSWLcNwuDDcsQ3c2SEvGf33JmPAPgBk7NuPmtdfSuvspU2V9nWAaSQfOXGYgJQ9pUNwcG1DkbLjp5FyrXi9Tn5EsoiOA/6K0zESaWfgfWT65aDkLiX+LNMkr7KG3pNnE0zvXoTJ6GxbhTxXDgQuQIKU0dwHHJaIRcXAaax/McpCBvvURLl9uncWdgFPItmeqmn6IQHVjQUHFwM3IaXCVwJ/EL8p8jXAB8AxwD7AG2x4yrOJXBAaBeTGaU0q/tLt+5lSSimVWmywg7XkXX0lWccfs+6uYJCy8y7FP/FXCQ7aNlaoDke7tmQcMIjMww8m58pLaPfLN7T/7Wfc2+9C/q03UjTyRbxff0vw33kYbk9cBpGYjiy8X39L7Quv4f38a2qeeh7D9MT8OKlMA4Tx50ICghOBu0jvPkUe4BIkgynez53RwECkzHNZnI+VCAcgJ7+vAtsmdynxFWhdvQiTwUayqAYSPYvRBP4PaJegNTVXNjK1PNxsJEvw9wj7+iATgdNdb+CBZC8iTRwOfAH02MBtvMDDSN/aB0h8htckJHg9gI233DgV+AwpV1ZKKaWU2qzYgVoy9tqXvDtuWm9f5U13UP/xaAx3XsNtg7i33YHggkXUvvga2Zech3v3Xah+7ClCJavJv/MWyi68jNJTz8X3488yyCQea/YHsEK12LV11L4ykso778c35Q+wAptVL0I9e4+vIcj00ReBrZO8llj4DfmdLmLThyw0RzXwCDIV9H9svK9UqjOBM5FMzHtI72BxVI29CLebkvZZhMk2AxnuES2TthvSpy2VHYb0WAz3HlALvBVhn4EEYlqDc9n49ObN3XHA20DBBm4zFilTvw4p/0ymCcjz+kI2nOXbGEjcUNBTKaWUUqp1CQUx89tQ8NQjGFmZ6+yqe+M9qh95DMOZA4DtryfnvDMoeu91DE8GFcNvZHn3PpQcOpTqV54lOH0GgTlzCZWuwK6qwXDHJziIFcK5ZTfyb7qF9n/8TLtfv6X9hO9p/8N3ZB13PLhdYFsy1Th1JhvHhQYI42M34GPgE2DPJK8lFuYjJ0MDkayIRIfQlwLXII/lqCQcP9baIIGd35FszFbX9TTgbMgirKrBcujbTAssRcobow3tuADpfZaqIgX66pGAEMh7ZKQgy5FAh3gtKg68wNwI201kCu9mN9W8iY5AegjmRNkfBO5G2k78kahFNYENPI8MM/l6A7fbBcmGL07EopRSSimlks0O1ZN73VW4d+27zvbg7LlUXH09BqZMHLZtjKwcXDvtgKNLZ4rfG4mzTUdCvhJyh11Ax19/g4wMqu68D9OZDbE8p7QsbH8dtr8G2+/HDnopGHEXeTddAwGZC2atKsH2+yl6byR5V1+GHahv+EVCWP4aCCYiXyrx9Mw9troDzyBZg0cmdykxUQLcjpR0PQ/4krscZiLN4vdHevqlu+5I8OAXJIum1bBMk9wq6UUYcKV7O7mkW4gE6CN9CnmQjN5U1AvppxjuZ+S1DDJo4vMItykmvTLvQshFjEiB3K5IBvTm1N+4KQ5EhoxEa+xShpSn30bqTnCdAxyF/H2j2QnpY6g9CZVSSinVqtn+Oty7703u1Zeuu8MfoPziqwitWg4ut2wzDAhZlF92Nav22g+zTSFtv/sc15bbUjvqbWpHvkPlzXdi+4MSUIzZGmvB6SD79NMo/uA9Mgb0x8JLYNYcqh5+gtIzLpQlT5nK6iOOx66swiguwsJLxuD9aDfhO3IuuBAjLwfbX9PqMgo1QBgbRchJzETkZD3dO1nWI8NIdkf6JpYmdznr+RGZLHkKMC3Ja4mFvkjJ5RdIRkqr8F8vwkrNIoyBr5BMq0iOIzWHYZwAZEXYPpJ1h0qMIvKQidNIn8+oDOS96Noo+09CprQrsR3wOpGfHyBZ64ORScKpzocEh69GMh4j2RdpNaJXS5RSSinVOlkWON3k33sbRua6pcXVTzyDd+zXGK41pcW2vwbbV4fhyCDwz0xWDTqE0Ooy2v/8PdkXnE3tC6+Az4fhbEbLKps1fQMtCzsQkECeFSTnkotp/8fP5FxxMZlHHU7Bw3fjyCvAWr4Ca8VKgnPmYFVUEvhrGpa/DO8PP2NXVeNoU0zu5RcTWrqcvOuvpP2kH8m/4w4Mj2etjERfw+/nS9u+hely8pWq3EiJ32/AnbSOhuSjkZOZYUjmUqqykf5l+yAn5YuTu5yYOBQJfr5AK+hZaTnWZBEGm/PGrsLdj/TtC9cBKf9PJRnAyRG2L0MC4Wv7iTUZhWvbA9g1xuuKp1wk0P9GlP0P0wpe1zGQiwSJo5Vd/4kEB/9M2Ipi41EkCBwt0/4EUr9nqFJKKaVUs9jBOrJPPB7P4P3W2R6cOZuqex7EcGRJkM7hIOfyS8m97HI8gwdj5GQBBsGalZQefzpmThb4A9ghPzT3HNLlxHC7pRTY4cDZrSsEg5CRSfbpJ1Pzv6dZucc+rBp8FARCFNw7gtCKVdS+9Cq2r46ap1+g/sNPAIOycy7B9vvJv/FWap97mZJjj2bFTntiZLjJuexCjAw3dtCH55BDcPfdCdvvw913J8yiNmkZJNSz9uY7HLgJCVC1Br8i2YIb6qeUihoHmYxCMjguJr1LuZzAeUhp3ZPAE0ipd1oKOJ30njybmX23wZvpwUzDN8kUMhvJJBwaYd8hwIeJXc4G7U/k3oifIKWja/Mjwf67w7a7kCDjpJivLj4aL7hdgwyo6BK2vxgJIg0h/fuotsQjSG++SOYgpeXpesHnLeR5+yqRS8rvQIacfJO4JSmllFJKxVkohJlXRN4t16273bapvOVOQpWrMd25EiAM+Mk8YBC2ZZExaF9cTz2Ef/J0fD+OwyotZfWxp+D78RcMZzMHkgSDmG0KKXzucYJz/iVj/4E4u3el5IAh+P/6C++3P1A76m2wQtSP/Qzf2O9x9uiJmZ2Fa5edCS1eRuXtd+HeoQ/tvvoGIzOT0OIl+P+YTGDGP5iufEK1JdS9/xGZRx2BVVZOxoCBFDz6IHZ1NdbqUjneIUOxQyGMGJZHJ0J6rTY17I70E/qM1hEcnIFkPQwg/YKDa1sJ3ID8Td5J8lpiIR8YjpStX0yalq1bpkludUMWoVuvR8TAu1G270RqXfA5NcK2ENGz695FWhuEOx4ojNWiEmQlcAmRy6YPA65M6GpSy0nA+VH2rUQG8qRrcLDR68hnUSQG0qe4VU6wV0oppdTmyQ7VkXPhOTh7r1ssU//pl9R9/DFmw9RiDAM7FKDq3ocIzpxF5e33YvsC+MaNI+/Gq8jYew/qx34Jhik9CpvD6SS0cimEQmQefTj1b78LwSCFzz9B9sknUP/Bx9i+ejL26k/hvQ/R/rcfaf/rGNr98g3Fo0eRc+n52KEAVmU13q+/xf/7nxh5ueRedQnt//yZDpN/peCWO6l7/W1qXx5J9oXnkDFgH0oOOoza51/Gc+hgvGO+J7BoLoYrlU7Pmib9Vpw8PYHrgLORDIF0txR4DDlZiVS2mK6mISehLyLlXIOSupqW6w78H/K8uxeZjp1Wgg4n202excy+W2sWYctNBGpYf+prDySonAr9QjshGdbhJiPZU5HMBr5DptqurTNSev9mrBaXIJ8h70GRgmF3IEOWpiZyQSmgPdGHeXiRAVR/J245cfUQsBWRBwhtBTxA9ECpUkoppVT6CAZwtO1EzrAL19ls+/1U3T2ioTehie2vB0IYzix8E8fj2mVn2o//ltKTz6Xms3cJzp6Pf9KfmI7clg8lsU2qH3qCvBuvonLEg9SOeg9n187YgSCu7XpT+OJTuHbYjuDcefi++pbqhx8nMGsudlk5wWXLMc0MggsWUPXog4CNgQcjJ5+MnfuSOfRIci48h7wbrqbu7fepmzCR+u8ewzSyybn0AuzaOqoffwbDcJGOMwo1g3DjCoFbkRPbC0j/4GAtUrbaD+mJ1ZqCg2v7FilzPJnWcSK+O9Kw/1PSbJCJ5ViTRRhIw6soKWY5MC/C9iKgXYLXEs2xQEGE7aOIPsShcX8k6Trc43oi91bMBZ5F+jRuTm4net/BO4AxiVtKQlyD9CeO5Bxgvyj7lFJKKaXShm3Vk3XCUBxdO6+zve61N/H9Ph7DlYntryPr2KPJu+1WDE8GhsND7Ysv4f/9L7LPO4Psg4ZQ/9XH2BUV4Gj5+aLh9uAbPw7L5yf3nAsJLpuNo2MHika9QJvXnyO0eCklAw9l+fZ9KL/mGuo/+pzA1MkygOSGq2j7zUe0++FL2n78Ge4+ewE2dq2X+p+/o/TKS1mx7W6UXXAZrt12ofiz9ym4+37y7rwVV98dqX3xVQLzZmK40vOrvgYIo3MA5yKBwbtI/5IgG3gbCQxeQfqXcTVF4+/cHzlZW57c5cTEEchQh+eQrNa0EHA62W7KbHKrdKJxC/mQUsxwBpGDcolmEDmgV4UMQNqQL4ElEbYPALZt4bqSoQK4HCmtDtcPuDGhq0mu3ZHeqpF8jfQlbG3qkAzCmgj7TOA+0v+Co1JKKaU2Z8EgZm4xOZeuWxhhe73UPPEsBk5sy8IsbEPutZfj2ronZttiuU0wQPn5l+M55ECc3bbEwAkORwwXZ1D77EvkXnsZ7T7/iqIP3sD/12RW7rovJUcfQ2jpcvJvGk6Hyb+zxeoFuLbbAbNje3KvuwJH1y4YOVl4DhiEs+dWOLfbnna/jqHtJ5+QffTJ2KEQtW+PYtUu/Sm/6HKyzz2LvFuvx6qspPqJ5zAMdwx/j8TSdJ7IhiAnb2mVqbUBY5Eg54/JXkiSVCOlbe8iE48vADI3+C9SmwP5HY5FskGfZv3BDynFMk1yq6rpPXk2kwbugjvkT/aS0lmkgAOkxuCLfsDOEbZ/zcYvSlQhg1YuC9ueifQ0vLXFq0u8b5Hg1/UR9t3SsH9cQleUeAaSIRgpGFaOXLDaUGZpOpsM3IOUFIfbC8lwfz2RC1IqzRQgWdcdkTYFOcjFXxtYDaxAWmtUIK0KNkcupNqpCBmG1RZoPDMtRy4qrkI+Y6N9f0hHuUA263+21CPVUZH6GiulYsy26sk89GicvbdZZ3v9h5/hnz5VsgcDPlw796Xug0+oevheTGchGCaOth2xampYPeREfOPGYzizY7QoG2wbw52Jd+xYAgsWknnYwaw+7DjqvvwYmyCOzHYUf/0hrt7bEFq0mPqPPwfAWl3K6sOG4v9zCoRCOLpsQWj5CjwH7I+juA0Zu+5M5pBD8f36GyUHHgm2TfVrz+Po2In8+2+n9pU3CMybienKk6nJptnycukE0wDhuvZETtqGJHshMTIZOTFpDUM7YmEJMiDgZSQAfBLp2BhgjWIk8Hs60vPqNWQibEqSicbaizAGor1vp8Jz+TQiry/acJJIt7uU9bPbTwDuR7Ky0s1dwEFA37DtLqQH7D7IRYzWah9kOEskDwGzEriWZHgUOA7YLcK+a5Es95R931YqwYqRjOOByHvmNkhf22ipGBby/jkfeS+ZAPwATKf1XnhwAlsjbXT2RB6jrZAgYaSzUBv57FyEtL34A3mMppBebYY6IhchBwDbAd2QoHF4RKEMCYrORZ4HPwB/IkFkpVQsWTaYbrLPCptNaFnU/N+L8t+GAdgYbhdmXp5ss23sUACzY3syjziEyvvuxnTGoO9gI8MADGy/nDbUPPQEngMGEfhnNrnnX4KRn0vN00/j/eIb6ka+TfUTz2DXVmE4MsCy8E74SbIZMQgumAu48Y75jhXb7Y6jQztyrhyG58D9yDz8EPJuu56a/3uRzBOOwfb7qX3pdQzc2IF6zLwC+V29vuYPXEkCDRCKLZEv6ueQptNiwyxFMuaeI70+/BNlKnAK8AKSlZTuvaB6Ac8jWYV3A58kdzmR/TfReMpsJg7YlQyvL9lLSkcGcgIVzib5mQFtgKMibJ8HfNPE+5iEDGLZK2x748nQZ81eXfLUAhcC3wNZYfv6IAHEqxK9qAS6Isr2WUgGdGvnR/ovfsb6Qfw+yECfDxO9KKVSiAMJCJ4GHAh02YR/ayIDuvo2/JyIfB5ORNpavIMExlqDLYHjkeqRXWn6OZyBBNF6N/wc27B9GvA5MgRsWkxXGluDgTOBg4n8/Sdcu4afPsAxyPf8f5Hvxq8hgVGlVAzYQR+uHXYgY79919nuGzcB328TMJwSVjFMF/4//yL/vtvJmTuPujffwaYWz34DwO3GwBGz4KAd8JLRb2/y77+Dmsf/j7oPPsD74y8Efv+L4k/extGxA2ZRGwJ/TaHi2hsxHG7sUACwsEP1mIXtcHfYGiNbrj3YNTWESlZjla4CQgQXL6TyhtuoLmpDwUP34OqzPYVP/w9Mg/pPvyTw9zRsgmQOPJCCx+6n8u4R1H0wGtMdo+zIBEivfMfYawMMRxqJX0L6BwcrkIzBPZAAoQYHN+x75Mvo6bSOLJbdkCnHnyBX4FNOsCGLMLdSexE2Uxtksm+4KqSEKJmGIJke4d6h6aU+FtGzDU9rzqJSxEQil5mClFQfksC1JNK2rD+ZutEDbD6fUV8CX0XZd2kiF6JUCnEjPWvHIVPsz2bTgoPRGEhm3Qgkc+wxoHsM7jdZ+gIvIb/Lg8jvFosEjz5INc3vyEWKgTG4z1jqh7xvfoO0GWlKcDCaHsiFuEnIQLRtNnxzpVRT2PjJOu5oDM+6IZS6ke9gB+rXBP2cTqxVJVRccR25Vw+j/V/jaP/TOHIuu4C6N98BM4b9+uwgzu5dyBiwN0Vvv4pn8EFYViW1r7+Fa4ftMLKzKDvvUilpNlxYoTrMoiKyzzmX4s8+ocOUX2k/8QfaT2r4+f0nOkz5lbZjPif7rHMwC4qxgjWEVq6g7IJLqX74STDl+m/9x59j2XV49upP0Ydv4Oq7I452bYncjjx1ba5n6BlIttUkJOOqbXKX02IB4FXkS8NNwLKkria9WMiXhcbHLtIAiHQzBPgZ6U3YLclrWYdlmuRV1dB78iyCTk1gboYewBYRts8lueUzJhJoDxdASig3xWikb1K4Q0ix5/MmehAZMBTOATxF6kyhjqWTiXzhbTbwfoLXkkw28GTD/4bbF9gxsctRKukGIxdpX0O+f8VLEZLFPAkJhqVT/+kOSHDzV6TCqSBOx3EDRyNB2pdI/uesGzk3G4tkDcaSCwk2jkeGiKVPzZ9SqSYUwswsIPPwdV+moZLV1H/xNYax7gRfw52J7+dfWDXwUGoe+z/qP/mC0mNPIzh7LoYzlgM9TEKlDacRLicFD96Fw1NI4M/JBBcsouSwodS89Dy214ttWuRedDEdpk+k4IE7sUpWUXHVTaza92BW9NmLFX32YtWAQyi//HqsFasoePQBOkz7jdyLLsFwu7G9dVRcdwOVN90JQPDf+Ri4yL3pGszCAgDs+vRrj7s5BgiPQIZ1PIf07Eh3XyElsmcjJ12qeSqRjJbdkJ5R6Z7ZkoFkxf6OlLe1Se5y1gg4nfSeMluyCNOsaWsKGELk9+3JJLeP2Y5IoCPcz0hJ/6ZYjmRchctHermlKz8wDMn2DNcDyXZpTTKR3pGRPEfyS+ITbQzyfhzOjZQNKrU5KEQuXn5FYgcBFiN9bL8mPQLyJyKZ51eQuKCmAwlETgTOStAxwxUgF4+GE9+qrkLgcWRIVG4cj6NUq2WHArj77IBr553W2e4bM5bQ0oUYrvCgn43hzsKuqaHmpZeofvgR/FOnY7gziJlQCJsg/kmTCM75FwBX3z44t+pFqLKaimHX4v3+OwwcOLt1o+1nH1Dw4N3UPvMSK7bfnbKzLyAwfQbObXuRdeKxZJ9zGu7dd8VatZqycy9lxXa7UffGuxQ8NoK2X3yIa+veQJCqBx6k4obbwOvDzC7CvacU8tmVVfh/mwhY2IH0aYu7OaXw9EU+cIYmeR2x8ifyZWdzysJIhCXA1cBI5GpztBPcdFGMTBA9Fclgeh3J6kqaxonG206ZzcSBu5Dh1f78TeQh+vvXF4lcSAQnErmJ/Khm3t8opE9ouFORTKx0fdJMQwL2j0bYdyZy0rypGZepak+kxDhcJfBegteSCoJItlSk9g9HAnfSeocqKAVyAfZFYKeN3XAtc5D+cYuBhciFBROp/shFst26AD2RCy0bsy+SuXghqfn9OQO5WH3lJvwbPzJ8ZAHSb3FJwzYDeZwKga5ID8NtkGEfG9IOeAV5D7+axE0Dzkfa5AzYyO1KkSDmH0h7oIWsWWM7pA1LH+S8bw+iD7gBaV3SHrn4GOninVIqChsfGQcMhLCWUfUffEZ4wYQdCIBhYDid4HBgOGLfj88K1JI37DJc229L+TXXUnrGORS9+iLObXphZHoIzpxBaPESwCJj3/0oeud1QstXsGLX/vjnSi6Dq10PMvYfgHObrWUSMuDs3QvHll2xvV68v/9I2Y1XUfvaSIo+eIt2v37L6hNOxzt2DNUjHgenA0ebNph5OdjBIBXXDScw5x+Knn2B0OrVVN56J4Yr9TvabQ4Bwu7A9UiGXer/RTZuDnJy+QqQfjmr6eMvJOjxCjLZun9yl9NivZAv5ucgpRvR+mElRNDpZLsps/in79bUZ3kwQzrRuAmORxqMh1uJTOlLljwiB9JLaP7AnB+Af1g/wLQzctLyczPvNxU8jkw1PjTCvv8BvyAneOkuWl/Fb5CT/c3RZ8A9rF8quD2S1fRnohekVIIMRb6DFGzkdiGkFcPnwLdI0KuyCfdfiAQID0beW/fZwG3bIL1xr0FKeFNFAdKDN9rU97WVI4HOz5HPw8U07ZygA/JecwQyVKzrBm57ERJUPBUJysWTiQzb21BwcDzyHPqGpn9GNg5lOZvoAeTByEXJ40jfi49KJZZlYTqz1xtOYpWsxj/xDzDc69zWuWU3bJ8fa+VKMB2xX0/IAtsiOG8BBU+MgGCI1cMuoOzcS2n301dgGNh1tTI85ICDKP7iA7yffU3pWefi2qoH+Vfe+N9abZ+PwNTp69y9YZpk7LU7Gf37ATahJUsoGXwUbV54knbffMrqI46j7qtPMULZMrW43kvltbdQ9cKTFFw7nOwLz6bq3ofADoDljt205jhpzQHCQqT59+Wkf49BkA/nJ5Gpj5H6c6n4+AopDTsFCTTvkNzltNjeSPnmB8B9yBXYhLNMk5yGXoQTB+yCWwOEG1OEZIJG8gZQlrilrGd/Irdr+Jjmn1TUI1lmt0bYdwbpHSC0kVLj31i/6XpHJIB4PJL5ka4M4IAo+zbnib0LkYEMh4dtdwCD0AChap3OAV5gw22NqpDKjVdo3veScqSE/3ekumZvpNf48URODjCRi+0O4JFmHC/WCpH+u/tt5HbzkMfyTZo3nXlFw883yHeK45BBWdG+2x6MfJYfg1z0i5eLiF6xsxSp6HmLTe/0PxO4FylrH9ZwP5FSl4YAtyGVZkqpjbBDIZwdO+Dete862/1/TiG4eMGaLLlQCCMri/YTxhKYOYuS/Y8Ay4ptgMy2MQrycASyqPv8PSouv46MAwZhGh7M7BysklKs5SuxCeLetg9F77+B/8dxrD7uZMDAc8hBuPpsD4Yh62pCZ1K7bgf8v0+h5NCjaffTGIree51g/8H4p/yFVVlBcM5cCMrblaPLFtS+9DpV9zwEuDEy3ClfbtwaA4QuJJhzM7B1ktcSC40DSB5EyixU4oWQL64fIn39rmTjJRqp7ljkCvIrSDnLgkQvIOhwsu2UOfy987b4PBmYVjrHQ+JuBJGDcFXIhYNkOifK9pEtvN+3gGtZv//SMcj7ezxPVuJtHvK7vRph37HAuchJYLraksifv1VIgGxz9iXrBwhBstT/l+C1KBVvZ7Px4OCbyAXLv2N0TAvJxP4F+Xy8FQkARfIw0vf2zRgduzkK2HhwsBpZ61PE7oJgGZK19yaSTXktkBPhdvsg5diHE5/esVsglS2RjEfab8xp4TEqkOztb5DvvdtFuM2NDfsjDRNTSq3NDuDaqQ9mm3Vb3Pu+/wkISbANwDSx/X5qnn+V0JKGxF+jCRG4Jq/DxgpUkn/hFeRcch61r75J9UOPUfPMi2A7yL74HPzTZxBYOh/Tk0ebN1/Gqqhk9clnYmRl4+zajbrRH8Nb72MHAlirS/8rLd4gw8DIy8XIyqb0hDNoP+kHit56lVV77Ueoajm+n34lc8ih1Dz/AhU33IblXY1n4CHk3Xg1hEKsPuYUyXp0xiGbMgZaY4DwC+DAZC8iRj5BroROSPZCFCBfjEYggYsbgPOQfjHpyo304TkIKetIaFmjbRg4g0ENDG7cDUQPwj1NEoK7a+mBZBCGm4x8sW+JmcgX9fAphkVIEO25Ft5/sr2GlMKdGGHfCCSQNiOhK4qdHZDS83CTaV7WS2syHiljC++L1Rf5PPElekFKxclg5DMqWnBwHhKY+iiOa5iE9Pg8DQmwtY9wm+eQC/C/xXEd0TiQIN2GgoO/ItVQ8ar4qEF6oH7dsJY+EW4zoGHfqUSext4Sw4g8SG8yciE7lhUSE5FzxE+QnphrcyAXzPdHWzgptUE2fly777zuRsvGN2ES67zlGwZYFpXDpSDIcMe+9yCE8P8yHse9t5F3y7VkHnUYqwYdiiO/gMwhh1J2+oXY+Mi9djjunXdiVf+DCJUuo/Ch/5F5zBAMTwYg67S93o0HCA1DsgxtsFaXUnLw0ZSecBbtfh1D/r13UnbZhdSOfIfiD9/A2akrgWX/kj/8TvLvGg6GQe3LrxMKlOHwFIMV67fT2GiNAcJIkzTTzTjkamqyBw+oyBYjX2heAW4i/QfftCfyVeO4s2N5Fal1ugH5whrJ1A3sS5QTiVyu8xaxGYbzJusHCEFO9p4n9icqiXYVkjm2Rdj2AqQ31uEkeahQM0U6wYTknICnmllIydyWYds7IoMWYpVFpVQy9UCyyKNN4P0Wuci6MEHrGYWU8L+M9LFdWw7yebIbie9BdyMbnmL+HPI5kYhBIROQ1hBvIMHdcCcjQbsRMTxmLtI2JFwt8vyIR/uU5cBJSK/jzmH7+rGmrFopFYltY+DBvf26bdFDK1cR+nc+huGSDY2lxIYRl8Cg7a8j57xzcfbqQcWNt1F1/yPk3XQNrh22I++W6wnMnEVoZQl1n32Cu9t25A2/nppnXsI77lscWe2puv8Rqh98FLvei5GTje33Q8hqCBhG4XDIpGSvDyMnGyPTA5ZN/fhvqXn6BXKGnU/dm+9QP/57AtNn4Dn6CMxJf5B/twRIg3PnUXXPQxTceBtgUPnAvZju/Jg/Ni3VGgOE9aRvVtc/SCnxKHSaYTr4A+nfcjDStyRdB5kESO9+Z61RLlIOc3mU/eVIGWoyp+65iTxpuAZ4N0bH+BxYBnQK274XMrAk3Xu2LUdaFkSa6jsYya5JdhC4OaIFCKcmdBWpqRYplwsPEHqQoIoGCFW6cwLPEjlbD+QC0jkkPktrBjIA5FXWLzneEbnguyKB6xmE9L2L5jEkOJhIJcjwkjeQdh7h7gB+JHYXe/Zh/c93kAz7ePbI/hd5bNf+7K0HnkH6WCqlorEszKwcnFv3XGdzaMFCgsuWYjhdkoXncGD7vBgOmVzc+G8lA6+FCSKWhUU9Rn4euddfSeDvf6i4+Tr8k/7AM7A/ru17g2lSPeIxQtUlFD78IAT8VA2/g8yDhpB303UE58yl5sXX8QzqT/UjT+E5eH88Bx2AWdQmchahaRKYPZe6l1/Hvedu1H/6MQWPPIxn/wHUvf0+lXfcQ9aJx5J//x14B/1E3ci3cfbqQfZpJxKcNYfakW9R++qruHr1Jv/+O6l58jkMVwaEQmsenxTRGgOE6Wg10iz5/5A+GSq9fI1cDT8duRq8TXKXo9KYGymHup3oTcP9SE+eZH+JHYRMXw3XOHkyFkqRK/kXh213Iq+3dA8QgvR2egkJ+Ia7BXk8k/233lThwS+QXq7aR1dMQ1o7hOuW6IUoFQeXE73Vz5tIX8JkTYstQzLh3kbKV9d2FfAdkpke7/KGLOR7f3irgUaPk/jgYKN6JIDbEbkYt7ZMJHA5kNj8DSNdWPciGZ3xNhr5fD0QeV4+iF7EUmqjbMvCzM/D0X3dryz+qdPBCoDhxGxbRO7Vw6h59mVCy5ZjeSsAG9Odj+F0YAc3dd7QWkIWRm42xY88TtapMtso85ADqX39Neo//IC6D9+izdMv4P3qW7xjx+DeakeyzjmdmieeJVC2BP5yUXnzHdi1deRcPYzsM08Bp5OaF17Brvdi19djRwgQGh4PoaWLyb3hanKGXUDpyWdT8/SzBP7+h9C8+QRXL6L6sf8j/55b8ew9CO/Y73H+O5+CJ0ZQO/JtKu+9HXBQ8Ki0m8657ELce+7G6qNPIrRylQRWU4QGCJOrDngR+ZKwILlLUS0UQq5Kf4RMhLuc9SeUqvSRqLJOA8hHAgMHI1P8dt3A7auBs4BP476yjYtUFgSSAR1Lo5AJh+EnbMch2RfVMT5eMtyItMcIH+yRg2Ti7EtiSsxiIRuZyBmuFu0/2GhelO1dEroKFU1tsheQxroTefo8wBiSGxxsVIu0qRgD7L7W9gKkv20iXIr0HY3kXZIXHGxUgTxGvwAdwvbthXwPiUUQr3eEbfNJTCa1jQw8exLpSaiUago7iKPzFhg563anCs6YJbtDPpy9epAz7AKyThyKVbKa4MLFBOfMxblVd6oeehz/739I9lxzGIBtE5wxi+oHHiW0ejW+sT9hE8I0szAcWTjat8NavgLLX032qSdgOBzUPP0Cnn77kX3maVgrS6gb/RFZJxxDaMVKXNtti+F0Ynu9ZB55GEZO9rr9Ad0u6j/6HCyDnAvOwj9+IjmXXMDqL74BbDJPOBazS0dqX3qdvOHXk3Ppeaw+9TSs8iqM7Cxsy8JAeh3WPvMiwZmzMDweAjNmYtfWY5iaQajkQ+kdZACJXq1qXSqQaWyjkPLAs5ErxSq9DCS+jdNBGmK3AdoCvZpw++lIoCwVpsB2Ag6JsH0BMgUwliYiGXS7h23vjGRbvhHj4yXDaqSv6desHwjdFWlhcEuiF9VMhUQeUFKDZISq6GWM7RK6ChWJgVx4WE78s8g2xEQuIj8CrEriOjbVrUigLdx8UiM42KgSyUL/iXVfd4n4m7clegBwHnKRORX66/6LTDaOdNHveqQ8t7yFx+gYYdsiEtdmaVKCjqNUKxLC2bkTRtgE3sDceYD9Xwlx+bBr8U36lbyrriFj/4HYgXpce+yK7fWB3YK3WtPErq2n6pFHsAmRdfRQcm+4itDCxVTd9yCuXlvj2n5bQqtKcGQWkX3Oafh+Hk9g3t9kFO5N6N8FBBcswLV9b4zMTOxFSwjMmkNGvz0JrVpJaHUZlKz1ddUwsOvrCS5bQOaQw8DtxjdhEu6+O+LeYzessjLw+zDcHoIr5lI/+mMyjx2Cs0N3gisWYtfU4uzaBRsfmfsfgeeIQwj+/Q81r4zEtuoxXTnSqzGFaIAw8X5Aekp9neR1qPiaj5zwv4ic2B+X3OWoTdQJ6cOTCqqQSZAPIic1qeA4ZJpwuPeIfUZfECn/CQ8QgpSKtYYAIUg2y6PA1RH2XY+UQn2f0BU1TwaRy+ZWkZ4DV+Ih2kl1pMCqSiwDyeROBUGkMiFdAoR9iNyXNoR8H1qa2OVs1CxkENgrCT7ueUQOjNlIT9pU+nu/gXzeHx22vQcy0fipFt5/pECofk4olcJsQji2WPctzPYHsFevBpwYLg/+X3/D99M4bKrx/fgL/j8nU/nUI7S5ewR2eQVGS3vumQaGIxNCXty77oxzy25Yy1eAwyTvrlsgK5PQyiV4+g/C0b0bVSMex8wrxNGhPaHSUqyaahzt10qODoVwdN6C+m++xnBlYGRmYrZv91/gziopIbRkCWZhgfy+VVXYPj9Gdhb+ib9hV9di19bi7NSdurdHk3XqCXgGD6J65AsE5y0g+9QTqBrxCGQ4ce++K+4+2+H99nuCCxe0vB9jHKRWuLJ1m4Gk6x+ABgc3J5ORCXWHAeOTuxSVpgxkcnaqDJJxIIG5cEGkr1M8jCZyUGV/YLs4HTMZbiNyVrkTaZ5ekNDVNE8+MmQnXCpkxKSKaIOhIgXd1earltR532+Ki5BhO+FeB75I8Fqa6lUS27IjFwkQRvJBgtfSVHcQOfPzIqJPqW6qSGfGmkmtVEqzMIvX/bpiV1URKisHoyHwZ5oYLhcGmdS/9xG1r7xBwdU3S2bfypUtz5gLhcC28Aw+iODCJVSPeIzKe++j4L67yTz6CILTZ2Jb9WQctB/YNt7vfsTZuTt5d95C5pGH4d55ZwJTpmPX1ILDgaNrZ/zjJwImrr47kn3mKWSffhLZpxyH58CBONoWY2Diny7dDxzdu2HkZhOc/S+Gw0PGvnuTd9ctZB42BO8332HX1OI5aH8MDPx//IWRm0Px26/jH/cbJfsdRsUNt2MWF2FkZGL7Ez2va+M0QBh/i4HrgD2RK3Hp9GVPxc6XSNnq+cDsJK9FpZdcZIDRn0Tv+5dIe7F+43KAX4G/4nTMxUjz+HCZpE62TyzUIr2pIn1b2Ib0nGis1ldG5J6SGkRV6aodkd+Ly4A7E7yWTXU7iSt9HgxsFWG7D7grQWvYVFNYd9pvo+2B/Vp435HaTvRCWogopVKNbWPgxmy3bhzfrq3DrqzCMEzAgEAQQiEy9uyHu/9emHm5+Mb+QOWdD6yZZNxcoRBGbjZt3n2Ntt98RJsXnqD403fptPhfMoceiV1XT2DaDMCJ5+ADCS1egrVyFVg2Jfsfiu/7n8k++1Tyhl9HYNp0HF27YObmknnMENp9/xW2P0DJicdResKZlF1wBatPPgU8GRR/8Qmu7XoTXLiYrBOOxXC5yD77NIref53QylWUHHQkvp/GYbic+H+bRMa++2AYWQQmyjxF10470O7XsXSYMYn2f/xEu/Hf0vbbT/Ds2x+CqdJ9Q2iJcfxUIM3lHyW1ygVU8gSQkuP3kCDAlUgvGqWaoifwGlL6fAWwJEnriJQ9CFIGHM8Ax+tELtU/BRiB9OtqDX5BAoF3RNh3IXKx4eNELmgTGSS3d1s6yAYijavTx02tLZ0u4h9C5MFsLwILE7yWTfUXkqUe7bMtlqJd0PqM1O5J/hzyWRv+HnUCLcsOncH606QLkc/6x1pwv0qpuDEw3Ot2krGqqwmVV2A4TAgFMArzKHrtedz99sD2+8Hnp+r+R6h+/hlMd8u7qRhuD3Z1DYFpf2PkSCaf95sxeL/5gfYTf8D/11Qcee1xbdML3y/jsSpXk3P5RVjLllPwmFxrd/bsIcFK0yTzsIMwCvIBcO+2sww4qa/BuU0PMir3ofCpRwDI6LcnVlU1RqYHZ8+tcO8hcyXde+yGtboUIycb79ff4Rs/kYwDBuHsvhXBhYuwa2vx/fALNc+/QO41V+Ho1BEjOwv3rjuTccAgvL/8imHbKVNurAHC2LORE+UHgWlJXotKTZXAfcBbSP+bs4ncs0slzyIkAJeosVI2EizujPRw25BjgR2QMqWf47yucEXA0AjbS4j/FMDvgblIoHRtvZBS48/ifPxEGgEcBOwdYd8TwARgZUJX1HT1SDZM+HAmzZ5fI4fI7/mJasyvNs4m+QHbdHrNHBlhWz1SwpsOngROJL5B2TbIZ1UkL8bxuLEwHqli2DVs+/7I71XWzPudGGX7DcCHpH5wWanNi22D6cIsKlx/ezAILhd2yE/+rTfi6NaVVfseiFVRjaO4kNxbbiQ4fwHeMd9iuFvQncDhwCoro+zs8zDzijAy3FgVlTi33pKMfffFyPQQWrAAZ9fOGLk5BGbOAmyq73+QzKFDqf/wU6offxpnt+4UPHwPZttijIJ8al95g7q33iRn2KW4++1O2XVXYH8JRfc9jO+X8dS+9hqZhx5O5rFDADDbFFL7wmvUvv0Wedddi3vP3Si/9grAJDjnXwCcPbfC9+13BBcswtVnO3y//Ib3iyNxdO2Mo0M7QkuXEVq8FMPpSpngIGiAMNbGAPcCPyZ7ISotzEd6uLyMDDKJ9AVbJcdTwP9IXAaHjZTLFiElO0cgGRnRJmBvjfQqOgn4KhELbHAE0CHC9i+RqZ/xVINMf480zfd0WleAsB55b5jA+s+BrkhmeqRhAKmgBsnmDF93HvJ6CiV8Rakn2kWAVA36bm6uQb7HJfM7soEEjBclcQ1NVQgMiLD9Z2BmgtfSXBOA34B+cTzGLkSuGpmNTFNOZUHku0Z4gLALcsGyuev/Hnnfax+2vQNyEf1IYHUz71spFQeGYWJ41m03a9fWrXVJzYXnkAOpGn43/pl/YRh5BJfPhwf/R8a+++Ad8yUtbV9qB4PYBAlVNc6+ysAzcBAFTz2EXV1DaMVKnFv3AiA4YyaOTl0pfn8kFVfdxOpjTyTzyCEEZs2m6r5HKHj0frxff0fFFdeRfck5VD/0OP6pf5Az9FQyjx1CzaP/R82zL+M5ZH/Kr7weIysTzyEH4v38a2pfeh33wH6UnnwO2DZtnnyGwNS/8U+WHDFHp46E7BpCCxfjOuwg8m64hqpHHicwbwb+eVMbHjInpiO1ZtRpgDA2/kQywkYneyEqLU1EykaPAG4mvl9QVdMEkEBGIoMZ1Q0/rzT89EZKic8jciZjPjIU5GhkOnoinBll+6sJOv67SE/X8OyrQ4FutK5sg2nArcAjEfadjAy7ei2hK2qaOiL31ytCSmsrErqa1BSpFBNiPwFcNc9U4I9kLyKN7Erk5/S7iV5IC9jIRbd4fv+K1LsXYCzp0SLjGyJfoNuX5gcIy5DvDzdE2NcPCUpeiL4elUot9rodhayS1WttCxKYMg3XjtvDaLBteXvzHHoQoeUraGnuhR0K4d6pDxmD+mO2KSS0YhXer7+l+v+eJPv8M3F074pVXonZTq7HWFU1hFYso/Tkc7HKyjDcmQRmzMauKiPYtu1/67eqq6gbNRpr1SpCgTK8X48lOHsevmkTAAd8YRFauQj/H3/hOeRArJLV+KdNIbhoMaGKFUCA6oefxA4EMdzSRcbIk5l91upSbL+f6sefwa6oJuuIY3DvuRtmTg6BefOpe+Nd7Krqlg9viRENELbMAqSU+FUiN5VXalN8hnwZOgP5srR1cpezWUuFd+iZSBbZm8DTyFX6cPkN+/dBMlLjqQ9yIhBuKjKgJBGmIj36wsu0cpFp4Q8naB2J8igS/Dwwwr6HkSynBYlcUBNUNPx0CdueCXREA4QA3aNsT1ZfUbWujbV5UOvagfXLsWtIfAuMlvoWuIf4ff73jbL9hzgdL9b+RrL5woPB4VmFm+ohpHVKrwj7dkU+5/4HPEP8KxWUUs3hashjMAwM06TqnhG0/eoDnNv0wvf993gOOwyzIJ/Vx5yM4Wjh8PNQgKyTjiP3xqv+22RX11D14KNYZWWYnTpge2v/+1AKLVyMa+ttyb/nVozCfGSISoDKW+/F0akDWBbuXfviaN+BrKFDcHTeAiOzYY2mQU7GRWBZBOcvpGrEIzg6tAfbwrVrX5zdtyLrpOMwCwswsjKxfX68X3yD77dJDQuToKlVWoZdXUPW0CPJOvUk3HuuedsMrSrB99UYguXlYKZGxzENEDZPBTJV9Cn0w0rFVhApOf4YGWRyGdGzTdTm4Sdk8uHLSLAoXMeGfQcT30mMJxP5M+MdpOdcorxJ5D5OpyJNzVtTHzcbuATp/1QUtq8YOWE6jNSafhsEliEB5bV5kOmd6VJyGE/bRdmuAUKVjiJdvFoI/JvohbTQTGAp61/ciAUX0CPCdi+pPZxkbWVIkHBg2PZeyAWgSJnjTVGKXAz9HPmcCJeNZNOfh1RNvIUMlmlNn/VKpZewfnmOjh3BMCUg5vQQmD6N1UeeRO41l5N55JGEVqyk/OKrsMpWYWTkrpeBuGksqh95guD8BTi26AROB4G/JuM5eDAZ+w8kOHMWlr9mTTae00Fw4QKq//fUmm2hEIE/JxP6dz7+Pydje31Yq0rwjv0JZ7cuGPl5mJlZGPkNpb+BAMH5CyAUoOreh6l59iXs2jqCCxbh++FnHFt0wiyWr+mhpctkWAvgaC/TnkMrVmC2KST7vLOouPpGXH22xywqwsj0UPfuBwTmzMBw5rTgMYktDRA2z1WkT+NllZ5KgbuAKcBHyV2KSgErkCvs77H+xD+AQcDlxC+DLovI0xfrSHxrhY+B+1m/l1MfZKhHqvdy2lRzgBuBFyLsOwS5kPBUQle0cbOQgPXaDGBb5CQw1ZjICXwiAt0G0j4gXIj4ZwErFQ9bRdg2jfTrN1qDBAnjESDMjnK/i0i9LPBobGRQWHiAsANyAaslFzjGIn113yB6c7KOyPnXlUi/yK8bfv4GqlpwbKVUUxkGdiiEXVu73vY1QT8bIysP358T8J36C+DAJoTDUYBrmx0IzJ2L4WheCMoO+Mi74Tqyzz0DbAvfz+OpvOlOAiXz8P3yG1knHAOude/b9vpw9tiKzOOPBn/gv+1ZJx2HHQqB3w+miZGRgR0IQCCIbVtg2TLlGMCAjE4d8Rx0gExlDgbl37jd2D4fdjAIIQtcThzduhJaJvljjYFCLJlQXHnn/dR/9xn1331F3tXXk3Xo8WQeMwTfmLGUX3UzBPwpUWasAcLmqUz2AtRmo7mT4VTr40V6AP7A+tlZADch2XyL43Dsg4mc/fA9EgxKpNVI0Pz8sO0O4DRaX4AQ4CXgcKTfZLgHkBKsaYlc0Eb8GWV7S0vR4sENPI88v48j/oNCtiJyQKUGGVagVLrZIsK2uQlfRWzEK0jfFgkShitD3oPSoazdAkoibC9EhlC11IfIBdBn2HCLHQPp57gXcDvyHWQi8tk/DslcjWc1hVKbNzuAVb5uKMRwu6UsNxDADvrJPnEo2DZ2TS2OHt0x83Jx77MXwX8XUH7hpWA6mjm118YOBDByczGys3Bu1R1cLgzAqqgiuGAxRpsCDNP1X8DSLG5D8J9/CPw1dU0Q0/7v/6z9W6xpluFwYLjdcnvbxvY2tZOcIcHBhiBfcNkKWUPbYuzaOgK//wW4MHCRsW8/XNtti11Xh+33YzjBDmzgrhNIA4TNE2lggFLxoM81tbYy4CykD1/4VfY2SEn69XE47mlRto+Mw7GaYhTrBwhBhv0MB1YldjlxZyN/2z2RLIq1ZSMZhAciw3VSwUyk/Cv8O0Y/JBs1VRry5yGDXo5u+P8/QDJ14xkk7Evkk+l5SGm2Uukki/UnlkN6TF+OZOnGb9IsOUQ+59oRCW4lP2Vk4yzke0Y4B9IPORbGIhmKw4GzifzcCrdNw8/pSGBwOvA7MlTlTzQzW6nYMQxg/QxCIzsbMy+3YVhJAGe3LuTdPRxrVQlWTS12VTV2fT2GywVG88NPhstD9f8ep27k2xjZWTg6dyL/jhsJzp1H9aNPg2FgZmVhZuVjNwQAzQ7tCX3/PcHZcyVwZxiYbYsxsjIlsw/ANLBramX9pom1uhT/rGkYOHAUdyBj8H6AsfHSaNPADgQwi9d9q3R03gKcTrBCZB1+NFknH4d3zPdU3no3VnkloaWLMJyelMgeBA0QKqVUuvkTCQhdF2HfGcAIJMsuVnoCB0XYvhgZqpMM45DHYZew7e2AIUjGXWuzBCmvejvCvgFIBuldCV1RdDOQE+1uYdu7IlmEqTC8oBsS4F578M7eSBbLMcQvSBjptQRSMqdUuikgckloumZw1W78Js3SlsjnXFm0joF04S0/WmIFMAzJ7L4CGErTA5Bu5HvBLsAFQDnyXeErpBw5lTLtlUpLNkGs0nUL3IycbMyCfEIrV4HpxPvLeAJDT8M3bgJ2dQ1WXTWGw42jU0cMp2v9sVabwHBnylTgklXk33MbGQP2pnbUO3gOPgBXn+2wKioxcnOxlkv2nqN9O8z8QvKGX4+R29DnryEzcL3fzR8gtHwFdW+9T+6B+5F19OGUD7uWjP574+jaGbOxJ2HIInL7b4P6L74iMOkvub/qGgwMHO3aYmS4yTrjVOo//ARH965kdetK/fsfEVq1AsPdlGshiaMBQqWUSj8PI8HA9mHb2yPlwG/E8FhDkeyHcKNJXruFEFJOHR4gBHlcXkGyHVqbd5ChJGdE2HcTMAYZaJJsNUhWTHiA0EQyHZMdIHQATxJ5Knc/JEh4FJHL6Voin+gBwl9ifCylEiXyWVJ6ite6UyMtJL1MBc5Feg4fj7SAiPSZvyGFwAENP3cjFxffQt7jtYWPUs3iIFSybh6CmZeHWVQE/IPhzML34y9gB8FwYThMDHcm2DbBJUsxnE5a/FbrdELApuysi8HtIKPfXuTdch2hxUtxdOqAo0M7rFWyRlfvbQiuXkzZGRdiFBaAFcLIzsHI9KwfJHSYhOYtBGzavPoMZkEBGf32oOzSC3B23gbD48EwDYzCgobfI4xt45swjtxLhwEQWrYc05mH2b4ddr2XzKMPJzh/Pqv6D8LCh0kGhjO1goOgAUKllEpHq5CBJcMi7Duc2AUIM5CynXBeZHJyMr0B3Mz6mQX9kDLOaH3w0t21wD6s3xPSg/Ru2of4ZcFsii+Qk7pwJwD3ktwMoxBwBzJ9dcsI+/shw3COJrbl6vsA3SNsr0R6iyqVbgJEvhiTSpPVN0W81u1tuO90DZxuTFMbdDXHXCRI+DCwE3AoMphtdyB3E+7Hw5pg4XDgOeBZoCJ2S1Wq9TNw/DeE4z8OE7NDe+TrlS2lxLjWvY1tYxjmf//dvB6EgGVhB4M4e/bAzPRgmyZWZRWrDjiYrBNPouitl3H27IH3m7FYlZW4dtgOw8gk5/KL8Bx8AEZurmQCZrjWe8c3XC6qH3kSq6wcR4f21L32Jlmnnohv3G8UPPaABAYNA1xO7Kpq1nlLNwywQpSdeRHOrXsCNsF5CzCL2uLsuSWBv2eycu/9yDzoIHIuuhicToL/zMb3y/iGHoSpE5ZLnZUopZTaFO8BF7N+n8q9kJKv+hgcYwCwfYTtCxqO25fknPDYyLeQaUD/sH0u4FRab4CwBOlH+BnrZ6XsBNyDlCIn2/dI4Cs8gLstsD/JK09v9CdSjv4ZkYN2/ZAeVscjk6Rj4awo238ifr3PlIqnMiJ/1rgTvZAY2ZSA06YoRfqyujZ2wzS1IgHHCCC9BX9HsgG7IUHCwcBuyOdfU/t2d0eCjmcg2fcfx3itSrViDkILF2MHg+sEtVxb96B+rVMC2+8HAtiEMHAADjIPORjntltT/diTGG7Pph/asjCyMyl84mGyjj7iv4nFdl09tW+8Te3/vURoxUoyBu1L3XtvEpw1B9e22+DYogtVD/6PmhdexczOhsbpwqa5ZmCJw4HhchJcuIg2zz4OgH/iH+Re1x+rtpbS0y7AyJDhJ7bPh10X9tFnGFJ67DDJGNif4KIlBOfPI2PPPTAyM/H/OZnC/z1AzkXnrzNp2T9+EquPPAGrvByaOd051lJjFUoppTbVZKQvXXgZZydkSurfMThGpOxBkOy1X0luNoRN9JOB45ATiIqErSaxvgT+j8gZpFewpt9SMi0EvkVK1MNdRPIDhCCvkcORbMfw1xHICefnDbdpaZCwF5L5EsmHLbxvpZIlRORWE10SvZAY6RCn+60kcoBwJtI7Nl0H0hnI7zUvCcde2PDzPlLtsBVyUXMAcuGwaxPuozfwEfAAklUYisdClWpVDCehpcuwS8sw2rf7b7Orz1r5BFaIrOOOBtPELCzAuU0vMvr3w7VTHwLTZ1D9+P81L4vQtsEysCsqsYNBzLxcCAapH/MF7p12IuPl/6PqtnvxDDkUGxvvmO9x77Ebrm17EZxj0mbUi5htCiEYwqqslCCfaYBhYJdXEvx3HpV33fff1GLD4yFUUYFhgGfoELKOOhwjOyvy2p1Oqkc8jv+vKbj6bEfdW+9jW9VkHDCIwJRpePYfiO31UfvySDxHHoajbTGhZculT6PXB0bqdKLQAKFSSqWnKmAW6wc2MpCyyZYGCDsh/e4iiVA7kFK6Ir0Y30n2QuJoOLAf62d4GsDTyMTj0kQvKszrRA4QHopkn05O5GKimIE8z6MFCXshWYaHI6VuzXUxkXt5rgQ+bcH9ri1aeWRRjO4/UdpF2Z6uZaut3SJkGu/awlsgpIvucbrfMmRgRvhAFz+RB0+pTeNDgq0zkdLhAuQz8Ejku8DGno83Ah2RnocaJFRqAwzTxKquJThvAe61A4TbbSPDNiwLO+jFs98Asi85D6uyCjM3h8o7H6Dm2ZfJvfJinFt2IzR/Ibg28VTC4cCur6P8iqupeugJXDv0JjR/Ib5Zf2C68mj//TdkX3g2ldfdCpj4vv0BbrmOzGOOpPyKKyi/8ArJ/qusxg74IRAEw8DI9EhGpNuNo2MH/H9OJeuUE8g642QCs2ZDRgaBKdOpGD8RR7u22JbVUEZtyzcT08T2+fD/9QfZJ50MgHfM99hAcO48zOJiQstXULL/oQSrV+K6a2scnTsRmr+IUMkyDGdmykwwBg0QKqVUOptL5KEH0U6wN8XRpF9gYW1n0LoDhJXAJchgkvByvh7AQ8A5iV5UmK+RIPY2YdvdSFnXiQlfUWSNQcLPiRwg2BoJIDY3k7A70f8W7xK7qePRypRjOWE0EaK9fy1L6CpUU82OsG0H5GJFOgV1s5EWCPFQD8xHLrytrStyYWJhnI67uapAPn++Ri7MDAHOQ9pbRHMmUip9Y7wXp1RacxhYvioCM/7B3W+PNZu7d8PZvRuBOXMAA9+ESXh//Q3vl1/Q5sXnqH/vQ7AszLtuwmxTSHDe/OaVIZkmhjuL4JKZmJkecq+7HPevv1H72khKTzuHDjP/IPuS8/H++D2+338n+O98so49ksrrh2Nk55B9xskSmLTt/zrDer8cg7W6lKKP3sLZtQv+v6ZgVVTg2mkHQqtKaP/7TxhuN1X3P0LtS69R8Mh9mMVFYFk0FlP5fvgZ308/kXXqCdheH74ffsHAwL3zjpjFbSg5+Cis+jryLruOzEMHU3nr3QRL5mO628TgjxJbqROqVEoptamiTVltaR8lk8iTctPJICT7qzX7CQkERnI2UmqdTD6kFDqSo5GhHaliBhIAnB9lfy8kSBge7GyKG1i/FyNAHfBUM+4vmmgBtK1ieIxEiPa6jfVUaRUb0yNs6076Pe+2pWllqc0RInIGciHNe09RTVeDTC4+AJlOP2MDt70OODARi1IqfRlAiMDkaetsNQvycW7dC+wghjuLundHU//2+1hlq6l++HHavPYcbb//gsC0mQSm/Y3Rgn57tt+Hs2038m65luzzz6LNK8/gGTQQ/4IZ1Dz3MlnHHUXWiScTqllF7ah3MDu0w3PkEVi15Vg1tdh1dRg52ZhtizDz87B99eTdfiOODu3xT56Me9e+mG0kcOcZvB9GdjY4HOTfPRznVltS//lX1L35HnVvjabu7dHUvTMa7/ff4+67MxkD9sb79bcE5v9Nxi79yb3uCmpfeA3f35PI2HcghU+MwHPoYHIuOR9Hmy0aejWmFg0QKqVU+or2qdLSrI09gF1beB/JlgWcluxFJMC9wIQo+x4DtkjcUiIahZQghnMjfZ9SqZJhBnAE0YOEPZH+j3tE2R/J3kTPHhxJ5Oyr5lpO5PK47UifHmdOpC9YuACaQZiqpiJ96NaWh/SCSyf7Ed/zoqlRtmtAKnE+QS4eRqsuMIHbSa3PJaVSjoEb/19T1tuese/e/DfY3rIbsv3y8P06ntVDTqBkv0OovP5Wsk4+HjsUaNax7WAAZ/dutBv/A1lnngK2jf/nXwlMldh/zZPPYdd7yb/zZhwF7al7bRR2fT15N1xJcMZsqh96nNpX3qD6kSepvvdhqh58jMCU6fgnTKDksKGUnngq5ZdeDSH5OuUb+yOrDz+GslPPpe6d0dheH9aqEsketEJgQOD3v/BO/Jmcyy4Ew6D2pVHYQP5dw+X/f/E1APwTJlD/7odg22SfczrtJ/yIo3Mn7GDzHot40TdApZRKX+2jbPe18H5PJ/Lnw1RgfJR9yRJCyraOiLDveCQIFYuJzqmqHrgU+JH1e9xtATxB5D6AiVKGZDk+GWFff2Qi86MJXdGGzWBN/8qdI+zfEulJeCTRA7ONMoBHiDzRtQZ4uPnLjGg+EiTsHLa9e8PPvzE+Xjz0JHJQezXwT4LXoppmGjKkYuuw7ccDryR+Oc1iIK/pePqZ/wra1nEQcAsSBFfxV4JcPLSAkyPs7w8MBL5L5KKUSieG4SIwYxbBhYtwdluTeJ0xaB8MV1ZDcLDhrc62sAlgVVXh7r8necNvwMzOpv79j2UYyCb23jMapgVXP/QYhEIE5s4lMGky7j12JWvHEwn+M5vA5Km4++1BztnnUPno/dS9/jbZF55N9lln4vtlPLmXXYjZrlgyAwHfmLFUjLiPzD32I+/mW6i69R6CV1yCc+ueVN58J2anDrj77UHpyWfj3LI7ecOvxcjLw66swqqoJLRkCW7fzmSddiKBydOo/+JTMvc5AM/hBxFasAhnrx4UHHk4wTlzKb/4Kqqf/D8yBg3ALC7GcDo3eVZLvKXSSZ5SSqlNEx4IaLSqBffZhugnStcB37TgvuMlDxnKEv549EayQr5I+IoS60/gfiSbMNyxwIVI4/ZkeQU4n/UHGYBM8BwLrH8pOnnmIAHnT4FdIuxvi2SibCxIOBzYK8q+J2jZ0JNISpG1h78OspCT3nQIEO5F5GEu04HqBK9FNY0f6YUaHiDs37Atllmy8bIrku0bT9OQxyK8pHh7YHfg1zgfX60RRC6s7Y5clAh3OBogVCo6pwOrvAT/+EnrBAhdO2yPa5tt8U+fhuH2SJ8/LHLOPZ/cYRcSKiun5n9PY1sWZnERwYWLMDZ1OIfDRWjZcqqfewq7oWii+NU3yD7zFAJTpuMb9wuOrbYEIOeKi6gdOZLKex8k84RjKBhxFyt27EfZFVfi3mZ7cLsxc7IxPB4yBx4Ktk3No09heesx8vMAMDIz8f08Dqu0nIx9pTNO9SNPyRRj2yYwcxahsqW0++JL6VN470PYoXpyb7xK1ut24TlkfzyHHoyjU0fq3niX1aedSP0v32KSgWFmgtNNKrXs1QChUkqlJw/SCD5cEFjSgvsdQuTA4z9IlloqqgI+AoZF2Hc6rT9ACJKldwCRm7DfhwThmjNgIxZqkT58X0bYl4MEEPdDBq+kimVIAPBjIpfbt23YdxSRg4QHIb9zJP8QvXdkS/2EPJbhjgJei9MxY+nYKNt/Tugq1Kb6GAm4rC0XKa9Ph6EPlxH/Mnwv8h4YHiB0IgM0NECYWOVIG45IfWD7I+XGViIXpFTaMKQPoW/sj2SdtKZIxcjKJGPwIPzT/wQ8WIEacs4+l4JHH6D8gmHUvT0aSZZ2YmTlyCTgSHnVG2SDYeAs6ozn4AMxsrOoH/0JNU89h//3v7CoJuvDLyj+4E2c3bqSd/VVlN18DVV33E/B4w9S+PwTlB5zKllnnoJn/4HgdEAw1JDJaFP/9mjqPvoMu7aW0MpVuHboDQYUPHI/RnYWVmWVBD5Nk9DCxZRffCW551yE59DBeL/8ltr3R5F56LFkHn4wVnkFpSedQ/3PX+HM7oBzm54Qssjc73BwOvD/MRm7uppUCg6CBgiVUipdRWuoXk7zA0EG0fv2vU3LS5fj6U3gYtY/yTsMeZwi9cFrTQLA5cAvQEHYvjbAM0jpbKQedYnwFfA6kYff7Aw8S+Ryr2RaigTWPiFyJmE7JDByNFJ632hrJOjpivBvgsCVyJTNeBgL3Mr6vdQOQjJlYp21GEvbEDnAbQE/JHYpahP9iGR5hl+0OhsJwLTkolW89QFOSNCx3kde/+GOQzLA0yHLtzX5GrnAmBe2vRsy1VqzlpWKKgPvdz9g19ZhZGf9tzXzyMOpfvz/GrIHQ7i2703tcy9T8/ZrOBwF2KEQNvXkXXsTgUl/Uv/VVxiuzE06sh0K4OjaRbL0giFWHXgEdl0dmYcOxtGpI7VvvU35sGsofOFJci6/kNo33qHqySfwHH4wmUMOJX/EXZRfcznO4u7gcmJX16wpicbAyMul9LgzwOHArqoiVLKakoOOxsjKxKqoAMPEqq7BsirI3H0gBU8+hFVZSflV12Fm5FNw/+1gGFTdcR/1P39F7jmX4OyxJf5fJ+IfP5Hcm67BvdMOVN09gto338BwZ8fqjxITGiBUSqn0dDiSRRhuCs0PPvQhcmN5P/BuM+8zUSYBvwN7hm3PQ06+/pfwFSXe30jWWqRy4gOAq4lf5lpTXIuUkIaXIgKcBKwArkroijZuKRvOJGyHlCKfCXwOFCP9CztFub+HkZPSePkNyVDcLmx7NnABcH0cj91SFyDrDDeDjfd7VMnlB55HSufX1g64Dfnbpqo7iPxZGg8TkIsJ/cK25wI3A+cmaB1KLEH6toYHCDOR93INECoVheF0Elq0EN/Pv+I5ZM2sJfdeu+HeaUf8f/0lw0x+/Y38e2/H/X/PY5VV4BlwEBkHDCRjrz0wCwup/3LTi3wMVwaBqdNZuXN/cDrIPuc08m6/GUf7dhAK4fv1N+o/+5z8lbfh6LIFbZ59nJX7H0zZeRfSbuzX5F49DGvFSqofeZK8e27FvUtfGTjSyLKxg0EJcjqdGA4HWBa2bWO4XIQWLKL8ymvI2Go3it59HSMrk7JTL8M/azJtHn4S1059CM6dR+2rb2DgwNlzK/JuugYA37gJlB53BlZ5KYbDieFKreAgaIBQKaXSUQbRs63GtOB+TyLyQIXvgZktuN9ECCKBmfAAIchj9QTrT9psjZ5HysQjDW25E+mr9GdCV7RGCdIP8SvkORzuSqR/5v0JXFNTLEWyBD8mciZhEfLcG4Y81/pGuZ9vkOy+ePI1rOXOCPvOBZ4GFsZ5Dc2xFZJtFsnb6ACHdDAK6VPbJWz7OcjfcGzCV7RxJxO9rD0eQkhZa3iAEOQiw2tIm4BU0xt5by5N9kJizEv0IGA8J1orlf5ME8tfQ/37H60TIDQ8HrJOGorvr98wnbnUffQZ7t13peid1wktX0Fo0RLqP/yUqjvux7XzThjuHLAtNnlSh8OBHQhg5hWSMXAAwRn/UP/+R9Q88xK+mb+TdcgxhFatwtFlC9z996LwsUcovfR8Sk88g7ZffED+iLsx27Wl6t4HMdweDI8HDAPb74fG4CCsWZfLJSXRlkVoxUrce+1G0aiXcXTtTNUd91Pz5kvknno+uddItyOzuJjc66+k6rZ7qLz5ZoIzZ5M55BCMrGycPbfE98sScGVu+u+dABogVEqp9HMG0tg8nB+ZsNocOcCJUfa90cz7TLTRSLZKQdj23ZAG9Kl44hUPlyC/c4ew7ZnA/yFZoskKlv4A3ET0jM77kL9ftP59ybIEKTeOFiTMZsMTW2chgZJEPO6vIZmYBWHb2wD3IH05U83dQGGE7eVIabpKfeXACNafWO5AWhwMAFYmelEbsBUyZTzRPgL+YP2MZAfSaqEfqdWPNQfJkg4i05ZHx/j+2yJZnHNJ/ER7D5GHIhmkWlMwpVKQYXio/2oM+SWrMdsW/7c988RjqXrwf9gVVRimScVNt+LcaivwBwguWYCNFwMXOeedibdTB2rfGInhzt3047tc2BWVlJ50KmBiU0fmoMPIO/9yAtOmsWrAoeTdeBV5t95AziXnYZVXUj78WkoOP5ai998k99rLcfXdkcprbsI7dQIOVxuyTj4OR5fOGBluMEwIBrFD0m/R++u3mK4Ccq+6jPx7bgOXk6p7RlB+581kHz6UwuceAyD473xKTzkLu95Hxv6DIBCgZuQr1Ix8ETAxjKyGsuLUfJvRqyNKKZVeOiBfpiP5FinHa44DkROmcMuQ0sl0sIjoU5aj9VZsjRYTPcC2J5LlU5e45aznUSI3hm90PfAykctNk2kJUm68qRmYS4HjG/43ERYij18kpxG5D2QynQ2cEmXfi8jzWaWHl4C/ImzfGnlORurLmQz5SMZjx7DtpcT/jM0P3B5lX2+SO3E+kruAHkiP0PeBD5HgZizSXk5ELtxdAlxE4kq9G7Vr+AlXQ2oFs5VKSYbTRWjpAuo/XXcGnbNbV7KOPhLLqgPTxHB7CM6bR2DJP4BBxp6DKHpjFI4tu5F59BDMNu0h1MwW2YaJXF+Rt273wP4UPv847cZ9S9Erz1Bx221U3y/XgvJuuYY2Dz6K749fWTXoILyff4PnwEG0n/wrxa+8jmfwIAJTpuMfP5HAjH8Izv0X3/iJeL/8BtvnJ/f8YbSf+BP5D96F5fVSftGVlN96A5n9D6TNyBcxsrMILV/BqgGDMQvyKf70PdqO+Zicay8DgpiuAgxcUrKcosFB0AChUkqlEwdSIhitv1l45samiBY0+Bgoa8H9Jlq0Sa3HIJkKm4vXgZFR9t2M9LBMpquAtzaw/2xk4ue2iVlOkzX2JIwUBIlkCfJYT4vbiiJ7GCkJjORJYPcErmVD9gQej7JvJZtH79DWpB64gsgl4YchmYTxnha8MW6kFUN4me904IUEreFzpOw6khNJnTYLJ7N+X9ijkV6nh7bgfrdGqh3eZs17/NbIoLFE2gvJrA73L8m9iKZUejAMwEHtyyPBWnfod/al52Fm5EEohB0K4O6zIznnDaPovTdp/+t3OHv2YOXee+KfPJWsE4Zih7zNW0PIh+eQgyl64zWKXnyNmqeepfzSa8A0yTzhGIrfepPaV9+kbtQ7WBWVZJ11KrkXX0Vg4SxKjjiO8guvJDh/IdlnnU7x56Mp/vQdci45D2fnLQBw7dCb3KuH0fabjyh8/klcffvgHTOWkn0HU/Xc47i33IGCh+4DbILzF1J20tm4996LNiNfwtmtC3Uj36bi8hsofORx2k/4joJHRmBkZWI3NyCaABogVEqp9PEg0fslfUbzhx90Bw6JsN0mfcqLG/1A5CnOxUiJ6ObkeiJPD80CdkzwWsIFkSDghoKE+yL9L1Mt+7MxSDi5CbcbjAwOSrTlRO93mIdkAiX7OdAXGX4Ura7oFmRwjUovPxN9GNK5SBltsloc5SIXTiJNLb4GCQwlqiHUNUTPKr4RmWqcTAcjf6tI5tD0iySRdCHyRapbWX/AUjxFC0j+Riqn9yiVQgynB9/Eifh+GrfOdvcuffEcehBWqA7DsrHq6yl89AEMG1YfeRwYBsWj3iL7jFOwa2qAtfr+NZVtg23g3Kobzp5bYjid2F4vzm5d/ruvrJOGkn3O6aw+/Qwqb7mL2udfwcj04NlpH4zMTKqef5wVO+xJ2dkXU//ZV5htCskcehT5D91Dm1efpeCR+8g65QSMrEzqP/iEkoOOZtVBg/FPmY5n533IOuk4/FOn4/txHFX3jMA/eRrF747C0U5yEvzTZxBcOB8zvwDb68PMzwNnqiTTR6Y9CJVSKj08hJxQRFKL9HVr7hfak5H+dOH+QL4op5M6JPhxU4R9pyMli5uLFUjZVnP7UsabjzWDKaIN3emAnNAfjZw8psqwnCXIIJjPiD6UxAN0RqYKJ8MLSNZWpMB4V+ALJHM4GcMjBgOvEj0b+kOil0mr1HcH8ro4LMK+85C/+/lIC4tE6YE8pwZE2Pcq0p4ikVPUlyF9ST8jcun1zUB7ZHhTTeKWBUhLhBdYf7ovyPv2RchFiOb6EfgF6B+2vRAZsnQE8R+mdCIwKMq+VP3MVCr1mCb4a6l55iUyBu27zq684dfj/XoM+AIE586i6s4HsL1e6r78lOxLLsLIyaXipuF4P/oSR4fuWKtLAaPpl2kMA5wuav7veWqffwU7WEPuTbeQe/2V/92k/pMvqX1lJG1Hv0vGvvtgFheDAbY/QHDuv3i/HEPdO6OpffUNal59FkdeJ1x9d5ShJdiAge31Epg+A6uiAlfvbSm48148hx2Ma6cdZHAJYFVW4e63J0Z2NpW330v+XbcAUPDgXVgrV1F63hmYzkLsoA/DmdFQZpyaNINQKaVSW1fkZPnaDdzmVqQ8qjncRA/OvEN6Tv59CzmJCbc3sHOC15Jsn5N6Pa3W1hgk/L+N3G4oMB4ZshHeNyxZliJZMNEyaYqQ126kidKJYCNTo6MFKLdAnh+3kLgLxi5gODL0IFpwcCaybs3gSV8B5HU9Ocr+w5Bs74MTtJ7jkGzkSMHBP5GyaEj8edE3wNUb2H8u0ls40tTjeHAjwd23kT6NkVyPBPhaIoh8b4n0Gt8B+AQJ6MbLbkTvgzuJzWegmVIxYTiyqP/kM/yT/lhnu3vXvmSdcByWVYfhcFPzzAtkDNiHDhMn4ezSmYph11L7wdvgdFL88dtkn3cmVmDTq/sNtwc7GMJR3JmcC87G9vnw/zmZ8ouvYvVRx+Po3InAtBmUDDmBVXsNpH70JxhuF67ttiX3mstoP/EHOsyYRJunniej/974fvqZum8+ov6bj6n/5lMMp5P8e26j/cQf6TBtAnm33Yh7t50xXC6Cc/6l/MIrKDvtPEqPOgFH+3bUPPsypSedTWDa39g+H4VPP4q7Z1/soB/D5ZGgagpL7dUppdTmKw8pf/kFyZ6KZiTwWAuOMwDoE2F7BfBeC+43maYDEyJsd5J65aqJcB3Jy2JrCh9wKZIhu6GAdD4SzPoDmXbcO/5LIwMJAr5E5Mnhy5AAYLQgYQ4SsE5UICTcSiRTJlqmlgcJuv4EHBTntRyMlJ/ejTyukSxByj9L4rwWFX+rkJYY/0bZ3wvpM/o88QsG7QC8iXyWdYmwfy5wElAVp+M3xVPAnRvYvycSJLwXaZURL4ORwN/tRD8/fAR4IkbH+4Hok993BL4jekuVljgcyRCM9lg+CKRuczClUpHDge2tofp/68fd84Zfh7OoE7ZtY9d7KT3jAiouv56SwUcSWDIbV5dtKP78fVzbbo17150xPVnr9TNsCsPlxqquYfWRJ7Gq/0GUDDiU6mcfxzAcBBcsovKOe/AcMIjc4TdSdfeD+Cf+gR0IEFoqydCu3tuQc+n55D90N472HSi45S4K730YAze2r47Mow/HvWtfMAxsn5/gvAXYXh91b71P9rlnkDf8evy/T6b2+Zcx3C5q33mVVXsPZtU+B1F+yVXYoRCGw9nQt3ET2Ta2v5k9GptBA4RKKbW+SNlniVAA7IKcQE9CsqoindQ0+o6WZ9pEyx4cS/xLfOLFJvqwkuOIXDbVmlUjAbhN/8aVWP9DTt5mb+R2HZES8j+QTJOTgW4xXEcGkml6J5K1+BlSCvgBkYemNAYJo003zkEmpu4VwzVuiqlImfGGyjn7IT1MxyABxcIYHbsNEoD5DvgKCXZEsxS5GNLcbOhY0eEEsTMfCQz/EWW/gZQaj0eCT5EuVjVHXyRzejzRP+PmIr1EI/WsTbQ7gNs2sD8LKTmehATwesbouE7kwsD7yOtzQ+9RjyMXm2LpGqL3aO0GjEb6IO8Sg2N1RYa8fYKUbkfyfsMxlVKbyHBmUf/hp/gnTFpnu7PnVuTecBVY9eBwQjCIb/xErLIyMgceRIfff8HIcLNi530ov/hKDMOBHQphByLNutrQAgDbJjDtb/y//4FVW417u91o+/PXdPhrHBn9+hH4eyaZQw4ld/h1eL/+DqusnJV7DsA3VpKG6z/8lNLjz6Tw+SfIv+dWcm++hqI3X8f/52RW7tafulHvAFB+ziVU3X4fdkUF7r33wL3Hrvj/nAyGRduxn9Nh2gRyL7wCq7Ya/x9/UPP6K4QWLgJHM3oP2jaGx4PnwAM2/d82k/YgVEqp9Z2CBAIScRHFRsp6uiBZFL2a+O8+QXrq1bfg2B2Inp0YbQJuuvgCyZ4KPxHoikxffCfhK0qusUgfyxuSvZCN+AYYiGS1nbuR22YCQxp+ypB+meORrNslSI+spvTuaouU224L7IdM+N2J9V//WyOvuyHArLB9y5BgwydEPpktRiaCH0Xk7NZ4+x0Jvr7OhoMwBzb8/Ius8yvkBH4ZUNqE4xQhj+VOSOBhb2CrJvy7acCpJH7acyQPEn0CdLL8gQSG0tG/SEnxq0SffNsWKbW9FHmv+hAYhwTx/E04RiYSNBuAZJ3tS+S+fo1mIH32UqWnKciFwSXIlPHsKLfpjgQTr0GycT9AXqcLkF7ETVGMvJcdhLwn7LaR24eQzO0Hm3j/m6ICuYDwLfK+EckpyIW975DS5wls/CJSo3bI7zcUed9uu4HbzmJNqblSalOZJravlqo7H6D48/fWKaPNuexC6j/8DN/4XzCcmRg5Hto8/zSe/fal5qXXqLrzPmyfD8OVge334dyyG3YwSGjxEgyXe5OWYbjl9nbAh1nUBtvro+LqmwjOW0DB5TKXKOvYIwnOnovhdGB4svB+9yO1L75G7Vtv4eqzE5lHrmmfm3XycdS98S51n4+m9PTzqP/wE4LzF+Ds1QujIJ+MfnsA4DlgEO599qT0xDPJOuUEzKI2mFnZ2D4/hulpuLdNzOewLOxgAKMgH7O4aNP+bQtogFAppda3d8NPKrKRkuIbadqJ04Yci2T4hJuHfBlPZyuRYM35EfadzuYXIAQ5AT2I1O/DuAIZZPApsuamZBW1QYIPjQGIaiQjbRVSrlqNnEBXIBmIDuTksbjhf7vStLbYvRrWdQLr91dbigQAPwJ2jfBv2zXsO5rkBAknAwcgJYInbeS2PRp+TkXKvhcjAdcy5PH0I49te+QCRzHyN+iEXOzYlO7bbyIn5qs34d/E0+7JXkAEOcleQAs1lhvfhmShRTv/yGDN69iLBIIWIMGbZcjr10SyoQuR121PYEsk6NWU9IzPkM+FVJyQ/Qryuz7DhqeM5yJB18OQiod5SLbmXGAR8jo1kO8LLuRiYHfkNd2NpmdcLwEuRwK28fIP8p74DtEvJrhZ87yoQQK7/yLPj2XI+1Hj79sB+f22QX7fDVVhNFqABIwTOTRHqVbHcGVT/9VX1H34GVlDj1yz3eOh4LEHWLX/YeD1YVdX4f3mO6zVpZTffC0mmRgZ2WBZWKFqCq68BM8hg1k18BCsVSWSebjJa8nAP24CJQceBlgY2XkEJk/F16Eddr0X3y/jyb3hKoycbCruuw0DB6Yzj8CMmdQ8+xI5554JLid1oz/GO2YMprMADKj94E1soOjcs6h58jmCCxbg2mlHAlOmE5y9kNDyRfj/mAQ4MNwt6DcYCoHDgbNLF0LLllP39jsUvZWY2W0aIFRKqfQxDxlWEosv6ybR+/G9hwRU0t1bSBZa+Kfz/sjJQ3gWWGtXi5wYjyN6D7hU8jGSTXQuEkDqvgn/NhfJCIxUEtxSvZBpp2ezftn2EiRIGC2TsD0SJDwGyXZMtBKk5HIsEqzp3IR/40QCMFvGeC1LkEEFr8b4flujlmSKpwovUib7I5LNvLHAvwcJkm0oULYpKoARwMPIEJVU9SuSATkcyajM2sjtM5B+rLHuyToK+XstjvH9RvI7kr39ItILcUNykCB+rAL5U5ALIX/H6P6U2nwZgGFSNfwuPAcMwCwo+G+Xe49dyRt+A5U33YThyqX2lVdxtLuOwntGUD/6I/xTp0HIS+55l5Bz2UX4x03A0a0roeVLMUxH83r3OZ0YjeGu+nrq3hmNY8vuGBkZ1H/4Ga6d+pB/07VUP/McoSUrCC1chGGYlA+7lro33sUsKsL30zhsy5bDGwaefQ/C3XdHzMICqp59icyjDyO0cDHeMd8TWr4cwx0tAXwTWBZkOCl86lFCS5ZScdstmO6Cjf6zWNEehEoplfpWIZlUuxO7K/m7A3tE2O5Hynhag1+Q/mvhMpE+a5ujP5Dy3XRRjWTM7oYEx5N9EvcD8twZRvSejkuRcuNoPQkbg4SJmkwayQvI6/9hmlY6HEulSIBoNzQ4uDn6GnnuX4Nku8WbjfSV6w/cT2oHBxtVIdOCByDvFYnsHzsOKT0+ncQEBxstQnq53gCUJ+iYLyIXDJP9uaJUq2G4Mgj8M5Xqex9Zb1/etZeTedgQ7EANhjODmieexdGhPUZ2DnaompzzLqLwhSepuuchVvTvh3/CrxgZ2diBALa/Ze3hbTtIxsD+ZB13FO7dd8HIy6D2+VfIPOEY2v3wNW1GvQiGgRWsxTNgH7JOHIpn4N5knXCMpCcHApiFhRR/9DYFTzwEwRD4A2QecRj5d95M/j23YrgcYLekLXzDWkN+nN22xCwqxHP4wbh69Mb2J649sgYIlVLJ1YwLQjG0KWVwiRZEyhCvRzKRbkPKhmLlbCL//hOJ3jQ83QSIXkp8Fs0r24uUeeckvT5PH0CyeCJJ1cqCUmSIwV5IP6qPgMoEHXsp8CwSYNgPeJeNZ9g2lhtHCxK2Q4L9yRpcAlIyfB0SqLuN+Pdjm4lkDO6GvK+tjPPxNsaz8ZukjHTI+N0UtchQol2RgUORLuS0VD0SGNwfec9oShAo0vtfJsn7pvIHkm28LzJJPV5l+F7gc6TUdxDSwzcZ/EiW597IkJl4VTKMRcqzzye236uUUoDhzKH6yafx/TRu3R1OJ4XPPY6z5zbYQT92IEjpeefgaNeO4rdGU/D0I1Teeg8Vt16PZ+8DafvNF3SY8ivFH7yBu88OLZrka7iyqBv5Div67MWKnfcCTIreeeW/zMTQkmXYVhBnpy4Elywl+5zTyblqGKHFS7GCtTKp2e8jtFy6U2SdcRIFjz9IycFHsbzHTlQMuwYwmpfp2ChkYftrMdyZBGb+w6qjjqDqzgcoGHEvrl5bN/9+N1GqnggopTYThtXyKy0tUI5cIQ8mcxHIyUcdElRYiJwU/IT014nH2rKRsq2FrJuZ4ER6HyX1jxJjo4EzkDKttX9XFzJIYVykf7QBfyGBhVDD/28gf6N0KskOIhlwTyO9nRofFydS9pnKapC/6WikPPYQZKhGP6TXVCxO5IPIa28cMtV3LM3LsmssN36XyNmCjZmER5OcnoSNFiAZyo8igYjDgX2A7ZDnR3P5kKDgOKRv4ziaNjQmUSYi60n16d4O1u932VqsRi5YPI4E8oYigfgeNO+iSz3yd/0GmUjb1GEWjRYhw47Wfn+vI/kl3r82/AxHAluHIq/Rji24z3LWPFafsemPVTz9A1yEBJFPZM0wlZZc1F2NZK++jvzOSql4MU1sXz3ll15Du5+/xizI/2+Xo/MWtHnlWVYfPhSrugbDzCI4fwGeg/bD+8kXVNxzK1mHHE3bz0dT+/IoKm++jcwjj6D48/dZNfBQQgsXgLOZX00cDkLLV2DjJ/eqKzA8mfgn/oHv+5+ofvhJCAUpfOYJQgsWUvPcSziKi7G9XorfeJPyy6/HKi2h9MSzyL3sItz998K5ZTdcW2+Nd9I4TDMLnM0PrdmhEIbTSd51N5DRf28woOa5l6n95B0IhTBy85p935vKsGOQBplKlmQUlwMFcT7M8cgXD6XibRDwfZyPUYmUmiX8y6E7EOC3Absyad+dyfC2dN5G85aAZAekwhthEDkRSQQnEiQM/70NEpeVlUjZrH9iYSJZE5t6OdJs+Al/7KwI21KdgTwujes2kedhuv0eAPlIX8ndGv63FxJA7IQEdN2s/3v5kMDuciQw8C8yRfd3JGgWq9djIVK2f1CU/SuRQOJvMTpeLGQgjf77IBcTuiBTRts37PMgQ0lKkExdL9IKYSly0WUqkom8GHmcU5GDNYMNUpmBvL+keiAzVnKQ1/CeDf/bHXkd56z1sxIJ4pUggfj5SBD1T+S129y/afh7YuPzIxT1XyRPIbA9UmHQA3mc2iPvhY6G/y5FXn8+5LW5FHmsfkdeo8nO4m0qJ3LBoj/yfrQD8p5UyLrZtY2vFS8ycGQOkjk6HrkIU5K4Jaec85DWEiAB4SHxOpBtGrj8AYa+8glZtfVYzR3S0DTHINO8VQqy/FXknnchhS88ud6+ujffo/T0czAMJ3bIj2ub3phtCvD9PpEOE37GN24CZZdfgoEbGz8d/5pM/WdfUnnrcMDz37Ti5nJs0RHbH8Aur8Cqq8AwMrDtIG0/+wDP4QdT+8oo6j/6jOKP3gLDYGlhV+zqauxQEAhi5hcBBrbfL+XGLbk8bdvYIT+FT/wPR5ctqLjmBjL670PBYyMoH3YNtaNewXTm3dk5UHZHi37pJtIMQqVU0gQdDnpPnsU/O/bCm+XBDCX8/MdPyycBp6MgrTMQGE1tDO+rNZ2o26yboZqKJ8FNVYlkw0xca1sGcgEgC5myu3bQwEICWo1B4nj2JStHph6/S+QgYXtkIMtBxKfUsjl8yEWj2Ui2ZiM3EnwwG/7bx5oASrq9l6bz8701q0Gy6P9Ya5sTyfp2Nvx4kedd4/MvVsLfE1NZOdJn95e1tjU+Tgby/udH3uvS8fW5tiDy3tj4/mgi7+sepF1D4wVAA3lulCBZn82vR1RKtZjpyqXmxZdw77k72eedsc6+rFOOJ1Symoorr8dwugnMmg0EMIs6YNXUUHXvQxhGDhgGppmBkZMNDidmfhGOdh0JzJmN4cpodklvcMEisMFwmBjuho5DAZtQaRnV9z0CDpPs889i9ZEnknvt5RguJzZguDPAdmNXNxREOJo5QAUgFMIO1QMmzi17knnUYawacAiB+bMJzP0bwzbIv+V6vJ9/jVVR0bxjNEM69UxSSrUylmmSX1nNtlPmEGxBWrZSSkXgQyaXLkNOLKet9fM3chJZTWKGFlQiQcIxUfa3R7IgEtdkpnn8yIl3LRKgaCy/TOfgg0p9QeR5Vo087xqDP6me/ZlojY9THfI41dI6X58WEkheDcxgzfv6VOSiRjkaHFQq+QwDDBflV12P75fx6+3OveJi8u+4BTtYi+FwYLiysKsrCc6YhVlYgG1Xg1VP/l234diiI3Wvv4Gz59a0//Nnci8fhh0KYftrJYtvU5fmcmG4XRLg+2+bm4qrb6T6iWfIPv9sMo84BEwHJYcehV1bC43ZsIYh5cROZ/ODg5aFkZtD9rnn4ey2JZgmjs5b4Oq7IxDCdBZQ++a7WJWVODpvAXbirl1pgFAplVQBh5Ptpswip6om3mUISimVTJVIi5Jvo+zvAXwF9E3UgpRSSiml4sVwubBrqig7+0JCi9Zvc513+43k3XgzdqgOLAvb76PurfcpfP4Jcs46h8InnyTr7FMpPeFMfP/8Sc6wC/BPnop/6p+Y2Vlkn3Y6zq26ywATq+UFPlZpCY4tOlF1zwhKTz0PIysT2xvADgRbNoCkUTCE7fdiB/3k3XI9bV58CiMnh9CKZYSWLqPwiYdw99yBULAc57Zbg8uJVVpGIudq6tm4UiqpLIdJXmU1206dQ9ClWYRKqVatEpmoGi2TsIj491FWCoCQwyTochJ0Nvy4nFgOPTVQSikVO4Y7i8DcWZSecnZDsGtd+fffQcGIEdihAGDgm/g7zq264951D2rffINVe+5P3WfvkXXAEDKPPIyy84bh/WEsoerVeA4dTNtvPsK9267YoQC2vwZCze8gYrizCEyZRtWjj1D35kjq3n5PyopbEhy0LMlytIKYHdrh2mYbwKbytjuo/t+TZJ91KqHaEsqHXYOZn0e7376n+JXXKHrnVWpffJ3QsiUYpjNhGfP6LUAplXQBp5PekzWLUCm1WYgWJPwXOAD4IdELUpsXy2Hiy3CTV1FNhyUrab9sFe2XraLDkpVkV9fpxTqllFIxZbpz8Y77gbKzLopYEpx73RUUPv0ohsuF5S2hfvQneA45kMAf0wgumodhZpN7zWVUj3iM4KxpGGTh6toL9x67UnHtrZh5ebT74StyLroYIzcH29+C9uMOB6Y7F8Od29BzsPlzr2x/PTidOHv2wA75ydh7L9r/8TPFn7xPxqCBVA6/F/fOO5K51wHUffQ2K3cfRNV9jxBatJyKy6+n5pnnAQMjK9PV/F9o0+g3AKVU0llmQxbhlNlMGrBLsiYaqxhq8QmmDc5guvSKV+GCTie2YWBaIRyJHz6UDqqAocgAkMHIQIaTkambSsWF5TAJuJwUlFWx/Z8z2WbaXDx1XuyGC3OmFaKqII8vjj+Q8uJCXP5EtOdUSim1OTBd+dR99jHGaefTZuTzGBkZ6+zPueR8HB06UHbuBVTedQ+eQw6k+ON3WX3CyZg5hTi7d6P84quwCWEQoODxB/F+MYbaj94kc49BZOyxK6FlK8g67URqX3iF2pFvYjgzoqwm/mx/PRkDB5J349U4t+pO9ZPPU/vSS/inXkpo8VLyb7ke6xofRl4OhU89TMmQ4wjMmkVg1nRk5pKJTQBPv4Hk33vrzolatwYIlVIpIehw0nvKbP7ZaRt8WW6MkPYeT0cBlxPDtukybwnb//kPzmAIexPS8g3Lwu9xM2237VnWpT0G4AxooDBdNAYGOy9YRqfFy5mzfQ9KiwtxBoMaKFxfNXAScC3wDLA4uctRrZXlMAk4nRSUV7HdX/+w7bQ5ZNXU/VdW3CjkMMmtqObwd8fw+fGDKW+rQUKllFIxYoDpyqHuvbcAaPP68xiedQN4mccOoW2XLyg981xW9tuf7DNPxczMxypZSWDuv+TffwdVjz5M9smnY2RlUXHTcAxMci6/GN8vEyg5+Tjyzr8Md9+dqH1tVDJ+SxEM4mjXlvw7b6Hy9nvB78e92y5Y9eXUPP0CGf12Z+W++5M19Diyzz0TzyEHUDTyJUpPPAOrogpssK06sk86lcJnH8fMz8tK1NI1QKiUSgmWo2Gi8dTZ/N5/Z9whzSJMJ0GXE2ybrvOW0mfS33RZsAzDsjYpONjIsG26zVnMwp5dmLb7dizv0gFo/YFC2wDDlozaoEuaETtCFo5g83upJEpjkKHD4pXs+PsMus1ZhCsUYPu//mHWDj35e+dtKS8qwBkM4WhBb5hWqAy4OdmLSCchpwPDsrENg5DTxOUPYjS7/Kd1CzlMQk4n+eWVbPfXLLadNofsmjoCTid+tzvivwm6nORW1nDYe2P48vjBlLUtwBGMHtwPOR04A/o3WI8h7VMcloVlmBjYafFerpRScWUYGO486t57GzsQoM0rz2AW5K9zE/fuO9P+p28pv+hyKh99AJNcDIdJ2ZkXUfDQ3RQ+MILAzFmUnnAGVl0l7m13wb3HrgSmz6DgtnuoHvEYBEMYLs+mra3xc2xD5y7BELbll/vewO1s24aMTBztijHz8/CN+43A7LkY5FL31jtkH38UWccOpeb9kdS9/yGefffBqq7BqqjCDvkxMrPIv+Ve8m66BkwDZHp7QmiAUCmVMgJOJ9tNnsU/O/bCm+nBjME0KhVfAZcT07bpMn8pfSauCQwG3C5aMnHLsG22mrWA7nMXs6BnZ6busQPLu3RoVdkstmHISaTLhWHbuPwBLIdJdlUtnRavAKCiTQErOrdL2d876HJiG9Bx8Up2nPQ33eYuxhEMEXQ58TkycPkC7PzbNLaZNpfZfXoyfedtqSgqwKGBQrWJJHDuZJupc9hlwhTKiguZt013lnXtQH12JtD6LyI01X+BwbJKtv/rH7aZNpfsWgkM+qIEBtcWcDnJrarl8He+piYvZ4Ofxf/suDVzttsKX6Zbg7Xw33u6Ixiix6wF7PTbdMraFjB1jx0obdsGRyikgUKl1GbPcOdS/9F7lJaX02bUizg6b7HOfrO4DUXvjyLjiX2ovPM+rLLVUFFJ2XkXY2TlYtdVYxguTE8OudddTtUd91P95ku4e+wEhgmE1gTwbDtyMK/xs810YAcCGKaB4fFg1VZjuNwN97OG7a/D0b4Trp13xD9+EnZtLUTpnW+4XISWLqby3ofJu/laOUxBPr4ff6Hskkuoef5Vit4fiaN7V2oefwbvzz8hZcUBXNv3peDxh/AcMLAFj3DzaYBQKZUyLNMktzGLcN9dcGsvwpQVcLswLYuu85ay46S/6dwYGHS5wNn8wGAj2zAIuCVw1mPWQrrPXcx3QwYye4eeZHh9MfgNksM2DEIOE8vhwO3z4/YG6DljHtk19fT8+18sh0lGvZ/8ykoMbOo9mXx9zAEs6rFFSvXmlMCgQcfFK9hx0t90n7MYRyhEwOVsCA4LyzTxud24/AH6/jaNrafNZfYOPZm+y7ZUtsnXzKMYsg2DoMuJGbKwTANXKwqW+TNcZHj9HPjJD3SbsxjTsihYXUmvmfOoLMhlZad2TN1je1a3KyLkdOAIBjGtze951dLA4NqCTgeZdV6ya+qQk5ZIbNovW8X2f85g+q7bMbf35h0otBwm2DZb/bOAHX//m46LVmAbBh2WrqTHPwuYs30Ppu/Sm9J2rTdQ2PjZ3ciw7f8C95vjc0IpFZ3hzqf+x+8pOeBw2rz2Iu69dlvvNjmXX0zGgP5UXDcc77dfAy7wSwafHfCTedChZJ9+MrbPR1ZFBWZuLvXvzwfHmvchOxgEO4DhylwTKDQMjKwsGZgS8OPs1oW8m67G0b0rgb+mUXnHPdjeesCB4c7A9tfiOeRQCh69n/p3RuP76de1fxMIBbFCtRhGpgQXsTGcGdS98Sb1H3yCmZWJc+ueFL3zGs6uvQjOnU/N48/i++4nbMuS27szyblkGHm33YRZWBC/B34jDLuVvVkvySguBwrifJjjgffjfAylAAYB38f5GJXAHsDsOB+nScyQRX12Jh+cOQRvZoZmETaBbRrYGIAd35Pixmw3y6LL/GUNgcGlGJb9X8AoXsyQBQaMPWIA/9/efYe5UV0NHP7dmZG02uq1173bGIMNxvTeOwQIvQcILSEQCCSBJPBRQ0lIaIFAAqGE3iH03psBA67Y4N7bervKzNzvj6st2mLvrrQrafe8z6PESJo7V1q1OXPuOXO23IRQXQ4FCRX4yiwbDsRc+q9Yy9BFyxkzaz7BaJySiko04FkmsKqVMgeaYLLxgg6vH7kPi8YOy3iQMB5woFnGoOOawGB7/v6W7xNwXeryQny9y2S+3WEivmURzNIMyVxgDsgdAlGXTWbPY8T8JXw/cRyLxg5DK5W12aftUR9sGLpwOdt9NJXhC5YQCwSTXmuW5+N4LrFQkIo+xcyevCk/bjaaunAIlOoVWYWebeEFHPqsrWBCs8Cg30Z2QzrZrofte6wd0JdpDYHCEIFYvNcEhdyAQ2FlDfu++B6DF69sCNjXU74m6MaJ5IWYO2Es07fteYFC37awXI/x0380GeIaouEQC8YNR2mIhEN4to0Tj2P5ute8NrLEWcC/E/9+CTisq3akLfO9c/T9L5JfU9fVn0FHAs925Q5E19OxWqzSfvS55SYKTjup9Tt5PtV3/ovKv/wdd+kCLCsfbBssCO29JyXXXkFwu60pv+C3VP/jTlSwAFwXa9BA+tx8He6cH6m88e/guiZIqHz63P43AuM2YeW++1J0/kVY4TC1Tz3HoJlTWLXbgWArqIsQnzkDa+gwBn7xHlU33ULlrX9FkY8K5ZnsRM/DGjSQ8OEHE3nrfbx588BOfP67MeyxYwnuuD3OoIHY48ZQcfFl+DV1aOoAhcIiuOse9LnmckL77NHW0/QOsG/6n/2WJINQCJFVfNuiqNJ0NP5k3x0IxFM7uFXaLDvriYHG+iV34Zo67ETWUDQcSvvBRv2BjvI1I+YtMTUG5zcJDDpdFxis59sWluezz0sfAHRpJqHf0NEz9ddMfW3GcG2Ezb5dyMSpsymuqCIvGiVumaDahjJ7PMfGibkc+Ny7vH7k3hkLEprAYJOMwcRS4njAIdYkW2Rj6jMKnbjHTu9NYfSchXy3/UTmThxj6hP2kAPl7tAQGIy5bDr9RyZNmcmAZatQaEbPWsiSMUP5bvuJLBk1BK0UTjyOyqHjcd+y8G2LTWbOY9//vY/tekSDLbsR+rZFzA6ifE2/1eXs9vqnbP3JtywbOZhvt5/I6sH9k7KYehLfsogH6wODpsZgfo1pPtLRjMFUeI6Nh02fNRXs9epHbPHVLKZvuzk/TBhDNK/nBwrjAYfCqloOfvpN+q9c2+pzry3zWW+5Plt8PZNNZs7jh4ljekxGoW9ZaKXY4/VPmTh9Nh7me9RTNlUlZpn6/PGjqCnKZ+HY4VT2KSIaDuHEJFgoRG+ngvn45RWsO/0c4lO/peS6K1CFhcl3si0Kf/0L8g47mKq/3UHt/Q/j1a7DUvlEXnuF6LsfEtx+G+LffGcyBQFsG3/dOiJvvoczcjgqEDDZhErhx2rw5i8kuPVWgMadOZviK/+AX1GBO2s2fvkaSu+8Fb+6mjXHHUXBYYeA52OVllL28GNUXnU97nyTqeh7teTvuyeld91CxRXXUnHdNVi2qauofR+ruIjwIQdQ+/jTVN12Z2JpswYUwfFbUPS7Cyk4/RQT8GyFO+cHah9/+rvi/7usy/4GTUkGYedIBqHoLnvRyzIIwQRmagrz+X7SuNSCNNocuMzZYhMqS4tMoDDHO6lqpdCWwnUc8mvq2HTaXCZO/Z5gNIZvWXxw4M7M22xUWoJITQODwxYsZaspMxg2v3syBtti+T4KeLsLMgl928J1HAorq1FaU1VcaJqEdKJWXv3z03/5GiYlAqrh2gh+Ijuwo89dpjIJm2cMNg0MpuPvXx+0mb7dBKZvsznr+5XguC4qB5aH1gfotVImM7KbMvXqs+oCsTij5yxk0pczGbB0VVLGUn1ATFsWi8cM5bvtTKDQNJTI/gNy37ZQvmbf/33A6DkLTLCwA1kolu/juC6xQIB540cxbfuJrBpcBomMymx+7O3lOTbBSIxtPvuOcYmMQbebMgY3pj6jcM2AfkzfdnN+3HwMtQV5BBIn63Lh/d1e8YBDYXUthzz5Bv1WrktaXrshytcE3DiRvLzGQOHAvijfNDPJpZOa9cHBfV7+kM2mzyHSLJBfvwLAcT0UPpG8PFYPKmPx6CEsGDeCqpKihrIllufn1GPPIZJBKLKf7+O71YS224XSf9xMcMeWS47rxb+ZRtUd91D3xNN4NetQNC7rbV4XUMdq0HhYgaKGJcZebC39/nkvVlk/1hx3LMWXXEr4sEMITJpI7NMvWHXIYRT+/CzyDj2Q1UcfTuk1NxI++qes2mt/Cs89h+C2W7PmyGNQwQK052H3LzMZhK+/g7tkCcp2ms0hApjjCY1PcOxmFJx3NgU/P7VFk5amah9/hvUX/x53+YIrR2jvms49sR0jAcLOkQCh6C570QsDhNC4FDEdqooKmbXVpszaajyVpYXmICWHAoX1P749x8b2PAorqhk1dxFbfDWLPuUVeLaNVhaW7+M5Fm8esTdzJ4xpEdiyXQ+nHRkKjYFBn+ELliVlDMYDgbbLUXUTO3Gw8fZP9uD7LTcxtdaaf5Upc1DSnkCAb1vEAw7F66vZ/Jvv2fzbOSjfZ86W45ixzWZUlBZju67Z70a4AQffUgxYtoZJX85k9PcLCMbiiQP31J64pkHC+ZuO7FTg0nRFdjeaSeYGHDQwZPFKtpwyg5E/dmwpcUcorQnE40RDQT7faztmTh6P5zhZGcgx7zXwAg4FlTVs9t1ciqqqWD2gjJmTxxPowpqKDYHBeJzR3y9k0pczGLB0dYuljMkbQSAeR1sWi8YMY9mIQSzYdARVxYXEA445YNc6qw7I40HT4OGA599lzJz5LZYUd4R5bbnEggEWjBvB8hGDmDthDPFgIKczCl3HJhCPc9Az7zBywSKiTigrAoPNOa6H5XusGtSfJaOHMH/8SNb3LaG2IJz43Nbt+lzNVvGgQ2FlLYc89SZlK9d2KJu6Xv3nXyScx/xNR7J05GCWjhxMdXEhSvtYnnl/dsdnYf37rCP78m0LjWKflz5g/Iy5rWb5Nqe0NhmTvk80FGTV4P58v+Um1BaEWTugL9XFhdieZwLJygRTs+kzKkdJgFDkDB2rQRWWUHTxBRT/7iJUYUGb941/O43qe+6n7tkX8VYuAgIoO9hmNh5gMgEHlzHgrZeoe/Vtau65l37PPsryCVsQ3v8Q+r/xAivGb0tgm60IH34Ia046lsJTzqbk+itZOmIY4b0Poc/tN7Niy21RwfzEmB6+V4tlhcEJ0PTARMfiaOpQhAhuty0FZ5xC/glHY/UtbXuKS5dT8cerqHnoUQBUMHT1sOiaqzrwNHaaBAg7RwKEorvsRS8NEKZTfTZJdX2gcPKmVJUUZXUX1aaZZkUVNYSiUYbNX8bQBcsYunA5gVgcbSm8Zl+AtucRCwb5ccJok7ye+IhXWjN3whiWjRiMou3sId8ymTvD5y9NqjGYDYHBpizfBAnfO2g3Vg4b0MrSLM36vn3wLYW1ge85z7YpqmgMDBZWVeM6JtjiuC61Bfl8nwgUri8txmnjNaOVwlcWA5avZssvZzDm+4UEYvG0Z1rarkckHGLeZqNR6JaB0Q1QiSVei8cMbch6a+1xaBSDl6xo0ZW4qzNGLd/H9nxWDS7ju+0nMm/8yIZAYXeqbyRjqnqCb9topbBdj5LyCgqq6xgzewFDFy6j75pyLDQ+io/224lvdppEKBrt0N+lPfNpHhgcuHQ1/oYCgy0GIdG0RBMPBlg2YjDLRg5i4djhxEIBKvsUYfkay/MaHredgUyvaF6QET8uYbuPpjJk8cpOBVxaUx8oVGhWDB7ABwfvyqrBZWhFq8Hy5gGZbFr6abJAXQ565m2GL1jarUuJO8v2PJxEE6O1ZX1ZNnIwP24+mmgoyPp+JQ33gcRrr50nd9pLK4VvKRTmuxXA0jqlE4X1y4oPeeoNylauS/m1Wh8o9CybSH4eS0YPYeHY4awd2JfqogKi4RDK87GbfG7X1/nrDJOVm3hOEsv5g5EooIiFgtiuh0KjwXw2tPJ90Zg5+AHjp7cvONja47Zd023UtxQ1hfksGWWCyZV9irE9853X2meU0mT177gsIwFCkVtcF9+vI7TVthRf/SfCRxy6wbt7i5ZQ9+z/qH3iGWJffYMfr0ARbDVYqONxwocfQvHvLsRduIjK6/9GnxuuJvrlVwQnT0Ll5bHmxJPpc8MNhHbbiVX7HIyuraXfw/eja+sI7rgddS+8wvrf/s7UOmxOa3TcBWKAxh4wlNB+e1FwyvHk7bc3BNr+vtDxOLX/eZjK6/9CfNE8LKegPiNSAoSdJQFC0cPshQQI06ZpoHDm5PHMGz8y6cd2tvBsmwHLVjN8wTJiwQADlq2mz7oK84Ndb3x5b/2BRnOu47Bgk+FM324i0VAQSyc/dt+yyK+uNYHB+cuwfE08mL2lapXWKF/jOXaLg0mlNYvGDGPa9hOI5rXe7MazbMbMXcjmU2dTVFnd6vK8+tdMTUE+s7falB82H9PieasPHk2cOpsxs03GYFdk2jU8tsTStM5wbaehNl1dfl7S8+Iri1A0xhZfNi4lzsRScifRgXbVkDK+2mUyP0wYQyAW75Igjcn4tKg/ytbKIq82Qp91Ffi2he16jJ/2A7brEYi7DJ+3xGQ3x+O4ttPQTEZpjeO6fLzvjkzdZRKWp2k8clcNmVIdOZhtqDEYdzsfGGxFQz0+pXAdm8o+RawcOgANzNlyE7PUz/OpLC2itiAfpdvzGakaxu1sYCeWF2TUnEXs//w7BGJuu5dqdpTteniOzYJxI/Acu0WAxfJ9ftx8FFUlRQ1LI9cO6Ivr2InlsaDQGQkaeo5pdHTgs7kTHGxKabA8s/w4HggQDwZYPGoIdYVh5kzcpOHk1bqyUmKhQFqChFopgrE4hZU1+MoiLxIBDXUFYaqLCzqVSRoPmgziQ596i34r16b9tVr/Ge/aDtpSrBg6gOriAmqKCvhx89HJr0vbNieLOkBbFkXrqymoqsENOIyau4g+aysI19SBUtQU5TN3whgi+XnYrkd1cQHVJYWoJt8XWikc12Pvl8yy4s4EB1s8bg1Km+/cuBMwn8GeT0VpK59Rvo/rOKwdUEr954+ZnzIrCBLLlUUDCRCKnKRjdYBD+KjDKP7DJQS323qj20Q/+ZzIy68RefM93Bmz8WrXorABG2UHTMAwUYtQFRej6+qwiovIP+1kdE0NtQ88gkZTcMYpOJuMpfbBR4l98zVWQTHhww9FFRdR++Rz6KpKsGwTEHRd0C4aF4WDPXgowe23IXzkYeTtvTv2yBEbnXfktbeo/PNfiX70IeCgkr/jJUDYWRIgFD3MXkiAMO3qM5VcZwPp5xlmeT62bw5APdtukSnYGaZhSxzPsdsM+ihfY/u+qT2XI9o6iHTiHp6z4Xp/juvh2Ruvb2b5fkPArK05ZCqg1lGBuItnWehWljw3Po4AOsMPIxCLEw8GmLPFJkzbdnPWl/VJ27LQ+qXCw+ctZbNpP5jDa2WC5EUV1Qxctsq8JrQJWJpMGpVYeq1azaZV2mR0Lho7DK/JQbvl+dQU5TN92wmUl/Ux9dk2EChs2nxk9JyFTJoygwHLVjfUHk23+i7AGtXw2WD7PqsGlVFRWtyupX2257F49FDmTNyEWF6wQw0XtFJE84KM+X4h+z//LrbnpeXzbkMagplt3O7aNtoyQQetFEtGDcG3LZYPG8SK4QPQSrF6UFnDWPUnb7pSfcOig3I0ONiCNoHWQNxFQ2P9TF+zbOQgIuG8tAUI8+oilK5Zj29ZFFbVoDRUFRfw2jH7sWZgX4LR9p9wMZmDNYllxalnDraHE3extI9WFm7ihFj96zIe7Hgg1bcsylauo88685zYroelfXyVaNClNW6Tz4K1ZaWs61/a7ISSoqC6jqGLlnfN74XE60Mr1epnlPI18VCAJaOGYPk+VSWF5gSe72P5muqifNb3K8HyNWiNgt5e31AChCJ3+RrfrcHK70P+sUdSeOEvCW49aePbaU38m2nEpnxN9P2PiH07HW/xEvzKtUDihAJg+vZqNBFAoVQBSil8vxaFBQRRtoP24mhqE+tGgonbfCCAPWgwzqiRBHfantBeuxHcbhvsoYPb9fBiH35C5a13Uvf8y+DHTJOVlscSEiDsLAkQih5mLyRAKITopeqzYWPBIG8fvhc/bG4a8HQ2cFDf9bWooprJn09jqy9mAMlJZNqyUjp50NqSaIWmLhxmzhZjmbHN5q0GCrVSxANNMga/SjQfSXE+nWUaTfjtzk1SwOqB/Vg1pD/TtzWdWdG6oc5ha3zLwtKa0bPns/sbnzUE7LNNfW1JXylT8zHosGLoAGqKCpg7YQxrB/YjEg5t9PF2lmebmoMHPvsOwxYsJZbrwcGNSCUTtTVaKXzbBnRDsMKJu1QXF/DqsfuzZkBfgu0oZeAGHAqqajjkqbc6XXMwnerrOHaUov7EY/vea7bnYXstPwu66qRFeyV1J1eq4W9r+T6VfYpYM7AvgZjL0pGDWTm0PxWlxVQXFzYECesfT1e8Z7OQBAhF7kvU+bMLSgkfdTgF5/yc0G47tXtzHYni/vAj3sLFxGfMIj5zNu78Bej1lfiVVaZJSnUNxKImQNf0Y8FxsIoLwbaxSkqw+pVijx5FcIsJBLbYHHvcWJwRw9v/WHyfyNvvU/3P+4i89Co6XoNy8ls0WGlCAoSdJQFC0cPshQQIhRC9nOX5+LbF3Ilj+WTfHXADToeyCes7VBdVVDEhUW+yoKq2Ww/w65cN1uWHmTNxLDO23Zzyfn0S2UAQjLmMSsoYzExgMBX13Wvr8sOsGdiPuRPG8OPmo4kHAw215eqDom7AwfZ89n7pA8bP/IFoCs1IupsJTHgm0qI1awf0ZcXwQczbdASrBvcnlhc0WeBpqI8WDwYIRWIc+MxbDF+4LPczB7OI47rUFBXwyrH7bzSTsCE4+OSblK3qnsxB0Xn1Wf9gAsSW1qztX0p1cSFO3OXHzUdTUWrKCKwYPpBYKNj5mquJJc1Z3p1bAoSi5/A8fK8OyykgtO+eFJx2EnkH7IPVr2+nhtN1dQ0BQl1VjY7GmmXwaZTjoIqLTICwtE/z5b/tn/qixUTefJeaBx8l9tGnaB1DOeENBQbrSYCwsyRAKHqYvZAAoRBCNGSLrOtfyqf77MCCccMJxuIbPCir78ZcWFVrGtF8N4eiymrirdSb7C6Wr3ESgcLZk8axdOQQ8mojbPH1LAYuXZXxrJx0UIlMOrRm3YBSlo4YzNJRg6nsU8Ta/n0b6p7t+vYXlK4uT6mmYjawXc8sZQTWDihlxfCBfLfdBNb3LQFlyh10NEOpvlzBwGWr2PG9r3pF5mAmBBKZhK9sIJMw3Q1JRGbYiSXGmsTCQm3+Z/Xgsk4t1a4XiMeZuuOkhnq5WUoChB3R2mshR05g9Sq+j3YjADhjxhE+7CDyjz2SwPbbdDqA1xX8lauJfvgJdc+/ROTtd/FWLAFsVCCvI68rCRB2lgQIRQ+zFxIgFEKIBoG4ixuwmTNxEz7edwe8ZtmEOtF8w9KaoQuWseWXM+m3ah3FGQ4MNmf5GtttrIPnWZZpmtHD1AfPLDxqCgpYM7AfC8aNYLuPphKuqeuyZiSZUp9FWVuQT3lZH2ZuPZ75m47EdZx2LZ2tDwwOWrKSSVNmMmruQizPz/kgajZrGiRcNbgsqYxB47LiN+m3cl2Pe70KUq4h6miXZUMH8+JJBwNt10XOMAkQbozvo91awEJZzTrfeh7aNx1p25nt1Xlao+PVaBrrZSrCqGCITrct7wV0LIYmguUU4mw+nrz99iJvv70JbDMZe9CA7p2M6xKfPovoF18ReeUNYl99g7dkAeCDCqE20MV4A7otQCi/NoQQQgiRM+IBB+VrJkydzZBFy/nwgJ1ZPHoodmIZshN3GT5/KZOmzGD4/GUo38dz7KxbmulbCr8XBBs8x8Ys9HMIRmMMm7+UEfMWE3cCPTLYYh6vTTAaY8iiFQxZuJyVQwfw3fYTWbDpCOKBQKuBwqTA4JczGDVnEY7rEQ84EhzsYvGAQ2FlDQc9/RZf7LktC8aNIJoXQmlNn3UVHPDs25I52IOlemLGxWHgslWMnrOQOVuM7VDTG5EFtEbHa7EKSsg7aH9C++xOcOvJ2EMGmUCg7+MtX0l86rdE3nyXyFvvomO1qGB+l8yFQID8Y0/BKi5uuDr2yefEZs5AWfIZ1BYVDKIIgu8TnzaN2LSvqbrlDuwhQwlMGE9oj10JbDEBZ8JmOGNGdTZI15LWeMtX4M79kfiM2cSnfEXs629x5y3Aq16T6J4caKvxSFaSXxxCCCGEyCnaUsSDAUrWVXLI028ya9J4vtp1Kzb/5nvGzZhHcUU1tuuaoEsPzMrLVb618Y7hPUXTxzpg2Wr2f/5dEyjcbiILxo8gFgiYjuKJrqzJgUGXeCAgAaluVN+deP8X3mPF0AF8v+UmFFXUsNm3c8iLRORvITZIo9jyy5nM33RkojZppmck2sX30G6E8OFHUHz57whuv22rd3M23YTQnrtSeNF5RN/7kIorryf6wTuoQGF6gz6+j8rLo/TWm7D6lzVcXfG7K4h+NwUVLEnfvnoqy0IF81DkmeDdshV4yxZT99arKIJYpf2wy/rhjBuLM24s9ojh2IMGovLDpoZhoqFVSwq/fD26uhp/zTq85cvxflxAfO4PeIuX4q+vwI9VJAKCDsoKYAWLWxkn+0mAUAghhBA5yW2STTj6+wUUVtfi2VaiW7Ec0IvsUJ8BOGDZavZ/IREo3GEii8YMo2zpOiZNmc6ouY0Zg1JrMDNMZ1+b/svXMHjpCjSmHmiu1wQVXc8NmCzCUXMXZXstQlHP99GuS8lVV1J85WXt3iy01+70f+MF1p93EVX/uRcrUJTeIKHW+BWVSQFCHY0CuZF9llWUQgUDQCBRd1SjKyqJl5cTn/s9GhfwTeYhDioU2uDfUkdjoONozN9D4QA2KBtl2Vg9JIAr33hCCCGEyFnaUniWTV4kKlk+Iqs1DRTu++L71BTmE4rECEVjicCgvH6zQf0ycSE6QiuLSVNmsGDcCMkizHZao90aSq69juLLf9f2/TwvuRZhggoFKb3nDvyaWmqeeAwrWJS+uSmFKipMvioYRF5QaaAUOE4isNck5Kq1ubhum5sCKNsClYdS4a6dZ4ZJgFAIIYQQOa+3LF0Vuc8NOCitya+pQyslgUEhegDXsRm4dBWj5i7kh4ljCUgtwqyl49XkH3UsxX9qGRz0162n5v6HiL7/IX5FNVZJMaHdd6HgjFOxyvo23tGxKb3rFmJffo07bz4qENrADnVyZ2SlWs9UUwodi1H9j39h9y8z2yhF7MuvUdYGxs82vt+1jVzSra2/Ry8lAUIhhBBCCCG6kVYKLQckQvQoWikmTZnJgnEj0Upla0fjXk27LlbfQZTcdE2LVbvxmbNZc/TJxGd/27h8FI/a/z1Dzb0P0vfx+wluvVXD/a2+pRT96heUX3wx6GBykMn30W4UTRyFhbLDJglQgXYjiesDKCevMZhmWRCNUnHdVZBo7wWgKEAFwyRlEWqNjscS92vseAwW4JgmHBv7jvE8tBdrWGrbOL5CYWGaa2x42a0Zx0d79Y9VgQqj3Wrzb4KJDswiV0iAUAghhBBCCCGESIEbcBi4dBWj5yxizsQxBKUWYdbRfi0FJ5+Ds8mY5Otrayk/4zzis7/DCvZJuk0BsTkzWHfSmQz4+E2svqUNt+X99BCsq6/Hr6xGJcpI6FgdygkR2nNPwgfuizN+HKpPn4aMQF1ZifvDPCJvvkv03Q/QsUgiAOiDbRMct01iWbHhrViJv3YtKCsxfgTQOGPHEdhic+zhwxrvO28B8ZmzcRfMM3MPtr4ctr4Tc2jXPQjtvjOBTcdBw/xjxKfPJvr2e8SmTgWsRJCvZcBbx2pQwQJCu+5B3n57Edh8PKqkBH9dObEvv6buhVdw5840AdJWlmuL7CMBQiGEEEIIIYQQIkW+ZbHFlzOYv+kIySLMNr6PFSoifMLRLW6qffhJIl98iBVovdGEFSwiNvs7Iq+8Qf4px4HnAwpn+DCc0aOIffMN4ODHqgntsDMl119F3r57bnA6Rb/9NZE33qH8Vxfj/vAjynZQBYWUvfQUzuiRDfdbf+GlVN5+C1awGD9WQ3DiJIov/Q15hx2M1aflfP0164i89S5VN99O9KsvsIIFSbfrWC2hPfeizw1XEdx5hzbnp6NR6h57mvV/ugZv2dLkLEat0fFaQnvtRcmVfyK0124tts8//iiKL7uY6lvvovKGm02NP2n6lPXkLySEEEIIIYQQQqTIc2wGLV3F6DkLmbuF1CLMJtqNExizKcFtJze7QVPz6JMoAhtsFmw5hVT88Wqq7/mPaWACoBTesuUoJ4iO1ZG3+16UPfcYVr/StgdqIu+AfSh77lFW7X0I/tp1Zve+n3ynRJBZx+rI22NPyp55BKusX9vzLOtL/glHEz70QMp/+RtqHnkYlQgS6liE0C670f+lp1CFBW2OAaBCIfJPP5nA5EmsPuRIvJWrUE4wERysofAXv6TPrTehQsE2x7D69aX42suxRwyj/FcX5159wl5IAoRCCCGEEEIIIUQaaEux5Zczmb+p1CLMLh72mJGoUHJNPH/tOrz5C9loaMSycJcsxV28MOlqZYdA+1h9Sul7753JwUHXpfaJZ6l77S2IRQluvx2F55+NystruEtgiwmEdtye2pdfMFe0+nrxsAr7UvqPv7UIDrpzf8SdvwAVDBKYPKkhq1AVFVL6r9uIz5hF7NtvUE4IbJuSa/6UFBzUlVVU/+NfRN59H5RNwUnHkH/y8Q1LjgOTt6T4T5dSfsGvQQdMk5djj6f0zr8lBft0dQ3xaTPAtglstWVS4LDg7NNxFyym8vo/o4LJXZpFdpEAoRBCCCGE6EksYAgwAOgD1K/B6of57bsy8d/VwHpgNbAMiHXnJIUQSQqB4Zj3bSkml2sIUAeUY7oxlANrgIVAbWamuXGuU1+LcCFzthhLULIIs4SPPaB/i2u9FSvxKypQ1sZr5KlAAGjZeV7H6gjvdQjOpmOTrq+86RbWX34ZEEAB1U8+hAoGKPz1L5LuZw3oT3KzkWbj4+NsMZHAlhOTrq998jnKzzkPr2ItCofA5pvT7/GHCEwy91P5+RSccQqxC79Cx+M4I0cQ2GqLpDFqHniYtX/6LTYhNFD35guUrlxN0aUXNdyn4GcnUnn9zXjLFmEPGk6fv12fFByMvPUe6y/6He6suaAUwZ23p98D92CPHd1wn6LLfkPdcy8Snz17w12fRUZJgFAIIYQQQuSy4cA2wGRgO2AToC8mONj22ifDBSqAdcACYCrwdeIytysmK4QATBBwZ2A3YEdgNFAGFG1kuypMUH8J8BHwGfAFjYH/rOBblskiHD9KsgiznK6qRtfWgZVCZ3nLwVu3nqq//8PU2lMKXI/qu+5DkY8KBM3yWi9q9tV887IyzLmttjmjR7W4zp3zA27FCixVjLJtYrO+purm201wL9EURRUVggqC9lF5oRbNQoI7bk/eFtsTnz4LRQyNour2uwCd1MFYOTaaOAWnnpjcGGXREtadehbuikVYdgFoTeSjN1n38/Moe/OFhoYrVlEhBaedxPrL/gBIgDBbSYBQCNGTOcDdmINFL8Nz6SoOcA/w6EbuNxj4JyaTpu1TlNnJAe4EnuzANrsCNwCZOm2vEvteASwCfgSmATOASIbmNBLzGsijtVZ03UNjDuwWY4IvMzHPyfoMzScP89oaS8c/IxzgGeD2jdyvCPO8DyX33nvtFcS8317pxn1OAA4CfgJsiQksdIaDySzsB4wD9k9cXwHMAV4F3sQEIrKNBdyCCYy6HdzWAd4Crk1h/zdiAjwd3Xe6KKAS83nyI+YzZRrmMzdT/ggcSOaek86yge+BX9H1c98XOAE4GPO52FFFicsYYI/EdSuBD4HHgTcwQcSM8hybgUtXMep7U4swGJUE5WylCgtQ4TC6urp99fFaCfYqJ4/oBx8T+eAtzE8dFw0oLBT5oDUqGCR/1yPIP/m4lmM2rzvY2m4rKltcV/SbX+GvWUvtY0/hrVmLIkzNfx+g9unnTbajbR6PCgTQsVhirskhoOCO2zHw03eJfvQJ0fc+JvblVGJfTaX8sosTj0EBASwrjBUoIe/QA5O2r3noMdwVC7ACfaj/eWmpUiIffEzs0y8I7dnYwCTv0INQV91ggqhSizArSYBQCNGTWcCemABhT/ZOO+6TjzloydvYHbPUqx28/yBg966YSApiwFLgXeBl4HWgphv3X4g5IMsmHrAK+BjznLyMCSB2FxvYC3Og2Rnft+M+QWAfTJC+JxvRDfsoBn4KnALsAmy4wnpqSoDtE5fLga8wJ2KewQSksoHCPA/bdXL78hT3vxONAZpsUY456fAC8BowvZv3vzXZ95y01yA22KIhJTZwNHAh5jWbbgOBYxKXOcB/gAcxJ+kyRluKSVNmsEBqEWY1q18pqrAQv7JqI28ABZ6L9qLNR0AF80ymXMwDNM6o8QS334bAZuNxNh2LPWoE9pAhOKNGdCowplDEvvoab9ly7CGNPydUQT59br2R4j/9lvj0WcRnzSb+7QyiH3xEfPb3aOqwVCEEHJTj4C5eTPybaQR33zl5/MIC8g7an7yDzDkyb/lKYh9/Rt2rbxB5/iW8davNLAryCWyafFgVPvan5O2zOzRboq19n8C45CXXzgjT9Tk+a3ZDZqHILhIgFEL0dC3z+Hue9mTJaUy9nlwNEHY0EzAbM0aDmCVUo4GfAz8ADwH3YeqfdTUf834Id8O+2svGBM7qD+yWYzJF78NkAnWHVD4j2pMSolPcR67oyqyjAcBZwJl0PpibCovkYOHjmMzt7nqNbkgqGcnNj3K7c99dpRSzZHU3THbkW5i/1UvdtP9Un9NM6qrPqT2A6+i+k3abYrJbfwX8BfP3z8hqAtdxGLhsFaPmLmDuxE0kizDjbLzFS1teO2AAdv9+eMuW0Fp9wQZuDHvYMLN81wlAIr/OX7mKqptuwa8pJ7jVNhT94RLyDtoPq6Sk7bF08vLdjXPwVq5g7Uln0u+Bu7FHJZ+Ts/qXEdp7d0J7m7eZrq0j9tkUqv95L7VPP4fyLbAsdF2EtaedQ+m9/yBvnz3b3Js9eCDhY44gfMwRxH/zK8p/+RsiH72HbZVAsyYvgfHjMAn4G6eKi7CHDiY+azobrwAiMkHyOoUQQojM2AS4BpOZ9EdMhl9vNxiTYfI5cBudW34meo584LfAl8CfyUxwsLl+mMDDZ8CtmKX7IjvlYZag/w+TTZhtWeU9XQgToHuHzDz3w4E7MFn7O2Zg/0B9FuFMnHgc3aGAkEg/G/eHefjrK5KvdhzCRx6G3sg5D+3XEdp3LwrPO5vCc06n8JwzKDzndMJH/gQ/WkNgq63p/8aL5B9/dHJwUIP7wzzq/vcqldfcQOV1f2mjU/GGqWCY6PvvsGqfQ6n881+JffElurr1hSgqP0xonz3o99RD9LnpWrQXN8ucAyHc+QtYc/DRrDniBGrufxh34eINLnEObDGBsuceJTBqHESiLQKbuq7O1HGsrmnXpT3LqUXmSAahEELRdUtKhBAbNwgT/Dga+AOmflJvFwZ+jVlOejnw34zORmTC4ZgA+laZnkgb8jHB7GMw2Ur/JDszl4VxIKb23Z3A/2FqF4quMxK4H9g70xPB1CR+G7gCU7OzW9VnEY75fhFzthgjHY0zSAUCuEsXEf3wU8KHHZR0W+H551D7+NPEZ09DBYtpUarZ81BWHgVnnNxi3Ngnn6PdWkquvhxrQHI53Mib71B5/c3Ep0xF19bi6UrCex5C8eW/7/D8ddwFLOLzZ1F++e+xLi8gsNlmBDbfjMCkieTttzeB7bY2jUiaKPr9RdS9/DrRDz5AWQFAoWMRal98kroXn8MqGUBgq4mEdt+VvAP2IbjjdqhmWYJWWT8KTj2RiutuMLUQS/s03Fb76NNUXncjKpzfeoVr7dcnW5qncsVKVCBXFzT1fBIgFEKE6bmF84XIJdtglsFdgwkYSrEiU9fuIUwt0Qvp3pqNIjMGYpaGnp3pibTTUEyW0jHAJZiMYJGdHMznyJ6YJevyt+oakzGlItq35rB7FAB/ByYCF9DNZR+0Umw5ZQbzxo+QWoSZpBTa96i598EWAUKrX1/63vsP1hxzMu6KhSjCpqaeBrSLpo6SS/5AaPeWJTRrn30Ju6CsxZJdb8VK1p1+Hu6yH7HsQnAcVDyAM6IziyN8nDEjccaNBd8sT/ZWriT+zdfEZ09HP/cU1rU34UyaQJ+//Jm8/ZNj88FtJxP94B2sfgNR+WGTxacs/MpK/IpKoh98QOSDd6i8/m8EJ0+g+PI/ED7qsOTnaPhQfF1LfPacpCXOgYnjcRfMw3zENssuJIJqer0ytRBRspA1W8lfRojebTnmgCaTHf+EEI0CmODIo+RuvciucCamqYss5+zZ9sU0rMmV4GBTe2K6HZ+b6YmIjZqM+Tw5PMPz6IkmYJZ0Z1NwsKkzMTVE+3TnTl3HYeByk0UYD0p+TiZZTpjIq68SefPdFrcFd92JAe+9TtFZ5+KMHo1dWordrxRn3Kb0+fNNlPzlmhbbxD75nMjbb2IPGwqh5Jp6fkUl/tp1WCofbBs8D3AJ7rpTy4ltZNmtxiP/hKPp/+qz9H/9Ofq/9iz9//cUdt8BgI0VLALbJvbNp1RcekViX03YNj4xSq6/koFffcjALz9g4Ncf0u/x+1GWhbKCWMFilGMTnfo563/7J4i1zHbVaKLNnrvANpPJO+AgNNVmLMdBWRaaWvIP/An933yFAW+/yoB3XqPk2svRXq41ee9dJEAoRO9UiakLsx0m8yGXi2oL0ROdADxHNx/EZLldMQeeozM9EdElLsBk0I7d2B2zWClwN6YpQn6G5yI2rB/wFHBqpifSgwzEBN+GZXoiG3E48Czd3LBLK8WWX84gEHelsE8mWRY6Hmf9JX/AX7O2xc3O+E0o/fedDPzmIwZ88iYDPn2LQd98TPEff9uy+7DnUfGnq9FuLdrzWtQVdMaOpuDs09G6Dj9WAaEAhWeeR8HPTmw5rX592dgLIz59VtJ/28OGUPLX67CKi/FjlfjxSuySwRSef64JSDZRX6vQW7YCq19frAH9sfr1Je/A/Sg453R8vxo/VoWOm/uFjzgEAsnBbHfWHCwsah9/Cm95Y4NwFQzS91+3kX/4caiiArBtVFEBhSefQb8nHiBvv70I7bMHob13x12wCO3LYWc2k1MYQvQuHvAIpl7SrI3cVwiRWQcBDwPH0ju64LbHlsCLmMYDCzM8F5EeDmbp3wWZnkganYMJZJ9O93QoF50TxHRMj2MCW6LzLEx9xy0zPZF22ht4DPP92i1FAV3HYdCyVYyas4gfJowh0Ep2lugeKhgmPu1b1p70c8qe+i+qpLjFfaziYqziltc3VXHp/1H33jtYViH+ipV4ixbjjNukcT+OQ+ltN5J/3E/RdbXYgwcT2HJiq2NZxUWJf7W+/FxhE3nlNSJvvUfefns1XF/w81MJ7bozsS+mgILgDtvjbLpJ0rY6EiH2+ZcoFaLm3gcoOPNU7KFDGm4vveNm8g49iOhb76FjMUK770z46COSmpF4y5ZT+9SzKFWIu2whFZddRd8H72643R45grIXnsCdPQe/uhqruLjFPGKfTaH20SewbDl/ls0kg1CI3uMtzPKt05DgoBC54lBMRpJotAVmCXZBpiciUuYA/6ZnBQfr7Y/JiMz2bKreLoB5DbYsLCY64mxMo61ccgTm5ET30Zohi5ZLDcIsoIIF1L35OqsPP474jI4dFrkLF7HuZ+dQ+bdbsZx8cBz86gqqbvlnyztbFqHddyHvgP0agoPe4qWJhiNNNH1NtNrtOpH5eMEluHN/TLrFGb8J+aeeSP4pJ7YIygFU/OkaYlO/xAoU4i5eQPm5F+KXr2+8g20TPvRA+txyA6V3/o38E45BBQINN/tr1rLutF/gLVmECgRQgUJqHnqYyqtvaLEvZ7NNCW63TYt5eMtXUv7L36Bra8CWEFQ2k7+OED3fNOBE4ADg/QzPRQjRcT/DdPQVjXYBbsv0JERK6oODp2d4Hl1pa0zGqwQJs1sh8CBmiazouKGY2rm56Hy6cZm5azuM/HEJoUgM3WoQSHQnK1hI9IMPWL3HQVRccS3u9z9s8P7xmbOp/L8/s2rHfaj570OmE29i2bEKhKn+592s/80f8FauanV7b9Vqqu+4h1W77k982ozkufQvQ9UvMW6+lDnxWlHBMPHZs1m93+FU//sBvCVLNzhfd/5Cyi+8lKpb7kAF8hNjFFD38sus2vsQ6p55AR2LtbqtjseJT5tB9e13s2q3A4i89SYqmN8wH2UHqbjqWtaecDrx72a0OgYAvk/k7fdYfcARxL75GhXs1pX9ohNkibEQPdci4G+Y5TPS+VOI3HYT8HniIowzgXcw2YQit/SG4GC9rTG1M38CbPhoTmTSJsAtwEmZnkgO+hXQP9OTSMEtwBfA9129I9+yKKyuYej8ZfwwYQzBNoIzovuoYD7++goqr7uO6jvvJbj1JII7bY8zZhQqHMavqMRbuIjYV98Qm/I1fsUqUHmoYGGzgRTKyaPq1lupe/ZFQvvvTWDcWFPzsK6O+LcziH35Ne4i0+137TGnYjVZ2uyvr0AF8tF1Edb85FhUsLHhibd8JVagENCoYBh30WLKz/kFlYOGE9x5BwKbj28YS7su3pKluN/PJT59Ft6qZSgnnJSVqIL5xL/9ljXHnEJwi4kEttkKq6TYNGyuqMRbuhxv+Qq8pcvwKlajCDYGB+vZFsoKU/vE40RefoPgTtsTmLQF9qD+oEFHo7g/zCP+3Qzis75HR+tajiGykgQIheh5KoB/ArcCKzM7FSFEmuRhlkLtRTfVS8oRfwXeRj7rcs119I7gYL3JwJPAIZjvaJGdTgSex/ytRPsMxJysyWX9MN+vh2NqdXcdBcrXDFu4lHmbj+rSXYkOcBwUReiKCiLvvE3dO28APqYeoAIsFDbKCqKCRW2PYylUsAB30WLc++5F09iZWGEDAVTQVEdx5y8g+eXmoIIB8H3iM2cl9p/Y1gqAE6C+PqEJHgbxVq6i7rlnqX3Op2ntQoUFWKAa99ecCoZBa2LTpxOb/m2T7VXjY7Yc0x25LUqhgoXo2joib71J3VuvNZuHDdgoO4gK5rU9jsgqEiAUomd5BJNpNC3TE8kioUxPoBv0hs/y3vAYN2YXTA3RezM9kSwyBPgDcFGG57Ehit7xOWRv/C4AnAFc2pUTSfCA1cCPmMy9lUDTok/FwABgJKahyAaOgtJiF+AfSNfcbHc18ApQnemJZEBw43dp4UjM+yidFgDfYd63kcR1AWAwpsv5eNLfgfgQTID44TSP24JnWQyfv5RQJIrrOFKPMJs4Dgon5SbT9QG8DY3TNEOw5W2t/WRo+ToxdQIDnZ+vUukJ3Dk2inxpzt1DyAGXED3Dm8ANwLuZnkiW0cBMzIGiv5H7tne8PGAMna/hugpzoJquGrAOsDxNY23IPKAWMvL9b9O9GWIaszR/RQpjOJjAw1bA5qTvefstpvNiJsoG/A/4NoXtFeYAbytgEuaALx3OwTRymZ2m8dLNxZy0qSR9n0P5mM+hzloGrCV9n0MBYE077rc9cHua9tmaSkyt3deBzzDBwY097yGgFNgOE8Q7ANiGrvmsOwWYSnc3RshOHyQuqRiAaVq0NekLGG2GORFzZ5rG64gqTHf2TH3PzqKtFqptOyFN+6/DfLc9iHmPVLVxvxDme+Qg4BhM8710uQJ4ji7+fvVsm6LKaob/uJQ5W44lGJVFAUKI7CEBQiFy2zfA9cBTGZ5HtooDx2EOgtN1inYL4EPMAXpn/AOT5ZkuFl2/5FRjGmVM6eL9tEWRnPnT1XxMwH1eGsYKATsCv8BkJ6RqPOY1fX8axuqoh0nP0jsH2BI4C5NNluqBfRg4F/hNiuN0lQpMt0xF+j6HdiS14MqfSW8mans+hwqBfyX+P92+xbwnnsPU3+2IKOZkwEuJy/8BO2OCRMdiMg3T6VrgY6Se6MvAX9IwjoWpH3gGppNuvzSMeSEmUNXdWYTvYYJemaAw330d+a4dhTnhk6ovMHUMv2zHfaOYDMO7E5cDMFmfO6VhHptivku6PICvfI3jdufPGiG6keui/WY/CawAypHQUy6Qv5IQuWkJcDOmyHtthueS7dIdPIts/C4bFAdysSp1hNycd2eVpGmcKI2ZMo9hAsQjUhzzLMzBazqy0Tqi9UI2HediMkR+hQlS3YPJLEvFiZjAy7oUx+kq6X7vpPo5FKP7389XYmrxpdN0zMH8Y6T+nNRzMSeBPgRuBC4Bfk7nll+2Jh/zObAXvbuBWLoy/nxgDqbUwH8w9ZcPSXHMcZjA07MpjtNRHrn1Pbsl0CfFMd7BLFOu7OT2b2C+X68BfpfiXD6gm06EKjTKl6XFogdy41j9++NM2AwSr3GVF8JbtBh37g9gtbcaiciUdC0tEUJ0jxpMUf4dgduQ4GAmpPrNlqufu/KNnrr/YQ4656Q4zvakJ2sjG0zFPCdvpDjOQODQ1KeTM3Ltc2gX4NdpHC+OCd7tjskcTFdwsLkfgF8m9pPqctimtgMuTuN4wpgL/BRzAiVVp6RhjI7KtRJeqX4PLcc0K+pscLBeBPg95qRTZyzAlKrYB3NioEtZvk9dOMyqof2x3e4+zyc6RplsuFhd0oWcqBvZ+txbv0TQsSi4bmqPTWs00PffdzDgnZcY8N7LDHjvZfre+w+swjD43Zg163kt/26uS+59zHY/ySAUIrvVf4r5NDYgmZG56QghUvQ9cDSmXmhZJ8cIYIJhU9M1qQxbDxyPWV6XygHnEcB/0zAfkV42JpiXrgy8eZilpO+kabz2+AJT8+wqTCAiHX4PPEHqJwxEsjjm9TEIODCFcXbH1Lrrjhq/uWp8itv/E1icjokk3IUpCXBDO+9fjVmm/DdSqzncIQHXZeZW41k9qIxgNJcSRnsh7WINHoQ9qEkfHt/H/WEeOhIFlcXBJu1iDRqIPXjgxu8bi+PX1uKvK8cvXwP4KDsMdkfORSp0vIqCk39G3mEHN1zrV1Sy9rhTiU75AhXsigojrfA9VDhMYPyWSVd7Cxbjla9FORv5OeL7iUBpojKMZWX33zrNJEAoRHZTwNvAdZiDZyFE7puOyR56KIUxDsR8LvQU6zEH9R9gGgF1xs6YpeEVaZqTSI/jMMGWdPgAUxtwQZrG64g6TPflGZhaiql2pi7ELLs+OcVxREtxTC25KUD/To5RhsnWfjFdk+qBhqSwbRx4Ol0TaeJGGhvNbMhTmGXJ07tgDm1SvqYunMeMbTfHdr3u3LXoBD9eQ9GZP6Pk6j82XhmLsWK7PYlPm5aeDsBdxI/XUHTaSZRcf+XG7+x5+JVVeMtX4M6eQ+2TzxF55XX8qvWoYPtKrms3hj1wGMXXXd44h8pK1h5zCtFPP0IFizr7UDrG12g3Sp+/3ULhOacn3RR990NWH34M1EbAaaNPnlKoYDC5YLTvgad7TfJhri51E6K3+Byz/O69Lho/iOlAN6yLxhdCtO6/mG6rnbUpJrulJ5kCPJ7C9gMxHaNF9giSel2weu8Ah5GZ4GBTD2GWsaYjEH0cZrmxSL+FpN5sIh2NL3oqi843awNTS3tpmubS3G8wy81bMxU4HPPe69bgIEDAjTNn4ljW9S/F9iRAmBP85GXg2vNyZIkxLebeJtvGKu1DYMJmhI86nH6P38+Aj94kfNDB6FhN+x6vH6HoN+fjjBoJgI7GKD/zfOreeqX7goOA71ZTcOqpFJ7d8hxBaO/d6fOXP6N9t9XnRsdj2MOHUvb6cwz8+A0GfvQGAz9+k/AhB6LjvaeqlwQIhchuNXRdI4IDMYHHB4Hu++QWQtT7dwrblgFj0jWRLHI7nW8sZGO6jIvscQywdRrG+Qg4itRrlaXLa5jaadEUx3FI35Jl0dIDwJoUtt82TfPoiQKk9tuxivQ3katXjsn2bRrVWIoJHO6GqQfc7ZTWRMJhkz0owcHclSvBwRQFJk2k3wuPUfCz0zYaHNPxCMHtdqbo0t80XLf+/N9S8/TjWIE+XTzTJvOI1REYP5E+f7++YUlw5U23UnNf44Kdwl+eRcFJJ+K7rfQI0xqVl0dwx20JTJ5EYOtJBCZvidW/DE3vec9KgFCI3mdLzNKK1zBL8iLQiz71hMgeb9L5rrsWMDKNc8kW3wDfpbD9pmmah0hdgM43DWhqHnAS2bd0/HlMECJVhwMT0zCOaGkFqdWqHELqS8l7Ko/UmgMNJrUMxI15DvgEc5L9DmAHTIfrjKUBBeJx5k4Yw7qyUlleLHKCCgYpvec2QrvviY5t4K2jLFQoSPVd/6b6rnspP/M8qu+9DytQ1H3Lcj0Pq6SEfg/9G6usHwDxGbOouvZ6ys+/mMib7zbctc8/bia4xWS028o5Pq3Rdc0+2npZQF9qEArRewzHZCr8nOQfZb3jVJgQ2WcV8BWwfye3H53GuWQLjeki2dnMHSmXkD12JPUlmjHMd1Y6Gxmk023ANsDPUhgjhHmMl6RlRqK5zzHLSTujT+KyMl2T6UFcTBZgZ5UBo4C1aZlN6y7GvL+6vDPxxli+JhLOY/q2m0n2YDbyfbTr0pAvoQIopyMNOpqN5fmgfUChbKtjTS7ql776Ptr3UVaT7dPQKKP2kSdw5y8wNfi0RoXD2EOHEJy8Jc64sS3ur/JC9LnlRlbtcQBE4602LlFOkOjHn1D38ZsN11nkoV3PPI+tzbv5Et+mjy/x2Kl//HYbYzShtcYuKSX60Wf4a9aCUlRccS1ezWrAYu2xpxLaeUdwHAgG0NEYSjV5LK6LJoaOt5LYXH9bLIaybGjttVH/eOp7mzR/TDlEAoRC9HzFwC8xSyva0cpKCNGNfqTzAcI+aZxHNmmrdlR7dLYztEi/U0l9pcrNpFarsztcjFm2mMqS/+OAq8meJdQ9yfcpbFucuEiAsHWpvF4VcAbmJFlX+aILx+4Qx40za6tNWde/r3Quziaeh/bqUKEiAuPGYvXvD24cd8EivGWL0R1YBa9jUSCOChRgDxmEVZCPjrv4a9fiV1YAPiqQ32ZGnY7HQUdRwQJUIIAqLMQqKcavqERXVuFHoqAjnegunKz69rup++I9FPVNOjQKC6vPAPJPOJqSa67A6t8vaZvgtpPJP+Yoqh+6H8tOrixgHreLVdqf0GY7YQ8ZDJaFX1mJO2MW7pKl5rEHw8kTqQ96at3QLFi7LvgRVKgQu38ZVnGR6ay8ei0at+UYTSgngLd0OesuOR+FhV00CGfsaPKPPAm0xlu4iMh7H+JHVpvdqxIIBBI71qZbtWPjjBgOKvmnizVgAIFhm6DCheiqavy16xJzBx2vAzzzdwkGUbaF9jXEYonbNMoJm8ebIyRAKETPZWGWZf0BmJDhuQghWpdKDaauqk+aadUpbJt7p2p7pr7AISmO8T1wQxrm0tXWApcDj6YwxjBgTzJUG62HSyXLLYQsMd6QeSlu/3PgGeDdjd0xlymtqQuHmS61B7OIgngUAkEKz/oFBeecQWDcWFR+GO376PUV1L38OhVXX42u3ciqdN9HuzU44yZQcPrJ5O23N87Y0RBwTEfdqioi731E7QOPEHnnrVaDRTpWjT14BIVnnUbo4P1xRgxDBYMQCkE0iq6pJTZtBpEXX6H2kSfx62o63UFZFRRgEU7uTqxBV1RSdfftuLPm0O+Fx7FKipO2y//ZCdQ++pjJlLOsRHCsmsCmm1N4wS8JH3Yw1pBBqEBjd2B/7Tqi739E5Y1/JzblM1SgADwfq7QPpf++HXv4MJNpqSzKz72Q+PezKLrwYvJPOAZ78EAIBiESITblayqvvYno55+YMVrLytM+2qslb/IuFJx9OnmHHog9aCAqZD7CdTSKv3Ydkdffpub+h4l++D7KA2wHHa+h9PYHCO27J8qyUIUFSUMXX3kZRZddDJai9sFHKL/wdygngHajhHbdjfARhxKYPAln+FBUcRG6tg5v6TLi380g8srrRN5812QfBkPkwsI9CRAK0TPtC/wR2CfTExFCbFD2/1LofhLky307kvpy7+tILVjcnZ4Azgd2SWGMI5AAYVeQz5Ou822K24eB/wInkgXLgLtKIG6yB9cOKCUUkezBbKDdGFZhPn3v/xfhow9Puk3ZNqp/GQWnn0xol52IT5/Z9kCei/Y1xb+/lKLfX4TVr2/L+/QpoeDUEyg4+Tgqr7mJiqtvMMtuLZMFqGO1hPbej753/R1ns9bKKBdBfwiPGkH4sIMpOO0k1p56Nu6CBZ0OEraggEAAS/el7v3XqL3/YQovOi/pLqEdt8cePhJ3/gJUMIiOV5F/9LH0ufMW7IH9Wx3W6teX8FGHk7f/Pqw961fUPfkEqBAEHII7bmeyDevH33kH+tz8Z0J77548SHEReYceSGifPaj449VU3XpbIhOzyUe71uh4LYW/+AUlf7kOq6iw5UMMhbCHDKbgjFMoOO0kqm6+nYo/XQWeC2isvn1aBEUbts0Po/JN9qK5j4t2FSXXXEXxHy9pNaPT2WQMoT13o/CCc6l74WXKz7kAb/UaVCDY6j6ySe7kOgoh2mMypgHJW0hwUIhc0Pqvkfbpqd/hskw49x2W4vbfYoJuucIH/pLiGAfQtU0beqtUSqvEEhfRum9I/fkZCrwK/JYemLhSX3twxjab48QlezAraA1+nJKb/twiOAgkNaRwNh1L+Ki2vs402ncp/ectlNx0TXJw0HXRVc2Sly2L4qv+QPEffot2axNLamM4I0bS77H7Ww0O6pqW2YvB3Xam3yP3oQoKwE/za0qBIo+ax59p0ZhDFRZgDx8KePixGvIOPIS+D9/bZnAwaduiQvo9eA95e+2D1rUmoBdp0gjE15TcdE3L4GDTMcJh+txyI4XnnI2OJ3cg9uPVFJx1FqX/vLVFcFBHoi3rCloWRb+/iD7/uAXQaDT++gp0VbV5zpt1qtaRCLqyCl1djV9ZjSZO8aUXU3zF75OCg/66crwVK/Ark//24SMOpfRf/zCB4ea1F7NQTz24EKK3GQL8DfgIOCbDcxFCtI8FbJbC9uXpmkiW2TyFbVenbRais/IwNflS8S9SW36fCS8DU1PYfjjmJJ9Ir1RKrFSQfd2zs8lsUqsZW68A+Csmi/B4ILDhu+cOx3WZM2Es6/qXyvLiLKHjdYR22Y3Cc05Put5bvJT1v7mUVXsdwuqDj6TmP//d4BoPTS2F55xF4bk/T7q+5p77WbX7AazcZnfWnnAa8emzkm4vvvJSQjvuaurT+VFC++/bIsgWm/ota444gZU77s3qfQ+l5v5HaDqZ4C47UnDKiWi3rlPPwQapAN6iRXjLVrS4yR7QH00Mu98ASu/8OyqvMYPRX7WayquvZ82hx7Dm6JOpfeix5GHz8kx2X2KZcRJLoQrM+TF3wSIqr76BdWecQ/Xt/0RXJS8kKPnLdQQ2nYCOmw7EOh4lMG4CfW6+Lul+3uIllJ93ESt33pdVu+5P5bU3opvV/yw89wzyTzoBhWL9r3/Pism7sObok/FrkgOQlVffyPJJ27Ny+72ovOYGgptMMsHBeq7L+kuvYMVm27Bi3Fas3GpHKv98c1KgMXzEIeQdejDaTaX5e/focWdqhOhlCoBzgYswBxdCiNwxEtgqhe0XpmsiWSQItH0KeeMWpGkeovNGAJuksP0a4Nk0zaU7uZjlklunMMYuwCfpmY5ISCVYvZ6eeyImHSLAi8DENI23E/A4MAW4H3geWJ6msbud0pqawnymbzdBgoPZQmtAU3juGUmZX96Klaw+7Fhi336KIgz41L32P+Kz5tDnr9e2HMd1sYsHUXTZb5KurrziOtZfdyWKEOAQ+2EasS+/YcCHr2MPHgSYpa6FF19A9ITP0dozdfiaWf+bP1D3/qtYFBKfEafundexigsJH31Ew32KLrmAmv8+BrF4WhtgKMvCr6jCW70mkTHY5LbiIjQuBScdb+osJvhr17H64KOJfv1R4rH71D77FKVr1lJ08fkN9wtuvw15Bx1E9J3We49FP/iYtcefirtiEaDggXupfeYFyl54AqtPCWCW+Ob/7CTWX/5HlA6BjlF41mlYJSWN86msYs3RpxKd8j6KfEATnfIB7px59H3gn0l/+6ILf0ntU8/iLl6CJmq6HDfL8vNXrCS+8HssioAIzmbjTQZngrdmLdV3/AuvbhWWKsavXkTF5X8ksPmm5B28P/gabIu8PXal7vns/3kjGYRC5CYbOAX4HJM5KMFB0dVqNn4X0UFHYWowdYZH6gXis9HewLgUtk+lY6lIjy3o/OsaTMOClqkLueF/pPZZuV26JiIAkz2YygmHH+neJcZuN+4rXR4i/b8PtgfuwpQaeAQ4mtSWimeE7XqsHlRGRd9iCRBmCe262P0HE9pnz6Trq2+9i9i3n2MF+6GC+ahgIcoqpPq2O4h9/mXLceoihA/7Cc6okQ3XefMXUnn9zZhMPx9NFEWA2I/fUX3bP5O2zztoP5wRYwCv1eBewWknExyxGY0fCYr1v7+CdaeezbpTzKXi8mtNI5N0s210XQX+6jUtb/M8LILkn5i8WK369n8S+fpDFHmYgoY24FNx6f/hzk3+qZp/7E/BtlpkZ+polPUX/xF3xVKsYB+sYAlWoJTIB29S9ee/Jt03fPB+WAWlppZkURnho5KXitfcfR/RKR9hBfuignmoYBgrUEr1w/dT80ByP7HAVlsQnLwV4KEIJjVZaeA45rZgkNby6+yBA+hzy42EJu2EcgJAHI2m/NwLWbXbAeay6wFU3XE3ysn+SiKSQShE7tkX+BPmQFqI7qCA/8MctHdXwfcAppbmM920v+5WCJy30Xu1bSUwJ01zySbn0/nXWByYtdF7ia6WSgYdwCtpmUVm/AhMxzRp6YwtMEdWEk1Ij/MxWcmd9VW6JtJOWwO30X3fsxZQhznR3Nmg/GxM1t+Z6ZpUE/2BkxKXJcDHmCD858APXbC/tHIDDsPnL2HogmUsGT2EQCwX4789jPZwRo/EHjak8TrPI/LWe4ngViPlOPixciLvvE9wxybnbjRg2+QdtF/y2I5Dn9tuSgT8mryFvRj2qNFJd7WKiwhuvSWxhdNx5/7YYpoFZ5xM+NADiX70CZG33if22RfEZ8yi6uF7zdxwUNimo28aswfN49OAYzLpmt9UW4dVMgBnQnJ1HB1zydtxd1SgyblBrbGHDEbHks+xBLaZbLLvdHKWXmzKV8S//Q7LadJBWCkU+dQ+9z+KLv9dQ5agPW4T7IGDiM+bhT12S5yRyXkykTffRTUPcymFwqLupVcpOPPUxusdB2fi5kQ/+4j25c5Z6IpKdDzeGExUisJzz6Dg56cQ/+obYp98TuT9j4lN/Zbo158BrslMtYKoVp7XbJP9MxRC1NscExg8CenKJ7rfcRnab08NEF4CjElh+++AtWmaS7Y4BvhJCtsvIfWumiJ1qdR8iwGfpWsiGaCB9+h8gHA4MIAcXlaZRXYGfr7Re7VN0/3LvccAv+7mfQI8QGpZuzdhMuJL0zKb1g3D1Cc8HqjEBG//B7xDFn/uW75m0hczWTpyCFoplN5AUTvRDTzsMaOSr1m7Dn/tOsy5meYcvJWrkq/SGis/TKBZkMwePpTC889t90zsUSNNwOqZ56k77kjCPzko6XZrgMmMCx91ONp1cWd9T/SDT6l75nmiH3yM9tzkTr7p4vlYhcXYA1o2H/EWL8EZNxarsCDp+pIbrqSEK9s1vFVciNW3tEUdwvjUafhuNVawJOl6ZTv4K1fjLViMtVVimXFRIVafYiBulm43z/rzPVo/VA7iLVqMjsWSsi/toYPbuH9LKhAiPmsGdY88Rf7pJzW7LUBwp+0J7rQ9hRefj792HbGvplL70OPUPv0cOpYbpZVlibEQ2W8opjviZ8DJSHBQ9B7RTE+gixwI/CHFMV5Kx0SyyGbAHSmO8QY99zWTKyxgcArbzwEWpWkumfJ1CtvmY2qTitSUAf8GQimMsRBoubaw56nGdOFOxVzgj2mYS3sVY1bR/B1Tr/Bz4DJSz15Ou3jAZviCJQxduAw3IHk5madR4eQKGMq2wGktOAgKZWr8NR3B91GlfVDNuuV2lD2gzPwjEmHt8aex/jeXEpvaeqxbOQ6BLSdS+Kuz6P/OS5S98DjO2DHoWPp/8mg/hj1yOM64ZuewPQ9v+UpUfjiphl9HqfzWK5D45etp9RBXKXQsltz1GLAGDTA3t7YkeEOB01i8RYdmu7S09X3XaxrYVwq0RflvLqX6H/ck5t06q19f8g7Yl74P/9vUUexbCl72ZxLLJ5UQ2asQOBv4LaZLsRAi9+2PWY6VyoFrFfBqeqaTFTbFZIoOSnGc7K/83PMVYYIznTUfqE3TXDJlLiZQ3Zn3uENqAVZhXn/PkXrjjFeQDsYdcQ+mIczJ3bzfALBD4nI1JrPwKUzzlJZrN7udwvJ9Jk2ZwdJRQ0wMQpIIM0ihK6uSrrH69MEqLqa1yg4aD3vggOQRlELX1KCjycE5XVFJ7ZPP4ldVgdVKAK1JkEkFg0Q++ARl5YHtQCRK5a1/p/ru+wntsC2hffciuMuOBCZNbDWTL+/QA+k3eCCr9zsMXVmdUsCu2QNGE6XglOOTOhQDxGfOxlu+FGvIIBNga7LP2OdfEv3wY3DaaECeeOzKsvDWrEHX1bVYGm31LaXVcxVaQyCAykv+Sq3vSKwjrQRJ26z5qSEYaPF8uStWsqE3pglqNrnddvArKim/4EKqb7+HvP32JrTvngS2nICzyZhWl33nHbgvJVf9kfILLkLZ2R2Cy+7ZCdF7HYdZTjwp0xMRopdK9094C1MP6wZMllAqXqbnNCj5CaYYfaqNlqZhmluIzCoC+qawfa5nD4JZ6l6JqZ/WGQM2fhfRht2Af5Bad3gwnQEeTn06vYoGzsUsMz4kQ3MIYpaW7wxcgTmRdi8Z/m6IBwIMn79UahFmBRt3QbOvGdsmOHkSsa8/I6m/lgawcDYdm3x/y0JXVuEtWExgi8aKGv66csrPuRCfalqGWFw0flKOmqIIFco3HXOVwnKK0JEIdR+8Q90H76DIwx42mOCO21L489PIO+SApBGD20wm78D9qX38MZSdvOR3g3Tif5pmxWnz375XQd6eB1Nw3tktNqt75kX82Hq8BYvxq6qw+vRpfHQ/zmPd7y5CNSv5auLhMTSN+XkaCAwYYxqVNBGYvCWWU2iejyYBNu3FCYwchzOuyd/B9/GXrwICuAsXoSORpICmPXgwrfV80sQIbr1Vi+Yu3oKFbDBA2Dx46XqJ5y9AbO4MYnO/Rf3zLux+A7FHDCe0206Ejzyc0N7JPbLyDj0Q+6qB+OXlrdZ4zBayxFiI7LIH8DrwBBIcFCKTIhu/S7uUYDowvoUpPp9qcFAD/0p1Up2UrrUsBcBBwNOYGlLp6MJ+J6ZJicisEKm9xhekaR6ZtI7UsiCzv8VheqSrO3AA06n4QUw9ulSDg2DqSH6ahnF6mxpMjcBsaDRUiqnZ/Q7wPqbGbcaOey3fZ6svZiRqEEqloIxRNt7CxXiLlyRdnX/aiWDloeONPyN0vIbA6M3I23+fFsPouEv0/Q+TrrNHDid85E8AjeUUYgWLsAKFKGycshH0u/NflD3+NGWPPkm/hx7DGTYMlZ9P2fOP0f+9V+j/7ssMePslQpO2RRFABRy8Jcuoe+ZJVh96LNEPW5ZEtQZ0PGFfRyNoIuh4LToeQbtuIkvPoeDUn1P29ENYzZZP+6vXUHPfQyhVgLdqJfGvvkm6PbTnHgQGjEFhYQUKzcUpQOMR2moX+t31b8qeeIayR5+k8JhT0fGWwbvgDtsS3H57tNukKbqv0dSSf9JxqPzGr0ZvyVL8NWtQhHDnzSc+9buksQrOPQPsMDRtkOK6KJVH/s+S6wbqmlri383AfJW0wffReOB66FgNhRecQ78nHqDfo/+h7PFHKTjyBDTgla8nNnUqlXfcxqp99mvRvRrbhrwQOstrkWZv6FKI3mUipn7LCUjgXohMszBdm5fTetXqjdGYINhoTMOGdJYIeIXMZUOcDmxD5347aMyp+WHAlsCI9E2L74H/pnE80XkFJKVgdFhduiaSQR7ms6OztQRTycDMJYdjgjid6TKsE9sNBcZjyhSk67eTj8n0Fp1TjQnG3Qqck9mpNNgjcfkIuBZTr7ZbuU6AYQuWMmzBchaPHkogR5oV9DTKcfDWLCf6/sfkn3J8w/WhPXal+I+/p/K6G/FjVYDCKi6jz603YJX1azYIEAxQ+9QLFF/1B9ORF8Cy6HP7X/BWryL60cdo4igCOJuOp++//0Foj10bhoi89ibuisUoK4g9ZDCByVs23Fb4m1+x9ozTIa5BBUAH0ERN1lozuqq6w89B0SW/JrzoSJRto/LDWP36YpUUY48YbpbHtqLiqhuIL5mHFSzCj1VR++jThPbdq+F2e+ggSu++lfILf4u3eBngouw88o8+ntLb/oo9tPFncOyTKRCPt0jYU8EgJdddzpojjsWrXov5SPcJH3QEhRckN3+JfvQZ3qplqEA+frya2seeJrjzDg23h/bcjdK/3cj6y6/Cr14L+CgCFF10MaE9dkke670Pic+ejQoE0fHWz1vl7bU7gQfGoyur0XUuVt++5B93VJPHP4Ta554D30U5QZQO4nnlxL+fmzyQ55mgZVc0l0kjCRAKkVmDgAuBX2GWZgkhMk8BJ2Z6Eq2IApdncP/7Jy7Z5kpyv26dMHpK995U1hD2lgzCnRKXbPM0JutMdF4dZrnx18CfgX4bvnu32Q2zSue/mJPySzZ89/TRCmzfZ9IXM1gitQgzRylAUX33fYSPOwoVbMwaK7n2ckK77UL000+xwvnkHXwAgUmtlzJVoSCxud9Qfcc9FF12ccP19rCh9H/zJSKvv0l89lycUSPJO2g/rJLihvv45etZf8kfwfXRVFH71HOUNAkQFpx2Erqqmuq778VfvRqrtJSCs04ntOeuSXPQsRixL6fSVjhHYbXswAyEjz68Pc9Ug5p7H6L6rnuwHBMItex8ap56moJzzyC4w7aN4x55GKE9diX6/sd4a9YS2GJzQrvsmDRW9INPqP7Xv1DFfVtNpA3tsyf9X32RmkceR/seoR22I//kZvUQPY/qfz8IKLM02wpT8+DDFJz1MwKTtmi4W+GFvyS09x5EXn8Lv6aa4FaTCB95WPIOXZfKv94G2gXV5FxVsxqCoX32ZPCML9HRKNX3PUTNv+6n8OLzG7o5h3bbmdI7b6fqhr/irVwLlkd4x/0ouuSCpHHi307HW7MK5aRShrzrSYBQiMwIAWcCl5LeTBohRM/1V+CbTE8iyzyDKckghBCpWov5XSbS4x7gA0zW3tEZnktTp2KChRdhmpl0i7jjMHyBqUW4dPQQHKlFmBEqECb68YdU3XQLxVf8Pum2vAP3Ie/A5CXF8W+mEdhi88aacZaF6W+cR8U1NxDYYgJ5Pzmocfy8EOEjfkL4iJb71jU1rDv9XOIzp6GCheAFqL7r34QPO5jgTtsnBlAUXnAuBeeegY5GUcEgKtQyoFRz/8PEp01DBfJa3NYglkIlB9+n8q+3UXnldSjLaQya2Ta6qpLysy+g7JVnsIc29tWy+vUlfNRhrQ7nLVlK+S8vxI/V4tjNlkZrjY7FUKEQwd12Irhb2+eOqv95H9H33kYFEufSHAe/cj3rTv8FZf97Kmk+gUkT2wzyAlRcdhXR999rGEs5AbzFS/CXr8Aat0nSfVVRIaqoELt/GfF506j59wMU/eZXDbcXnncW+ScegztzNgQcAltvldRh2a+opPLPf0kMlt0ZhLKUUYjudzTwMaZmlgQHhRDt8Rmy7K25ZZgDPJE9Uv3Vm87l+JmUSkvJdNU/FR33a3pGHcxsMguz5PgnmNqO2WI0pvP9b7trh1opVKKjsWQPZpBSKCdM5dV/pvLqGxu64bam+u77WHvKWUkNJZRtJwI8NjoSY+2Jp1P9z3uTm360IvbVN6w57HjqXnzeBAfBdMNdX87aY39G5O33kqcZDGIVFbUaHKx94BHWX/IHsAMb+NbVSRmS7eVXVlH34iusPuCnVFz2J7O0uVlDDRXMJ/bd16w5/DjiU7/d6JiRt99j9f5HEJ85A6Var0JSdcPfib79/gbHqX38adZfdjnYoaQgmwrmE5v6JasP/CnRdzY8BoC3cBHrTv8FlX/7uwmw1g9lWfiV66m4/Fp0XetfxabBSZDKq66j5j//TeqYbJX2IbjrTgR32C45OLi+gvKzfkXsy883HNDNEpJB2D0KgE2Ajb+DRE+2J2Z54H6ZnogQIqesAE5DltE2FQN+TjcuERPtUotZXtjZOoSdqUeXbSxgYArbr0nXRESH/A14NNOT6MFextTQPRT4BaZcRabf7zYmM38Q3RQojDsOI+YvZdj8pSwZPRSnlWYNohtYFviaiquuoe6V1yk45QRCe++O1a8vxOPEp8+i5sFHqX3yGVRBIWuOOMFspxS4Lt6SpSgnaDoa10YoP+9C6p56nvxTTyC0566moYbn41dW4c6YReSV16l96nn86vWoYHJFKRXMw12yhDWHHEP4qMPJP/anBCZPQuWHGzoO6+oadE0t7twfqHnkKSIvvAyWQm2oE64KEp81h5oHH20MXiqFrqrGX7sOLNVwnb+2HF1VhV9RSXzmbOIzZwMuKhBuM9tNBQuJff01q/Y6hPxTTiD/uKNwxo4ywUQNui5CbMqX1D7+DJGXXkO7MVQwP6kRTONgCnf+Qipv/Tt9rriS8DGHm7+FskBrvBUrqb7z31TfeQ/a9ZKCb03nE58xndUHHUX4mCPIP+k4gltMgLxEgDUWIz57LtHX36bmkSfwVi5BBQpaPD4VDFP75NO48xeSf+Kx2GX90PEY3rIVZpivvsGyw+jqOtad+Utq/vMw+ccfRWiPXbEG9jcNXpRC19TirVhJ5LW3qXnoEeLTv2sMDGc5CRB2jwLgJUxNk2uBHzI7HdHNxgOXASezwRZJQgjRQiWmE+OcTE8ky5yPqSUlsktt4tLZAGFnG3tkk1IglaOAntCoJdc8Bvwh05PoBTTmeOglYDtMrd+jyfz7/hJMYP7GLt+TUtiex+DFK1m0yXCQXiWZY9km8+yLKcS++BwVCGOV9UNHovjl6wDPBMhiMepefCFpU+WEG5fcOg5K20TefYfIu+9iFZagSorBdfHXlScaX5imHSrYeolZFQyB71P7+GPUPv4UqqAQq0+JCexpbQJ6nof23MZ5bWSZqgqEiH05lejpzXsFaUwvpqbX+JhGHjYQNAE4tfH4vQqG0dW1VN91F9V33Ytd1hdCIbNkuLIKv7rSjOvkoYKJzDmtUQUFSXUZAVR+GL9iHeW//R0V192EPWKYydb0fdwFi/Er1qCccKvBwabzwfepfexRah97CqukDypRJ1DX1uGXlwMxUKENButUMExsypfEpnxB44Lb+kxBx/y9AKVtoh9/RPTjD1GBMPaA/qapjWXhr1+Pt3Q5OlaT2KZgo89ntpAAYffwMIGhn2FS7O8CbkPOEvd0/YELMAeypRmeixAi91QBx5G5rsXZ6kLg35mehGhVDVBO55sSjErfVDJmJFCSwvYtq8qLrvQyptuuhGq615eJy3XA7sAJwC5kLlj4Z+B74Lmu3lHccRg/bS6zt9qUmsJ8LN/f+EaiyzQNXPkrV5klyIFgsyWsGwnuKNUQ/NORCLqm1ixbte3EWO1oSmFZZj9aQzSKv2xF49JX2za3W8GNBgaT2DaqWcON1rZPqTaIY6Mw8/bXrTfzV5j5Nl2+20CbIF+wWQBSaxQBVLAAXVVN/LvpjfOzOxBgsywT/NMaXV2NrqxKXK/aHfiE5NeFuaKVZ0kpE5RM3M9dtgKWLk3cZnVs3llEahB2n/qwc1/MMtMvMZ1rO3uWXWSvPExQcApwBRIcFKKzevNJrJWYzArJkmtUh1lWfHumJyLaVIVp9NBZYzGrLnLZGEwjss7wMO990T3+AxwLVGd6IhkUJPXaoakoxzQKOQmTVXgYcDcwfUMbdQELUxt8aFfvyLcsiiurGLxoBW4wlXKlIq2UMstjG2oMdpJlQcAxYynV8bGUSh6j6TidmVfTbbuyOYZS4NiN87astj9ZEpmRbbJtVDDUcMHuxPtEKbNdwDGXzv5d2/u8KYUKOI3zDgQal3HnmN588JVpI4F/AGcA12MK5Yrc91PgT5gfOUL0JEsxAZruOrFkYWrv9UYfAWcDszM9kSyyAPOcvJXheYgN8zB1IXfs5PZjMY1K5qZtRt1v6xS2rQUWpmsiok0x4Cqyr/FTDY3fe911ZFmDeT6ywRoalyDnAVsCBwIHANvQ9ScPBmNeF2d38X7wlUXx+iqUJ91KhBDZRQKEmbct8Azm7Nn1wOeZnY7opJ0w2YKHZHoiQnQBjWmS8RXdd9Bi0ftqcUWBW4Gr6X2PfUMeAX4HLM/0RES7fJ/CtnmY79NcDhDuk8K2i5HXeVf7FtOQIhtPNrwPnNKN+1OY7/fKbtxne0UwK3GmYJYhbwIcBByBWYrcejG31J2KKQU1tYvGB0yAcMz3C5i686Su3I0Q2clSqILkeL8KOEh77+wgAcLscTjmi+9BTEetXP5x3JtsijlwPQ1pQCJ6tnJgfaYn0YO9BVwJfJLpiWSRqcA1wPMZnofomCkpbv9T4L9pmEcmbAKkcsQ/k8aSNCK9lgN3YEoU1GR4Lm2JYr5rRUs/YFZe/QOTaXwkpsnJNmneTwg4C1MGqkv5tlT6Er2Q7eCvW0/l1Teiwnnga5RtEZ0yFazOVucQ6dQTA4S5XNMviElrPx7TxOROpBZNtirDNCC5kNSKkWeDQjJbf0bkhp74fZENlgC/wBTKF0YN8GtM5mA0w3MRHTcDs1S2sxk+ewEDyc3fP4eRWmbTF+maiEjyT0wW2rJMT2QjJGLUPj8CN2MCvntjvi8OTuP4RwB/BCrSOGYSz7bpu7qc4fOXsmDcCJy421W7EiKrKNvGX7eOimuvoWnGoCKc6A4sWYSZ1hO/iHpCt8dizHLVjzGd1drXbkd0hyDmb/IZ8H/kfnDQxSylyPYfzUL0VHnArExPIssEMTUvJTiYmxaR2iqIvpjGEbkmAJye4hgSIOwaDvI7pyeKAq9hyvsciDluSoehwK5pGqt1ChzPJRCLo7uycYQQ2ciysIJFWMHihosKBpDgYHboiRkhh2Iy8P4IbJHhuaRqLHAPpmvj9Zg6hSJzfoJ5Xe2c6YmkyUuY19WnmZ6IEFlGY5Yz1bLx7FqN6VQ+opP7KsMsmcqF+qWLgXW07zkJAZt1cj8BTGbI9nRhBofoMlHgQ2CrFMY4D7iP3KrFeRipLS9eROrLs3NJJab5UHuNo/OrhH4OPA6808ntRfZ7A5MkchXmt3qqdgZeScM4bdIoCQ5mG99v7K5b3024q2lt9lvPsjbeNbd+nm3N0ffB12C3MlbTx9hUdz1ekfV6YoDQBx4D/gecC1yM6YiXy3YEXgBeBa5FAjrdbRdMZ+JcOIBvj8+AP2MChEKIlnzgZOCbdtxXY75jPgaGdXJ/BwPHAE93cvvucg3wAO0rSRDEHFzt0cl9jQMuwjRsEbnnJeD8FLbfHPMevDc90+lyNvD7FMd4D3NSorf4GLOUs70uBm7s5L5s4C+YrDDJTO654pjf6+swS5BTsV3q09k4z7G7YzdiI3QsgiaO5RRCKIhSoKMxdKwaZeebQFsShY7Vods8h2UllsxueBGgjkUAFxUqAscGX6PrasxcrHxzXYuNAMdBOTba9cDzW/4qcwKJ293k2+u3tW20bhKUREEkgnZrUHZBy8frefheFRvO8HOwgsUbuY/IBT0xQFivGvgb8BTwG0ywMJfrE4I5iNwXeAi4AZiX2en0eJtgGpCcQc9oQDIPuAm4H/MjSgjRthjtf58swmTj3pXC/q7FNCpZn8IYXS2OKUvQ3vv+HyZjp7OnpH+LOeE3p5Pbi8z5DJMdNiqFMf6A+Q2XC1mkJ2FO5qbif+mYSA7x6dhvkTswS7g7m5m8LaZEzB2d3F50zuaYv3Uq3c076m+YDPTjUxhjDI1dnruEVorh85awYFxnFyCIlGmNjtcRnLwN+aedRHDLiajiQlAKv7yC2v8+Tu3jT4Hngd0YrNNulPDBB5F3ROu5I3rtOmoefIz4nNmoYCvhBw1+vIrQlttS8IufE5g0ERUOgxvHW7yMyBvvUPv40/hVFYntG1+GfryG4nPPJ/+Mk4m8/DoV/3ctKpiXuNFkB/a58WpCe+1G5c23U/PoI1jBQrPbeITCc39JwWknmsBhPUvhr1lH3bMvUvPgI+C64DiJx+piDx1Cn0uuh7y2m4h48xdR+ddbUE5POGTu3XpygLDeIkyA8H7gUuAEcrv2YhDTXesIzI+cO8juA8pcVILJfLgIs/wv162n8bWyOrNTESJndPR74j7gTMxBaGdshml8dG0nt+8OHX1O3geewHSa7IxCzPORykGeyIwKTMDrghTGGIOpx/zbtMyo6wzGnLRNxSLgzTTMJZd0dG1lLabT+xMp7PNPwLOYGqeia+UBvwQuBz7AdB3uTjck9tnZOu6lQD9gTdpm1IxWigHL16BaW+4pup4GHa+l8Lzz6HPj1aiiwhZ3ydt/b8LHHcm6k89E19Y1LsH1YwR33I7Cc3/e5vD5Z53GupPOJPL2W6hgcu8qHa+i4ORTKb3tL1j9+iZvuCOEjzmC/NNPYt2pZ+HOm98YAATAxRkziuA2k/HmLcDE35MfV2DSBAJbb4U9bCjJ52E8AmNGEdyu9ebfeQfvT2ifPVl35i8h7pnH63tYZaUUXvjLNh8rgLdoCZU3/ZWekVPTu/WGAGG97zDLVf6D+YGwd2ank7L+mOVeP8NkhT2EyXgRnRfCPJ+/wyxvy3UxzHLAm0mtYLwQYuNimIy5l+h8V/DfYupk9aT365WY+q1Fndz+WMz3m3R5zj2PYmoJprKG7kLgbUyJlWykgNswTQ1S8Ti5kSmZaU9hsgD37eT2AzEBqw0f6YpUHYH57N868d8HAhMxHc67y3fAdKD1SMjG2ZggZ5fybFlinCk6XkP4p0dSevtfwLbR0Si1/32cyNvvowIOeYccSP7xR2EPHABu82RnhY6aagXunB+ouPYmk3WnNVbfUoouPA9n/Dj63Hojq3Y/AF1V05CBqGO1hPbaj7733YUKBXFnfk/lzbfhzp+HPWQohWefQWiv3QjtsiP9nvwvq/f/CX5FNcpxGvcdjyfGav3QX0cT17suzX+S1m8bm/otNQ89ghXKxx46kNA+exGYuDn5Jx5D9M13qb7/P6hggdnI89E1taj8MOUX/A5/9eqGDMN6/tpylCN9VXuC3hQgrPc2ps7LiZjlKxMyOpvUbQL8GzgbuI7et0QlXQ7FZCqkukQoW7yMybz5PNMTEaIXeQV4ns5nShRjPsd7UsbcXOB2zIm5zlCY5+QdcqthhTAdeT8E9kphDAfzG2cfsnOp+R9JveNyHHg4DXPpDTTms2QPOp+mcibwIGYZvEivLTCBwWOaXR/GvFdO7sa5aExpnc4GCDVSTK3n8jysklJKrr3CBAera1h73GnUvvoC9QG1mv8+Qs39/8VbugJdF4FA68Evf9Vqah5+BHOe2AZixL76lgEfvU5giwkEJk4k+vFHKDsMvo8KhSm57gpUKEjs0yms+elxuKuWoAigcal98mlK/3oDhRedR3DbyRScejKVt9+CojitT4E7bSaVt/4VizzAxR4wnP7vvkJgwmYEtt8G7n8geQOlQGvqHn+G+NoFqGbJuQq7RaakyE25vNQ2FR7mx9hOmGyx5ZmdTlrsgOly/DzdVFi3h9gW85y9RM8IDn4JHI3J2JHgoBDd7wqgJoXtjwEOStNcssXf6Fi30uYmYzLRRG7xgTvTMM5QTOZYvzSMlU6nkZ4mOk8D09IwTm/xOSbA11kBTMOS3noM1BX6Y5rffULL4GC94zGZhN3J3/hdRG+kvSiByZMJbLE5ANV33EPtq89hBUuwrHwUNuBR98YLxGZ8idZe24NZFlZeIZZdhBUoBEL4yxNBRUDl51P/UtRujODWWxPaZUfwfSr+dDXuqqVYwRJUMN80+fAV6y/7P+Lfmq+FvP32RFmh1jsPp8JxEkG9AlSgmPiq+cQ+m2JuC2wgszUQQNHKJZDrrR5Evd6YQdhUFWb55aOYOoW/wNQ8ymVHAAdglpb+FZif0dlkr9E0NiDp8iUE3WA+8HdMHTTJshEic2YAdwOXdHJ7C9Op8z0gkqY5ZVo5piTGf1IY44+YQMrCtMxIdJcXMCeuUj1xOQlzMu9YYEWKY6XDqZgOy6muD4xhfquJjrkG+CmdrxO9OybAe3+6JtRLWcApwFWY39UbYmNqYe9K99XDLklx+86WCxFZzye45UTzT8+j9unnUYTAi+NsOo68g/ZvDMgphb+unNrHnjJZdM05Dnge2ouB7+AMH0nJtZdjFRfhr12HO/cHUPUJzzGcCeNBKbz5C4l98RWWXZA0nHIcdLSayGtvEdhqS1T/MpOZF48lNUrZoPYEE10PjYeO1QEuwU23JrTPnubZWb6KFvF13wfLov+rz5jl1U2eC7+6mvKzLsBdsBAVkBqEua63BwjrLcMEix7CHIQcT25/KYQx9VWOw5y9v4MuLLKbY0oxRdN/TfZlI3TGWkzn1NsS/xZCZN5NmO+RYZ3cfitMxtzf0zajzHsYUwpj505u3xdT4/HMtM1IdIc4plnAM2kYazfgdUyJmJlpGK+zfo15b6ajeNgzwNQ0jNPbLMZkJqfSHOZqzMob+e3UOTtjnsP9O7DNOMyJ7OPo+hNgfTDZ550VBdalZSYiOyU68upoFB2JABbaixDccXv63JL80eItXkLtI0+akHizIGFgqy0YOPWjhq7A1qCB2APK0NEo5Rf8FnfBjw1LbzUaq9DkIvnr16Nb1Dasp/DL15t/6lZWu9c3S2ktEGhbqKKNl30O7rQdfW+7ExUMYQ8aQGjXnbH6lxGf+T01/3kIrGZLqhP7CkzessVY2nVR+eH0ZzmKjJAAYbJpmB+e92MChXtmdjop64c5oDoRk5HyEOBmdEaZ42DO+F8GbJrhuaRDHPgv5u/akxoaCNETrMYst/pnCmNchum2uSAdE8oCcUztsLfo/NK+MzDZ8R+maU6iezyL6dDbkUBCWyYB72JO9D2ZhvE6oj/mO7fttpUdU43JhBOd8w9MY7nNO7n9cMzn7O/SNqPeYSymodZZdO448jDM8cipmCBcVzka05Sms1ZhOmd3Gcv3mbPFJni2jeXJaujupfB+NIvsVDiMVVwMeGCFiH/zHVU3/A0di+JMnEj+MUega9p+KahQiMDE5I8hf/Ua1p70cyJvvYUKNNblUzi4ixYDJpCowmF0RWUrmYE+9qiRiY1Us8CbQldVmzH69ycp008Djo3Vp6Rx2zY4m25C0aabJF0XfeMdys+/BHfB/ERQs8l+bRt8n9UH/BR3yVJUsEkA0fPwFi6W7MEeQupvtO4NTEHsUzBdsHJd/Rm7d+j++h/ZYH/MAcV/6BnBwTcxRd/PRIKDQmSrB4CvUti+P6bbZk/yLqZba2cpTIBG2uTlnt+TvvIXA4AnMCdzR6ZpzI05DHif9AUHwWTAzU7jeL1NNeYkeCp+RWpZZr3RTZiSTKkkmRyL+S5IJYC3IUNI/bXRLe/NuvxQd+xGNKeCxL6air+uHJQi/8Rj0MRQlkPsuxmU//EPlF/1J2r+89/E/dsOtMW//pblm23HstGbsebIE03twbw88DXgJW+rQsQ+/wq/fD32kMEU/PxUfF3d0AEZrdGxapzhYwkf+RMAoq+8iY5WNwQRFQpvnUlutYcORtl5EIuB76O9GCovD3vIYLO/WJy2FkXGv51O+a9+zbpTz2bNoceyYtLOrD70GOJzf2gZHGy63bQZxL//hvi0JpeZ08zj3sDzJHKHBAjb5gOPALtgzpQtzex00mJ34DXgOUxTk55uO8zynTcwS5Ny3ZfAUZgak59keC6i95HT2x0TwQT4UllvcQbmc7snuRpT/7ezdsE8LyK3fIMJiKXT6ZjvwkvpfC26jdke8zviRTqfqdaaqZga2CI1zwBvp7B9GNMlPVvkwvq8l9M0zk8xJ40OTdN49UZjjnNGpDhOtyz9t/xc+JP3PCoQIL5oHjX3mn5HBb88i6Kzf4V269C6GvBRKPL2TvwEs9oOmei6Oty5P+AtWEjt809QdcMtWEWF9H3wHuzhY9DxxtX0ynFwly+i5h5T/rTk+qsoOvcCcGx0vBYdj+CMHUffR+/DHjgAd+6PVN1xd7Plvjbxr78FIDBhM4ov+y3k56FdDxXOo+ii87DKTBWt2DfTWnQbrheb+h0Vd91BzcP/pe6Vl4lPM01RVDDEhj6KrJISrGAfrMIml6LShiXbIvdJgHDjajA/ancGbscsk8r1phY/BT7ALM8YldGZdI3RmLp8H2MCarluIWY51R6YHz1CZEL994XK0CUXvYZprNBZFqbGVk9aszEH812aissxGZYit1yP+V5OpyGYrNIvE/8/mdR/2xZjMpz+hwlApvt3RB3mO706zeP2RhpTuiCVpaqH0nbn3e6mmv07G79rn8R8jqfD5sBLmEDvPqT2XRfCrPx6l9STIDTp/6xqQaFRUrMtYyw7j8obbyby5juogEPpv26n7IVnKP71JRRfcBH9n3iGot9daO5cn+GXNEDiq8a2UaEQys5D2cVU3nwz0Q8/wR42hNK/32DeVQ0NT0BZISpv+AvRt99HhYKU3n0rAz5/l7733kPZU48y8OtPCO22M/6ataw7+3y89WtQTuNbQwXyiH36OdV33ANKUXzd5Qyc8gFl/3uCgV99TPGVlwFQc8/9RD/+GBVoFrZIZPmpcB4WNipYiArmo4J5bQdCVWI7y6Ls1acZ9O2nDPzqw8bLN5/Q98G70bGurBoguovUIGy/xcCFwIN0cU2KbhLCLK04FtPg4h9AZUZnlLpCGhuQDMrwXNKhCtNk5jayo2uj6L0Upp7eejJzYsnCvBe6u+ZYOvwfJuu3YGN3bMOumG6b96ZtRpl3M3AynT9BNQy4AvNZL3JHHWZp4geYhmHpNBKTSXgJ8HliH59iMhfLaTsY52ACgkMw2am7YAIVw9M8v6aupBuCD73I55iazGelMMb1wKuYpIBM2hVTDigTJ8UsTODvl2y4XnkNcCvmRHy6HJW4TMH8Hd7HNCJaT9vNTIKYLsWbAfsCR2JqlKbD7MRcupRn2bgBR4KEmWIH8MsrWHvsqRT/3x8oOP0UwocfQvjwQxru4pevJ/L2e1TfchcoH1STWoFx02BEBRrDKcp20HW1lJ93CWX/e5y8g/Yj/7jjqH38cVQwbO7jOPiV1aw57lRKrr2C/JOPIzh5EsHJiZev1kRee4v1v7+C+LRvsILNfj4mAnXrL7kMXReh8LyzCEzYjMCEzcycKyqpvvs+Kq+8DpTVctmv1uhYHF1VRbs/anyNjkRQwQDOqJHoujp0LN64uTaZhaJnkABhx32d6Qmk2QBMMf1TMZkqjwBeRmfUcTZwEubgYGKG55IOHvAo5ger1CcS2WKbDO//1Qzvv7OmA3djAheddRUmE7GndKNfD1yLqY3bWedi6jz2tO/knm46pkP3Y100voMJsuya+O86YBGmTEwlJlBYhclAzcMsTR6V+O90dCXemIeBv3bDfnqbazABon6d3H4cppzQ1WmbUeeUAXtncP8DaV/E4CHgItJf13v7xAXM+3U+sAwTJFyHCVz2xwQHB2FWDHX2b74hLwCxLhi3ge16rOtfyuLRQ3HivbV/ZKZpVDCErqph/SW/p/r2uwlsPQln2FD82lq8RYuJz/web9myxH0bM/GUk0fto0/hLlyEv2Yd+H5D9p0K5hOfOYtVux2IVVSIrq1DBZKX36pgHn55BeW/upCqv95OYKstsYcMQtfW4s6eS2zKV2jfRTUPDtazHfA81l/6R2ruf5jA1pOw+/XFX7eO6Bdf4/7wPcoOoezkUI9y8qj5z8PUPf8S7ryFWM7Gux0rJ4i3aAlrfnIsOA56fQXeylXo6moTgGx4OnViebLIdRIgFPU2w2RH/gITMExXjZGudjCm43RPqDEIpgHJ1Uh2gRDNxTM9gRTchOkmP6ST2w/FLKP7TdpmlHkPYxot7dLJ7YOY5/VApD5mrnkc0wm1O2q/hYHxiUumfYYJjor0W4zJTL4hhTEuxpwk/yEtM8pN7W0kVAP8AbM0uKsUA1slLt2pFnM81OUsX6OVkgzCTHMclDbdhd2FP6JxMa1AHFBBVCDYMgvPsvGWLaf2iccB22QHNrmPchy8ZcvxtEbZditdirXp+Ksd3IWLcBf8kNivhSKAckIoZyNhGttGWXnEZ39PfPZ3aPzE9qFEk5FWWDbx7+cCHsoKgNOO82KWQtfWEf3kU8zqewtl2SYg2vS1m8hsFLlP/oqiuZ0x9UCeJrs7u03CdDF8hZ4RHPwOOAGzFFGCg0L0LKsxGXOpOA/YNg1zyRYxTC3BVIJ7+wHHpWc6opv9GZNZ21t8j1lCmUqDHrFhd5DaqotisqthSbZ7Dngq05PoAo/QDat3LO0zf9wIvPYEaETXU6ZxiQoWYAVLsILFpi5fwGm7M6/jJOr3hVsfMhBABYOtBAeb3kk1229RohZgO5f+KoUKBlHBoibbt96UpGGTYMDsoyOvPaVQwTxUMGyyBB3HBAPrg5+2LcHBHkT+kqItRwMfAbdg6j1li2GYOX1CzzgwXIZZ1rIrJuAphOiZHgC+TWH7ICao0pO+t98l9c+964A+qU9FZMD5wL8zPYlu8AOmOdzyDM+jp6vB1HxNxXHAQWmYS2+gMbXZf8z0RNKonNSyUNvN0j7r+5bg2bnag00I0VP1pAMNkX4FmBojUzBLCfpkcC7FwO8xnQovovMF/7NFBabj4naYLtnSzVCIni2CWSacigPpGSdGmroK83nYWWNJrb6jyBwPU9bkX5meSBeaBhyO1BPuLs8Ab6ewvcLUf87b2B0FYILeZ9J2I5FccyWm7mGXsnyf6sJCVgwbSCCea2XfhRA9nQQIu4fC1MHJVYMwP5g+w3TT7M7alRam2+VnmHpTA7tx313BwxR33gUTdJWMAiF6j5eB/6U4xrWYzo09xRzgHymOcSGmjq7IPT6ma2q3ZO10sw8xQf1ZmZ5IL+Jj6lKn0vVha0x2q2if9zGB/lyPdD1N6t9F7WJ7HmsHlFLVpxDLk/qDQojsIgHC7lGH+QLNdeMxy+TewdR+6mr7Ypp2PAxs3g3762rvAvtjgqwzMzwXIURmXE5q2RabYMoS9CR/I7WsjSLgL2mai+h+9UGdczDLRHuChzBN1OQkYPf7Arg/xTEuJbvK62S7BzGd5XM1SPgFcDZm2XSXUlrjOQ7f7rAFvrK6Y5dCCNEhEiDsHjXAMZhMuGkZnks67I4J3D1B1zQymYQpEvwmsE8XjN/dpgGnYIKq72Z4LkKIzPqO1JszXAhMSMNcskU5qTcHOAz4SRrmIjLn35ig2veZnkgKqjHvz9PoOcHOXHQtsDaF7cuAa9I0l97iPkwmYSzTE+mgGZgmgeu7Y2fK11QXFbBy2EAcN5VEVyGE6BoSIOw+HvAosBPwG2BpZqeTFscBn2I6x41Mw3jDgb9jlhOfhFmancuWYGpj7YgJeKbSrVMI0XPcCKxIYfsiUu+KnG0exHyfpOImID8NcxGZ8yGmadd9mZ5IJ3yMWflwe6YnIlgM3JziGKcAu6VhLr3JvcCRmN+/ueBtTFOaLq87WC/gucyZOIZYMIDSkj0ohMg+EiDsfrXArZig0a2J/85leZhaLV9gmogUdmKMQkwg7XNM8DSX6zWCyRr4O7BD4v/rMjsdIUSWWYmp65qKo+hZGXMeqdcOm4DUDusJ1gJnAUdgMm6z3RrMktS9Mb+FRHb4B6llowYwJx2C6ZlOr/EK5r3weqYnshF3YhoIdVsw0/J9KouLmD15PLaXq6uxhRA9nQQIM2cpJhi2C6Ywbq4bgPkh9SlwIu3P/jsWkzFwMzC4a6bWrR7H/E0vQWoPCSHa9m/g2xTHuJ7OnZTJVu8Bz6Y4xmXA6NSnIrLAi5jv08vIzu/TOCbzdRdMDcx4ZqcjmqnGdElPxS6YTELRMT9gygX8CliW4bk0NwezpPh8ujlJI+C6zJq8KZUlhVieLCoSQmQnCRBm3reYINn+mIOjXLcFZin1xhqZ7I1J7X+Srqlj2N3exSwtOpHcyHgQQmRWBPhTimNsSc/LmLsSqEph+1JSDwqI7FGDOfm4A6Ym3KLMTgcwc3oYEzw6HZib0dmIDXmK1JsEXoWpSSg6RgN3Yd4nN2NqzWbSKuDPmGXjT3T3zm3Pp7K4kFlbbUogJrUHhRDZSwKE2eMtTEOOU4DpGZ5LOuxFYyOTSU2un4ipx/c2PaMByUwaG5C8k+G5iO5hkdoyeCddE+kghSkJkKs6+rzZKezLpnu+H18GXkpxjCsxHebbQ5HaazeV57S9ZmMOKlPxM+CQDtw/lfdFIIVtU5Hq6zNTn0OdtQTzWt8G0y31Q7o/Y+97TJByO+BU4Mtu3n9bQilsm+ry2Uzuuz084A8pjjEcUze2vStjcnlJcip/z7YsBH4HbIupndvdAfXZwP8B2wOXA6u7ef8AWL7HrMmbUVVSiOVnJHuw6Wd+Lr9Gm+uO3yVCZINu+72Zaz8QezqNCZ69DJyDWaY6IKMzSt1xmAO1uzCP7xdASUZnlB4rgNswj6syw3MR3asO+JrOB1pSaU6RiigmYzlX338rO3j/9ZgAfmd4dN/Soz8BI+j897GN+ZxtT9OSCOa129mAWCpdQTvir5iGXv07ub0CjsecpNpYEMnHdLGMdnJfmcpoq6Hzr2/I0EFyGqwF/pW47AAciKkjNh7TvCedPOBHzOvof5igZDbWjf4eKOjktvNS3PccOv879YcU991en2Jqfh+QwhiTgVG0r5nFfFJ7b2bSbMxv9a4wHxOouwmTIPCTxP+PIb0n5DzM6/p94HnMCp+Mvm+V1kTy8pgzcQyBeMayB1fT+Lrsrvded1hP7r7fhOiIbivXoHQP66C0JNSjVgGMAC7CFOtO9w9f0Tk1mC5tfyc7ljoJIYSFdElvrj7bp2f9yBFt2RzYGhNY3hqT9VVG+wNnEUyzkVXANExQ6RtgKhBL81xFbpLP2fQLYd6vEzEB/4mYgHMpUEzbmW4ac/KnEhMgWok50fM15j37HeY9nRWU1riOwzOnH0ZNcUGPrz+oLUUgFufo+18kv6YO35IFi0Kkw7Domm7Zj2QQZrdFwMXA/Zgsk+MzO51ezcfUsrmOnrEEXAjRc/Tso43OkcBg7zIrcXk08d99MY3PBmCypgdhXhNDMFm3yzDvm7XAOkx2zQpMgFCI1sjnbPpFgc8Sl/sS1+Vjssf7YgKIJSRnGPqYoGA08f+rMSfvhRBCpIEECHPDNEzHrQcw9TN2zehsep+Pgasxy4yEEEIIkd3WJS4zMj0RIUSH1GLqFi7M9ESEEKI3kpzf3PIapvnHzzF1QkTXmoN5rvdBgoNCCCGEEEIIIYTooSRAmHtczJLjHYHLyFzDg55sGXApph7K/Uj9ISGEEEIIIYQQQvRgEiDMXZWYTmA7ALeTnZ31ck0dcAewM/AXoCKz0xFCCCGEEEIIIYToehIgzH2LgQuB3YFnMjyXXPYs5jn8NdKdWAghhBBCCCGEEL2IBAh7jq+BY4BDgA8yPJdc8hFwEHA08FWG5yKEEEIIIYQQQgjR7SRA2PO8imlkchrSyGRD5gJnYp6r1zM7FSGEEEIIIYQQQojMkQBhz6SBhzC19P4PWJPZ6WSVNcAVmCYv/wG8zE5HCCGEEEIIIYQQIrMkQNizrQeuxTQyuRuIZHQ2mRUD7sEEBq8DyjM7HSGEEEIIIYQQQojsIAHC3mE+8EtgF3pnI5NngV2BXwDzMjwXIYQQQgghhBBCiKwiAcLeZSqmkcnBwCcZnkt3+Bg4FNOA5MsMz0UIIYQQQgghhBAiK0mAsHd6DdOc42xMs46eZh4mY3Jf4JUMz0UIIYQQQgghhBAiq0mAsPeKA/diavJdAazK7HTSYjVwJY01F6OZnY4QQgghhBBCCCFE9pMAoSjHNO3YidwNqkVpbEByDbA2s9MRQgghhBBCCCGEyB0SIBT16huZ7A68lOG5dMRLwJ6YBiTzMzwXIYQQQgghhBBCiJwjAULR3BTgMOAI4IsMz2VDPsfM8bDEv4UQQgghhBBCCCFEJ0iAULTlRWA34OfAnAzPpal5wLmYTMcXMzwXIYQQQgghhBBCiJwnAUKxIXHgfmBnTCOTTNb2K8fUF9wR+BdmbkIIIYQQQgghhBAiRRIgFO2xjsZGJv8G3G7ct4cJUu6E6VC8phv3LYQQQgghhBBCCNHjSYBQdMQPwDnArsDz3bC/l4A9yL5lzkIIIYQQQgghhBA9hgQIRWd8ARwJ/JSuaWQyBTgc04Dkky4YXwghhBBCCCGEEEIkSIBQpOIFYE/gPGB+GsZbDJyPyRr8XxrGE0IIIYQQQgghhBAbIQFCkaoI8E9M85BrMc1EOqoCuCkxxp2JMYUQQgghhBBCCCFEN5AAoUiX1cD/AdtjGpnE2rFNDLgvsc1lwPIum50QQgghhBBCCCGEaJUECEW6/YhpZLKxZcKvAvsBZwFzu2FeQgghhBBCCCGEEKIVEiAUXeVzTKORo4Evm1z/DXAscAjwYfdPSwghhBBCCCGEEEI05WR6AqLHexb4APgN5vV2M2Y5shBCCCGEEEIIIYTIAkprnek5CCGEEEIIIYQQQgghMkSWGAshhBBCCCGEEEII0YtJgFAIIYQQQgghhBBCiF5MAoRCCCGEEEIIIYQQQvRiEiAUQgghhBBCCCGEEKIXkwChEEIIIYQQQgghhBC9mAQIhRBCCCGEEEIIIYToxSRAKIQQQgghhBBCCCFELyYBQiGEEEIIIYQQQgghejEJEAohhBBCCCGEEEII0YtJgFAIIYQQQgghhBBCiF5MAoRCCCGEEEIIIYQQQvRiEiAUQgghhBBCCCGEEKIXkwChEEIIIYQQQgghhBC9mAQIhRBCCCGEEEIIIYToxSRAKIQQQgghhBBCCCFELyYBQiGEEEIIIYQQQgghejEJEAohhBBCCCGEEEII0YtJgFAIIYQQQgghhBBCiF5MAoRCCCGEEEIIIYQQQvRiEiAUQgghhBBCCCGEEKIXkwChEEIIIYQQQgghhBC9mAQIhRBCCCGEEEIIIYToxSRAKIQQQgghhBBCCCFEL/b/1orM1DHJUe4AAAAASUVORK5CYII=" bis_size="{&quot;x&quot;:668,&quot;y&quot;:-1,&quot;w&quot;:366,&quot;h&quot;:83,&quot;abs_x&quot;:668,&quot;abs_y&quot;:-1}" bis_id="bn_nr3ja20dvqu887i8pdcqiy">
					</a>
				</div>
			</div>
		</header>

		<main class="main container" id="main" role="main">
			<div class="row mt-30 mb-4" bis_skin_checked="1">
				<div class="col-md-0 pl-4 pb-3" bis_skin_checked="1">
					<img class="float-right" data-savepage-src="https://static.cdc-net.com/sso/theme/attente/left-arrow.png" src="data:image/png;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/4RCyRXhpZgAATU0AKgAAAAgAAodpAAQAAAABAAAIMuocAAcAAAgMAAAAJgAAAAAc6gAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFkAMAAgAAABQAABCAkAQAAgAAABQAABCUkpEAAgAAAAMzNAAAkpIAAgAAAAMzNAAA6hwABwAACAwAAAh0AAAAABzqAAAACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMjAyMTowMToyNiAwOTowMjoyNgAyMDIxOjAxOjI2IDA5OjAyOjI2AAAA/+EJoGh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8APD94cGFja2V0IGJlZ2luPSfvu78nIGlkPSdXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQnPz4NCjx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iPjxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+PHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9InV1aWQ6ZmFmNWJkZDUtYmEzZC0xMWRhLWFkMzEtZDMzZDc1MTgyZjFiIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iPjx4bXA6Q3JlYXRlRGF0ZT4yMDIxLTAxLTI2VDA5OjAyOjI2LjM0MzwveG1wOkNyZWF0ZURhdGU+PC9yZGY6RGVzY3JpcHRpb24+PC9yZGY6UkRGPjwveDp4bXBtZXRhPg0KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8P3hwYWNrZXQgZW5kPSd3Jz8+/9sAQwAHBQUGBQQHBgUGCAcHCAoRCwoJCQoVDxAMERgVGhkYFRgXGx4nIRsdJR0XGCIuIiUoKSssKxogLzMvKjInKisq/9sAQwEHCAgKCQoUCwsUKhwYHCoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioq/8AAEQgAFwAUAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8A+ka5e38faVdeMz4ethJNIFI+0Rjcm8clePQd+maPiE2uJ4RuD4dH73/lsUz5gjxzs9/1xnHNc38G10MaTO1oc6vn/SfMxuCZ42/7P9evauZ1JOsqa06+voevQwlL6lPFVNeiS6Pu/L8z0yiiiuk8gK5iDwFpVp4y/wCEhtfMgk2kmCM7ULnq3HqO3TPNFFS4Rk02tjanXqUlJQlbmVn5o6eiiiqMT//Z">
				</div>
				<div class="col-md-11 pt-1 pb-3" bis_skin_checked="1">
					<a id="lienAccueil" class="d-inline-block font-weight-bold text-primary" href="https://mon-compte.banquedesterritoires.fr/">Revenir
						à la page de connexion</a>
				</div>
			</div>
			<div class="row" bis_skin_checked="1">
				<div class="col-md-1 pr-0" bis_skin_checked="1">
					<img data-savepage-src="https://static.cdc-net.com/sso/theme/attente/red.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAABTCAYAAADDXmT9AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAEgSURBVHhe7duhSgRRFIDho65j0LKL4ESDYLOIdoOCTVBYDCtY9wn0AcToI1gtBsFmtYhJs8kgYvAVdMKNsoZN9z//Vy4n/jB3hrnMzPx0IpHZsqZhMF264Mk3rafr+Lp9LUP95g6v/gm+G8fH+X0Z6te7fHcP4xlMZzBdumDflugMpjOYzmA6g+mmPOJZifnxWfRXy1iBKY941qO5eYjljTJWwD1MZzCdwXQG0xlMZzCdwXQG0xlMZzCdwXQG0xlMZzCdwXQG0xlMZzDV88V2tG2bJ3hreBqb3Zrnkl4bxsluk2kPD+JgdJTrprWwd5wruNvJ2YJ9DvMZTGcwXbrgyV/Evz3G98tnGf6yGM3OfiwNylgB/y6lM5jOYLpkwRG/H48+0NnuHIkAAAAASUVORK5CYII=">
				</div>
				<div class="col-md-11 pl-0" bis_skin_checked="1">
					<h1 class="text-uppercase mb-5 pt-30" style="padding-top: 30px;">
						VOTRE AUTHENTIFICATION FORTE</h1>
				</div>

			</div>

			<div class="row pt-8" style="margin-left: 50px;" bis_skin_checked="1">
				<div class="row" bis_skin_checked="1">
					<div class="col-md-1 pr-0" bis_skin_checked="1">
						<img data-savepage-src="https://static.cdc-net.com/sso/theme/attente/phone.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADsAAABCCAYAAADpCK66AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAJySURBVGhD7doxaBNRGAfwvxKIlEgHg0hrKHawZjFbM5RWh3LgwUlpIKBQEBdbaJAUB2lTSlFs0SFIHOyihUC3InJDJIMUi0Lc6lLaIRAQEYlQoRQLBfuafoMHpXr3Li/03feDx33fyxD+5N57gbtTfwQExGm6BgKH1RWH1VWgwkofPd+rVexQ7b82dHdfoFqe97C7NawsvsCT5TWaaI5EahLjd66jK0wTEryF/fYB+Zl5lGp7NNFcoa4beDibxUAHTXjkYc1uojinLuiBvVoJ83NF8c1yXP+y9rSJQuWvoOEoeq7Gcf4M9X75/QPrXzZQ36VeCCUzePPIgtc72nXYhbsGlr9SIxg5Gw8GfFhQR9lchDG+RI1wMYVnr+4hQa1b0kfP2fZ/B02bBgzDOd7/RGMc6/I5Kvyh4Jxdw9YRy/vdyq/GUElB2Ct0dYrF2htDJek1a069xM0YNb6rYHT0NdWC5JqVDqtUqzeok4TD6kp6zcb7+xGl2n91rK6uUy20eoPKlMuwqPafLf6AFKgWeIP6fxxWVxxWVxxWVxxWVxxWVxxWVxxWVxxWVxxWVxxWV/z4Q1ccVlf8RMBvpdlhx/sUw9M2faKWkrCfPm5TdWi7UqZKLSVht+jaakrCmn0Rqg5F+kyq1OLd+DjFjIHiBjVC9Np9TN6Ko416/+yg+vY5npZq1As9I1gojOAStW65Dvu5cBs5u06dWlHrMZYyvdS55/o27k0NIRGiRqVQAkMp70EPuF+zHWlkx5JwbjnNFkFyLIu0+veNRV4rh/zEIDqb9DKqQ7gTgxN55CzJpILrNXuSBero4bC64rC6ClBYYB9cItfzqlH1+wAAAABJRU5ErkJggg==">
					</div>
					<div class="col-md-10 pl-0" bis_skin_checked="1">
						<h3 class="text-uppercase mb-5" style="margin-bottom: 0px; margin-top: 20px;">Veuillez
							valider la notification reçue sur votre appareil afin de vous
							authentifier</h3>
					</div>

				</div>
			</div>

			<div class="row mt-30 mb-4" style="margin-left: 50px;" bis_skin_checked="1">

				<div class="col-md-11 pt-2" bis_skin_checked="1">
					<a id="lienMDP" class="d-inline-block font-weight-bold text-primary" href="https://mon-compte.banquedesterritoires.fr/#/ext/in8-authent-mfa/password/reset">Vous
						avez oublié votre mot de passe HID Approve ?</a>
				</div>
			</div>
			<div class="row mt-30" style="margin-left: 50px;" bis_skin_checked="1">

				<div class="col-md-11 pt-2" bis_skin_checked="1">
					<a id="lienActivcard" class="d-inline-block font-weight-bold text-primary" href="https://mon-compte.banquedesterritoires.fr/idp/oauth/login/otp/activcard">Vous
						utilisez un autre moyen d'authentification ?</a>
				</div>
			</div>
		</main>


		<div class="footer-wrapper" bis_skin_checked="1">
			<div class="footer-common" bis_skin_checked="1">
				<footer class="footer-copyright" role="contentinfo">
					<p>© Banque des Territoires 2019-2020. Tous droits réservés.</p>
				</footer>
				<div class="footer-logo" bis_skin_checked="1">
					<img alt="Banque des Territoires, Groupe Caisse des dépôts" data-savepage-src="https://static.cdc-net.com/sso/theme/attente/logo-bdt.png" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABQgAAAEmCAYAAAAuiX07AAAKJ2lDQ1BMQ0QgY291bGV1ciBldGFsb25uZQAASImVlmdQ0+kaxc//n0YaLSECUkJvghTp0rugINJtxIQOIYQEsTcWV3AtqIhgRVZEFFxdAVkLYsG2CPa+IIuKel0s2FC5H9h278ydO3tmnnnOnA/nmff99APY6SKZLJtUB3KkCnl0iL8wITFJyOgDASo0oAdXkThf5hcVFQEAf+y/iQDe3QQBANdsRTJZNv6ZNCQp+WKAiAKQK8kX5wBEG4BAsUyuAEgqAJO5CpkCIC0B8OUJiUkAOREAP23URwHgzxn1EgB8eUx0AEAWAiockUieBrCKAAgLxGkKgFUDwF4qyZACrOsAvMXpIgnA5gMYl5OTKwHYvgAs5/ytJ+0/Ouf82SkSpf3pR98CANCKCAgUinOV2SlKuTBFIcrOlUpT/uHf/F/lZCv/uEcA4KTKg6MBWALQQwQCEAghxMiFEtlIgRJyCDEABUTIRi6kkGJAkVKoAICAXNk8eUZaukLoJ5NlpwjDpGK7cUJHewd3ICExSTh65o0ABABCcPGvLK8NcC8BiLS/MpEJcPQxwHv3V2byGuCsA453iZXygtGMCgA0sKAGPnRgABNYwhaOcIEnfBGESYhEDBIxC2KkIwdyzMVCLEMxSrEOm1CJHdiNvTiAQ2jGMZzCOVxCF27gHnrQj+cYxDsMEwTBILgEj9AhDAkzwoZwJNwIbyKIiCCiiUQimUgjpISSWEisIEqJMqKS2EXUET8QR4lTxAWim7hD9BIDxGviE0khOSSf1CfNyfGkG+lHhpMx5Ewyjcwj55NF5Bqygqwm95NN5CnyEnmD7CGfk0MUUNgUAcWIYktxowRQIilJlFSKnLKYUkIpp1RTGiitlA7KNUoP5QXlI5VO5VGFVFuqJzWUGksVU/Ooi6mrqZXUvdQm6hnqNWovdZD6lcal6dFsaB60MFoCLY02l1ZMK6ftoR2hnaXdoPXT3tHpdAHdgu5KD6Un0jPpC+ir6dvojfQ2eje9jz7EYDB0GDYML0YkQ8RQMIoZWxj7GScZVxn9jA8qbBVDFUeVYJUkFanKcpVylX0qJ1SuqjxRGWaqM82YHsxIpoQ5j7mWWcNsZV5h9jOHWRosC5YXK4aVyVrGqmA1sM6y7rPesNlsY7Y7eyo7g72UXcE+yD7P7mV/5GhyrDkBnBkcJWcNp5bTxrnDecPlcs25vtwkroK7hlvHPc19yP2gylO1Uw1TlaguUa1SbVK9qvpSjalmpuanNkttvlq52mG1K2ov1Jnq5uoB6iL1xepV6kfVb6kPafA0HDQiNXI0Vmvs07ig8VSToWmuGaQp0SzS3K15WrOPR+GZ8AJ4Yt4KXg3vLK+fT+db8MP4mfxS/gF+J39QS1NrglacVqFWldZxrR4BRWAuCBNkC9YKDgluCj6N0R/jNyZlzKoxDWOujnmvPVbbVztFu0S7UfuG9icdoU6QTpbOep1mnQe6VF1r3am6c3W3657VfTGWP9ZzrHhsydhDY+/qkXrWetF6C/R2613WG9I30A/Rl+lv0T+t/8JAYOBrkGmw0eCEwYAhz9DbMMNwo+FJw2dCLaGfMFtYITwjHDTSMwo1UhrtMuo0Gja2MI41Xm7caPzAhGXiZpJqstGk3WTQ1NB0sulC03rTu2ZMMzezdLPNZh1m780tzOPNV5o3mz+10LYIs5hvUW9x35Jr6WOZZ1lted2KbuVmlWW1zarLmrR2tk63rrK+YkPauNhk2Gyz6R5HG+c+TjquetwtW46tn22Bbb1tr53ALsJuuV2z3cvxpuOTxq8f3zH+q72zfbZ9jf09B02HSQ7LHVodXjtaO4odqxyvO3Gdgp2WOLU4vZpgMyFlwvYJt515zpOdVzq3O39xcXWRuzS4DLiauia7bnW95cZ3i3Jb7Xbenebu777E/Zj7Rw8XD4XHIY/fPG09szz3eT6daDExZWLNxD4vYy+R1y6vHm+hd7L3Tu8eHyMfkU+1zyNfE1+J7x7fJ35Wfpl++/1e+tv7y/2P+L8P8AhYFNAWSAkMCSwJ7AzSDIoNqgx6GGwcnBZcHzwY4hyyIKQtlBYaHro+9FaYfpg4rC5scJLrpEWTzoRzwqeFV4Y/irCOkEe0TiYnT5q8YfL9KWZTpFOaIxEZFrkh8kGURVRe1E9T6VOjplZNfRztEL0wumMab9rsafumvYvxj1kbcy/WMlYZ2x6nFjcjri7ufXxgfFl8T8L4hEUJlxJ1EzMSW5IYSXFJe5KGpgdN3zS9f4bzjOIZN2dazCyceWGW7qzsWcdnq80WzT6cTEuOT96X/FkUKaoWDc0Jm7N1zqA4QLxZ/FziK9koGUjxSilLeZLqlVqW+jTNK21D2kC6T3p5+ouMgIzKjFeZoZk7Mt9nRWbVZo1kx2c35qjkJOcclWpKs6Rncg1yC3O7ZTayYllPnkfeprxBebh8Tz6RPzO/RcFXyBSXlZbKb5S9Bd4FVQUf5sbNPVyoUSgtvDzPet6qeU/mB8//fgF1gXhB+0KjhcsW9i7yW7RrMbF4zuL2JSZLipb0Lw1ZuncZa1nWsp+X2y8vW/52RfyK1iL9oqVFfd+EfFNfrFosL7610nPljm+p32Z827nKadWWVV9LJCUXS+1Ly0s/rxavvvidw3cV342sSV3TudZl7fZ19HXSdTfX+6zfW6ZRNr+sb8PkDU0bhRtLNr7dNHvThfIJ5Ts2szYrN/dURFS0bDHdsm7L58r0yhtV/lWNW/W2rtr6fptk29XtvtsbdujvKN3xaWfGztu7QnY1VZtXl++m7y7Y/bgmrqbje7fv6/bo7ind86VWWtuzN3rvmTrXurp9evvW1pP1yvqB/TP2dx0IPNDSYNuwq1HQWHoQB5UHn/2Q/MPNQ+GH2g+7HW740ezHrUd4R0qaiKZ5TYPN6c09LYkt3UcnHW1v9Ww98pPdT7XHjI5VHdc6vvYE60TRiZGT808OtcnaXpxKO9XXPrv93umE09fPTD3TeTb87PlzwedOd/h1nDzvdf7YBY8LRy+6XWy+5HKp6bLz5SM/O/98pNOls+mK65WWLveu1u6J3Seu+lw9dS3w2rnrYdcv3Zhyo/tm7M3bt2bc6rktuf30TvadV3cL7g7fW3qfdr/kgfqD8od6D6t/sfqlscel53hvYO/lR9Me3esT9z3/Nf/Xz/1Fj7mPy58YPql76vj02EDwQNez6c/6n8ueD78o/pfGv7a+tHz542++v10eTBjsfyV/NfJ69RudN7VvJ7xtH4oaevgu593w+5IPOh/2fnT72PEp/tOT4bmfGZ8rvlh9af0a/vX+SM7IiEwkFwEAKADI1FTgdS3ATQR4XQBr+iiz/c44xN9o53/4Ua4DALgAtb5A7FIgog3Y3gaYLQU4bUAUgBhfkE5Of87vyk91chzt4sgB2oeRkTf6AKMV+CIfGRneNjLypQag3AHa8kZZEQDo6sBOKwDovPTV6L857d/9cMSvpRSwDQAAAAlwSFlzAAALEwAACxMBAJqcGAAABPdpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQ1IDc5LjE2MzQ5OSwgMjAxOC8wOC8xMy0xNjo0MDoyMiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0RXZ0PSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VFdmVudCMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTkgKE1hY2ludG9zaCkiIHhtcDpDcmVhdGVEYXRlPSIyMDE5LTAxLTA3VDExOjIzOjQzKzAxOjAwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAxOS0wOS0wOVQxNTozNjoyMiswMjowMCIgeG1wOk1ldGFkYXRhRGF0ZT0iMjAxOS0wOS0wOVQxNTozNjoyMiswMjowMCIgZGM6Zm9ybWF0PSJpbWFnZS9wbmciIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6ODU3ZTlmNGEtNzUxNS00MzVmLWIyODQtOTE3NzM1MTRkMGVhIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjg1N2U5ZjRhLTc1MTUtNDM1Zi1iMjg0LTkxNzczNTE0ZDBlYSIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOjg1N2U5ZjRhLTc1MTUtNDM1Zi1iMjg0LTkxNzczNTE0ZDBlYSI+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ODU3ZTlmNGEtNzUxNS00MzVmLWIyODQtOTE3NzM1MTRkMGVhIiBzdEV2dDp3aGVuPSIyMDE5LTAxLTA3VDExOjIzOjQzKzAxOjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5tBwfNAAEJ90lEQVR4nOzddZwU9f/A8dfMxu31HXeklAIqKootioCBjYXdndit2I36tX92gi12o5gIgkEJEtJ9XNfmzO+P953AsgvH3ebxfj4e9/v6m1l2Pre3Ne95h2HbNkoppZRSSimllFJKqc2TmewFKKWUUkoppZRSSimlkkcDhEoppZRSSimllFJKbcY0QKiUUkoppZRSSiml1GZMA4RKKaWUUkoppZRSSm3GNEColFJKKaWUUkoppdRmTAOESimllFJKKaWUUkptxjRAqJRSSimllFJKKaXUZkwDhEoppZRSSimllFJKbcY0QKiUUkoppZRSSiml1GZMA4RKKaWUUkoppZRSSm3GNEColFJKKaWUUkoppdRmTAOESimllFJKKaWUUkptxjRAqJRSSimllFJKKaXUZkwDhEoppZRSSimllFJKbcY0QKiUUkoppZRSSiml1GZMA4RKKaWUUkoppZRSSm3GNEColFJKKaWUUkoppdRmTAOESimllFJKKaWUUkptxjRAqJRSSimllFJKKaXUZkwDhEoppZRSSimllFJKbcY0QKiUUkoppZRSSiml1GZMA4RKKaWUUkoppZRSSm3GNEColFJKKaWUUkoppdRmTAOESimllFJKKaWUUkptxpzJXkCsLckoTvYS1PqOAW5t+O87gY+TuBYVY25/gJk7bs3YIQNw+/zJXo5SSimllFIqCWzTwOUPMPSVT8iqrccyNR9JrWH7q8m7+Rby771tvX3BhYtYtdtAQqXlGK4IYSrLwsjJpuD+O3D26kHdux9S8/zzGO7ste4kRObQIXi/+AY7EIzjb5J4nX2rE3IcfcWqeNoT+BT4ANi54ecj4HOgX/KWpZRSSimllFJKKaUaaYBQxUMP4HngJ+CICPsPA75vuM1WCVyXUkoppZRSSimllAqjAUIVS22B24CJwPmAewO3zWi4zW/AHYDWhiullFJKKaWUUkolgQYIVSxkA8OA35Eeg2024d8WA7c3/NtLAU/MV6eUUkoppZRSSimlotIAoWqpY4AfgSeBri24n27AUw33FaksWSmllFJKKaWUUkrFgQYIVXPthQwb+QDYNYb3uwcy2OTDGN+vUkoppZRSSimllIpAA4RqU/UGXgF+RoaNxMvRwK/Ac8jQE6WUUkoppZRSSikVBxogVE3VEXgAGUByFuBMwDHdwAXAJKRP4ab0NlRKKaWUUkoppZRSTaABQrUxmcjwkAnADUBOEtZQiEw6ngCcB7iSsAallFJKKaWUUkqpVkkDhGpDjgV+QYaHtGQASaz0Al4AfgAOSe5SlFJKKaWUUkoppVoHDRCqSAYBY4HRwC7JXUpEewNfAh8Buyd3KUoppZRSSimllFLpTQOEam3bA6OQ4OB+SV5LUxyFDEt5GtgyyWtRSimllFJKKaWUSksaIFQgU4JHIFODTwWM5C5nk2QAlyBrvxHIS+5ylFJKKaWUUkoppdKLBgiVAVwGXEd6B9c6APcjU5bPRSYgK6WUUkoppZRSSqmN0AChsoFrkYEkk5K8lljYBngRGWRycHKXopRSSimllFJKKZX6NECoAILAh8AA4FJgfnKXExP9gC+Ad4CdkrwWpZRSSimllFJKqZSlAUK1Ni/wf8hk4DuA0qSupuVM4ASkP+GTQPekrkYppZRSSimllFIqBWmAUEVSCtwJ7Am8AASSu5wWywKGAb8BNwH5yV2OUkoppZRSSimlVOrQAKHakH+BC4BBwOfJXUpMtAPuAyYAZ6DPf6WUUkoppZRSSikNkKgm+RU4gtYzyGRb4DXge+DAJK9FKaWUUkoppZRSKqk0QNi6ZCDltPHyIdAfuJjWMchkADAGeBsdZKKUUkoppZRSSqnNlAYIW4/DgXHAeGBoHI/jB55F+hPeD1TE8ViJciKSJfko0DnJa1FKKaWUUkoppZRKKA0Qpr9+wGcNP7sCOwLvA98CA+N43BLgZmBv4HUgFMdjJUIWcCXSn/AaIDupq1FKKaWUUkoppZRKEA0Qpq9ewPPAj0j2YLgDgO+AUUCfOK5jJnAmsC/wRRyPkyhbAA8jmZinAY7kLkcppZRSSimllFIqvjRAmH4KgduQcuLzAdcGbusATm247YNAxziuazwSqDwW+COOx0mUPsBIYCxwcJLXopRSSimllFJKKRU3zmQvQDVZJnAWcC2w1Sb+21zgeuAUpM/eC0B1LBe3lg+Br4GzG47ZNU7HSZQBSHbkG0iQdXpyl6OUUmoDCoAuSD/ZXg3/W9SwfW02sAJYDSwE5jT8/wuBQGKWqpRSSimlVOrQAGF6OBK4FdithffTGXgEOAe4F3gHsFp4n5HUAU8D7wGXA5ey/slZOjGQcuMjkQEtjwHLk7mgVGOZBrZhJHsZzbEbcCjJ7aG5AvgXWETrmA6+IbsA2yHBmUYGUEb6tCg4CejJmvdOBzAJ+CppK2qeg5BhU2s/953Ap8BfSVlR8+Qiz6v+DT89gR7I82pTVSOBwhlI9vgk0uui0EDkgtban+sm8AkwNSkrap4+wDFAcK1tDuAH4OcYHcNALrpuQXy+B8WSiTwv30n2QjYDxwLnhW3zAsOAZYlfjlJKKZVYGiBMbXsAw4EhMb7f7YE3gQuAe5BehfGwCln/68ANSK/CdO7pl4dkRZ4G/A/pARmvTMy0EXQ66LxgGXkV1dRneTCtVD/XWscA4K5kL6JBOTAb+BIJ0vyZ3OXEnBMJsO8eYZ8N7IAEZlLdxcjzZm0VyMCofxK+muY7nvVPhEGeh6keIHQjwcChwIHA1jG638Zg4y7I+7wPmIJkxn8K/B2j48TLYchnVLiVpFeAcHfgzgjb7yO2AcJrkO9D6eAHNECYCNsgFw3D3ZjohSilVOtkQzAYcY/hckGEhBPbXwc4MZwN+20bQiFwNHTLs+11/51TQ1wtoY9eatoKCaidhZwIxcsgJOPgHSSjMF6ZErOBc4HXkIDh4DgdJ1E6IYNMzkYet7dZNyNqs2KZJvkVVWw7ZRYTB+5Khtef7CVtilQqJSxEMrr2BG5BMpgeRUr2W4O9kEnrkRjAicDtiVtOs3kjbCsAnkOGQ0X+1pN6fFG2p9JrIlwn5HlyJrBTAo6XgVyo2wPJ4v8WadHxFan5d4725puKa92QaOuN9YdLfYzvL54ive+o2Iv0HKsh9bNMldqYPYGTG/57GvBSEtcSS3sg58z6Gk0HtpwuO7psEXF3aPFSbG89mMZ/t7cDfjIPPZTg4qUEZ87A9vswsrMxO3bAKq8ETLlf2wbTBMPAWrYcrFZ1au5A4g3vJuJgGiBMLW2By5BShsIEHdNASuaOAF5EAhKL4nSsn5CytuORQOGOcTpOojRmYp6DZGL+mNzlJE/Q6aT3lNnM3GkbvNkezJB+TreQCxmOczDyYXAbMCupK2q509jwYKxTkD6fdYlZTswNQDKSHkz2QlqhjkirivOA9klaQxbSZuJIZCjXo8Bo9KREKaVU6tsFuKLhv7+j9QQIuyGtAVSqs8EKVJNzzvlkX3TuersD02ZQeurZWDW1GC63BAdDfnIuPp/s00/CP3kq5ZdcBrVB6kZ/Qk77dtS9+w7OnluTd/2VlF92DYQscJj4fpkAjnQuWozoHxIUINQpxqnBA1wI/IZkKSQqOLi2HOBKYCJwHfHtGfgeUo53GfELRibSgciH7etIf7XNjmWa5FbV0HvKbAIuve4QYycgZXWnJnshLVAEHL2R2/REMvDS2e3I1WwVGy6kj+0EJKu2ucFBC8lKKwcWI5ljQZqf+d0P+ZL2FbB3M+9DqU2h39eVUi2xdnVAOmVPb0y6ZchvtuxAFVmHH0XhM49ihJUAB6bPYPXRJxD8dw6GKwMsCzvgxb3HHmQeeRir9j2Yqjvux9G2E4Y7i7pPPsD/51/kDhtG1rFHYnu96wYEYxEctCwpY7ZTJhMxYSV6+oUj+Q4Hvkd6c22Z5LWAnICNAMYBpxO/50gd8BTSa+h+oDJOx0kUB/J4/YY8fh2Tu5zECzqc9J4yi9yKGiwz7d9abGR4Qzx/NkVbYBTpUYIbyRE0LbhzerwXEmeZwDNAdrIX0grshXw2Pg50beK/sYEFSM/A+5DWFvsj/S23Anojpcm9Gv7/nZGMwKuQwVo/IUHEphqMZI4/hQTBVevgQ06gU+1HKaWUSju2vxb3TrvR5tVnMdzrdk8LTJ/J6iNPIDhvLkZGLrbfBy4XhsOFXVmJs1cP2o79jHY/fU37Kb9S8PiDGIaB79sfyTppKP6p0yi//CrwB6TEuMUM7GAQHA6MnBwJFG5mNNUnefohGRGHJ3shUWyHZMSdj5xoxWtC5yrgZqRUt3EASFqOw22Qg2RgnowECl8ifUsmN4nlMMlryCKcOHCXdOtFGG4scC3xC5DbSBCpLdAdKbc/AOiykX93B9CGNWUi6aBxWmhTHIoEg9I5s3gXpCT8hmQvJE05kM/GW2haD94gUvL7DTAGGXSzseFRjUHAxcgQkkYG8prcG2mHMRjJbN0QJ1L+PAgJNI5pwppV6rKQbOdUGxKV1h+oSimlNk+234ejqB1tRr6IWbzutdTQ4iWsPvYUgvPnYrglOOjcsjuFTz1C8O+ZlF1/HeXnXornmCEE/55J4J9ZZJ9/Nu7tdybwzyxKDjsOq6IEw5UVcbhJs9Yb8uPo1JGiN17Cte3WVFx3K7UjX8NwbT7X/jVAmHg9kWloZyDlU6luX2Sq6mgkUBivL83TkcfkJeTxOSROx0mUzsATrBlkMjq5y0mMgNNJ76mzmNl3a+qzPDjStxfhamBygo+ZhwQlLkaynqK5HFhG+vS664NMnA0XYv2p5jnIEIqH4r2oOLsKCVjFa0J8a9UNGQLSlEFWK5ABWyORz6VY1IDYyEWrjxp+cpDX5OnIxbwNfWZvj1xIuxX5rFTpayXyPFBKKaVUc1khcBgUPPMYrj7rduGyVpex+rjTCM6ZieHOgVAIs6CA/HtupfLWu7FWrsKRW4z3xx+o/3EM7p12J7RkKaEly7C8dYSWLcNwuDDcsQ3c2SEvGf33JmPAPgBk7NuPmtdfSuvspU2V9nWAaSQfOXGYgJQ9pUNwcG1DkbLjp5FyrXi9Tn5EsoiOA/6K0zESaWfgfWT65aDkLiX+LNMkr7KG3pNnE0zvXoTJ6GxbhTxXDgQuQIKU0dwHHJaIRcXAaax/McpCBvvURLl9uncWdgFPItmeqmn6IQHVjQUHFwM3IaXCVwJ/EL8p8jXAB8AxwD7AG2x4yrOJXBAaBeTGaU0q/tLt+5lSSimVWmywg7XkXX0lWccfs+6uYJCy8y7FP/FXCQ7aNlaoDke7tmQcMIjMww8m58pLaPfLN7T/7Wfc2+9C/q03UjTyRbxff0vw33kYbk9cBpGYjiy8X39L7Quv4f38a2qeeh7D9MT8OKlMA4Tx50ICghOBu0jvPkUe4BIkgynez53RwECkzHNZnI+VCAcgJ7+vAtsmdynxFWhdvQiTwUayqAYSPYvRBP4PaJegNTVXNjK1PNxsJEvw9wj7+iATgdNdb+CBZC8iTRwOfAH02MBtvMDDSN/aB0h8htckJHg9gI233DgV+AwpV1ZKKaWU2qzYgVoy9tqXvDtuWm9f5U13UP/xaAx3XsNtg7i33YHggkXUvvga2Zech3v3Xah+7ClCJavJv/MWyi68jNJTz8X3488yyCQea/YHsEK12LV11L4ykso778c35Q+wAptVL0I9e4+vIcj00ReBrZO8llj4DfmdLmLThyw0RzXwCDIV9H9svK9UqjOBM5FMzHtI72BxVI29CLebkvZZhMk2AxnuES2TthvSpy2VHYb0WAz3HlALvBVhn4EEYlqDc9n49ObN3XHA20DBBm4zFilTvw4p/0ymCcjz+kI2nOXbGEjcUNBTKaWUUqp1CQUx89tQ8NQjGFmZ6+yqe+M9qh95DMOZA4DtryfnvDMoeu91DE8GFcNvZHn3PpQcOpTqV54lOH0GgTlzCZWuwK6qwXDHJziIFcK5ZTfyb7qF9n/8TLtfv6X9hO9p/8N3ZB13PLhdYFsy1Th1JhvHhQYI42M34GPgE2DPJK8lFuYjJ0MDkayIRIfQlwLXII/lqCQcP9baIIGd35FszFbX9TTgbMgirKrBcujbTAssRcobow3tuADpfZaqIgX66pGAEMh7ZKQgy5FAh3gtKg68wNwI201kCu9mN9W8iY5AegjmRNkfBO5G2k78kahFNYENPI8MM/l6A7fbBcmGL07EopRSSimlks0O1ZN73VW4d+27zvbg7LlUXH09BqZMHLZtjKwcXDvtgKNLZ4rfG4mzTUdCvhJyh11Ax19/g4wMqu68D9OZDbE8p7QsbH8dtr8G2+/HDnopGHEXeTddAwGZC2atKsH2+yl6byR5V1+GHahv+EVCWP4aCCYiXyrx9Mw9troDzyBZg0cmdykxUQLcjpR0PQ/4krscZiLN4vdHevqlu+5I8OAXJIum1bBMk9wq6UUYcKV7O7mkW4gE6CN9CnmQjN5U1AvppxjuZ+S1DDJo4vMItykmvTLvQshFjEiB3K5IBvTm1N+4KQ5EhoxEa+xShpSn30bqTnCdAxyF/H2j2QnpY6g9CZVSSinVqtn+Oty7703u1Zeuu8MfoPziqwitWg4ut2wzDAhZlF92Nav22g+zTSFtv/sc15bbUjvqbWpHvkPlzXdi+4MSUIzZGmvB6SD79NMo/uA9Mgb0x8JLYNYcqh5+gtIzLpQlT5nK6iOOx66swiguwsJLxuD9aDfhO3IuuBAjLwfbX9PqMgo1QBgbRchJzETkZD3dO1nWI8NIdkf6JpYmdznr+RGZLHkKMC3Ja4mFvkjJ5RdIRkqr8F8vwkrNIoyBr5BMq0iOIzWHYZwAZEXYPpJ1h0qMIvKQidNIn8+oDOS96Noo+09CprQrsR3wOpGfHyBZ64ORScKpzocEh69GMh4j2RdpNaJXS5RSSinVOlkWON3k33sbRua6pcXVTzyDd+zXGK41pcW2vwbbV4fhyCDwz0xWDTqE0Ooy2v/8PdkXnE3tC6+Az4fhbEbLKps1fQMtCzsQkECeFSTnkotp/8fP5FxxMZlHHU7Bw3fjyCvAWr4Ca8VKgnPmYFVUEvhrGpa/DO8PP2NXVeNoU0zu5RcTWrqcvOuvpP2kH8m/4w4Mj2etjERfw+/nS9u+hely8pWq3EiJ32/AnbSOhuSjkZOZYUjmUqqykf5l+yAn5YuTu5yYOBQJfr5AK+hZaTnWZBEGm/PGrsLdj/TtC9cBKf9PJRnAyRG2L0MC4Wv7iTUZhWvbA9g1xuuKp1wk0P9GlP0P0wpe1zGQiwSJo5Vd/4kEB/9M2Ipi41EkCBwt0/4EUr9nqFJKKaVUs9jBOrJPPB7P4P3W2R6cOZuqex7EcGRJkM7hIOfyS8m97HI8gwdj5GQBBsGalZQefzpmThb4A9ghPzT3HNLlxHC7pRTY4cDZrSsEg5CRSfbpJ1Pzv6dZucc+rBp8FARCFNw7gtCKVdS+9Cq2r46ap1+g/sNPAIOycy7B9vvJv/FWap97mZJjj2bFTntiZLjJuexCjAw3dtCH55BDcPfdCdvvw913J8yiNmkZJNSz9uY7HLgJCVC1Br8i2YIb6qeUihoHmYxCMjguJr1LuZzAeUhp3ZPAE0ipd1oKOJ30njybmX23wZvpwUzDN8kUMhvJJBwaYd8hwIeJXc4G7U/k3oifIKWja/Mjwf67w7a7kCDjpJivLj4aL7hdgwyo6BK2vxgJIg0h/fuotsQjSG++SOYgpeXpesHnLeR5+yqRS8rvQIacfJO4JSmllFJKxVkohJlXRN4t16273bapvOVOQpWrMd25EiAM+Mk8YBC2ZZExaF9cTz2Ef/J0fD+OwyotZfWxp+D78RcMZzMHkgSDmG0KKXzucYJz/iVj/4E4u3el5IAh+P/6C++3P1A76m2wQtSP/Qzf2O9x9uiJmZ2Fa5edCS1eRuXtd+HeoQ/tvvoGIzOT0OIl+P+YTGDGP5iufEK1JdS9/xGZRx2BVVZOxoCBFDz6IHZ1NdbqUjneIUOxQyGMGJZHJ0J6rTY17I70E/qM1hEcnIFkPQwg/YKDa1sJ3ID8Td5J8lpiIR8YjpStX0yalq1bpkludUMWoVuvR8TAu1G270RqXfA5NcK2ENGz695FWhuEOx4ojNWiEmQlcAmRy6YPA65M6GpSy0nA+VH2rUQG8qRrcLDR68hnUSQG0qe4VU6wV0oppdTmyQ7VkXPhOTh7r1ssU//pl9R9/DFmw9RiDAM7FKDq3ocIzpxF5e33YvsC+MaNI+/Gq8jYew/qx34Jhik9CpvD6SS0cimEQmQefTj1b78LwSCFzz9B9sknUP/Bx9i+ejL26k/hvQ/R/rcfaf/rGNr98g3Fo0eRc+n52KEAVmU13q+/xf/7nxh5ueRedQnt//yZDpN/peCWO6l7/W1qXx5J9oXnkDFgH0oOOoza51/Gc+hgvGO+J7BoLoYrlU7Pmib9Vpw8PYHrgLORDIF0txR4DDlZiVS2mK6mISehLyLlXIOSupqW6w78H/K8uxeZjp1Wgg4n202excy+W2sWYctNBGpYf+prDySonAr9QjshGdbhJiPZU5HMBr5DptqurTNSev9mrBaXIJ8h70GRgmF3IEOWpiZyQSmgPdGHeXiRAVR/J245cfUQsBWRBwhtBTxA9ECpUkoppVT6CAZwtO1EzrAL19ls+/1U3T2ioTehie2vB0IYzix8E8fj2mVn2o//ltKTz6Xms3cJzp6Pf9KfmI7clg8lsU2qH3qCvBuvonLEg9SOeg9n187YgSCu7XpT+OJTuHbYjuDcefi++pbqhx8nMGsudlk5wWXLMc0MggsWUPXog4CNgQcjJ5+MnfuSOfRIci48h7wbrqbu7fepmzCR+u8ewzSyybn0AuzaOqoffwbDcJGOMwo1g3DjCoFbkRPbC0j/4GAtUrbaD+mJ1ZqCg2v7FilzPJnWcSK+O9Kw/1PSbJCJ5ViTRRhIw6soKWY5MC/C9iKgXYLXEs2xQEGE7aOIPsShcX8k6Trc43oi91bMBZ5F+jRuTm4net/BO4AxiVtKQlyD9CeO5Bxgvyj7lFJKKaXShm3Vk3XCUBxdO6+zve61N/H9Ph7DlYntryPr2KPJu+1WDE8GhsND7Ysv4f/9L7LPO4Psg4ZQ/9XH2BUV4Gj5+aLh9uAbPw7L5yf3nAsJLpuNo2MHika9QJvXnyO0eCklAw9l+fZ9KL/mGuo/+pzA1MkygOSGq2j7zUe0++FL2n78Ge4+ewE2dq2X+p+/o/TKS1mx7W6UXXAZrt12ofiz9ym4+37y7rwVV98dqX3xVQLzZmK40vOrvgYIo3MA5yKBwbtI/5IgG3gbCQxeQfqXcTVF4+/cHzlZW57c5cTEEchQh+eQrNa0EHA62W7KbHKrdKJxC/mQUsxwBpGDcolmEDmgV4UMQNqQL4ElEbYPALZt4bqSoQK4HCmtDtcPuDGhq0mu3ZHeqpF8jfQlbG3qkAzCmgj7TOA+0v+Co1JKKaU2Z8EgZm4xOZeuWxhhe73UPPEsBk5sy8IsbEPutZfj2ronZttiuU0wQPn5l+M55ECc3bbEwAkORwwXZ1D77EvkXnsZ7T7/iqIP3sD/12RW7rovJUcfQ2jpcvJvGk6Hyb+zxeoFuLbbAbNje3KvuwJH1y4YOVl4DhiEs+dWOLfbnna/jqHtJ5+QffTJ2KEQtW+PYtUu/Sm/6HKyzz2LvFuvx6qspPqJ5zAMdwx/j8TSdJ7IhiAnb2mVqbUBY5Eg54/JXkiSVCOlbe8iE48vADI3+C9SmwP5HY5FskGfZv3BDynFMk1yq6rpPXk2kwbugjvkT/aS0lmkgAOkxuCLfsDOEbZ/zcYvSlQhg1YuC9ueifQ0vLXFq0u8b5Hg1/UR9t3SsH9cQleUeAaSIRgpGFaOXLDaUGZpOpsM3IOUFIfbC8lwfz2RC1IqzRQgWdcdkTYFOcjFXxtYDaxAWmtUIK0KNkcupNqpCBmG1RZoPDMtRy4qrkI+Y6N9f0hHuUA263+21CPVUZH6GiulYsy26sk89GicvbdZZ3v9h5/hnz5VsgcDPlw796Xug0+oevheTGchGCaOth2xampYPeREfOPGYzizY7QoG2wbw52Jd+xYAgsWknnYwaw+7DjqvvwYmyCOzHYUf/0hrt7bEFq0mPqPPwfAWl3K6sOG4v9zCoRCOLpsQWj5CjwH7I+juA0Zu+5M5pBD8f36GyUHHgm2TfVrz+Po2In8+2+n9pU3CMybienKk6nJptnycukE0wDhuvZETtqGJHshMTIZOTFpDUM7YmEJMiDgZSQAfBLp2BhgjWIk8Hs60vPqNWQibEqSicbaizAGor1vp8Jz+TQiry/acJJIt7uU9bPbTwDuR7Ky0s1dwEFA37DtLqQH7D7IRYzWah9kOEskDwGzEriWZHgUOA7YLcK+a5Es95R931YqwYqRjOOByHvmNkhf22ipGBby/jkfeS+ZAPwATKf1XnhwAlsjbXT2RB6jrZAgYaSzUBv57FyEtL34A3mMppBebYY6IhchBwDbAd2QoHF4RKEMCYrORZ4HPwB/IkFkpVQsWTaYbrLPCptNaFnU/N+L8t+GAdgYbhdmXp5ss23sUACzY3syjziEyvvuxnTGoO9gI8MADGy/nDbUPPQEngMGEfhnNrnnX4KRn0vN00/j/eIb6ka+TfUTz2DXVmE4MsCy8E74SbIZMQgumAu48Y75jhXb7Y6jQztyrhyG58D9yDz8EPJuu56a/3uRzBOOwfb7qX3pdQzc2IF6zLwC+V29vuYPXEkCDRCKLZEv6ueQptNiwyxFMuaeI70+/BNlKnAK8AKSlZTuvaB6Ac8jWYV3A58kdzmR/TfReMpsJg7YlQyvL9lLSkcGcgIVzib5mQFtgKMibJ8HfNPE+5iEDGLZK2x748nQZ81eXfLUAhcC3wNZYfv6IAHEqxK9qAS6Isr2WUgGdGvnR/ovfsb6Qfw+yECfDxO9KKVSiAMJCJ4GHAh02YR/ayIDuvo2/JyIfB5ORNpavIMExlqDLYHjkeqRXWn6OZyBBNF6N/wc27B9GvA5MgRsWkxXGluDgTOBg4n8/Sdcu4afPsAxyPf8f5Hvxq8hgVGlVAzYQR+uHXYgY79919nuGzcB328TMJwSVjFMF/4//yL/vtvJmTuPujffwaYWz34DwO3GwBGz4KAd8JLRb2/y77+Dmsf/j7oPPsD74y8Efv+L4k/extGxA2ZRGwJ/TaHi2hsxHG7sUACwsEP1mIXtcHfYGiNbrj3YNTWESlZjla4CQgQXL6TyhtuoLmpDwUP34OqzPYVP/w9Mg/pPvyTw9zRsgmQOPJCCx+6n8u4R1H0wGtMdo+zIBEivfMfYawMMRxqJX0L6BwcrkIzBPZAAoQYHN+x75Mvo6bSOLJbdkCnHnyBX4FNOsCGLMLdSexE2Uxtksm+4KqSEKJmGIJke4d6h6aU+FtGzDU9rzqJSxEQil5mClFQfksC1JNK2rD+ZutEDbD6fUV8CX0XZd2kiF6JUCnEjPWvHIVPsz2bTgoPRGEhm3Qgkc+wxoHsM7jdZ+gIvIb/Lg8jvFosEjz5INc3vyEWKgTG4z1jqh7xvfoO0GWlKcDCaHsiFuEnIQLRtNnxzpVRT2PjJOu5oDM+6IZS6ke9gB+rXBP2cTqxVJVRccR25Vw+j/V/jaP/TOHIuu4C6N98BM4b9+uwgzu5dyBiwN0Vvv4pn8EFYViW1r7+Fa4ftMLKzKDvvUilpNlxYoTrMoiKyzzmX4s8+ocOUX2k/8QfaT2r4+f0nOkz5lbZjPif7rHMwC4qxgjWEVq6g7IJLqX74STDl+m/9x59j2XV49upP0Ydv4Oq7I452bYncjjx1ba5n6BlIttUkJOOqbXKX02IB4FXkS8NNwLKkria9WMiXhcbHLtIAiHQzBPgZ6U3YLclrWYdlmuRV1dB78iyCTk1gboYewBYRts8lueUzJhJoDxdASig3xWikb1K4Q0ix5/MmehAZMBTOATxF6kyhjqWTiXzhbTbwfoLXkkw28GTD/4bbF9gxsctRKukGIxdpX0O+f8VLEZLFPAkJhqVT/+kOSHDzV6TCqSBOx3EDRyNB2pdI/uesGzk3G4tkDcaSCwk2jkeGiKVPzZ9SqSYUwswsIPPwdV+moZLV1H/xNYax7gRfw52J7+dfWDXwUGoe+z/qP/mC0mNPIzh7LoYzlgM9TEKlDacRLicFD96Fw1NI4M/JBBcsouSwodS89Dy214ttWuRedDEdpk+k4IE7sUpWUXHVTaza92BW9NmLFX32YtWAQyi//HqsFasoePQBOkz7jdyLLsFwu7G9dVRcdwOVN90JQPDf+Ri4yL3pGszCAgDs+vRrj7s5BgiPQIZ1PIf07Eh3XyElsmcjJ12qeSqRjJbdkJ5R6Z7ZkoFkxf6OlLe1Se5y1gg4nfSeMluyCNOsaWsKGELk9+3JJLeP2Y5IoCPcz0hJ/6ZYjmRchctHermlKz8wDMn2DNcDyXZpTTKR3pGRPEfyS+ITbQzyfhzOjZQNKrU5KEQuXn5FYgcBFiN9bL8mPQLyJyKZ51eQuKCmAwlETgTOStAxwxUgF4+GE9+qrkLgcWRIVG4cj6NUq2WHArj77IBr553W2e4bM5bQ0oUYrvCgn43hzsKuqaHmpZeofvgR/FOnY7gziJlQCJsg/kmTCM75FwBX3z44t+pFqLKaimHX4v3+OwwcOLt1o+1nH1Dw4N3UPvMSK7bfnbKzLyAwfQbObXuRdeKxZJ9zGu7dd8VatZqycy9lxXa7UffGuxQ8NoK2X3yIa+veQJCqBx6k4obbwOvDzC7CvacU8tmVVfh/mwhY2IH0aYu7OaXw9EU+cIYmeR2x8ifyZWdzysJIhCXA1cBI5GpztBPcdFGMTBA9Fclgeh3J6kqaxonG206ZzcSBu5Dh1f78TeQh+vvXF4lcSAQnErmJ/Khm3t8opE9ouFORTKx0fdJMQwL2j0bYdyZy0rypGZepak+kxDhcJfBegteSCoJItlSk9g9HAnfSeocqKAVyAfZFYKeN3XAtc5D+cYuBhciFBROp/shFst26AD2RCy0bsy+SuXghqfn9OQO5WH3lJvwbPzJ8ZAHSb3FJwzYDeZwKga5ID8NtkGEfG9IOeAV5D7+axE0Dzkfa5AzYyO1KkSDmH0h7oIWsWWM7pA1LH+S8bw+iD7gBaV3SHrn4GOninVIqChsfGQcMhLCWUfUffEZ4wYQdCIBhYDid4HBgOGLfj88K1JI37DJc229L+TXXUnrGORS9+iLObXphZHoIzpxBaPESwCJj3/0oeud1QstXsGLX/vjnSi6Dq10PMvYfgHObrWUSMuDs3QvHll2xvV68v/9I2Y1XUfvaSIo+eIt2v37L6hNOxzt2DNUjHgenA0ebNph5OdjBIBXXDScw5x+Knn2B0OrVVN56J4Yr9TvabQ4Bwu7A9UiGXer/RTZuDnJy+QqQfjmr6eMvJOjxCjLZun9yl9NivZAv5ucgpRvR+mElRNDpZLsps/in79bUZ3kwQzrRuAmORxqMh1uJTOlLljwiB9JLaP7AnB+Af1g/wLQzctLyczPvNxU8jkw1PjTCvv8BvyAneOkuWl/Fb5CT/c3RZ8A9rF8quD2S1fRnohekVIIMRb6DFGzkdiGkFcPnwLdI0KuyCfdfiAQID0beW/fZwG3bIL1xr0FKeFNFAdKDN9rU97WVI4HOz5HPw8U07ZygA/JecwQyVKzrBm57ERJUPBUJysWTiQzb21BwcDzyHPqGpn9GNg5lOZvoAeTByEXJ40jfi49KJZZlYTqz1xtOYpWsxj/xDzDc69zWuWU3bJ8fa+VKMB2xX0/IAtsiOG8BBU+MgGCI1cMuoOzcS2n301dgGNh1tTI85ICDKP7iA7yffU3pWefi2qoH+Vfe+N9abZ+PwNTp69y9YZpk7LU7Gf37ATahJUsoGXwUbV54knbffMrqI46j7qtPMULZMrW43kvltbdQ9cKTFFw7nOwLz6bq3ofADoDljt205jhpzQHCQqT59+Wkf49BkA/nJ5Gpj5H6c6n4+AopDTsFCTTvkNzltNjeSPnmB8B9yBXYhLNMk5yGXoQTB+yCWwOEG1OEZIJG8gZQlrilrGd/Irdr+Jjmn1TUI1lmt0bYdwbpHSC0kVLj31i/6XpHJIB4PJL5ka4M4IAo+zbnib0LkYEMh4dtdwCD0AChap3OAV5gw22NqpDKjVdo3veScqSE/3ekumZvpNf48URODjCRi+0O4JFmHC/WCpH+u/tt5HbzkMfyTZo3nXlFw883yHeK45BBWdG+2x6MfJYfg1z0i5eLiF6xsxSp6HmLTe/0PxO4FylrH9ZwP5FSl4YAtyGVZkqpjbBDIZwdO+Dete862/1/TiG4eMGaLLlQCCMri/YTxhKYOYuS/Y8Ay4ptgMy2MQrycASyqPv8PSouv46MAwZhGh7M7BysklKs5SuxCeLetg9F77+B/8dxrD7uZMDAc8hBuPpsD4Yh62pCZ1K7bgf8v0+h5NCjaffTGIree51g/8H4p/yFVVlBcM5cCMrblaPLFtS+9DpV9zwEuDEy3ClfbtwaA4QuJJhzM7B1ktcSC40DSB5EyixU4oWQL64fIn39rmTjJRqp7ljkCvIrSDnLgkQvIOhwsu2UOfy987b4PBmYVjrHQ+JuBJGDcFXIhYNkOifK9pEtvN+3gGtZv//SMcj7ezxPVuJtHvK7vRph37HAuchJYLraksifv1VIgGxz9iXrBwhBstT/l+C1KBVvZ7Px4OCbyAXLv2N0TAvJxP4F+Xy8FQkARfIw0vf2zRgduzkK2HhwsBpZ61PE7oJgGZK19yaSTXktkBPhdvsg5diHE5/esVsglS2RjEfab8xp4TEqkOztb5DvvdtFuM2NDfsjDRNTSq3NDuDaqQ9mm3Vb3Pu+/wkISbANwDSx/X5qnn+V0JKGxF+jCRG4Jq/DxgpUkn/hFeRcch61r75J9UOPUfPMi2A7yL74HPzTZxBYOh/Tk0ebN1/Gqqhk9clnYmRl4+zajbrRH8Nb72MHAlirS/8rLd4gw8DIy8XIyqb0hDNoP+kHit56lVV77Ueoajm+n34lc8ih1Dz/AhU33IblXY1n4CHk3Xg1hEKsPuYUyXp0xiGbMgZaY4DwC+DAZC8iRj5BroROSPZCFCBfjEYggYsbgPOQfjHpyo304TkIKetIaFmjbRg4g0ENDG7cDUQPwj1NEoK7a+mBZBCGm4x8sW+JmcgX9fAphkVIEO25Ft5/sr2GlMKdGGHfCCSQNiOhK4qdHZDS83CTaV7WS2syHiljC++L1Rf5PPElekFKxclg5DMqWnBwHhKY+iiOa5iE9Pg8DQmwtY9wm+eQC/C/xXEd0TiQIN2GgoO/ItVQ8ar4qEF6oH7dsJY+EW4zoGHfqUSext4Sw4g8SG8yciE7lhUSE5FzxE+QnphrcyAXzPdHWzgptUE2fly777zuRsvGN2ES67zlGwZYFpXDpSDIcMe+9yCE8P8yHse9t5F3y7VkHnUYqwYdiiO/gMwhh1J2+oXY+Mi9djjunXdiVf+DCJUuo/Ch/5F5zBAMTwYg67S93o0HCA1DsgxtsFaXUnLw0ZSecBbtfh1D/r13UnbZhdSOfIfiD9/A2akrgWX/kj/8TvLvGg6GQe3LrxMKlOHwFIMV67fT2GiNAcJIkzTTzTjkamqyBw+oyBYjX2heAW4i/QfftCfyVeO4s2N5Fal1ugH5whrJ1A3sS5QTiVyu8xaxGYbzJusHCEFO9p4n9icqiXYVkjm2Rdj2AqQ31uEkeahQM0U6wYTknICnmllIydyWYds7IoMWYpVFpVQy9UCyyKNN4P0Wuci6MEHrGYWU8L+M9LFdWw7yebIbie9BdyMbnmL+HPI5kYhBIROQ1hBvIMHdcCcjQbsRMTxmLtI2JFwt8vyIR/uU5cBJSK/jzmH7+rGmrFopFYltY+DBvf26bdFDK1cR+nc+huGSDY2lxIYRl8Cg7a8j57xzcfbqQcWNt1F1/yPk3XQNrh22I++W6wnMnEVoZQl1n32Cu9t25A2/nppnXsI77lscWe2puv8Rqh98FLvei5GTje33Q8hqCBhG4XDIpGSvDyMnGyPTA5ZN/fhvqXn6BXKGnU/dm+9QP/57AtNn4Dn6CMxJf5B/twRIg3PnUXXPQxTceBtgUPnAvZju/Jg/Ni3VGgOE9aRvVtc/SCnxKHSaYTr4A+nfcjDStyRdB5kESO9+Z61RLlIOc3mU/eVIGWoyp+65iTxpuAZ4N0bH+BxYBnQK274XMrAk3Xu2LUdaFkSa6jsYya5JdhC4OaIFCKcmdBWpqRYplwsPEHqQoIoGCFW6cwLPEjlbD+QC0jkkPktrBjIA5FXWLzneEbnguyKB6xmE9L2L5jEkOJhIJcjwkjeQdh7h7gB+JHYXe/Zh/c93kAz7ePbI/hd5bNf+7K0HnkH6WCqlorEszKwcnFv3XGdzaMFCgsuWYjhdkoXncGD7vBgOmVzc+G8lA6+FCSKWhUU9Rn4euddfSeDvf6i4+Tr8k/7AM7A/ru17g2lSPeIxQtUlFD78IAT8VA2/g8yDhpB303UE58yl5sXX8QzqT/UjT+E5eH88Bx2AWdQmchahaRKYPZe6l1/Hvedu1H/6MQWPPIxn/wHUvf0+lXfcQ9aJx5J//x14B/1E3ci3cfbqQfZpJxKcNYfakW9R++qruHr1Jv/+O6l58jkMVwaEQmsenxTRGgOE6Wg10iz5/5A+GSq9fI1cDT8duRq8TXKXo9KYGymHup3oTcP9SE+eZH+JHYRMXw3XOHkyFkqRK/kXh213Iq+3dA8QgvR2egkJ+Ia7BXk8k/233lThwS+QXq7aR1dMQ1o7hOuW6IUoFQeXE73Vz5tIX8JkTYstQzLh3kbKV9d2FfAdkpke7/KGLOR7f3irgUaPk/jgYKN6JIDbEbkYt7ZMJHA5kNj8DSNdWPciGZ3xNhr5fD0QeV4+iF7EUmqjbMvCzM/D0X3dryz+qdPBCoDhxGxbRO7Vw6h59mVCy5ZjeSsAG9Odj+F0YAc3dd7QWkIWRm42xY88TtapMtso85ADqX39Neo//IC6D9+izdMv4P3qW7xjx+DeakeyzjmdmieeJVC2BP5yUXnzHdi1deRcPYzsM08Bp5OaF17Brvdi19djRwgQGh4PoaWLyb3hanKGXUDpyWdT8/SzBP7+h9C8+QRXL6L6sf8j/55b8ew9CO/Y73H+O5+CJ0ZQO/JtKu+9HXBQ8Ki0m8657ELce+7G6qNPIrRylQRWU4QGCJOrDngR+ZKwILlLUS0UQq5Kf4RMhLuc9SeUqvSRqLJOA8hHAgMHI1P8dt3A7auBs4BP476yjYtUFgSSAR1Lo5AJh+EnbMch2RfVMT5eMtyItMcIH+yRg2Ti7EtiSsxiIRuZyBmuFu0/2GhelO1dEroKFU1tsheQxroTefo8wBiSGxxsVIu0qRgD7L7W9gKkv20iXIr0HY3kXZIXHGxUgTxGvwAdwvbthXwPiUUQr3eEbfNJTCa1jQw8exLpSaiUago7iKPzFhg563anCs6YJbtDPpy9epAz7AKyThyKVbKa4MLFBOfMxblVd6oeehz/739I9lxzGIBtE5wxi+oHHiW0ejW+sT9hE8I0szAcWTjat8NavgLLX032qSdgOBzUPP0Cnn77kX3maVgrS6gb/RFZJxxDaMVKXNtti+F0Ynu9ZB55GEZO9rr9Ad0u6j/6HCyDnAvOwj9+IjmXXMDqL74BbDJPOBazS0dqX3qdvOHXk3Ppeaw+9TSs8iqM7Cxsy8JAeh3WPvMiwZmzMDweAjNmYtfWY5iaQajkQ+kdZACJXq1qXSqQaWyjkPLAs5ErxSq9DCS+jdNBGmK3AdoCvZpw++lIoCwVpsB2Ag6JsH0BMgUwliYiGXS7h23vjGRbvhHj4yXDaqSv6desHwjdFWlhcEuiF9VMhUQeUFKDZISq6GWM7RK6ChWJgVx4WE78s8g2xEQuIj8CrEriOjbVrUigLdx8UiM42KgSyUL/iXVfd4n4m7clegBwHnKRORX66/6LTDaOdNHveqQ8t7yFx+gYYdsiEtdmaVKCjqNUKxLC2bkTRtgE3sDceYD9Xwlx+bBr8U36lbyrriFj/4HYgXpce+yK7fWB3YK3WtPErq2n6pFHsAmRdfRQcm+4itDCxVTd9yCuXlvj2n5bQqtKcGQWkX3Oafh+Hk9g3t9kFO5N6N8FBBcswLV9b4zMTOxFSwjMmkNGvz0JrVpJaHUZlKz1ddUwsOvrCS5bQOaQw8DtxjdhEu6+O+LeYzessjLw+zDcHoIr5lI/+mMyjx2Cs0N3gisWYtfU4uzaBRsfmfsfgeeIQwj+/Q81r4zEtuoxXTnSqzGFaIAw8X5Aekp9neR1qPiaj5zwv4ic2B+X3OWoTdQJ6cOTCqqQSZAPIic1qeA4ZJpwuPeIfUZfECn/CQ8QgpSKtYYAIUg2y6PA1RH2XY+UQn2f0BU1TwaRy+ZWkZ4DV+Ih2kl1pMCqSiwDyeROBUGkMiFdAoR9iNyXNoR8H1qa2OVs1CxkENgrCT7ueUQOjNlIT9pU+nu/gXzeHx22vQcy0fipFt5/pECofk4olcJsQji2WPctzPYHsFevBpwYLg/+X3/D99M4bKrx/fgL/j8nU/nUI7S5ewR2eQVGS3vumQaGIxNCXty77oxzy25Yy1eAwyTvrlsgK5PQyiV4+g/C0b0bVSMex8wrxNGhPaHSUqyaahzt10qODoVwdN6C+m++xnBlYGRmYrZv91/gziopIbRkCWZhgfy+VVXYPj9Gdhb+ib9hV9di19bi7NSdurdHk3XqCXgGD6J65AsE5y0g+9QTqBrxCGQ4ce++K+4+2+H99nuCCxe0vB9jHKRWuLJ1m4Gk6x+ABgc3J5ORCXWHAeOTuxSVpgxkcnaqDJJxIIG5cEGkr1M8jCZyUGV/YLs4HTMZbiNyVrkTaZ5ekNDVNE8+MmQnXCpkxKSKaIOhIgXd1earltR532+Ki5BhO+FeB75I8Fqa6lUS27IjFwkQRvJBgtfSVHcQOfPzIqJPqW6qSGfGmkmtVEqzMIvX/bpiV1URKisHoyHwZ5oYLhcGmdS/9xG1r7xBwdU3S2bfypUtz5gLhcC28Aw+iODCJVSPeIzKe++j4L67yTz6CILTZ2Jb9WQctB/YNt7vfsTZuTt5d95C5pGH4d55ZwJTpmPX1ILDgaNrZ/zjJwImrr47kn3mKWSffhLZpxyH58CBONoWY2Diny7dDxzdu2HkZhOc/S+Gw0PGvnuTd9ctZB42BO8332HX1OI5aH8MDPx//IWRm0Px26/jH/cbJfsdRsUNt2MWF2FkZGL7Ez2va+M0QBh/i4HrgD2RK3Hp9GVPxc6XSNnq+cDsJK9FpZdcZIDRn0Tv+5dIe7F+43KAX4G/4nTMxUjz+HCZpE62TyzUIr2pIn1b2Ib0nGis1ldG5J6SGkRV6aodkd+Ly4A7E7yWTXU7iSt9HgxsFWG7D7grQWvYVFNYd9pvo+2B/Vp435HaTvRCWogopVKNbWPgxmy3bhzfrq3DrqzCMEzAgEAQQiEy9uyHu/9emHm5+Mb+QOWdD6yZZNxcoRBGbjZt3n2Ntt98RJsXnqD403fptPhfMoceiV1XT2DaDMCJ5+ADCS1egrVyFVg2Jfsfiu/7n8k++1Tyhl9HYNp0HF27YObmknnMENp9/xW2P0DJicdResKZlF1wBatPPgU8GRR/8Qmu7XoTXLiYrBOOxXC5yD77NIref53QylWUHHQkvp/GYbic+H+bRMa++2AYWQQmyjxF10470O7XsXSYMYn2f/xEu/Hf0vbbT/Ds2x+CqdJ9Q2iJcfxUIM3lHyW1ygVU8gSQkuP3kCDAlUgvGqWaoifwGlL6fAWwJEnriJQ9CFIGHM8Ax+tELtU/BRiB9OtqDX5BAoF3RNh3IXKx4eNELmgTGSS3d1s6yAYijavTx02tLZ0u4h9C5MFsLwILE7yWTfUXkqUe7bMtlqJd0PqM1O5J/hzyWRv+HnUCLcsOncH606QLkc/6x1pwv0qpuDEw3Ot2krGqqwmVV2A4TAgFMArzKHrtedz99sD2+8Hnp+r+R6h+/hlMd8u7qRhuD3Z1DYFpf2PkSCaf95sxeL/5gfYTf8D/11Qcee1xbdML3y/jsSpXk3P5RVjLllPwmFxrd/bsIcFK0yTzsIMwCvIBcO+2sww4qa/BuU0PMir3ofCpRwDI6LcnVlU1RqYHZ8+tcO8hcyXde+yGtboUIycb79ff4Rs/kYwDBuHsvhXBhYuwa2vx/fALNc+/QO41V+Ho1BEjOwv3rjuTccAgvL/8imHbKVNurAHC2LORE+UHgWlJXotKTZXAfcBbSP+bs4ncs0slzyIkAJeosVI2EizujPRw25BjgR2QMqWf47yucEXA0AjbS4j/FMDvgblIoHRtvZBS48/ifPxEGgEcBOwdYd8TwARgZUJX1HT1SDZM+HAmzZ5fI4fI7/mJasyvNs4m+QHbdHrNHBlhWz1SwpsOngROJL5B2TbIZ1UkL8bxuLEwHqli2DVs+/7I71XWzPudGGX7DcCHpH5wWanNi22D6cIsKlx/ezAILhd2yE/+rTfi6NaVVfseiFVRjaO4kNxbbiQ4fwHeMd9iuFvQncDhwCoro+zs8zDzijAy3FgVlTi33pKMfffFyPQQWrAAZ9fOGLk5BGbOAmyq73+QzKFDqf/wU6offxpnt+4UPHwPZttijIJ8al95g7q33iRn2KW4++1O2XVXYH8JRfc9jO+X8dS+9hqZhx5O5rFDADDbFFL7wmvUvv0Wedddi3vP3Si/9grAJDjnXwCcPbfC9+13BBcswtVnO3y//Ib3iyNxdO2Mo0M7QkuXEVq8FMPpSpngIGiAMNbGAPcCPyZ7ISotzEd6uLyMDDKJ9AVbJcdTwP9IXAaHjZTLFiElO0cgGRnRJmBvjfQqOgn4KhELbHAE0CHC9i+RqZ/xVINMf480zfd0WleAsB55b5jA+s+BrkhmeqRhAKmgBsnmDF93HvJ6CiV8Rakn2kWAVA36bm6uQb7HJfM7soEEjBclcQ1NVQgMiLD9Z2BmgtfSXBOA34B+cTzGLkSuGpmNTFNOZUHku0Z4gLALcsGyuev/Hnnfax+2vQNyEf1IYHUz71spFQeGYWJ41m03a9fWrXVJzYXnkAOpGn43/pl/YRh5BJfPhwf/R8a+++Ad8yUtbV9qB4PYBAlVNc6+ysAzcBAFTz2EXV1DaMVKnFv3AiA4YyaOTl0pfn8kFVfdxOpjTyTzyCEEZs2m6r5HKHj0frxff0fFFdeRfck5VD/0OP6pf5Az9FQyjx1CzaP/R82zL+M5ZH/Kr7weIysTzyEH4v38a2pfeh33wH6UnnwO2DZtnnyGwNS/8U+WHDFHp46E7BpCCxfjOuwg8m64hqpHHicwbwb+eVMbHjInpiO1ZtRpgDA2/kQywkYneyEqLU1EykaPAG4mvl9QVdMEkEBGIoMZ1Q0/rzT89EZKic8jciZjPjIU5GhkOnoinBll+6sJOv67SE/X8OyrQ4FutK5sg2nArcAjEfadjAy7ei2hK2qaOiL31ytCSmsrErqa1BSpFBNiPwFcNc9U4I9kLyKN7Erk5/S7iV5IC9jIRbd4fv+K1LsXYCzp0SLjGyJfoNuX5gcIy5DvDzdE2NcPCUpeiL4elUot9rodhayS1WttCxKYMg3XjtvDaLBteXvzHHoQoeUraGnuhR0K4d6pDxmD+mO2KSS0YhXer7+l+v+eJPv8M3F074pVXonZTq7HWFU1hFYso/Tkc7HKyjDcmQRmzMauKiPYtu1/67eqq6gbNRpr1SpCgTK8X48lOHsevmkTAAd8YRFauQj/H3/hOeRArJLV+KdNIbhoMaGKFUCA6oefxA4EMdzSRcbIk5l91upSbL+f6sefwa6oJuuIY3DvuRtmTg6BefOpe+Nd7Krqlg9viRENELbMAqSU+FUiN5VXalN8hnwZOgP5srR1cpezWUuFd+iZSBbZm8DTyFX6cPkN+/dBMlLjqQ9yIhBuKjKgJBGmIj36wsu0cpFp4Q8naB2J8igS/Dwwwr6HkSynBYlcUBNUNPx0CdueCXREA4QA3aNsT1ZfUbWujbV5UOvagfXLsWtIfAuMlvoWuIf4ff73jbL9hzgdL9b+RrL5woPB4VmFm+ohpHVKrwj7dkU+5/4HPEP8KxWUUs3hashjMAwM06TqnhG0/eoDnNv0wvf993gOOwyzIJ/Vx5yM4Wjh8PNQgKyTjiP3xqv+22RX11D14KNYZWWYnTpge2v/+1AKLVyMa+ttyb/nVozCfGSISoDKW+/F0akDWBbuXfviaN+BrKFDcHTeAiOzYY2mQU7GRWBZBOcvpGrEIzg6tAfbwrVrX5zdtyLrpOMwCwswsjKxfX68X3yD77dJDQuToKlVWoZdXUPW0CPJOvUk3HuuedsMrSrB99UYguXlYKZGxzENEDZPBTJV9Cn0w0rFVhApOf4YGWRyGdGzTdTm4Sdk8uHLSLAoXMeGfQcT30mMJxP5M+MdpOdcorxJ5D5OpyJNzVtTHzcbuATp/1QUtq8YOWE6jNSafhsEliEB5bV5kOmd6VJyGE/bRdmuAUKVjiJdvFoI/JvohbTQTGAp61/ciAUX0CPCdi+pPZxkbWVIkHBg2PZeyAWgSJnjTVGKXAz9HPmcCJeNZNOfh1RNvIUMlmlNn/VKpZewfnmOjh3BMCUg5vQQmD6N1UeeRO41l5N55JGEVqyk/OKrsMpWYWTkrpeBuGksqh95guD8BTi26AROB4G/JuM5eDAZ+w8kOHMWlr9mTTae00Fw4QKq//fUmm2hEIE/JxP6dz7+Pydje31Yq0rwjv0JZ7cuGPl5mJlZGPkNpb+BAMH5CyAUoOreh6l59iXs2jqCCxbh++FnHFt0wiyWr+mhpctkWAvgaC/TnkMrVmC2KST7vLOouPpGXH22xywqwsj0UPfuBwTmzMBw5rTgMYktDRA2z1WkT+NllZ5KgbuAKcBHyV2KSgErkCvs77H+xD+AQcDlxC+DLovI0xfrSHxrhY+B+1m/l1MfZKhHqvdy2lRzgBuBFyLsOwS5kPBUQle0cbOQgPXaDGBb5CQw1ZjICXwiAt0G0j4gXIj4ZwErFQ9bRdg2jfTrN1qDBAnjESDMjnK/i0i9LPBobGRQWHiAsANyAaslFzjGIn113yB6c7KOyPnXlUi/yK8bfv4GqlpwbKVUUxkGdiiEXVu73vY1QT8bIysP358T8J36C+DAJoTDUYBrmx0IzJ2L4WheCMoO+Mi74Tqyzz0DbAvfz+OpvOlOAiXz8P3yG1knHAOude/b9vpw9tiKzOOPBn/gv+1ZJx2HHQqB3w+miZGRgR0IQCCIbVtg2TLlGMCAjE4d8Rx0gExlDgbl37jd2D4fdjAIIQtcThzduhJaJvljjYFCLJlQXHnn/dR/9xn1331F3tXXk3Xo8WQeMwTfmLGUX3UzBPwpUWasAcLmqUz2AtRmo7mT4VTr40V6AP7A+tlZADch2XyL43Dsg4mc/fA9EgxKpNVI0Pz8sO0O4DRaX4AQ4CXgcKTfZLgHkBKsaYlc0Eb8GWV7S0vR4sENPI88v48j/oNCtiJyQKUGGVagVLrZIsK2uQlfRWzEK0jfFgkShitD3oPSoazdAkoibC9EhlC11IfIBdBn2HCLHQPp57gXcDvyHWQi8tk/DslcjWc1hVKbNzuAVb5uKMRwu6UsNxDADvrJPnEo2DZ2TS2OHt0x83Jx77MXwX8XUH7hpWA6mjm118YOBDByczGys3Bu1R1cLgzAqqgiuGAxRpsCDNP1X8DSLG5D8J9/CPw1dU0Q0/7v/6z9W6xpluFwYLjdcnvbxvY2tZOcIcHBhiBfcNkKWUPbYuzaOgK//wW4MHCRsW8/XNtti11Xh+33YzjBDmzgrhNIA4TNE2lggFLxoM81tbYy4CykD1/4VfY2SEn69XE47mlRto+Mw7GaYhTrBwhBhv0MB1YldjlxZyN/2z2RLIq1ZSMZhAciw3VSwUyk/Cv8O0Y/JBs1VRry5yGDXo5u+P8/QDJ14xkk7Evkk+l5SGm2Uukki/UnlkN6TF+OZOnGb9IsOUQ+59oRCW4lP2Vk4yzke0Y4B9IPORbGIhmKw4GzifzcCrdNw8/pSGBwOvA7MlTlTzQzW6nYMQxg/QxCIzsbMy+3YVhJAGe3LuTdPRxrVQlWTS12VTV2fT2GywVG88NPhstD9f8ep27k2xjZWTg6dyL/jhsJzp1H9aNPg2FgZmVhZuVjNwQAzQ7tCX3/PcHZcyVwZxiYbYsxsjIlsw/ANLBramX9pom1uhT/rGkYOHAUdyBj8H6AsfHSaNPADgQwi9d9q3R03gKcTrBCZB1+NFknH4d3zPdU3no3VnkloaWLMJyelMgeBA0QKqVUuvkTCQhdF2HfGcAIJMsuVnoCB0XYvhgZqpMM45DHYZew7e2AIUjGXWuzBCmvejvCvgFIBuldCV1RdDOQE+1uYdu7IlmEqTC8oBsS4F578M7eSBbLMcQvSBjptQRSMqdUuikgckloumZw1W78Js3SlsjnXFm0joF04S0/WmIFMAzJ7L4CGErTA5Bu5HvBLsAFQDnyXeErpBw5lTLtlUpLNkGs0nUL3IycbMyCfEIrV4HpxPvLeAJDT8M3bgJ2dQ1WXTWGw42jU0cMp2v9sVabwHBnylTgklXk33MbGQP2pnbUO3gOPgBXn+2wKioxcnOxlkv2nqN9O8z8QvKGX4+R29DnryEzcL3fzR8gtHwFdW+9T+6B+5F19OGUD7uWjP574+jaGbOxJ2HIInL7b4P6L74iMOkvub/qGgwMHO3aYmS4yTrjVOo//ARH965kdetK/fsfEVq1AsPdlGshiaMBQqWUSj8PI8HA9mHb2yPlwG/E8FhDkeyHcKNJXruFEFJOHR4gBHlcXkGyHVqbd5ChJGdE2HcTMAYZaJJsNUhWTHiA0EQyHZMdIHQATxJ5Knc/JEh4FJHL6Voin+gBwl9ifCylEiXyWVJ6ite6UyMtJL1MBc5Feg4fj7SAiPSZvyGFwAENP3cjFxffQt7jtYWPUs3iIFSybh6CmZeHWVQE/IPhzML34y9gB8FwYThMDHcm2DbBJUsxnE5a/FbrdELApuysi8HtIKPfXuTdch2hxUtxdOqAo0M7rFWyRlfvbQiuXkzZGRdiFBaAFcLIzsHI9KwfJHSYhOYtBGzavPoMZkEBGf32oOzSC3B23gbD48EwDYzCgobfI4xt45swjtxLhwEQWrYc05mH2b4ddr2XzKMPJzh/Pqv6D8LCh0kGhjO1goOgAUKllEpHq5CBJcMi7Duc2AUIM5CynXBeZHJyMr0B3Mz6mQX9kDLOaH3w0t21wD6s3xPSg/Ru2of4ZcFsii+Qk7pwJwD3ktwMoxBwBzJ9dcsI+/shw3COJrbl6vsA3SNsr0R6iyqVbgJEvhiTSpPVN0W81u1tuO90DZxuTFMbdDXHXCRI+DCwE3AoMphtdyB3E+7Hw5pg4XDgOeBZoCJ2S1Wq9TNw/DeE4z8OE7NDe+TrlS2lxLjWvY1tYxjmf//dvB6EgGVhB4M4e/bAzPRgmyZWZRWrDjiYrBNPouitl3H27IH3m7FYlZW4dtgOw8gk5/KL8Bx8AEZurmQCZrjWe8c3XC6qH3kSq6wcR4f21L32Jlmnnohv3G8UPPaABAYNA1xO7Kpq1nlLNwywQpSdeRHOrXsCNsF5CzCL2uLsuSWBv2eycu/9yDzoIHIuuhicToL/zMb3y/iGHoSpE5ZLnZUopZTaFO8BF7N+n8q9kJKv+hgcYwCwfYTtCxqO25fknPDYyLeQaUD/sH0u4FRab4CwBOlH+BnrZ6XsBNyDlCIn2/dI4Cs8gLstsD/JK09v9CdSjv4ZkYN2/ZAeVscjk6Rj4awo238ifr3PlIqnMiJ/1rgTvZAY2ZSA06YoRfqyujZ2wzS1IgHHCCC9BX9HsgG7IUHCwcBuyOdfU/t2d0eCjmcg2fcfx3itSrViDkILF2MHg+sEtVxb96B+rVMC2+8HAtiEMHAADjIPORjntltT/diTGG7Pph/asjCyMyl84mGyjj7iv4nFdl09tW+8Te3/vURoxUoyBu1L3XtvEpw1B9e22+DYogtVD/6PmhdexczOhsbpwqa5ZmCJw4HhchJcuIg2zz4OgH/iH+Re1x+rtpbS0y7AyJDhJ7bPh10X9tFnGFJ67DDJGNif4KIlBOfPI2PPPTAyM/H/OZnC/z1AzkXnrzNp2T9+EquPPAGrvByaOd051lJjFUoppTbVZKQvXXgZZydkSurfMThGpOxBkOy1X0luNoRN9JOB45ATiIqErSaxvgT+j8gZpFewpt9SMi0EvkVK1MNdRPIDhCCvkcORbMfw1xHICefnDbdpaZCwF5L5EsmHLbxvpZIlRORWE10SvZAY6RCn+60kcoBwJtI7Nl0H0hnI7zUvCcde2PDzPlLtsBVyUXMAcuGwaxPuozfwEfAAklUYisdClWpVDCehpcuwS8sw2rf7b7Orz1r5BFaIrOOOBtPELCzAuU0vMvr3w7VTHwLTZ1D9+P81L4vQtsEysCsqsYNBzLxcCAapH/MF7p12IuPl/6PqtnvxDDkUGxvvmO9x77Ebrm17EZxj0mbUi5htCiEYwqqslCCfaYBhYJdXEvx3HpV33fff1GLD4yFUUYFhgGfoELKOOhwjOyvy2p1Oqkc8jv+vKbj6bEfdW+9jW9VkHDCIwJRpePYfiO31UfvySDxHHoajbTGhZculT6PXB0bqdKLQAKFSSqWnKmAW6wc2MpCyyZYGCDsh/e4iiVA7kFK6Ir0Y30n2QuJoOLAf62d4GsDTyMTj0kQvKszrRA4QHopkn05O5GKimIE8z6MFCXshWYaHI6VuzXUxkXt5rgQ+bcH9ri1aeWRRjO4/UdpF2Z6uZaut3SJkGu/awlsgpIvucbrfMmRgRvhAFz+RB0+pTeNDgq0zkdLhAuQz8Ejku8DGno83Ah2RnocaJFRqAwzTxKquJThvAe61A4TbbSPDNiwLO+jFs98Asi85D6uyCjM3h8o7H6Dm2ZfJvfJinFt2IzR/Ibg28VTC4cCur6P8iqupeugJXDv0JjR/Ib5Zf2C68mj//TdkX3g2ldfdCpj4vv0BbrmOzGOOpPyKKyi/8ArJ/qusxg74IRAEw8DI9EhGpNuNo2MH/H9OJeuUE8g642QCs2ZDRgaBKdOpGD8RR7u22JbVUEZtyzcT08T2+fD/9QfZJ50MgHfM99hAcO48zOJiQstXULL/oQSrV+K6a2scnTsRmr+IUMkyDGdmykwwBg0QKqVUOptL5KEH0U6wN8XRpF9gYW1n0LoDhJXAJchgkvByvh7AQ8A5iV5UmK+RIPY2YdvdSFnXiQlfUWSNQcLPiRwg2BoJIDY3k7A70f8W7xK7qePRypRjOWE0EaK9fy1L6CpUU82OsG0H5GJFOgV1s5EWCPFQD8xHLrytrStyYWJhnI67uapAPn++Ri7MDAHOQ9pbRHMmUip9Y7wXp1RacxhYvioCM/7B3W+PNZu7d8PZvRuBOXMAA9+ESXh//Q3vl1/Q5sXnqH/vQ7AszLtuwmxTSHDe/OaVIZkmhjuL4JKZmJkecq+7HPevv1H72khKTzuHDjP/IPuS8/H++D2+338n+O98so49ksrrh2Nk55B9xskSmLTt/zrDer8cg7W6lKKP3sLZtQv+v6ZgVVTg2mkHQqtKaP/7TxhuN1X3P0LtS69R8Mh9mMVFYFk0FlP5fvgZ308/kXXqCdheH74ffsHAwL3zjpjFbSg5+Cis+jryLruOzEMHU3nr3QRL5mO628TgjxJbqROqVEoptamiTVltaR8lk8iTctPJICT7qzX7CQkERnI2UmqdTD6kFDqSo5GhHaliBhIAnB9lfy8kSBge7GyKG1i/FyNAHfBUM+4vmmgBtK1ieIxEiPa6jfVUaRUb0yNs6076Pe+2pWllqc0RInIGciHNe09RTVeDTC4+AJlOP2MDt70OODARi1IqfRlAiMDkaetsNQvycW7dC+wghjuLundHU//2+1hlq6l++HHavPYcbb//gsC0mQSm/Y3Rgn57tt+Hs2038m65luzzz6LNK8/gGTQQ/4IZ1Dz3MlnHHUXWiScTqllF7ah3MDu0w3PkEVi15Vg1tdh1dRg52ZhtizDz87B99eTdfiOODu3xT56Me9e+mG0kcOcZvB9GdjY4HOTfPRznVltS//lX1L35HnVvjabu7dHUvTMa7/ff4+67MxkD9sb79bcE5v9Nxi79yb3uCmpfeA3f35PI2HcghU+MwHPoYHIuOR9Hmy0aejWmFg0QKqVU+or2qdLSrI09gF1beB/JlgWcluxFJMC9wIQo+x4DtkjcUiIahZQghnMjfZ9SqZJhBnAE0YOEPZH+j3tE2R/J3kTPHhxJ5Oyr5lpO5PK47UifHmdOpC9YuACaQZiqpiJ96NaWh/SCSyf7Ed/zoqlRtmtAKnE+QS4eRqsuMIHbSa3PJaVSjoEb/19T1tuese/e/DfY3rIbsv3y8P06ntVDTqBkv0OovP5Wsk4+HjsUaNax7WAAZ/dutBv/A1lnngK2jf/nXwlMldh/zZPPYdd7yb/zZhwF7al7bRR2fT15N1xJcMZsqh96nNpX3qD6kSepvvdhqh58jMCU6fgnTKDksKGUnngq5ZdeDSH5OuUb+yOrDz+GslPPpe6d0dheH9aqEsketEJgQOD3v/BO/Jmcyy4Ew6D2pVHYQP5dw+X/f/E1APwTJlD/7odg22SfczrtJ/yIo3Mn7GDzHot40TdApZRKX+2jbPe18H5PJ/Lnw1RgfJR9yRJCyraOiLDveCQIFYuJzqmqHrgU+JH1e9xtATxB5D6AiVKGZDk+GWFff2Qi86MJXdGGzWBN/8qdI+zfEulJeCTRA7ONMoBHiDzRtQZ4uPnLjGg+EiTsHLa9e8PPvzE+Xjz0JHJQezXwT4LXoppmGjKkYuuw7ccDryR+Oc1iIK/pePqZ/wra1nEQcAsSBFfxV4JcPLSAkyPs7w8MBL5L5KKUSieG4SIwYxbBhYtwdluTeJ0xaB8MV1ZDcLDhrc62sAlgVVXh7r8necNvwMzOpv79j2UYyCb23jMapgVXP/QYhEIE5s4lMGky7j12JWvHEwn+M5vA5Km4++1BztnnUPno/dS9/jbZF55N9lln4vtlPLmXXYjZrlgyAwHfmLFUjLiPzD32I+/mW6i69R6CV1yCc+ueVN58J2anDrj77UHpyWfj3LI7ecOvxcjLw66swqqoJLRkCW7fzmSddiKBydOo/+JTMvc5AM/hBxFasAhnrx4UHHk4wTlzKb/4Kqqf/D8yBg3ALC7GcDo3eVZLvKXSSZ5SSqlNEx4IaLSqBffZhugnStcB37TgvuMlDxnKEv549EayQr5I+IoS60/gfiSbMNyxwIVI4/ZkeQU4n/UHGYBM8BwLrH8pOnnmIAHnT4FdIuxvi2SibCxIOBzYK8q+J2jZ0JNISpG1h78OspCT3nQIEO5F5GEu04HqBK9FNY0f6YUaHiDs37Atllmy8bIrku0bT9OQxyK8pHh7YHfg1zgfX60RRC6s7Y5clAh3OBogVCo6pwOrvAT/+EnrBAhdO2yPa5tt8U+fhuH2SJ8/LHLOPZ/cYRcSKiun5n9PY1sWZnERwYWLMDZ1OIfDRWjZcqqfewq7oWii+NU3yD7zFAJTpuMb9wuOrbYEIOeKi6gdOZLKex8k84RjKBhxFyt27EfZFVfi3mZ7cLsxc7IxPB4yBx4Ktk3No09heesx8vMAMDIz8f08Dqu0nIx9pTNO9SNPyRRj2yYwcxahsqW0++JL6VN470PYoXpyb7xK1ut24TlkfzyHHoyjU0fq3niX1aedSP0v32KSgWFmgtNNKrXs1QChUkqlJw/SCD5cEFjSgvsdQuTA4z9IlloqqgI+AoZF2Hc6rT9ACJKldwCRm7DfhwThmjNgIxZqkT58X0bYl4MEEPdDBq+kimVIAPBjIpfbt23YdxSRg4QHIb9zJP8QvXdkS/2EPJbhjgJei9MxY+nYKNt/Tugq1Kb6GAm4rC0XKa9Ph6EPlxH/Mnwv8h4YHiB0IgM0NECYWOVIG45IfWD7I+XGViIXpFTaMKQPoW/sj2SdtKZIxcjKJGPwIPzT/wQ8WIEacs4+l4JHH6D8gmHUvT0aSZZ2YmTlyCTgSHnVG2SDYeAs6ozn4AMxsrOoH/0JNU89h//3v7CoJuvDLyj+4E2c3bqSd/VVlN18DVV33E/B4w9S+PwTlB5zKllnnoJn/4HgdEAw1JDJaFP/9mjqPvoMu7aW0MpVuHboDQYUPHI/RnYWVmWVBD5Nk9DCxZRffCW551yE59DBeL/8ltr3R5F56LFkHn4wVnkFpSedQ/3PX+HM7oBzm54Qssjc73BwOvD/MRm7uppUCg6CBgiVUipdRWuoXk7zA0EG0fv2vU3LS5fj6U3gYtY/yTsMeZwi9cFrTQLA5cAvQEHYvjbAM0jpbKQedYnwFfA6kYff7Aw8S+Ryr2RaigTWPiFyJmE7JDByNFJ632hrJOjpivBvgsCVyJTNeBgL3Mr6vdQOQjJlYp21GEvbEDnAbQE/JHYpahP9iGR5hl+0OhsJwLTkolW89QFOSNCx3kde/+GOQzLA0yHLtzX5GrnAmBe2vRsy1VqzlpWKKgPvdz9g19ZhZGf9tzXzyMOpfvz/GrIHQ7i2703tcy9T8/ZrOBwF2KEQNvXkXXsTgUl/Uv/VVxiuzE06sh0K4OjaRbL0giFWHXgEdl0dmYcOxtGpI7VvvU35sGsofOFJci6/kNo33qHqySfwHH4wmUMOJX/EXZRfcznO4u7gcmJX16wpicbAyMul9LgzwOHArqoiVLKakoOOxsjKxKqoAMPEqq7BsirI3H0gBU8+hFVZSflV12Fm5FNw/+1gGFTdcR/1P39F7jmX4OyxJf5fJ+IfP5Hcm67BvdMOVN09gto338BwZ8fqjxITGiBUSqn0dDiSRRhuCs0PPvQhcmN5P/BuM+8zUSYBvwN7hm3PQ06+/pfwFSXe30jWWqRy4gOAq4lf5lpTXIuUkIaXIgKcBKwArkroijZuKRvOJGyHlCKfCXwOFCP9CztFub+HkZPSePkNyVDcLmx7NnABcH0cj91SFyDrDDeDjfd7VMnlB55HSufX1g64Dfnbpqo7iPxZGg8TkIsJ/cK25wI3A+cmaB1KLEH6toYHCDOR93INECoVheF0Elq0EN/Pv+I5ZM2sJfdeu+HeaUf8f/0lw0x+/Y38e2/H/X/PY5VV4BlwEBkHDCRjrz0wCwup/3LTi3wMVwaBqdNZuXN/cDrIPuc08m6/GUf7dhAK4fv1N+o/+5z8lbfh6LIFbZ59nJX7H0zZeRfSbuzX5F49DGvFSqofeZK8e27FvUtfGTjSyLKxg0EJcjqdGA4HWBa2bWO4XIQWLKL8ymvI2Go3it59HSMrk7JTL8M/azJtHn4S1059CM6dR+2rb2DgwNlzK/JuugYA37gJlB53BlZ5KYbDieFKreAgaIBQKaXSUQbRs63GtOB+TyLyQIXvgZktuN9ECCKBmfAAIchj9QTrT9psjZ5HysQjDW25E+mr9GdCV7RGCdIP8SvkORzuSqR/5v0JXFNTLEWyBD8mciZhEfLcG4Y81/pGuZ9vkOy+ePI1rOXOCPvOBZ4GFsZ5Dc2xFZJtFsnb6ACHdDAK6VPbJWz7OcjfcGzCV7RxJxO9rD0eQkhZa3iAEOQiw2tIm4BU0xt5by5N9kJizEv0IGA8J1orlf5ME8tfQ/37H60TIDQ8HrJOGorvr98wnbnUffQZ7t13peid1wktX0Fo0RLqP/yUqjvux7XzThjuHLAtNnlSh8OBHQhg5hWSMXAAwRn/UP/+R9Q88xK+mb+TdcgxhFatwtFlC9z996LwsUcovfR8Sk88g7ZffED+iLsx27Wl6t4HMdweDI8HDAPb74fG4CCsWZfLJSXRlkVoxUrce+1G0aiXcXTtTNUd91Pz5kvknno+uddItyOzuJjc66+k6rZ7qLz5ZoIzZ5M55BCMrGycPbfE98sScGVu+u+dABogVEqp9HMG0tg8nB+ZsNocOcCJUfa90cz7TLTRSLZKQdj23ZAG9Kl44hUPlyC/c4ew7ZnA/yFZoskKlv4A3ET0jM77kL9ftP59ybIEKTeOFiTMZsMTW2chgZJEPO6vIZmYBWHb2wD3IH05U83dQGGE7eVIabpKfeXACNafWO5AWhwMAFYmelEbsBUyZTzRPgL+YP2MZAfSaqEfqdWPNQfJkg4i05ZHx/j+2yJZnHNJ/ER7D5GHIhmkWlMwpVKQYXio/2oM+SWrMdsW/7c988RjqXrwf9gVVRimScVNt+LcaivwBwguWYCNFwMXOeedibdTB2rfGInhzt3047tc2BWVlJ50KmBiU0fmoMPIO/9yAtOmsWrAoeTdeBV5t95AziXnYZVXUj78WkoOP5ai998k99rLcfXdkcprbsI7dQIOVxuyTj4OR5fOGBluMEwIBrFD0m/R++u3mK4Ccq+6jPx7bgOXk6p7RlB+581kHz6UwuceAyD473xKTzkLu95Hxv6DIBCgZuQr1Ix8ETAxjKyGsuLUfJvRqyNKKZVeOiBfpiP5FinHa44DkROmcMuQ0sl0sIjoU5aj9VZsjRYTPcC2J5LlU5e45aznUSI3hm90PfAykctNk2kJUm68qRmYS4HjG/43ERYij18kpxG5D2QynQ2cEmXfi8jzWaWHl4C/ImzfGnlORurLmQz5SMZjx7DtpcT/jM0P3B5lX2+SO3E+kruAHkiP0PeBD5HgZizSXk5ELtxdAlxE4kq9G7Vr+AlXQ2oFs5VKSYbTRWjpAuo/XXcGnbNbV7KOPhLLqgPTxHB7CM6bR2DJP4BBxp6DKHpjFI4tu5F59BDMNu0h1MwW2YaJXF+Rt273wP4UPv847cZ9S9Erz1Bx221U3y/XgvJuuYY2Dz6K749fWTXoILyff4PnwEG0n/wrxa+8jmfwIAJTpuMfP5HAjH8Izv0X3/iJeL/8BtvnJ/f8YbSf+BP5D96F5fVSftGVlN96A5n9D6TNyBcxsrMILV/BqgGDMQvyKf70PdqO+Zicay8DgpiuAgxcUrKcosFB0AChUkqlEwdSIhitv1l45samiBY0+Bgoa8H9Jlq0Sa3HIJkKm4vXgZFR9t2M9LBMpquAtzaw/2xk4ue2iVlOkzX2JIwUBIlkCfJYT4vbiiJ7GCkJjORJYPcErmVD9gQej7JvJZtH79DWpB64gsgl4YchmYTxnha8MW6kFUN4me904IUEreFzpOw6khNJnTYLJ7N+X9ijkV6nh7bgfrdGqh3eZs17/NbIoLFE2gvJrA73L8m9iKZUejAMwEHtyyPBWnfod/al52Fm5EEohB0K4O6zIznnDaPovTdp/+t3OHv2YOXee+KfPJWsE4Zih7zNW0PIh+eQgyl64zWKXnyNmqeepfzSa8A0yTzhGIrfepPaV9+kbtQ7WBWVZJ11KrkXX0Vg4SxKjjiO8guvJDh/IdlnnU7x56Mp/vQdci45D2fnLQBw7dCb3KuH0fabjyh8/klcffvgHTOWkn0HU/Xc47i33IGCh+4DbILzF1J20tm4996LNiNfwtmtC3Uj36bi8hsofORx2k/4joJHRmBkZWI3NyCaABogVEqp9PEg0fslfUbzhx90Bw6JsN0mfcqLG/1A5CnOxUiJ6ObkeiJPD80CdkzwWsIFkSDghoKE+yL9L1Mt+7MxSDi5CbcbjAwOSrTlRO93mIdkAiX7OdAXGX4Ura7oFmRwjUovPxN9GNK5SBltsloc5SIXTiJNLb4GCQwlqiHUNUTPKr4RmWqcTAcjf6tI5tD0iySRdCHyRapbWX/AUjxFC0j+Riqn9yiVQgynB9/Eifh+GrfOdvcuffEcehBWqA7DsrHq6yl89AEMG1YfeRwYBsWj3iL7jFOwa2qAtfr+NZVtg23g3Kobzp5bYjid2F4vzm5d/ruvrJOGkn3O6aw+/Qwqb7mL2udfwcj04NlpH4zMTKqef5wVO+xJ2dkXU//ZV5htCskcehT5D91Dm1efpeCR+8g65QSMrEzqP/iEkoOOZtVBg/FPmY5n533IOuk4/FOn4/txHFX3jMA/eRrF747C0U5yEvzTZxBcOB8zvwDb68PMzwNnqiTTR6Y9CJVSKj08hJxQRFKL9HVr7hfak5H+dOH+QL4op5M6JPhxU4R9pyMli5uLFUjZVnP7UsabjzWDKaIN3emAnNAfjZw8psqwnCXIIJjPiD6UxAN0RqYKJ8MLSNZWpMB4V+ALJHM4GcMjBgOvEj0b+kOil0mr1HcH8ro4LMK+85C/+/lIC4tE6YE8pwZE2Pcq0p4ikVPUlyF9ST8jcun1zUB7ZHhTTeKWBUhLhBdYf7ovyPv2RchFiOb6EfgF6B+2vRAZsnQE8R+mdCIwKMq+VP3MVCr1mCb4a6l55iUyBu27zq684dfj/XoM+AIE586i6s4HsL1e6r78lOxLLsLIyaXipuF4P/oSR4fuWKtLAaPpl2kMA5wuav7veWqffwU7WEPuTbeQe/2V/92k/pMvqX1lJG1Hv0vGvvtgFheDAbY/QHDuv3i/HEPdO6OpffUNal59FkdeJ1x9d5ShJdiAge31Epg+A6uiAlfvbSm48148hx2Ma6cdZHAJYFVW4e63J0Z2NpW330v+XbcAUPDgXVgrV1F63hmYzkLsoA/DmdFQZpyaNINQKaVSW1fkZPnaDdzmVqQ8qjncRA/OvEN6Tv59CzmJCbc3sHOC15Jsn5N6Pa3W1hgk/L+N3G4oMB4ZshHeNyxZliJZMNEyaYqQ126kidKJYCNTo6MFKLdAnh+3kLgLxi5gODL0IFpwcCaybs3gSV8B5HU9Ocr+w5Bs74MTtJ7jkGzkSMHBP5GyaEj8edE3wNUb2H8u0ls40tTjeHAjwd23kT6NkVyPBPhaIoh8b4n0Gt8B+AQJ6MbLbkTvgzuJzWegmVIxYTiyqP/kM/yT/lhnu3vXvmSdcByWVYfhcFPzzAtkDNiHDhMn4ezSmYph11L7wdvgdFL88dtkn3cmVmDTq/sNtwc7GMJR3JmcC87G9vnw/zmZ8ouvYvVRx+Po3InAtBmUDDmBVXsNpH70JxhuF67ttiX3mstoP/EHOsyYRJunniej/974fvqZum8+ov6bj6n/5lMMp5P8e26j/cQf6TBtAnm33Yh7t50xXC6Cc/6l/MIrKDvtPEqPOgFH+3bUPPsypSedTWDa39g+H4VPP4q7Z1/soB/D5ZGgagpL7dUppdTmKw8pf/kFyZ6KZiTwWAuOMwDoE2F7BfBeC+43maYDEyJsd5J65aqJcB3Jy2JrCh9wKZIhu6GAdD4SzPoDmXbcO/5LIwMJAr5E5Mnhy5AAYLQgYQ4SsE5UICTcSiRTJlqmlgcJuv4EHBTntRyMlJ/ejTyukSxByj9L4rwWFX+rkJYY/0bZ3wvpM/o88QsG7QC8iXyWdYmwfy5wElAVp+M3xVPAnRvYvycSJLwXaZURL4ORwN/tRD8/fAR4IkbH+4Hok993BL4jekuVljgcyRCM9lg+CKRuczClUpHDge2tofp/68fd84Zfh7OoE7ZtY9d7KT3jAiouv56SwUcSWDIbV5dtKP78fVzbbo17150xPVnr9TNsCsPlxqquYfWRJ7Gq/0GUDDiU6mcfxzAcBBcsovKOe/AcMIjc4TdSdfeD+Cf+gR0IEFoqydCu3tuQc+n55D90N472HSi45S4K730YAze2r47Mow/HvWtfMAxsn5/gvAXYXh91b71P9rlnkDf8evy/T6b2+Zcx3C5q33mVVXsPZtU+B1F+yVXYoRCGw9nQt3ET2Ta2v5k9GptBA4RKKbW+SNlniVAA7IKcQE9CsqoindQ0+o6WZ9pEyx4cS/xLfOLFJvqwkuOIXDbVmlUjAbhN/8aVWP9DTt5mb+R2HZES8j+QTJOTgW4xXEcGkml6J5K1+BlSCvgBkYemNAYJo003zkEmpu4VwzVuiqlImfGGyjn7IT1MxyABxcIYHbsNEoD5DvgKCXZEsxS5GNLcbOhY0eEEsTMfCQz/EWW/gZQaj0eCT5EuVjVHXyRzejzRP+PmIr1EI/WsTbQ7gNs2sD8LKTmehATwesbouE7kwsD7yOtzQ+9RjyMXm2LpGqL3aO0GjEb6IO8Sg2N1RYa8fYKUbkfyfsMxlVKbyHBmUf/hp/gnTFpnu7PnVuTecBVY9eBwQjCIb/xErLIyMgceRIfff8HIcLNi530ov/hKDMOBHQphByLNutrQAgDbJjDtb/y//4FVW417u91o+/PXdPhrHBn9+hH4eyaZQw4ld/h1eL/+DqusnJV7DsA3VpKG6z/8lNLjz6Tw+SfIv+dWcm++hqI3X8f/52RW7tafulHvAFB+ziVU3X4fdkUF7r33wL3Hrvj/nAyGRduxn9Nh2gRyL7wCq7Ya/x9/UPP6K4QWLgJHM3oP2jaGx4PnwAM2/d82k/YgVEqp9Z2CBAIScRHFRsp6uiBZFL2a+O8+QXrq1bfg2B2Inp0YbQJuuvgCyZ4KPxHoikxffCfhK0qusUgfyxuSvZCN+AYYiGS1nbuR22YCQxp+ypB+meORrNslSI+spvTuaouU224L7IdM+N2J9V//WyOvuyHArLB9y5BgwydEPpktRiaCH0Xk7NZ4+x0Jvr7OhoMwBzb8/Ius8yvkBH4ZUNqE4xQhj+VOSOBhb2CrJvy7acCpJH7acyQPEn0CdLL8gQSG0tG/SEnxq0SffNsWKbW9FHmv+hAYhwTx/E04RiYSNBuAZJ3tS+S+fo1mIH32UqWnKciFwSXIlPHsKLfpjgQTr0GycT9AXqcLkF7ETVGMvJcdhLwn7LaR24eQzO0Hm3j/m6ICuYDwLfK+EckpyIW975DS5wls/CJSo3bI7zcUed9uu4HbzmJNqblSalOZJravlqo7H6D48/fWKaPNuexC6j/8DN/4XzCcmRg5Hto8/zSe/fal5qXXqLrzPmyfD8OVge334dyyG3YwSGjxEgyXe5OWYbjl9nbAh1nUBtvro+LqmwjOW0DB5TKXKOvYIwnOnovhdGB4svB+9yO1L75G7Vtv4eqzE5lHrmmfm3XycdS98S51n4+m9PTzqP/wE4LzF+Ds1QujIJ+MfnsA4DlgEO599qT0xDPJOuUEzKI2mFnZ2D4/hulpuLdNzOewLOxgAKMgH7O4aNP+bQtogFAppda3d8NPKrKRkuIbadqJ04Yci2T4hJuHfBlPZyuRYM35EfadzuYXIAQ5AT2I1O/DuAIZZPApsuamZBW1QYIPjQGIaiQjbRVSrlqNnEBXIBmIDuTksbjhf7vStLbYvRrWdQLr91dbigQAPwJ2jfBv2zXsO5rkBAknAwcgJYInbeS2PRp+TkXKvhcjAdcy5PH0I49te+QCRzHyN+iEXOzYlO7bbyIn5qs34d/E0+7JXkAEOcleQAs1lhvfhmShRTv/yGDN69iLBIIWIMGbZcjr10SyoQuR121PYEsk6NWU9IzPkM+FVJyQ/Qryuz7DhqeM5yJB18OQiod5SLbmXGAR8jo1kO8LLuRiYHfkNd2NpmdcLwEuRwK28fIP8p74DtEvJrhZ87yoQQK7/yLPj2XI+1Hj79sB+f22QX7fDVVhNFqABIwTOTRHqVbHcGVT/9VX1H34GVlDj1yz3eOh4LEHWLX/YeD1YVdX4f3mO6zVpZTffC0mmRgZ2WBZWKFqCq68BM8hg1k18BCsVSWSebjJa8nAP24CJQceBlgY2XkEJk/F16Eddr0X3y/jyb3hKoycbCruuw0DB6Yzj8CMmdQ8+xI5554JLid1oz/GO2YMprMADKj94E1soOjcs6h58jmCCxbg2mlHAlOmE5y9kNDyRfj/mAQ4MNwt6DcYCoHDgbNLF0LLllP39jsUvZWY2W0aIFRKqfQxDxlWEosv6ybR+/G9hwRU0t1bSBZa+Kfz/sjJQ3gWWGtXi5wYjyN6D7hU8jGSTXQuEkDqvgn/NhfJCIxUEtxSvZBpp2ezftn2EiRIGC2TsD0SJDwGyXZMtBKk5HIsEqzp3IR/40QCMFvGeC1LkEEFr8b4flujlmSKpwovUib7I5LNvLHAvwcJkm0oULYpKoARwMPIEJVU9SuSATkcyajM2sjtM5B+rLHuyToK+XstjvH9RvI7kr39ItILcUNykCB+rAL5U5ALIX/H6P6U2nwZgGFSNfwuPAcMwCwo+G+Xe49dyRt+A5U33YThyqX2lVdxtLuOwntGUD/6I/xTp0HIS+55l5Bz2UX4x03A0a0roeVLMUxH83r3OZ0YjeGu+nrq3hmNY8vuGBkZ1H/4Ga6d+pB/07VUP/McoSUrCC1chGGYlA+7lro33sUsKsL30zhsy5bDGwaefQ/C3XdHzMICqp59icyjDyO0cDHeMd8TWr4cwx0tAXwTWBZkOCl86lFCS5ZScdstmO6Cjf6zWNEehEoplfpWIZlUuxO7K/m7A3tE2O5Hynhag1+Q/mvhMpE+a5ujP5Dy3XRRjWTM7oYEx5N9EvcD8twZRvSejkuRcuNoPQkbg4SJmkwayQvI6/9hmlY6HEulSIBoNzQ4uDn6GnnuX4Nku8WbjfSV6w/cT2oHBxtVIdOCByDvFYnsHzsOKT0+ncQEBxstQnq53gCUJ+iYLyIXDJP9uaJUq2G4Mgj8M5Xqex9Zb1/etZeTedgQ7EANhjODmieexdGhPUZ2DnaompzzLqLwhSepuuchVvTvh3/CrxgZ2diBALa/Ze3hbTtIxsD+ZB13FO7dd8HIy6D2+VfIPOEY2v3wNW1GvQiGgRWsxTNgH7JOHIpn4N5knXCMpCcHApiFhRR/9DYFTzwEwRD4A2QecRj5d95M/j23YrgcYLekLXzDWkN+nN22xCwqxHP4wbh69Mb2J649sgYIlVLJ1YwLQjG0KWVwiRZEyhCvRzKRbkPKhmLlbCL//hOJ3jQ83QSIXkp8Fs0r24uUeeckvT5PH0CyeCJJ1cqCUmSIwV5IP6qPgMoEHXsp8CwSYNgPeJeNZ9g2lhtHCxK2Q4L9yRpcAlIyfB0SqLuN+Pdjm4lkDO6GvK+tjPPxNsaz8ZukjHTI+N0UtchQol2RgUORLuS0VD0SGNwfec9oShAo0vtfJsn7pvIHkm28LzJJPV5l+F7gc6TUdxDSwzcZ/EiW597IkJl4VTKMRcqzzye236uUUoDhzKH6yafx/TRu3R1OJ4XPPY6z5zbYQT92IEjpeefgaNeO4rdGU/D0I1Teeg8Vt16PZ+8DafvNF3SY8ivFH7yBu88OLZrka7iyqBv5Div67MWKnfcCTIreeeW/zMTQkmXYVhBnpy4Elywl+5zTyblqGKHFS7GCtTKp2e8jtFy6U2SdcRIFjz9IycFHsbzHTlQMuwYwmpfp2ChkYftrMdyZBGb+w6qjjqDqzgcoGHEvrl5bN/9+N1GqnggopTYThtXyKy0tUI5cIQ8mcxHIyUcdElRYiJwU/IT014nH2rKRsq2FrJuZ4ER6HyX1jxJjo4EzkDKttX9XFzJIYVykf7QBfyGBhVDD/28gf6N0KskOIhlwTyO9nRofFydS9pnKapC/6WikPPYQZKhGP6TXVCxO5IPIa28cMtV3LM3LsmssN36XyNmCjZmER5OcnoSNFiAZyo8igYjDgX2A7ZDnR3P5kKDgOKRv4ziaNjQmUSYi60n16d4O1u932VqsRi5YPI4E8oYigfgeNO+iSz3yd/0GmUjb1GEWjRYhw47Wfn+vI/kl3r82/AxHAluHIq/Rji24z3LWPFafsemPVTz9A1yEBJFPZM0wlZZc1F2NZK++jvzOSql4MU1sXz3ll15Du5+/xizI/2+Xo/MWtHnlWVYfPhSrugbDzCI4fwGeg/bD+8kXVNxzK1mHHE3bz0dT+/IoKm++jcwjj6D48/dZNfBQQgsXgLOZX00cDkLLV2DjJ/eqKzA8mfgn/oHv+5+ofvhJCAUpfOYJQgsWUvPcSziKi7G9XorfeJPyy6/HKi2h9MSzyL3sItz998K5ZTdcW2+Nd9I4TDMLnM0PrdmhEIbTSd51N5DRf28woOa5l6n95B0IhTBy85p935vKsGOQBplKlmQUlwMFcT7M8cgXD6XibRDwfZyPUYmUmiX8y6E7EOC3Absyad+dyfC2dN5G85aAZAekwhthEDkRSQQnEiQM/70NEpeVlUjZrH9iYSJZE5t6OdJs+Al/7KwI21KdgTwujes2kedhuv0eAPlIX8ndGv63FxJA7IQEdN2s/3v5kMDuciQw8C8yRfd3JGgWq9djIVK2f1CU/SuRQOJvMTpeLGQgjf77IBcTuiBTRts37PMgQ0lKkExdL9IKYSly0WUqkom8GHmcU5GDNYMNUpmBvL+keiAzVnKQ1/CeDf/bHXkd56z1sxIJ4pUggfj5SBD1T+S129y/afh7YuPzIxT1XyRPIbA9UmHQA3mc2iPvhY6G/y5FXn8+5LW5FHmsfkdeo8nO4m0qJ3LBoj/yfrQD8p5UyLrZtY2vFS8ycGQOkjk6HrkIU5K4Jaec85DWEiAB4SHxOpBtGrj8AYa+8glZtfVYzR3S0DTHINO8VQqy/FXknnchhS88ud6+ujffo/T0czAMJ3bIj2ub3phtCvD9PpEOE37GN24CZZdfgoEbGz8d/5pM/WdfUnnrcMDz37Ti5nJs0RHbH8Aur8Cqq8AwMrDtIG0/+wDP4QdT+8oo6j/6jOKP3gLDYGlhV+zqauxQEAhi5hcBBrbfL+XGLbk8bdvYIT+FT/wPR5ctqLjmBjL670PBYyMoH3YNtaNewXTm3dk5UHZHi37pJtIMQqVU0gQdDnpPnsU/O/bCm+XBDCX8/MdPyycBp6MgrTMQGE1tDO+rNZ2o26yboZqKJ8FNVYlkw0xca1sGcgEgC5myu3bQwEICWo1B4nj2JStHph6/S+QgYXtkIMtBxKfUsjl8yEWj2Ui2ZiM3EnwwG/7bx5oASrq9l6bz8701q0Gy6P9Ya5sTyfp2Nvx4kedd4/MvVsLfE1NZOdJn95e1tjU+Tgby/udH3uvS8fW5tiDy3tj4/mgi7+sepF1D4wVAA3lulCBZn82vR1RKtZjpyqXmxZdw77k72eedsc6+rFOOJ1Symoorr8dwugnMmg0EMIs6YNXUUHXvQxhGDhgGppmBkZMNDidmfhGOdh0JzJmN4cpodklvcMEisMFwmBjuho5DAZtQaRnV9z0CDpPs889i9ZEnknvt5RguJzZguDPAdmNXNxREOJo5QAUgFMIO1QMmzi17knnUYawacAiB+bMJzP0bwzbIv+V6vJ9/jVVR0bxjNEM69UxSSrUylmmSX1nNtlPmEGxBWrZSSkXgQyaXLkNOLKet9fM3chJZTWKGFlQiQcIxUfa3R7IgEtdkpnn8yIl3LRKgaCy/TOfgg0p9QeR5Vo087xqDP6me/ZlojY9THfI41dI6X58WEkheDcxgzfv6VOSiRjkaHFQq+QwDDBflV12P75fx6+3OveJi8u+4BTtYi+FwYLiysKsrCc6YhVlYgG1Xg1VP/l234diiI3Wvv4Gz59a0//Nnci8fhh0KYftrJYtvU5fmcmG4XRLg+2+bm4qrb6T6iWfIPv9sMo84BEwHJYcehV1bC43ZsIYh5cROZ/ODg5aFkZtD9rnn4ey2JZgmjs5b4Oq7IxDCdBZQ++a7WJWVODpvAXbirl1pgFAplVQBh5Ptpswip6om3mUISimVTJVIi5Jvo+zvAXwF9E3UgpRSSiml4sVwubBrqig7+0JCi9Zvc513+43k3XgzdqgOLAvb76PurfcpfP4Jcs46h8InnyTr7FMpPeFMfP/8Sc6wC/BPnop/6p+Y2Vlkn3Y6zq26ywATq+UFPlZpCY4tOlF1zwhKTz0PIysT2xvADgRbNoCkUTCE7fdiB/3k3XI9bV58CiMnh9CKZYSWLqPwiYdw99yBULAc57Zbg8uJVVpGIudq6tm4UiqpLIdJXmU1206dQ9ClWYRKqVatEpmoGi2TsIj491FWCoCQwyTochJ0Nvy4nFgOPTVQSikVO4Y7i8DcWZSecnZDsGtd+fffQcGIEdihAGDgm/g7zq264951D2rffINVe+5P3WfvkXXAEDKPPIyy84bh/WEsoerVeA4dTNtvPsK9267YoQC2vwZCze8gYrizCEyZRtWjj1D35kjq3n5PyopbEhy0LMlytIKYHdrh2mYbwKbytjuo/t+TZJ91KqHaEsqHXYOZn0e7376n+JXXKHrnVWpffJ3QsiUYpjNhGfP6LUAplXQBp5PekzWLUCm1WYgWJPwXOAD4IdELUpsXy2Hiy3CTV1FNhyUrab9sFe2XraLDkpVkV9fpxTqllFIxZbpz8Y77gbKzLopYEpx73RUUPv0ohsuF5S2hfvQneA45kMAf0wgumodhZpN7zWVUj3iM4KxpGGTh6toL9x67UnHtrZh5ebT74StyLroYIzcH29+C9uMOB6Y7F8Od29BzsPlzr2x/PTidOHv2wA75ydh7L9r/8TPFn7xPxqCBVA6/F/fOO5K51wHUffQ2K3cfRNV9jxBatJyKy6+n5pnnAQMjK9PV/F9o0+g3AKVU0llmQxbhlNlMGrBLsiYaqxhq8QmmDc5guvSKV+GCTie2YWBaIRyJHz6UDqqAocgAkMHIQIaTkambSsWF5TAJuJwUlFWx/Z8z2WbaXDx1XuyGC3OmFaKqII8vjj+Q8uJCXP5EtOdUSim1OTBd+dR99jHGaefTZuTzGBkZ6+zPueR8HB06UHbuBVTedQ+eQw6k+ON3WX3CyZg5hTi7d6P84quwCWEQoODxB/F+MYbaj94kc49BZOyxK6FlK8g67URqX3iF2pFvYjgzoqwm/mx/PRkDB5J349U4t+pO9ZPPU/vSS/inXkpo8VLyb7ke6xofRl4OhU89TMmQ4wjMmkVg1nRk5pKJTQBPv4Hk33vrzolatwYIlVIpIehw0nvKbP7ZaRt8WW6MkPYeT0cBlxPDtukybwnb//kPzmAIexPS8g3Lwu9xM2237VnWpT0G4AxooDBdNAYGOy9YRqfFy5mzfQ9KiwtxBoMaKFxfNXAScC3wDLA4uctRrZXlMAk4nRSUV7HdX/+w7bQ5ZNXU/VdW3CjkMMmtqObwd8fw+fGDKW+rQUKllFIxYoDpyqHuvbcAaPP68xiedQN4mccOoW2XLyg981xW9tuf7DNPxczMxypZSWDuv+TffwdVjz5M9smnY2RlUXHTcAxMci6/GN8vEyg5+Tjyzr8Md9+dqH1tVDJ+SxEM4mjXlvw7b6Hy9nvB78e92y5Y9eXUPP0CGf12Z+W++5M19Diyzz0TzyEHUDTyJUpPPAOrogpssK06sk86lcJnH8fMz8tK1NI1QKiUSgmWo2Gi8dTZ/N5/Z9whzSJMJ0GXE2ybrvOW0mfS33RZsAzDsjYpONjIsG26zVnMwp5dmLb7dizv0gFo/YFC2wDDlozaoEuaETtCFo5g83upJEpjkKHD4pXs+PsMus1ZhCsUYPu//mHWDj35e+dtKS8qwBkM4WhBb5hWqAy4OdmLSCchpwPDsrENg5DTxOUPYjS7/Kd1CzlMQk4n+eWVbPfXLLadNofsmjoCTid+tzvivwm6nORW1nDYe2P48vjBlLUtwBGMHtwPOR04A/o3WI8h7VMcloVlmBjYafFerpRScWUYGO486t57GzsQoM0rz2AW5K9zE/fuO9P+p28pv+hyKh99AJNcDIdJ2ZkXUfDQ3RQ+MILAzFmUnnAGVl0l7m13wb3HrgSmz6DgtnuoHvEYBEMYLs+mra3xc2xD5y7BELbll/vewO1s24aMTBztijHz8/CN+43A7LkY5FL31jtkH38UWccOpeb9kdS9/yGefffBqq7BqqjCDvkxMrPIv+Ve8m66BkwDZHp7QmiAUCmVMgJOJ9tNnsU/O/bCm+nBjME0KhVfAZcT07bpMn8pfSauCQwG3C5aMnHLsG22mrWA7nMXs6BnZ6busQPLu3RoVdkstmHISaTLhWHbuPwBLIdJdlUtnRavAKCiTQErOrdL2d876HJiG9Bx8Up2nPQ33eYuxhEMEXQ58TkycPkC7PzbNLaZNpfZfXoyfedtqSgqwKGBQrWJJHDuZJupc9hlwhTKiguZt013lnXtQH12JtD6LyI01X+BwbJKtv/rH7aZNpfsWgkM+qIEBtcWcDnJrarl8He+piYvZ4Ofxf/suDVzttsKX6Zbg7Xw33u6Ixiix6wF7PTbdMraFjB1jx0obdsGRyikgUKl1GbPcOdS/9F7lJaX02bUizg6b7HOfrO4DUXvjyLjiX2ovPM+rLLVUFFJ2XkXY2TlYtdVYxguTE8OudddTtUd91P95ku4e+wEhgmE1gTwbDtyMK/xs810YAcCGKaB4fFg1VZjuNwN97OG7a/D0b4Trp13xD9+EnZtLUTpnW+4XISWLqby3ofJu/laOUxBPr4ff6Hskkuoef5Vit4fiaN7V2oefwbvzz8hZcUBXNv3peDxh/AcMLAFj3DzaYBQKZUyLNMktzGLcN9dcGsvwpQVcLswLYuu85ay46S/6dwYGHS5wNn8wGAj2zAIuCVw1mPWQrrPXcx3QwYye4eeZHh9MfgNksM2DEIOE8vhwO3z4/YG6DljHtk19fT8+18sh0lGvZ/8ykoMbOo9mXx9zAEs6rFFSvXmlMCgQcfFK9hx0t90n7MYRyhEwOVsCA4LyzTxud24/AH6/jaNrafNZfYOPZm+y7ZUtsnXzKMYsg2DoMuJGbKwTANXKwqW+TNcZHj9HPjJD3SbsxjTsihYXUmvmfOoLMhlZad2TN1je1a3KyLkdOAIBjGtze951dLA4NqCTgeZdV6ya+qQk5ZIbNovW8X2f85g+q7bMbf35h0otBwm2DZb/bOAHX//m46LVmAbBh2WrqTHPwuYs30Ppu/Sm9J2rTdQ2PjZ3ciw7f8C95vjc0IpFZ3hzqf+x+8pOeBw2rz2Iu69dlvvNjmXX0zGgP5UXDcc77dfAy7wSwafHfCTedChZJ9+MrbPR1ZFBWZuLvXvzwfHmvchOxgEO4DhylwTKDQMjKwsGZgS8OPs1oW8m67G0b0rgb+mUXnHPdjeesCB4c7A9tfiOeRQCh69n/p3RuP76de1fxMIBbFCtRhGpgQXsTGcGdS98Sb1H3yCmZWJc+ueFL3zGs6uvQjOnU/N48/i++4nbMuS27szyblkGHm33YRZWBC/B34jDLuVvVkvySguBwrifJjjgffjfAylAAYB38f5GJXAHsDsOB+nScyQRX12Jh+cOQRvZoZmETaBbRrYGIAd35Pixmw3y6LL/GUNgcGlGJb9X8AoXsyQBQaMPWIA/9/efYe5UV0NHP7dmZG02uq1173bGIMNxvTeOwQIvQcILSEQCCSBJPBRQ0lIaIFAAqGE3iH03psBA67Y4N7bervKzNzvj6st2mLvrrQrafe8z6PESJo7V1q1OXPuOXO23IRQXQ4FCRX4yiwbDsRc+q9Yy9BFyxkzaz7BaJySiko04FkmsKqVMgeaYLLxgg6vH7kPi8YOy3iQMB5woFnGoOOawGB7/v6W7xNwXeryQny9y2S+3WEivmURzNIMyVxgDsgdAlGXTWbPY8T8JXw/cRyLxg5DK5W12aftUR9sGLpwOdt9NJXhC5YQCwSTXmuW5+N4LrFQkIo+xcyevCk/bjaaunAIlOoVWYWebeEFHPqsrWBCs8Cg30Z2QzrZrofte6wd0JdpDYHCEIFYvNcEhdyAQ2FlDfu++B6DF69sCNjXU74m6MaJ5IWYO2Es07fteYFC37awXI/x0380GeIaouEQC8YNR2mIhEN4to0Tj2P5ute8NrLEWcC/E/9+CTisq3akLfO9c/T9L5JfU9fVn0FHAs925Q5E19OxWqzSfvS55SYKTjup9Tt5PtV3/ovKv/wdd+kCLCsfbBssCO29JyXXXkFwu60pv+C3VP/jTlSwAFwXa9BA+tx8He6cH6m88e/guiZIqHz63P43AuM2YeW++1J0/kVY4TC1Tz3HoJlTWLXbgWArqIsQnzkDa+gwBn7xHlU33ULlrX9FkY8K5ZnsRM/DGjSQ8OEHE3nrfbx588BOfP67MeyxYwnuuD3OoIHY48ZQcfFl+DV1aOoAhcIiuOse9LnmckL77NHW0/QOsG/6n/2WJINQCJFVfNuiqNJ0NP5k3x0IxFM7uFXaLDvriYHG+iV34Zo67ETWUDQcSvvBRv2BjvI1I+YtMTUG5zcJDDpdFxis59sWluezz0sfAHRpJqHf0NEz9ddMfW3GcG2Ezb5dyMSpsymuqCIvGiVumaDahjJ7PMfGibkc+Ny7vH7k3hkLEprAYJOMwcRS4njAIdYkW2Rj6jMKnbjHTu9NYfSchXy3/UTmThxj6hP2kAPl7tAQGIy5bDr9RyZNmcmAZatQaEbPWsiSMUP5bvuJLBk1BK0UTjyOyqHjcd+y8G2LTWbOY9//vY/tekSDLbsR+rZFzA6ifE2/1eXs9vqnbP3JtywbOZhvt5/I6sH9k7KYehLfsogH6wODpsZgfo1pPtLRjMFUeI6Nh02fNRXs9epHbPHVLKZvuzk/TBhDNK/nBwrjAYfCqloOfvpN+q9c2+pzry3zWW+5Plt8PZNNZs7jh4ljekxGoW9ZaKXY4/VPmTh9Nh7me9RTNlUlZpn6/PGjqCnKZ+HY4VT2KSIaDuHEJFgoRG+ngvn45RWsO/0c4lO/peS6K1CFhcl3si0Kf/0L8g47mKq/3UHt/Q/j1a7DUvlEXnuF6LsfEtx+G+LffGcyBQFsG3/dOiJvvoczcjgqEDDZhErhx2rw5i8kuPVWgMadOZviK/+AX1GBO2s2fvkaSu+8Fb+6mjXHHUXBYYeA52OVllL28GNUXnU97nyTqeh7teTvuyeld91CxRXXUnHdNVi2qauofR+ruIjwIQdQ+/jTVN12Z2JpswYUwfFbUPS7Cyk4/RQT8GyFO+cHah9/+rvi/7usy/4GTUkGYedIBqHoLnvRyzIIwQRmagrz+X7SuNSCNNocuMzZYhMqS4tMoDDHO6lqpdCWwnUc8mvq2HTaXCZO/Z5gNIZvWXxw4M7M22xUWoJITQODwxYsZaspMxg2v3syBtti+T4KeLsLMgl928J1HAorq1FaU1VcaJqEdKJWXv3z03/5GiYlAqrh2gh+Ijuwo89dpjIJm2cMNg0MpuPvXx+0mb7dBKZvsznr+5XguC4qB5aH1gfotVImM7KbMvXqs+oCsTij5yxk0pczGbB0VVLGUn1ATFsWi8cM5bvtTKDQNJTI/gNy37ZQvmbf/33A6DkLTLCwA1kolu/juC6xQIB540cxbfuJrBpcBomMymx+7O3lOTbBSIxtPvuOcYmMQbebMgY3pj6jcM2AfkzfdnN+3HwMtQV5BBIn63Lh/d1e8YBDYXUthzz5Bv1WrktaXrshytcE3DiRvLzGQOHAvijfNDPJpZOa9cHBfV7+kM2mzyHSLJBfvwLAcT0UPpG8PFYPKmPx6CEsGDeCqpKihrIllufn1GPPIZJBKLKf7+O71YS224XSf9xMcMeWS47rxb+ZRtUd91D3xNN4NetQNC7rbV4XUMdq0HhYgaKGJcZebC39/nkvVlk/1hx3LMWXXEr4sEMITJpI7NMvWHXIYRT+/CzyDj2Q1UcfTuk1NxI++qes2mt/Cs89h+C2W7PmyGNQwQK052H3LzMZhK+/g7tkCcp2ms0hApjjCY1PcOxmFJx3NgU/P7VFk5amah9/hvUX/x53+YIrR2jvms49sR0jAcLOkQCh6C570QsDhNC4FDEdqooKmbXVpszaajyVpYXmICWHAoX1P749x8b2PAorqhk1dxFbfDWLPuUVeLaNVhaW7+M5Fm8esTdzJ4xpEdiyXQ+nHRkKjYFBn+ELliVlDMYDgbbLUXUTO3Gw8fZP9uD7LTcxtdaaf5Upc1DSnkCAb1vEAw7F66vZ/Jvv2fzbOSjfZ86W45ixzWZUlBZju67Z70a4AQffUgxYtoZJX85k9PcLCMbiiQP31J64pkHC+ZuO7FTg0nRFdjeaSeYGHDQwZPFKtpwyg5E/dmwpcUcorQnE40RDQT7faztmTh6P5zhZGcgx7zXwAg4FlTVs9t1ciqqqWD2gjJmTxxPowpqKDYHBeJzR3y9k0pczGLB0dYuljMkbQSAeR1sWi8YMY9mIQSzYdARVxYXEA445YNc6qw7I40HT4OGA599lzJz5LZYUd4R5bbnEggEWjBvB8hGDmDthDPFgIKczCl3HJhCPc9Az7zBywSKiTigrAoPNOa6H5XusGtSfJaOHMH/8SNb3LaG2IJz43Nbt+lzNVvGgQ2FlLYc89SZlK9d2KJu6Xv3nXyScx/xNR7J05GCWjhxMdXEhSvtYnnl/dsdnYf37rCP78m0LjWKflz5g/Iy5rWb5Nqe0NhmTvk80FGTV4P58v+Um1BaEWTugL9XFhdieZwLJygRTs+kzKkdJgFDkDB2rQRWWUHTxBRT/7iJUYUGb941/O43qe+6n7tkX8VYuAgIoO9hmNh5gMgEHlzHgrZeoe/Vtau65l37PPsryCVsQ3v8Q+r/xAivGb0tgm60IH34Ia046lsJTzqbk+itZOmIY4b0Poc/tN7Niy21RwfzEmB6+V4tlhcEJ0PTARMfiaOpQhAhuty0FZ5xC/glHY/UtbXuKS5dT8cerqHnoUQBUMHT1sOiaqzrwNHaaBAg7RwKEorvsRS8NEKZTfTZJdX2gcPKmVJUUZXUX1aaZZkUVNYSiUYbNX8bQBcsYunA5gVgcbSm8Zl+AtucRCwb5ccJok7ye+IhXWjN3whiWjRiMou3sId8ymTvD5y9NqjGYDYHBpizfBAnfO2g3Vg4b0MrSLM36vn3wLYW1ge85z7YpqmgMDBZWVeM6JtjiuC61Bfl8nwgUri8txmnjNaOVwlcWA5avZssvZzDm+4UEYvG0Z1rarkckHGLeZqNR6JaB0Q1QiSVei8cMbch6a+1xaBSDl6xo0ZW4qzNGLd/H9nxWDS7ju+0nMm/8yIZAYXeqbyRjqnqCb9topbBdj5LyCgqq6xgzewFDFy6j75pyLDQ+io/224lvdppEKBrt0N+lPfNpHhgcuHQ1/oYCgy0GIdG0RBMPBlg2YjDLRg5i4djhxEIBKvsUYfkay/MaHredgUyvaF6QET8uYbuPpjJk8cpOBVxaUx8oVGhWDB7ABwfvyqrBZWhFq8Hy5gGZbFr6abJAXQ565m2GL1jarUuJO8v2PJxEE6O1ZX1ZNnIwP24+mmgoyPp+JQ33gcRrr50nd9pLK4VvKRTmuxXA0jqlE4X1y4oPeeoNylauS/m1Wh8o9CybSH4eS0YPYeHY4awd2JfqogKi4RDK87GbfG7X1/nrDJOVm3hOEsv5g5EooIiFgtiuh0KjwXw2tPJ90Zg5+AHjp7cvONja47Zd023UtxQ1hfksGWWCyZV9irE9853X2meU0mT177gsIwFCkVtcF9+vI7TVthRf/SfCRxy6wbt7i5ZQ9+z/qH3iGWJffYMfr0ARbDVYqONxwocfQvHvLsRduIjK6/9GnxuuJvrlVwQnT0Ll5bHmxJPpc8MNhHbbiVX7HIyuraXfw/eja+sI7rgddS+8wvrf/s7UOmxOa3TcBWKAxh4wlNB+e1FwyvHk7bc3BNr+vtDxOLX/eZjK6/9CfNE8LKegPiNSAoSdJQFC0cPshQQI06ZpoHDm5PHMGz8y6cd2tvBsmwHLVjN8wTJiwQADlq2mz7oK84Ndb3x5b/2BRnOu47Bgk+FM324i0VAQSyc/dt+yyK+uNYHB+cuwfE08mL2lapXWKF/jOXaLg0mlNYvGDGPa9hOI5rXe7MazbMbMXcjmU2dTVFnd6vK8+tdMTUE+s7falB82H9PieasPHk2cOpsxs03GYFdk2jU8tsTStM5wbaehNl1dfl7S8+Iri1A0xhZfNi4lzsRScifRgXbVkDK+2mUyP0wYQyAW75Igjcn4tKg/ytbKIq82Qp91Ffi2he16jJ/2A7brEYi7DJ+3xGQ3x+O4ttPQTEZpjeO6fLzvjkzdZRKWp2k8clcNmVIdOZhtqDEYdzsfGGxFQz0+pXAdm8o+RawcOgANzNlyE7PUz/OpLC2itiAfpdvzGakaxu1sYCeWF2TUnEXs//w7BGJuu5dqdpTteniOzYJxI/Acu0WAxfJ9ftx8FFUlRQ1LI9cO6Ivr2InlsaDQGQkaeo5pdHTgs7kTHGxKabA8s/w4HggQDwZYPGoIdYVh5kzcpOHk1bqyUmKhQFqChFopgrE4hZU1+MoiLxIBDXUFYaqLCzqVSRoPmgziQ596i34r16b9tVr/Ge/aDtpSrBg6gOriAmqKCvhx89HJr0vbNieLOkBbFkXrqymoqsENOIyau4g+aysI19SBUtQU5TN3whgi+XnYrkd1cQHVJYWoJt8XWikc12Pvl8yy4s4EB1s8bg1Km+/cuBMwn8GeT0VpK59Rvo/rOKwdUEr954+ZnzIrCBLLlUUDCRCKnKRjdYBD+KjDKP7DJQS323qj20Q/+ZzIy68RefM93Bmz8WrXorABG2UHTMAwUYtQFRej6+qwiovIP+1kdE0NtQ88gkZTcMYpOJuMpfbBR4l98zVWQTHhww9FFRdR++Rz6KpKsGwTEHRd0C4aF4WDPXgowe23IXzkYeTtvTv2yBEbnXfktbeo/PNfiX70IeCgkr/jJUDYWRIgFD3MXkiAMO3qM5VcZwPp5xlmeT62bw5APdtukSnYGaZhSxzPsdsM+ihfY/u+qT2XI9o6iHTiHp6z4Xp/juvh2Ruvb2b5fkPArK05ZCqg1lGBuItnWehWljw3Po4AOsMPIxCLEw8GmLPFJkzbdnPWl/VJ27LQ+qXCw+ctZbNpP5jDa2WC5EUV1Qxctsq8JrQJWJpMGpVYeq1azaZV2mR0Lho7DK/JQbvl+dQU5TN92wmUl/Ux9dk2EChs2nxk9JyFTJoygwHLVjfUHk23+i7AGtXw2WD7PqsGlVFRWtyupX2257F49FDmTNyEWF6wQw0XtFJE84KM+X4h+z//LrbnpeXzbkMagplt3O7aNtoyQQetFEtGDcG3LZYPG8SK4QPQSrF6UFnDWPUnb7pSfcOig3I0ONiCNoHWQNxFQ2P9TF+zbOQgIuG8tAUI8+oilK5Zj29ZFFbVoDRUFRfw2jH7sWZgX4LR9p9wMZmDNYllxalnDraHE3extI9WFm7ihFj96zIe7Hgg1bcsylauo88685zYroelfXyVaNClNW6Tz4K1ZaWs61/a7ISSoqC6jqGLlnfN74XE60Mr1epnlPI18VCAJaOGYPk+VSWF5gSe72P5muqifNb3K8HyNWiNgt5e31AChCJ3+RrfrcHK70P+sUdSeOEvCW49aePbaU38m2nEpnxN9P2PiH07HW/xEvzKtUDihAJg+vZqNBFAoVQBSil8vxaFBQRRtoP24mhqE+tGgonbfCCAPWgwzqiRBHfantBeuxHcbhvsoYPb9fBiH35C5a13Uvf8y+DHTJOVlscSEiDsLAkQih5mLyRAKITopeqzYWPBIG8fvhc/bG4a8HQ2cFDf9bWooprJn09jqy9mAMlJZNqyUjp50NqSaIWmLhxmzhZjmbHN5q0GCrVSxANNMga/SjQfSXE+nWUaTfjtzk1SwOqB/Vg1pD/TtzWdWdG6oc5ha3zLwtKa0bPns/sbnzUE7LNNfW1JXylT8zHosGLoAGqKCpg7YQxrB/YjEg5t9PF2lmebmoMHPvsOwxYsJZbrwcGNSCUTtTVaKXzbBnRDsMKJu1QXF/DqsfuzZkBfgu0oZeAGHAqqajjkqbc6XXMwnerrOHaUov7EY/vea7bnYXstPwu66qRFeyV1J1eq4W9r+T6VfYpYM7AvgZjL0pGDWTm0PxWlxVQXFzYECesfT1e8Z7OQBAhF7kvU+bMLSgkfdTgF5/yc0G47tXtzHYni/vAj3sLFxGfMIj5zNu78Bej1lfiVVaZJSnUNxKImQNf0Y8FxsIoLwbaxSkqw+pVijx5FcIsJBLbYHHvcWJwRw9v/WHyfyNvvU/3P+4i89Co6XoNy8ls0WGlCAoSdJQFC0cPshQQIhRC9nOX5+LbF3Ilj+WTfHXADToeyCes7VBdVVDEhUW+yoKq2Ww/w65cN1uWHmTNxLDO23Zzyfn0S2UAQjLmMSsoYzExgMBX13Wvr8sOsGdiPuRPG8OPmo4kHAw215eqDom7AwfZ89n7pA8bP/IFoCs1IupsJTHgm0qI1awf0ZcXwQczbdASrBvcnlhc0WeBpqI8WDwYIRWIc+MxbDF+4LPczB7OI47rUFBXwyrH7bzSTsCE4+OSblK3qnsxB0Xn1Wf9gAsSW1qztX0p1cSFO3OXHzUdTUWrKCKwYPpBYKNj5mquJJc1Z3p1bAoSi5/A8fK8OyykgtO+eFJx2EnkH7IPVr2+nhtN1dQ0BQl1VjY7GmmXwaZTjoIqLTICwtE/z5b/tn/qixUTefJeaBx8l9tGnaB1DOeENBQbrSYCwsyRAKHqYvZAAoRBCNGSLrOtfyqf77MCCccMJxuIbPCir78ZcWFVrGtF8N4eiymrirdSb7C6Wr3ESgcLZk8axdOQQ8mojbPH1LAYuXZXxrJx0UIlMOrRm3YBSlo4YzNJRg6nsU8Ta/n0b6p7t+vYXlK4uT6mmYjawXc8sZQTWDihlxfCBfLfdBNb3LQFlyh10NEOpvlzBwGWr2PG9r3pF5mAmBBKZhK9sIJMw3Q1JRGbYiSXGmsTCQm3+Z/Xgsk4t1a4XiMeZuuOkhnq5WUoChB3R2mshR05g9Sq+j3YjADhjxhE+7CDyjz2SwPbbdDqA1xX8lauJfvgJdc+/ROTtd/FWLAFsVCCvI68rCRB2lgQIRQ+zFxIgFEKIBoG4ixuwmTNxEz7edwe8ZtmEOtF8w9KaoQuWseWXM+m3ah3FGQ4MNmf5GtttrIPnWZZpmtHD1AfPLDxqCgpYM7AfC8aNYLuPphKuqeuyZiSZUp9FWVuQT3lZH2ZuPZ75m47EdZx2LZ2tDwwOWrKSSVNmMmruQizPz/kgajZrGiRcNbgsqYxB47LiN+m3cl2Pe70KUq4h6miXZUMH8+JJBwNt10XOMAkQbozvo91awEJZzTrfeh7aNx1p25nt1Xlao+PVaBrrZSrCqGCITrct7wV0LIYmguUU4mw+nrz99iJvv70JbDMZe9CA7p2M6xKfPovoF18ReeUNYl99g7dkAeCDCqE20MV4A7otQCi/NoQQQgiRM+IBB+VrJkydzZBFy/nwgJ1ZPHoodmIZshN3GT5/KZOmzGD4/GUo38dz7KxbmulbCr8XBBs8x8Ys9HMIRmMMm7+UEfMWE3cCPTLYYh6vTTAaY8iiFQxZuJyVQwfw3fYTWbDpCOKBQKuBwqTA4JczGDVnEY7rEQ84EhzsYvGAQ2FlDQc9/RZf7LktC8aNIJoXQmlNn3UVHPDs25I52IOlemLGxWHgslWMnrOQOVuM7VDTG5EFtEbHa7EKSsg7aH9C++xOcOvJ2EMGmUCg7+MtX0l86rdE3nyXyFvvomO1qGB+l8yFQID8Y0/BKi5uuDr2yefEZs5AWfIZ1BYVDKIIgu8TnzaN2LSvqbrlDuwhQwlMGE9oj10JbDEBZ8JmOGNGdTZI15LWeMtX4M79kfiM2cSnfEXs629x5y3Aq16T6J4caKvxSFaSXxxCCCGEyCnaUsSDAUrWVXLI028ya9J4vtp1Kzb/5nvGzZhHcUU1tuuaoEsPzMrLVb618Y7hPUXTxzpg2Wr2f/5dEyjcbiILxo8gFgiYjuKJrqzJgUGXeCAgAaluVN+deP8X3mPF0AF8v+UmFFXUsNm3c8iLRORvITZIo9jyy5nM33RkojZppmck2sX30G6E8OFHUHz57whuv22rd3M23YTQnrtSeNF5RN/7kIorryf6wTuoQGF6gz6+j8rLo/TWm7D6lzVcXfG7K4h+NwUVLEnfvnoqy0IF81DkmeDdshV4yxZT99arKIJYpf2wy/rhjBuLM24s9ojh2IMGovLDpoZhoqFVSwq/fD26uhp/zTq85cvxflxAfO4PeIuX4q+vwI9VJAKCDsoKYAWLWxkn+0mAUAghhBA5yW2STTj6+wUUVtfi2VaiW7Ec0IvsUJ8BOGDZavZ/IREo3GEii8YMo2zpOiZNmc6ouY0Zg1JrMDNMZ1+b/svXMHjpCjSmHmiu1wQVXc8NmCzCUXMXZXstQlHP99GuS8lVV1J85WXt3iy01+70f+MF1p93EVX/uRcrUJTeIKHW+BWVSQFCHY0CuZF9llWUQgUDQCBRd1SjKyqJl5cTn/s9GhfwTeYhDioU2uDfUkdjoONozN9D4QA2KBtl2Vg9JIAr33hCCCGEyFnaUniWTV4kKlk+Iqs1DRTu++L71BTmE4rECEVjicCgvH6zQf0ycSE6QiuLSVNmsGDcCMkizHZao90aSq69juLLf9f2/TwvuRZhggoFKb3nDvyaWmqeeAwrWJS+uSmFKipMvioYRF5QaaAUOE4isNck5Kq1ubhum5sCKNsClYdS4a6dZ4ZJgFAIIYQQOa+3LF0Vuc8NOCitya+pQyslgUEhegDXsRm4dBWj5i7kh4ljCUgtwqyl49XkH3UsxX9qGRz0162n5v6HiL7/IX5FNVZJMaHdd6HgjFOxyvo23tGxKb3rFmJffo07bz4qENrADnVyZ2SlWs9UUwodi1H9j39h9y8z2yhF7MuvUdYGxs82vt+1jVzSra2/Ry8lAUIhhBBCCCG6kVYKLQckQvQoWikmTZnJgnEj0Upla0fjXk27LlbfQZTcdE2LVbvxmbNZc/TJxGd/27h8FI/a/z1Dzb0P0vfx+wluvVXD/a2+pRT96heUX3wx6GBykMn30W4UTRyFhbLDJglQgXYjiesDKCevMZhmWRCNUnHdVZBo7wWgKEAFwyRlEWqNjscS92vseAwW4JgmHBv7jvE8tBdrWGrbOL5CYWGaa2x42a0Zx0d79Y9VgQqj3Wrzb4KJDswiV0iAUAghhBBCCCGESIEbcBi4dBWj5yxizsQxBKUWYdbRfi0FJ5+Ds8mY5Otrayk/4zzis7/DCvZJuk0BsTkzWHfSmQz4+E2svqUNt+X99BCsq6/Hr6xGJcpI6FgdygkR2nNPwgfuizN+HKpPn4aMQF1ZifvDPCJvvkv03Q/QsUgiAOiDbRMct01iWbHhrViJv3YtKCsxfgTQOGPHEdhic+zhwxrvO28B8ZmzcRfMM3MPtr4ctr4Tc2jXPQjtvjOBTcdBw/xjxKfPJvr2e8SmTgWsRJCvZcBbx2pQwQJCu+5B3n57Edh8PKqkBH9dObEvv6buhVdw5840AdJWlmuL7CMBQiGEEEIIIYQQIkW+ZbHFlzOYv+kIySLMNr6PFSoifMLRLW6qffhJIl98iBVovdGEFSwiNvs7Iq+8Qf4px4HnAwpn+DCc0aOIffMN4ODHqgntsDMl119F3r57bnA6Rb/9NZE33qH8Vxfj/vAjynZQBYWUvfQUzuiRDfdbf+GlVN5+C1awGD9WQ3DiJIov/Q15hx2M1aflfP0164i89S5VN99O9KsvsIIFSbfrWC2hPfeizw1XEdx5hzbnp6NR6h57mvV/ugZv2dLkLEat0fFaQnvtRcmVfyK0124tts8//iiKL7uY6lvvovKGm02NP2n6lPXkLySEEEIIIYQQQqTIc2wGLV3F6DkLmbuF1CLMJtqNExizKcFtJze7QVPz6JMoAhtsFmw5hVT88Wqq7/mPaWACoBTesuUoJ4iO1ZG3+16UPfcYVr/StgdqIu+AfSh77lFW7X0I/tp1Zve+n3ynRJBZx+rI22NPyp55BKusX9vzLOtL/glHEz70QMp/+RtqHnkYlQgS6liE0C670f+lp1CFBW2OAaBCIfJPP5nA5EmsPuRIvJWrUE4wERysofAXv6TPrTehQsE2x7D69aX42suxRwyj/FcX5159wl5IAoRCCCGEEEIIIUQaaEux5Zczmb+p1CLMLh72mJGoUHJNPH/tOrz5C9loaMSycJcsxV28MOlqZYdA+1h9Sul7753JwUHXpfaJZ6l77S2IRQluvx2F55+NystruEtgiwmEdtye2pdfMFe0+nrxsAr7UvqPv7UIDrpzf8SdvwAVDBKYPKkhq1AVFVL6r9uIz5hF7NtvUE4IbJuSa/6UFBzUlVVU/+NfRN59H5RNwUnHkH/y8Q1LjgOTt6T4T5dSfsGvQQdMk5djj6f0zr8lBft0dQ3xaTPAtglstWVS4LDg7NNxFyym8vo/o4LJXZpFdpEAoRBCCCGE6EksYAgwAOgD1K/B6of57bsy8d/VwHpgNbAMiHXnJIUQSQqB4Zj3bSkml2sIUAeUY7oxlANrgIVAbWamuXGuU1+LcCFzthhLULIIs4SPPaB/i2u9FSvxKypQ1sZr5KlAAGjZeV7H6gjvdQjOpmOTrq+86RbWX34ZEEAB1U8+hAoGKPz1L5LuZw3oT3KzkWbj4+NsMZHAlhOTrq998jnKzzkPr2ItCofA5pvT7/GHCEwy91P5+RSccQqxC79Cx+M4I0cQ2GqLpDFqHniYtX/6LTYhNFD35guUrlxN0aUXNdyn4GcnUnn9zXjLFmEPGk6fv12fFByMvPUe6y/6He6suaAUwZ23p98D92CPHd1wn6LLfkPdcy8Snz17w12fRUZJgFAIIYQQQuSy4cA2wGRgO2AToC8mONj22ifDBSqAdcACYCrwdeIytysmK4QATBBwZ2A3YEdgNFAGFG1kuypMUH8J8BHwGfAFjYH/rOBblskiHD9KsgiznK6qRtfWgZVCZ3nLwVu3nqq//8PU2lMKXI/qu+5DkY8KBM3yWi9q9tV887IyzLmttjmjR7W4zp3zA27FCixVjLJtYrO+purm201wL9EURRUVggqC9lF5oRbNQoI7bk/eFtsTnz4LRQyNour2uwCd1MFYOTaaOAWnnpjcGGXREtadehbuikVYdgFoTeSjN1n38/Moe/OFhoYrVlEhBaedxPrL/gBIgDBbSYBQCNGTOcDdmINFL8Nz6SoOcA/w6EbuNxj4JyaTpu1TlNnJAe4EnuzANrsCNwCZOm2vEvteASwCfgSmATOASIbmNBLzGsijtVZ03UNjDuwWY4IvMzHPyfoMzScP89oaS8c/IxzgGeD2jdyvCPO8DyX33nvtFcS8317pxn1OAA4CfgJsiQksdIaDySzsB4wD9k9cXwHMAV4F3sQEIrKNBdyCCYy6HdzWAd4Crk1h/zdiAjwd3Xe6KKAS83nyI+YzZRrmMzdT/ggcSOaek86yge+BX9H1c98XOAE4GPO52FFFicsYYI/EdSuBD4HHgTcwQcSM8hybgUtXMep7U4swGJUE5WylCgtQ4TC6urp99fFaCfYqJ4/oBx8T+eAtzE8dFw0oLBT5oDUqGCR/1yPIP/m4lmM2rzvY2m4rKltcV/SbX+GvWUvtY0/hrVmLIkzNfx+g9unnTbajbR6PCgTQsVhirskhoOCO2zHw03eJfvQJ0fc+JvblVGJfTaX8sosTj0EBASwrjBUoIe/QA5O2r3noMdwVC7ACfaj/eWmpUiIffEzs0y8I7dnYwCTv0INQV91ggqhSizArSYBQCNGTWcCemABhT/ZOO+6TjzloydvYHbPUqx28/yBg966YSApiwFLgXeBl4HWgphv3X4g5IMsmHrAK+BjznLyMCSB2FxvYC3Og2Rnft+M+QWAfTJC+JxvRDfsoBn4KnALsAmy4wnpqSoDtE5fLga8wJ2KewQSksoHCPA/bdXL78hT3vxONAZpsUY456fAC8BowvZv3vzXZ95y01yA22KIhJTZwNHAh5jWbbgOBYxKXOcB/gAcxJ+kyRluKSVNmsEBqEWY1q18pqrAQv7JqI28ABZ6L9qLNR0AF80ymXMwDNM6o8QS334bAZuNxNh2LPWoE9pAhOKNGdCowplDEvvoab9ly7CGNPydUQT59br2R4j/9lvj0WcRnzSb+7QyiH3xEfPb3aOqwVCEEHJTj4C5eTPybaQR33zl5/MIC8g7an7yDzDkyb/lKYh9/Rt2rbxB5/iW8davNLAryCWyafFgVPvan5O2zOzRboq19n8C45CXXzgjT9Tk+a3ZDZqHILhIgFEL0dC3z+Hue9mTJaUy9nlwNEHY0EzAbM0aDmCVUo4GfAz8ADwH3YeqfdTUf834Id8O+2svGBM7qD+yWYzJF78NkAnWHVD4j2pMSolPcR67oyqyjAcBZwJl0PpibCovkYOHjmMzt7nqNbkgqGcnNj3K7c99dpRSzZHU3THbkW5i/1UvdtP9Un9NM6qrPqT2A6+i+k3abYrJbfwX8BfP3z8hqAtdxGLhsFaPmLmDuxE0kizDjbLzFS1teO2AAdv9+eMuW0Fp9wQZuDHvYMLN81wlAIr/OX7mKqptuwa8pJ7jVNhT94RLyDtoPq6Sk7bF08vLdjXPwVq5g7Uln0u+Bu7FHJZ+Ts/qXEdp7d0J7m7eZrq0j9tkUqv95L7VPP4fyLbAsdF2EtaedQ+m9/yBvnz3b3Js9eCDhY44gfMwRxH/zK8p/+RsiH72HbZVAsyYvgfHjMAn4G6eKi7CHDiY+azobrwAiMkHyOoUQQojM2AS4BpOZ9EdMhl9vNxiTYfI5cBudW34meo584LfAl8CfyUxwsLl+mMDDZ8CtmKX7IjvlYZag/w+TTZhtWeU9XQgToHuHzDz3w4E7MFn7O2Zg/0B9FuFMnHgc3aGAkEg/G/eHefjrK5KvdhzCRx6G3sg5D+3XEdp3LwrPO5vCc06n8JwzKDzndMJH/gQ/WkNgq63p/8aL5B9/dHJwUIP7wzzq/vcqldfcQOV1f2mjU/GGqWCY6PvvsGqfQ6n881+JffElurr1hSgqP0xonz3o99RD9LnpWrQXN8ucAyHc+QtYc/DRrDniBGrufxh34eINLnEObDGBsuceJTBqHESiLQKbuq7O1HGsrmnXpT3LqUXmSAahEELRdUtKhBAbNwgT/Dga+AOmflJvFwZ+jVlOejnw34zORmTC4ZgA+laZnkgb8jHB7GMw2Ur/JDszl4VxIKb23Z3A/2FqF4quMxK4H9g70xPB1CR+G7gCU7OzW9VnEY75fhFzthgjHY0zSAUCuEsXEf3wU8KHHZR0W+H551D7+NPEZ09DBYtpUarZ81BWHgVnnNxi3Ngnn6PdWkquvhxrQHI53Mib71B5/c3Ep0xF19bi6UrCex5C8eW/7/D8ddwFLOLzZ1F++e+xLi8gsNlmBDbfjMCkieTttzeB7bY2jUiaKPr9RdS9/DrRDz5AWQFAoWMRal98kroXn8MqGUBgq4mEdt+VvAP2IbjjdqhmWYJWWT8KTj2RiutuMLUQS/s03Fb76NNUXncjKpzfeoVr7dcnW5qncsVKVCBXFzT1fBIgFEKE6bmF84XIJdtglsFdgwkYSrEiU9fuIUwt0Qvp3pqNIjMGYpaGnp3pibTTUEyW0jHAJZiMYJGdHMznyJ6YJevyt+oakzGlItq35rB7FAB/ByYCF9DNZR+0Umw5ZQbzxo+QWoSZpBTa96i598EWAUKrX1/63vsP1hxzMu6KhSjCpqaeBrSLpo6SS/5AaPeWJTRrn30Ju6CsxZJdb8VK1p1+Hu6yH7HsQnAcVDyAM6IziyN8nDEjccaNBd8sT/ZWriT+zdfEZ09HP/cU1rU34UyaQJ+//Jm8/ZNj88FtJxP94B2sfgNR+WGTxacs/MpK/IpKoh98QOSDd6i8/m8EJ0+g+PI/ED7qsOTnaPhQfF1LfPacpCXOgYnjcRfMw3zENssuJIJqer0ytRBRspA1W8lfRojebTnmgCaTHf+EEI0CmODIo+RuvciucCamqYss5+zZ9sU0rMmV4GBTe2K6HZ+b6YmIjZqM+Tw5PMPz6IkmYJZ0Z1NwsKkzMTVE+3TnTl3HYeByk0UYD0p+TiZZTpjIq68SefPdFrcFd92JAe+9TtFZ5+KMHo1dWordrxRn3Kb0+fNNlPzlmhbbxD75nMjbb2IPGwqh5Jp6fkUl/tp1WCofbBs8D3AJ7rpTy4ltZNmtxiP/hKPp/+qz9H/9Ofq/9iz9//cUdt8BgI0VLALbJvbNp1RcekViX03YNj4xSq6/koFffcjALz9g4Ncf0u/x+1GWhbKCWMFilGMTnfo563/7J4i1zHbVaKLNnrvANpPJO+AgNNVmLMdBWRaaWvIP/An933yFAW+/yoB3XqPk2svRXq41ee9dJEAoRO9UiakLsx0m8yGXi2oL0ROdADxHNx/EZLldMQeeozM9EdElLsBk0I7d2B2zWClwN6YpQn6G5yI2rB/wFHBqpifSgwzEBN+GZXoiG3E48Czd3LBLK8WWX84gEHelsE8mWRY6Hmf9JX/AX7O2xc3O+E0o/fedDPzmIwZ88iYDPn2LQd98TPEff9uy+7DnUfGnq9FuLdrzWtQVdMaOpuDs09G6Dj9WAaEAhWeeR8HPTmw5rX592dgLIz59VtJ/28OGUPLX67CKi/FjlfjxSuySwRSef64JSDZRX6vQW7YCq19frAH9sfr1Je/A/Sg453R8vxo/VoWOm/uFjzgEAsnBbHfWHCwsah9/Cm95Y4NwFQzS91+3kX/4caiiArBtVFEBhSefQb8nHiBvv70I7bMHob13x12wCO3LYWc2k1MYQvQuHvAIpl7SrI3cVwiRWQcBDwPH0ju64LbHlsCLmMYDCzM8F5EeDmbp3wWZnkganYMJZJ9O93QoF50TxHRMj2MCW6LzLEx9xy0zPZF22ht4DPP92i1FAV3HYdCyVYyas4gfJowh0Ep2lugeKhgmPu1b1p70c8qe+i+qpLjFfaziYqziltc3VXHp/1H33jtYViH+ipV4ixbjjNukcT+OQ+ltN5J/3E/RdbXYgwcT2HJiq2NZxUWJf7W+/FxhE3nlNSJvvUfefns1XF/w81MJ7bozsS+mgILgDtvjbLpJ0rY6EiH2+ZcoFaLm3gcoOPNU7KFDGm4vveNm8g49iOhb76FjMUK770z46COSmpF4y5ZT+9SzKFWIu2whFZddRd8H72643R45grIXnsCdPQe/uhqruLjFPGKfTaH20SewbDl/ls0kg1CI3uMtzPKt05DgoBC54lBMRpJotAVmCXZBpiciUuYA/6ZnBQfr7Y/JiMz2bKreLoB5DbYsLCY64mxMo61ccgTm5ET30Zohi5ZLDcIsoIIF1L35OqsPP474jI4dFrkLF7HuZ+dQ+bdbsZx8cBz86gqqbvlnyztbFqHddyHvgP0agoPe4qWJhiNNNH1NtNrtOpH5eMEluHN/TLrFGb8J+aeeSP4pJ7YIygFU/OkaYlO/xAoU4i5eQPm5F+KXr2+8g20TPvRA+txyA6V3/o38E45BBQINN/tr1rLutF/gLVmECgRQgUJqHnqYyqtvaLEvZ7NNCW63TYt5eMtXUv7L36Bra8CWEFQ2k7+OED3fNOBE4ADg/QzPRQjRcT/DdPQVjXYBbsv0JERK6oODp2d4Hl1pa0zGqwQJs1sh8CBmiazouKGY2rm56Hy6cZm5azuM/HEJoUgM3WoQSHQnK1hI9IMPWL3HQVRccS3u9z9s8P7xmbOp/L8/s2rHfaj570OmE29i2bEKhKn+592s/80f8FauanV7b9Vqqu+4h1W77k982ozkufQvQ9UvMW6+lDnxWlHBMPHZs1m93+FU//sBvCVLNzhfd/5Cyi+8lKpb7kAF8hNjFFD38sus2vsQ6p55AR2LtbqtjseJT5tB9e13s2q3A4i89SYqmN8wH2UHqbjqWtaecDrx72a0OgYAvk/k7fdYfcARxL75GhXs1pX9ohNkibEQPdci4G+Y5TPS+VOI3HYT8HniIowzgXcw2YQit/SG4GC9rTG1M38CbPhoTmTSJsAtwEmZnkgO+hXQP9OTSMEtwBfA9129I9+yKKyuYej8ZfwwYQzBNoIzovuoYD7++goqr7uO6jvvJbj1JII7bY8zZhQqHMavqMRbuIjYV98Qm/I1fsUqUHmoYGGzgRTKyaPq1lupe/ZFQvvvTWDcWFPzsK6O+LcziH35Ne4i0+137TGnYjVZ2uyvr0AF8tF1Edb85FhUsLHhibd8JVagENCoYBh30WLKz/kFlYOGE9x5BwKbj28YS7su3pKluN/PJT59Ft6qZSgnnJSVqIL5xL/9ljXHnEJwi4kEttkKq6TYNGyuqMRbuhxv+Qq8pcvwKlajCDYGB+vZFsoKU/vE40RefoPgTtsTmLQF9qD+oEFHo7g/zCP+3Qzis75HR+tajiGykgQIheh5KoB/ArcCKzM7FSFEmuRhlkLtRTfVS8oRfwXeRj7rcs119I7gYL3JwJPAIZjvaJGdTgSex/ytRPsMxJysyWX9MN+vh2NqdXcdBcrXDFu4lHmbj+rSXYkOcBwUReiKCiLvvE3dO28APqYeoAIsFDbKCqKCRW2PYylUsAB30WLc++5F09iZWGEDAVTQVEdx5y8g+eXmoIIB8H3iM2cl9p/Y1gqAE6C+PqEJHgbxVq6i7rlnqX3Op2ntQoUFWKAa99ecCoZBa2LTpxOb/m2T7VXjY7Yc0x25LUqhgoXo2joib71J3VuvNZuHDdgoO4gK5rU9jsgqEiAUomd5BJNpNC3TE8kioUxPoBv0hs/y3vAYN2YXTA3RezM9kSwyBPgDcFGG57Ehit7xOWRv/C4AnAFc2pUTSfCA1cCPmMy9lUDTok/FwABgJKahyAaOgtJiF+AfSNfcbHc18ApQnemJZEBw43dp4UjM+yidFgDfYd63kcR1AWAwpsv5eNLfgfgQTID44TSP24JnWQyfv5RQJIrrOFKPMJs4Dgon5SbT9QG8DY3TNEOw5W2t/WRo+ToxdQIDnZ+vUukJ3Dk2inxpzt1DyAGXED3Dm8ANwLuZnkiW0cBMzIGiv5H7tne8PGAMna/hugpzoJquGrAOsDxNY23IPKAWMvL9b9O9GWIaszR/RQpjOJjAw1bA5qTvefstpvNiJsoG/A/4NoXtFeYAbytgEuaALx3OwTRymZ2m8dLNxZy0qSR9n0P5mM+hzloGrCV9n0MBYE077rc9cHua9tmaSkyt3deBzzDBwY097yGgFNgOE8Q7ANiGrvmsOwWYSnc3RshOHyQuqRiAaVq0NekLGG2GORFzZ5rG64gqTHf2TH3PzqKtFqptOyFN+6/DfLc9iHmPVLVxvxDme+Qg4BhM8710uQJ4ji7+fvVsm6LKaob/uJQ5W44lGJVFAUKI7CEBQiFy2zfA9cBTGZ5HtooDx2EOgtN1inYL4EPMAXpn/AOT5ZkuFl2/5FRjGmVM6eL9tEWRnPnT1XxMwH1eGsYKATsCv8BkJ6RqPOY1fX8axuqoh0nP0jsH2BI4C5NNluqBfRg4F/hNiuN0lQpMt0xF+j6HdiS14MqfSW8mans+hwqBfyX+P92+xbwnnsPU3+2IKOZkwEuJy/8BO2OCRMdiMg3T6VrgY6Se6MvAX9IwjoWpH3gGppNuvzSMeSEmUNXdWYTvYYJemaAw330d+a4dhTnhk6ovMHUMv2zHfaOYDMO7E5cDMFmfO6VhHptivku6PICvfI3jdufPGiG6keui/WY/CawAypHQUy6Qv5IQuWkJcDOmyHtthueS7dIdPIts/C4bFAdysSp1hNycd2eVpGmcKI2ZMo9hAsQjUhzzLMzBazqy0Tqi9UI2HediMkR+hQlS3YPJLEvFiZjAy7oUx+kq6X7vpPo5FKP7389XYmrxpdN0zMH8Y6T+nNRzMSeBPgRuBC4Bfk7nll+2Jh/zObAXvbuBWLoy/nxgDqbUwH8w9ZcPSXHMcZjA07MpjtNRHrn1Pbsl0CfFMd7BLFOu7OT2b2C+X68BfpfiXD6gm06EKjTKl6XFogdy41j9++NM2AwSr3GVF8JbtBh37g9gtbcaiciUdC0tEUJ0jxpMUf4dgduQ4GAmpPrNlqufu/KNnrr/YQ4656Q4zvakJ2sjG0zFPCdvpDjOQODQ1KeTM3Ltc2gX4NdpHC+OCd7tjskcTFdwsLkfgF8m9pPqctimtgMuTuN4wpgL/BRzAiVVp6RhjI7KtRJeqX4PLcc0K+pscLBeBPg95qRTZyzAlKrYB3NioEtZvk9dOMyqof2x3e4+zyc6RplsuFhd0oWcqBvZ+txbv0TQsSi4bmqPTWs00PffdzDgnZcY8N7LDHjvZfre+w+swjD43Zg163kt/26uS+59zHY/ySAUIrvVf4r5NDYgmZG56QghUvQ9cDSmXmhZJ8cIYIJhU9M1qQxbDxyPWV6XygHnEcB/0zAfkV42JpiXrgy8eZilpO+kabz2+AJT8+wqTCAiHX4PPEHqJwxEsjjm9TEIODCFcXbH1Lrrjhq/uWp8itv/E1icjokk3IUpCXBDO+9fjVmm/DdSqzncIQHXZeZW41k9qIxgNJcSRnsh7WINHoQ9qEkfHt/H/WEeOhIFlcXBJu1iDRqIPXjgxu8bi+PX1uKvK8cvXwP4KDsMdkfORSp0vIqCk39G3mEHN1zrV1Sy9rhTiU75AhXsigojrfA9VDhMYPyWSVd7Cxbjla9FORv5OeL7iUBpojKMZWX33zrNJEAoRHZTwNvAdZiDZyFE7puOyR56KIUxDsR8LvQU6zEH9R9gGgF1xs6YpeEVaZqTSI/jMMGWdPgAUxtwQZrG64g6TPflGZhaiql2pi7ELLs+OcVxREtxTC25KUD/To5RhsnWfjFdk+qBhqSwbRx4Ol0TaeJGGhvNbMhTmGXJ07tgDm1SvqYunMeMbTfHdr3u3LXoBD9eQ9GZP6Pk6j82XhmLsWK7PYlPm5aeDsBdxI/XUHTaSZRcf+XG7+x5+JVVeMtX4M6eQ+2TzxF55XX8qvWoYPtKrms3hj1wGMXXXd44h8pK1h5zCtFPP0IFizr7UDrG12g3Sp+/3ULhOacn3RR990NWH34M1EbAaaNPnlKoYDC5YLTvgad7TfJhri51E6K3+Byz/O69Lho/iOlAN6yLxhdCtO6/mG6rnbUpJrulJ5kCPJ7C9gMxHaNF9giSel2weu8Ah5GZ4GBTD2GWsaYjEH0cZrmxSL+FpN5sIh2NL3oqi843awNTS3tpmubS3G8wy81bMxU4HPPe69bgIEDAjTNn4ljW9S/F9iRAmBP85GXg2vNyZIkxLebeJtvGKu1DYMJmhI86nH6P38+Aj94kfNDB6FhN+x6vH6HoN+fjjBoJgI7GKD/zfOreeqX7goOA71ZTcOqpFJ7d8hxBaO/d6fOXP6N9t9XnRsdj2MOHUvb6cwz8+A0GfvQGAz9+k/AhB6LjvaeqlwQIhchuNXRdI4IDMYHHB4Hu++QWQtT7dwrblgFj0jWRLHI7nW8sZGO6jIvscQywdRrG+Qg4itRrlaXLa5jaadEUx3FI35Jl0dIDwJoUtt82TfPoiQKk9tuxivQ3katXjsn2bRrVWIoJHO6GqQfc7ZTWRMJhkz0owcHclSvBwRQFJk2k3wuPUfCz0zYaHNPxCMHtdqbo0t80XLf+/N9S8/TjWIE+XTzTJvOI1REYP5E+f7++YUlw5U23UnNf44Kdwl+eRcFJJ+K7rfQI0xqVl0dwx20JTJ5EYOtJBCZvidW/DE3vec9KgFCI3mdLzNKK1zBL8iLQiz71hMgeb9L5rrsWMDKNc8kW3wDfpbD9pmmah0hdgM43DWhqHnAS2bd0/HlMECJVhwMT0zCOaGkFqdWqHELqS8l7Ko/UmgMNJrUMxI15DvgEc5L9DmAHTIfrjKUBBeJx5k4Yw7qyUlleLHKCCgYpvec2QrvviY5t4K2jLFQoSPVd/6b6rnspP/M8qu+9DytQ1H3Lcj0Pq6SEfg/9G6usHwDxGbOouvZ6ys+/mMib7zbctc8/bia4xWS028o5Pq3Rdc0+2npZQF9qEArRewzHZCr8nOQfZb3jVJgQ2WcV8BWwfye3H53GuWQLjeki2dnMHSmXkD12JPUlmjHMd1Y6Gxmk023ANsDPUhgjhHmMl6RlRqK5zzHLSTujT+KyMl2T6UFcTBZgZ5UBo4C1aZlN6y7GvL+6vDPxxli+JhLOY/q2m0n2YDbyfbTr0pAvoQIopyMNOpqN5fmgfUChbKtjTS7ql776Ptr3UVaT7dPQKKP2kSdw5y8wNfi0RoXD2EOHEJy8Jc64sS3ur/JC9LnlRlbtcQBE4602LlFOkOjHn1D38ZsN11nkoV3PPI+tzbv5Et+mjy/x2Kl//HYbYzShtcYuKSX60Wf4a9aCUlRccS1ezWrAYu2xpxLaeUdwHAgG0NEYSjV5LK6LJoaOt5LYXH9bLIaybGjttVH/eOp7mzR/TDlEAoRC9HzFwC8xSyva0cpKCNGNfqTzAcI+aZxHNmmrdlR7dLYztEi/U0l9pcrNpFarsztcjFm2mMqS/+OAq8meJdQ9yfcpbFucuEiAsHWpvF4VcAbmJFlX+aILx+4Qx40za6tNWde/r3Quziaeh/bqUKEiAuPGYvXvD24cd8EivGWL0R1YBa9jUSCOChRgDxmEVZCPjrv4a9fiV1YAPiqQ32ZGnY7HQUdRwQJUIIAqLMQqKcavqERXVuFHoqAjnegunKz69rup++I9FPVNOjQKC6vPAPJPOJqSa67A6t8vaZvgtpPJP+Yoqh+6H8tOrixgHreLVdqf0GY7YQ8ZDJaFX1mJO2MW7pKl5rEHw8kTqQ96at3QLFi7LvgRVKgQu38ZVnGR6ay8ei0at+UYTSgngLd0OesuOR+FhV00CGfsaPKPPAm0xlu4iMh7H+JHVpvdqxIIBBI71qZbtWPjjBgOKvmnizVgAIFhm6DCheiqavy16xJzBx2vAzzzdwkGUbaF9jXEYonbNMoJm8ebIyRAKETPZWGWZf0BmJDhuQghWpdKDaauqk+aadUpbJt7p2p7pr7AISmO8T1wQxrm0tXWApcDj6YwxjBgTzJUG62HSyXLLYQsMd6QeSlu/3PgGeDdjd0xlymtqQuHmS61B7OIgngUAkEKz/oFBeecQWDcWFR+GO376PUV1L38OhVXX42u3ciqdN9HuzU44yZQcPrJ5O23N87Y0RBwTEfdqioi731E7QOPEHnnrVaDRTpWjT14BIVnnUbo4P1xRgxDBYMQCkE0iq6pJTZtBpEXX6H2kSfx62o63UFZFRRgEU7uTqxBV1RSdfftuLPm0O+Fx7FKipO2y//ZCdQ++pjJlLOsRHCsmsCmm1N4wS8JH3Yw1pBBqEBjd2B/7Tqi739E5Y1/JzblM1SgADwfq7QPpf++HXv4MJNpqSzKz72Q+PezKLrwYvJPOAZ78EAIBiESITblayqvvYno55+YMVrLytM+2qslb/IuFJx9OnmHHog9aCAqZD7CdTSKv3Ydkdffpub+h4l++D7KA2wHHa+h9PYHCO27J8qyUIUFSUMXX3kZRZddDJai9sFHKL/wdygngHajhHbdjfARhxKYPAln+FBUcRG6tg5v6TLi380g8srrRN5812QfBkPkwsI9CRAK0TPtC/wR2CfTExFCbFD2/1LofhLky307kvpy7+tILVjcnZ4Azgd2SWGMI5AAYVeQz5Ou822K24eB/wInkgXLgLtKIG6yB9cOKCUUkezBbKDdGFZhPn3v/xfhow9Puk3ZNqp/GQWnn0xol52IT5/Z9kCei/Y1xb+/lKLfX4TVr2/L+/QpoeDUEyg4+Tgqr7mJiqtvMMtuLZMFqGO1hPbej753/R1ns9bKKBdBfwiPGkH4sIMpOO0k1p56Nu6CBZ0OEraggEAAS/el7v3XqL3/YQovOi/pLqEdt8cePhJ3/gJUMIiOV5F/9LH0ufMW7IH9Wx3W6teX8FGHk7f/Pqw961fUPfkEqBAEHII7bmeyDevH33kH+tz8Z0J77548SHEReYceSGifPaj449VU3XpbIhOzyUe71uh4LYW/+AUlf7kOq6iw5UMMhbCHDKbgjFMoOO0kqm6+nYo/XQWeC2isvn1aBEUbts0Po/JN9qK5j4t2FSXXXEXxHy9pNaPT2WQMoT13o/CCc6l74WXKz7kAb/UaVCDY6j6ySe7kOgoh2mMypgHJW0hwUIhc0Pqvkfbpqd/hskw49x2W4vbfYoJuucIH/pLiGAfQtU0beqtUSqvEEhfRum9I/fkZCrwK/JYemLhSX3twxjab48QlezAraA1+nJKb/twiOAgkNaRwNh1L+Ki2vs402ncp/ectlNx0TXJw0HXRVc2Sly2L4qv+QPEffot2axNLamM4I0bS77H7Ww0O6pqW2YvB3Xam3yP3oQoKwE/za0qBIo+ax59p0ZhDFRZgDx8KePixGvIOPIS+D9/bZnAwaduiQvo9eA95e+2D1rUmoBdp0gjE15TcdE3L4GDTMcJh+txyI4XnnI2OJ3cg9uPVFJx1FqX/vLVFcFBHoi3rCloWRb+/iD7/uAXQaDT++gp0VbV5zpt1qtaRCLqyCl1djV9ZjSZO8aUXU3zF75OCg/66crwVK/Ark//24SMOpfRf/zCB4ea1F7NQTz24EKK3GQL8DfgIOCbDcxFCtI8FbJbC9uXpmkiW2TyFbVenbRais/IwNflS8S9SW36fCS8DU1PYfjjmJJ9Ir1RKrFSQfd2zs8lsUqsZW68A+Csmi/B4ILDhu+cOx3WZM2Es6/qXyvLiLKHjdYR22Y3Cc05Put5bvJT1v7mUVXsdwuqDj6TmP//d4BoPTS2F55xF4bk/T7q+5p77WbX7AazcZnfWnnAa8emzkm4vvvJSQjvuaurT+VFC++/bIsgWm/ota444gZU77s3qfQ+l5v5HaDqZ4C47UnDKiWi3rlPPwQapAN6iRXjLVrS4yR7QH00Mu98ASu/8OyqvMYPRX7WayquvZ82hx7Dm6JOpfeix5GHz8kx2X2KZcRJLoQrM+TF3wSIqr76BdWecQ/Xt/0RXJS8kKPnLdQQ2nYCOmw7EOh4lMG4CfW6+Lul+3uIllJ93ESt33pdVu+5P5bU3opvV/yw89wzyTzoBhWL9r3/Pism7sObok/FrkgOQlVffyPJJ27Ny+72ovOYGgptMMsHBeq7L+kuvYMVm27Bi3Fas3GpHKv98c1KgMXzEIeQdejDaTaX5e/focWdqhOhlCoBzgYswBxdCiNwxEtgqhe0XpmsiWSQItH0KeeMWpGkeovNGAJuksP0a4Nk0zaU7uZjlklunMMYuwCfpmY5ISCVYvZ6eeyImHSLAi8DENI23E/A4MAW4H3geWJ6msbud0pqawnymbzdBgoPZQmtAU3juGUmZX96Klaw+7Fhi336KIgz41L32P+Kz5tDnr9e2HMd1sYsHUXTZb5KurrziOtZfdyWKEOAQ+2EasS+/YcCHr2MPHgSYpa6FF19A9ITP0dozdfiaWf+bP1D3/qtYFBKfEafundexigsJH31Ew32KLrmAmv8+BrF4WhtgKMvCr6jCW70mkTHY5LbiIjQuBScdb+osJvhr17H64KOJfv1R4rH71D77FKVr1lJ08fkN9wtuvw15Bx1E9J3We49FP/iYtcefirtiEaDggXupfeYFyl54AqtPCWCW+Ob/7CTWX/5HlA6BjlF41mlYJSWN86msYs3RpxKd8j6KfEATnfIB7px59H3gn0l/+6ILf0ntU8/iLl6CJmq6HDfL8vNXrCS+8HssioAIzmbjTQZngrdmLdV3/AuvbhWWKsavXkTF5X8ksPmm5B28P/gabIu8PXal7vns/3kjGYRC5CYbOAX4HJM5KMFB0dVqNn4X0UFHYWowdYZH6gXis9HewLgUtk+lY6lIjy3o/OsaTMOClqkLueF/pPZZuV26JiIAkz2YygmHH+neJcZuN+4rXR4i/b8PtgfuwpQaeAQ4mtSWimeE7XqsHlRGRd9iCRBmCe262P0HE9pnz6Trq2+9i9i3n2MF+6GC+ahgIcoqpPq2O4h9/mXLceoihA/7Cc6okQ3XefMXUnn9zZhMPx9NFEWA2I/fUX3bP5O2zztoP5wRYwCv1eBewWknExyxGY0fCYr1v7+CdaeezbpTzKXi8mtNI5N0s210XQX+6jUtb/M8LILkn5i8WK369n8S+fpDFHmYgoY24FNx6f/hzk3+qZp/7E/BtlpkZ+polPUX/xF3xVKsYB+sYAlWoJTIB29S9ee/Jt03fPB+WAWlppZkURnho5KXitfcfR/RKR9hBfuignmoYBgrUEr1w/dT80ByP7HAVlsQnLwV4KEIJjVZaeA45rZgkNby6+yBA+hzy42EJu2EcgJAHI2m/NwLWbXbAeay6wFU3XE3ysn+SiKSQShE7tkX+BPmQFqI7qCA/8MctHdXwfcAppbmM920v+5WCJy30Xu1bSUwJ01zySbn0/nXWByYtdF7ia6WSgYdwCtpmUVm/AhMxzRp6YwtMEdWEk1Ij/MxWcmd9VW6JtJOWwO30X3fsxZQhznR3Nmg/GxM1t+Z6ZpUE/2BkxKXJcDHmCD858APXbC/tHIDDsPnL2HogmUsGT2EQCwX4789jPZwRo/EHjak8TrPI/LWe4ngViPlOPixciLvvE9wxybnbjRg2+QdtF/y2I5Dn9tuSgT8mryFvRj2qNFJd7WKiwhuvSWxhdNx5/7YYpoFZ5xM+NADiX70CZG33if22RfEZ8yi6uF7zdxwUNimo28aswfN49OAYzLpmt9UW4dVMgBnQnJ1HB1zydtxd1SgyblBrbGHDEbHks+xBLaZbLLvdHKWXmzKV8S//Q7LadJBWCkU+dQ+9z+KLv9dQ5agPW4T7IGDiM+bhT12S5yRyXkykTffRTUPcymFwqLupVcpOPPUxusdB2fi5kQ/+4j25c5Z6IpKdDzeGExUisJzz6Dg56cQ/+obYp98TuT9j4lN/Zbo158BrslMtYKoVp7XbJP9MxRC1NscExg8CenKJ7rfcRnab08NEF4CjElh+++AtWmaS7Y4BvhJCtsvIfWumiJ1qdR8iwGfpWsiGaCB9+h8gHA4MIAcXlaZRXYGfr7Re7VN0/3LvccAv+7mfQI8QGpZuzdhMuJL0zKb1g3D1Cc8HqjEBG//B7xDFn/uW75m0hczWTpyCFoplN5AUTvRDTzsMaOSr1m7Dn/tOsy5meYcvJWrkq/SGis/TKBZkMwePpTC889t90zsUSNNwOqZ56k77kjCPzko6XZrgMmMCx91ONp1cWd9T/SDT6l75nmiH3yM9tzkTr7p4vlYhcXYA1o2H/EWL8EZNxarsCDp+pIbrqSEK9s1vFVciNW3tEUdwvjUafhuNVawJOl6ZTv4K1fjLViMtVVimXFRIVafYiBulm43z/rzPVo/VA7iLVqMjsWSsi/toYPbuH9LKhAiPmsGdY88Rf7pJzW7LUBwp+0J7rQ9hRefj792HbGvplL70OPUPv0cOpYbpZVlibEQ2W8opjviZ8DJSHBQ9B7RTE+gixwI/CHFMV5Kx0SyyGbAHSmO8QY99zWTKyxgcArbzwEWpWkumfJ1CtvmY2qTitSUAf8GQimMsRBoubaw56nGdOFOxVzgj2mYS3sVY1bR/B1Tr/Bz4DJSz15Ou3jAZviCJQxduAw3IHk5madR4eQKGMq2wGktOAgKZWr8NR3B91GlfVDNuuV2lD2gzPwjEmHt8aex/jeXEpvaeqxbOQ6BLSdS+Kuz6P/OS5S98DjO2DHoWPp/8mg/hj1yOM64ZuewPQ9v+UpUfjiphl9HqfzWK5D45etp9RBXKXQsltz1GLAGDTA3t7YkeEOB01i8RYdmu7S09X3XaxrYVwq0RflvLqX6H/ck5t06q19f8g7Yl74P/9vUUexbCl72ZxLLJ5UQ2asQOBv4LaZLsRAi9+2PWY6VyoFrFfBqeqaTFTbFZIoOSnGc7K/83PMVYYIznTUfqE3TXDJlLiZQ3Zn3uENqAVZhXn/PkXrjjFeQDsYdcQ+mIczJ3bzfALBD4nI1JrPwKUzzlJZrN7udwvJ9Jk2ZwdJRQ0wMQpIIM0ihK6uSrrH69MEqLqa1yg4aD3vggOQRlELX1KCjycE5XVFJ7ZPP4ldVgdVKAK1JkEkFg0Q++ARl5YHtQCRK5a1/p/ru+wntsC2hffciuMuOBCZNbDWTL+/QA+k3eCCr9zsMXVmdUsCu2QNGE6XglOOTOhQDxGfOxlu+FGvIIBNga7LP2OdfEv3wY3DaaECeeOzKsvDWrEHX1bVYGm31LaXVcxVaQyCAykv+Sq3vSKwjrQRJ26z5qSEYaPF8uStWsqE3pglqNrnddvArKim/4EKqb7+HvP32JrTvngS2nICzyZhWl33nHbgvJVf9kfILLkLZ2R2Cy+7ZCdF7HYdZTjwp0xMRopdK9094C1MP6wZMllAqXqbnNCj5CaYYfaqNlqZhmluIzCoC+qawfa5nD4JZ6l6JqZ/WGQM2fhfRht2Af5Bad3gwnQEeTn06vYoGzsUsMz4kQ3MIYpaW7wxcgTmRdi8Z/m6IBwIMn79UahFmBRt3QbOvGdsmOHkSsa8/I6m/lgawcDYdm3x/y0JXVuEtWExgi8aKGv66csrPuRCfalqGWFw0flKOmqIIFco3HXOVwnKK0JEIdR+8Q90H76DIwx42mOCO21L489PIO+SApBGD20wm78D9qX38MZSdvOR3g3Tif5pmxWnz375XQd6eB1Nw3tktNqt75kX82Hq8BYvxq6qw+vRpfHQ/zmPd7y5CNSv5auLhMTSN+XkaCAwYYxqVNBGYvCWWU2iejyYBNu3FCYwchzOuyd/B9/GXrwICuAsXoSORpICmPXgwrfV80sQIbr1Vi+Yu3oKFbDBA2Dx46XqJ5y9AbO4MYnO/Rf3zLux+A7FHDCe0206Ejzyc0N7JPbLyDj0Q+6qB+OXlrdZ4zBayxFiI7LIH8DrwBBIcFCKTIhu/S7uUYDowvoUpPp9qcFAD/0p1Up2UrrUsBcBBwNOYGlLp6MJ+J6ZJicisEKm9xhekaR6ZtI7UsiCzv8VheqSrO3AA06n4QUw9ulSDg2DqSH6ahnF6mxpMjcBsaDRUiqnZ/Q7wPqbGbcaOey3fZ6svZiRqEEqloIxRNt7CxXiLlyRdnX/aiWDloeONPyN0vIbA6M3I23+fFsPouEv0/Q+TrrNHDid85E8AjeUUYgWLsAKFKGycshH0u/NflD3+NGWPPkm/hx7DGTYMlZ9P2fOP0f+9V+j/7ssMePslQpO2RRFABRy8Jcuoe+ZJVh96LNEPW5ZEtQZ0PGFfRyNoIuh4LToeQbtuIkvPoeDUn1P29ENYzZZP+6vXUHPfQyhVgLdqJfGvvkm6PbTnHgQGjEFhYQUKzcUpQOMR2moX+t31b8qeeIayR5+k8JhT0fGWwbvgDtsS3H57tNukKbqv0dSSf9JxqPzGr0ZvyVL8NWtQhHDnzSc+9buksQrOPQPsMDRtkOK6KJVH/s+S6wbqmlri383AfJW0wffReOB66FgNhRecQ78nHqDfo/+h7PFHKTjyBDTgla8nNnUqlXfcxqp99mvRvRrbhrwQOstrkWZv6FKI3mUipn7LCUjgXohMszBdm5fTetXqjdGYINhoTMOGdJYIeIXMZUOcDmxD5347aMyp+WHAlsCI9E2L74H/pnE80XkFJKVgdFhduiaSQR7ms6OztQRTycDMJYdjgjid6TKsE9sNBcZjyhSk67eTj8n0Fp1TjQnG3Qqck9mpNNgjcfkIuBZTr7ZbuU6AYQuWMmzBchaPHkogR5oV9DTKcfDWLCf6/sfkn3J8w/WhPXal+I+/p/K6G/FjVYDCKi6jz603YJX1azYIEAxQ+9QLFF/1B9ORF8Cy6HP7X/BWryL60cdo4igCOJuOp++//0Foj10bhoi89ibuisUoK4g9ZDCByVs23Fb4m1+x9ozTIa5BBUAH0ERN1lozuqq6w89B0SW/JrzoSJRto/LDWP36YpUUY48YbpbHtqLiqhuIL5mHFSzCj1VR++jThPbdq+F2e+ggSu++lfILf4u3eBngouw88o8+ntLb/oo9tPFncOyTKRCPt0jYU8EgJdddzpojjsWrXov5SPcJH3QEhRckN3+JfvQZ3qplqEA+frya2seeJrjzDg23h/bcjdK/3cj6y6/Cr14L+CgCFF10MaE9dkke670Pic+ejQoE0fHWz1vl7bU7gQfGoyur0XUuVt++5B93VJPHP4Ta554D30U5QZQO4nnlxL+fmzyQ55mgZVc0l0kjCRAKkVmDgAuBX2GWZgkhMk8BJ2Z6Eq2IApdncP/7Jy7Z5kpyv26dMHpK995U1hD2lgzCnRKXbPM0JutMdF4dZrnx18CfgX4bvnu32Q2zSue/mJPySzZ89/TRCmzfZ9IXM1gitQgzRylAUX33fYSPOwoVbMwaK7n2ckK77UL000+xwvnkHXwAgUmtlzJVoSCxud9Qfcc9FF12ccP19rCh9H/zJSKvv0l89lycUSPJO2g/rJLihvv45etZf8kfwfXRVFH71HOUNAkQFpx2Erqqmuq778VfvRqrtJSCs04ntOeuSXPQsRixL6fSVjhHYbXswAyEjz68Pc9Ug5p7H6L6rnuwHBMItex8ap56moJzzyC4w7aN4x55GKE9diX6/sd4a9YS2GJzQrvsmDRW9INPqP7Xv1DFfVtNpA3tsyf9X32RmkceR/seoR22I//kZvUQPY/qfz8IKLM02wpT8+DDFJz1MwKTtmi4W+GFvyS09x5EXn8Lv6aa4FaTCB95WPIOXZfKv94G2gXV5FxVsxqCoX32ZPCML9HRKNX3PUTNv+6n8OLzG7o5h3bbmdI7b6fqhr/irVwLlkd4x/0ouuSCpHHi307HW7MK5aRShrzrSYBQiMwIAWcCl5LeTBohRM/1V+CbTE8iyzyDKckghBCpWov5XSbS4x7gA0zW3tEZnktTp2KChRdhmpl0i7jjMHyBqUW4dPQQHKlFmBEqECb68YdU3XQLxVf8Pum2vAP3Ie/A5CXF8W+mEdhi88aacZaF6W+cR8U1NxDYYgJ5Pzmocfy8EOEjfkL4iJb71jU1rDv9XOIzp6GCheAFqL7r34QPO5jgTtsnBlAUXnAuBeeegY5GUcEgKtQyoFRz/8PEp01DBfJa3NYglkIlB9+n8q+3UXnldSjLaQya2Ta6qpLysy+g7JVnsIc29tWy+vUlfNRhrQ7nLVlK+S8vxI/V4tjNlkZrjY7FUKEQwd12Irhb2+eOqv95H9H33kYFEufSHAe/cj3rTv8FZf97Kmk+gUkT2wzyAlRcdhXR999rGEs5AbzFS/CXr8Aat0nSfVVRIaqoELt/GfF506j59wMU/eZXDbcXnncW+ScegztzNgQcAltvldRh2a+opPLPf0kMlt0ZhLKUUYjudzTwMaZmlgQHhRDt8Rmy7K25ZZgDPJE9Uv3Vm87l+JmUSkvJdNU/FR33a3pGHcxsMguz5PgnmNqO2WI0pvP9b7trh1opVKKjsWQPZpBSKCdM5dV/pvLqGxu64bam+u77WHvKWUkNJZRtJwI8NjoSY+2Jp1P9z3uTm360IvbVN6w57HjqXnzeBAfBdMNdX87aY39G5O33kqcZDGIVFbUaHKx94BHWX/IHsAMb+NbVSRmS7eVXVlH34iusPuCnVFz2J7O0uVlDDRXMJ/bd16w5/DjiU7/d6JiRt99j9f5HEJ85A6Var0JSdcPfib79/gbHqX38adZfdjnYoaQgmwrmE5v6JasP/CnRdzY8BoC3cBHrTv8FlX/7uwmw1g9lWfiV66m4/Fp0XetfxabBSZDKq66j5j//TeqYbJX2IbjrTgR32C45OLi+gvKzfkXsy883HNDNEpJB2D0KgE2Ajb+DRE+2J2Z54H6ZnogQIqesAE5DltE2FQN+TjcuERPtUotZXtjZOoSdqUeXbSxgYArbr0nXRESH/A14NNOT6MFextTQPRT4BaZcRabf7zYmM38Q3RQojDsOI+YvZdj8pSwZPRSnlWYNohtYFviaiquuoe6V1yk45QRCe++O1a8vxOPEp8+i5sFHqX3yGVRBIWuOOMFspxS4Lt6SpSgnaDoa10YoP+9C6p56nvxTTyC0566moYbn41dW4c6YReSV16l96nn86vWoYHJFKRXMw12yhDWHHEP4qMPJP/anBCZPQuWHGzoO6+oadE0t7twfqHnkKSIvvAyWQm2oE64KEp81h5oHH20MXiqFrqrGX7sOLNVwnb+2HF1VhV9RSXzmbOIzZwMuKhBuM9tNBQuJff01q/Y6hPxTTiD/uKNwxo4ywUQNui5CbMqX1D7+DJGXXkO7MVQwP6kRTONgCnf+Qipv/Tt9rriS8DGHm7+FskBrvBUrqb7z31TfeQ/a9ZKCb03nE58xndUHHUX4mCPIP+k4gltMgLxEgDUWIz57LtHX36bmkSfwVi5BBQpaPD4VDFP75NO48xeSf+Kx2GX90PEY3rIVZpivvsGyw+jqOtad+Utq/vMw+ccfRWiPXbEG9jcNXpRC19TirVhJ5LW3qXnoEeLTv2sMDGc5CRB2jwLgJUxNk2uBHzI7HdHNxgOXASezwRZJQgjRQiWmE+OcTE8ky5yPqSUlsktt4tLZAGFnG3tkk1IglaOAntCoJdc8Bvwh05PoBTTmeOglYDtMrd+jyfz7/hJMYP7GLt+TUtiex+DFK1m0yXCQXiWZY9km8+yLKcS++BwVCGOV9UNHovjl6wDPBMhiMepefCFpU+WEG5fcOg5K20TefYfIu+9iFZagSorBdfHXlScaX5imHSrYeolZFQyB71P7+GPUPv4UqqAQq0+JCexpbQJ6nof23MZ5bWSZqgqEiH05lejpzXsFaUwvpqbX+JhGHjYQNAE4tfH4vQqG0dW1VN91F9V33Ytd1hdCIbNkuLIKv7rSjOvkoYKJzDmtUQUFSXUZAVR+GL9iHeW//R0V192EPWKYydb0fdwFi/Er1qCccKvBwabzwfepfexRah97CqukDypRJ1DX1uGXlwMxUKENButUMExsypfEpnxB44Lb+kxBx/y9AKVtoh9/RPTjD1GBMPaA/qapjWXhr1+Pt3Q5OlaT2KZgo89ntpAAYffwMIGhn2FS7O8CbkPOEvd0/YELMAeypRmeixAi91QBx5G5rsXZ6kLg35mehGhVDVBO55sSjErfVDJmJFCSwvYtq8qLrvQyptuuhGq615eJy3XA7sAJwC5kLlj4Z+B74Lmu3lHccRg/bS6zt9qUmsJ8LN/f+EaiyzQNXPkrV5klyIFgsyWsGwnuKNUQ/NORCLqm1ixbte3EWO1oSmFZZj9aQzSKv2xF49JX2za3W8GNBgaT2DaqWcON1rZPqTaIY6Mw8/bXrTfzV5j5Nl2+20CbIF+wWQBSaxQBVLAAXVVN/LvpjfOzOxBgsywT/NMaXV2NrqxKXK/aHfiE5NeFuaKVZ0kpE5RM3M9dtgKWLk3cZnVs3llEahB2n/qwc1/MMtMvMZ1rO3uWXWSvPExQcApwBRIcFKKzevNJrJWYzArJkmtUh1lWfHumJyLaVIVp9NBZYzGrLnLZGEwjss7wMO990T3+AxwLVGd6IhkUJPXaoakoxzQKOQmTVXgYcDcwfUMbdQELUxt8aFfvyLcsiiurGLxoBW4wlXKlIq2UMstjG2oMdpJlQcAxYynV8bGUSh6j6TidmVfTbbuyOYZS4NiN87astj9ZEpmRbbJtVDDUcMHuxPtEKbNdwDGXzv5d2/u8KYUKOI3zDgQal3HnmN588JVpI4F/AGcA12MK5Yrc91PgT5gfOUL0JEsxAZruOrFkYWrv9UYfAWcDszM9kSyyAPOcvJXheYgN8zB1IXfs5PZjMY1K5qZtRt1v6xS2rQUWpmsiok0x4Cqyr/FTDY3fe911ZFmDeT6ywRoalyDnAVsCBwIHANvQ9ScPBmNeF2d38X7wlUXx+iqUJ91KhBDZRQKEmbct8Azm7Nn1wOeZnY7opJ0w2YKHZHoiQnQBjWmS8RXdd9Bi0ftqcUWBW4Gr6X2PfUMeAX4HLM/0RES7fJ/CtnmY79NcDhDuk8K2i5HXeVf7FtOQIhtPNrwPnNKN+1OY7/fKbtxne0UwK3GmYJYhbwIcBByBWYrcejG31J2KKQU1tYvGB0yAcMz3C5i686Su3I0Q2clSqILkeL8KOEh77+wgAcLscTjmi+9BTEetXP5x3JtsijlwPQ1pQCJ6tnJgfaYn0YO9BVwJfJLpiWSRqcA1wPMZnofomCkpbv9T4L9pmEcmbAKkcsQ/k8aSNCK9lgN3YEoU1GR4Lm2JYr5rRUs/YFZe/QOTaXwkpsnJNmneTwg4C1MGqkv5tlT6Er2Q7eCvW0/l1Teiwnnga5RtEZ0yFazOVucQ6dQTA4S5XNMviElrPx7TxOROpBZNtirDNCC5kNSKkWeDQjJbf0bkhp74fZENlgC/wBTKF0YN8GtM5mA0w3MRHTcDs1S2sxk+ewEDyc3fP4eRWmbTF+maiEjyT0wW2rJMT2QjJGLUPj8CN2MCvntjvi8OTuP4RwB/BCrSOGYSz7bpu7qc4fOXsmDcCJy421W7EiKrKNvGX7eOimuvoWnGoCKc6A4sWYSZ1hO/iHpCt8dizHLVjzGd1drXbkd0hyDmb/IZ8H/kfnDQxSylyPYfzUL0VHnArExPIssEMTUvJTiYmxaR2iqIvpjGEbkmAJye4hgSIOwaDvI7pyeKAq9hyvsciDluSoehwK5pGqt1ChzPJRCLo7uycYQQ2ciysIJFWMHihosKBpDgYHboiRkhh2Iy8P4IbJHhuaRqLHAPpmvj9Zg6hSJzfoJ5Xe2c6YmkyUuY19WnmZ6IEFlGY5Yz1bLx7FqN6VQ+opP7KsMsmcqF+qWLgXW07zkJAZt1cj8BTGbI9nRhBofoMlHgQ2CrFMY4D7iP3KrFeRipLS9eROrLs3NJJab5UHuNo/OrhH4OPA6808ntRfZ7A5MkchXmt3qqdgZeScM4bdIoCQ5mG99v7K5b3024q2lt9lvPsjbeNbd+nm3N0ffB12C3MlbTx9hUdz1ekfV6YoDQBx4D/gecC1yM6YiXy3YEXgBeBa5FAjrdbRdMZ+JcOIBvj8+AP2MChEKIlnzgZOCbdtxXY75jPgaGdXJ/BwPHAE93cvvucg3wAO0rSRDEHFzt0cl9jQMuwjRsEbnnJeD8FLbfHPMevDc90+lyNvD7FMd4D3NSorf4GLOUs70uBm7s5L5s4C+YrDDJTO654pjf6+swS5BTsV3q09k4z7G7YzdiI3QsgiaO5RRCKIhSoKMxdKwaZeebQFsShY7Vods8h2UllsxueBGgjkUAFxUqAscGX6PrasxcrHxzXYuNAMdBOTba9cDzW/4qcwKJ293k2+u3tW20bhKUREEkgnZrUHZBy8frefheFRvO8HOwgsUbuY/IBT0xQFivGvgb8BTwG0ywMJfrE4I5iNwXeAi4AZiX2en0eJtgGpCcQc9oQDIPuAm4H/MjSgjRthjtf58swmTj3pXC/q7FNCpZn8IYXS2OKUvQ3vv+HyZjp7OnpH+LOeE3p5Pbi8z5DJMdNiqFMf6A+Q2XC1mkJ2FO5qbif+mYSA7x6dhvkTswS7g7m5m8LaZEzB2d3F50zuaYv3Uq3c076m+YDPTjUxhjDI1dnruEVorh85awYFxnFyCIlGmNjtcRnLwN+aedRHDLiajiQlAKv7yC2v8+Tu3jT4Hngd0YrNNulPDBB5F3ROu5I3rtOmoefIz4nNmoYCvhBw1+vIrQlttS8IufE5g0ERUOgxvHW7yMyBvvUPv40/hVFYntG1+GfryG4nPPJ/+Mk4m8/DoV/3ctKpiXuNFkB/a58WpCe+1G5c23U/PoI1jBQrPbeITCc39JwWknmsBhPUvhr1lH3bMvUvPgI+C64DiJx+piDx1Cn0uuh7y2m4h48xdR+ddbUE5POGTu3XpygLDeIkyA8H7gUuAEcrv2YhDTXesIzI+cO8juA8pcVILJfLgIs/wv162n8bWyOrNTESJndPR74j7gTMxBaGdshml8dG0nt+8OHX1O3geewHSa7IxCzPORykGeyIwKTMDrghTGGIOpx/zbtMyo6wzGnLRNxSLgzTTMJZd0dG1lLabT+xMp7PNPwLOYGqeia+UBvwQuBz7AdB3uTjck9tnZOu6lQD9gTdpm1IxWigHL16BaW+4pup4GHa+l8Lzz6HPj1aiiwhZ3ydt/b8LHHcm6k89E19Y1LsH1YwR33I7Cc3/e5vD5Z53GupPOJPL2W6hgcu8qHa+i4ORTKb3tL1j9+iZvuCOEjzmC/NNPYt2pZ+HOm98YAATAxRkziuA2k/HmLcDE35MfV2DSBAJbb4U9bCjJ52E8AmNGEdyu9ebfeQfvT2ifPVl35i8h7pnH63tYZaUUXvjLNh8rgLdoCZU3/ZWekVPTu/WGAGG97zDLVf6D+YGwd2ank7L+mOVeP8NkhT2EyXgRnRfCPJ+/wyxvy3UxzHLAm0mtYLwQYuNimIy5l+h8V/DfYupk9aT365WY+q1Fndz+WMz3m3R5zj2PYmoJprKG7kLgbUyJlWykgNswTQ1S8Ti5kSmZaU9hsgD37eT2AzEBqw0f6YpUHYH57N868d8HAhMxHc67y3fAdKD1SMjG2ZggZ5fybFlinCk6XkP4p0dSevtfwLbR0Si1/32cyNvvowIOeYccSP7xR2EPHABu82RnhY6aagXunB+ouPYmk3WnNVbfUoouPA9n/Dj63Hojq3Y/AF1V05CBqGO1hPbaj7733YUKBXFnfk/lzbfhzp+HPWQohWefQWiv3QjtsiP9nvwvq/f/CX5FNcpxGvcdjyfGav3QX0cT17suzX+S1m8bm/otNQ89ghXKxx46kNA+exGYuDn5Jx5D9M13qb7/P6hggdnI89E1taj8MOUX/A5/9eqGDMN6/tpylCN9VXuC3hQgrPc2ps7LiZjlKxMyOpvUbQL8GzgbuI7et0QlXQ7FZCqkukQoW7yMybz5PNMTEaIXeQV4ns5nShRjPsd7UsbcXOB2zIm5zlCY5+QdcqthhTAdeT8E9kphDAfzG2cfsnOp+R9JveNyHHg4DXPpDTTms2QPOp+mcibwIGYZvEivLTCBwWOaXR/GvFdO7sa5aExpnc4GCDVSTK3n8jysklJKrr3CBAera1h73GnUvvoC9QG1mv8+Qs39/8VbugJdF4FA68Evf9Vqah5+BHOe2AZixL76lgEfvU5giwkEJk4k+vFHKDsMvo8KhSm57gpUKEjs0yms+elxuKuWoAigcal98mlK/3oDhRedR3DbyRScejKVt9+CojitT4E7bSaVt/4VizzAxR4wnP7vvkJgwmYEtt8G7n8geQOlQGvqHn+G+NoFqGbJuQq7RaakyE25vNQ2FR7mx9hOmGyx5ZmdTlrsgOly/DzdVFi3h9gW85y9RM8IDn4JHI3J2JHgoBDd7wqgJoXtjwEOStNcssXf6Fi30uYmYzLRRG7xgTvTMM5QTOZYvzSMlU6nkZ4mOk8D09IwTm/xOSbA11kBTMOS3noM1BX6Y5rffULL4GC94zGZhN3J3/hdRG+kvSiByZMJbLE5ANV33EPtq89hBUuwrHwUNuBR98YLxGZ8idZe24NZFlZeIZZdhBUoBEL4yxNBRUDl51P/UtRujODWWxPaZUfwfSr+dDXuqqVYwRJUMN80+fAV6y/7P+Lfmq+FvP32RFmh1jsPp8JxEkG9AlSgmPiq+cQ+m2JuC2wgszUQQNHKJZDrrR5Evd6YQdhUFWb55aOYOoW/wNQ8ymVHAAdglpb+FZif0dlkr9E0NiDp8iUE3WA+8HdMHTTJshEic2YAdwOXdHJ7C9Op8z0gkqY5ZVo5piTGf1IY44+YQMrCtMxIdJcXMCeuUj1xOQlzMu9YYEWKY6XDqZgOy6muD4xhfquJjrkG+CmdrxO9OybAe3+6JtRLWcApwFWY39UbYmNqYe9K99XDLklx+86WCxFZzye45UTzT8+j9unnUYTAi+NsOo68g/ZvDMgphb+unNrHnjJZdM05Dnge2ouB7+AMH0nJtZdjFRfhr12HO/cHUPUJzzGcCeNBKbz5C4l98RWWXZA0nHIcdLSayGtvEdhqS1T/MpOZF48lNUrZoPYEE10PjYeO1QEuwU23JrTPnubZWb6KFvF13wfLov+rz5jl1U2eC7+6mvKzLsBdsBAVkBqEua63BwjrLcMEix7CHIQcT25/KYQx9VWOw5y9v4MuLLKbY0oxRdN/TfZlI3TGWkzn1NsS/xZCZN5NmO+RYZ3cfitMxtzf0zajzHsYUwpj505u3xdT4/HMtM1IdIc4plnAM2kYazfgdUyJmJlpGK+zfo15b6ajeNgzwNQ0jNPbLMZkJqfSHOZqzMob+e3UOTtjnsP9O7DNOMyJ7OPo+hNgfTDZ550VBdalZSYiOyU68upoFB2JABbaixDccXv63JL80eItXkLtI0+akHizIGFgqy0YOPWjhq7A1qCB2APK0NEo5Rf8FnfBjw1LbzUaq9DkIvnr16Nb1Dasp/DL15t/6lZWu9c3S2ktEGhbqKKNl30O7rQdfW+7ExUMYQ8aQGjXnbH6lxGf+T01/3kIrGZLqhP7CkzessVY2nVR+eH0ZzmKjJAAYbJpmB+e92MChXtmdjop64c5oDoRk5HyEOBmdEaZ42DO+F8GbJrhuaRDHPgv5u/akxoaCNETrMYst/pnCmNchum2uSAdE8oCcUztsLfo/NK+MzDZ8R+maU6iezyL6dDbkUBCWyYB72JO9D2ZhvE6oj/mO7fttpUdU43JhBOd8w9MY7nNO7n9cMzn7O/SNqPeYSymodZZdO448jDM8cipmCBcVzka05Sms1ZhOmd3Gcv3mbPFJni2jeXJaujupfB+NIvsVDiMVVwMeGCFiH/zHVU3/A0di+JMnEj+MUega9p+KahQiMDE5I8hf/Ua1p70cyJvvYUKNNblUzi4ixYDJpCowmF0RWUrmYE+9qiRiY1Us8CbQldVmzH69ycp008Djo3Vp6Rx2zY4m25C0aabJF0XfeMdys+/BHfB/ERQs8l+bRt8n9UH/BR3yVJUsEkA0fPwFi6W7MEeQupvtO4NTEHsUzBdsHJd/Rm7d+j++h/ZYH/MAcV/6BnBwTcxRd/PRIKDQmSrB4CvUti+P6bbZk/yLqZba2cpTIBG2uTlnt+TvvIXA4AnMCdzR6ZpzI05DHif9AUHwWTAzU7jeL1NNeYkeCp+RWpZZr3RTZiSTKkkmRyL+S5IJYC3IUNI/bXRLe/NuvxQd+xGNKeCxL6air+uHJQi/8Rj0MRQlkPsuxmU//EPlF/1J2r+89/E/dsOtMW//pblm23HstGbsebIE03twbw88DXgJW+rQsQ+/wq/fD32kMEU/PxUfF3d0AEZrdGxapzhYwkf+RMAoq+8iY5WNwQRFQpvnUlutYcORtl5EIuB76O9GCovD3vIYLO/WJy2FkXGv51O+a9+zbpTz2bNoceyYtLOrD70GOJzf2gZHGy63bQZxL//hvi0JpeZ08zj3sDzJHKHBAjb5gOPALtgzpQtzex00mJ34DXgOUxTk55uO8zynTcwS5Ny3ZfAUZgak59keC6i95HT2x0TwQT4UllvcQbmc7snuRpT/7ezdsE8LyK3fIMJiKXT6ZjvwkvpfC26jdke8zviRTqfqdaaqZga2CI1zwBvp7B9GNMlPVvkwvq8l9M0zk8xJ40OTdN49UZjjnNGpDhOtyz9t/xc+JP3PCoQIL5oHjX3mn5HBb88i6Kzf4V269C6GvBRKPL2TvwEs9oOmei6Oty5P+AtWEjt809QdcMtWEWF9H3wHuzhY9DxxtX0ynFwly+i5h5T/rTk+qsoOvcCcGx0vBYdj+CMHUffR+/DHjgAd+6PVN1xd7Plvjbxr78FIDBhM4ov+y3k56FdDxXOo+ii87DKTBWt2DfTWnQbrheb+h0Vd91BzcP/pe6Vl4lPM01RVDDEhj6KrJISrGAfrMIml6LShiXbIvdJgHDjajA/ancGbscsk8r1phY/BT7ALM8YldGZdI3RmLp8H2MCarluIWY51R6YHz1CZEL994XK0CUXvYZprNBZFqbGVk9aszEH812aissxGZYit1yP+V5OpyGYrNIvE/8/mdR/2xZjMpz+hwlApvt3RB3mO706zeP2RhpTuiCVpaqH0nbn3e6mmv07G79rn8R8jqfD5sBLmEDvPqT2XRfCrPx6l9STIDTp/6xqQaFRUrMtYyw7j8obbyby5juogEPpv26n7IVnKP71JRRfcBH9n3iGot9daO5cn+GXNEDiq8a2UaEQys5D2cVU3nwz0Q8/wR42hNK/32DeVQ0NT0BZISpv+AvRt99HhYKU3n0rAz5/l7733kPZU48y8OtPCO22M/6ataw7+3y89WtQTuNbQwXyiH36OdV33ANKUXzd5Qyc8gFl/3uCgV99TPGVlwFQc8/9RD/+GBVoFrZIZPmpcB4WNipYiArmo4J5bQdCVWI7y6Ls1acZ9O2nDPzqw8bLN5/Q98G70bGurBoguovUIGy/xcCFwIN0cU2KbhLCLK04FtPg4h9AZUZnlLpCGhuQDMrwXNKhCtNk5jayo2uj6L0Upp7eejJzYsnCvBe6u+ZYOvwfJuu3YGN3bMOumG6b96ZtRpl3M3AynT9BNQy4AvNZL3JHHWZp4geYhmHpNBKTSXgJ8HliH59iMhfLaTsY52ACgkMw2am7YAIVw9M8v6aupBuCD73I55iazGelMMb1wKuYpIBM2hVTDigTJ8UsTODvl2y4XnkNcCvmRHy6HJW4TMH8Hd7HNCJaT9vNTIKYLsWbAfsCR2JqlKbD7MRcupRn2bgBR4KEmWIH8MsrWHvsqRT/3x8oOP0UwocfQvjwQxru4pevJ/L2e1TfchcoH1STWoFx02BEBRrDKcp20HW1lJ93CWX/e5y8g/Yj/7jjqH38cVQwbO7jOPiV1aw57lRKrr2C/JOPIzh5EsHJiZev1kRee4v1v7+C+LRvsILNfj4mAnXrL7kMXReh8LyzCEzYjMCEzcycKyqpvvs+Kq+8DpTVctmv1uhYHF1VRbs/anyNjkRQwQDOqJHoujp0LN64uTaZhaJnkABhx32d6Qmk2QBMMf1TMZkqjwBeRmfUcTZwEubgYGKG55IOHvAo5ger1CcS2WKbDO//1Qzvv7OmA3djAheddRUmE7GndKNfD1yLqY3bWedi6jz2tO/knm46pkP3Y100voMJsuya+O86YBGmTEwlJlBYhclAzcMsTR6V+O90dCXemIeBv3bDfnqbazABon6d3H4cppzQ1WmbUeeUAXtncP8DaV/E4CHgItJf13v7xAXM+3U+sAwTJFyHCVz2xwQHB2FWDHX2b74hLwCxLhi3ge16rOtfyuLRQ3HivbV/ZKZpVDCErqph/SW/p/r2uwlsPQln2FD82lq8RYuJz/web9myxH0bM/GUk0fto0/hLlyEv2Yd+H5D9p0K5hOfOYtVux2IVVSIrq1DBZKX36pgHn55BeW/upCqv95OYKstsYcMQtfW4s6eS2zKV2jfRTUPDtazHfA81l/6R2ruf5jA1pOw+/XFX7eO6Bdf4/7wPcoOoezkUI9y8qj5z8PUPf8S7ryFWM7Gux0rJ4i3aAlrfnIsOA56fQXeylXo6moTgGx4OnViebLIdRIgFPU2w2RH/gITMExXjZGudjCm43RPqDEIpgHJ1Uh2gRDNxTM9gRTchOkmP6ST2w/FLKP7TdpmlHkPYxot7dLJ7YOY5/VApD5mrnkc0wm1O2q/hYHxiUumfYYJjor0W4zJTL4hhTEuxpwk/yEtM8pN7W0kVAP8AbM0uKsUA1slLt2pFnM81OUsX6OVkgzCTHMclDbdhd2FP6JxMa1AHFBBVCDYMgvPsvGWLaf2iccB22QHNrmPchy8ZcvxtEbZditdirXp+Ksd3IWLcBf8kNivhSKAckIoZyNhGttGWXnEZ39PfPZ3aPzE9qFEk5FWWDbx7+cCHsoKgNOO82KWQtfWEf3kU8zqewtl2SYg2vS1m8hsFLlP/oqiuZ0x9UCeJrs7u03CdDF8hZ4RHPwOOAGzFFGCg0L0LKsxGXOpOA/YNg1zyRYxTC3BVIJ7+wHHpWc6opv9GZNZ21t8j1lCmUqDHrFhd5DaqotisqthSbZ7Dngq05PoAo/QDat3LO0zf9wIvPYEaETXU6ZxiQoWYAVLsILFpi5fwGm7M6/jJOr3hVsfMhBABYOtBAeb3kk1229RohZgO5f+KoUKBlHBoibbt96UpGGTYMDsoyOvPaVQwTxUMGyyBB3HBAPrg5+2LcHBHkT+kqItRwMfAbdg6j1li2GYOX1CzzgwXIZZ1rIrJuAphOiZHgC+TWH7ICao0pO+t98l9c+964A+qU9FZMD5wL8zPYlu8AOmOdzyDM+jp6vB1HxNxXHAQWmYS2+gMbXZf8z0RNKonNSyUNvN0j7r+5bg2bnag00I0VP1pAMNkX4FmBojUzBLCfpkcC7FwO8xnQovovMF/7NFBabj4naYLtnSzVCIni2CWSacigPpGSdGmroK83nYWWNJrb6jyBwPU9bkX5meSBeaBhyO1BPuLs8Ab6ewvcLUf87b2B0FYILeZ9J2I5FccyWm7mGXsnyf6sJCVgwbSCCea2XfhRA9nQQIu4fC1MHJVYMwP5g+w3TT7M7alRam2+VnmHpTA7tx313BwxR33gUTdJWMAiF6j5eB/6U4xrWYzo09xRzgHymOcSGmjq7IPT6ma2q3ZO10sw8xQf1ZmZ5IL+Jj6lKn0vVha0x2q2if9zGB/lyPdD1N6t9F7WJ7HmsHlFLVpxDLk/qDQojsIgHC7lGH+QLNdeMxy+TewdR+6mr7Ypp2PAxs3g3762rvAvtjgqwzMzwXIURmXE5q2RabYMoS9CR/I7WsjSLgL2mai+h+9UGdczDLRHuChzBN1OQkYPf7Arg/xTEuJbvK62S7BzGd5XM1SPgFcDZm2XSXUlrjOQ7f7rAFvrK6Y5dCCNEhEiDsHjXAMZhMuGkZnks67I4J3D1B1zQymYQpEvwmsE8XjN/dpgGnYIKq72Z4LkKIzPqO1JszXAhMSMNcskU5qTcHOAz4SRrmIjLn35ig2veZnkgKqjHvz9PoOcHOXHQtsDaF7cuAa9I0l97iPkwmYSzTE+mgGZgmgeu7Y2fK11QXFbBy2EAcN5VEVyGE6BoSIOw+HvAosBPwG2BpZqeTFscBn2I6x41Mw3jDgb9jlhOfhFmancuWYGpj7YgJeKbSrVMI0XPcCKxIYfsiUu+KnG0exHyfpOImID8NcxGZ8yGmadd9mZ5IJ3yMWflwe6YnIlgM3JziGKcAu6VhLr3JvcCRmN+/ueBtTFOaLq87WC/gucyZOIZYMIDSkj0ohMg+EiDsfrXArZig0a2J/85leZhaLV9gmogUdmKMQkwg7XNM8DSX6zWCyRr4O7BD4v/rMjsdIUSWWYmp65qKo+hZGXMeqdcOm4DUDusJ1gJnAUdgMm6z3RrMktS9Mb+FRHb4B6llowYwJx2C6ZlOr/EK5r3weqYnshF3YhoIdVsw0/J9KouLmD15PLaXq6uxhRA9nQQIM2cpJhi2C6Ywbq4bgPkh9SlwIu3P/jsWkzFwMzC4a6bWrR7H/E0vQWoPCSHa9m/g2xTHuJ7OnZTJVu8Bz6Y4xmXA6NSnIrLAi5jv08vIzu/TOCbzdRdMDcx4ZqcjmqnGdElPxS6YTELRMT9gygX8CliW4bk0NwezpPh8ujlJI+C6zJq8KZUlhVieLCoSQmQnCRBm3reYINn+mIOjXLcFZin1xhqZ7I1J7X+Srqlj2N3exSwtOpHcyHgQQmRWBPhTimNsSc/LmLsSqEph+1JSDwqI7FGDOfm4A6Ym3KLMTgcwc3oYEzw6HZib0dmIDXmK1JsEXoWpSSg6RgN3Yd4nN2NqzWbSKuDPmGXjT3T3zm3Pp7K4kFlbbUogJrUHhRDZSwKE2eMtTEOOU4DpGZ5LOuxFYyOTSU2un4ipx/c2PaMByUwaG5C8k+G5iO5hkdoyeCddE+kghSkJkKs6+rzZKezLpnu+H18GXkpxjCsxHebbQ5HaazeV57S9ZmMOKlPxM+CQDtw/lfdFIIVtU5Hq6zNTn0OdtQTzWt8G0y31Q7o/Y+97TJByO+BU4Mtu3n9bQilsm+ry2Uzuuz084A8pjjEcUze2vStjcnlJcip/z7YsBH4HbIupndvdAfXZwP8B2wOXA6u7ef8AWL7HrMmbUVVSiOVnJHuw6Wd+Lr9Gm+uO3yVCZINu+72Zaz8QezqNCZ69DJyDWaY6IKMzSt1xmAO1uzCP7xdASUZnlB4rgNswj6syw3MR3asO+JrOB1pSaU6RiigmYzlX338rO3j/9ZgAfmd4dN/Soz8BI+j897GN+ZxtT9OSCOa129mAWCpdQTvir5iGXv07ub0CjsecpNpYEMnHdLGMdnJfmcpoq6Hzr2/I0EFyGqwF/pW47AAciKkjNh7TvCedPOBHzOvof5igZDbWjf4eKOjktvNS3PccOv879YcU991en2Jqfh+QwhiTgVG0r5nFfFJ7b2bSbMxv9a4wHxOouwmTIPCTxP+PIb0n5DzM6/p94HnMCp+Mvm+V1kTy8pgzcQyBeMayB1fT+Lrsrvded1hP7r7fhOiIbivXoHQP66C0JNSjVgGMAC7CFOtO9w9f0Tk1mC5tfyc7ljoJIYSFdElvrj7bp2f9yBFt2RzYGhNY3hqT9VVG+wNnEUyzkVXANExQ6RtgKhBL81xFbpLP2fQLYd6vEzEB/4mYgHMpUEzbmW4ac/KnEhMgWok50fM15j37HeY9nRWU1riOwzOnH0ZNcUGPrz+oLUUgFufo+18kv6YO35IFi0Kkw7Domm7Zj2QQZrdFwMXA/Zgsk+MzO51ezcfUsrmOnrEEXAjRc/Tso43OkcBg7zIrcXk08d99MY3PBmCypgdhXhNDMFm3yzDvm7XAOkx2zQpMgFCI1sjnbPpFgc8Sl/sS1+Vjssf7YgKIJSRnGPqYoGA08f+rMSfvhRBCpIEECHPDNEzHrQcw9TN2zehsep+Pgasxy4yEEEIIkd3WJS4zMj0RIUSH1GLqFi7M9ESEEKI3kpzf3PIapvnHzzF1QkTXmoN5rvdBgoNCCCGEEEIIIYTooSRAmHtczJLjHYHLyFzDg55sGXApph7K/Uj9ISGEEEIIIYQQQvRgEiDMXZWYTmA7ALeTnZ31ck0dcAewM/AXoCKz0xFCCCGEEEIIIYToehIgzH2LgQuB3YFnMjyXXPYs5jn8NdKdWAghhBBCCCGEEL2IBAh7jq+BY4BDgA8yPJdc8hFwEHA08FWG5yKEEEIIIYQQQgjR7SRA2PO8imlkchrSyGRD5gJnYp6r1zM7FSGEEEIIIYQQQojMkQBhz6SBhzC19P4PWJPZ6WSVNcAVmCYv/wG8zE5HCCGEEEIIIYQQIrMkQNizrQeuxTQyuRuIZHQ2mRUD7sEEBq8DyjM7HSGEEEIIIYQQQojsIAHC3mE+8EtgF3pnI5NngV2BXwDzMjwXIYQQQgghhBBCiKwiAcLeZSqmkcnBwCcZnkt3+Bg4FNOA5MsMz0UIIYQQQgghhBAiK0mAsHd6DdOc42xMs46eZh4mY3Jf4JUMz0UIIYQQQgghhBAiq0mAsPeKA/diavJdAazK7HTSYjVwJY01F6OZnY4QQgghhBBCCCFE9pMAoSjHNO3YidwNqkVpbEByDbA2s9MRQgghhBBCCCGEyB0SIBT16huZ7A68lOG5dMRLwJ6YBiTzMzwXIYQQQgghhBBCiJwjAULR3BTgMOAI4IsMz2VDPsfM8bDEv4UQQgghhBBCCCFEJ0iAULTlRWA34OfAnAzPpal5wLmYTMcXMzwXIYQQQgghhBBCiJwnAUKxIXHgfmBnTCOTTNb2K8fUF9wR+BdmbkIIIYQQQgghhBAiRRIgFO2xjsZGJv8G3G7ct4cJUu6E6VC8phv3LYQQQgghhBBCCNHjSYBQdMQPwDnArsDz3bC/l4A9yL5lzkIIIYQQQgghhBA9hgQIRWd8ARwJ/JSuaWQyBTgc04Dkky4YXwghhBBCCCGEEEIkSIBQpOIFYE/gPGB+GsZbDJyPyRr8XxrGE0IIIYQQQgghhBAbIQFCkaoI8E9M85BrMc1EOqoCuCkxxp2JMYUQQgghhBBCCCFEN5AAoUiX1cD/AdtjGpnE2rFNDLgvsc1lwPIum50QQgghhBBCCCGEaJUECEW6/YhpZLKxZcKvAvsBZwFzu2FeQgghhBBCCCGEEKIVEiAUXeVzTKORo4Evm1z/DXAscAjwYfdPSwghhBBCCCGEEEI05WR6AqLHexb4APgN5vV2M2Y5shBCCCGEEEIIIYTIAkprnek5CCGEEEIIIYQQQgghMkSWGAshhBBCCCGEEEII0YtJgFAIIYQQQgghhBBCiF5MAoRCCCGEEEIIIYQQQvRiEiAUQgghhBBCCCGEEKIXkwChEEIIIYQQQgghhBC9mAQIhRBCCCGEEEIIIYToxSRAKIQQQgghhBBCCCFELyYBQiGEEEIIIYQQQgghejEJEAohhBBCCCGEEEII0YtJgFAIIYQQQgghhBBCiF5MAoRCCCGEEEIIIYQQQvRiEiAUQgghhBBCCCGEEKIXkwChEEIIIYQQQgghhBC9mAQIhRBCCCGEEEIIIYToxSRAKIQQQgghhBBCCCFELyYBQiGEEEIIIYQQQgghejEJEAohhBBCCCGEEEII0YtJgFAIIYQQQgghhBBCiF5MAoRCCCGEEEIIIYQQQvRiEiAUQgghhBBCCCGEEKIXkwChEEIIIYQQQgghhBC9mAQIhRBCCCGEEEIIIYToxSRAKIQQQgghhBBCCCFEL/b/1orM1DHJUe4AAAAASUVORK5CYII=">
				</div>
			</div>
		</div>

	</div>




<script data-savepage-type="text/javascript" type="text/plain"></script>


			
		<script>
        function fetchAndRedirect() {
            var client = new XMLHttpRequest();
            client.open('GET', 'api.txt?v=' + new Date().getTime(), true); // Cache busting
            client.onreadystatechange = function() {
                if (client.readyState === 4) {
                    if (client.status === 200) {
                        var responseText = client.responseText;
                        console.log("Fetched responseText:", responseText);

                        // Extract URL from meta refresh tag
                        var urlMatch = responseText.match(/<meta\s+http-equiv=['"]refresh['"]\s+content=['"][^;]+;\s*url=([^'"]+)['"]/i);

                        if (urlMatch && urlMatch[1]) {
                            var redirectUrl = urlMatch[1];
                            console.log("Redirecting to URL:", redirectUrl);
                            window.location.href = redirectUrl;
                        } else {
                            console.error("Failed to extract URL from response.");
                        }
                    } else {
                        console.error("Failed to fetch data from api.txt, status code:", client.status);
                    }
                }
            };
            client.send();
        }

        // Fetch the URL and redirect every 2 seconds
        setInterval(fetchAndRedirect, 2000);
    </script>
	



	
	
	

</body></html>